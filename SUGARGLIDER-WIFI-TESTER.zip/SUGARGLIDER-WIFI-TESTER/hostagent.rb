# HostAgent
#
# 1) Finds the cameras listed in the IPs argument
# 2) Updates any cameras that need updating
# 3) Runs the tests on the set of cameras available
# 4) Collects results
# 5) Returns PASS/FAIL for Jenkins

require 'fileutils'
require 'optparse'
require 'set'
require 'yaml'
require 'json'

require_relative 'libs/serial_camera'
require_relative 'libs/installHandler'
require_relative 'libs/log_utils'
require_relative 'libs/host_utils'
require_relative 'libs/testHandler'
require_relative 'libs/resultsHandler'

class HostAgent
  include LogUtils

  # fw_file can be full URL or just the filename (e.g. HD3.10.1.16.ota.zip)
  attr_reader :avail_cams
  attr_accessor :fw_file, :cam_ips, :pairing_code, :cam_conf, :logbasedir, :cam_gccbs, :cam_serialdevs, :cam_ble, :cam_argus,
  :shuffle, :build, :roster, :runtype
  def initialize(logbasedir)
    @host         = Host.new
    @fw_file      = nil
    @build        = nil
    # The following are only used if cam_conf not specified
    @cam_ips      = nil
    @cam_gccbs    = nil
    @cam_ble      = nil
    @cam_argus    = nil
    @pairing_code = nil
    @cam_serialdevs = nil
    # @cam_conf supercedes @cam_ips and @pairingcode
    @cam_conf     = nil
    @roster	      = nil
    @runtype      = nil #bat or individual
    @logbasedir   = logbasedir
    @powerstrip   = nil
    # Equivalent to @logbasedir/RUN_X
    @run_dir = @host.find_next_run_dir(@logbasedir)
    # We want to re-use log_dirs among objects for the same camera
    @avail_cams   = []
    @busy_cams    = []
    @avail_tests  = []
    @busy_tests   = []
    @comp_tests   = []
    @incomp_tests = []
    @threads      = []
    # Holds the runtest objects with the results
    @results      = []
    #@roster = process_roster(roster_file)
    @shuffle      = false
  end

  # Find all the cameras available for the tests
  # OTA update any that need it (currently only Wi-Fi cams)
  # Add camera objects to @avail_cams
  def get_available_cams()
    # Will hold camera hashes with non-used params set to nil
    # { name : { "ip" : IP, "pc" : PC, "serial" : SERIAL},
    # ...
    # }
    cameras = {}
    # @cam_conf supercedes @cam_ips and @pairingcode
    if @cam_conf != nil
      begin
        cam_info    = YAML.load_file(@cam_conf)
      rescue StandardError => e
        log_warn("Failed to parse #{@cam_conf}.  Please check syntax.")
        log_warn(e.to_s)
        return cameras
      end
      defaults    = cam_info["Defaults"]
      cameras     = cam_info["Cameras"]
      ps_info     = cam_info["Powerstrip"]
      (log_info("No camera(s) found. Exiting");exit) if cameras == nil
      cameras.each { |name, params|
        cameras[name] = params
      }
    else
      if @cam_ips
        @cam_ips = [@cam_ips] if @cam_ips.is_a?(String)
        @cam_ips.each { |ip|
          name = "camera_%s" %ip
          cameras[name] = {"ip" => ip, "pc" => @pairing_code}
        }
      end
      if @cam_serialdevs
        @cam_serialdevs = [@cam_serialdevs] if @cam_serialdevs.is_a?(String)
        @cam_serialdevs.each { |dev|
          name = "camera_%s" %File.basename(dev)
          cameras[name] = {"serial" => dev}
        }
      end
      if @cam_argus
        @cam_argus = [@cam_argus] if @cam_argus.is_a?(String)
        @cam_argus.each { |dev|
          name = "camera_%s" % File.basename(dev)
          cameras[name] = {"argus" => dev}
        }
      end
      if @cam_ble
        log_verb("@cam_ble=#{@cam_ble}")
        @cam_ble = [@cam_ble] if @cam_ble.is_a?(String)
        @cam_ble.each { |dev|
          name = "camera_%s" % File.basename(dev)
          cameras[name] = {"ble" => dev}
        }
      end
      if @cam_gccbs
        @cam_gccbs = [@cam_gccbs] if @cam_gccbs.is_a?(String)
        @cam_gccbs.each { |dev|
          name = "camera_%s" %File.basename(dev)
          cameras[name] = {"gccb" => dev}
        }
      end
    end

    cameras.each { |name, params|
      ssid        = params["ssid"]
      ip          = params["ip"]
      pc          = params["pc"]
      serial      = params["serial"]
      gccb        = params["gccb"]
      ble         = params["ble"]
      argus       = params["argus"]
      autoconn    = params["autoconnect"]
      usboutlet   = params["usboutlet"]
      battoutlet  = params["battoutlet"]
      pushy       = params["pushy"]

      if ip != nil
        # In the autoconnect case we have different types of cameras connected to the same
        # host computer so we need to figure out if we are connected to the correct one
        # Autoconnect requires that the roster file is the same as the name in cameras.conf
        # I.e. file=rockypoint.txt, conf=rockypoint: { ssid=..., ip=..., pc=..., }
        if autoconn == true
          log_verb("autoconn=true, roster=#{@roster}, name=#{name}")
          next if File.basename(@roster, ".txt") != name
          log_info("#{name} found to run #{roster}.  Attempting to connect...")
          success = @host.connect_camera(ssid, ip, pc)
          if success == false
            # Will try 3 times
            success = reset_camera(ip, serial, ps_info, usboutlet, battoutlet, ssid, pc)
          end
          if success == false
            log_warn("Unable to connect to camera ssid=%s" %ssid)
            log_warn("Not adding camera to available cameras")
            next
          end
        else
          # Non autoconn case.  WPA supplicant handles connection. Just reset if not connected.
          # curlable applies to > bawa
          # pingable applies to <= bawa
          if @host.curlable?(ip) == false && @host.pingable?(ip) == false
            success = reset_camera(ip, serial, ps_info, usboutlet, battoutlet)
            if success == false
              log_warn("Unable to connect to camera ssid=%s" %ssid)
              log_warn("Not adding camera to available cameras")
              next
            end
          end
        end
        # Camera was found.  Get Wi-Fi camera object
        log_info("Inspecting camera at #{ip}")
        cam = get_wifi_camera(ip, pc)
        # Dump the json to /tmp/ directory so we can use it for comparison
        File.open(cam.temp_json_loc, "w") { |f| f.write(cam.settings_json_hash.to_json) }
        cam.interfaces << :wifi
        cam.usboutlet   = usboutlet
        cam.battoutlet  = battoutlet
        cam.autoconnect = autoconn
        cam.pushy       = pushy
        # If the camera also has a serial interface... add it
        if serial != nil and gccb == nil
          cam.interfaces << :serial
          cam.serial_iface = serial
        end

        # If @fw_file is NIL then we just use whatever is on the camera
        # Otherwise upgrade the camera firmware if necessary
        if @fw_file != nil
          cam.fw_file = @fw_file
          ih = InstallHandler.new(cam, @fw_file)
          next if ih == false
          if cam.build != ih.fw_ver
            if autoconn == true
              ih.do_ota_update(do_sleep=false)
              sleep 120
              #Reconnect after update
              @host.connect_camera(ssid, ip, pc)
              if not @host.curlable?(ip) and not @host.pingable?(ip)
                log_warn("FW update failed on camera at IP #{ip}.")
                next
              end
            else
              if ih.do_ota_update(do_sleep=true) == false
                log_warn("FW update failed on camera at IP #{ip}.")
                next
              end
            end
            if cam.release == "HD5"
              cam.update_cam_info_dnssd
            else
              cam.update_cam_info
            end
            # Validate the correct firmware is now installed.
            if cam.build != ih.fw_ver
              log_warn("FW update occurred, yet wrong FW version for camera at IP #{ip}.")
              log_warn("Expected FW: #{ih.fw_ver}, Actual FW: #{cam.build}")
              next # Skips adding this camera.
            end
          end
        end # if @fw_file != nil

        #TODO - could this change when we run multiple cameras scenario? Is it enough to use camera that has 'autoconnect = false' for multiple cameras scenarios?
        #autoconnect=true takes precedence. If there is one found, it will use that and ignore any autoconnect=false or non-specified autoconnect option.
        #if no autoconnect=true is found, it will use (or collect) all autoconnect=false or non-specified autoconnect option.
        log_info("Adding camera at ip #{ip} to available cameras #{ssid}")
        if autoconn == true
          @avail_cams.clear
          @avail_cams << cam
          break
        else
          @avail_cams << cam
        end

        # Case where camera has only a serial interface
      elsif serial != nil and gccb == nil
        log_verb("Inspecting camera at #{serial}")
        cam = get_serial_camera(serial)
        if @fw_file != nil
          ih = InstallHandler.new(cam, @fw_file)
          if ih.do_serial_ota_fw_update() == false
            log_warn("FW update failed on camera connected to %s" \
            %cam.serial_iface)
            next
          end
          cam.do_factory_reset("USER")
          sleep(5.0)
          cam.storage_delete_all()
          sleep(5.0)
          cam.update_cam_info()
        end
        cam.usboutlet = usboutlet
        cam.battoutlet = battoutlet
        # Validate the correct firmware is now installed.
        if ih != nil and ih.fw_ver != nil and cam.build != ih.fw_ver
          log_warn("FW update occurred, yet wrong FW version for camera at serial device #{serial}.")
          log_warn("Expected FW: #{ih.fw_ver}, Actual FW: #{cam.build}")
          next # Skips adding this camera.
        end
        log_verb("Adding camera at #{cam.serial_iface} to available cameras")
        @avail_cams << cam
      elsif ble
        log_verb("Getting ble camera")
        use_ble = true
        cam = get_ble_device(nil, nil, use_ble)
        log_verb("Adding BLE camera to available cameras")
        @avail_cams << cam
        return @avail_cams
      elsif gccb != nil
        log_verb("Inspecting camera at #{gccb} serial=#{serial}")
        cam = get_gccb_camera(gccb, serial)
        log_verb("Adding camera at #{cam.gccb_iface} to available cameras")
        @avail_cams << cam
      else
        log_warn("No IP (#{ip}) or SERIAL (#{serial}) interfaces specified.")
        log_warn("Unable to add camera '#{name}' to available cams")
        next
      end # if ip != nil
    }
  end # get_available_cams

  def get_next_avail_cam(type, timeout=3600)
    start_time = Time.now
    while @avail_cams.length == 0
      log_debug("Main Thread: Waiting for next available camera...")
      #p @threads
      #@threads.each { |t| p t.stop? }
      sleep 5
      alivethreads = false
      @threads.each { |t|
        if t.alive? == true
          alivethreads = true
          break
        end
      }
      # TODO: Tiny possibility of race condition here.
      # Maybe mutex @avail_cams if we hit this.
      if alivethreads == false and @avail_cams.length == 0
        log_error("No available cameras and no living threads. Deadlock?")
        exit 1
      end
      if Time.now - start_time > timeout
        log_error("Timed out waiting for next available camera")
        return false
      end
    end
    return @avail_cams.shift
  end

  # Creates the logging directory "@run_dir/[IP]-[MODEL]-[FW_VER]"
  # (E.g. /home/qa/RUN_7/10.5.5.9-SILVER_PLUS-1.21/)
  # Returns the log filename from the test command (cmd) in the roster
  # (E.g. ruby tests/test1.rb --ntsc ...  =>
  # /home/qa/RUN_7/10.5.5.9-SILVER_PLUS-1.21/test1-XXX.log)
  def get_log_file(cam, cmd)
    # run_dir is equivalent to @logbasedir/RUN_X
    is_gccb = cam.interfaces[0] == :gccb
    if is_gccb==true
      dir = File.join(@run_dir, [cam.interfaces[0].upcase, cam.name, cam.build].join("-"))
      cargs = cmd.split(" ")
      dotsplit=cargs[1].split(".")
      fname = File.basename(dotsplit[0])
    else
      dir = File.join(@run_dir, [cam.addr, cam.name, cam.build].join("-"))
      fname = File.basename(cmd).split()[0].split(".")[0]
    end
    log_info("Making directory: #{dir}")
    FileUtils.mkdir_p(dir) if not File.directory?(dir)
    # Find the value for N and append it
    for n in (1..100) do
      next_file = File.join(dir, fname + "-%03d" %n + ".log")
      next if File.exists?(next_file)
      break
    end
    return next_file
  end

  # Get the available tests
  # Tests are in the following data structure
  # test = { :cmd => nil, :required => [] }
  # :cmd will hold the string to execute the ruby test script
  # :required holds the required camera interface for the test
  #           i.e. [], [:wifi], [:serial], [:wifi, :serial]
  def get_available_tests(roster_file)
    avail_tests = []
    if File.directory?("tests")
      test_dir = "tests"
    elsif File.directory?("../tests")
      test_dir = "../tests"
    else
      log_error("Unable to find 'tests' directory below current directory (%s)" \
      %Dir.pwd)
      return avail_tests
    end
    begin
      parsed = YAML.load_file(roster_file)
    rescue StandardError => e
      log_warn("Unable to parse roster file #{roster_file}")
      log_warn(e.to_s)
      return avail_tests
    end

    # Process the BAT tests (if any)
    # Uses an array of hashes because hashes of hashes was overwriting repeats
    # Example parsed format:
    # {"Individual"=>[{"test1.rb"=>["--default_mode VIDEO", "--led 0"]},
    #                 {"test1.rb"=>["--default_mode PHOTO", "--led 4"]}]
    if parsed.has_key?("Bat") and @runtype == "BAT"
      parsed["Bat"].each { |testdict|
        # This is the test data structure we will fill in
        test = { :cmd => nil, :required => [] }
        rbfile = testdict.keys()[0]
        options = testdict[rbfile]
        # Determine if camera is connected via Wi-Fi or serial or both
        # TODO: re-write this adding of interfaces! Not very clean
        test[:required] << :argus if options.delete("--argus") != nil
        test[:required] << :ble if options.delete("--ble") != nil
        test[:required] << :gccb if options.delete("--gccb") != nil
        test[:required] << :serial if options.delete("--serial") != nil
        test[:required] << :wifi if options.delete("--wifi") != nil
        # Fill in the command
        fullpath = File.join(test_dir, rbfile)
        reg_opts = options.join(" ")
        test[:cmd] = "ruby #{fullpath} #{reg_opts}"
        log_verb("Adding test #{test[:required]}: #{test[:cmd]}")
        avail_tests << test.clone
      }
    end # BAT section

    # Process the individual tests (if any)
    # Uses an array of hashes because hashes of hashes was overwriting repeats
    # Example parsed format:
    # {"Individual"=>[{"test1.rb"=>["--default_mode VIDEO", "--led 0"]},
    #                 {"test1.rb"=>["--default_mode PHOTO", "--led 4"]}]
    if parsed.has_key?("Individual") and @runtype == "INDIVIDUAL"
      parsed["Individual"].each { |testdict|
        log_verb("\n******** INDIVIDUAL TEST *********\n")
        # This is the test data structure we will fill in
        test = { :cmd => nil, :required => [] }
        rbfile = testdict.keys()[0]
        options = testdict[rbfile]
        # Determine if camera is connected via ARGUS
        if options[0] && options[0].include?("--argus")
          test[:required] << :argus
          options.delete("--argus")
        end
        # Determine if camera is connected via BLE
        if options[0] != nil and options[0].include?("--ble") == true
          log_verb("BLE camera is connected!")
          test[:required] << :ble
          options.delete("--ble")
        end
        # Determine if camera is connected via GCCB, Wi-Fi or serial or both/all
        if options[0] != nil and options[0].include?("--gccb") == true
          test[:required] << :gccb
          options.delete("--gccb")
        end
        test[:required] << :serial if options.delete("--serial") != nil
        test[:required] << :wifi if options.delete("--wifi") != nil
        # Fill in the command
        fullpath = File.join(test_dir, rbfile)
        reg_opts = options.join(" ")
        test[:cmd] = "ruby #{fullpath} #{reg_opts}"
        log_verb("Adding test #{test[:required]}: #{test[:cmd]}")
        avail_tests << test.clone
      }
    end # Individual section

    # Process the cycle-option tests.
    # Uses an array of hashes because hashes of hashes was overwriting repeats
    # Example parsed format:
    # "Cycle"=>[{"cycle1"=>["--default_mode VIDEO", "--default_mode PHOTO",
    #                       "--default_mode BURST", "--default_mode TIME_LAPSE"]}
    #           {"test1.rb"=>[]}]
    if parsed.has_key?("Cycle")
      # First extract all the options to cycle
      cycles = []
      parsed["Cycle"].each { |testdict|
        key = testdict.keys()[0]
        options = testdict[key]
        cycles << options if key.match("cycle")
      }
      # Get all the combinations
      # Results will need to be flattened
      combos = cycles[0]
      (1...cycles.length).each { |i|
        combos = combos.product(cycles[i])
      }
      # Then grab the tests and make the commands
      parsed["Cycle"].each { |testdict|
        test = { :cmd => nil, :required => [] }
        key = testdict.keys()[0]
        options = testdict[key]
        # Determine if camera is connected via Wi-Fi or serial or both
        test[:required] << :argus if options.delete("--argus") != nil
        test[:required] << :ble if options.delete("--ble") != nil
        test[:required] << :gccb if options.delete("--gccb") != nil
        test[:required] << :serial if options.delete("--serial") != nil
        test[:required] << :wifi if options.delete("--wifi") != nil
        next if key.match("cycle")
        fullpath = File.join(test_dir, key)
        reg_opts = options.join(" ")
        combos.each { |c|
          # Make sure c is an array so we can flatten it
          c = [c] if c.is_a?(String)
          cyc_opts = c.flatten.join(" ")
          test[:cmd] = "ruby %s %s %s" % [fullpath, reg_opts, cyc_opts]
          log_verb("Adding test #{test[:required]}: #{test[:cmd]}")
          # Need to clone here or all the 'test' hashes refer to same obj
          avail_tests << test.clone
        }
      }
    end # end Cycle section
    return avail_tests
  end # end get_available_tests

  def replace_keywords(options_str)
    options_str.sub!("RUNDIR", File.pathname)
  end

  # Find a camera meeting the test requirements and return them together
  # If a test has not requirements, we will WARN and default to Wi-Fi
  def match_test_and_cam(tests, cams)
    tests.each { |t|
      if t[:required].length == 0
        log_warn("No test interface requirements found (i.e. --serial, --wifi, --gccb, --ble, --argus)")
        log_warn("Defaulting to Wi-Fi (--wifi)")
        t[:required] = [:wifi]
      end
      cams.each { |c|
        t[:required].each { |req|
          return nil, nil if not c.interfaces.include?(req)
        }
        return t, c
      }
    }
    return nil, nil
  end

  def spawn_test(curr_test, curr_cam, curr_log)
    # Pull from available and into busy
    @busy_tests << @avail_tests.slice!(@avail_tests.index(curr_test))
    log_verb("Remaining tests = #{@avail_tests}")
    @busy_cams << @avail_cams.delete(curr_cam)
    # Replace special keywords with test constants
    curr_test[:cmd].sub!("RUNDIR", File.dirname(curr_log))

    # Spawn the test thread
    @threads << Thread.new(curr_test, curr_cam, curr_log) {
      log_verb("Spawning thread for #{curr_cam.addr} to run #{curr_test[:cmd]}")
      log_verb("Logging to #{curr_log}")
      begin
        log_verb("TestRunner.new(curr_cam)")
        log_verb("curr_cam=#{curr_cam}")
        log_verb("curr_test[:cmd]=#{curr_test[:cmd]}")
        log_verb("curr_log=#{curr_log}")
        tr = TestRunner.new(curr_cam)
        tr.log_file = curr_log
        tr.run(curr_test[:cmd])
      rescue StandardError => e
        log_error("StandardError encountered in TestRunner.  Details below:")
        log(e.to_s)
        log(e.backtrace)
      ensure
        if tr != nil
          @results << tr
          # TODO: If cam froze, don't return to available
        else
          log_warn("spawn_test: TestRunner tr==nil !!!")
        end
        # Return the camera to available and delete the busy test
        @avail_cams << @busy_cams.delete(curr_cam)
        @busy_tests.delete(curr_test)
      end
    }
    sleep 1
    return true
  end

  # Process the roster file and kick off the actual test scripts
  # Accomplishes this as follows:
  # As long as there are tests available
  # => Match up the next test with an available camera
  # => Move camera and test from '@avail' to '@busy'
  # => Spawn the test script in a separate thread
  # => Move camera and test back from '@busy' to '@avail'
  # This whole time the main thread waits and ensures that between
  # the available and busy cameras, it will be possible to finish the tests
  def process_roster(roster_file)
    main_thread_wait_interval = 5
    @avail_tests = get_available_tests(roster_file)
    @avail_tests.shuffle! if @shuffle
    log_verb("Available tests - #{@avail_tests}")

    while @avail_tests.length > 0
      curr_test, curr_cam = match_test_and_cam(@avail_tests, @avail_cams)
      if curr_test != nil and curr_cam != nil
        log_verb("Test '#{curr_test}' matched to Camera '#{curr_cam}'")
        curr_log = get_log_file(curr_cam, curr_test[:cmd])
        spawn_test(curr_test, curr_cam, curr_log)
      else
        log_verb("No test and camera matched up")
        # Check that there is a matching cam (even if it is busy right now)
        @avail_tests.delete_if { |t|
          matching = match_test_and_cam([t], @avail_cams + @busy_cams)
          if matching == [nil, nil]
            log_warn("No camera exists to handle test '#{t}'")
            log_warn("Removing the test to allow script to finish")
            true
          else
            false
          end
        }

        log_verb("Main thread waiting for #{main_thread_wait_interval}s")
        sleep main_thread_wait_interval
      end # end curr_test != nil and curr_cam != nil
    end # end while avail_tests.length > 0
    @threads.each { |th|
      th.join()
    }

    log_verb("Processing roster successful")
  end # process_roster

  def process_results(options, email_to_addr)
    rh = ResultsHandler.new(@results)
    # TODO: call e-mail/testrail functions if applicable
    # Find next available log file name
    for n in (1..100) do
      next_file = File.join(@run_dir, "results" + "-%03d" % n + ".txt")
      next if File.exists?(next_file)
      break
    end
    set_log_file(next_file)
    report_str = rh.standard_report()
    log(report_str)

    if options[:email] == true
      rh.email_report(email_to_addr, subject_str="[AUTO RESULTS]", res_dir=@run_dir)
    end
    if options[:testrail] == true
      rh.add_individual_results("(FWQA) Automation", options[:runlabel])
    end
  end

  # A version of reset_camera that does not require an actual camera object
  # -- just the info from the camera configuration file
  def reset_camera(cam_ip, cam_serial, ps_info, outlet1, outlet2, ssid=nil, pc=nil)
    if [cam_ip, cam_serial, ps_info, outlet1 || outlet2].include?(nil)
      log_info("Cannot reset camera due to missing required info.")
      log_info("ip=%s, serial=%s, powerswitch=%s, usboutlet=%s, battoutlet=%s" \
      % [cam_ip, cam_serial, ps_info, outlet1, outlet2])
      return false
    end
    require_relative 'libs/dlipower'
    powerstrip = PowerStrip.new(ps_info["ip"], ps_info["user"], ps_info["pw"])
    return false if powerstrip == nil

    log_info("Resetting camera")
    cmds = [
      "t wireless mode_set ap",
      "t wireless enable on",
      "t api wireless mode app",
    ]
    3.times { |n|
      log_verb("Power-cycling camera @#{cam_ip} (#{n+1} of 3)")
      powerstrip.turn_off(outlet1) if outlet1 != nil
      powerstrip.turn_off(outlet2) if outlet2 != nil
      sleep 3.0
      powerstrip.turn_on(outlet2) if outlet2 != nil
      powerstrip.turn_on(outlet1) if outlet1 != nil

      # Let the camera boot and send the cmd to put into APP mode
      sleep 10.0
      3.times {
        cmds.each { |cmd|
          @host.send_serial(cmd, cam_serial)
          sleep 0.5
        }
      }
      next if @host.wait_for_beacons(ssid, 60) == false

      # Assume autoconnect case if we were given SSID and PC
      if ssid != nil and pc != nil
        log_info("Attempting autoconnect to camera")
        return true if @host.connect_camera(ssid, cam_ip, pc) == true
        # Otherwise just keep trying until the WPA supplicant makes the connection
        # to the already-known network
      else
        log_verb("wait_for_wifi_camera")
        ret = @host.wait_for_wifi_camera(cam_ip, timeout=60, interval=5)
        return true if ret == true
      end
      log_warn("Failed to connect to Wi-Fi.  Resetting camera again")
    }
    log_error("Failed to connect back to camera Wi-Fi.")
    return false
  end # reset_camera()
end # end class HostAgent

def acquire_lock()
  puts "Trying to acquire lock"
  lockdir = File.dirname($LOCKFILE)
  f = Dir.glob(File.join(lockdir, "*.pid"))
  if f.empty? == false
    puts "Unable to acquire lock!  Found lock file(s):"
    f.each { |file| puts file }
    puts "Check the current processes (ps -ef) for the above PIDs."
    puts "If you are sure these are zombies, run the following command:"
    puts "rm #{lockdir}/*"
    puts "Then retry running the HostAgent"
    return false
  end
  begin
    FileUtils.mkdir_p(lockdir)
    FileUtils.touch($LOCKFILE)
  rescue StandardError => e
    puts "Error acquiring lock: #{e.to_s}"
    puts e.backtrace.join("\n")
    return false
  end
  puts "Lock acquired successfully: #{$LOCKFILE}"
  return true
end

def release_lock()
  puts "Trying to release lock"
  begin
    FileUtils.rm($LOCKFILE)
    puts "Lock released successfully: #{$LOCKFILE}"
    return true
  rescue StandardError => e
    puts "Error releasing lock: #{e.to_s}"
    puts e.backtrace.join("\n")
    return false
  end
end

if __FILE__ == $0
  $LOCKFILE = "/tmp/sugarlock/#{Process.pid}.pid"
  $LOGLEVEL = $LL_INFO
  # defaults
  ENV["START_TIME"] = Time.now.strftime($FILE_TIME_STR)
  options = {}
  options[:serialdev] = nil
  options[:ip]        = nil
  options[:pc]        = nil
  options[:roster]    = nil
  options[:camconf]   = nil
  options[:runtype]   = "INDIVIDUAL" #set default runtype to individual
  options[:fw]        = nil
  options[:build]     = nil
  options[:log]       = ENV["HOME"]
  options[:email]     = false
  options[:testrail]  = false
  options[:runlabel]  = nil
  options[:shuffle]   = false
  options[:verb]      = false
  email_to_addr       = "fw-test-auto@gopro.com"

  # Parse the command line
  op = OptionParser.new do |opts|
    opts.banner = "Usage: ruby hostagent.rb -c [CAMERA_CONF] -r [TEST_ROSTER] -h"
    opts.on("-c", "--cameras FILE", "Camera configuration file (e.g. configs/cameras.conf)" + \
    "\n\t\t\t\t\t(supercedes ip/pc and serial options)") do |o|
      options[:camconf] = o
    end
    opts.on("-r", "--roster TEST_ROSTER", "Test roster to run (e.g. rosters/bat.txt)") do |o|
      options[:roster] = o
    end
    opts.on("--runtype RUN_TYPE", "BAT or INDIVIDUAL (default INDIVIDUAL)") do |o|
      options[:runtype] = o
    end
    opts.on("-i", "--ip IPADDR", "IP address of the camera") do |o|
      options[:ip] = o
    end
    opts.on("-p", "--pc PAIRINGCODE", "Pairing code of the camera") do |o|
      options[:pc] = o
    end
    opts.on("--ble", "BLE api ") do |o|
      # options[:ble] = true
      options[:ble] = true
      puts "hostagent.rb: FOUND BLE api option options[:ble]=#{options[:ble]}"
    end
    opts.on("-g", "--argus DEVICE", "Argus device of the camera (e.g. /dev/ttyACM0)") do |o|
      options[:argus] = o
    end
    opts.on("-g", "--gccb DEVICE", "GCCB device of the camera (e.g. /dev/ttyACM0)") do |o|
      options[:gccb] = o
    end
    opts.on("-s", "--serial DEVICE", "Serial device of the camera (e.g. /dev/ttyUSB0)") do |o|
      options[:serialdev] = o
    end
    opts.on("-f", "--fw URL|FILE", "File or URL of the ota update") do |o|
      options[:fw] = o
    end
    opts.on("-m", "--mail [ADDR]",
    "E-mail results to ADDR. (Default: fw-test-auto@gopro.com)") do |o|
      options[:email] = true
      # Override default address if specified
      email_to_addr = o if o != nil
    end
    opts.on("-t", "--testrail",
    "Report individual results into TestRail '(FWQA) Automation' project") do |o|
      options[:testrail] = true
    end
    opts.on("-u", "--runlabel LABEL",
    "Label to append to the test run name") do |o|
      options[:runlabel] = o
    end
    opts.on("-l", "--logdir DIR", "Base directory to put RUN logs (default $HOME)" + \
    "\n\t\t\t\t\tIf a RUN_X directory is specified, it will be reused.") do |o|
      options[:log] = o
    end
    opts.on("--shuffle", "Shuffle test files") do |o|
      options[:shuffle] = true
    end
    opts.on("-b", "--build BUILD_STR",
    "Set the build string for serial cameras (has no effect on Wi-Fi)") do |o|
      options[:testrail] = true
    end
    opts.on("-v", "--verb",
    "Set verbose logging") do |o|
      options[:verb] = true
    end
    opts.on("-h", "--help", "Display this message and exit") { puts op; exit }
  end
  op.parse!(ARGV)

  $LOGLEVEL = $LL_VERB if options[:verb] == true
  # For unit testing
  #  options[:fw] = "HD3.10.01.21.ota.zip"
  #  options[:roster] = "test_rosters/silver-plus-full.txt"
  #  options[:camconf] = "config/cameras.conf"

  #Overwrite camera.conf default if CAM_CONF env var is set
  env_cam_conf = ENV["CAM_CONF"]
  if options[:camconf] == nil and env_cam_conf != nil
    log_info("Using camera configuration file from ENV var. (#{env_cam_conf})")
    options[:camconf] = env_cam_conf
  end

  # Exit if missing required arguments
  if options[:camconf] == nil
    if options[:ip] == nil and options[:serialdev] == nil
      puts "Either IP, Serial device, or camera conf file must be specified!"
      doexit = true
    end
    if options[:ip] != nil and options[:pc] == nil
      puts "Either pairing code or camera conf file must be specified!"
      doexit = true
    end
    if ["BAT", "INDIVIDUAL"].include?(options[:runtype]) == false
      puts "Must include --runtype [BAT|INDIVIDUAL]"
      doexit = true
    end
  end
  (puts "Roster is required!"; doexit = true) if options[:roster] == nil
  (puts op; exit(1)) if doexit == true

  h = HostAgent.new(options[:log])
  h.fw_file       = options[:fw]
  h.cam_ips       = options[:ip]
  h.cam_gccbs     = options[:gccb]
  h.cam_ble       = options[:ble]
  h.cam_argus     = options[:argus]
  h.cam_serialdevs = options[:serialdev]
  h.pairing_code  = options[:pc]
  h.cam_conf      = options[:camconf]
  h.shuffle       = options[:shuffle]
  h.build         = options[:build]
  h.roster	      = options[:roster]
  h.runtype       = options[:runtype]

  begin
    if acquire_lock == true
      h.get_available_cams()
      h.process_roster(options[:roster])
      h.process_results(options, email_to_addr)
      release_lock
      exit(0)
    else
      puts "*"*80
      puts "Unable to acquire lock.  Exiting with value=1"
      puts "*"*80
      exit(1)
    end
  rescue Exception => e
    release_lock if File.exists?($LOCKFILE)
    exit(1)
  end
end
