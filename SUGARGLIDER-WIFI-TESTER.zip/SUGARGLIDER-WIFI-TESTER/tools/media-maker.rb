# media-maker.rb
# Description: Iterates over capture modes and creates media for the manual team.

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}")
    @host = Host.new
    @camera = tu_get_camera()
    @camera.squelch_status = true # Shh!
    set_options()
    @seed = srand >> 100 
    @seed = options[:seed] if options[:seed]
    if options[:format_afterward] and options[:skip_upload]
      log_warn("--format_afterward used with --skip_upload. How did you plan to get the media?")
      exit 1
    end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
    # Debugging tools...
    @camera.squelch_status = true # Shh!
    @print_settings_only = false # Handy.
    @first_media_only = true;
  end

  # base is the file basename (GOPRXXXX.MP4)
  # rest are self-explanatory
  # Example result: GOPR1468-4K-15-W-spot-OFF-pt-OFF.MP4
  def generate_video_fname(base, mode, vm, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex)
    to_file = File.basename(base, ".MP4")
    to_file += "_#{mode}"
    to_file += "_#{vm}_#{res}_#{fps}_#{fov}"
    to_file += "_ori-#{orient}" if orient != nil
    to_file += "_lli-#{ll}"     if ll     != nil
    to_file += "_spt-#{spot}"   if spot   != nil
    to_file += "_pro-#{pt}"     if pt     != nil
    to_file += "_wba-#{wb}"     if wb     != nil
    to_file += "_col-#{co}"     if co     != nil
    to_file += "_sha-#{sh}"     if sh     != nil
    to_file += "_iso-#{iso}"    if iso    != nil
    to_file += "_evc-#{ex}"     if ex     != nil
    to_file += ".MP4"
    return to_file
  end

  # base is the file basename (GOPRXXXX.JPG)
  
  def generate_photo_fname(base, mode, res, orient, spot, pt, wb, co, sh, iso, ex)
    to_file = File.basename(base, ".JPG")
    to_file += "_#{mode}"
    to_file += "_#{res}"
    to_file += "_ori-#{orient}" if orient != nil
    to_file += "_spt-#{spot}"   if spot   != nil
    to_file += "_ptu-#{pt}"     if pt     != nil
    to_file += "_wba-#{wb}"     if wb     != nil
    to_file += "_col-#{co}"     if co     != nil
    to_file += "_sha-#{sh}"     if sh     != nil
    to_file += "_iso-#{iso}"    if iso    != nil
    to_file += "_evc-#{ex}"     if ex     != nil
    to_file += ".JPG"
    return to_file
  end

  def runtest()
    log_info("Using seed: #{@seed}")
    capture_modes_hash = { # Hash for mode name loopup later.
      :make_video => "VIDEO",
#      :make_video_timelapse,
#      :make_video_piv,
#      :make_video_looping,
      :make_photo_single => "PHOTO",
#      :make_photo_continuous
#      :make_photo_night,
#      :make_photo_burst => "BURST",
#      :make_photo_time_lapse,
#      :make_photo_nightlapse
    }
    capture_modes = capture_modes_hash.keys
    capture_modes.shuffle!(random: Random.new(@seed)) if @options[:shuffle]
    srand @seed

    @camera.delete_all_media() unless @options[:skip_initial_format]
    capture_modes.each() {|mode|
      method(mode).call()
      @camera.delete_all_media() if @options[:format_afterward]
    }



  end
  
  def make_video()
    save_dir = File.join(@options[:save_dir], @camera.name + "-" + @camera.build) # + VIDEO/ ?
    all_settings = tu_get_video_res_with_protune().flatten(1)

    # Rejection area.
    #all_settings.reject! { |n| orient = n[4]; orient == "DOWN" }    
    #all_settings.reject! { |n| pt = n[7]; pt == "ON" }
    #all_settings.reject! { |n| res = n[1]; res != "1080" }

    if all_settings == []
      log_warn("No media to generate for VIDEO. Please check your settings.")
    else
      dur = @options[:duration]
      log_info("Capturing #{dur}s long videos for #{all_settings.length} combinations of settings.")
    end

    counter = 0
    all_settings.each { |settings|
      counter += 1
      next if counter > 1 and @first_media_only
      log_info("Capturing #{counter} of #{all_settings.length}.") unless @print_settings_only
      (puts "#{counter}: #{settings}"; next) if @print_settings_only
      #@camera.delete_all_media()
      # Break apart the settings.
      video_mode, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex = settings
      # Duration goes at index 4 to match @camera.capture_video() signature
      ret, msg = @camera.capture_video(video_mode, res, fps, fov, dur, orient, ll, spot, pt, wb, co, sh, iso, ex)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      media = @camera.get_medialist("MP4")
#      (fail("Cannot find media"); next) if (media == nil or media.empty?)
#      (fail("More than one MP4 file found!"); next) if media.length > 1

      # Save it
      ret, msg = @camera.download_media(media[media.length-1], save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      # And rename it to something useful (local file location held in 'msg')
      to_file = File.join(save_dir, generate_video_fname(media[media.length-1], "VIDEO", *settings))
      FileUtils::mv(msg, to_file)
      log_info("Saved to #{to_file}")
    }
  end # make_video

  def make_photo_single()
    save_dir = File.join(@options[:save_dir], @camera.name + "-" + @camera.build) # + PHOTO_SINGLE/ ?
    # Get all_the settings to use.
    all_settings = tu_get_photo_test_params()
    # Bail if none were found.
    if all_settings == []
      log_warn("No media to generate for PHOTO. Please check your settings.")
    end
    counter = 0
    all_settings.each { |settings|
      counter += 1
      next if counter > 1 and @first_media_only
      log_info("Generating single photo #{counter} of #{all_settings.length}") unless @print_settings_only
      # Extract the settings.
      (puts "#{counter}: #{settings}"; next) if @print_settings_only
      res, orient, spot, pt, wb, col, sh, iso, ex = settings

      ret, msg = @camera.capture_photo_single(*settings)
      (ret == false) ? (fail(msg); next) : log_info(msg)
      
      media = @camera.get_medialist("JPG")
#      (fail("Cannot find media"); next) if (media == nil or media.empty?)
#      (fail("More than one JPG file found!"); next) if media.length > 1

      # Save it
      ret, msg = @camera.download_media(media[media.length-1], save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      # And rename it to something useful (local file location held in 'msg')
      to_file = File.join(save_dir, generate_photo_fname(media[media.length-1], "PHOTO", *settings))
      FileUtils::mv(msg, to_file)
      log_info("Saved to #{to_file}")
    }
  end # make_photo_single

  def cleanup
    @host.kill_status_process() if @host
  end
end # Test

# Execution starts here
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only,
      :video_pt, :video_pt_wb, :video_pt_color, :video_pt_iso, :video_pt_sharp, :video_pt_ev,
      :duration, :video_low_light, :full,
      :photo_resolution, :photo_shutter_ev, :photo_pt, :photo_spot_metering,
      :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering,
      :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, #:quick,
      :skip_initial_format, :format_afterwards, :skip_upload, :upload_to]
    options = t.parse_options(ARGV, use_options)

    # Set some defaults
    options[:ip] = "10.5.5.9" if options[:ip] == nil
    options[:pc] = "goprohero" if options[:pc] == nil
    # res=ALL, fps=ALL, fov=ALL, pt=OFF/ON are already defaults.
#    options[:video_pt_color] = "ALL" if options[:video_pt_color] == nil
#    options[:photo_pt_color] = "ALL" if options[:photo_pt_color] == nil
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    options[:duration] = 120 if options[:duration] == nil # Video defaults to 2 minutes.

    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
