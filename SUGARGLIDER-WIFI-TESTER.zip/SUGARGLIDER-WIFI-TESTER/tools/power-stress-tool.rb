# power-stress-tool.rb
# A stand-alone version of the power stress test.
# Works for wifi cameras only.
# Assumes that the camera uses api version 2.


# Requires these three ruby gems:
require 'net/http/persistent'
require 'socket'
require 'open3'


class StandAloneHost
  def initialize
  end # initialize

 def wait_for_wifi_camera(ip, timeout=60, interval=5)
    start_time = Time.now()
    while Time.now - start_time < timeout do
      return true if pingable?(ip) # HD3/+ will respond to this
      return true if curlable?(ip) # HD4 will respond to this
      log_verb("Waiting for camera... %ds/%ss" \
      %[Time.now - start_time, timeout])
      sleep interval
    end
    return false
  end

  def pingable?(ip)
    cmd = "ping -c 3 -w 1 -i .3 #{ip}"
    o, e, s = sys_exec(cmd)
    # If even one packet makes it, we will return true.
    o.split("\n").each { |line|
      result = line.match("[0-9] received")
      if result != nil
        n_rec = result[0][0].to_i
        return true if n_rec > 0
      end
    }
    return false
  end

  def curlable?(ip, ct=1, rt=1, mt=2)
    url = "http://#{ip}"
    cmd = "curl -s --connect-time #{ct} --retry #{rt} --max-time #{mt} #{url}"
    o, e, s = sys_exec(cmd)
    return s.success?
  end

  def sys_exec(cmd, opts=nil)
    if opts == nil
      o, e, s = Open3.capture3(cmd)
    else
      o, e, s = Open3.capture3(cmd, opts)
    end
    return o, e, s
  end

  # Send the magic WOL packet in a UDP packet
  # Returns number of bytes sent should be >0 on success
  def wol(ip, mac)
    sock = UDPSocket.new
    sock.setsockopt(Socket::SOL_SOCKET, Socket::SO_BROADCAST, true)
    # Format is 0xFF 6 times followed by the MAC ADDR 16 times
    wol_pkt = "\xFF"*6 + ("\\x" + mac.split(":").join("\\x"))*16
    # Send to the class D IPv4 broadcast address (usually 10.5.5.255)
    dest_ip = ip.split(".")[0..2].join(".") + ".255"
    dest_port = 1234 # Don't think this ever changes
    return sock.send(wol_pkt, 0, dest_ip, dest_port)
  end

end # StandAloneHost

class StandAloneCamera
  def initialize(ip, pc)
    @ip = ip
    @pc = pc
    # We need the MAC address too. Pull it from bacpac info.
    @ssid, @mac, @wifi_version  = get_bacpac_info()
    # Don't call this. It's missing some functions if it fails.
    #info = get_cam_info_dnssd() unless @mac # We only need the MAC.
    #if info
    #  @serialno   = info[:sn]
    #  @fw_version = info[:fw]
    #  @mac        = info[:mac]
    #  @release    = info[:rel]
    #  @type       = info[:type]
    #  @build      = info[:build]
    #end
    unless @mac
      puts "ERROR : Could not get camera's MAC address, which we need for a WoL packet."
      exit 2
    end
  end # initialize

  def get_bacpac_info()
    ssid, mac, wifi_ver = nil, nil, nil
#    begin
    resp = decode_bacpac_cv(get_bacpac_resp(bacpac_cv[:get], nil, false), nil)
#    rescue WifiCameraError => e
#      puts "WARN : #{e.to_s}"
#    end
    if resp.is_a?(Hash) and resp.has_key?(:success) and resp[:success] == true
      ssid, mac, wifi_ver = resp[:ssid], resp[:mac], resp[:wifi_ver]
    else
      puts "WARN : Unable to retrieve bacpac information."
    end
    return ssid, mac, wifi_ver
  end

  def bacpac_cv
    {
      :get  => "cv",
      :ret  => method("decode_bacpac_cv")
    }
  end

  def get_bacpac_resp(cmd, param=nil, do_retry=true)
    return http_get(make_bacpac_url(cmd, param)) #, do_retry)
  end # get_backpac_resp

def http_get(url)
    puts "#{Time.now} \t #{url}"
    begin
      $http.request(URI(url))
    rescue Timeout::Error,
    Errno::ECONNRESET,
    Errno::EHOSTUNREACH,
    Errno::EHOSTDOWN,
    Errno::ECONNREFUSED,
    Errno::ENETUNREACH => e
      puts "HTTP ERROR => #{e.to_s}"
      puts e.backtrace.join("\n")
      puts "Exiting..."
      exit 1
    rescue StandardError => e
      puts "OTHER ERROR => #{e.to_s}"
      puts e.backtrace.join("\n")
      puts "Exiting..."
      exit 1
    end
  end

  def make_bacpac_url(cmd, param)
    return make_url(@ip, @port, 'bacpac', cmd, param)
  end # make_bacpac_url

  def make_url(ip, port, target, cmd, param=nil)
    param_str = @pairing_code == nil ? "" : "?t=#{@pairing_code}"
    param_str += param == nil ? "" : "&p=#{param}"
    return "http://#{ip}:#{port}/#{target}/#{cmd}#{param_str}"
  end

  def decode_bacpac_cv(resp, param, expected=nil)
#    wifi_pass   = resp.body[0].ord == wifi_success
    ver_maj     = resp.body[1].ord & 0xF0
    ver_min     = resp.body[1].ord & 0x0F
    mdl         = resp.body[2].ord
    id          = resp.body[3..4].unpack("H*")[0].to_i(16)
    boot_maj    = resp.body[5].ord
    boot_min    = resp.body[6].ord
    boot_bld    = resp.body[7].ord
    rev         = resp.body[8].ord
    major       = resp.body[9].ord
    minor       = resp.body[10].ord
    build       = resp.body[11].ord
    mac1        = resp.body[12].unpack("H*")[0]
    mac2        = resp.body[13].unpack("H*")[0]
    mac3        = resp.body[14].unpack("H*")[0]
    mac4        = resp.body[15].unpack("H*")[0]
    mac5        = resp.body[16].unpack("H*")[0]
    mac6        = resp.body[17].unpack("H*")[0]
    ssid        = resp.body[19..-1]
    # Some of the fields don't seem useful, so not including here
    retval = {
      :wifi_pass   => true, #wifi_pass, # We only want the MAC!
      :success     => true, #wifi_pass,
      :wifi_ver    => [major, minor, build, rev].join("."),
      :mac         => [mac1, mac2, mac3, mac4, mac5, mac6].join(":"),
      :ssid        => ssid,
    }
    return retval
  end

  def get_cam_info_dnssd()
    begin
      raise if (require 'dnssd') != true
    rescue LoadError, RuntimeError => e
      puts "WARN : 'dnssd' gem failed to load. Unable to perform mDNS discovery."
      return nil
    end

    wake_reply = web_reply = nil
    begin
      timeout(5) {
        DNSSD.browse('_gopro-wake._udp') { |r| wake_reply = r } # QCA chip
        DNSSD.browse('_gopro-web._tcp') { |r| web_reply = r } # A9
        while wake_reply == nil and web_reply == nil
          sleep 1
        end
      }
    rescue Timeout::Error
    end

    info = nil
    if wake_reply == nil
      puts "WARN : Did not see any gopro-wake service. Is camera connected?"
      if web_reply == nil
        puts "WARN : Did not see gopro-web service. Is camera awake?"
      else
        puts "WARN : Somehow see gopro-web service without wake service."
      end
    else
      # At least we got the wake reply, which is what we use to resolve
      info = dnssd_resolve(wake_reply)
    end
    return dnssd_parse_wake(info)
  end

  def send_camera_sleep_api2
    url = "#{make_gpcontrol_url}/command/system/sleep"
    http_get(url)
  end

  def make_gpcontrol_url
    "http://#{@ip}/gp/gpControl"
  end

  def api2_camera_power_on_ok?(tries=3)
    h = StandAloneHost.new()
    tries.times { |n|
      puts "INFO : Waking up camera @ %s (try %d of %d)." %[@ip, n+1, tries]
      h.wol(@ip, @mac)
      return true if h.wait_for_wifi_camera(@ip, timeout=15, interval=1.0) == true
    }
    puts "WARN : Unable to connect to camera after #{tries} tries."
    return false
  end

end # StandAloneCamera

class PowerCycleTest
  def initialize
  end

  def setup(ni, ip, pc)
    @host = StandAloneHost.new()
    @camera = StandAloneCamera.new(ip, pc)
    @iter = ni
  end

  def toggle_power_off_on_via_wifi(timeout=30)
    @camera.send_camera_sleep_api2
    sleep(10)
    return @camera.api2_camera_power_on_ok?
  end

  def runtest
    iter = @iter #@options[:n_iter]
    puts "INFO : Running power OFF/ON test for #{iter} iterations"
    iter = iter.to_i # D'oh!
    (1..iter).each do |n|
      puts "INFO : Iteration #{n} of #{iter}. Powering off and on."
      result = toggle_power_off_on_via_wifi()
      if result == false
        puts "FAIl : Camera did not toggle power successfully at iteration #{iter}."
        exit 4 #ExitCode.camera_off
      else 
        puts "PASS: Camera toggled power at iteration #{n}."
      end
      sleep(5.0) # Camera not quite ready even though says OK...
    end # Each n
    log_pass("All #{iter} power off-on iterations passed")
  end
end # end Test class

def usage()
  puts "USAGE: ruby power-stress.rb [ni [ip [pc]]]"
  puts "  [ni] - The number of iterations to do. (Default: 1000)"
  puts "  [ip] - The IP address of your wifi camera. (Default: 10.5.5.9)"
  puts "  [pc] - The pairing code for your camera. (Default: goprohero)"
end # usage

# Execution starts here
if __FILE__ == $0
  (usage(); exit 1) if ARGV.length > 3 or (ARGV.length == 1 and ["-?","-h"].include?(ARGV[0]))
  ARGV << 1000        unless ARGV.length >= 1
  ARGV << "10.5.5.9"  unless ARGV.length >= 2
  ARGV << "goprohero" unless ARGV.length >= 3
  $http = Net::HTTP::Persistent.new(ARGV[1])
  pst = PowerCycleTest.new
  pst.setup(ARGV[0], ARGV[1], ARGV[2])
  pst.runtest
  return 0
end
