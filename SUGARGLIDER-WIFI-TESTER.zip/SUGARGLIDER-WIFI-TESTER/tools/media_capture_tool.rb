# media_capture_tool.rb
# Description: Iterates over capture modes and downloads media locally
#   By default for video it will iterate over:
#     - RES (ALL)
#     - FPS (ALL)
#     - FOV (ALL)
#     - ProTune (OFF/AUTO)
#        - ProTune COLOR (FLAT/GoPro)
#   By default for images it will iterate over:
#     - RES (ALL)
#     - ProTune (OFF/AUTO)
#        - ProTune COLOR (FLAT/GoPro)
#
#   Files will be downloaded to /tmp/[FW-VERSION]/GOPRXXXX-[RES]-[FPS]-[FOV]-[PT]-... ProTune vars...MP4|JPG
#require 'rubygems'
#require 'bundler/setup'
require 'fileutils'
require 'yaml'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/utils'
require_relative '../libs/camera_mode_banner'
#require_relative '../libs/emailResults'
class ImageList
  include Utils

  #load json
  #validate array with valid paths
  def loadjson(path)
    @path = path
    @orphan = '__'
    @jsonend=',}]'
    @ok = false
    @imagelist = nil
    @modemap = Hash.new()
    @cameraindex = -1
    puts '---- Load ImageList JSON ---'
    rc = Utils.loadJSON(@path)
    if rc[0]
      @imagelist = rc[1] if rc[1]
      if validatelist
        @ok=true
        puts 'Found ImageList JSON'
      else
        puts 'NOT FOUND ImageList JSON'
        @imagelist = Array.new()
        puts rc.to_s
      end
    else
      puts 'NOT FOUND ImageList JSON'
      @imagelist = Array.new()
      puts rc.to_s
    end
    @fileitem = [] #:gopro, :camera, :path, :ok]
  end

  #iterate filelog
  #check file path
  #orphan files get renamed
  def validatelist
    return false if @imagelist == nil || @imagelist.length==0
    @imagelist.each_index { |id|
      repopath = @imagelist[id]['path']
      mp4 = @imagelist[id]['mp4']
      mode =  @imagelist[id]['camera']
      gppath = repopath + '/' + mp4

      if File.exists?(gppath)
        #@imagelist[id]['validate']=true
        puts 'FOUND: '+mode+ ' - '+gppath
        #idx = getindexfromname("GOPR",mp4)

      else
        #  filename = File.basename(f, File.extname(f))
        # File.rename(f, folder_path + filename.capitalize + File.extname(f))
        #item = @imagelist.delete_at(id)
        puts '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
        puts 'NOT FOUND: '+gppath
      end
    }
    @imagelist.each_index { |id|
      @modemap[@imagelist[id]['camera']]=id  #last dupe overides previous
    }

  end

  def imagecount()
    return @imagelist.length
  end

  def getindexfromname(fname)
    idx = -1
    #prefix = 'GOPR' if prefix=nil
    ffile = File.basename(fname, '.*')
    nfile = ffile[ffile.length-4..-1]
    #nfile = ffile.gsub(prefix,"")
    idx = nfile.to_i()
    if @cameraindex < idx
      @cameraindex = idx
    end
    puts fname+idx.to_s
    return idx
  end

  def adaptGoProIndex(sdfile, targetdir)
    rc = false
    newindex = nil

    if File.exist?(targetdir + '/' + sdfile)
      sdidx = getindexfromname(sdfile)
      file = File.basename(sdfile, ".*")
      ext = File.extname(sdfile)
    end

    return rc , newindexfile
  end

  def savejson()
    puts "savejson: path=#{@path}"
    if @imagelist !=nil and @imagelist.length > 0
      puts "savejson: image count=#{@imagelist.length}"
      rc = Utils.saveJSON(@path, @imagelist)
    end
  end
  def isimage(camera)
    if @modemap.has_key?(camera)
      return true
    else
      return false
    end
  end

  def getimageitem(camera)
    if isimage(camera)
      return @imagelist[@modemap[camera]]
    else
      return nil
    end
  end
  # def getmetajson()
  #   j={}
  #   j['aspect_ratio']='null'
  #   j['audio_bitrate']='null'
  #   j['audio_channels']='null'
  #   j['audio_codec']='null'
  #   j['audio_sample_rate']='null'
  #   j['colorspace']='null'
  #   j['creation_time']='null'
  #   j['frame_rate']='null'
  #   j['has_timecode']='null'
  #   j['height']='null'
  #   j['profile_level']='null'
  #   j['timecode']='null'
  #   j['valid']='null'
  #   j['video_bitrate']='null'
  #   j['video_codec']='null'
  #   j['width']='null'
  #   return j
  # end

  def evalmeta(metavalue)
    if not metavalue
      return 'null'
    else
      return metavalue
      # if metavalue.is_a?(String)
      #   return metavalue
      # else
      #   return metavalue
      # end
    end
  end

  def meta_json(meta)
    j={}
    return j if not meta
    j['aspect_ratio'] = evalmeta(meta.aspect_ratio)
    j['audio_bitrate'] = evalmeta(meta.audio_bitrate)
    j['audio_channels'] = evalmeta(meta.audio_channels)
    j['audio_codec'] = evalmeta(meta.audio_codec)
    j['audio_sample_rate'] = evalmeta(meta.audio_sample_rate)
    j['colorspace'] = evalmeta(meta.colorspace)
    j['creation_time'] = evalmeta(meta.creation_time)
    j['frame_rate'] = evalmeta(meta.frame_rate)
    j['has_timecode'] = evalmeta(meta.has_timecode)
    j['height'] = evalmeta(meta.height)
    j['profile_level'] = evalmeta(meta.profile_level)
    j['timecode'] = evalmeta(meta.timecode)
    j['valid'] = evalmeta(meta.valid)
    j['video_bitrate'] = evalmeta(meta.video_bitrate)
    j['video_codec'] = evalmeta(meta.video_codec)
    j['width'] = evalmeta(meta.width)


    return j
  end

  def addimage(mp4,mp4_meta, lrv,lrv_meta, thm, camera, path, json_mode, tags)
    puts('>>>>>>>>')
    puts("addimage:mp4#{mp4},mp4_meta#{mp4_meta}, lrv#{lrv},lrv_meta#{lrv_meta}, thm#{thm}, camera#{camera}, path#{path}, json_mode#{json_mode}, tags#{tags}")
    puts('<<<<<<<<<')
    savef = {}
    savef['mp4'] = mp4
    savef['mp4_meta'] = meta_json(mp4_meta)
    savef['camera'] = camera
    savef['path'] = path
    savef['mode'] = json_mode
    savef['lrv'] = lrv
    savef['lrv_meta'] = meta_json(lrv_meta)
    savef['thm'] = thm
    savef['tags'] = tags
    # savef['mediameta_base64'] = ''
    # if meta != nil and meta.length > 0
    #   # meta2=meta.gsub('\n', '')
    #   # meta3=meta2.gsub('\\n', '')
    #   savef['mediameta_base64'] = Utils.converttobase64(meta)
    # end
    savef['validate'] = true
    if @imagelist.length > 0  #Array(@imagelist).count
      @imagelist.push(savef)
    else
      @imagelist[0]=savef
    end
    puts "addimage: count=#{@imagelist.length}"
    @modemap[savef['camera']] = @imagelist.length - 1
    return savef
  end
end


class Test < TestCase
  include TestUtils
  include Utils
  #include Host
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}")
    @host = Host.new
    @camera = tu_get_camera()
    set_options()
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
    @imagelist = ImageList.new
  end

  # base is the file basename (GOPRXXXX.MP4)
  # rest are self-explanatory
  # Example result: GOPR1468-4K-15-W-spot-OFF-pt-OFF.MP4
  def generate_video_fname(base, vm, res, fps, fov,orient, ll, spot, pt, wb, co, sh, iso, ex)
    to_file = File.basename(base, ".MP4")
    to_json = Hash.new
    to_json['file']=base
    to_json['sec']=10
    to_file += "_vm#{vm}_res#{res}_fps#{fps}_fov#{fov}"
    to_json['vm']=vm
    to_json['res']=res
    to_json['fps']=fps
    to_json['fov']=fov
    to_json['orient']=orient
    to_file += "_ll-#{ll}"      if ll != nil
    to_json['ll']=ll
    to_file += "_spot-#{spot}"  if spot != nil
    to_json['spot']=spot
    to_file += "_pt-#{pt}"      if pt != nil
    to_json['pt']=pt
    to_file += "_wb-#{wb}"      if wb != nil
    to_json['wb']=wb
    to_file += "_co-#{co}"      if co != nil
    to_json['co']=co
    to_file += "_sh-#{sh}"      if sh != nil
    to_json['sh']=sh
    to_file += "_iso-#{iso}"    if iso != nil
    to_json['iso']=iso
    to_file += "_ex-#{ex}"      if ex != nil
    to_json['ex']=ex
    to_file += ".MP4"

    return to_file, to_json
  end

  # base is the file basename (GOPRXXXX.JPG)
  # rest are self-explanatory
  # Example result: GOPR1468-4K-15-W-spot-OFF-pt-OFF.MP4
  def generate_photo_fname(base, res, spot, pt, wb, co, sh, iso, ex)
    to_file = File.basename(base, ".JPG")
    to_file += "_res#{res}"
    to_file += "_spot-#{spot}"  if spot != nil
    to_file += "_pt-#{pt}"      if pt != nil
    to_file += "_wb-#{wb}"      if wb != nil
    to_file += "_co-#{co}"      if co != nil
    to_file += "_sh-#{sh}"      if sh != nil
    to_file += "_iso-#{iso}"    if iso != nil
    to_file += "_ex-#{ex}"      if ex != nil
    to_file += ".JPG"
    return to_file
  end

  def downloadFiles()
    mp4 = @camera.get_medialist("MP4")
    lrv = @camera.get_medialist("LRV")
    thm = @camera.get_medialist("THM")

  end

  def runtest()
    save_dir = File.join(@options[:save_dir]+'/', @camera.name + "-" + @camera.build)
    save_descript = File.join(@options[:image_repo2]+'/', @camera.name + "-" + @camera.build)
    ##https://www.vmware.com/support/ws3/doc/ws32_running9.html
    if not Dir.exists?(@options[:save_dir])
      log_warn("ERROR Check save_dir")
      log_warn(@options[:save_dir])
      return
    else
      log_info("File Repo=#{save_dir}")
    end
    
    cam_build = "#{@camera.name}-#{@camera.build}"
    media_json = "#{cam_build}.json"
    media_json_path = File.join(save_dir,media_json )

    @imagelist.loadjson(media_json_path)

    #################################################
    ### MP4 files
    # Enumerate all the test combinations
    test_params = tu_get_video_res_with_protune().flatten(1)
    if test_params == []
      log_warn("No tests to run!  Check resolution chosen")
    end

    #bip = @options[:config_info]['http_banner']
    #httpbanner = Camera_mode_banner.new("192.168.52.111","8081")
    banner_ip = @options[:config_info]['http_banner']['ip']
    banner_port = @options[:config_info]['http_banner']['port']
    banner_info = @options[:config_info]['http_banner']['info']

    httpbanner = Camera_mode_banner.new(banner_ip,banner_port,banner_info)
    counter = 0
    testmax =  test_params.length
    test_params.each { |capture_args|
      counter += 1
      @options[:durationlist].each { |dur|
        
        video_mode, res, fps, fov, orient,ll, spot, pt, wb, co, sh, iso, ex = capture_args
        log_info("#{dur.to_s}|#{video_mode}|#{res}|#{fps}|#{fov}|#{pt}================================================")
        log_info("#{counter.to_s} of #{testmax.to_s} ====================================================")
        vretry = 3
        
        cam_mode, json_mode= generate_video_fname("", *capture_args)
        cam_mode=dur.to_s+"sec"+cam_mode
        json_mode['sec']=dur
        if @imagelist.isimage(cam_mode)
          log_warn( "DONE:" + cam_mode)
          next
        end
        #def capture_video(vm, res, fps, fov, duration, orient=nil, ll=nil, spot=nil, p=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
        #video_mode, res, fps, fov, orient,ll, spot, pt, wb, co, sh, iso, ex = capture_args
        if @options[:single_fov]!=fov
          log_warn( "SKIP NOT FOV:[" + @options[:single_fov] + " <> "+fov +"]"+ cam_mode)
          next
        end

        log_info( cam_mode)
        begin
          # if cam_mode exists in @imagelist then skip
          log_info("Capturing #{counter} of #{test_params.length}.")
          @camera.delete_all_media()
          #cammode=capture_args.to_s
          banner_result = httpbanner.setbanner(cam_mode,"RECORD #{cam_build}-#{DateTime.now}" )
          if banner_result == nil
            log_warn("ERROR httpbanner.setbanner")
            log_warn(banner_result.to_s)
            break
          end
          log_info("Capturing #{dur}s long videos in #{test_params.length} capture modes")
          # Duration goes at index 4 to match @camera.capture_video() signature
          ret, msg = @camera.capture_videoKF(video_mode, res, fps, fov, dur, orient, ll, spot, pt, wb, co, sh, iso, ex)
          (ret == false) ? (fail(msg); next) : log_info(msg)

          media = @camera.get_medialist("MP4")
          (fail("Cannot find media"); next) if (media == nil or media.empty?)
          #(fail("More than one MP4 file found!"); next) if media.length > 1

          # Download mp4 lrv thm & Save it
          local_path = File.join(save_dir, media[0])
          mp4_name=File.basename(local_path)
          mp4_dir=File.dirname(local_path)
          log_info( "Camera:#{cam_mode}")
          log_info( "Download:#{local_path}")
          banner_result = httpbanner.setlabel("DOWNLOAD #{mp4_name}-#{DateTime.now}" )
          new_media_file = mp4_name
          if File.exist?(mp4_dir+'/'+mp4_name)
            new_media_file = Utils.getunusedmediaindex(mp4_dir,mp4_name,1,9999)
            if new_media_file
              local_path=File.join(mp4_dir, new_media_file)
              banner_result = httpbanner.setlabel("DOWNLOAD #{mp4_name}>>#{new_media_file}-#{DateTime.now}" )
            else
              log_warn('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
              log_warn('SKIPPED FILE ALREADY EXISTS IN TARGET DIR:\n'+mp4_dir+'/'+mp4_name)
              log_warn('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
              next
            end

          end
          file = File.basename(new_media_file, ".*")

          ret, msg = @camera.download_mediaKF(mp4_name,mp4_dir,new_media_file)
          (ret == false) ? (fail(msg); next) : log_info(msg)

          if Utils.waitdownload(local_path)
            lrv_path=nil
            thm_path=nil
            new_lrv_file=''
            if @camera.has_lrv?(res,fps,fov,pt)
              lrvdir = File.dirname(media[0])
              lrv_name = File.basename(media[0], '.MP4')+'.LRV'
              lrv_dir = File.join(save_dir,lrvdir)
              lrv_path = File.join(lrv_dir,lrv_name)
              new_lrv_file= file+'.LRV'
              banner_result = httpbanner.setlabel("DOWNLOAD #{lrv_name}-#{DateTime.now}" )
              begin
                ret, msg = @camera.download_mediaKF(lrv_name,lrv_dir,new_lrv_file)
                lrv_path = nil if ret == false
              rescue StandardError => e
                log_info("LRV not Found #{lrv_path}")
                lrv_path = nil
              end
            end
            new_thm_file=''
            if @camera.has_thm?(res, fps, pt)
              thmdir = File.dirname(media[0])
              thm_name = File.basename(media[0],'.MP4')+'.THM'
              thm_dir = File.join(save_dir, thmdir)
              thm_path = File.join(thm_dir,thm_name)
              new_thm_file= file+'.THM'
              banner_result = httpbanner.setlabel("DOWNLOAD #{thm_name}-#{DateTime.now}" )
              begin
                ret, msg = @camera.download_mediaKF(thm_name,thm_dir,new_thm_file)
                thm_path = nil if ret == false
              rescue StandardError => e
                log_info("THM not Found #{thm_path}")
                thm_path = nil
              end
            end

            #log json
            #log_info( "MediaInfo:#{local_path}")

            #meta=Utils.savemediainfo(local_path)
            #puts "Mediainfo META:#{meta.length}" if meta != nil
            #log_info( "UpdateJSON:#{local_path}")
            banner_result = httpbanner.setlabel("VALIDATE #{DateTime.now}" )
            failed_Validate = tu_wifi_analyze_video_metadata(local_path, pt, res, fps, fov)
            puts failed_Validate.to_s
            vcount=0
            # failed_Validate.each { |v|  #items all should be nil
            #   if v
            #     log_warn("FAILED META VALIDATE: #{v}")
            #     vcount +=1
            #   end
            # }
            if vcount > 0
              log_warn("FAILED META VALIDATE: Skipping")
              vretry -= 1
              if vretry < 1
                next
              else
                redo
              end
            end
            log_info("READING: Tag Info")
            taglist = tu_read_hilight_tags(File.dirname(local_path)+'/'+new_media_file)
            if taglist==nil
              log_info("FAILED: Tag Read Error 3 tags")
            else
              if taglist.length>0
                taglist.each {|tagitem|
                  log_info("TAG: #{tagitem.to_s}")
                }
              end
            end
            @imagelist.addimage(new_media_file,@meta_mp4,new_lrv_file,@meta_lrv,new_thm_file, cam_mode,File.dirname(local_path),json_mode, taglist)

#            @imagelist.addimage(File.basename('/'+media[0]),@meta_mp4,lrv_path,@meta_lrv,thm_path, cam_mode,File.dirname(local_path),json_mode)
            log_info("Saved to #{local_path}")
            @imagelist.savejson()
          else
            log_warn("FAILED to save camera media: #{local_path}")
            log_warn("FAILED to save camera media: SKIPPED")
          end

        rescue StandardError => e
          log_warn( e.to_s+'\n'+e.backtrace.join("\n"))

          vretry -= 1
          if vretry < 1
            next
          else
            redo
          end
        end
      }
    }

#    puts '#################################################'
#    puts '### JPG files'
#    test_params = tu_get_photo_test_params()
#    if test_params == []
#      log_warn("No tests to run!  Check resolution chosen")
#    else
#      log_info("Running #{test_params.length} tests")
#    end
#
#    counter = 0
#    test_params.each { |photo_opts|
#      counter += 1
#      log_info("Test #{counter} of #{test_params.length}")
#      @camera.delete_all_media()
#      res, spot, pt, wb, col, sh, iso, ex = photo_opts
#
#      ret, msg = @camera.capture_photo_single(*photo_opts)
#      (ret == false) ? (fail(msg); next) : log_info(msg)
#
#      media = @camera.get_medialist("JPG")
#      (fail("Cannot find media"); next) if (media == nil or media.empty?)
#      (fail("More than one JPG file found!"); next) if media.length > 1
#
#      # Save it
#      ret, msg = @camera.download_media(media[0], save_dir)
#      (ret == false) ? (fail(msg); next) : log_info(msg)
#
#      # And rename it to something useful (local file location held in 'msg')
#      # to_file = File.join(save_dir, generate_photo_fname(media[0], *photo_opts))
#      # FileUtils::mv(msg, to_file)
#      # log_info("Saved to #{to_file}")
#    }
  end # runtest

  def cleanup
    @host.kill_status_process() if @host
  end
end # Test

#############################################
# Execution starts here
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  debugMsg = ''
  begin
    if Dir.exists?('/run/user/1000/gvfs/smb-share:server=pc-sqasd,share=automation2/ImageRepo')
      puts 'TRUE Image repo dir exists'
    else
      puts 'FALSE Image repo dir exists'
    end
    t = Test.new
    use_options = [:ssid, :ip, :pc, :serialdev,
                   :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only,
                   :video_pt, :video_pt_wb, :video_pt_color, :video_pt_iso, :video_pt_sharp, :video_pt_ev,
                   :duration, :duration1, :duration2, :duration3, :video_low_light, :full,
                   :photo_resolution, :photo_shutter_ev, :photo_pt, :photo_spot_metering,
                   :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
                   :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering,
                   :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, :quick,
                   :projroot, :config_info, :single_fov
    ]
    options = t.parse_options(ARGV, use_options)
    # if not Utils.setgoprowifi()
    #
    # end
    # if not Utils.setwifi('en0','autobackdoor4851','password1')
    #
    # end
    options[:platform] = Utils.os()
    options[:projroot] = Utils.getprojroot()
    options[:config_info] = YAML.load_file("#{options[:projroot]}/config/media_capture.conf")
    if options[:config_info].has_key?("Email_Sender")
      em = options[:config_info]['Email_Sender']
      Utils.Email_Sender = em['email']
      Utils.Email_pw = em['pw']
      if options[:config_info].has_key?("Email_Debug")
        Utils.EmailDebug(options[:config_info]['Email_Debug'],"IMAGE CAPTURE AUTOMATION IS STARTED", "IMAGE CAPTURE AUTOMATION IS STARTED")
      end
    end

    #iterate cameras

    #ar.each_index do |cameraid|
    for camid in 0..(options[:config_info]['CameraList'].length-1)
      camera = options[:config_info]['CameraList'][camid]
      debugMsg=t.log_info(camera.to_s())
      wifiok=true
      #Utils.setwifi('en0',camera['ssid'],'pro2450go!')
      #sleep 2
      debugMsg='Utils.setwifi'
#       if not Utils.setwifi('en0',camera['ssid'],camera['pw'])
#       wifiok=false
#       debugMsg=t.log_info('skip failed ssid connect')
#       sleep 2
#       next  #skip failed ssid connect
#       end
#       if not wifiok
#       debugMsg=t.log_warn('No cameras to connect to')
#       t.log_info('Done')
#       return
#       end
      # Set some defaults
      options[:ip] = camera['ip'] #"10.5.5.9"
      options[:pc] = camera['pw'] #"goprohero"
      options[:ssid] = camera['ssid'] #"goprohero"

      # res=ALL, fps=ALL, fov=ALL, pt=OFF/ON are already defaults.  Just add pt_color=ALL
      options[:video_pt_color] = "ALL" if options[:video_pt_color] == nil
      options[:photo_pt_color] = "ALL" if options[:photo_pt_color] == nil
      options[:image_repo] = options[:config_info]['ImageRepo']
      options[:image_repo2] = options[:config_info]['ImageRepo2']
      options[:save_dir] = "#{options[:image_repo]}"
      options[:duration] = 10 if options[:duration] == nil
      options[:durationlist] = [128] #[2,16,32,64,128]

      options[:single_fov] = "W"
      $LOGLEVEL = $LL_VERB if options[:verb] == true
      t.setup(options)
      t.runtest()
      
      t.log_info('Done')
    end

  rescue StandardError => e
    t.log_error(e.to_s)
    Utils.EmailDebug(options[:config_info]['Email_Debug'],"Automation Error", debugMsg+'\n'+e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
    
    Utils.EmailDebug(options[:config_info]['Email_Debug'],"IMAGE CAPTURE AUTOMATION IS STOPPED", "IMAGE CAPTURE AUTOMATION IS STOPPED")
  end
end

