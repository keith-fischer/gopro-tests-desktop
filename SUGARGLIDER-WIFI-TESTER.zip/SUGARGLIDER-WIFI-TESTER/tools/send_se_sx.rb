require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/wifi_commands'

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
#  begin

  t = TestCase.new
  use_options = [:ip, :pc, :serialdev, :shuffle,]
  $options = t.parse_options(ARGV, use_options)

  @test_file = __FILE__
  set_tc_name("se_sx_tool")
  if $options[:serialdev] != nil
    $camera = get_serial_camera($options[:serialdev])
  elsif $options[:ip] != nil and $options[:pc] != nil
    $camera = get_wifi_camera($options[:ip], $options[:pc])
  else
    log_error("Must specify either serial or ip/pc")
    exit 1
  end

  while true do 
    $camera.ok?
    sleep 0.1
    $camera.bacpac_ok?
    sleep 0.5
  end
  
#  rescue StandardError => e
#    require_relative '../libs/log_utils'; include LogUtils
#    log_error(e.to_s + "\n" + e.backtrace.join("\n"))
#  end
end
