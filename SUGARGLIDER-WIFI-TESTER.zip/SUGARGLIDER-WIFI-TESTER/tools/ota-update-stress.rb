# ota-update-stress.rb
# OTA update script for HD4 cameras. Performs a many OTA update in a row.
# Requires: 
#   - Ruby 1.9.3+
#   - Multipart post gem (gem install multipart-post)
#   - HTTP persistent gem (gem install net-http-persistent)
#   - OTA update firmware file
#   - Open3 (ruby probably comes with it, but it's worth a mention anyway)
#
# Note:  The OTA update firmware file is a ZIP file with all
# necessary files at the TOP level (e.g. not in any directories)
#########################################
# Do not just zip up the UPDATE folder! #
########################################
# In Linux, this can be created with the following command:
# "zip OTAUPDATE.zip camera_firmware.bin camera_loaders.bin hd4_update.txt"
#
# Instructions:
#   - Put camera into GOPRO APP mode (may require to pair with smart device first)
#   - Connect to camera AP
#   - Run script: ruby ota-update-stress.rb 10.5.5.9 /path/to/update.zip 100

require 'digest'
require 'open3'
require 'net/http/persistent'
require 'net/http/post/multipart'
require 'open-uri'
require 'uri'
require 'fileutils'

def calculate_sha1_digest_of(filename)
  buffer = ''
  sha1 = Digest::SHA1.new
  File.open(filename) do |f|
    while not f.eof do
      f.read(4096, buffer)
      sha1.update(buffer)
    end
  end
  return sha1.to_s
end

def http_get(url)
  puts "#{Time.now} \t #{url}"
  begin
    $http.request(URI(url))
  rescue Timeout::Error,
  Errno::ECONNRESET,
  Errno::EHOSTUNREACH,
  Errno::EHOSTDOWN,
  Errno::ECONNREFUSED,
  Errno::ENETUNREACH => e
    puts "HTTP ERROR => #{e.to_s}"
    puts e.backtrace.join("\n")
    puts "Exiting..."
    exit 1
  rescue StandardError => e
    puts "OTHER ERROR => #{e.to_s}"
    puts e.backtrace.join("\n")
    puts "Exiting..."
    exit 1
  end
end

# depends on https://github.com/nicksieger/multipart-post
# gem install multipart-post
def upload_firmware(fw_fname)
  fw_sha = calculate_sha1_digest_of(fw_fname)
  uri = URI.parse("http://#{$CAM_IP}:8080/gp/gpUpdate")
  puts "Uploading #{fw_fname} (sha1=#{fw_sha}) to #{uri}"

  # Craft the request
  post = Net::HTTP::Post::Multipart.new uri.path,
    "DirectToSD" => '1',
    "sha1" => fw_sha,
    "update" => "submit",
    "file" => UploadIO.new(File.new(fw_fname), "application/zip", "firmware.gpu")
  begin
    response = Net::HTTP.start(uri.host, uri.port, :read_timeout => 300) { |http|
      http.request(post)
    }
  rescue StandardError => e
    puts e.to_s
    puts e.backtrace.join("\n")
    puts "ERROR: HTTP POST failed."
    return nil
  end
  return response
end

def do_wifi_fw_update()
  $NUM_ITR.times do |n| 
    puts "Entering OTA Update Mode..."
    puts "Doing update number #{n+1} of #{$NUM_ITR}"
    http_get("http://#{$CAM_IP}/gp/gpControl/command/fwupdate/download/start")
    ret = upload_firmware($FW_FILE)
    if ret == nil
      puts "ERROR: Uploading OTA file failed"
      exit 1
    end
    sleep 5.0
#    puts "HTTP status code=#{ret.code}, body=#{ret.body}"
    puts "Starting OTA Update..." # (if download was successful)..."
    puts "Waiting for a minute before we start to poll for camera."
    sleep 60.0
    # Wait for camera to come back.
    result = wait_for_wifi_camera()
    if result
      puts "\033[92mPASS : Update #{n+1} of #{$NUM_ITR} completed.\033[0m"
      sleep 5.0
    else
      puts "\033[91mFAIL : Timed out waiting for camera. Stopping.\033[0m"
      exit 3
    end
  end # Do so many times.
  return true
end

def wait_for_wifi_camera()
   timeout = 300
   interval = 5
   puts "Polling for camera..."
   start_time = Time.now()
    while Time.now - start_time < timeout do
      return true if pingable?($CAM_IP) # HD3/+ will respond to this
      return true if curlable?($CAM_IP) # HD4 will respond to this
#      puts "Waiting for camera... %ds/%ss" \
#      %[Time.now - start_time, timeout])
      sleep interval
    end
    return false
end # wait_for_wifi_camera

def pingable?(ip)
  cmd = "ping -c 3 -w 1 -i .3 #{ip}"
  o, e, s = sys_exec(cmd)
  #return true if s.success?
  # If even one packet makes it, we will return true
  o.split("\n").each { |line|
    result = line.match("[0-9] received")
    if result != nil
      n_rec = result[0][0].to_i
      return true if n_rec > 0
    end
  }
  return false
end

def curlable?(ip, ct=1, rt=1, mt=2)
  url = "http://#{ip}"
  cmd = "curl -s --connect-time #{ct} --retry #{rt} --max-time #{mt} #{url}"
  o, e, s = sys_exec(cmd)
  return s.success?
end

  def sys_exec(cmd, opts=nil)
#    puts "Running system command: #{cmd} #{opts}"
    if opts == nil
      o, e, s = Open3.capture3(cmd)
    else
      o, e, s = Open3.capture3(cmd, opts)
    end
#    log_verb("Output = #{o}")
#    log_verb("Error = #{e}")
#    log_verb("Status = #{s}")
#    log_verb("Command (#{cmd}) returned unsucessful") if not s.success?
    return o, e, s
  end


def usage
  puts "Usage: ota-update-stress.rb <CAM_IP> <FW_FILE> <NUM_ITR>"
  puts "   CAM_IP - The IP address of your wifi camera."
  puts "  FW_FILE - The firmware file to use, which is a zip of the update files."
  puts "            This is NOT the UPDATE folder zipped up! Zip the FILES."
  puts "  NUM_ITR - The number of times to do this update."
  exit 1
end # usage

# script starts here
$CAM_IP  = ARGV[0]
$FW_FILE = ARGV[1]
$NUM_ITR = ARGV[2].to_i
if $CAM_IP == nil
  puts "Camera IP is required."
  usage
elsif $FW_FILE == nil or !File.exists?($FW_FILE)
  puts "Cannot find firmware file."
  usage
elsif $NUM_ITR == nil or $NUM_ITR.to_i <= 0
  puts "Number of iterations is missing or invalid."
  usage
end
$http = Net::HTTP::Persistent.new($CAM_IP)
ret = do_wifi_fw_update()

