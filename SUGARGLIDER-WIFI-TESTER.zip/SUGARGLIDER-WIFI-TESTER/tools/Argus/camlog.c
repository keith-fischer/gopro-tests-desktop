/* camlog.c - Reads serial in and sends to a dated directory and argus log file
 *
 * camlog -h
 * 
 *   usage:
 *     -h               : print usage
 *     -port    <dev>   : set serial port (default is /dev/ttyUSB2)
 *     -cam     <num>   : associate a camera# with the output log file
 *
 *
 */
int cam_num=0;         // camera number
int nobin_flag=0;      // dont create a binary log file of all input received
char serial_port[80];  // serial port name
char onoff[5];         // on/off option
char binfile[80];      // binary file name
char readbin_file[80]; // binary file to READ (instead of the serial port)
int readbin_flag=0;    // flag to read the binary file  instead of the serial port (see -readbin option)

#include <stdlib.h> // exit(), system()
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> // sleep(), fsync()
#include <stdint.h> // uint32_t
#include <strings.h> // bzero()
#include <string.h>  // strcpy
#include <linux/types.h> // u8 u16
#include <asm/termios.h> // u8 u16

#define s8 signed char
#define s16 signed short
#define s32 signed short
#define u8 unsigned char
#define u16 unsigned short
#define u32 unsigned short
#define DEBUG 1
#define __IO volatile


#define DEFAULT_PORT "/dev/ttyUSB2"
#define BSZ 10280
       

void printBuf(unsigned char *bptr, int nchars);
void usage();
char *getFileDate(char *fdate);
int createBinaryFile(char *bfile);
void chomp(const char *s);

char *toUpperCase(char *s)
{
  int n=0;
  while(*s != '\0')
      *s = toupper((unsigned char)*s);
      n++;
      printf("n=%d\n", n);
  return s;
}

void processArgs(int argc, char *argv[])
{
  int i;

  for (i = 1; i < argc; i++)  /* Skip argv[0] (program name). */
  {
      if (strcmp(argv[i], "-cam") == 0) 
      {
          i++;
          sscanf(argv[i], "%d", &cam_num);
          printf("cam_num=%d\n",cam_num);
      }
      else if (strcmp(argv[i], "-port") == 0) 
      {
          i++;
          strcpy((char *)serial_port, (const char*)argv[i]);  /* Convert string to int. */
      }
      else if (strcmp(argv[i], "-readbin") == 0) 
      {
          i++;
          strcpy((char *)readbin_file, (const char*)argv[i]);  /* Convert string to int. */
          readbin_flag = 1;
          nobin_flag   = 1;  // Turn off binary logging
      }
      else if (strcmp(argv[i], "-h") == 0) 
      {
          usage();
      }

      else if (strcmp(argv[i], "-bin") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          if (!strcmp(onoff, "on"))
            nobin_flag=0;
          else if (!strcmp(onoff, "off"))
            nobin_flag=1;
          else
            usage();
      }
  }
} // processArgs

void printOptions()
{
  printf("\nOptions:\n");
  if (!readbin_flag)
  {
    printf("SERIAL PORT \t: %s\n"    , serial_port);
    printf("BINARY LOG \t: %s\n"     , binfile);
  }
  else
    printf("BINARY LOG (reading)\t: %s\n"     , readbin_file);
  printf("\n");
  sleep(3);
} // printOptions

void usage()
{
  printf("\nusage:\n");
  printf("\t-h               : print usage\n");
  printf("\t-port    <dev>   : set serial port (default is %s)\n", DEFAULT_PORT);
  printf("\t-cam     <num>   : associate a camera# with the output log file\n");
  printf("\n");
  exit(1);
}

char *getFileDate(char *fdate)
{
  // equivalent to: system("date +%d%b%y_%H%M");
  char *cmd= "date +%d%b%y_%H%M";
  FILE *fp = popen(cmd, "r");

  fgets(fdate,20,fp);
  chomp(fdate);
  pclose(fp);
  // printf("fdate=%s\n", fdate);
  return fdate;
}

void chomp(const char *s)
{
  char *p;
  while (NULL != s && NULL != (p = strrchr(s, '\n'))){
    *p = '\0';
  }
} /* chomp */

int createBinaryFile(char *bfile)
{
   int fd = open(bfile,  O_CREAT | O_RDWR, 0666);
   if (fd < 0)
   {
      char msg[80];
      sprintf(msg,"Error opening %s", bfile);
      perror(msg);
      exit(1);
   }
   return fd;
} // createBinaryFile

void set_term_misc(int fd)
{
  struct termios2 tio;

  // c_iflag flag constants:
  // IGNBRK Ignore BREAK condition on input.

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("IGNBRK=%d\n", tio.c_iflag & IGNBRK);
  printf("IGNPAR=%d\n", tio.c_iflag & IGNPAR);
  printf("\n");

  // SET
  tio.c_iflag |=  IGNBRK | IGNPAR;
  ioctl(fd, TCSETS2, &tio);

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("IGNBRK=%d\n", tio.c_iflag & IGNBRK);
  printf("IGNPAR=%d\n", tio.c_iflag & IGNPAR);
  printf("\n");
  sleep(2);

}

void set_term_raw(int fd)
{
  struct termios2 tio;
  struct termios2 *termios_p = &tio;

  ioctl(fd, TCGETS2, &tio);
  termios_p->c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP
                 | INLCR | IGNCR | ICRNL | IXON);
  termios_p->c_oflag &= ~OPOST;
  termios_p->c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
  termios_p->c_cflag &= ~(CSIZE | PARENB);
  termios_p->c_cflag |= CS8;

  ioctl(fd, TCSETS2, &tio);
  printf("TERMINAL *RAW* mode is set\n");
  sleep(1);

} // set_term_raw

void set_term_speed(int fd)
{
  struct termios2 tio;

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("CBAUD=%d\n", tio.c_cflag & ~CBAUD);
  printf("ispeed=%d\n", tio.c_ispeed);
  printf("ospeed=%d\n", tio.c_ospeed);
  // printf("\n");

  // SET
  tio.c_cflag &= ~CBAUD;
  tio.c_cflag |=  BOTHER;
  tio.c_ispeed = 115200;
  tio.c_ospeed = 115200;
  ioctl(fd, TCSETS2, &tio);

  // GET verify
  ioctl(fd, TCGETS2, &tio);
  printf("CBAUD=%d\n", tio.c_cflag & ~CBAUD);
  printf("ispeed=%d\n", tio.c_ispeed);
  printf("ospeed=%d\n", tio.c_ospeed);
  // printf("\n");


} // set_term_speed

void set_term_size(int fd)
{
  struct termios2 tio;
  printf("TERM SIZE:\n");

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("~CSIZE=%d\n", tio.c_cflag & ~(CSIZE | PARENB));
  printf("CSIZE=%d\n", tio.c_cflag & (CSIZE | PARENB));
  // printf("\n");

  // SET
  tio.c_cflag &= ~(CSIZE | PARENB);
  tio.c_cflag |= CS8;
  // tio.c_cflag |= CS7;
  ioctl(fd, TCSETS2, &tio);

  // GET verify
  ioctl(fd, TCGETS2, &tio);
  printf("~CSIZE=%d\n", tio.c_cflag & ~(CSIZE | PARENB));
  printf("CSIZE=%d\n", tio.c_cflag & (CSIZE | PARENB));
  // printf("\n");



} // set_term_size

int main (int argc, char *argv[])
{

   char fdate[80];
   bzero(fdate,80);
   bzero(onoff,5);
   getFileDate(fdate);
   // # of write operations to binary file log.
   // Used for flushing (fsync) of the file in case we control-C this program
   int binwrites=0; 

   strcpy(serial_port, DEFAULT_PORT);

   processArgs(argc, argv);
   char logdir[80];
   char mkdir_cmd[80];
   char file[80];
   sprintf(logdir, "/var/log/argus/%s", fdate);
   sprintf(mkdir_cmd, "mkdir %s", logdir);
   system(mkdir_cmd);
   sprintf(file, "camera#%d-%s.log", cam_num, fdate);
   sprintf(binfile, "%s/%s", logdir, file);
   printOptions();

   char *infile = serial_port;

   if (readbin_flag)
     infile = readbin_file;

   int fd = open(infile,  O_RDONLY);
   if (fd < 0)
   {
      char msg[80];
      sprintf(msg,"Error opening %s", infile);
      perror(msg);
      exit(1);
   }
   if (readbin_flag==0)
   {
     // Set serial port settings
     set_term_misc(fd);
     set_term_speed(fd);
     set_term_size(fd);
     // set_term_raw(fd);
   }

   printf("begin!\n");
   int bfd=0;
   if ((readbin_flag==0) || (nobin_flag==0))
     bfd = createBinaryFile(binfile);

   unsigned char *buf = (unsigned char *)malloc(BSZ);
   bzero(buf,BSZ);

   int nread;
   int nwrite;
   unsigned char *p;
   unsigned char *p0;
   int n;
   int berrors=0;
   int nerrors=0;

   while(1)
   {
     bzero(buf,BSZ);
     p = buf;
     n = 0;
     nread = 0;
     do 
     {
       n = read(fd, p, 1);
       if (n > 0)
       {
         nread++;
         p0 = p;
         p++;
       }
       else if (readbin_flag)
       {
         printf("n=%d (%d)\n", n, nerrors);
         nerrors++;
         sleep(1);
         if (nerrors > 0)
         {
           printf("\nDONE READING BINARY FILE %s\n\n", readbin_file);
           exit(0);
         }
       }
     } while ((nread < BSZ));

     //printBuf(buf, nread);

     // BINARY-FILE
     if ((readbin_flag==0) && (nread > 0) && (bfd > 0) && (nobin_flag==0))
     {
       nwrite = write(bfd, buf, nread);
       if (nwrite < 0)
       {
         berrors++;
         if (berrors < 100)
         {
           perror("ERROR writing to binary file");
           printf("ERROR writing to file bfd=%d, binfile=%s\n", bfd, binfile);
         }
       }
       binwrites++;
       if (! (binwrites % 10))
         fsync(bfd);              // FLUSH the output to the binary log file
     } // nread > 0

   } // while 1
   if (bfd > 0)
     close(bfd);
   exit(0);
} // main
