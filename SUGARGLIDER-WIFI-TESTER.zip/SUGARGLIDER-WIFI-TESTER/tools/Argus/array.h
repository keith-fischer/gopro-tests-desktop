/**
*****************************************************************************
* $Id$
* @file array.h
* @brief
* Provides definitions for bacpac array implementation
*
* @section COPYRIGHT
*  Unpublished Copyright (c) 2014 GoPro, Inc., All Rights Reserved.
*
*  GoPro, Inc. ("GoPro") CONFIDENTIAL
*
*  NOTICE: All information contained herein is, and remains the property of
*  GoPro. The intellectual and technical concepts contained herein are
*  proprietary to GoPro and may be covered by U.S. and Foreign Patents, patents
*  in process, and are protected by trade secret or copyright law.
*  Dissemination of this information or reproduction of this material is
*  strictly forbidden unless prior written permission is obtained from GoPro.
*  Access to the source code contained herein is hereby forbidden to anyone
*  except current GoPro employees, managers or contractors who have executed
*  Confidentiality and Non-disclosure agreements explicitly covering such
*  access.
*
*  The copyright notice above does not evidence any actual or intended
*  publication or disclosure of this source code, which includes information
*  that is confidential and/or proprietary, and is a trade secret, of GoPro.
*  ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
*  DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
*  CONSENT OF GOPRO IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
*  AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
*  AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
*  DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
*  THAT IT MAY DESCRIBE, IN WHOLE OR IN PART.
*
*****************************************************************************
*/
#ifndef _ARRAY_H_
#define _ARRAY_H_

#ifdef BACPAC_3D_ARRAY
#include "bit_alias.h"
#ifndef BOOTLOADER
// #include "message_queue.h"
#endif

//#define BACPAC_ARRAY_FLIP_EVERY_OTHER_CAMERA //D.L. Request from 7/23/2014 to make array version where every second camera has flipped screens
//#define BACPAC_MARS_ARRAY_GPIO_CONTROLLED //D.L. Request from 10/28/2014 for "Mars Project": use some GPIO lines on debug port
    //to let external circuit to order bacpac array to turn camera ON and then start capture.

#define MAX_SLAVE_COUNT 256

//#define TEST_SYNC_SEPARATE //This was used during prototyping. Each MCU ran its own sync timer
    //and drove sync lines to its attached camera. 
    //In the final design primary master drives sync for all slaves

enum PendingCommandID
{//Order of decreasing priority
   PC_CommandFromPort2Queue,
   PC_Ack,
   PC_GetStatusBit,
   PC_CheckPrevCmd,
   PC_VerifyErrorMask,//I2CMSG_ARRAY_VERIFY_ERROR_MASK
   PC_GetNoErrorBit,//I2CMSG_ARRAY_GET_NO_ERROR_BIT
   PC_VerifyErrorMaskForSlave,//I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE
   PC_GetNoErrorBitForSlave,//I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE
   PC_Wait,
   PC_WaitRes,
   PC_WaitResNegative,
   PC_Ping,
   PC_Debug,
   PC_SetTimeStamp,
   PC_SetPowerOffCode,
//   PC_CommandFromPort2Queue,
   PC_FpgaDone,
   PC_FpgaResetID,
   
   PC_NumPendingCommands
};//Note: values of this enum is used as indexes in struct PendingCommand

int array_init();
enum CommandWaitResult
{
    CWR_Ack,
    CWR_Nack,
    CWR_Timeout,
};
typedef void T_arrayBroadcastOnAckCallback(enum CommandWaitResult result);
#ifndef BOOTLOADER
void array_broadcast_command_queue(enum PendingCommandID command_id, 
    struct CommandHeader * cmd, u8 param, T_arrayBroadcastOnAckCallback * callback, 
    int async//async should be 1 if we be called from ISR or recursively from within send_command
);
#endif
//void array_broadcast_start_wait_sr(int param);//Called on master
void array_broadcast_on_response(u8 ordinal, u8 success);//Called on slaves
//void array_broadcast_end_wait_sr();
void array_handle_sync_ready(u8 param);
void array_abort_wait_on_error();
void array_handle_broadcast_command();
void array_handle_broadcast_response();
void array_handle_broadcast_tx();
void array_broadcast_init(void);
void array_broadcast_poll();
void array_bus_receiver_poll();
#ifdef LOG
void array_broadcast_print_stat();
void array_broadcast_reset_stat();
#endif

//BIT_ALIAS extern pending_command_sy;
//BIT_ALIAS extern pending_command_sr;
//BIT_ALIAS extern pending_command_ping;
//BIT_ALIAS extern pending_command_debug;
//#define IS_BROADCAST_COMMAND_PENDING (pending_command_sy || pending_command_sr || pending_command_ping || pending_command_debug)
extern u32 pending_broadcast_command_flags;
#define IS_BROADCAST_COMMAND_PENDING (pending_broadcast_command_flags)


BIT_ALIAS extern array_port_i2c_error[2];//array_port_i2c_error[0] - port2, array_port_i2c_error[1] - port3
BIT_ALIAS extern array_camera_error;
BIT_ALIAS extern array_internal_error;
BIT_ALIAS extern array_fatal_internal_error;
BIT_ALIAS extern array_camera_error_to_clear;
BIT_ALIAS extern broadcast_error;
BIT_ALIAS extern criticalPowerOffSent;
extern u8 criticalPowerOffCodeToSend;
extern u32 criticalPowerOffCodeToSendAfterTick;

//i2c_port3_read_command initiates asynchronous RX transfer.
//It will store received data in static I2C buffer RX_Transfer[chan].pbBuffer.
//When transfer finished, ISR callback CPAL_I2C_RXTC_UserCallback will set i2c_port3_rx_data_ready flag
//and our main loop should invoke i2c_port3_get_received_command()
//i2c_port3_read_command will return 0 on success or -1 of error (I2C not working)
int i2c_port3_read_command();
const u8 * i2c_port3_get_received_command();


void bacpac_array_poll();

/*
//D.L. 4/14/2014 Disable this: 
enum ArraySettingsEvents
{
    ASE_ForgetSettings,
    ASE_NewSettings,
    ASE_Poll
};
void array_settings_state_machine(enum ArraySettingsEvents event);
*/

enum ArraySySrEvents
{
    SYSR_Reset,//Forget old SR result
    SYSR_SendSY,
    SYSR_GotSYReply,
    SYSR_GotOtherReply,
    SYSR_GotSR012,
    SYSR_GotSR3,
};
void array_sy_sr_state_machine(enum ArraySySrEvents event, int param, int verbose);

//array_on_port3_command_queued_or_sent called with interrupt disabled, possibly from ISR
u8 array_on_port3_command_queued_or_sent(u16 message, u8 param, u8 ordinal, u8 sent);
void array_on_port3_command_queue_reset();

//array_is_duplicate_command called with interrupt disabled, possibly from ISR
int array_is_duplicate_command(u16 message, u8 ordinal);

enum SY_SR_Action
{
    SA_Reset,
    SA_NeedPostSY,
    SA_GotSR
};
enum SY_SR_State
{
    SS_Idle,
    SS_PostedSY,
    SS_GotSR
};
void shutter_SY_SR_handler(u8 camera_idx, enum SY_SR_Action action, u8 param);

BIT_ALIAS extern i2c_port3_irq_pending;
BIT_ALIAS extern i2c_port3_rx_data_ready;
BIT_ALIAS extern Port3SlaveConnected;
BIT_ALIAS extern Port3TerminatorConnected;
BIT_ALIAS extern Port2MasterConnected;
BIT_ALIAS extern Port2MasterConnectedInitialized;
BIT_ALIAS extern slave_bacpac_version_verified;

BIT_ALIAS extern global_status_i_am_primary;
BIT_ALIAS extern global_status_i_am_secondary;
BIT_ALIAS extern global_status_i_am_secondary_end;
BIT_ALIAS extern global_status_i_am_connected;
BIT_ALIAS extern global_status_last_slave_ready;

BIT_ALIAS extern array_ping_to_send;
BIT_ALIAS extern array_ping_incoming_pending;
BIT_ALIAS extern array_ping_outgoing_pending;
extern u8 array_ping_pending_ordinal;
extern u32 last_received_command_tick_count;
extern u8 array_ping_recvd_flags;
extern u8 array_ping_current_flags;//Equal to array_ping_recvd_flags for slaves or flags sent in the last ping for master
extern u32 array_ping_sent_tick_count;

extern u8 outgoing_command_ordinal;
extern u16 outgoing_command_code;
extern u32 i2c_port3_send_command_tick_count;
extern u32 vs_sent_tick_count;

extern u32 last_power_cycle_tick_count;
extern u32 array_ping_reply_tick_count;
//extern u32 array_ping_reply_status;
//extern u32 array_ping_combined_status;
//extern u32 array_ping_sent_to_master_status;

extern u32 array_local_status;//Status of this node, does not include status of slaves.
                              //On slaves this is the only status we need.
extern u32 array_slave_status;//Used on master only
extern u32 array_combined_status;//On slaves - equal to array_local_status.
                                 //On master: combined with the status of slaves


extern u32 array_status_received_tick_count;

BIT_ALIAS extern array_mode_3D_requested;
BIT_ALIAS extern array_mode_3D_pending;
BIT_ALIAS extern array_mode_3D_OK;
BIT_ALIAS extern array_green_led;//Means we are in 3D and no errors detected

BIT_ALIAS extern syncReadyCaptureDone;

extern u8 arrayPowerOffCode;

BIT_ALIAS extern skip_scl_low_print;

//D.L. 4/14/2014 Disable this: extern u32 bacpac_cam_settings_change_count;//0 means we have no valid settings
extern int array_cam_settings_version_acked;
extern int array_cam_settings_version_sending;
BIT_ALIAS extern array_got_settings_from_master;

//BIT_ALIAS extern array_sync_on;

#ifdef TEST_SYNC_SEPARATE
//This was prototype code that allowed slaves drive Sync lines for their attached cameras
BIT_ALIAS extern array_got_sync_rdy_and_sync;
BIT_ALIAS extern array_got_sync_rdy_no_sync;
BIT_ALIAS extern array_got_capture_stop;
BIT_ALIAS extern array_got_sync_stop;
#endif

BIT_ALIAS extern array_sync_running_do_not_log;

BIT_ALIAS extern array_slave_capture_in_progress;
BIT_ALIAS extern array_got_sr012;
BIT_ALIAS extern array_got_sr3;

//BIT_ALIAS extern array_ping_odd_led;
#ifdef LOG
extern u32 outgoing_command_cycle;
#endif

extern u32 i2c_port3_num_errors;
extern u32 i2c_port3_last_error_tick_count;
#define INC_NUM_ERRORS {i2c_port3_num_errors++; i2c_port3_last_error_tick_count = tickCount;}
#endif

extern const u8 crc8_lookup[256];

enum LastVSResponse
{
    VS_NONE,
    VS_FOUND_BOOTLOADER,
    VS_FOUND_FW_CRC_MATCH,
    VS_FOUND_FW_CRC_MISSMATCH,
    VS_FOUND_DEBUG_FW,
    VS_ERROR
};
extern enum LastVSResponse last_vs_response;
void need_send_vs();

#if defined(BACPAC_MARS_ARRAY_GPIO_CONTROLLED) || defined(LOG)
BIT_ALIAS extern all_cameras_secondary_mode;
BIT_ALIAS extern internal_poweron_request;
BIT_ALIAS extern internal_poweron_request_persistent;
BIT_ALIAS extern internal_poweroff_request;
#else
#define all_cameras_secondary_mode 0
#define internal_poweron_request 
#define internal_poweron_request_persistent
#define internal_poweroff_request 0
#endif

#ifdef LOG
BIT_ALIAS extern array_eeprom_returned_primary;
BIT_ALIAS extern array_eeprom_returned_secondary;
#else
#define array_eeprom_returned_primary 0
#define array_eeprom_returned_secondary 0
#endif

#ifdef LOG
extern u32 port2_num_commands_rcvd;
extern u32 port2_num_commands_sent;
extern u32 port2_num_responses_sent;
extern u32 port2_num_bad_crc_rcvd;
extern u32 port2_num_duplicates_rcvd;
#endif

//#define DO_NOT_SEND_FW_IF_SLAVE_DEBUG

#ifdef BACPAC_3D_ARRAY_NONSTOP
#define DO_NOT_STOP_CAPTURE_ON_ERROR //Request from Tim on 4/18/2014:
    //"A failure on one camera should not prevent the array from working"

#define PES_WITHOUT_SKIPS //Request from Tim on 4/18/2014: 
    //"If in PES mode any camera is not ready by the next required capture time
    //- skip shot on that camera, but take shot on the remaining cameras"
//D.L. 4/21/2014 As explained by Alex on 4/21/2014, PES without skips cannot work because:
//1. "cameras syncs must run  until the last camera is complete"
//2. "external syncs have to stop before the cameras take the next exposure" 
#ifdef PES_WITHOUT_SKIPS
BIT_ALIAS extern pes_without_skips;//Currently it is an experimental feature enabled from command line
#endif
#endif

enum SettingID
{
   SID_Setup = 0,
   SID_Video = 1,
   SID_Photo = 2,
   SID_MultiShot = 3,
   
   SIDV_SetMode = 4,
   SIDV_VideoRecordStart = 5,
   SIDV_VideoRecordStop = 6,
   SIDV_PhotoRecordStart = 7,
   SIDV_PhotoRecordStop = 8,
   
   NUM_SETTINGS
};

struct CommandHeader * prepare_setting_to_send_to_slaves(enum PendingCommandID command_id, int * return_buffer_size);//Returns pointer to static array
struct CommandHeader * prepare_setting_to_send_to_camera(enum SettingID ID, int * return_buffer_size);
void on_settings_command_ack_by_camera(u16 command, u8 status);
void on_settings_command_id_ack(enum PendingCommandID command_id);
void check_and_send_settings();
void on_camera_restart();
void array_update_master_cur_flag();
#ifdef BOOTLOADER
int ProcessBroadcastCommandOnISRContext(u8 * buffer, s8 command_ordinal);
void UpdateStatusBitsOnISRContext(u32 * array_status);
#endif

#ifndef BOOTLOADER
int prepare_response(u8 * msg_data, u8 ordinal, int success, struct Response * response, 
    int response_size);//response_size is space after and including response->command.length
#define MESSAGE_MAX_BYTES         128
#define MESSAGE_QUEUE_SIZE          4
#pragma pack(1)
typedef struct
{
   struct CommandHeader header;
   u8 msg_data[MESSAGE_MAX_BYTES];
   u8 ordinal; 
} msg_t;
int prepare_response_for_message(msg_t * msg, int success, struct Response * response,
   int response_size//response_size is space after and including response->command.length
   );
#endif

BIT_ALIAS extern array_need_get_status_asap;

extern u32 arrayTimeStamp;

//enum ArrayBatteryPresentChangeState is used on slaves to know when master receives our changed battery state
enum ArrayBatteryPresentChangeState
{
    ABP_Changed,//Camera plugged or unplugged
    ABP_Reported,//We reported ASB_CAMERA_PRESENT bit to master
    ABP_GetStatusFinished,//master accepted status bits (and sent ASB_NO_STATUS_CHANGES)
    ABP_Done,//master sent new command (which should reflect the previously reported battery state)
};
extern enum ArrayBatteryPresentChangeState arrayBatteryPresentChangeState;
extern uint32_t camerasBatPresentChangeTickCount;

int array_get_termination(void);
void array_show_termination(uint8_t bell);

void array_set_termination(int termination);
int array_is_last_slave_not_ready(void);
void array_last_slave_ready_set(void);
void array_last_slave_ready_clear(void);

#endif //_ARRAY_H_
