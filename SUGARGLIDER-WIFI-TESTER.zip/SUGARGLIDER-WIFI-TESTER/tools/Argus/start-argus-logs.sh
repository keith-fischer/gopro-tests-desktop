# 
LOGD=/var/log/argus

function start_camlog {
  # DATE=`date +'%e%b-%H%M'`
  CMD="/usr/local/bin/camlog -cam $1 -port $2"
  echo ""
  echo $CMD
  nohup $CMD &
  echo ""
  echo "####################################################"
  echo "see LOG DIRECTORY: $LOGD"
  echo "####################################################"
  echo ""
}

echo ""
echo "######## LIST OGF USB DEVICES ##########"
echo "Note: Use even-numbered ports for t-command control"
ll /dev/ttyUSB*
ls /dev/ttyUSB* | wc
mkdir -p /var/log/argus
echo ""
echo "STARTING camlog for all 16 cameras..."
echo "Note: See /var/log/argus"
echo "Note: run ps and grep for minicom to see which ports are attached. kill -9 <pid> to stop camlog"
echo ""
start_camlog 1 /dev/ttyUSB0
start_camlog 2 /dev/ttyUSB2
start_camlog 3 /dev/ttyUSB4
start_camlog 4 /dev/ttyUSB6
start_camlog 5 /dev/ttyUSB8
start_camlog 6 /dev/ttyUSB10
start_camlog 7 /dev/ttyUSB12
start_camlog 8 /dev/ttyUSB14
start_camlog 9 /dev/ttyUSB16
start_camlog 10 /dev/ttyUSB18
start_camlog 11 /dev/ttyUSB20
start_camlog 12 /dev/ttyUSB22
start_camlog 13 /dev/ttyUSB24  
start_camlog 14 /dev/ttyUSB26
start_camlog 15 /dev/ttyUSB28  # Green board needs jumper
start_camlog 16 /dev/ttyUSB30  # Green board needs jumper

echo ""
ps ax | grep -i camlog | grep -v grep | grep -v vi
echo ""
