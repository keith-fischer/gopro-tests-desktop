/**
*****************************************************************************
* $Id$
* @file bit_alias.c
* @brief
* Definition of BIT_ALIAS macro that allows using bit alias feature of Cortex
*
* @section COPYRIGHT
*  Unpublished Copyright (c) 2014 GoPro, Inc., All Rights Reserved.
*
*  GoPro, Inc. ("GoPro") CONFIDENTIAL
*
*  NOTICE: All information contained herein is, and remains the property of
*  GoPro. The intellectual and technical concepts contained herein are
*  proprietary to GoPro and may be covered by U.S. and Foreign Patents, patents
*  in process, and are protected by trade secret or copyright law.
*  Dissemination of this information or reproduction of this material is
*  strictly forbidden unless prior written permission is obtained from GoPro.
*  Access to the source code contained herein is hereby forbidden to anyone
*  except current GoPro employees, managers or contractors who have executed
*  Confidentiality and Non-disclosure agreements explicitly covering such
*  access.
*
*  The copyright notice above does not evidence any actual or intended
*  publication or disclosure of this source code, which includes information
*  that is confidential and/or proprietary, and is a trade secret, of GoPro.
*  ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
*  DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
*  CONSENT OF GOPRO IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
*  AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
*  AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
*  DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
*  THAT IT MAY DESCRIBE, IN WHOLE OR IN PART.
*
*****************************************************************************
*/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BIT_ALIAS_H
#define __BIT_ALIAS_H

//D.L. 11/11/2013 To reduce RAM usage I converted flags variables, which used to be uint8_t,
//to bits places in separate .bitflags section. 
//These bits are accessed via 32 bit aliases placed in .bitflagalias section.
#define BIT_ALIAS _Pragma("location=\".bitflagalias\"") uint32_t
//All these bits are initialized to 0.
//When assigning values to these aliases only bit[0] is used. So, let's assign only 0 or 1.
//If you add more such bitalias variables and linker prints an error:
//Error[Lp011]: section placement failed 
//          unable to allocate space for sections/blocks with a total estimated minimum size of xxx bytes in <[0x2203ffe0-
//then you should allocate more space for .bitflags and .bitflagalias section:
//In stm32f1000x8_release.icf and stm32f1000x8_debug.icf:
//Decrease __ICFEDIT_region_RAM_end__ value by 1.
//Assign value of __ICFEDIT_region_RAM_end__ plus 1 to __ICFEDIT_region_RAM_BITS_start__.
//Assign value of __ICFEDIT_region_BIT_ALIAS_start__ according to formula
//__ICFEDIT_region_BIT_ALIAS_start__ == 0x22000000 + (__ICFEDIT_region_RAM_BITS_start__ - 0x20000000) * 32
#endif /* __BIT_ALIAS_H */
