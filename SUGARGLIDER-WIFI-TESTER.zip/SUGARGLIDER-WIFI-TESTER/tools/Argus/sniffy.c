/* sniffy.c - decodes Arguys binary bus data read over the RS-485 serial connection.
 *
 *  - "sniffy -h' prints out help/options
 *  - capable of printing out all packets seen including unknowns
 *  - capable of filtering (not printing) packets (ie - ack,ping, packets)
 *  - saves all binary data read to a file argus-<data>.bin
 *  - capable of playing back binary data read from a file and decoding it (as if
 *     read from serial input)
 *
 * TODO:
 * x1. Collect *ALL* binary data and ascii logs - EVEN THOUGH messages might be turned off
 *    - this includes acks and GetStatus, ArrayDebugs, BroadcastPings
 * x2. build options parser so that we can ignore certain messages
 *
 */
int show_ak=0;         // ACK/NOACK
int show_gs=0;         // get-status
int show_bp=0;         // broadcast-ping
int show_ad=0;         // array-debug
int show_uk=0;         // unknown-commands
int nobin_flag=0;      // dont create a binary log file of all input received
char serial_port[80];  // serial port name
char onoff[5];         // on/off option
char binfile[80];      // binary file name
char readbin_file[80]; // binary file to READ (instead of the serial port)
int readbin_flag=0;    // flag to read the binary file  instead of the serial port (see -readbin option)
int offset=1;          // determines offset into input whether Argus bacpacs are transmitting 0xff (BREAK) or not

#include <stdlib.h> // exit(), system()
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> // sleep(), fsync()
#include <stdint.h> // uint32_t
#include <strings.h> // bzero()
#include <string.h>  // strcpy
#include <linux/types.h> // u8 u16
#include <asm/termios.h> // u8 u16

#define s8 signed char
#define s16 signed short
#define s32 signed short
#define u8 unsigned char
#define u16 unsigned short
#define u32 unsigned short
#define BACPAC_3D_ARRAY 1
#define DEBUG 1
#define __IO volatile

#include "./app_i2c_protocol.h"
#undef DEBUG_printf
#undef DEBUG_printf_broadcast
#define DEBUG_printf printf
#define DEBUG_printf_broadcast printf
#include "./bit_alias.h"
#include "./array.h"

//This is single 128KB sector setup
#define USER_START_ADDRESS  ((uint32_t)0x08020000)
#define USER_END_ADDRESS    ((uint32_t)0x08040000)


#define ARGUS_BUS "/dev/ttyUSB%s"
#define DEFAULT_PORT "/dev/ttyUSB2"
#define BSZ 10280
#define LONGEST_COMMAND_LEN 130 //For FW upgrade
#define BROADCAST_REPLY_NO   0
#define BROADCAST_REPLY_ACK  1
#define BROADCAST_REPLY_NACK 2
       
volatile u8 broadcast_rx_buffer[LONGEST_COMMAND_LEN*2];//To be safe let buffer hold 2 commands
int reply_now = BROADCAST_REPLY_ACK;
int snoop_bus = 1;
uint32_t ack_mask = 0xffffffff;
u8 slave_waiter_ordinal = 0xFF;//This is ordinal of the wait command
u8 slave_waitee_ordinal = 0xFF;//This is ordinal of the command that we wait for
u32 slave_waitee_ordinal_changed_tick;
u32 tickCount=0;
BIT_ALIAS slave_wait_last_response_success;//Once we acked a Wait keep success/fail flag here
struct DebugParams debug_params;

//syncReady bits apply to the last SYNC_READY commands (start, stop, done)
BIT_ALIAS syncReadyStartSeen;
BIT_ALIAS syncReadyStopSeen;
BIT_ALIAS syncReadyCaptureDone;

BIT_ALIAS slave_wait_aborted_by_error;

BIT_ALIAS slave_wait_last_response_success;//Once we acked a Wait keep success/fail flag here
BIT_ALIAS global_status_i_am_primary;
BIT_ALIAS global_status_i_am_secondary;
BIT_ALIAS global_status_i_am_secondary_end;
BIT_ALIAS global_status_i_am_connected;
BIT_ALIAS global_status_last_slave_ready;
enum ArrayBatteryPresentChangeState arrayBatteryPresentChangeState = ABP_Changed;

u32 logTickCount;


u32 array_send_status = 0;
u32 arrayTimeStamp;
u8 arrayPowerOffCode;

void printBuf(unsigned char *bptr, int nchars);
void decodePkt(unsigned char *buffer, int nchars);
void decodeMasterCommand(u8 masterCommand);
int printThisCommand(u16 command, unsigned char *bptr, int len);
void usage();
char *getFileDate(char *fdate);
int createBinaryFile(char *bfile);
void chomp(const char *s);

char *toUpperCase(char *s)
{
  // while(*s != '\0')
  int n=0;
  while(*s != '\0')
      *s = toupper((unsigned char)*s);
      n++;
      printf("n=%d\n", n);
  return s;
}

void decodeMasterCommand(u8 masterCommand)
{
   //Order of decreasing priority
   printf("\n");
   switch (masterCommand)
   {
     case PC_CommandFromPort2Queue:
       printf("masterCommand==PC_CommandFromPort2Queue\n");
       break;
     case PC_Ack:
       printf("masterCommand==PC_Ack\n");
       break;
     case PC_GetStatusBit:
       printf("masterCommand==PC_GetStatusBit\n");
       break;
     case PC_CheckPrevCmd:
       printf("masterCommand==PC_CheckPrevCmd\n");
       break;
     case PC_VerifyErrorMask://I2CMSG_ARRAY_VERIFY_ERROR_MASK
       printf("masterCommand==PC_VerifyErrorMask\n");//I2CMSG_ARRAY_VERIFY_ERROR_MASK
       break;
     case PC_GetNoErrorBit://I2CMSG_ARRAY_GET_NO_ERROR_BIT
       printf("masterCommand==PC_GetNoErrorBit\n");//I2CMSG_ARRAY_GET_NO_ERROR_BIT
       break;
     case PC_VerifyErrorMaskForSlave://I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE
       printf("masterCommand==PC_VerifyErrorMaskForSlave\n");//I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE
       break;
     case PC_GetNoErrorBitForSlave://I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE
       printf("masterCommand==PC_GetNoErrorBitForSlave\n");//I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE
       break;
     case PC_Wait:
       printf("masterCommand==PC_Wait\n");
       break;
     case PC_WaitRes:
       printf("masterCommand==PC_WaitRes\n");
       break;
     case PC_WaitResNegative:
       printf("masterCommand==PC_WaitResNegative\n");
       break;
     case PC_Ping:
       printf("masterCommand==PC_Ping\n");
       break;
     case PC_Debug:
       printf("masterCommand==PC_Debug\n");
       break;
     case PC_SetTimeStamp:
       printf("masterCommand==PC_SetTimeStamp\n");
       break;
     case PC_SetPowerOffCode:
       printf("masterCommand==PC_SetPowerOffCode\n");
       break;
     // case PC_CommandFromPort2Queue:
       // printf("masterCommand==PC_CommandFromPort2Queue\n");
       break;
     case PC_FpgaDone:
       printf("masterCommand==PC_FpgaDone\n");
       break;
     case PC_FpgaResetID:
       printf("masterCommand==PC_FpgaResetID\n");
       break;
     default: 
       printf("WARNING: UNKNOWN MASTER COMMAND=0x%x\n", masterCommand);
       break;
   }
} // decodeMasterCommand

#if 0
#pragma pack(1)
struct CommandHeader
{
    u8 flags; //Flags from enum CommandHeaderFlags: We do not send this byte, but keep it in RAM
    unsigned char size;//Space allocated for this command including struct CommandHeader and following data
    unsigned char length;//This is the first byte to be sent. It contains the number of bytes sent excluding this length byte itself.
    unsigned short  commandCode;
};

// array.h
enum PendingCommandID
{//Order of decreasing priority
   PC_CommandFromPort2Queue,
   PC_Ack,
   PC_GetStatusBit,
   PC_CheckPrevCmd,
   PC_VerifyErrorMask,//I2CMSG_ARRAY_VERIFY_ERROR_MASK
   PC_GetNoErrorBit,//I2CMSG_ARRAY_GET_NO_ERROR_BIT
   PC_VerifyErrorMaskForSlave,//I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE
   PC_GetNoErrorBitForSlave,//I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE
   PC_Wait,
   PC_WaitRes,
   PC_WaitResNegative,
   PC_Ping,
   PC_Debug,
   PC_SetTimeStamp,
   PC_SetPowerOffCode,
//   PC_CommandFromPort2Queue,
   PC_FpgaDone,
   PC_FpgaResetID,

   PC_NumPendingCommands
};//Note: values of this enum is used as indexes in struct PendingCommand


struct PendingCommand
{
   enum PendingCommandID id;
   u16 command;
   u8  clear_pending_on_sending;
        //4.2.4. To remember that a command need repeating after channel is cleared,
        // we should reset command pending flag only afted it is ACKed.
        //This is true for all commands except for PC_Wait and PC_Ping
   u8 special_retry_logic;//PC_Wait, PC_Ping and PC_CheckPrevCmd have special logic
};

const struct PendingCommand PendingCommands[] = {//Positions - from enum PendingCommandID
   //[PC_SY] = {PC_SY, I2CMSG_SYNC_NOTIFY, 0},
   [PC_CommandFromPort2Queue] = {PC_CommandFromPort2Queue, 'Q'+'Q'*0x100, 0, 0},//QQ is a fake just for logging
   [PC_Ack] =  {PC_Ack, I2CMSG_ACK, 1, 0},
   [PC_GetStatusBit] = {PC_GetStatusBit, I2CMSG_BRST_GET_STATUS_BIT, 0, 0},
   [PC_CheckPrevCmd] = {PC_CheckPrevCmd, I2CMSG_BRST_CHECK_PREV_CMD, 1, 1},
   [PC_VerifyErrorMask] = {PC_VerifyErrorMask, I2CMSG_ARRAY_VERIFY_ERROR_MASK, 0, 0},
   [PC_GetNoErrorBit] = {PC_GetNoErrorBit, I2CMSG_ARRAY_GET_NO_ERROR_BIT, 0, 0},
   [PC_VerifyErrorMaskForSlave] = {PC_VerifyErrorMaskForSlave, I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE, 0, 0},
   [PC_GetNoErrorBitForSlave] = {PC_GetNoErrorBitForSlave, I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE, 0, 0},
   [PC_Wait] = {PC_Wait, I2CMSG_WAIT, 1, 1},
   [PC_WaitRes] = {PC_WaitRes, I2CMSG_WAIT_RESULT, 0, 0},
   [PC_WaitResNegative] = {PC_WaitResNegative, I2CMSG_WAIT_RESULT_NEGATIVE, 0, 0},
   [PC_Ping] = {PC_Ping, I2CMSG_BROADCAST_PING, 1, 1},
   [PC_Debug] = {PC_Debug, I2CMSG_ARRAY_DEBUG_COMMAND, 0, 0},
   [PC_SetTimeStamp] = {PC_SetTimeStamp, I2CMSG_ARRAY_SET_TIMESTAMP, 0, 0},
   [PC_SetPowerOffCode] = {PC_SetPowerOffCode, I2CMSG_ARRAY_SET_POWER_OFF_CODE, 0, 0},
   //[PC_CommandFromPort2Queue] = {PC_CommandFromPort2Queue, 'Q'+'Q'*0x100, 0, 0},//QQ is a fake just for logging
   [PC_FpgaDone] = {PC_FpgaDone, I2CMSG_FPGA_DONE, 0, 0},
   [PC_FpgaResetID] = {PC_FpgaResetID, I2CMSG_FPGA_RESET_ID, 0, 0},

};

struct WaitResponseBuffer
{
    struct Response header;
    u8 data[10];
};
//ResponseBufferSize includes size starting from the length byte
#define WaitResponseBufferSize (sizeof(struct WaitResponseBuffer) - offsetof(struct WaitResponseBuffer, header.command.length))
struct WaitResponseBuffer wait_response;//DL: 6/1/2015

#endif // 0


int printThisCommand(u16 command, unsigned char *buffer, int len)
{
  u8  length     = buffer[0] & 0x7f;//This excludes length itself, but includes crc
  u8  command_ordinal = buffer[length] & 0xF;
  //u16 command    = *(u16*)(&buffer[1]);
  u8  param      = buffer[3];
  if ((command_ordinal==0) && (show_uk==0)) // Ignore (dont show) empty commands
    return 0;
  switch(command)
  {
    case I2CMSG_BRST_GET_STATUS_BIT:
      if (!show_gs) return 0;
      break;
    case I2CMSG_ACK:
      if (!show_ak) return 0;
      break;
    case I2CMSG_BROADCAST_PING:
      if (!show_bp) return 0;
      break;
    case I2CMSG_ARRAY_DEBUG_COMMAND:
      if (!show_ad) return 0;
      break;
    default:
      break;
  }
  return 1;
}

const u8 crc8_lookup[] = {//Polynomial 0x8C or x**8 + x**5 + x**4 + 1
    0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
    0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e, 0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
    0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0, 0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
    0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d, 0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
    0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5, 0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
    0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58, 0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
    0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6, 0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
    0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b, 0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
    0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f, 0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
    0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92, 0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
    0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c, 0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
    0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1, 0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
    0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49, 0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
    0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4, 0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
    0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a, 0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
    0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7, 0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35
};

s8 check_crc_in_command(const u8 * buffer, const char * log_comment)//Return -1 on error, command ordinal on success
   //check_crc_in_command does not reduce the command length in buffer[0]
{
    //command format:
    //len, cmd1, cmd2, p1, ... px, crcOrd
    //if no payload, then len == 3:
    //len, cmd1, cmd2, crcOrd
    //length does not include length byte itself, but includes the last crcOrd byte
    //crc includes all bytes including length, but excluding crcOrd byte
    //crcOrd byte has ordinal in lower 4 bit and combined crc bytes in upper 4 bits
    //Calculation of crcOrd byte:
    //- calculate crc of all bytes including length, but excluding crcOrd
    //- add 4 lower bits of command_ordinal and 0 as upper 4 bits to crc
    //- Store 4 lower bits if command_ordinal to lower bits of crcOrd
    //- xor 4 lower bits of crc with 4 upper bits of crc and store to 4 upper bits of crcOrd
    int i, len = (buffer[0] & 0x7F);
    u8 crc = 0;
    for(i = 0; i < len; i++)
    {
        crc = crc8_lookup[crc ^ buffer[i]];
    }
    u8 command_ordinal = buffer[len] & 0xF;
    crc = crc8_lookup[crc ^ (command_ordinal & 0xF)];
    crc = (crc << 4) ^ crc;//Merge all bits of crc into the upper half
    crc = (crc & 0xF0) | (command_ordinal & 0xF);//Merge CRC with ordinal
    if(crc != buffer[len])
    {
        // DEBUG_printf("%s: crcOrd calc %x != rcvd %x", log_comment, crc, buffer[len]);
        printf("%s: crcOrd calc:%x != rcvd:%x ord=%d\t", log_comment, crc, buffer[len], command_ordinal);
        return (s8)-1;
    }
    return command_ordinal;
}

// from array.c:

//Equal to array_ping_recvd_flags for slaves or flags sent in the last ping for master
u8 array_ping_current_flags = 0;

u32 array_local_status = 0;//Status of this node, does not include status of slaves.
                              //On slaves this is the only status we need.
//Note port3_commands array (in ROM) is parallel to  array (in RAM),
//where we keep dynamic info about these commands.
//items in thes arrays must be on positions defined by enum PendingCommandTypes
//struct PendingCommand pending_commands[countof(port3_commands)] = {0};
//
void I2CdecodeCommand(unsigned char *buffer, u16 I2Ccommand)
{
  // int I2Ccommand = cmd;
  u8  length     = buffer[0] & 0x7f;//This excludes length itself, but includes crc
  u8  command_ordinal = buffer[length] & 0xF;
  u8  param      = buffer[3];
  u8 masterCommand=0;

  if(I2Ccommand == I2CMSG_BRST_CHECK_PREV_CMD)
  {
    struct CheckPrevCmdParam * param = (struct CheckPrevCmdParam *)(buffer + 3);
    printf(" I2CMSG_BRST_CHECK_PREV_CMD");
    printf(" prev ordinal/min_rcvd_count=%d%d", param->ordinal, param->min_rcvd_count);
  }
  switch(I2Ccommand)
  {
  case I2CMSG_BRST_GET_STATUS_BIT:
    if(snoop_bus && show_gs) { DEBUG_printf("SNOOP: I2CMSG_BRST_GET_STATUS_BIT %d", param);}
      #ifdef BOOTLOADER
      UpdateStatusBitsOnISRContext(&array_local_status);
      #endif
      if(param == 0)
      {
          masterCommand = buffer[4];
          decodeMasterCommand(masterCommand);
          //Master command is attached to PC_GetStatusBit bit #0
          if(array_ping_current_flags != buffer[4])
          {
              DEBUG_printf("Array: *NEW* MASTER command 0x%02x->0x%02x", array_ping_current_flags, buffer[4]);
              // masterCommand = array_ping_current_flags = buffer[4];
              // decodeMasterCommand(masterCommand);
          }

          array_send_status = array_local_status;
          #ifdef BOOTLOADER
          addLog("SS", array_send_status);
          #endif
          if(arrayBatteryPresentChangeState == ABP_GetStatusFinished)
          {
              arrayBatteryPresentChangeState = ABP_Done;
          }
      }
      if (param == 0) DEBUG_printf_broadcast("\r\n================== PARAM TABLE ====================");
      if(param == ASB_NO_STATUS_CHANGES)//last bit
      {
          if(array_send_status == array_local_status)
          {
              DEBUG_printf_broadcast(" Br: bit #%d is set. ACK", param);
              reply_now = BROADCAST_REPLY_ACK;;
          }
          else
          {
              DEBUG_printf_broadcast(" Br: status changed bit #%d is not set. NACK", param);
              reply_now = BROADCAST_REPLY_NACK; //!@#
          }
          if(arrayBatteryPresentChangeState == ABP_Reported)
          {
              arrayBatteryPresentChangeState = ABP_GetStatusFinished;
          }
      }
      else if(array_send_status & (1 << param))
      {
          DEBUG_printf_broadcast(" Br: bit #%d is set. ACK", param);
          reply_now = BROADCAST_REPLY_ACK;;
      }
      else
      {
          DEBUG_printf_broadcast(" Br: bit #%d is not set. NACK", param);
          reply_now = BROADCAST_REPLY_NACK; // !@#
      }
      if(param == ASB_CAMERA_PRESENT)
      {
          if(arrayBatteryPresentChangeState == ABP_Changed)
          {
              arrayBatteryPresentChangeState = ABP_Reported;
          }
      }
      break;
  case I2CMSG_ARRAY_GET_NO_ERROR_BIT:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_GET_NO_ERROR_BIT");}
      // reply_now = getErrorBit(param);
      break;
  case I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE");}
      // reply_now = getErrorBitForSlave(param, *(u32*)(buffer + 4));
      break;
  case I2CMSG_ARRAY_VERIFY_ERROR_MASK:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_VERIFY_ERROR_MASK");}
      // reply_now = verifyErrorMask(*(__packed__ uint64_t*)(buffer + 3));
      // reply_now = verifyErrorMask(*(uint64_t*)(buffer + 3));
      break;
  case I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE");}
      // reply_now = verifyErrorMaskForSlave(*(__packed uint64_t*)(buffer + 3), *(u32*)(buffer + 11));
      // reply_now = verifyErrorMaskForSlave(*(uint64_t*)(buffer + 3), *(u32*)(buffer + 11));
      break;
  case I2CMSG_SYNC_NOTIFY:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_SYNC_NOTIFY");}
      //4.2.5. I2CMSG_SYNC_NOTIFY (SY+x) is acked after forwarding SY+x to camera and call to shutterOnSYFromMaster
      //(however forwarded SY+x may remain in I2C queue for a while).


      // shutterOnSYFromMaster(param);
      //Note that we must send ACK to master after we called shutterOnSYFromMaster()
      //When master get ACK from all slaves, it will call array_sy_sr_state_machine(SYSR_GotSYReply, 0);
      //This is equivalent to I2C sequence: 
      //- SY+x from master to slave
      //- shutterOnSYFromMaster() on slave
      //- SY+x reply from slave to master
      //- master call array_sy_sr_state_machine(SYSR_GotSYReply, 0);
      break;
  case I2CMSG_FPGA_DONE:
      DEBUG_printf("INFO: last slave ready, can begin (%c%c)", buffer[0], buffer[1]);
      // reply_now = fpga_done_received (buffer);

    break;
  case I2CMSG_FPGA_RESET_ID:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_FPGA_RESET_ID");}
    reply_now = BROADCAST_REPLY_NO;
    DEBUG_printf("WARNING: Lost slave wants re-enumeration");
    // !@# This was for duplicate master, make it work new node
    // node_id_second_primary_detected();

    // array_last_slave_ready_clear();
    // if (buffer[4] == 3)
      // node_id_set_node_count(0);
    if ((buffer[4] == 3))
    {
      u16 ack_mask_array[] = {
        0x0000, 
        0x0000, 0x0002, 0x0006, 0x000e, 
        0x001e, 0x003e, 0x007e, 0x00fe,
        0x01fe, 0x03fc, 0x07fe, 0x0ffe,
        0x1ffe, 0x3ffc, 0x7ffe, 0xfffe,
      };
      ack_mask = ack_mask_array[0];
    }
    break;


  case I2CMSG_ACK:
    if(snoop_bus && show_ak) { DEBUG_printf("SNOOP: I2CMSG_ACK from camera#%d state %d", buffer[3], buffer[6]);}
    // reply_now = ack_message_received(length, buffer);
    break;
  case I2CMSG_WAIT:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_WAIT");}
      //4.3.5. When a slave receives I2CMSG_WAIT command, it will turn both lines to NACK immediately.
      //If SR was recieved prior to I2CMSG_WAIT, then it is ACKed immediately.
      //Otherwise slave signal ACK after the appropriate SR is received from the camera.
      /*
      if(param == 3)
      {
          if(!array_got_sr3)
          {
              reply_now = BROADCAST_REPLY_NO;
              slave_sr_wait_ordinal = command_ordinal;
              slave_sr_wait_param = param;
          }
      }
      else
      {
          if(!array_got_sr012)
          {
              reply_now = BROADCAST_REPLY_NO;
              slave_sr_wait_ordinal = command_ordinal;
              slave_sr_wait_param = param;
          }
      }*/
      slave_waiter_ordinal = command_ordinal;
      if(slave_waitee_ordinal != param)
      {
          slave_waitee_ordinal_changed_tick = tickCount;
      }
      slave_waitee_ordinal = param;
      DEBUG_printf(" Br: wait %d %d", slave_waiter_ordinal, slave_waitee_ordinal);
      // if(!slave_check_wait_condition())//If return 1, then slave_send_ack was already called
      // {
        // //!@# Used to hold ack lines in NAK state until ready to ACK.
      // }
      return;//Do not call slave_send_ack below
  case I2CMSG_WAIT_RESULT:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_WAIT_RESULT");}
      DEBUG_printf(" Br: last wait res %d", slave_wait_last_response_success);
      reply_now = slave_wait_last_response_success == 1? 1 : 0;
      break;
  case I2CMSG_WAIT_RESULT_NEGATIVE:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_WAIT_RESULT_NEGATIVE");}
      DEBUG_printf(" Br: last wait res neg %d", !slave_wait_last_response_success);
      reply_now = slave_wait_last_response_success == 1? 0 : 1;
      break;
  case I2CMSG_BROADCAST_PING:
    if(snoop_bus && show_bp) { DEBUG_printf("SNOOP: I2CMSG_BROADCAST_PING");}
    if(global_status_i_am_primary)
    {
      DEBUG_printf("%c\r\nERROR: DETECTED ANOTHER PRIMARY",7 );
      #ifndef BOOTLOADER
      // node_id_second_primary_detected();
      // Could be the second master, ask the other masters to re-ID.
      // slave_send_request_id_restart(command, command_ordinal);
      #endif
    }
    if(!global_status_i_am_connected && !snoop_bus)
    {
       DEBUG_printf("\r\nERROR: DETECTED BROADCAST BEFORE ON BUS" );
      #ifndef BOOTLOADER
      // !@# Do I want to treat this as a Primary that needs to re-ID?  Probably not
      //node_id_second_primary_detected();
      //slave_send_ack(command, command_ordinal);
      #endif
    }
      break;
  case I2CMSG_ARRAY_DEBUG_COMMAND:
    if(snoop_bus && show_ad) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_DEBUG_COMMAND");}
      #ifdef DEBUG
      memcpy(&debug_params.header.length, buffer, sizeof(debug_params) - 1);
      debug_params.header.flags = 0;
      logTickCount = debug_params.master_tick_count;
      #endif
      break;   
  case I2CMSG_ARRAY_SET_TIMESTAMP:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_SET_TIMESTAMP");};
      arrayTimeStamp = *(u32*)(buffer + 3);
      DEBUG_printf(" Br: got timestamp %d", arrayTimeStamp);
      //Timestamp always preceed each capture
      syncReadyStartSeen = 0;
      syncReadyStopSeen = 0;
      syncReadyCaptureDone = 0;
      break;
  case I2CMSG_ARRAY_SET_POWER_OFF_CODE:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_SET_POWER_OFF_CODE");}
      arrayPowerOffCode = param;
      DEBUG_printf(" Br: arrayPowerOffCode %d", arrayPowerOffCode);
      break;
  case I2CMSG_YY_COMMAND:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_YY_COMMAND");}
      DEBUG_printf(" Br: got cmd YY grp %d api %d", buffer[6], buffer[7]);
      slave_wait_aborted_by_error = 0;//Forget all wair abort
      // app_i2c_SendCommandEnqueueEx(CHAN_PRIMARY, I2CMSG_YY_COMMAND, 
                          // buffer + 3, 
                          // length - 3,//Exclude command itself and crc
                          // CHF_FROM_BROADCAST,
                          // command_ordinal, //TODO: currently camera protocol does not use ordinals,
                            //so let's pass array ordinal just to be kept along with the message.
                            //if camera will have ordinal, this may change.
                          // 0,
                          // NULL
                          // );
      break;
  case I2CMSG_ZZ_COMMAND:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ZZ_COMMAND");}
      DEBUG_printf(" Br: got cmd ZZ %d %d", buffer[5], buffer[6]);
      slave_wait_aborted_by_error = 0;//Forget all wair abort
      // app_i2c_SendCommandEnqueueEx(CHAN_PRIMARY, I2CMSG_ZZ_COMMAND, 
                          // buffer + 3, 
                          // length - 3,//Exclude command itself and crc
                          // CHF_FROM_BROADCAST,
                          // command_ordinal, //TODO: currently camera protocol does not use ordinals,
                            //so let's pass array ordinal just to be kept along with the message.
                            //if camera will have ordinal, this may change.
                          // 0,
                          // NULL
                          // );
      break;
  case I2CMSG_ARRAY_CAM_VERS:
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_ARRAY_CAM_VERS");}
      // settingsPutArrayCamVersionInfoFromMaster(buffer + 3);
      break;
  case I2CMSG_BOOT_STORE_FC_CRC:
    if(snoop_bus) 
    {         
      u32 MastersCRC = *(u32*)(buffer + 3);
      DEBUG_printf("SNOOP: I2CMSG_BOOT_STORE_FC_CRC 0x%08x", MastersCRC);
    }
    else
  {
      DEBUG_printf("INFO: I2CMSG_BOOT_STORE_FC_CRC length %d = %d\n", length, *(u32*)(buffer + 3));
      if(length != sizeof(u32) + 3)//Include 2 byte cmd and ordinal
      {
          DEBUG_printf("Error: length %d != %d\n", length, sizeof(u32) + 2);
          reply_now = BROADCAST_REPLY_NO;
          break;
      }
      u32 MastersCRC = *(u32*)(buffer + 3);
      SET_STATUS_BIT(array_local_status, ASB_CRC_RECEIVED);
      if(MastersCRC == ((u32*)USER_END_ADDRESS)[-1])
      {
          DEBUG_printf("Got CRC 0x%x. Match", MastersCRC);
          SET_STATUS_BIT(array_local_status, ASB_CRC_MASTER_MATCH);
      }
      else
      {
          DEBUG_printf("Got CRC 0x%x != 0x%x", MastersCRC, ((u32*)USER_END_ADDRESS)[-1]);
          CLEAR_STATUS_BIT(array_local_status, ASB_CRC_MASTER_MATCH);
      }

  }
  break;

  case I2CMSG_BRST_CHECK_PREV_CMD://Already processed
    if(snoop_bus) { DEBUG_printf("SNOOP: I2CMSG_BRST_CHECK_PREV_CMD");}
      break;
  default:
    if(snoop_bus && show_uk) { DEBUG_printf("SNOOP: UNKNOWN");}
      if (show_uk) DEBUG_printf(" Br: Unknown command %c%c %d ord camera:%d", buffer[1], buffer[2], buffer[3], command_ordinal);
      break;
  } // switch(command)

} // I2CdecodeCommand

void decodePkt(unsigned char *buffer, int nchars)
{

#if 0
  s8 command_ordinal = check_crc_in_command(buffer, "Brst rx");//Return -1 on error, command ordinal on success
  //check_crc_in_command does not reduce the command length in buffer[0]
  if(command_ordinal == -1)
  {//Error already printed
      DEBUG_printf("Error: command_ordinal %d\n", command_ordinal);
      printf("Error: command_ordinal %d\n", command_ordinal);
      return;
  }
#endif // 0

  u8  length     = buffer[0] & 0x7f;//This excludes length itself, but includes crc
  u8  command_ordinal = buffer[length] & 0xF;
  u16 I2Ccommand    = *(u16*)(&buffer[1]);
  u8  param      = buffer[3];
  // if ((length==1) && (command_ordinal==0) && (show_uk==0)) // Ignore (dont show) empty I2Ccommands
  if ((command_ordinal==0) && (show_uk==0)) // Ignore (dont show) empty I2Ccommands
    return;
  switch(I2Ccommand)
  {
  case I2CMSG_BRST_GET_STATUS_BIT:
    if (!show_gs) {
      // printf("\n");
      return;
    }
    break;
  case I2CMSG_ACK:
    if (!show_ak) {
      // printf("\n");
      return;
    }
    break;
  default:
    break;
  }

  if (nchars <= 10) 
    printf("\t\t");
  else if ((nchars > 10)  && (nchars < 14))
    printf("\t");
  else if (nchars == 14) 
    printf("\t");
  if (nchars < 7) 
    printf("\t\t");
  else if (nchars == 7) 
    printf("\t");
  else if (nchars == 8) 
    printf("\t");

  // printf(" COMMAND:%c%c %2d  \tlen:%d \tord:%d plen:%2d ", buffer[1], buffer[2], buffer[3], length, command_ordinal,nchars);
  printf(" (%d) COMMAND:%c%c Param:%3d len:%d Ordinal:%d ", command_ordinal, buffer[1], buffer[2], buffer[3], length, command_ordinal);

  I2CdecodeCommand(buffer, I2Ccommand);
  printf("\n");

} /* decodePkt */

void printBuf(unsigned char *bptr, int nchars)
{
   int n;
   unsigned char *p = bptr;
   for (n=0; n < nchars; n++)
   {
     printf("%02x ", *p);
     // if ((n % 80) == 0)
       // printf("\n");
     p++;
   }
   // printf("\t");
   // printf("\n");
}


void all_packets_onoff(int onoff)
{
    show_ak=onoff;       // ak
    show_gs=onoff;         // gs
    show_bp=onoff; // BP
    show_ad=onoff; // AD
    show_uk=onoff; // UNKnown cmds
    printf("ALL packets turned %s\n", onoff ? "ON":"OFF");
}

// int show_ak=0;       // ak
// int show_gs=0;         // gs
// int show_bp=0; // BP
// int show_ad=0; // AD
void processArgs(int argc, char *argv[])
{
  int i;

  for (i = 1; i < argc; i++)  /* Skip argv[0] (program name). */
  {
      /*
       */

      if (strcmp(argv[i], "-all") == 0) 
      {
          all_packets_onoff(1);
      }
      else if (strcmp(argv[i], "-q") == 0) 
      {
          // surpress all packets
          all_packets_onoff(0);
      }
      else if (strcmp(argv[i], "-port") == 0) 
      {
          i++;
          strcpy((char *)serial_port, (const char*)argv[i]);  /* Convert string to int. */
      }
      else if (strcmp(argv[i], "-readbin") == 0) 
      {
          i++;
          strcpy((char *)readbin_file, (const char*)argv[i]);  /* Convert string to int. */
          readbin_flag = 1;
          nobin_flag   = 1;  // Turn off binary logging
          all_packets_onoff(1);
      }
      else if (strcmp(argv[i], "-h") == 0) 
      {
          usage();
      }

      /****** ON/OFF stuff *******/
      else if (strcmp(argv[i], "-ak") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          // toUpperCase(onoff);
          if (!strcmp(onoff, "on"))
            show_ak=1;
          else if (!strcmp(onoff, "off"))
            show_ak=0;
          else
            usage();
      }
      else if (strcmp(argv[i], "-gs") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          if (!strcmp(onoff, "on"))
            show_gs=1;
          else if (!strcmp(onoff, "off"))
            show_gs=0;
          else
            usage();
      }
      else if (strcmp(argv[i], "-bp") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          if (!strcmp(onoff, "on"))
            show_bp=1;
          else if (!strcmp(onoff, "off"))
            show_bp=0;
          else
            usage();
      }
      else if (strcmp(argv[i], "-ad") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          if (!strcmp(onoff, "on"))
            show_ad=1;
          else if (!strcmp(onoff, "off"))
            show_ad=0;
          else
            usage();
      }
      else if (strcmp(argv[i], "-uk") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          if (!strcmp(onoff, "on"))
            show_uk=1;
          else if (!strcmp(onoff, "off"))
            show_uk=0;
          else
            usage();
      }
      else if (strcmp(argv[i], "-bin") == 0) 
      {
          i++;
          strcpy((char *)onoff, (const char*)argv[i]);  /* Convert string to int. */
          if (!strcmp(onoff, "on"))
            nobin_flag=0;
          else if (!strcmp(onoff, "off"))
            nobin_flag=1;
          else
            usage();
      }
  }
} // processArgs

void printOptions()
{
  printf("\nOptions:\n");
  if (!readbin_flag)
  {
    printf("SERIAL PORT \t: %s\n"    , serial_port);
    printf("BINARY LOG \t: %s\n"     , binfile);
  }
  else
    printf("BINARY LOG (reading)\t: %s\n"     , readbin_file);
  printf("ACK \t\t: %s\n"          , show_ak       ? "ON":"OFF");
  printf("GET-STATUS \t: %s\n"     , show_gs       ? "ON":"OFF");
  printf("BROADCAST-PING \t: %s\n" , show_bp       ? "ON":"OFF");
  printf("ARRAY-DEBUG \t: %s\n"    , show_ad       ? "ON":"OFF");
  printf("Unknown-cmds \t: %s\n"   , show_uk       ? "ON":"OFF");
  printf("Binary file logging \t: %s\n"   , nobin_flag       ? "OFF":"ON");
  printf("\n");
  sleep(3);
} // printOptions

void usage()
{
  printf("\nusage:\n");
  printf("\t-h               : print usage\n");
  printf("\t-port    <dev>   : set serial port (default is %s)\n", DEFAULT_PORT);
  printf("\t-readbin <file>  : read a binary log file INSTEAD of the serial port\n");
  printf("\t-all             : show *all* messages. Note: Can be combined with \"off\" options\n");
  printf("\t-q               : quiet all optional messages (this is the default). Note: Can be combined with \"on\" options\n");
  printf("\n");
  printf("\t-ak <on/off>     : show/hide ACK messages\n");
  printf("\t-gs <on/off>     : show/hide GET-STATUS messages\n");
  printf("\t-bp <on/off>     : show/hide BROADCAST-PING messages\n");
  printf("\t-ad <on/off>     : show/hide ARRAY-DEBUG messages\n");
  printf("\t-uk <on/off>     : show/hide Unknown-command messages\n");
  printf("\t-bin <on/off>    : enable/disable binary file logging\n");
  printf("\n");
  exit(1);
}

char *getFileDate(char *fdate)
{
  // equivalent to: system("date +%d%b%y_%H%M");
  char *cmd= "date +%d%b%y_%H%M";
  FILE *fp = popen(cmd, "r");

  fgets(fdate,20,fp);
  chomp(fdate);
  pclose(fp);
  // printf("fdate=%s\n", fdate);
  return fdate;
}

void chomp(const char *s)
{
  char *p;
  while (NULL != s && NULL != (p = strrchr(s, '\n'))){
    *p = '\0';
  }
} /* chomp */

int createBinaryFile(char *bfile)
{
   int fd = open(bfile,  O_CREAT | O_RDWR, 0666);
   if (fd < 0)
   {
      char msg[80];
      sprintf(msg,"Error opening %s", bfile);
      perror(msg);
      exit(1);
   }
   return fd;
} // createBinaryFile

void set_term_misc(int fd)
{
  struct termios2 tio;

  // c_iflag flag constants:
  // IGNBRK Ignore BREAK condition on input.

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("IGNBRK=%d\n", tio.c_iflag & IGNBRK);
  printf("IGNPAR=%d\n", tio.c_iflag & IGNPAR);
  printf("\n");

  // SET
  tio.c_iflag |=  IGNBRK | IGNPAR;
  ioctl(fd, TCSETS2, &tio);

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("IGNBRK=%d\n", tio.c_iflag & IGNBRK);
  printf("IGNPAR=%d\n", tio.c_iflag & IGNPAR);
  printf("\n");
  sleep(2);

}

void set_term_raw(int fd)
{
  struct termios2 tio;
  struct termios2 *termios_p = &tio;

  ioctl(fd, TCGETS2, &tio);
  termios_p->c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP
                 | INLCR | IGNCR | ICRNL | IXON);
  termios_p->c_oflag &= ~OPOST;
  termios_p->c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
  termios_p->c_cflag &= ~(CSIZE | PARENB);
  termios_p->c_cflag |= CS8;

  ioctl(fd, TCSETS2, &tio);
  printf("TERMINAL *RAW* mode is set\n");
  sleep(1);

} // set_term_raw

void set_term_speed(int fd)
{
  struct termios2 tio;

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("CBAUD=%d\n", tio.c_cflag & ~CBAUD);
  printf("ispeed=%d\n", tio.c_ispeed);
  printf("ospeed=%d\n", tio.c_ospeed);
  // printf("\n");

  // SET
  tio.c_cflag &= ~CBAUD;
  tio.c_cflag |=  BOTHER;
  tio.c_ispeed = 115200;
  tio.c_ospeed = 115200;
  ioctl(fd, TCSETS2, &tio);

  // GET verify
  ioctl(fd, TCGETS2, &tio);
  printf("CBAUD=%d\n", tio.c_cflag & ~CBAUD);
  printf("ispeed=%d\n", tio.c_ispeed);
  printf("ospeed=%d\n", tio.c_ospeed);
  // printf("\n");


} // set_term_speed

void set_term_size(int fd)
{
  struct termios2 tio;
  printf("TERM SIZE:\n");

  // GET
  ioctl(fd, TCGETS2, &tio);
  printf("~CSIZE=%d\n", tio.c_cflag & ~(CSIZE | PARENB));
  printf("CSIZE=%d\n", tio.c_cflag & (CSIZE | PARENB));
  // printf("\n");

  // SET
  tio.c_cflag &= ~(CSIZE | PARENB);
  tio.c_cflag |= CS8;
  // tio.c_cflag |= CS7;
  ioctl(fd, TCSETS2, &tio);

  // GET verify
  ioctl(fd, TCGETS2, &tio);
  printf("~CSIZE=%d\n", tio.c_cflag & ~(CSIZE | PARENB));
  printf("CSIZE=%d\n", tio.c_cflag & (CSIZE | PARENB));
  // printf("\n");



} // set_term_size

int main (int argc, char *argv[])
{

   char fdate[80];
   bzero(fdate,80);
   bzero(onoff,5);
   getFileDate(fdate);
   sprintf(binfile, "argus-%s.bin", fdate);
   // # of write operations to binary file log.
   // Used for flushing (fsync) of the file in case we control-C this program
   int binwrites=0; 

   strcpy(serial_port, DEFAULT_PORT);

   processArgs(argc, argv);
   printOptions();

   char *infile = serial_port;

   if (readbin_flag)
     infile = readbin_file;

   int fd = open(infile,  O_RDONLY);
   if (fd < 0)
   {
      char msg[80];
      sprintf(msg,"Error opening %s", infile);
      perror(msg);
      exit(1);
   }
   if (readbin_flag==0)
   {
     // Set serial port settings
     set_term_misc(fd);
     set_term_speed(fd);
     set_term_size(fd);
     set_term_raw(fd);
   }

   // printf("sleeping 3 seconds\n");
   // sleep(3);

   printf("begin!\n");
   int bfd=0;
   if ((readbin_flag==0) || (nobin_flag==0))
     bfd = createBinaryFile(binfile);

   unsigned char *buf = (unsigned char *)malloc(BSZ);
   bzero(buf,BSZ);

   int nread;
   int nwrite;
   unsigned char *p;
   unsigned char *p0;
   int n;
   int berrors=0;
   int nerrors=0;

   while(1)
   {
     bzero(buf,BSZ);
     p = buf;
     n = 0;
     nread = 0;
     do 
     {
       n = read(fd, p, 1);
       if (n > 0)
       {
         nread++;
         p0 = p;
         p++;
       }
       else if (readbin_flag)
       {
         printf("n=%d (%d)\n", n, nerrors);
         nerrors++;
         sleep(1);
         if (nerrors > 0)
         {
           printf("\nDONE READING BINARY FILE %s\n\n", readbin_file);
           exit(0);
         }
       }
     } while ( (*p0 != 0) && (nread < BSZ));
     if (buf[0] != 0xff)
       offset = 0;
     else
       offset = 1;

     u16 command    = *(u16*)(&buf[offset+1]);
     if (printThisCommand(command, buf+offset, nread-offset))
     {
       printBuf(buf, nread);
       decodePkt(buf+offset, nread-offset);
     }

     // BINARY-FILE
     if ((readbin_flag==0) && (nread > 0) && (bfd > 0) && (nobin_flag==0))
     {
       nwrite = write(bfd, buf, nread);
       if (nwrite < 0)
       {
         berrors++;
         if (berrors < 100)
         {
           perror("ERROR writing to binary file");
           printf("ERROR writing to file bfd=%d, binfile=%s\n", bfd, binfile);
         }
       }
       binwrites++;
       if (! (binwrites % 10))
         fsync(bfd);              // FLUSH the output to the binary log file
     } // nread > 0

   } // while 1
   if (bfd > 0)
     close(bfd);
   exit(0);
} // main
