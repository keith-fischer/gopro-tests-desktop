

#PCMD="ps ax | grep camlog | grep -v grep | grep -v vi"
#$PCMD
ps ax | grep camlog
campids=`ps ax | grep camlog | grep -v grep | grep -v vi | awk '{print $1}'`
echo campids=$campids
K="kill -9 $campids"
echo "KILLING all camlogs..."
echo $K
$K
echo "Check.."
ps ax | grep camlog
# $PCMD
echo ""
