
/**
*****************************************************************************
* $Id$
* @file app_i2c_protocol.h
* @brief
* Provides application-level I2C interface functions  
* 
* @section COPYRIGHT
*  Unpublished Copyright (c) 2014 GoPro, Inc., All Rights Reserved.
*
*  GoPro, Inc. ("GoPro") CONFIDENTIAL
*
*  NOTICE: All information contained herein is, and remains the property of
*  GoPro. The intellectual and technical concepts contained herein are
*  proprietary to GoPro and may be covered by U.S. and Foreign Patents, patents
*  in process, and are protected by trade secret or copyright law.
*  Dissemination of this information or reproduction of this material is
*  strictly forbidden unless prior written permission is obtained from GoPro.
*  Access to the source code contained herein is hereby forbidden to anyone
*  except current GoPro employees, managers or contractors who have executed
*  Confidentiality and Non-disclosure agreements explicitly covering such
*  access.
*
*  The copyright notice above does not evidence any actual or intended
*  publication or disclosure of this source code, which includes information
*  that is confidential and/or proprietary, and is a trade secret, of GoPro.
*  ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
*  DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
*  CONSENT OF GOPRO IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
*  AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
*  AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
*  DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
*  THAT IT MAY DESCRIBE, IN WHOLE OR IN PART.
*
*****************************************************************************
*/
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_I2C_PROTOCOL_H
#define __APP_I2C_PROTOCOL_H

/* Defines --------------------------------------------------------*/

// Herobus protocol I2C message types.  NOTE: little-endian byte swap
#define I2CMSG_GET_PROTOCOL_VER  ('v'+'s'*0x100)
#define I2CMSG_SET_SHUTTER       ('S'+'H'*0x100)
#define I2CMSG_GET_SHUTTER       ('s'+'h'*0x100)
#define I2CMSG_GET_CAM_VER       ('c'+'v'*0x100)
#define I2CMSG_GET_SETTINGS      ('s'+'e'*0x100)
#define I2CMSG_SET_SETTINGS      ('S'+'E'*0x100)
#define I2CMSG_GET_3D_SETTINGS   ('t'+'d'*0x100)
#define I2CMSG_SET_3D_SETTINGS   ('T'+'D'*0x100)
#define I2CMSG_SET_AUDIO_IN      ('A'+'I'*0x100)
#define I2CMSG_SET_USB_MODE      ('U'+'M'*0x100)
#define I2CMSG_SET_PING          ('P'+'I'*0x100)
#define I2CMSG_SET_POWEROFF      ('P'+'W'*0x100)
#define I2CMSG_SET_AUTO_OFF      ('A'+'O'*0x100)
#define I2CMSG_SET_VID_RES_OLD   ('V'+'R'*0x100)
#define I2CMSG_SET_VID_RES       ('V'+'V'*0x100)
#define I2CMSG_SET_VID_OUT       ('V'+'O'*0x100)
#define I2CMSG_SET_CAM_MODE      ('C'+'M'*0x100)
#define I2CMSG_SYNC_NOTIFY       ('S'+'Y'*0x100)
#define I2CMSG_SYNC_READY        ('S'+'R'*0x100)
#define I2CMSG_SET_LED_BLINK     ('L'+'B'*0x100)
#define I2CMSG_SET_BEEP_SOUND    ('B'+'S'*0x100)
#define I2CMSG_SET_FPS           ('F'+'S'*0x100)
#define I2CMSG_SET_FOV           ('F'+'V'*0x100)
#define I2CMSG_SET_PHOTO_RES     ('P'+'R'*0x100)
#define I2CMSG_SET_EXPOS_MODE    ('E'+'X'*0x100)
#define I2CMSG_SET_PHOTO_T_INTVL ('T'+'I'*0x100)
#define I2CMSG_SET_TIME_LAPSE_STYLE ('T'+'S'*0x100) //"TS" //D.L. 11/15/2013 Fix bug 16536
#define I2CMSG_SET_PIV_INTERVAL  ('P'+'N'*0x100)
#define I2CMSG_SET_LOOP_MODE     ('L'+'O'*0x100)
#define I2CMSG_SET_CONTIN_SHOTS  ('C'+'S'*0x100)
#define I2CMSG_SET_BURSTSEQ      ('B'+'U'*0x100)
#define I2CMSG_SET_PROTUNE_ON    ('P'+'T'*0x100)
#define I2CMSG_SET_OSD           ('D'+'S'*0x100)
#define I2CMSG_SET_VMODE_PAL     ('V'+'M'*0x100)
#define I2CMSG_SET_WHITE_BAL     ('W'+'B'*0x100) //"WB"
#define I2CMSG_SET_FLIP_MIRROR   ('U'+'P'*0x100) //"UP" //D.L. 11/15/2013 Fix bug 16536
#define I2CMSG_SET_DEFAULT_MODE  ('D'+'M'*0x100) //"DM" //D.L. 11/15/2013 Fix bug 16536
#define I2CMSG_SET_PROTUNE_COLOR ('C'+'O'*0x100) //D.L. 10/11/2013 Fix bug 15929
#define I2CMSG_SET_PROTUNE_GAIN  ('G'+'A'*0x100) //D.L. 10/11/2013 Fix bug 15929
#define I2CMSG_SET_PROTUNE_SHARPNESS ('S'+'P'*0x100) //D.L. 10/11/2013 Fix bug 15929
#define I2CMSG_SET_EV            ('E'+'V'*0x100) //D.L. 10/21/2013 Request from Ajay on 10/16/2013 5:59 PM to add "EV" setting command
#define I2CMSG_SET_TIMEDATE      ('T'+'M'*0x100)
#define I2CMSG_GET_WIFI_MODE     ('w'+'i'*0x100)
#define I2CMSG_SET_WIFI_MODE     ('W'+'I'*0x100)
#define I2CMSG_FAULT_NOTIFY      ('F'+'N'*0x100)
#define I2CMSG_SET_VIDEO_TIMING  ('V'+'T'*0x100)
#define I2CMSG_FWD_DELETE_LAST   ('D'+'L'*0x100)
#define I2CMSG_FWD_DELETE_ALL    ('D'+'A'*0x100)
#define I2CMSG_FWD_XS            ('X'+'S'*0x100)//D.L. 10/22/2013
#define I2CMSG_HEART_BEAT        ('H'+'B'*0x100)//D.L. 11/12/2013
#define I2CMSG_FIRMWARE_UPDATE   (0xFA+0xDD*0x100)

#define I2CMSG_ZZ_COMMAND        ('Z'+'Z'*0x100)
#define I2CMSG_YY_COMMAND        ('Y'+'Y'*0x100)
#define I2CMSG_XX_COMMAND        ('X'+'X'*0x100)

//*************** Hero4 command params ********************

// Separate Enums for ZZ and its internal commands
typedef enum {
	ZZ_INTERNAL_CMD=0,
	ZZ_I2C_SPEED_CMD,
	ZZ_CAMERA_READY,
	ZZ_FW_BUILD,
	ZZ_CAPABILITY=5
} ZZ_command_types;

typedef enum {
	ZZ_INTERNAL_CAM_COMPATIBLE=0,
	ZZ_INTERNAL_CAM_SYNC_READY,
	ZZ_INTERNAL_CAM_HEARTBEAT,
    ZZ_INTERNAL_CAM_POWER_OFF,
    ZZ_INTERNAL_CAM_SETUP_ERROR
} ZZ_Internal_command_types;

enum {
	MULTICAM_STATUS_IDLE=0,
	MULTICAM_STATUS_ENCODING,
};

enum {
	ESU_NOTREADY=0,
	ESU_READY=1
};

enum {
	MULTICAM_COMPATIBLE=0,
	MULTICAM_INCOMPATIBLE=1
};

typedef enum {
    BACPAC_MULTIHERO_I2C_SPEED_STANDARD = 0,
    BACPAC_MULTIHERO_I2C_SPEED_FAST,
    BACPAC_MULTIHERO_I2C_SPEED_FAST_PLUS,
    BACPAC_MULTIHERO_I2C_SPEED_HIGH,
    MAX_NUM_BACPAC_MULTIHERO_I2C_SPEED,
} Bacpac_speed_t;

typedef enum 
{
   HD1=0,HD2=1,Shores=2,Blacks=3,Todos=4, HERO4=13,CamUnknown=0xFF// Added HERO4 camera type 
} CameraModel_t;

typedef struct
{
    char ver[16];
} firmwareVer_t;

typedef struct
{
    char name[24];
} cameraName_t;

//*************** Hero4 command params end ********************

#ifdef BACPAC_3D_ARRAY
//#define I2CMSG_SET_SLAVE_ID     ('A'+'S'*0x100) //Master sends "AS 1" to the first slave, it sends "AS 2" to the second, etc.
/*
#define I2CMSG_ARRAY_PING       ('A'+'P'*0x100) //"AP" - Master sends AP periodically (usually once a second) 
                                                 //With one byte of payload with flags from ArrayPingCommandFlags.
                                                 //Last slave sends back AP reply with 2 byte payload with 
                                                 //status flags from ArrayPingReplyFlags. Each slave may update
                                                 //the status flags before resending the reply to its master.
*/                            
#define I2CMSG_ARRAY_CAM_VERS    ('A'+'V'*0x100) //Primary Master sends AV with Primary Camera version CamVerMsg_t 
                                                 //that it got from its attached camera and each slave compares 
                                                 //this version with version of its own attached camera. 
                                                 //Note that payload in I2CMSG_ARRAY_CAM_VERS is camVersion_t,
                                                 //not CamVerMsg_t as in response to "cv" command.

#define I2CMSG_ARRAY_DEBUG_COMMAND    ('A'+'D'*0x100)//Payload: struct DebugParams
#define I2CMSG_ARRAY_DEBUG_GET_VITALS ('G'+'V'*0x100)//Command: struct GetVitalsCommand
                                                     //Reply: struct GetVitalsCommand folowed by 0 or more struct LogRecord
#define I2CMSG_ARRAY_SET_TIMESTAMP    ('S'+'T'*0x100)//Payload: 4 bytes


#define I2CMSG_BROADCAST_PING    ('B'+'P'*0x100)
#define I2CMSG_ACK               ('a'+'k'*0x100)// Ack to ping
#define I2CMSG_FPGA_DONE         ('G'+'O'*0x100)// Last node ready
#define I2CMSG_FPGA_RESET_ID     ('R'+'E'*0x100)// Reset node IDs

#define I2CMSG_WAIT              ('W'+'W'*0x100)//Wait for some earlier command completion. Used on broadcast channel only.
                                                //Parameter: command ordinal to wait for.
#define I2CMSG_WAIT_RESULT       ('W'+'R'*0x100)//After wait get result of the previous wait. ACK if result is success.
#define I2CMSG_WAIT_RESULT_NEGATIVE ('W'+'r'*0x100)//After wait get result of the previous wait. ACK if result is failure.

#define I2CMSG_REBOOT_IN_BOOTLOADER ('B'+'L'*0x100)

#define I2CMSG_BRST_CHECK_PREV_CMD ('c'+'c'*0x100) //Input: struct CheckPrevCmdParam
    //Ack if slave received previous command with ordinal CheckPrevCmdParam.ordinal
    //at least CheckPrevCmdParam.min_rcvd_count number of times
struct CheckPrevCmdParam
{
    u8 ordinal;
    u8 min_rcvd_count;
};

/* //In this version we do not store settings
#define I2CMSG_BROADCAST_SETTINGS_SETUP ('s'+'S'*0x100)                                                
#define I2CMSG_BROADCAST_SETTINGS_VIDEO ('V'+'S'*0x100)
#define I2CMSG_BROADCAST_SETTINGS_PHOTO ('P'+'S'*0x100)
#define I2CMSG_BROADCAST_SETTINGS_MULTI_PHOTO ('M'+'S'*0x100)
*/
//#define I2CMSG_BROADCAST_VIDEO_RECORD_START ('R'+'S'*0x100)

#define I2CMSG_BRST_GET_STATUS_BIT   ('g'+'s'*0x100)

#define I2CMSG_ARRAY_GET_NO_ERROR_BIT   ('g'+'e'*0x100) //Master sends a bit from enum ArrayErrorBits.
                                                    //Each slave send ACK/Yes if it HAS NO such bit set.
                                                    //Each slave send ACK/No if it HAS such bit set.
                                                    //Master receives ACK/Yes if no slave have this bit or 
                                                    //  ACK/No if at least one slave has this bit
#define I2CMSG_ARRAY_GET_NO_ERROR_BIT_FOR_SLAVE  ('g'+'E'*0x100) //Master sends a bit from enum ArrayErrorBits and slave id.
                                                    //Slave with the given ID will send ACK/Yes if it has NO such bit set.
                                                    //Slave with the given ID will send ACK/No if it has such bit set.
                                                    //Other slaves will send ACK/Yes
#define I2CMSG_ARRAY_VERIFY_ERROR_MASK ('e'+'m'*0x100)//Master sends a 64 bit mask with bits from ArrayErrorBits.
                                                    //Each slave send ACK/Yes if it has NO bit set that are NOT in the mask.
                                                    //Each slave send ACK/No if it has such bit set.
                                                    //Master receives ACK/Yes if it have all slaves error bits, ACK/No otherwise.
#define I2CMSG_ARRAY_VERIFY_ERROR_MASK_FOR_SLAVE ('e'+'M'*0x100)//Master sends a 64 bit mask with bits from ArrayErrorBits and slave id.

#define I2CMSG_ARRAY_ENABLE_SLAVE_SELECT ('e'+'S'*0x100) //Slave with given ID (single byte payload) should select next slave

#define I2CMSG_ARRAY_SET_POWER_OFF_CODE  ('P'+'o'*0x100)//Payload: 1 byte

enum ArrayPingCommandFlags
{
    BBCF_Received = 1,//1 if slave received commands from master
    BBCF_DoPowerOn = 2,             //Need to power on SC
    BBCF_DoPowerOffBecausePCOff = 4,//Need to power off SC because PC is off
    BBCF_DoPowerOffBecauseSCNotPresent = 8,//Need to power off SC because some SC are missing
    BBCF_ResetCameraError = 0x10,
    BBCF_ResetSlaveID     = 0x20,
};

enum ArrayStatusBits
{
    ASB_IN_FW              = 0,//All slaves are in FW  mode(not in bootloader mode)
    ASB_CRC_MASTER_MATCH   = 1,//All slaves have CRC received and identical to the master's.
                               //(This implies ASB_CRC_RECEIVED)
    //If the first 2 bits are set, then master will skip the next group of bits (related to bootloader)
    
    ASB_IN_BOOTLOADER      = 2,//All slaves are in bootloader mode
    //ASB_CRC_RECEIVED will replace ASB_VersionNotVerified
    ASB_CRC_RECEIVED       = 3,//All slaves received CRC from master
    ASB_IN_FLASH_IDLE      = 4,//None of the slaves have flash upgrade operation in progress
    ASB_NoFWUpgradeErrors  = 5,//No slaves have FW upgrade errors. It is set by commands.c in bootloader
    ASB_LastBootloaderBit  = 5,
    //If ASB_IN_BOOTLOADER is set, master will skip the following bits until ASB_NO_STATUS_CHANGES
    
    ASB_NoErrors            = 6,//No slaves have any errors (including any other errors below)
    ASB_NoArrayCameraErrors = 7,//No slaves have any problems with cameras
    ASB_NoArrayBrstErrors   = 8,//No slaves have any problems in broadcast channel
    ASB_ErrorsAcked         = 9,//Master has a combined mask of all slave errors
    ASB_ErrorsDetailedAcked = 10,//Master knowns errors for each slave
    
    ASB_3DPending           = 11,//All slave nodes and our own node has 3D process pending
    ASB_3DOK               = 12,//All slave nodes and our own node has 3D mode on camera (it is possible to have camera error at the same time)
    ASB_GOT_CAM_VERSION    = 13,//All slaves got camera version from the master
    ASB_COMPARED_CAM_VERSION = 14,//All slaves received camera version from their cameras and compared with master's
    ASB_CAM_VERSION_OK     = 15,//All slaves have camera versions identical to the master
    //D.L. 4/14/2014 Disable this: ASB_NO_SETTINGS     = 0x40,//None of the slaves have settings
    ASB_CAMERA_PW_ON      = 16,//All cameras powered on (pin 24)
    ASB_CAMERA_PW_OFF     = 17,//All cameras powered off (pin 24)
    ASB_CAMERA_PRESENT    = 18,//All slaves have camera present (and have batteries)
    ASB_HAS_ID            = 19,//All slaves have IDs assigned
    ASB_HAS_NO_ID         = 20,//No slave have ID assigned
    ASB_CAPTURE_DONE      = 21,
   
    //The following must be the last bit
    ASB_NO_STATUS_CHANGES = 22,//Status word remained unchanged since bit #0 was sent
        //ASB_NO_STATUS_CHANGES is sent by master after it accepted previous bits

    NUM_STATUS_BITS = 23
};

//Let's detect camera failure to send the expected commands:
enum ArrayErrorBits
//Make sure to update const char * arrayErrorNames[] when changing this enum
{
    AE_FirstCameraError = 0,
    
    //These are errors sent by camera and are a part of protocol:
    AE_CamSDFull = AE_FirstCameraError,//0
    AE_CamSDRemoved,//1
    AE_CamSDError,  //2
    AE_CamOvertemp, //3
    AE_CamLowBatt,  //4
    
    //These errors are not reported by camera, but we will report them to camera
    AE_CamNoHearbeat,    //5
    AE_CamIncompatible,  //6
    AE_CamBatteryRemoved,//7
    
    AE_FirstCameraProtocolError,
    //Protocol errors should not happen once camera is fixed. 
    //They are not a part of protocol, so we cannot report them to camera (other than a generic array error).
    //We use them to track them for logging/debugging
    //and also to turn on red camera LED.
    //AE_CamProtocolError is set if any of the below protocol errors is set.
    //But it can be also set alone in case of a generic protocol error
    AE_CamProtocolError = AE_FirstCameraProtocolError,//8
    AE_CamNoActivity,          //9
    AE_CamNoEEPROMRead,        //10
    AE_CamNoReady,             //11
    AE_CamNoFwUpgrResp,        //12
    AE_CamNoSpeed,             //13
    AE_CamNoBuildResponse,     //14
    AE_CamNoCompatibleResponse,//15
    AE_CamNoGuriResponse,      //16
    AE_CamNoESNCommand,        //17
    AE_CamNoESNResponse,       //18
    AE_CamNoSetupSettings,     //19 //PC: no incoming YY, SC: no response to YY
    AE_CamNoVideoSettings,     //20 //PC: no incoming YY, SC: no response to YY
    AE_CamNoPhotoSettings,     //21 //PC: no incoming YY, SC: no response to YY
    AE_CamNoMultishotSettings, //22 //PC: no incoming YY, SC: no response to YY
    AE_CamNoStartResponse,     //23 //SC only
    AE_CamNoStopResponse,      //24 //SC only
    AE_CamNoSyncReadyStart,    //25
    AE_CamNoSyncReadyStop,     //26
    AE_CamNoYYResponse,        //27
    AE_LastCameraError = AE_CamNoYYResponse,
    
    AE_ArrayDidNotSend,        //28 //This is array's responsibility to send this
    AE_ArrayError,             //29
    
    AE_Terminal,               //30 //TODO: replace by slave ID assignment
    AE_AlwaysClear,            //31 //To ensure that this slave is responding. 
                                    //Slaves return ACK/Yes if error bit is clear, 
                                    //so slaves should always return ACK/Yes for AE_AlwaysClear
    
    AS_NoChanges,              //32
    AE_NumErrors,              //33
    AE_NoError = AE_NumErrors
    //Total number of flags less than 64
};//enum ArrayErrorBits
typedef uint64_t ErrorMask;

#define GET_BIT(bit) ( ((ErrorMask)1) << bit)
#define SET_STATUS_BIT(status, bit) status |= ( ((ErrorMask)1) << bit)
#define CLEAR_STATUS_BIT(status, bit) status &= ~( ((ErrorMask)1) << bit)
#define CHECK_BIT(status, bit) ( (status) & ( ((ErrorMask)1) << bit) )

#define CAMERA_SD_ERRORS (\
    GET_BIT(AE_CamSDFull) | \
    GET_BIT(AE_CamSDRemoved) | \
    GET_BIT(AE_CamSDError))

#define CAMERA_ERRORS_STOP_WORK (\
    GET_BIT(AE_CamProtocolError) | \
    GET_BIT(AE_CamBatteryRemoved) | \
    GET_BIT(AE_CamIncompatible) | \
    GET_BIT(AE_CamSDFull) | \
    GET_BIT(AE_CamSDRemoved) | \
    GET_BIT(AE_CamSDError) | \
    GET_BIT(AE_CamOvertemp) | \
    GET_BIT(AE_CamLowBatt))

#define CAMERA_ERRORS_ALL \
    ((GET_BIT(AE_LastCameraError + 1) - 1) & ~(GET_BIT(AE_FirstCameraError) - 1))
#define CAMERA_PROTOCOL_ERRORS_ALL \
    ((GET_BIT(AE_LastCameraError + 1) - 1) & ~(GET_BIT(AE_FirstCameraProtocolError) - 1))


/*
#pragma pack(1)
struct ArraySendErrors //Payload for I2CMSG_ARRAY_SEND_ERRORS
{
    u8 firstSlaveIdx;
    u8 lastSlaveIdx;
    u32 errors[1];//errors for slaves starting with firstSlaveIdx and ending with lastSlaveIdx
};
#pragma pack()
*/
enum ArrayDebugFlags
{
    ADF_LOG_SILENT = 1,
    ADF_I2C_LOG_VERBOSE_PORT1 = 8,
    ADF_I2C_LOG_VERBOSE_PORT23 = 0x10,
    ADF_LOG_TIMER_PARAMS   = 0x20,
	 ADF_LOG_BROADCAST      = 0x40,
    ADF_NO_DEBUG_LED       = 0x40,
    ADF_NO_LED             = 0x80,
};

enum ArrayDebugCommands
{
    ADC_LOG_PRINT_STATS = 1,
    ADC_LOG_RESET_STATS = 2,
    ADC_TEST_SLEEP_LOOP = 3,
};

enum CommandHeaderFlags
{
    CHF_CRC_ADDED = 1,
    CHF_FROM_BROADCAST = 2,
    CHF_NEED_RESPONSE = 4
};

#pragma pack(1)
struct CommandHeader
{
    u8 flags; //Flags from enum CommandHeaderFlags: We do not send this byte, but keep it in RAM
    u8 size;//Space allocated for this command including struct CommandHeader and following data
    u8 length;//This is the first byte to be sent. It contains the number of bytes sent excluding this length byte itself.
    u16 commandCode;
};
struct Response
{
   u16 incomingMessage;//This is the message that we are replying to (for logging only)
   u8  incomingMessageOrdinal;
   u8  param1;//Param of that message (for logging only)
   u8  param2;//Param of that message (for logging only)
   struct CommandHeader command;
   u8  data[1];
};
struct DebugParams
{
    struct CommandHeader header;
    u8 flags;//From enum ArrayDebugFlags
    u8 debug_command;//From enum ArrayDebugCommands
    u32 master_tick_count;
    //Since we send DebugParams through both I2C and broadcast channel that normally use different ordinal algos,
    //lets have a special orginal values in DebugParams to know when command params changed:
    u8 ordinal;//This is incremented when this structure changes
    u8 command_ordinal;//This is incremented when debug_command changes
    u8 crc_ord;//This is placeholder for regular I2C or Broadcast command ordinal/CRC
};

struct GetVitalsCommand //Used when sending I2CMSG_ARRAY_DEBUG_GET_VITALS command and reply
{
    struct CommandHeader header;
    u8 slave_id;
    u8 num_items;
    u8 dummy1;
    u8 dummy2;
    s32 start_idx;
    u8 crc_ord;
};

struct VitalsReplyHeader
{
    struct CommandHeader header;
    u8 slave_id;
    u8 num_items;
    s32 start_idx;
};

struct VitalsReply
{
    union {
        struct VitalsReplyHeader header;
        u8 data[255];
    };
};

#pragma pack(1)

#endif

#define CMD_FLAG 0x80 //D.L. This flag is set in the first byte of commands, but not in responses

//D.L. 11/21/2013 The following commands are for bootloader only. 
//To prevent errors they should be different from main commands above
//Commands have no parameters (unless specified).
//All commands (unless specified otherwise) return struct BootStandardResponse: 
//  BootStandardResponse has 2 bytes: length, status (where length == 1, status from enum BootloaderStatus)
//Some commands return more data, but second byte is always status from enum BootloaderStatus.
//If status == BS_Pending, then caller should either re-send the same command until returned status != BS_Pending.
//Or, if the original command is slow or has side effects (like I2CMSG_BOOT_ERASE_USER or I2CMSG_BOOT_FLASH_WRITE),
//then send I2CMSG_BOOT_GET_STATUS until returned status != BS_Pending.
#define I2CMSG_BOOT_GET_STATUS   ('G'+'S'*0x100)//Get Status. 
#define I2CMSG_BOOT_FLASH_INFO   ('F'+'I'*0x100)//Get flash info. Return: struct BootloaderFlashInfo. 
#define I2CMSG_BOOT_ERASE_USER   ('F'+'E'*0x100)//Erase user space flash memory (basically entire bacpac FW, excluding bootloader)
#define I2CMSG_BOOT_ERASE_PAGE   ('F'+'P'*0x100)//Erase flash pages. Input: struct BootloaderFlashErasePageParam
#define I2CMSG_BOOT_FLASH_WRITE  ('F'+'W'*0x100)//Write data to flash. 
    //Input: struct BootloaderFlashWriteHeader, data, struct BootloaderFlashWriteFooter
    //Where size of data is determined from the first byte of the command.
    //Size of data must be a multiple of 4 (to simplify flash writing and CRC calculation).
    //So, layout will be like: size, F, W, O0, O1, O2, O3, d0, d1, ... dn, C0, C1, C2, C3
    //But according to our I2C protocol, size must have 0x80 flag set because it is a command from camera to bacpac.
    //So, data size == (size & 0x7F) - 2 - sizeof(struct BootloaderFlashWriteHeader) - sizeof(struct BootloaderFlashWriteFooter)
    //The maximum data size == 116 bytes (0x7F - 2 - 4 - 4 == 117 bytes, but it must be a multiple of 4, so 116)
    //See BOOT_FLASH_WRITE_MAX_DATA_SIZE below
    //Note: it is sender's responsibility to ensure that flash is erased pior to I2CMSG_BOOT_FLASH_WRITE  
    //(either using I2CMSG_BOOT_ERASE_USER or I2CMSG_BOOT_ERASE_PAGE)
    //If CRC check fails, then BS_Error status will be set
//#define I2CMSG_BOOT_FLASH_READ   ('F'+'R'*0x100)//Read data from flash. Input: struct BootloaderFlashReadParam
    //Output: length, status, d0, d1, ... dn,   c0, c1, c2, c3. Where cx are CRC bytes. CRC covers data only.
    //Maximum data size: 248 bytes. See BOOT_FLASH_READ_MAX_DATA_SIZE below. (255 - 5 == 250, to make it a number of 4, so 248)
#define I2CMSG_BOOT_START_USER   ('U'+'B'*0x100)//User boot. Jump to main bacpac FW. 
    //If CRC is wrong, then error is returned and execution stays in the bootloader.

//Also bootloader supports I2CMSG_GET_PROTOCOL_VER "vs" command, but returns 0 for FW version.
//Note that unlike all other bootloader responses, "vs" does not contain status byte.

//Note that the last 4 bytes of the FW image is CRC.
//CRC is calculated using the same algo, as used by STM MCU with polynomial 0x104C11DB7.
//For sample code search for 0x04C11DB7 on site:st.com

#define I2CMSG_BOOT_DUMMY ('B'+'D'*0x100)//D.L. 2/5/2014 Used internally by FW. Never sent.
    //Can have any value except those used by other commands.
    
    
#ifdef BOOTLOADER
enum BootloaderStatus
{
    BS_Idle = 0,
    BS_Pending = 1,
    BS_Error = 2,
    BS_Busy = 3, //Cannot handle new command before previous finished
    BS_UnknownCommand = 4,
    BS_BadCommandParams = 5,
    BS_CRCMissmatch = 6
};
//The following data fields are little endian
struct BootStandardResponse
{
    uint8_t  length;//According to our normal response protocol first byte is number of bytes to follow
    uint8_t  status;//From enum BootloaderStatus
};

enum FlashVerification
{
    FV_Unknown = -1,
    FV_Bad = 0,
    FV_Good = 1,
};
struct BootloaderFlashInfo//Return from I2CMSG_BOOT_FLASH_INFO
{
    uint8_t  length;//According to our normal response protocol first byte is number of bytes to follow
    uint8_t  status;//From enum BootloaderStatus
    int8_t   FwVerification;//from enum FlashVerification
    int8_t   dummy;
    uint32_t UserFlashOffset;//Offset of user data in FW upgrade binary file. Caller should start sending
                             //data from this offset and send TotalUserFlashSize bytes
    uint32_t UserFlashSize;//bacpac FW size, excluding bootloader
    uint32_t ErasePageSize;
};
#endif //BOOTLOADER

struct BootloaderFlashErasePageParam//input for I2CMSG_BOOT_ERASE_PAGE
{
    uint32_t Offset;//Offset of the page (in bytes) in the user space flash memory (between 0 and TotalUserFlashSize)
                    //Must be a multiple of ErasePageSize
    uint32_t NumPages;//Number of pages to erase
};
struct BootloaderFlashWriteHeader//Start of input for I2CMSG_BOOT_FLASH_WRITE
{
    uint32_t Offset;//Offset of the data in the user space flash memory (between 0 and TotalUserFlashSize)
};
struct BootloaderFlashWriteFooter//End of input for I2CMSG_BOOT_FLASH_WRITE
{
    uint32_t Crc;//CRC must include struct BootloaderFlashWriteHeader as well as data
};
#define BOOT_FLASH_WRITE_MAX_DATA_SIZE 116
#define BOOT_FLASH_WRITE_MAX_DATA_SIZE_BROADCAST 112
#define BOOT_FLASH_READ_MAX_DATA_SIZE 248
struct BootloaderFlashReadParam//Input for I2CMSG_BOOT_FLASH_READ
{
    uint32_t Offset;//Offset of the data in flash memory (between 0 and UserFlashOffset + TotalUserFlashSize)
    uint32_t Size;//Number of bytes to return. (BOOT_FLASH_READ_MAX_DATA_SIZE == 250 bytes max).
                  //Size must be a multiple of 4 (to calculate CRC32)
};
//D.L. 11/21/2013 End of bootloader protocol

//DL: 6/20/2015 The commands/structures above are still used for FW upgrade of Array bacpac from camera via I2C.
//The commands below are for FW upgrade of ArrayV2 via broadcast. 
#define I2CMSG_BOOT_STORE_FC_CRC     ('F'+'c'*0x100)//Store master's FW CRC. Input: 32 bit CRC
#define I2CMSG_BOOT_PAGE_CHECK_ERASE ('F'+'C'*0x100)//Compare page CRC. If different - erase the page.
                                                    //Input: struct BootloaderFlashPageCheckEraseParam
//#define I2CMSG_BOOT_FLASH_WRITE  ('F'+'W'*0x100)//Write data to flash. - same as in I2C protocol - see above
//#define I2CMSG_BOOT_START_USER   ('U'+'B'*0x100)//User boot. Jump to main bacpac FW. 
struct BootloaderFlashPageCheckEraseParam
{
    struct BootloaderFlashErasePageParam Params;
    uint32_t Crc;//CRC of the desired data in this page (after FW upgrade is complete)
};

//These are codes for I2CMSG_FAULT_NOTIFY "FN" command 
/*
#define FAULTCODE_LOBAT          0x01 //FN+1
#define FAULTCODE_HITEMP         0x02 //FN+2
#define FAULTCODE_SDCARD_FULL    0x03 //FN+3
#define FAULTCODE_MODEL_MISMATCH 0x04 //FN+4
#define FAULTCODE_FWVER_MISMATCH 0x05 //FN+5
#define FAULTCODE_UNRESPONSIVE   0x06 //FN+6
*/

//D.L. The following fault codes are used by array slaves to report problems to master.
//They are not passed to camera:
/*
#define FAULTCODE_ARRAY_CAMERA_UNRESPONSIVE -1
#define FAULTCODE_ARRAY_CAMERA_SUDDEN_RESET -2
#define FAULTCODE_ARRAY_NO_CAMERA_ACTIVITY -3
#define FAULTCODE_ARRAY_NO_EEPROM_READ -4
#define FAULTCODE_ARRAY_NO_VS -5
#define FAULTCODE_ARRAY_BATTERY_REMOVED_IN_3D -6
#define FAULTCODE_ARRAY_WARNING_FN_DURING_CAPTURE -20
*/

#define USB_MODE_INTERNAL   0x00
#define USB_MODE_HEROBUS    0x02

#define AUDIO_INPUT_CAM     0x00
#define AUDIO_INPUT_HEROBUS 0x01

#define CVBS_OUT_CAM        0x00
#define CVBS_OUT_HEROBUS    0x01

/* Slave address 0x50 = ID PROM; 0x60 = commands */
#define OWN_ADDRESS1             0xC0
#define OWN_ADDRESS2             0xA0

#define NUM_I2C_SLAVE_ADDRS       2

/* To use the I2C at 400 KHz (in fast mode), the PCLK1 frequency (I2C peripheral
   input clock) must be a multiple of 10 MHz */
//#define I2C_SPEED               100000  /* Speed in Hz */

#define I2C_SPEED               400000 //D.L. 2/9/2014 Test max 400 KHz clock: note:it only afects master mode on port3
    //The MCU manual says that PCLK1 must be a multiple of 10 MHz,
    //but this is not exactly true. Read "I2C Fast Mode 400KHz" on st.com:
    //https://my.st.com/public/STe2ecommunities/mcu/Lists/cortex_mx_stm32/Flat.aspx?RootFolder=https%3a%2f%2fmy.st.com%2fpublic%2fSTe2ecommunities%2fmcu%2fLists%2fcortex_mx_stm32%2fI2C%20Fast%20Mode%20400KHz&FolderCTID=0x01200200770978C69A1141439FE559EB459D7580009C4E14902C3CDE46A77F0FFD06506F5B&currentviews=1605
    //Currently on STMF401 we have PCLK1 == HCLK == 84 MHz
    //On LA I saw clock period 2.5 us 1/0.0000025 == 400000
    //High pulse = 0.7 us, low = 1.8 us
    

#define ACTION_NONE             0xFF
#define ACTION_DISABLED         0xFD
#define ACTION_PENDING          0xFE
#define ACTION_PERIODIC         0xFC

#define STATE_OFF               0
#define STATE_ON                1

#define PROM_ID_REPEATS         4

#define I2C_RESPONSE_FAIL       1
#define I2C_RESPONSE_PASS       0


/* Exported types ------------------------------------------------------------*/
#ifdef BACPAC_3D_ARRAY
//typedef enum { CHAN_I2C1=0, CHAN_I2C2=1 , CHAN_I2C3=2 } chanI2C_t;
//D.L. 2/2/2014 Get rid of chanI2C_t because they duplicated enum  Ports:
enum Ports
{
    CHAN_PRIMARY   = 0,
    CHAN_SECONDARY = 1,
    CHAN_BROADCAST = 1,//On Master port2 queue is reused for broadcast
    CHAN_PORT_PLL  = 2
};
//#define NUM_I2C_CHANNELS          3
#define NUM_I2C_CHANNELS          1
#define NUM_CAMERA_CHANNELS       1
#define IS_CAMERA_CHANNEL(ch) (ch == CHAN_PRIMARY)
#define IS_SLAVE_CHANNEL(ch) (ch == CHAN_PRIMARY)
#define CAM_VERSION_SECONDARY 1
#else
//typedef enum { CHAN_I2C1=0, CHAN_I2C2=1 } chanI2C_t;
//D.L. 2/2/2014 Get rid of chanI2C_t because they duplicated enum  Ports:
enum Ports
{
    CHAN_PRIMARY   = 0,
    CHAN_SECONDARY = 1,
};
#define NUM_I2C_CHANNELS          2
#define NUM_CAMERA_CHANNELS       2
#define IS_CAMERA_CHANNEL(ch) (ch == CHAN_PRIMARY || ch == CHAN_SECONDARY)
#define IS_SLAVE_CHANNEL(ch) (ch == CHAN_PRIMARY || ch == CHAN_SECONDARY)
#endif

#endif // __APP_I2C_PROTOCOL_H
