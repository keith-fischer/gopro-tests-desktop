# fill-sd-card.rb
# Description: Fills an SD card up with standard video or timelapse pictures.
# Please note: This could take a while depending on how full the card already is!
# Process:
# 1) Using the --ip and --pc, or --serialdev flags, finds a camera.
# 2) Determines if we should be filling the card with pictures or video.
#    - Either --video or --photo must be specified as an argument to the tool.
#    - Failure to specifiy one, or specifying both, will print an error message and quit.
# 3) If doing video, will pick the highest supported res/fps/fov for that camera.
#    - No extra parameters need to be passed in for this to happen. It discovers the best ones.
# 4) If doing pictures, it'll try to do the largest pictures and smallest delays supported.
#    - A warning will display if the specified delay is not the best one supported.
# 5) The camera will then start capturing forever.
#    - We restart capturing every minute so we don't hit the file size limit.
#    - This also happens in timelapse mode, without causing any problems.
# 6) If the camera ever fails to do a new capture in step 5, the card is probably almost full.
#    - "The SD card might still have space for a few more pictures." - FW
# 7) Now just take pictures until the last image taken doesn't change, as a final check.
#    - If you have to take more than, say, 20, something is probably wrong.
# 8) At this point, we declare that the memory card is full. Mission accomplished.

require_relative '../libs/camera'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase # Yes, this tool is actually a test. It seemed easier.
  include TestUtils
  def initialize()
    super
  end # initialize

  def setup(options, is_photos)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @camera = tu_get_camera()
    set_options()
    @fill_with_photos = is_photos
    @camera.delete_all_media() # Don't question it.
    if @fill_with_photos
      setup_for_timelapse()
    else
      setup_for_video()
    end
  end # setup

  def setup_for_timelapse()
    set_tc_name("#{@test_file}_setup_for_timelapse")
    # Put camera in timelapse mode or fail.
    ret, msg = @camera.set_capture_mode("TIMELAPSE")
    (log_fail(msg); exit 1) unless ret
    # Get the best settings to use.
    res = get_best_timelapse_res()
    rate = get_best_timelapse_rate(res)
    # Warn if the user specified value isn't the best.
    if rate != @options[:multi_photo_timelapse]
      log_warn("A better timelapse rate than the one you specified is supported.")
    end
    # We're not going to use the specified value anyway.
    # Set those settings.
    # Set timelapse rate or fail.
    ret, msg = @camera.set_multi_photo_timelapse(rate)
    (log_fail(msg); exit 1) unless ret
    # Set timelapse resolution or fail.
    ret, msg = @camera.set_multi_photo_resolution(res)
    (log_fail(msg); exit 1) unless ret
    # Might want to do one quick capture here to ensure a last media exists.
    log_info("Camera is setup to fill SD card with pictures (#{res}, #{rate}).")
  end # setup_for_timelapse

  def setup_for_video()
    set_tc_name("#{@test_file}_setup_for_video")
    # Put camera in video mode or fail.
    ret, msg = @camera.set_capture_mode("VIDEO")
    (log_fail(msg); exit 1) unless ret
    # Get the best settings to use.    
    vm = "NTSC" # Coinflip to PAL? Does this matter?
    # Determine the best res, fps, and fov to use.
    res = get_best_video_res(vm)
    fps = get_best_video_fps(vm, res)
    fov = get_best_video_fov(vm, res, fps)
    # Set those settings.
    # So camera.rb defines this function as set_video_mode(vm,res,fps,fov).
    # But wifi_camera.rb and serial_camera.rb just call it set_video(vm,res,fps,fov).
    ret, msg = @camera.set_video(vm, res, fps, fov)
    (log_fail(msg); exit 1) unless ret
    # Might want to do one quick capture here to ensure a last media exists.
    log_info("Camera is setup to fill SD card with video (#{vm}, #{res}/#{fps}/#{fov}).")
  end # setup_for_video
 
  def runtest()
    # Variables used to report what we're doing properly.
    what_take = "video"
    what_mode = "video"
    what_media = "MP4"
    if @fill_with_photos
      what_take = "pictures"
      what_mode = "timelapse"
      what_media = "JPG"
    end
    set_tc_name("#{@test_file}_runtest_#{what_mode}")
    log_info("Please wait while your camera takes lots of #{what_take}...")
    # Keep track of the number of loops to stop it from being super boring.
    loop_count = 0
    # Do this forever (well, until the camera fails to capture something new).
    while true
      loop_count += 1
      # Remember details about the last media.
      last_hash = @camera.get_medialist(nil).last #get_last_media(what_media, hash=true)
      # Determine the estimated time until completion (in minutes).
      # As this value can vary, it is used for display only, and is not used for control logic.
      if @fill_with_photos # timelapse
        etuc = @camera.get_photos_avail() / 120.0
      else # video
        etuc = @camera.get_mins_avail()
      end # if
      # Capture a minute of video or timelapse.
      log_info("Camera now trying to record minute #{loop_count} of #{what_mode}.")
      log_info("Current estimated time until completion: ~#{etuc.to_i} minutes.") if etuc
      @camera.start_capture()
      sleep(60.0)
      @camera.stop_capture()
      # Get the details about the newer last media.
      new_hash = @camera.get_medialist(nil).last #get_last_media(what_media, hash=true)
      # Stop looping if nothing new was recorded.
      break if last_hash == new_hash
    end # while
    # Both modes also perform this final check in the same way.
    # This final check is probably redundant. Consider removing it?
    set_tc_name("#{@test_file}_final_check")
    log_info("Attempting to take a few more pictures to verify the card is full...")
    # Switch to camera mode or fail gracefully. This mode is no longer "PHOTO_SINGLE"!
    ret, msg = @camera.set_capture_mode("PHOTO")
    unless ret
      log_info("Final check couldn't happen because the camera failed to go into photo mode:")
      log_fail(msg)
      log_info("There's a pretty good chance that your card is full anyway, however.")
      exit 1
    end
    # Take more pictures until it stops taking more pictures.
    victory = false
    20.times do
      # If we've already failed to take a picture, great! Skip to end.
      next if victory
      # Get the last picture's info.
      last_hash = @camera.get_medialist(nil).last #get_last_media("JPG", hash=true)
      # Take a new picture. One second should be enough time.
      @camera.start_capture
      sleep(1.0)
      @camera.stop_capture
      # Get the new picture's info.
      new_hash = @camera.get_medialist(nil).last #get_last_media("JPG", hash=true)
      # Compare. If they are the same, no new picture was taken and the card is full.
#      puts "LAST HASH: #{last_hash}"
#      puts " NEW HASH: #{new_hash}"
#      puts "   VEDICT: #{ last_hash == new_hash }"
      if last_hash == new_hash
        victory = true
      end # if
    end # 100 times
    set_tc_name("#{@test_file}_final_report")
    log_pass("Your SD card seems to be full now. Congratulations. I'm done.") if victory
    log_fail("Your SD card might not be totally full. I'm sorry. Try again.") unless victory
    return victory
  end # runtest

  def cleanup()
  end # cleanup

  # The following functions could be useful in setting up for stress tests too, maybe.

  # Gets the highest supported timelapse resolution.
  def get_best_timelapse_res()
    all_res = @camera.get_photo_resolutions()
#    puts "TIMELAPSE RESOLUTIONS: #{all_res}"
    # Score each resolution to find the best one.
    best = nil
    best_val = 0
    all_res.each do |res|
      # Score is the number of mega pixels, plus 0.5 if you're a WIDE.
      # Basically, 12WIDE > 7WIDE > 7MED > 5MED.
      fov = res.gsub(/[0-9]/, "")
      num = res.gsub(/[A-Za-z]/, "").to_f
      num += 0.5 if fov == "WIDE"
#      puts "#{res} scored #{num}"
      if num > best_val
        best_val = num
        best = res
      end # if
    end # each
#    puts "The best one is #{best}"
    return best if best
    log_warn("get_best_timelapse_res: Issue finding a resolution. Defaulting to 12WIDE.")
    return "12WIDE"
  end # get_best_timelapse_res

  # Gets the fastest supported timelapse rate.
  def get_best_timelapse_rate(res)
    all_rate = @camera.get_multi_photo_timelapse_rates(res)
#    puts "TIMELAPSE RATES: #{all_rate}"
    # Score the rates to find the best one.
    best = all_rate.min
#    puts "The best one is #{best}"
    return best if best
    log_warn("get_best_timelapse_rate: Issue finding a rate. Defaulting to 0.5.")
    return 0.5
  end # get_best_timelapse_rate

  # Gets the highest supported video resolution.
  def get_best_video_res(vm)
    all_res = @camera.get_video_resolution()
#    puts "VIDEO RESOLUTIONS: #{all_res}"
    # Score each resolution to find the best one.
    best = nil
    best_val = 0
    all_res.each do |res|
      # WVGA scores a 1. Ones with K in them get score * 1000.
      # _SUPER and _JS do not add any bonus to scores.
      res_str = res.gsub(/WVGA/,"1").gsub(/[_A-JL-Z]/,"")
      res_val = res_str.gsub(/[K]/, "").to_f
      res_val *= 1000 if res_str.include?('K')
#      puts "#{res} scored #{res_val}"
      if res_val > best_val
        best_val = res_val
        best = res
      end # if
    end # each
#    puts "The best one is #{best}."
    return best if best
    log_warn("get_best_video_res: Issues finding a resolution. Defaulting to 4K.")
    return "4K"
  end # get_best_video_res

  # Gets the highest supported video fps.
  # Do we need to check that the selected res/fps is supported by the vm?
  def get_best_video_fps(vm, res)
    all_fps = @camera.get_video_fps(res)
#    log_info("VIDEO_FPS: #{all_fps}")
    # Score each fps to find the best one.
    best = all_fps.max
#    puts "The best one is #{best}"
    return best if best
    log_warn("get_best_video_fps: Issues finding a fps. Defaulting to 30.")
    return 30
  end # get_best_video_fps

  # Gets the highest supported video fov.
  def get_best_video_fov(vm, res, fps)
    all_fov = @camera.get_video_fov(res, fps)
#    log_info("VIDEO_FOV: #{all_fov}")
    # Score each fov to find the best one.
    # So anyway, this logic could be better.
    return "W" if all_fov.include?("W")
    return "M" if all_fov.include?("M")
    return "N" if all_fov.include?("N")
    log_warn("get_best_video_fov: Issues picking a fov. Defaulting to W.")
    return "W"
  end # get_best_video_fov

end # Test

# Execution starts here.
# Please note that, while this was written as a test, it's actually a tool.
# That said, the logic below is the expected use, not an example of use!
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new()
    args = ARGV
    if args.include?("--photo") and args.include?("--video")
      puts "You must specify EITHER --photo or --video, not both!"; exit 1
    end
    if args.include?("--photo")
      is_photos = true
      args.delete("--photo")
    elsif ARGV.include?("--video")
      is_photos = false
      args.delete("--video")
    else
      puts "You MUST specify either --photo or --video as a parameter!"; exit 1
    end
    use_options = [:ip, :pc, :serialdev,:video_resolution, :multi_photo_timelapse, :verb, :save_dir]
    options = t.parse_options(args, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options, is_photos)
    t.runtest()
    # If you want to re-run runtest, you may need to re-run setup first.
    # Oh well. This is a tool, not a test.
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
# Would require a powerstrip, which is asking a lot for a simple tool.
#    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end

