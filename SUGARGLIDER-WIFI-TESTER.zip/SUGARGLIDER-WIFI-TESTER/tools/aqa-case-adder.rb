# Used to easily add AQA Case field information to test cases.
# Why? Because I was doing it manually...
# And the video looping section is a nightmare...

# Plan of attack:
# 1) Prompt for Project. (Like "(FWQA) STREAKY")
# 2) Find that Project, get a list of Plans. (Like "AQA Review 001")
# 3) Select a plan.
# 4) Find that plan, get a list of Runs. ("Function - Looping - NTSC")
# 5) Withing that plan is a list of tests.
# 6) pick out the tests that are marked Fully Automatable.
# 7) Pick out the ones that have no AQA Case.
# 8) Iterate over them, smartly suggesting a value.
# 9) Add those AQA case values.

require_relative '../libs/testrail'

def guess_pnl_res(r)
  r.chomp!
  r.strip!
  return "12WIDE" if r == "12 MP Wide"
  return "7WIDE" if r == "7 MP Wide"
  return "7MED" if r == "7 MP Medium"
  return "5MED" if r == "5 MP Medium"
  puts "UNABLE TO GUESS RES!"
  puts "Please enter a value instead [12WIDE|7WIDE|7MED|5MED]:"
  in_r = gets.chomp.strip
  return in_r
end

def guess_pnl_interval(r)
  r.chomp!
  r.strip!
  return "CONTINUOUS" if r == "Interval Continuous"
  return "4" if r == "Interval 4 sec"
  return "5" if r == "Interval 5 sec"
  return "10" if r == "Interval 10 sec"
  return "15" if r == "Interval 15 sec"
  return "20" if r == "Interval 20 sec"
  return "30" if r == "Interval 30 sec"
  return "60" if r == "Interval 60 sec"
  return "120" if r == "Interval 2 min"
  return "300" if r == "Interval 5 min"
  return "1800" if r == "Interval 30 min"
  return "3600" if r == "Interval 60 min"
  puts "UNABLE TO GUESS INTERVAL!"
  puts "Please enter a value instead [some number]:"
  in_r = gets.chomp.strip
  return in_r
end

def guess_pnl_shutter(r)
  r.chomp!
  r.strip!
  return "AUTO" if r == "Shutter Auto"
  return "2"    if r == "Shutter 2 sec"
  return "5"    if r == "Shutter 5 sec"
  return "10"    if r == "Shutter 10 sec"
  return "15"    if r == "Shutter 15 sec"
  return "20"    if r == "Shutter 20 sec"
  return "30"    if r == "Shutter 30 sec"
end

def guess_res(r)
  r.chomp!
  sup = r.include?("uper") ? "_SUPER" : ""
  fs = r.include?("4:3") ? "_FS" : ""
  return "1440" + sup      if r.include?("1440")
  return "1080" + sup      if r.include?("1080")
  return "WVGA"            if r == "WVGA"
  return "720"  + sup      if r.include?("720")
  return "960"  + sup      if r.include?("960")
  return "2.7K" + sup + fs if r.include?("2.7")
  return "4K"   + sup      if r.include?("4K") or r.include?("4k")
  return "!!!_UNKNOWN_RES_!!!"
end   
  

puts "Hello. I am the helpful AQA Case field adder tool."
# Disabled! I don't want this tool misused...
puts "I am currently disabled. I don't know why you're trying to run me."
puts "Goodbye now! Have a nice day!"
exit 1
puts "You may need to edit my code to enable certain options!"
puts "To begin, I'll need to know the project you want to work with."
puts "Please enter a project."
in_project = gets.chomp.upcase
$Testrail = TestRail.new(nil)
projects = $Testrail.get_projects()
project = nil
projects.each { |proj|
  next if proj["name"].match("(?i)" + in_project) == nil
  next if proj["name"].match("FWQA") == nil
  project = proj
}
(puts "Couldn't find a matching project. Bail."; exit 1) unless project
puts "Cool. The project that matched was \"#{project["name"]}\""
puts "Next, I need to know which suite you're looking to work with."
puts "Please enter a suite."
in_suite = gets.chomp
suites = $Testrail.get_suites(project["id"])
suite = nil
suites.each { |suit|
  next if suit["name"].match(in_suite) == nil
  suite = suit
}
(puts "Couldn't find a matching suite. Bail."; exit 2) unless suite
puts "Cool. The suite that matched was \"#{suite["name"]}\""
puts "Let's see what cases we've got for you... Sit tight..."
cases = $Testrail.get_cases(project["id"], suite["id"])
(puts "No cases found. Are there any? Bail."; exit 3) unless cases
puts "Found #{cases.length} cases! Yeah!"
sections = $Testrail.get_sections(project["id"], suite["id"])
sec_name_by_id = {}
sections.each { |sec| sec_name_by_id[sec["id"]] = sec["name"] }
counter = 0
cases.each { |cas|
  counter += 1
  # Always skip ones that are already done.
#  (puts "Skipping #{cas["title"]} (#{cas["custom_aqa_case"]})"; next) if cas["custom_aqa_case"]

  # Also I'm limiting this to the photo night lapse ones...
#  next if cas["custom_aqa_script"] != "test_photo_night_lapse.rb"

  puts ""
  puts "Section: #{sec_name_by_id[cas["section_id"]]}"
  puts "##{counter}: C#{cas["id"]}: #{cas["title"]}"
  
#  doing_automation_status_update = false
  # I gave up on this section and just changed these manually...
#  if doing_automation_status_update
    # Look at all test cases in a section.
    # Switch the Automation field to "Automation Complete" if both the
    # AQA Script and AQA Case fields are populated with meaningful values.
#    if cas["custom_aqa_case"] != ""
#      if cas["custome_aqa+script"] != "" 
#        puts "#{cas["custom_automation_status"]} => 3"

#  end

  # PHOTO NIGHTLAPSE SECTION
  doing_photo_nightlapse = false
  if doing_photo_nightlapse
    shutter = guess_pnl_shutter( sec_name_by_id[cas["section_id"]] )
    r1, r2 = cas["title"].split("-")
    interval = guess_pnl_interval( r1 )
    res = guess_pnl_res( r2 )
    guess = res + "_" + interval + "_.*_shutter_" + shutter + "_.*"
    puts "#{guess}"
    post_data = {}
    post_data["custom_aqa_case"] = guess
    resp = $Testrail.update_case( cas["id"], post_data )
    # Well, that was pretty straight-forward...
  end

  # VIDEO LOOPING SECTION
  doing_video_looping = false
  if doing_video_looping
    vm, dur = sec_name_by_id[cas["section_id"]].split("-")
    vm = vm.chomp.strip
    dur = dur.gsub(/Minutes/,"")
    dur = dur.chomp.strip.upcase
  
    res, fps, fov = cas["title"].split("/")
    if fov == nil
      fov = "W" if fps.include?("W")
      fov = "N" if fps.include?("N")
      fov = "M" if fps.include?("M")
    end
    fps = fps.to_i.to_s # Strips FOV off.
    res = guess_res(res)
    puts "!!! LOOKOUT !!! Had trouble guessing the VM."  if vm == nil
    puts "!!! LOOKOUT !!! Had trouble guessing the RES." if res == nil
    puts "!!! LOOKOUT !!! Had trouble guessing the FPS." if fps == nil
    puts "!!! LOOKOUT !!! Had trouble guessing the FOV." if fov == nil

    # This line will cause ruby error if any values are nil.
    guess = vm + "_" + res + "_" + fps + "_" + fov + "_loop_" + dur + "min_.*"
    guessing_enabled = false
    if guessing_enabled
      puts "Press enter to accept this guess.. or type a new value first."
      puts "GUESS: #{guess}"
      new_value = gets.chomp
      guess = new_value if new_value != ""
    end
    puts "#{guess}"
    post_data = {}
    post_data["custom_aqa_case"] = guess
    resp = $Testrail.update_case( cas["id"], post_data )
  end
}

puts "All done! Clean exit! Bye!"
exit 0
