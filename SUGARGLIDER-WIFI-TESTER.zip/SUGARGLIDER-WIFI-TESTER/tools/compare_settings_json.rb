# Compare the settings json file between two different firmware versions,
# so we check the initial json object then perform an OTA update and check
# the json object after and list out the differences (if any) between
# the two settings json objects.

# For key value pairs in which the value is an array, it tends to not
# print nicely in terms of readability. This tool shows the different
# key/value changes in the json hash from before and after to allow
# the user view what has changed in the settings json hash.

# This tool can probably be improved upon, and I'm still in the learning
# stages of writing tools/tests/programming like this.
# Sorry if its ugly :)

require_relative '../libs/camera'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/installHandler.rb'

class Test < TestCase # Yes, this tool is actually a test.
  include TestUtils
  def initialize
    super
  end # initialize

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @camera = tu_get_camera
  end

  # Reads in the nested hash and returns a simplified(?) list of hashes
  def recursive_parse_hash(hash, list=[])
    hash.each do |key, val|
      # Manually setting these key/value hashes, since in each of these array hashes,
      # we have duplicated keys and values, so we need to compare as a whole(?)
      # Need to think of a better way to do this
      if ["settings", "commands", "options", "activated_by", "blacklist", "fields"].include?(key)
        h = Hash.new
        h[key] = val
        list << h[key]
      elsif val.instance_of?(Hash)
        recursive_parse_hash(val, list)
      elsif val.instance_of?(Array)
        newhash = Hash[val.each_index.zip(val)]
        recursive_parse_hash(newhash, list)
      else
        h = Hash.new
        h[key]=val
        list << h
      end
    end
    return list
  end

  # Method to compare two different JSON hashes, and print out the resulting differences
  def compare_settings_json(prevhash=nil, newhash=nil, do_ota=false)
    log_info("Getting initial settings json file")

    # If we cannot get the settings json, then try to get the current hash
    if !@camera.get_settings_json_hash
      log_error("error getting settings json")
    elsif prevhash.nil?
      prevhash = @camera.settings_json_hash
    end

    # If we still cannot get the JSON hash, then exit out
    if prevhash.nil?
      log_error("Error finding Initial JSON settings file")
      exit 1
    end

    # Perform ota update to fw file if specified
    if do_ota
      ret = ota_update
      if !ret
        log_error("Error doing OTA Update")
      end
    end

    log_info("Getting updated settings json file")

    if !@camera.get_settings_json_hash
      log_error("Error getting new settings json")
    elsif newhash.nil?
      newhash = @camera.settings_json_hash()
    end

    if newhash.nil?
      log_warn("Error getting Initial JSON settings file")
      exit 1
    end

    log_info("Parsing the two JSON files...")
    old_settings_parsed = recursive_parse_hash(prevhash)
    new_settings_parsed = recursive_parse_hash(newhash)

    diff = prevhash.to_a - newhash.to_a
    diff_tree = []
    diff.each do |key, val|
      diff_tree << key
    end
    if !diff_tree.empty?
      log_warn("Changes under these keys!!!")
      log_warn(diff_tree)
      log_warn("________________________")
      old_diff = old_settings_parsed.flatten - new_settings_parsed.flatten
      new_diff = new_settings_parsed.flatten - old_settings_parsed.flatten
      old_diff.zip(new_diff).each do |old_diff, new_diff|
          changed = old_diff.to_a - new_diff.to_a
          log_warn("OLD: #{old_diff} ===> NEW: #{new_diff} ===> CHANGED: #{changed.flatten}")
          log_warn("_________________")
      end
    end
  end

  def ota_update
    # Make sure .ota.zip is appended if necessary
    fw = @options[:fw_file]
    fw += ".ota" if fw.match(".ota") == nil
    fw += ".zip" if fw.match(".zip") == nil

    ih = InstallHandler.new(@camera, fw)
    log_info("Camera release of FW file: #{ih.fw_rel()}")
    log_info("Camera model of FW file: #{ih.fw_cam()}")
    log_info("Firmware version of FW file: #{ih.fw_ver}")

    log_info("Updating to FW version #{ih.fw_ver}")
    @camera.set_capture_mode("PHOTO")
    start = Time.now
    result = ih.do_ota_update(true)
    time_taken = Time.now() - start

    if result == true
      pass("Update successful in %0.2f seconds" %(time_taken))
      return true
    end
    return false
  end # ota_update

  def runtest
    # 1) Perform info command check(mDNS / bacpac/cv)
    set_tc_name("compare_settings_json")
    compare_settings_json(nil, nil, true)
  end

end # Test

# Execution starts here.
# Please note that, while this was written as a test, it's actually a tool.
# That said, the logic below is the expected use, not an example of use!
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :fw_file, :verb]
    options = t.parse_options(ARGV, use_options)
    options[:ip] = "10.5.5.9" if options[:ip] == nil
    options[:pc] = "goproher" if options[:pc] == nil
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera
  ensure
    t.cleanup if t != nil
    t.final_actions if t != nil
  end

end
