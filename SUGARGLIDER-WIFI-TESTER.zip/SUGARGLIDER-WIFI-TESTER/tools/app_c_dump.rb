require 'serialport'
require 'English'
require 'optparse'
require 'json'

class AppCDump

  attr_accessor :serial
  def initialize(port, baud)
    @serial = SerialPort.new(port)
    @serial.baud = baud
    @serial.read_timeout = 5000
  end

  def available_commands(prefix)
    cmds = []
    write_to_serial(prefix)
    output = read_from_serial
    output.each do |line|
      line = line.gsub(/(\r|\r\n|\x00|\n|a:\\>)/, '').strip
      next if line.empty? || (line == prefix)
      cmds << unless line.include?(prefix)
                "#{prefix} #{line}"
              else
                line
              end
    end
    cmds
  end

  private
  
  def read_from_serial
    @serial.readlines
  end

  def write_to_serial(cmd, delay = 2)
    @serial.write(cmd)
    @serial.write("\r\n")
    sleep delay
  end
end


def parse_options(args)
  options = {}
  opt_parse = OptionParser.new do |opts|
    opts.banner = 'Usage: t_api_dump options'
    opts.on('-b', '--baud BAUD', 'Baud Rate') do |baud|
      options[:baud] = baud.to_i
    end

    opts.on('-p', '--port PORT', 'Serial port e.g. /dev/ttyUSB1') do |port|
      options[:port] = port
    end

    opts.on('-h', '--help', 'Show help') do
      puts opts
      exit(true)
    end
  end 
  opt_parse.parse!(args)
  options
end

def validate_options(options)
  errors = []
  [:baud, :port].each do |opt| 
    unless options[opt]
      errors << "#{opt}"    
    end
  end 
  
  unless errors.empty?
    puts "Missing required arguments: #{errors.join(', ')}"
    abort
  end
end

if __FILE__ == $PROGRAM_NAME
  options = parse_options(ARGV)
  validate_options(options)
  appc = AppCDump.new(options[:port], options[:baud])
  cmds = appc.available_commands('t api')
  cmds_hash = {}
  cmds.each do |cmd|
    next if cmd.include?('t appc') || (cmd == 't api')
    cmds_hash[cmd] = [] unless cmds_hash[cmd]
    p "Command is #{cmd}"
    cmds_hash[cmd] = appc.available_commands(cmd)
  end
  cmds_hash['t appc'] = appc.available_commands('t appc')
  puts JSON.pretty_generate(cmds_hash)
end
