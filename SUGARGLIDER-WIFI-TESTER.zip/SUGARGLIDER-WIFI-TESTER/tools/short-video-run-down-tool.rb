# Short-video Battery Run-down tool
# A quick tool to capture short videos until a battery runs down

Shoes.setup {
  gem 'net-http-persistent'
  # gem 'timeout'
}

require 'net/http/persistent'
require 'json'

class Camera
  attr_reader :shutter_on, :shutter_off, :gotosleep
  def initialize(ip, pc, log)
    @ip = ip
    @pc = pc
    @log = log
    @dead_cam = false
    @http = Net::HTTP::Persistent.new("Camera@#{ip}")

    # Get camera MAC address (needed for Wake-on-LAN)
    resp = http_get("http://#{@ip}:80/bacpac/cv?t=#{@pc}")
    return nil if resp == nil or resp.code != "200"
    @mac = resp.body[12..17].unpack("H2"*6).join(":")
    resp = http_get("http://#{@ip}/gp/gpControl")
    return nil if resp == nil or resp.code != "200"
    @gpcontrol = JSON.parse(resp.body)

    @shutter_on = makeurl("command/shutter?p=1")
    @shutter_off = makeurl("command/shutter?p=0")
    @gotosleep = makeurl("command/system/sleep")

    log("MAC address: #{@mac.upcase}")
    return
  end

  def http_get(url)
    return nil if @dead_cam == true
    tries = 10
    n = 1
    log ("#{Time.now} \t #{url}")
    begin
      @http.open_timeout = 2
      @http.request(URI(url))
    rescue Timeout::Error,
      Errno::ECONNRESET,
      Errno::EHOSTUNREACH,
      Errno::EHOSTDOWN,
      Errno::ECONNREFUSED,
      Errno::ENETUNREACH,
      Net::HTTP::Persistent::Error => e
      if n < tries
        n += 1
        retry
      else
        log("HTTP error (#{e.to_s})")
        @dead_cam = true
      end  
    rescue StandardError => e
      log("OTHER ERROR => #{e.to_s}")
      @dead_cam = true
    end
  end

  def makeurl(s)
    return "http://#{@ip}/gp/gpControl/#{s}"
  end

  # system_busy
  # encoding_active
  def get_status(key, refresh=true)
    if refresh
      resp = http_get(makeurl("status"))
      return nil if resp == nil or resp.code != "200"
      begin
        @status = JSON.parse(resp.body)
      rescue StandardError => e
        log("Error Parsing Status JSON (#{e.message})")
        return nil
      end
    end
    fields = index = nil
    fields = @gpcontrol["status"]["groups"].map { |m|
      m["fields"] if m["group"] == "system"
    }
    return nil if fields == nil
    index = fields[0].map { |m| m["id"] if m["name"] == key }
    index = index.compact[0].to_s
    if index == nil or index.empty?
      log("No key '#{key}'' found in \n%s" %fields[0].map { |m| m["name"] }.join("\n"))
      return nil
    end
    return @status["status"][index]
  end

  def idle_ready
    timeout = 10
    start_time = Time.now
    elapsed = 0
    while elapsed < timeout
      return true if get_status("system_busy") == 0
      sleep 0.25
      if get_status("encoding_active", refresh=false) == 1
        http_get(@shutter_off)
        sleep 2
      end
      elapsed = Time.now - start_time
    end
    return false
  end

  def capture_video(dur)
    return false if @dead_cam
    if idle_ready == false
      log("Camera is not reporting capture idle.  Unable to capture.")
      return false
    end
    http_get(@shutter_on)
    sleep (dur+1)
    http_get(@shutter_off)
  end

  # Send the magic WOL packet in a UDP packet
  # Returns number of bytes sent should be >0 on success
  def wake
    3.times {
      sock = UDPSocket.new
      sock.setsockopt(Socket::SOL_SOCKET, Socket::SO_BROADCAST, true)
      # Format is 0xFF 6 times followed by the MAC ADDR 16 times
      wol_pkt = "\xFF"*6 + ("\\x" + @mac.split(":").join("\\x"))*16

      # Send to the class D IPv4 broadcast address (usually 10.5.5.255)
      dest_ip = @ip.split(".")[0..2].join(".") + ".255"
      dest_port = 1234 # Don't think this ever changes
      sock.send(wol_pkt, 0, dest_ip, dest_port)
      sleep 3.0
      return true if get_status("system_busy") == 0
    }
    return false
  end

  def log(s)
    @log.text = @log.text + "\n#{s}"
  end
end # Camera class

Shoes.app(title: "Short-video Battery Run-down Tool", 
  resizable: false, width: 640, height: 480) {
  def_duration = 5 # Default video clip duration
  def_t_idle = 5
  def_n_videos = 5
  def_t_sleep = 5
  @thr_test = nil

  def log(s)
    @log.text = @log.text + "\n#{s}"
  end

  # Spawns a thread for the timer and returns it if successful
  def start_timer()
    @start_time = Time.now()
    @thr_timer = Thread.new {
      while true do
        sleep 1
        elapsed = (Time.now - @start_time).to_i
        h = elapsed / 3600
        m = (elapsed % 3600) / 60
        s = (elapsed % 3600) % 60
        @timer.replace("Timer: %02d:%02d:%02d" %[h, m, s])
      end
    }
  end

  def test_loop()
    log("Getting camera info...")
    @cam = Camera.new("10.5.5.9", "goprohero", @log)
    if @cam == nil
      log("Unable to get camera MAC address.  Make sure it is connected and ON.")
      return nil
    end

    @dur = @duration.text.to_i
    @idle = @t_idle.text.to_i
    @n_vid = @n_videos.text.to_i
    @t_slp = @t_sleep.text.to_i
    start_timer()
    x = 0
    while true do
      x += 1
      log("***Iteration #{x}")
      @n_vid.times { |n|
        log("Taking video #{n+1} of #{@n_vid} before power cycle")
        @cam.capture_video(@dur)
        sleep @idle
      }
      @cam.http_get(@cam.gotosleep)
      sleep @t_slp
      if @cam.wake == false
        log("Camera disconneted.  Battery shutdown?")
        break 
      end
      sleep @t_slp
    end
    kill_test()
  end

  def kill_test()
    log("Destroying camera object")
    @cam = nil
    @thr_timer.kill if @thr_timer != nil
    @thr_test.kill if @thr_test != nil
    @thr_test = nil
  end

  background white
  stack(scroll: false) { 
    stack {
      background (white..gainsboro)
      flow(height: 23) { 
        @duration = edit_line(width: 35, height: 20, margin_top: 3, text: def_duration.to_s)
        inscription("Video Duration (s)    ")
        @t_idle = edit_line(width: 35, height: 20, margin_top: 3, text: def_t_idle.to_s)
        inscription("Idle time (s)    ")
        @n_videos = edit_line(width: 35, height: 20, margin_top: 3, text: def_n_videos.to_s)
        inscription("# Videos/Cycle    ")
        @t_sleep = edit_line(width: 35, height: 20, margin_top: 3, text: def_t_sleep.to_s)
        inscription("Sleep time   ")
      }
      flow(height: 60) {
        @start = button("Start", width: 100, height: 60) {
          if @thr_test != nil
            log("Test thread already running.  Must STOP it first")
          else
            @thr_test = Thread.new { test_loop }
          end
        }
        @stop = button("Stop", width: 100, height: 60) { 
          kill_test
        }
        @timer = title "Timer: 00:00:00"
      }
    }
    flow(height: (parent.height - 90), scroll: true) {
      @log = edit_box(width: "100%", height: "100%", text: "Log messages:")
    }
  } # first stack
} # Shoe.app
