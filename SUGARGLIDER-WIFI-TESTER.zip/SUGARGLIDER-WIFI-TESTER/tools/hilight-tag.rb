# test_hilight_tag.rb
# Tests the hilight tag function by capturing '--duration' seconds of
# video and tagging every '--tag_interval' serconds.
# The video files are left on the SD card for manual verification of 
# the hilight tags.
#######################################
# Requires a large microSD card to save all the videos
# If using the defaults 128 GB CARD IS REQUIRED
#######################################
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    if @options[:ip] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify camera ip")
      exit 1
    end
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    set_options()
  end

  def runtest()
    # Enumerate all the test combinations
    # Default for this test will be protune OFF only (set nil -> OFF explicitly)
    @options[:video_pt] = "OFF" if @options[:video_pt] != "ON"
    test_params = tu_get_video_res_with_protune()

    if test_params[0].empty? && test_params[1].empty?
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end

    # Now run each test
    duration = (@options[:duration] != nil) ?  @options[:duration] : 30 * 60 # 30 Minutes
    tag_interval = (@options[:tag_interval] != nil) ?  \
                      @options[:tag_interval] : 2 * 60 # 2 minutes
    @camera.delete_all_media()

    test_params.each() { |r|
      next if r.empty?
      r.each {|vm, res, fps, fov, ll, spot, p, wb, co, sh, iso, ex|
        # Add all relevant info to the test case name
        tc_name = "tag_hilight_every_#{tag_interval}s"
        tc_name += "_#{vm}_protune_#{p}_spot_#{spot}_#{res}_#{fps}_#{fov}"
        tc_name += "_low_light_#{ll}" if ll != nil
        tc_name += "_#{wb}" if wb != nil
        tc_name += "_#{co}" if co != nil
        tc_name += "_#{sh}" if sh != nil
        tc_name += "_#{iso}" if iso != nil
        tc_name += "_#{ex}" if ex != nil
        set_tc_name(tc_name)
 
        # Perform a hilight tag every 'tag_interval' seconds during encoding
        # If the encoding thread dies, the tag loop should exit as well    
        ret, msg = false, "Waiting for thread"
        thr = Thread.new { 
          ret, msg = @camera.capture_video(vm, res, fps, fov, duration, ll, spot, p, wb, co, sh, iso, ex)
        }
        sleep 10 # Takes ~10 seconds for capture_video() to set all the settings
        start_time = Time.now()
        while Time.now() - start_time  < duration
          sleep tag_interval
          break if thr.alive? == false
          log_info("Tagging hilight at %0.2d seconds." %(Time.now() - start_time))
          tag_ret, tag_msg = @camera.tag_hilight()
        end
        thr.join
        (ret == false) ? (fail(msg); next) : log_info(msg)

        media = @camera.get_medialist("MP4")
        (fail("No video files were found after encoding"); next) if media.empty?
        log_info("Files created #{res}/#{fps}/#{fov} (#{vm}): #{media.join(', ')}")
        log_warn("Only one MP4 file seen in: #{media}") if media.length < 2
        first_file = true

        failed_arr = []
        media.each { |f|
          if first_file == true
            first_file = false

            #Analyze if mp4/lrv/thm exists over http (since there is no way to check
            #if thm exists on SD card, and doesn't hurt to check mp4/lrv as well)
            ret = tu_wifi_check_media_existence("VIDEO", f, vm, p, res, fps, fov, true)
            failed_arr.concat(ret) if !ret.empty?()

            #File name convention
            ret = tu_analyze_file_name("VIDEO", File.basename(f))
            failed_arr.concat(ret) if !ret.empty?()

            #gpMediaList or camera roll verification
            ret = tu_wifi_analyze_gpmedialist_params("VIDEO", p, res, fps, fov)
            failed_arr.concat(ret) if !ret.empty?()
          else
            #File name convention
            ret = tu_analyze_file_name("CHAPTERED_VIDEO", File.basename(f))
            failed_arr.concat(ret) if !ret.empty?()
          end

          #gpMediaList or camera roll verification
          ret = tu_wifi_analyze_gpmedialist_params(media_type, vm, p, res, fps, fov)
          failed_arr.concat(ret) if !ret.empty?()
          
          ret = tu_wifi_verfiy_low_light(res, fps)
          failed_arr.concat(ret) if !ret.empty?()
        }
        log_pass if !has_failure?(failed_arr)  # Will log a fail if it sees one

        # # Download all the files
        # save_dir = File.join(@options[:save_dir], res, fps.to_s, fov, vm, "pt_#{p}")
        # ret, msg = @camera.download_all_media(save_dir)
        # log_warn(msg) if ret == false
        # log_info(msg) if ret == true
      } # end r.each
    } # end test_params.each
  end

  def cleanup
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only,
      :video_pt, :duration, :video_low_light, :tag_interval,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering,
      :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, :quick]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
