# Pull methods that should be abstracted from camera.rb.
# Note that "abstract' should appear on the same line as the method name... It does anyway.
# Ensures that a def statement for that method exists in wifi_camera.rb and serial_camera.rb
# This is all done via string checking against the actual code, not via responds_to()! O_O

if __FILE__ == $0
  filename = "../libs/camera.rb"

  am = []
  IO.foreach(filename) do |line|
    if line.strip.start_with?("def ") and line.match(/abstract/)
      x = line.match(/ .*\(/)
      x = x.to_s.strip
      x = x.gsub("def ","").gsub("(","")
      am << x
    end
  end
  puts ""
  am.delete("abstract") # Remove this case. Heh.

  puts "ABSTRACT METHODS FOUND:"
  am.each do |x| puts "#{x}" end

  to_check = ["wifi_camera.rb","serial_camera.rb"]
  puts "CHECKING INTERFACES: #{to_check}"

  to_check.each do |filename|
    am.each do |met|
      ret = false
      IO.foreach("../libs/#{filename}") do |line|
        ret = true if line.include?("def #{met}")
      end
      puts "#{filename}: No abstraction for #{met}()" unless ret
    end
  end

  puts "THIS TOOL IS NOT DEFINITIVE. YOUR MILAGE MAY VARY."

end

