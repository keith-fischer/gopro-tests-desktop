# Preview stream file saver
require 'open3'
require 'optparse'
require 'socket'

def ltp_log(level, s)
  puts s if $LOGLEVEL <= level
end

def sys_exec(cmd, opts=nil)
  log_debug("Running system command: #{cmd} #{opts}")
  if opts == nil
    o, e, s = Open3.capture3(cmd)
  else
    o, e, s = Open3.capture3(cmd, opts)
  end
  log_debug("Output = #{o}")
  log_debug("Error = #{e}")
  log_debug("Status = #{s}")
  log_verb("Command (#{cmd}) returned unsucessful") if not s.success?
  return o, e, s
end

def valid_ipv4_addr?(ip)
  octets = ip.split(".")
  return false if octets.length != 4
  octets.each { |oct|
    return false if oct.to_i < 0 or oct.to_i > 255
  }
  return true
end

# Returns mask length if dest_ip is covered by dest_ip_route and mask
# I.e. route_match("10.5.5.9", "10.0.0.0", "255.0.0.0") returns 8
# Returns false otherwise
def route_match(dest_ip, dest_ip_route, mask)
  # First convert to arrays of ints
  ip1 = dest_ip.split(".").map { |m| m.to_i }
  ip2 = dest_ip_route.split(".").map { |m| m.to_i }
  m = mask.split(".").map { |m| m.to_i }
  (0..3).each { |i|
    return false if (ip1[i] & m[i]) != (ip2[i] & m[i])
  }
  # Route match.  Now get the length by counting the "1"s in binary
  len = 0
  m.each { |oct|
    (0..7).each { |i|
      len += (oct >> i) & 0x01
    }
  }
  return len
end

# Looks up the IP of the outgoing interface for the destination IP
# Returns true, IP on success
# Returns false, msg on failure
def get_system_camera_ip(dest_ip)
  cmd = "route -n"
  o, e, s = sys_exec(cmd)
  return false, e if !s.success?

  match_iface = nil
  match_len = -1
  o.each_line { |line|
    fields = line.split()
    next if !valid_ipv4_addr?(fields[0])
    dest = fields[0]
    mask = fields[2]
    iface = fields[7]
    # Look for the routing entry with the longest mask
    m = route_match(dest_ip, dest, mask)
    if (m != false and m > match_len)
      match_iface = iface
      match_len = m
    end
  }
  if match_iface != nil
    ret = get_network_ip_address(match_iface)
    log_info("Using addr/mask %s/%s (%s) to reach %s" \
      %[ret, match_len, match_iface, dest_ip])
    return true, ret
  else
    return false, "Unable to find interface with route to #{dest_ip}"
  end
end

# Returns IPv4 address of given interface name
# Retuns false on failure
def get_network_ip_address(interface)
  cmd = "ifconfig #{interface} | grep 'inet addr'"
  o,e,s = sys_exec(cmd)
  return false, e if !s.success?
  # Output looks like: inet addr:10.0.2.15  Bcast:10.0.2.255  Mask:255.255.255.0

  ip = o.split()[1].split(':')[1]
  if !valid_ipv4_addr?(ip)
    log_warn("IP found (#{ip}) not a valid IPv4 address")
    return false
  else
    return ip
  end
end

def start_streaming_protocol()
  temp = ""
  use_segment_number = -1
  got_first_frame = false
  skip_save_file = false

  $keepalive_thread = Thread.new {
    while !$stop_requested
      log_debug("Sending keepalive")
      $keepalive_socket.send("_GPHD_:0:0:2:0", 0, $CAM_IP, $PORT)
      sleep 3
    end
  }

  $receive_thread = Thread.new {
    File.delete($save_ts_filename) if File.exists?($save_ts_filename)
    first = false
    temp = ""
    while($stop_requested == false)
      result = IO.select([$receive_socket], nil, nil, 2)  # 2s timeout
      if result != nil
        msg = $receive_socket.recvfrom(1328)[0]
        # Decode response
        byte0, r1, r2,      \
        segment_number,     \
        segment_size,       \
        datagram_number_hi, \
        datagram_number_lo, \
        datagram_size_hi,   \
        datagram_size_lo = msg.unpack('CCCCNCCCC')
        datagram_number = (datagram_number_hi << 8) + datagram_number_lo
        datagram_size = (datagram_size_hi << 8) + datagram_size_lo

        next if first == false and datagram_number != 0
        first = true

        if datagram_number == 0
          puts "Writing #{temp.length} bytes to file"
          File.open($save_ts_filename, 'ab') { |file| file.write(temp) }
          temp = msg[12, datagram_size]
        else
          temp.concat(msg[12, datagram_size])
        end
      else
        log_verb("Timed out waiting for select.")
      end
    end # while
  } # receive thread


  # $receive_thread = Thread.new {
  #   File.delete($save_ts_filename) if File.exists?($save_ts_filename)
  #   tracker_datagram_number = nil
  #   tracker_segment_number = nil
  #   while(true)
  #     skip_save_file == false
  #     # Read Timeout. By design, resoutions that do not support streaming,
  #     # no packet will be seen
  #     result = IO.select([$receive_socket], nil, nil, 2)  # 2s timeout
  #     if result != nil
  #       msg = $receive_socket.recvfrom(1328)[0]
  #       # Decode response
  #       byte0, r1, r2,      \
  #       segment_number,     \
  #       segment_size,       \
  #       datagram_number_hi, \
  #       datagram_number_lo, \
  #       datagram_size_hi,   \
  #       datagram_size_lo = msg.unpack('CCCCNCCCC')

  #       datagram_number = (datagram_number_hi << 8) + datagram_number_lo
  #       datagram_size = (datagram_size_hi << 8) + datagram_size_lo

  #       if tracker_datagram_number != nil && tracker_segment_number != nil
  #         if (tracker_segment_number == segment_number) && \
  #            (datagram_number != (tracker_datagram_number + 1))
  #           log_debug("Missing datagram # %s \t (segment # %s)" \
  #             [tracker_datagram_number + 1, segment_number])
  #           got_first_frame = false
  #           use_segment_number = -1
  #           temp.clear
  #           skip_save_file == true
  #         end
  #       end
  #       tracker_datagram_number = datagram_number
  #       tracker_segment_number = segment_number

  #       if $save_ts_file == true and skip_save_file == false
  #         if datagram_number == 0 and use_segment_number == -1
  #           if got_first_frame != true
  #             got_first_frame = true
  #             use_segment_number = segment_number
  #             log_verb("#{Time.now} use_segment_number #{use_segment_number}")
  #           end
  #         elsif use_segment_number != -1 and use_segment_number != segment_number
  #           log_info("#{Time.now} \t write to file \t segment #" + \
  #             "#{use_segment_number} \t total write size #{temp.length}")
  #           File.open($save_ts_filename, 'ab') { |file| file.write(temp) }
  #           got_first_frame = false
  #           use_segment_number = -1
  #           temp.clear
  #           tracker_datagram_number = nil
  #           tracker_segment_number = nil
  #           #$save_ts_file = false
  #         end

  #         if use_segment_number == segment_number
  #           log_debug("#{Time.now} \t save to memory \t datagram #" + \
  #             "#{datagram_number} \t segment_number #{segment_number} \t " + \
  #             "datagram_size #{datagram_size} \t before save file #{temp.length}")
  #           temp.concat(msg[12, datagram_size])
  #         end
  #       end # if $save_ts_file == true and skip_save_file == false
  #     else
  #       log_verb("Timed out waiting for select.")
  #     end # if result != nil
  #   end # while true
  # } # receive_thread
end # start_streaming_protocol

def stop_streaming_protocol()
  begin
    log_verb("Stopping streaming protocol")
    $stop_requested = true
    $receive_thread.exit
    $keepalive_thread.join
    $receive_socket.close
    $keepalive_socket.close
    log_info("All sockets closed successfully")
  rescue StandardError => e
    log_warn("Error closing socket.")
    puts e.to_s
    puts e.backtrace.join("\n")
  end
end

if __FILE__ == $0
  # Constants
  $CAM_IP = "10.5.5.9"
  $PORT   = "8554"
  $DBG, $VERB, $INFO, $WARN, $ERR = 0, 1, 2, 3, 4
  $LOGLEVEL = $INFO
  # Defaults
  options = {}
  options[:duration] = nil
  options[:output]   = "/tmp/preview.ts"

  op = OptionParser.new do |opts|
    opts.banner = "ruby save-preview-stream.rb [-d DURATION] [-o OUTPUT_FILE] [-h]"
    opts.on("-d", "--duration D", "Duration to capture for") \
      { |o| options[:duration] = o }
    opts.on("-o", "--output FILE", "Output file (default /tmp/preview.ts") \
      { |o| options[:output] = o }
    opts.on("-h", "--help", "Display this message and exit") { puts op; exit 0}
  end
  op.parse!(ARGV)
  $duration = options[:duration]
  $save_ts_filename = options[:output]

  ret, msg = get_system_camera_ip($CAM_IP)
  if ret == true
    $system_address = msg
  else
    puts msg
    exit 2
  end

  $keepalive_socket = UDPSocket.new
  $stop_requested = false
  $receive_socket = UDPSocket.new
  $receive_socket.setsockopt(Socket::SOL_SOCKET, Socket::SO_REUSEADDR, true)
  $receive_socket.bind($system_address, $PORT)
  $save_ts_file = true

  sys_exec("curl -s http://#{$CAM_IP}/gp/gpControl/execute?p1=gpStream\\&c1=restart")
  start_streaming_protocol()
  if $duration.to_i > 0
    puts "="*60 + "\n" + "Captuing preview stream for #{$duration}s"
    puts "Saving to #{$save_ts_filename}"
    sleep $duration.to_i
    stop_streaming_protocol()
  else
    puts "="*60 + "\n" + "Capturing preview stream. Press Ctrl+C when finished"
    puts "Saving to #{$save_ts_filename}"
    begin
      while (true) do; sleep 10; end
    rescue Interrupt
      puts "\n"
      stop_streaming_protocol()
    end
  end

end # end script
