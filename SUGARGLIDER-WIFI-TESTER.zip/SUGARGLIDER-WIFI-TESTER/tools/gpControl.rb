#!/usr/bin/env ruby

# Print a human-readble gpControl status
# 

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require_relative '../libs/data_analytics_events'
require_relative '../libs/data_analytics_decode'
require_relative '../libs/data_analytics'
require_relative '../libs/testcase'
require 'open3'
require 'net/http/persistent'
require 'json'
require 'curses'
require 'optparse'

class Test < TestCase

  attr_accessor :settings_hash, :options_hash, :dbg, :td, :tlm_mode, :last_settings, :last_status, :current_mode

  def initialize
    super
    @dbg=true
    @tlm_mode = false
    @current_mode = 0
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    if @options[:ip] != nil and @options[:pc] != nil
      log_warn("ip=#{@options[:ip]}")
      log_warn("pc=#{@options[:pc]}")
      log_warn("serialdev=#{@options[:serialdev]}")
      log_warn("@camera = get_wifi_camera(ip, pc, serialdev)")
      sleep 4.0
      @camera = get_wifi_camera(@options[:ip], @options[:pc], @options[:serialdev])
    elsif @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    else
      log_error("Must specify either serial or ip/pc/serial")
      exit 1
    end
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.do_factory_reset("USER") if @camera.interfaces.include?(:serial)
    #set_options()  ### DONT NEED THIS -- only if controlling/setting camera!

  end

  def build_hashes()
    dbg=false
    @camera.get_settings_json_hash()
    ssid = @camera.settings_json_hash["info"]["ap_ssid"]
    serialno = @camera.settings_json_hash["info"]["serial_number"]
    puts "ssid=#{ssid}" if dbg 
    puts "serialno=#{serialno}" if dbg
    #hash_settings_id_to_name = Hash.new
    @last_settings = Hash.new
    @last_status   = Hash.new
    @settings_hash = Hash.new
    @options_hash  = Hash.new {|h,k| h[k] = Hash.new(&h.default_proc) }
    @camera.settings_json_hash['modes'].each do |hash|
      # Level_1_MODE_index: 
      printf "mode: %-10s %d\n",  hash["path_segment"], hash["value"] if dbg 
      mode = hash["path_segment"]
      # Build the SETTINGS id->name hash
      hash['settings'].each do |shash|
        settings_name = mode.to_s + "." +shash['path_segment']
        settings_id = shash['id']
        @settings_hash[settings_id] = settings_name
        printf "\t%-22s id: %02d\n",  settings_name, settings_id if dbg
        shash['options'].each do |ohash|
          options_name  = ohash['display_name']
          options_value = ohash['value']
          printf "\t\t%-22s %2d\n",  options_name, options_value if dbg
          @options_hash[settings_id][options_value] = options_name
        end
      end
    end
  end

  def print_options_hash()
    puts"\nOPTIONS_HASH:"
    @options_hash.each do |k,h| 
      puts "k=#{k} h=#{h}"
      #OUTPUT:
      #  k=51 h={0=>"Never", 1=>"1 MIN", 2=>"2 MIN", 3=>"3 MIN"}
      #  k=52 h={1=>"Up", 2=>"Down", 0=>"Auto"}
    end
  end

  def my_camera()
    return @camera
  end

  def my_json()
    return @camera.settings_json_hash
  end

  def sys_exec(cmd, opts=nil)
    log_debug("Running system command: #{cmd} #{opts}")
    if opts == nil
      o, e, s = Open3.capture3(cmd)
    else
      o, e, s = Open3.capture3(cmd, opts)
    end
    log_verb("Output = #{o}")
    log_verb("Error = #{e}")
    log_verb("Status = #{s}")
    log_verb("Command (#{cmd}) returned unsucessful") if not s.success?
    return o, e, s
  end

  def get_mode_by_id(id)
    @camera.settings_json_hash['modes'].each do |hash|
      # printf "%-10s %d\n",  hash["path_segment"], hash["value"]
      if hash["value"].to_s == id.to_s
        return hash["path_segment"].to_s
      end
    end
    return "UNKNOWN"
  end

  def get_submode_by_id(mode, submode)
    @camera.settings_json_hash['modes'].each do |hash|
      # printf "%-10s %d\n",  hash["path_segment"], hash["value"]
      if hash["value"].to_s == mode.to_s
        return "" if hash["settings"].empty?
        hash["settings"].each do |shash|
          if shash["path_segment"].to_s == "current_sub_mode"
            shash["options"].each do |ohash|
              if ohash["value"] == submode
                return ohash["display_name"]
              end
            end
          end
        end
      end
    end
    return "*"
  end

  def create_tlm_display()
    puts("NEW Test::create_tlm_display") if @dbg
    @td = TlmDisplay.new 
    return @td
  end

  def show_status()
    @td.prtStr(14,0,"status") if @tlm_mode
    gpsts = @camera.curr_status["status"]
    api2_sts_idmap = @camera.status_api2_mapping.invert

    mode = 0
    submode = 0
    # just scroll out the values
    last_value = 0
    gpsts.each { |id, value|
      i = id.to_i 
      i -= 1

      is_diff=false
      if not @last_status.empty?
        last_value = @last_status[id]
        is_diff=true if last_value != value #DETECT A CHANGE
      end

      name = api2_sts_idmap[id].to_s
      value_formatted = value.to_s

      if not @tlm_mode
        #sval = cam.get_level_1_index(:mode).to_s
        printf " %02d %40s %10s %s\n", id,  api2_sts_idmap[id], value
      else
        #value_formatted = api2_sts_valuemapper(id,value)
        name = api2_sts_idmap[id].to_s
        value_formatted = value.to_s
        if name == "date_time"
          # Ex. "%0F%01%02%10%28%0B" -> [15, 1, 2, 16, 40, 11] Y,M,D,h,m,s
          exp_year, exp_month, exp_day, exp_hour, exp_min, exp_sec = \
          value.split("%").reject{|n| n.empty?}.map {|h| h.to_i(16)}
          #exp_year += 2000
          value_formatted = sprintf("%d.%d.%d %02d:%02d:%02d",
                                    exp_month, exp_day, exp_year,
                                    exp_hour, exp_min, exp_sec)
        elsif name == "mode"
          @current_mode = value.to_i  # save this so we can index into the hash to get the submode
          value_formatted = sprintf "%d %10s", value.to_i, get_mode_by_id(@current_mode)
        elsif name == "submode"
          submode = value
          value_formatted = sprintf "%d %10s", value.to_i, get_submode_by_id(@current_mode,submode)
        end

        sline = sprintf(" %02d %-40s %-s\n", id,  name, value_formatted)
        row = i % @td.max_rows
        col = i / @td.max_rows
        if is_diff
          @td.text_color_red()
        else
          @td.text_color_normal()
        end
        @td.prtStr(@td.col_offset+(col*@td.col_width),row + @td.row_offset,sline)
      end
      @last_status[id] = value

    } # gpsts.each { |id, value|

  end # Test::show_status

  def show_settings()

    @td.prtStr(14,0,"settings") if @tlm_mode

    @camera.get_settings_json_hash()
    gpsettings = @camera.curr_status["settings"]

    last_val = 0
    gpsettings.each { |id, value|
      i = id.to_i 
      #next if i > 24
      setting_name = @settings_hash[i]
      value_hash   = @options_hash[i]
      value_name = ""
      if not value_hash.empty?
        if value_hash[value.to_i] != nil
          value_name   = value_hash[value.to_i]
        end
      end
      is_diff=false
      if not @last_settings.empty?
        if @last_settings[id] != nil
          last_value = @last_settings[id]
          is_diff=true if last_value != value #DETECT A CHANGE
        end
      end
      if not @tlm_mode
        if is_diff
          puts("CHANGED id=#{id} last=#{last_value} value=#{value} setting_name=#{setting_name} val_name=#{value_name}")
        else
          puts("id=#{id} i=#{i} value=#{value} setting_name=#{setting_name} val_name=#{value_name}")
        end
      else
        sline = sprintf("%02d %-32s %-5s %s\n", id,  setting_name, value, value_name)
        row = (i-1) % @td.max_rows
        col = (i-1) / @td.max_rows
        if is_diff
          @td.text_color_red()
        else
          @td.text_color_normal()
        end
        @td.prtStr(@td.col_offset+(col*@td.col_width),row + @td.row_offset,sline)
      end
      @last_settings[id] = value

    } # gpsettings.each

  end # def show_settings


  def show_info()
    puts "\nCAMERA INFO:"
    @camera.settings_json_hash['info'].each do |k,i|
      printf("\t%-30s : %s\n", k, i)
    end # info hash
    puts ""
  end

  def show_modes()
    @camera.settings_json_hash['modes'].each do |hash|
      # Level_1_MODE_index: 
      mode = hash["path_segment"]
      printf "mode: %-10s %d\n",  mode, hash["value"] if dbg
      # Build the SETTINGS id->name hash
      hash['settings'].each do |shash|
        settings_name = shash['path_segment']
        settings_id = shash['id']
        @settings_hash[settings_id] = settings_name
        printf "\t%-22s id: %02d\n",  settings_name, settings_id if dbg
        printf "\t\tl3 options:\n"
        #BUILD an OPTIONS HASH - which will tie settings id to a value's name
        # settingid -> option value ->  option name
        shash['options'].each do |ohash|
          options_name  = ohash['display_name']
          options_value = ohash['value']
          printf "\t\t%-22s %2d\n",  options_name, options_value if dbg
          @options_hash[settings_id][options_value] = options_name
          #options_hash['49']['70000'] = 'bit_stream_rate'
        end # do ohash
      end # do shash
    end
    puts ""
    puts "Camera MODES and SETTINGS (gpControl JSON output)"
    puts ""
  end # show_modes()

  # TODO: JSON format tool
  def json_formatter (file)
    #EXAMPLE: cat backdoor.json | python -m json.tool > bdoor.json

    #DATE=`date +"%j_%Y"`
    #puts "#{DATE}"
    #JFILE="gp-$DATE.json"
    #system("gpjson > tmp.json")
    #system("cat tmp.json | python -m json.tool > $JFILE"
    #echo "JFILE=$JFILE"
  end

  def show_json()  #TBD: not done
    puts "Option not available yet"
    exit

    #printf "HASHES:\n"
    @camera.settings_json_hash.each do |k,h0|
      printf "\t%-15s :\n", k
    end
    puts ""

    ######  TODI: MAKE THIS RECURSIVE !!!!!
    @camera.settings_json_hash.each do |k0,h0|
      printf "\t%-15s :\n", k0
      if h0.class.to_s == 'Hash'
        h0.each do |k1,h1|

          if k1.class.to_s == 'Hash'
            printf "\t\tk1 is a HASH\n"
          elsif h1.class.to_s != 'Hash'
            printf "\t\t%-15s : %s\n", k1, h1
            #printf "\t\tk1 is a NOT a HASH\n"
          end

          if h1.class.to_s == 'Hash'
            h1.each do |k2, h2|
              if h2.class.to_s != 'Hash'
                printf "\t\t\t%-15s : %s\n", k2, h2
              else 
                h2.each do |k3, h3|
                  if h3.class.to_s != 'Hash'
                    printf "\t\t\t%-15s : %s\n", k3, h3
                  end
                end
              end # h2.each
            end # h1.each
          end
        end
      end
    end
  end # show_json()

end # class Test

class TlmDisplay  
  require 'curses'
  include Curses

  attr_accessor :title_x, :title_y, :top_x, :top_y, :side_x, :side_y, :columns, :rows, :col_width, :w_len, :win, :max_cols, :max_rows,
            :row_offset, :col_offset, :row_footer
  def initialize
    puts "TlmDisplay:: initializing curses"
    Curses.init_screen()
    Curses.start_color
    color_set=2
    Curses.init_pair(color_set,Curses::COLOR_WHITE,Curses::COLOR_BLACK)
    color_set=3
    Curses.init_pair(color_set,Curses::COLOR_RED,Curses::COLOR_BLACK)
    @max_cols = 134
    @max_rows = 39
    @title_x=0
    @title_y=0
    @top_x=0
    @top_y=0
    @side_x=0
    @side_y=0
    @col_width=65
    @row_offset=2
    @row_footer=2
    @col_offset=3
    @left_margin=1
    @right_margin=1
    @w_len=40

    # TODO: do this stuff on the fly (by sizing up the nam and data size
    height = @max_rows + @row_offset + @row_footer
    #width=180
    width = @max_cols
    top=0
    left=0

    # TODO: do this stuff on the fly (by sizing up the nam and data size
    @win = Window.new(height, width, top, left)
    @win.box(?|, ?-)
    @win.setpos(0, 4)
    @win.addstr("gpControl ")
    @win.refresh
    #@win.getch
    #@win.close
    #windowCreate(40,80, 20,30)
  end

  def text_color_normal()
    @win.attron(Curses.color_pair(2)|A_NORMAL)
  end

  def text_color_red()
    @win.attron(Curses.color_pair(3)|A_NORMAL)
  end

  def windowCreate(height, width, top, left)
    @win = Window.new(height, width, top, left)
    # Note: fullscreen is Window.new(0,0,0,0)
  end

  def prtStr(x,y,message)
    @win.setpos(y,x)
    @win.addstr(message)
    @win.refresh
  end

  def prtTitle
  end

  def prtTopHdr(s)
    #td.prtStr(3,1,s)
    @win.setpos(3,1)
    @win.addstr(message)
    @win.refresh
  end

  def prtSideHdr
  end

  def show_message(message)
    width = message.length + 6
    win = Window.new(5, width,
               (lines - 5) / 2, (cols - width) / 2)
    win.box(?|, ?-)
    win.setpos(2, 3)
    win.addstr(message)
    win.refresh
    win.getch
    win.close
  end

  def update_sts(gpsts, idmap)
    #@win.getch
    gpsts.each { |id, value|
    #row = id % 31
    #col = id / 31
    @row++
    @col=3

    puts "row=#{@row} col=#{@col}"
    #@win.setpos(@row,@col)
    @win.setpos(10,4)
    str =  "x=#{@col} y=#{@row}"
    #@win.addstr("Hello")
    @win.addstr(str)
    #row = id % @rows
    #col = id / @rows
    #setpos(col*40,row)
    #puts "#{id}) "
    #puts "= #{value} \t #{api2_sts_idmap[id]}"
    #puts "#{id}) = #{value} \t #{idmap[id]}"
    #prtStr(row, col*40, idmap[id].to_str)
    @win.getch
    }
    @win.refresh
    #@win.close
  end

  def close_window()
    @win.close
  end

end # class TlmDisplay

#--------------------------------------


#---------- local functions
def quit?()
  return false
end

if __FILE__ == $0

  begin

  t  = Test.new
  lopts = {}
  dbg=false

  lopts[:debug_mode]      = false
  lopts[:tlm_mode]        = true   # preferred on by default now
  lopts[:show_status]     = false
  lopts[:show_settings]   = false
  lopts[:show_json]       = false
  lopts[:show_modes]      = false
  lopts[:show_info]       = false
  lopts[:ip]              = "10.5.5.9"
  lopts[:pc]              = "goprohero1"
  ipaddr                  = "10.5.5.9"   #default
  passcode                = "goprohero1" #default
  columns_to_display      = 0            #pass this to TlmDisplay
  looping = true

  OptionParser.new do |opts|
    opts.banner = "Usage: gpControl [--ip <IP adddress> | --pc <wifi passcode> | --tlmoff | --sts(-s) | --settings(-x) | --modes(-m) | --info(-i) | --json(-j)" 

    opts.on("-s", "--sts", "Show Status info") do
      lopts[:show_status] = true
      columns_to_display += 1
    end
    opts.on("-x", "--settings", "Show Settings info") do
      lopts[:show_settings] = true
      columns_to_display += 1
    end
    opts.on("-m", "--modes", "Show CAMERA MODES & SETTINGS") do
      lopts[:show_modes] = true
      looping = false
      lopts[:tlm_mode] = false
    end
    opts.on("-j", "--json", "Show beautified camera gpControl JSON output") do
      puts "\n-j option not available yet\n\n"
      exit
      lopts[:show_json] = true
      looping = false
      lopts[:tlm_mode] = false
    end
    opts.on("-i", "--info", "Show CAMERA INFO") do
      lopts[:show_info] = true
      looping = false
      lopts[:tlm_mode] = false
    end
    opts.on("--tlmoff", "Turn Telemetry Mode OFF for all modes") do
      lopts[:tlm_mode] = false
    end
    opts.on("--ip IPADDR", "IP address of camera") do |ip| 
      lopts[:ip] = ip
    end
    opts.on("-p", "--pc PASSCODE", "Passcode") do |pc| 
      lopts[:pc] = pc
    end
    opts.on("-d", "--debug", "Debugging mode") do
      lopts[:debug_mode] = true
      lopts[:tlm_mode] = false
    end
   # OptionsParser
  end.parse!

  t.tlm_mode      = lopts[:tlm_mode]
  ipaddr          = lopts[:ip]
  passcode        = lopts[:pc]
  show_status     = lopts[:show_status]
  show_settings   = lopts[:show_settings]
  show_json       = lopts[:show_json]
  show_modes      = lopts[:show_modes]
  show_info       = lopts[:show_info]
  debug_mode      = lopts[:debug_mode]
  if debug_mode
    puts "ipaddr=#{ipaddr}"
    puts "passcode=#{passcode}"
    puts "tlm_mode=#{t.tlm_mode}"
    puts "show_status=#{show_status}"
    puts "show_settings=#{show_settings}"
    puts "show_JSON=#{show_json}"
    puts "show_modes=#{show_modes}"
    puts "show_info=#{show_info}"
    puts "debug_mode=#{debug_mode}"
  end
  t.setup(lopts) 

  cam  = t.my_camera()
  json = t.my_json()
  t.build_hashes()

  if debug_mode
    puts "DEBUG_MODE"

    puts "settings hash:" if dbg
    t.settings_hash.each do |settings_id, name|
      puts "#{settings_id} #{name}" if dbg
      t.options_hash[settings_id].each do |options_value, options_name|
        printf "\t%8d %-22s\n", options_value, options_name if dbg
      end
      xhash =  t.options_hash['62']
    end

    puts "End DEBUG_MODE"
    exit
  end  # if debug

  #-----------------------
  if t.tlm_mode
    puts("IN TLM MODE...")
    td   = t.create_tlm_display()
    sn   = cam.serialno
    rel  = cam.release
    type = sprintf("%02d", cam.type)
    bld  = cam.build
    caminfo = sprintf("%s %s.%2s.%2s %s", cam.name, rel, type, bld, sn)
    td.prtStr(24,0,caminfo)
    td.columns = columns_to_display
  end # t.tlm_mode initialization

  quit = false

  while not quit do

    cam.get_status(:busy)  # This will update cam.curr_status hash

    t.show_status()     if show_status
    t.show_settings()   if show_settings
    t.show_modes()      if show_modes
    t.show_json()       if show_json
    t.show_info()       if show_info

    if looping
      sleep 1
    else
      quit = true
    end

  end # while do

  # TODO: have auto-sizing depending on number of statues and/or settings
  # TODO: add --map_check (iterations through gpControl status and maps ids to api2_status_mapping
  # TODO: add -scroll option
  # TODO: add -trend <id list> option
  # TODO: add -group option that will display statuses and settings in their respective groups

  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  end
end  # MAIN
