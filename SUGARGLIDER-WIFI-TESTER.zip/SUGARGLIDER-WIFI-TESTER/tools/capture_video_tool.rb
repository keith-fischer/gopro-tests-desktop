# test_video_metadata.rb
# Description: Iterates over all RES/FPS/FOV with both ProTunes
#              off and on (if supported).  Also checks LRV and THM.
# Tests the following items:
#   - Preview is available before and after capture
#   - # of videos on the card increments correctly
#   - # of minutes left on SD card decrements correctly
#   - The following video metadata is correct
#     - aspect_ratio
#     - audio_channels
#     - audio_codec
#     - audio_sample_rate
#     - bitrate
#     - colorspace
#     - frame_rate
#     - has_timecode
#     - height
#     - width
#     - video_codec
require 'set'
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include Test_utils

  def initialize
    super
  end

  def setup
    @test_file = __FILE__
    set_tc_name("#{@test_file} setup")
    $host = Host.new
    if $options[:serialdev] != nil
      $camera = get_serial_camera($options[:serialdev])
    elsif $options[:ip] != nil and $options[:pc] != nil
      $camera = get_wifi_camera($options[:ip], $options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit! 1
    end
    $camera.powerstrip = PowerStrip.new($options[:power_ip], 
                         $options[:power_usr], $options[:power_pwd])
    $camera.battoutlet = $options[:battoutlet] if $options[:battoutlet] != nil
    $camera.usboutlet = $options[:usboutlet] if $options[:usboutlet] != nil
  end

  def test_capture(res, fps, fov, duration)
    log_info("Capturing #{duration} seconds of #{res}/#{fps}/#{fov} video")
    ret, msg = $camera.capture_video(res, fps, fov, duration, retries=1)
    if ret == false
      fail(msg)
      return
    end    
    log_pass("Capture successful")
  end

  def runtest(protune=false)
    # Enumerate all the test combinations
    test_params = []
    $camera.get_video_resolution().each do |res|
      next if $options[:vid_res] != nil and $options[:vid_res] != res
      $camera.get_video_fps(res).each do |fps|
        next if $options[:fps] != nil and $options[:fps] != fps
        $camera.get_video_fov(res, fps).each do |fov|
          next if $options[:fov] != nil and $options[:fov] != fov
          log_verb("Adding test [#{res}, #{fps}, #{fov}]")
          test_params << [res, fps, fov]
        end # fov
      end # fps
    end # res
    
    if test_params.length == 0
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end
    test_params.shuffle! if $options[:shuffle]
    
    # Now run each test
    duration = ($options[:duration] != nil) ?  options[:duration] : 5 #seconds
    test_params.each do |res, fps, fov|
      tc_str = "test_#{res}_#{fps}_#{fov}"
      tc_str += "_protune" if protune == true
      set_tc_name(tc_str)
      begin
        test_capture(res, fps, fov, duration)
        break if @hard_fail and @assertion_failed
      rescue => e
        log_error(e.to_s + "\n" + e.backtrace.join("\n"))
      end
    end # end test_params
  end # end runtest

  def cleanup
    
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :save_dir,
      :battoutlet, :usboutlet, 
      :vid_res, :fps, :fov, :beep,
      :protune, :color, :white_balance, :exposure, 
      :duration, :shuffle, :save_dir]
    $options = t.parse_options(ARGV, use_options)
    t.setup
    t.runtest
    t.cleanup
  rescue => e
    require_relative '../libs/log_utils'; include Log_utils
    ltp_log($ERR, e.to_s + "\n" + e.backtrace.join("\n"))
  end
end
