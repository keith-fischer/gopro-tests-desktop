require_relative '../libs/data_analytics_events'
require_relative '../libs/data_analytics_decode'
require_relative '../libs/data_analytics'
require_relative '../libs/testcase'
require 'open3'

class Test < TestCase
  def initialize
    super
  end

	def process_data(filename, limit, ver, model)
		@analytics = DataAnalytics.new(ver, model)
		# log_info("Parsing analytics file #{filename}")
		f = File.open(filename, "r")
		n = 0
		while f.eof? == false
		  # Parse the timestamp (unpack as binary)
		  ts_bin = f.read(4)
		  ts = ts_bin.unpack('B8B8B8B8').reverse.join
		  y, mon, d = ts[0..5], ts[6..9], ts[10..14]
		  h, min, s = ts[15..19], ts[20..25], ts[26..31]

		  # Parse the event (unpack as hex)
		  ev = f.read(4).unpack('H*')[0]
		  name, p1, p2, p3 = ev[0..1], ev[2..3], ev[4..5], ev[6..7]
          ### Needed for a while on RKPT/HAL/HIMALAYAS since they 0xFF pad files.
          if ts_bin == "\xff\xff\xff\xff" or \
            (name == "ff" and p1 == "ff" and p2 == "ff" and p3 == "ff")
            log_warn("Breaking due to EOF (0xFF) timestamp or event")
            break
          end

		  tr_ev = @analytics.translate_entry(y, mon, d, h, min, s, name, p1, p2, p3)
		  s = "HEX=" + ts_bin.unpack('H*')[0] + ev + ", "
		  s += "DATE=%s/%s/%s %s:%s:%s, (0x#{name})EVENT=%s, P1=%s, P2=%s, P3=%s" %tr_ev
		  
		  # Verify the timestamp validity
		  ret, msg = @analytics.validate_timestamp(*tr_ev[0..5])
		  ts_ret = ret

		  # If any events were unrecognized, throw a warning (FAIL, maybe?)
		  ev_ret = true
		  tr_ev[6..9].each { |x|
		    if x.to_s.match("UNKNOWN") != nil
		      ev_ret = false
              log_warn("UNKNOWN or possible bad event (code=#{name}, p1=#{p1}, p2=#{p2}, p3=#{p3})")
		      break
		    end
		  }
		  s += ", WARN="
  	  s += "Invalid timestamp. " if ts_ret == false
	  	s += "Invalid event/parameter." if ev_ret == false
	  	puts(s)

		  n += 1
		  break if limit != nil and n > limit
		end
		f.close()
		return true
	end

  def sys_exec(cmd, opts=nil)
    log_debug("Running system command: #{cmd} #{opts}")
    if opts == nil
      o, e, s = Open3.capture3(cmd)
    else
      o, e, s = Open3.capture3(cmd, opts)
    end
    log_verb("Output = #{o}")
    log_verb("Error = #{e}")
    log_verb("Status = #{s}")
    log_verb("Command (#{cmd}) returned unsucessful") if not s.success?
    return o, e, s
  end

  def get_analytics
    sys_exec("curl -o #{$TMP_ANA_FILE} http://10.5.5.9/gp/gpControl/analytics/get")
  end

  def clear_analytics
    sys_exec("curl http://10.5.5.9/gp/gpControl/analytics/clear")
  end

  def freeform_actions(limit, ver, model)
    clear_analytics()
    sys_exec("rm #{$TMP_ANA_FILE}")
    sleep(1.0)
    puts "Perform actions for 30 seconds"
    sleep(30.0)
    get_analytics()
    process_data($TMP_ANA_FILE, limit, ver, model)
  end

  def just_view_events(limit, ver, model)
    sys_exec("rm #{$TMP_ANA_FILE}")
    get_analytics()
    process_data($TMP_ANA_FILE, limit, ver, model)
  end

end # Test

if __FILE__ == $0
  $TMP_ANA_FILE = "/tmp/analytics.bin"
  $LOGLEVEL = $LL_INFO
  begin
  	t = Test.new
    use_options = [:analytic_file, :verb, :n_iter, :analytic_version, :model, :quick]
    options = t.parse_options(ARGV, use_options, extra_opts=[], quiet=true)
    f = options[:analytic_file]
    if options[:n_iter] != nil and options[:n_iter].to_i == 0
      t.log_warn("Invalid number of iterations: #{limit}.  Must be integer")
      exit 1
    end
    limit = options[:n_iter].to_i if options[:n_iter] != nil

    if f == nil
      t.log_info("Are we connected to a camera?")
      o, e, s = t.sys_exec("curl -q http://10.5.5.9")
      if s.success?
        if options[:quick] == true
          t.just_view_events(limit, ver=options[:analytic_version], model=options[:model])
        else
          t.log_info("Camera found")
          sleep 2.0
          t.freeform_actions(limit, ver=options[:analytic_version], model=options[:model])
        end
        exit 1
      else
         t.log_warn("Unable to find a connected camera")
    	  exit 1
      end
    elsif File.exists?(f) == false
      t.log_warn("Unable to find analytics file: '#{f}'")
      exit 1
    end

    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.process_data(f, limit, ver=options[:analytic_version], model=options[:model])
    
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  end
end
