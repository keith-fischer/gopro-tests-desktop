# Dump all the capture modes that a camera model supports
# RES/FPS/FOV, Width, Height, FPS, Mbps, Level, Audio kbps, Audio codec, # Ch., Sample Rate, Colorspace, Aspect Ratio, Video Codec,
# LRV, Width, Height, FPS, Mbps, Sample Rate, Audio Codec, # Ch., Colorspace, Aspect Ratio, Video Codec, THM?

require_relative '../libs/camera'

# Quick monkey-patch to get at the member variables we want
class Camera
  attr_reader :audio_codec,
  :audio_channels,
  :audio_sample_rate,
  :colorspace,
  :video_capture_modes,
  :video_codec,
  :video_lrv_bitrate
end

def get_cam(name)
  c = Camera.new()
	case name
  when "WHITE"
    require_relative '../libs/camera_white'
    c.extend(White)
  when "SILVER"
    require_relative '../libs/camera_silver'
    c.extend(Silver)
  when "SILVER_PLUS"
    require_relative '../libs/camera_silver_plus'
    c.extend(SilverPlus)
  when "BLACK"
    require_relative '../libs/camera_black'
    c.extend(Black)
  when "BLACK_PLUS"
    require_relative '../libs/camera_black_plus'
    c.extend(BlackPlus)
  when "BACKDOOR"
    require_relative '../libs/camera_backdoor'
    c.extend(Backdoor)
  when "PIPE"
    require_relative '../libs/camera_pipe'
    c.extend(Pipe)
  when "ROCKYPOINT"
    require_relative '../libs/camera_rockypoint'
    c.extend(Rockypoint)
  when "HALEIWA"
    require_relative '../libs/camera_haleiwa'
    c.extend(Haleiwa)
  when "HIMALAYAS"
    require_relative '../libs/camera_himalayas'
    c.extend(Himalayas)
  when "SQUIRRELS"
    require_relative '../libs/camera_squirrels'
    c.extend(Squirrels)
  when "STREAKY"
    require_relative '../libs/camera_streaky'
    c.extend(Streaky)
  else
    puts "Camera name '#{name}' not recognized!"
    puts "Should be one of %s" \
    %"WHITE|SILVER|BLACK|SILVER_PLUS|BLACK_PLUS|BACKDOOR|PIPE|ROCKYPOINT|HALEIWA|HIMALAYAS|SQUIRRELS|STREAKY"
    exit 1
  end
  c.init()
  return c
end

def do_dump(c, ntsc_or_pal)
  headings = [ntsc_or_pal, "W", "H", "FPS", "Mbps", "Level", 
    "Audio kbps", "Audio Codec", "# Ch.", "Sample Rate", 
    "Colorpsace", "Aspect Ratio", "Video Codec",
    "LRV?", "W", "H", "FPS", "Mbps", "Sample Rate", 
    "Audio Codec", "# Ch.", "Sample Rate", "Colorpsace", 
    "Aspect Ratio", "Video Codec", "THM?"]
    puts headings.join(", ")
    
  c.get_video_resolution().each { |res|
    c.get_video_fps(res).each { |fps|
      next if ntsc_or_pal == "NTSC" and c.is_ntsc?(res, fps) == false
      next if ntsc_or_pal == "PAL" and c.is_pal?(res, fps) == false
      c.get_video_fov(res, fps).each { |fov|
        # MP4 metadata
        label = "#{res}/#{fps}/#{fov}"
        w = c.video_capture_modes[res][:width]
        h = c.video_capture_modes[res][:height]
        fr = c.video_capture_modes[res][:fps][fps][:frame_rate]
        br = c.get_bitrate(res, fps)
        lvl = c.get_profile_level(res, fps, "OFF")
        a_kbps = 128
        a_codec = c.audio_codec
        a_ch = c.audio_channels
        a_sr = c.audio_sample_rate
        cspace = c.colorspace
        ratio = c.video_capture_modes[res][:aspect_ratio]
        v_codec = c.video_codec

        # LRV metadata
        if c.has_lrv?(res, fps, fov) == true
          lrv = "YES"
          lrv_w = c.get_lrv_width(res, fps)
          lrv_h = c.get_lrv_height(res, fps)
          lrv_fr = c.get_lrv_fps(res, fps)
          lrv_br = c.get_lrv_bitrate(res, fps)
          lrv_sr = c.audio_sample_rate
          lrv_a_codec = c.audio_codec
          lrv_a_ch = c.audio_channels
          lrv_cspace = c.colorspace
          lrv_ratio = c.get_lrv_aspect_ratio(res)
          lrv_v_codec = c.video_codec
        else
          lrv = "NO"
          lrv_w = ""
          lrv_h = ""
          lrv_fr = ""
          lrv_br = ""
          lrv_sr = ""
          lrv_a_codec = ""
          lrv_a_ch = ""
          lrv_cspace = ""
          lrv_ratio = ""
          lrv_v_codec = ""
        end

        # THM existence
        thm = c.has_thm?(res, fps) == true ? "YES" : "NO"

        # Format and print the output
        # nil values are replaced by "UNK"
        # Empty strings ("") are preserved
        format = [label, w, h, fr, br, lvl, a_kbps, a_codec, a_ch, a_sr,
          cspace, ratio, v_codec, 
          lrv, lrv_w, lrv_h, lrv_fr, lrv_br, lrv_sr, lrv_a_codec, lrv_a_ch,
          lrv_cspace, lrv_ratio, lrv_v_codec,
          thm]
        format.map! { |m| m == nil ? "UNK" : m }
        puts format.join(", ")
      }
    }
  }
end

if __FILE__ == $0
  $LOGLEVEL = $LL_WARN
  c = get_cam(ARGV[0])
  do_dump(c, "NTSC")
  do_dump(c, "PAL")
end
