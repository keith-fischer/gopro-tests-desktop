require 'fileutils'
require 'optparse'
require_relative '../libs/host_utils'


if __FILE__ == $0
	$LOG_LEVEL = $LL_VERB
	options = {}
	options[:project]	= "banzai"
	options[:branch]	= "continuous"
	options[:build]  	= nil
	options[:mount]		= nil

	op = OptionParser.new do |opts|
    opts.banner = "Usage: ruby download-build.rb -p [PROJECT] -b [BRANCH] -h"
    opts.on("-p", "--project PROJ", "Req'd: Project (e.g. banzai)") \
    { |o| options[:project] = o }
    opts.on("-b", "--branch BRANCH", "Req'd: Branch [CONTINUOUS|RELEASE]") \
    { |o| options[:branch] = o }
    opts.on("-u", "--build BUILD", "Opt: Build (e.g. 604, 25)") \
    { |o| options[:build] = o }
    opts.on("-m", "--mount DIR", "Req'd: Mount point of SD card (e.g. /media/3363-8234)") \
    { |o| options[:mount] = o }
    opts.on("-h", "--help", "Display this message and exit") { puts op }
  end
  op.parse!(ARGV)

  prj = options[:project]
  branch = options[:branch]
  build = options[:build]
  mount_dir = options[:mount]

  if [prj, branch, mount_dir].include?(nil)
  	puts "Must specify project, branch, and mount directory"
  	exit 1
  end

  if not File.directory?(mount_dir)
  	puts "Unable to find mount directory"
  	exit 1
  end
  update_dir = File.join(mount_dir, "update")

  url = nil
  if prj.downcase == "banzai"
  	if branch.downcase == "continuous"
  		url_base = "http://goprofwbuild1.gopro.lcl:8080/job/Banzai-Continuous"
  		if build != nil
  			url = url_base + "/#{build}/artifact/BANZAI/build/hawaii/Release/"
  		else
  			url = url_base + "/lastSuccessfulBuild/artifact/BANZAI/build/hawaii/Release/"
  		end
  	elsif branch.downcase == "release"
  		url_base = "http://goprofwbuild1.gopro.lcl:8080/job/Banzai-Release"
  		if build != nil
  			url = url_base + "/#{build}/artifact/BANZAI/build/hawaii/Release/"
  		else
  			url = url_base + "/lastSuccessfulBuild/artifact/BANZAI/build/hawaii/Release/"
  		end
  	else
  		puts "Unrecognized branch '#{branch}' should be one of [continuous|release]"
  	end
  else
  	puts "Unrecognized project '#{prj}' should be one of [banzai]"
  end

  if url == nil
  	puts "No valid URL could be created"
  	exit 1
  end

  # Do the work
  FileUtils.mkdir(update_dir) if not File.directory?(update_dir)
  host = Host.new()

  # Get the camera_firmware.bin file.
  cam_fw_file = File.join(update_dir, "camera_firmware.bin")
  if File.exists?(cam_fw_file)
  	puts "Deleting existing camera_firmware.bin"
  	File.delete(cam_fw_file)
  end
  puts "Downloading camera_firmware.bin"
  host.wget("#{url}camera_firmware.bin", cam_fw_file)

  # Get the camera_loaders.bin file.
  cam_loaders_file = File.join(update_dir, "camera_loaders.bin")
  if File.exists?(cam_loaders_file)
    puts "Deleting existing camera_loaders.bin"
    File.delete(cam_loaders_file)
  end
  puts "Downloading camera_loaders.bin"
  host.wget("#{url}camera_loaders.bin", cam_loaders_file)

  # Create a hd4_update.txt file.
  puts "Copying hd4_update.txt" # Why not downloading?
  update_txt = File.join("/tmp", "hd4_update.txt")
  File.open(update_txt, "w") { |f|
    f.puts("OPTIONS:10\r\nCAMERA:1\r\nHIBER:1\r\n\r\n")
  }
  host.copy_file(update_txt, update_dir)

  puts "All done!"
end
