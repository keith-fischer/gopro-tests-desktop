/*
 * Author: NagaChaitanya Vellanki
 *
 *   Prints the Atoms of a MP4 files
 */

#include "mp4_meta.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

bool json = false;
char *atom = NULL;

void printUsage() {
  printf("Usage: mp4_meta [-ajh] FILE1 FILE2 FILE3 ...\n");
  printf("    The following options are available:\n");
  printf("        -a ATOM_NAME (TODO) To print a particular atom \n");
  printf("        -h To display the usage\n");
  printf("        -j (TODO) To dump the data in JSON format, default print to "
         "stdout\n");
}

void validateArgs(int argc, char *argv[]) {
  int opt;
  while ((opt = getopt(argc, argv, "a:hj")) != -1) {
    switch (opt) {
    case 'a':
      atom = optarg;
      printf("printing the atom: %s\n", atom);
      break;
    case 'j':
      json = true;
      break;
    case 'h':
      printUsage();
      exit(EXIT_SUCCESS);
    case '?':
      printUsage();
      exit(EXIT_FAILURE);
    }
  }

  if (argc == 1) {
    printUsage();
    exit(EXIT_FAILURE);
  }

  for (int i = optind; i < argc; i++) {
    parseFile(argv[i], atom, json);
  }
}

int main(int argc, char *argv[]) {
  json = false;
  atom = NULL;
  validateArgs(argc, argv);
  exit(EXIT_SUCCESS);
}
