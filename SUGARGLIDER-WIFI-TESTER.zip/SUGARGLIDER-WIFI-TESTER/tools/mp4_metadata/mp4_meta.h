/*
 * Author: NagaChaitanya Vellanki
 *
 *   Prints the Atoms of a MP4 files
 */

#ifndef MP4_META_H
#define MP4_META_H

#define ATOM_HEADER_SIZE 8
#define MAX_STR_BUF_SIZE 4000

#include "json.h"
#include <stdbool.h>
#include <stddef.h>

typedef unsigned char byte;

static const byte FTYP_TYPE[] = {'f', 't', 'y', 'p'};
static const byte MDAT_TYPE[] = {'m', 'd', 'a', 't'};
static const byte MOOV_TYPE[] = {'m', 'o', 'o', 'v'};
static const byte MOOV_MVHD_TYPE[] = {'m', 'v', 'h', 'd'};
static const byte MOOV_IODS_TYPE[] = {'i', 'o', 'd', 's'};
static const byte MOOV_TRAK_TYPE[] = {'t', 'r', 'a', 'k'};
static const byte MOOV_UDTA_TYPE[] = {'u', 'd', 't', 'a'};
static const byte UDTA_GURI_TYPE[] = {'G', 'U', 'R', 'I'};
static const byte UDTA_GUSI_TYPE[] = {'G', 'U', 'S', 'I'};
static const byte TRAK_TKHD_TYPE[] = {'t', 'k', 'h', 'd'};
static const byte TRAK_TREF_TYPE[] = {'t', 'r', 'e', 'f'};
static const byte TREF_TMCD_TYPE[] = {'t', 'm', 'c', 'd'};
static const byte TRAK_EDTS_TYPE[] = {'e', 'd', 't', 's'};
static const byte TRAK_MDIA_TYPE[] = {'m', 'd', 'i', 'a'};
static const byte EDTS_ELST_TYPE[] = {'e', 'l', 's', 't'};

struct HEADER {
  byte size[4];
  byte name[4];
};
typedef struct HEADER HEADER;

struct MVHD_HEADER {
  byte size[4];
  byte name[4];
  byte version;
  byte flags[3];
};
typedef struct MVHD_HEADER MVHD_HEADER;

struct MVHD {
  byte creation_time[4];
  byte modification_time[4];
  byte time_scale[4];
  byte duration[4];
  byte preferred_rate[4];
  byte preferred_volume[2];
  byte reserved[10];
  byte matrix_structure[36];
  byte preview_time[4];
  byte preview_duration[4];
  byte poster_time[4];
  byte selection_time[4];
  byte selection_duration[4];
  byte current_time[4];
  byte next_track_id[4];
};
typedef struct MVHD MVHD;

const static char *MVHD_ATOM_DATA_CHARS[15] = {
    "Creation Time",      "Modification Time", "Time Scale",
    "Duration",           "Preferred Rate",    "Preferred Volume",
    "Reserved",           "Matrix Structure",  "Preview Time",
    "Preview Duration",   "Poster Time",       "Selection Time",
    "Selection Duration", "Current Time",      "Next Track ID"};

struct TKHD_HEADER {
  byte size[4];
  byte name[4];
  byte version;
  byte flags[3];
};
typedef struct TKHD_HEADER TKHD_HEADER;

const static unsigned int MVHD_ATOM_DATA_OFFSETS[15][2] = {
    {0, 4},  {4, 4},  {8, 4},  {12, 4}, {16, 4}, {20, 2}, {22, 10}, {32, 36},
    {68, 4}, {72, 4}, {76, 4}, {80, 4}, {84, 4}, {88, 4}, {92, 4}};

const static char *TKHD_ATOM_DATA_CHARS[15] = {
    "Creation Time", "Modification Time", "Track ID",
    "Reserved",      "Duration",          "Reserved",
    "Layer",         "Alternative Group", "Volume",
    "Reserved",      "Matrix Structure",  "Track Width",
    "Track Height"};

struct TKHD {
  byte creation_time[4];
  byte modification_time[4];
  byte track_id[4];
  byte reserved1[4];
  byte duration[4];
  byte reserved2[8];
  byte layer[2];
  byte alternative_group[2];
  byte volume[2];
  byte reserved3[2];
  byte matrix[36];
  byte track_width[4];
  byte track_height[4];
};
typedef struct TKHD TKHD;

const static unsigned int TKHD_ATOM_DATA_OFFSETS[13][2] = {
    {0, 4},  {4, 4},  {8, 4},  {12, 4},  {16, 4}, {20, 8}, {28, 2},
    {30, 2}, {32, 2}, {34, 2}, {36, 36}, {72, 4}, {76, 4}};

struct FTYP {
  byte major_brand[4];
  byte minor_version[4];
  byte comp_brand[4];
};
typedef struct FTYP FTYP;

unsigned int bytesToInt(byte *buf);
void printHex(byte *buf, int len);
void printChars(byte *buf, int len);
void byteToHexString(char **str, int str_len, byte *buf, int len);
void byteToString(char **str, int str_len, byte *buf, int len);

void printHeader(void *buf);
void printMOOVAtom(void *buf, unsigned int atom_size);
void printMVHDAtom(void *buf);
void printFTYPAtom(void *buf);
void printTRAKAtom(void *buf);
void printTKHDAtom(void *buf);

json_object *jsonFTYPAtom(void *buf, unsigned int atom_size);
json_object *jsonMOOVAtom(void *buf, unsigned int atom_size);
json_object *jsonMVHDAtom(void *buf);
json_object *jsonUDTAAtom(void *buf);
json_object *jsonTRAKAtom(void *buf);
json_object *jsonTKHDAtom(void *buf);

FTYP *parseFTYPAtom(void *buf);
void printDashes(void);
void parseFile(char *file_name, char *atom, bool json);

#endif
