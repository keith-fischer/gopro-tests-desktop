set -x
wget https://s3.amazonaws.com/json-c_releases/releases/json-c-0.10.tar.gz
tar -xvzf json-c-0.10.tar.gz
cd json-c-0.10
./configure
make
sudo make install
sudo cp json_object_iterator.h /usr/local/include/json
