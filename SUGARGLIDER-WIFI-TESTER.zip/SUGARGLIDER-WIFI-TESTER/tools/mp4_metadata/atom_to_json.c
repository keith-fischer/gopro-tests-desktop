/*
* Author: NagaChaitanya Vellanki
*
*   Prints the Atoms of a MP4 files
*/

#include "mp4_meta.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void byteToHexString(char **str, int str_len, byte *buf, int len) {
  memset(*str, 0, str_len);
  for (int i = 0; i < len; i++) {
    if (i != (len - 1)) {
      sprintf(*str + strlen(*str), "%02x ", buf[i]);
    } else {
      sprintf(*str + strlen(*str), "%02x", buf[i]);
    }
  }
}

void byteToString(char **str, int str_len, byte *buf, int len) {
  memset(*str, 0, str_len);
  for (int i = 0; i < len; i++) {
    sprintf(*str + strlen(*str), "%c", buf[i]);
  }
}

json_object *jsonTKHDAtom(void *buf) {
  byte *data = (byte *)(buf);
  char *temp = (char *)malloc(MAX_STR_BUF_SIZE);
  json_object *jobj;
  jobj = json_object_new_object();
  json_object_object_add(jobj, "Atom Size",
                         json_object_new_int64(bytesToInt(buf)));
  json_object_object_add(jobj, "Atom Type",
                         json_object_new_string_len((char *)TRAK_TKHD_TYPE, 4));

  if (temp != NULL) {
    byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 8, 1);
    json_object_object_add(jobj, "Version", json_object_new_string(temp));

    byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 9, 3);
    json_object_object_add(jobj, "Flags", json_object_new_string(temp));

    data += 12;
    for (int i = 0; i < 13; i++) {
      byteToHexString(&temp, MAX_STR_BUF_SIZE,
                      data + TKHD_ATOM_DATA_OFFSETS[i][0],
                      TKHD_ATOM_DATA_OFFSETS[i][1]);
      json_object_object_add(jobj, TKHD_ATOM_DATA_CHARS[i],
                             json_object_new_string(temp));
    }

    free(temp);
  }
  return jobj;
}

json_object *jsonMVHDAtom(void *buf) {
  json_object *jobj;
  jobj = json_object_new_object();
  byte *data = (byte *)(buf);
  json_object_object_add(jobj, "Atom Size",
                         json_object_new_int64(bytesToInt(data)));
  json_object_object_add(jobj, "Atom Type",
                         json_object_new_string_len((char *)MOOV_MVHD_TYPE, 4));
  char *temp = (char *)malloc(MAX_STR_BUF_SIZE);
  if (temp != NULL) {

    byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 8, 1);
    json_object_object_add(jobj, "Version", json_object_new_string(temp));

    byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 9, 3);
    json_object_object_add(jobj, "Flags", json_object_new_string(temp));

    data += 12;
    for (int i = 0; i < 15; i++) {
      byteToHexString(&temp, MAX_STR_BUF_SIZE,
                      data + MVHD_ATOM_DATA_OFFSETS[i][0],
                      MVHD_ATOM_DATA_OFFSETS[i][1]);
      json_object_object_add(jobj, MVHD_ATOM_DATA_CHARS[i],
                             json_object_new_string(temp));
    }
    free(temp);
  }

  return jobj;
}

json_object *jsonUDTAAtom(void *buf) {
  byte *data = (byte *)(buf);
  json_object *jobj;
  jobj = json_object_new_object();
  char *temp = (char *)malloc(MAX_STR_BUF_SIZE);
  json_object_object_add(jobj, "Atom Size",
                         json_object_new_int64(bytesToInt(data)));
  json_object_object_add(jobj, "Atom Type",
                         json_object_new_string_len((char *)MOOV_UDTA_TYPE, 4));
  unsigned int atom_size = bytesToInt(data);
  byte *pos = (byte *)buf + atom_size;
  data += 8;
  if (temp != NULL) {
    while (data < pos) {
      atom_size = bytesToInt(data);
      json_object *jobj_temp = json_object_new_object();
      json_object_object_add(jobj_temp, "Atom Size",
                             json_object_new_int64(bytesToInt(data)));
      json_object_object_add(jobj_temp, "Atom Type",
                             json_object_new_string_len((char *)data + 4, 4));

      if (memcmp(data + 4, UDTA_GURI_TYPE, 4) == 0) {
        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 8, 8);
        json_object_object_add(jobj_temp, "Primary Backpack ESN",
                               json_object_new_string(temp));

        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 16, 1);
        json_object_object_add(jobj_temp, "Rig Type",
                               json_object_new_string(temp));

        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 17, 3);
        json_object_object_add(jobj_temp, "Rig Firmware Version",
                               json_object_new_string(temp));

        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 20, 2);
        json_object_object_add(jobj_temp, "Rig Size",
                               json_object_new_string(temp));

        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 22, 2);
        json_object_object_add(jobj_temp, "Node ID",
                               json_object_new_string(temp));

      } else if (memcmp(data + 4, UDTA_GUSI_TYPE, 4) == 0) {
        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 8, 2);
        json_object_object_add(jobj_temp, "Primary Camera Shot Number",
                               json_object_new_string(temp));
        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 10, 8);
        json_object_object_add(jobj_temp, "Primary Camera ESN",
                               json_object_new_string(temp));

        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 18, 4);
        json_object_object_add(jobj_temp, "Backpack Timestamp at Capture Start",
                               json_object_new_string(temp));

        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 22, 2);
        json_object_object_add(jobj_temp, "Chapter Number",
                               json_object_new_string(temp));
      }
      byteToHexString(&temp, MAX_STR_BUF_SIZE, data, atom_size);
      json_object_object_add(jobj_temp, "Raw", json_object_new_string(temp));

      byteToString(&temp, MAX_STR_BUF_SIZE, data + 4, 4);
      json_object_object_add(jobj, temp, jobj_temp);
      data += atom_size;
    }
    free(temp);
  }

  return jobj;
}

json_object *jsonTRAKAtom(void *buf) {
  json_object *jobj;
  jobj = json_object_new_object();
  char *temp = (char *)malloc(MAX_STR_BUF_SIZE);
  unsigned int atom_size = bytesToInt(buf);
  byte *data = (byte *)buf;
  byte *pos = data + atom_size;
  json_object_object_add(jobj, "Atom Size", json_object_new_int64(atom_size));
  json_object_object_add(jobj, "Atom Type",
                         json_object_new_string_len((char *)MOOV_TRAK_TYPE, 4));
  data += 8;
  if (temp != NULL) {
    while (data < pos) {
      atom_size = bytesToInt(data);
      if (memcmp(data + 4, TRAK_TKHD_TYPE, 4) == 0) {
        json_object *jsonTKHD = jsonTKHDAtom(data);
        byteToHexString(&temp, MAX_STR_BUF_SIZE, data + 8, atom_size - 8);
        json_object_object_add(jsonTKHD, "Raw", json_object_new_string(temp));
        json_object_object_add(jobj, "TKHD", jsonTKHD);
      } else if (memcmp(data + 4, TRAK_TREF_TYPE, 4) == 0) {

      } else if (memcmp(data + 4, TRAK_EDTS_TYPE, 4) == 0) {
      }
      data += atom_size;
    }
    free(temp);
  }

  return jobj;
}

json_object *jsonMOOVAtom(void *buf, unsigned int atom_size) {
  json_object *jsonTRAKArr = json_object_new_array();
  json_object *jobj;
  jobj = json_object_new_object();
  json_object_object_add(jobj, "Atom Size", json_object_new_int64(atom_size));
  json_object_object_add(jobj, "Atom Type",
                         json_object_new_string_len((char *)MOOV_TYPE, 4));
  byte *data = (byte *)buf;
  byte *pos = data + atom_size;
  while (data < pos) {
    if (memcmp(data + 4, MOOV_MVHD_TYPE, 4) == 0) {
      json_object *jsonMVHD = jsonMVHDAtom(data);
      json_object_object_add(jobj, "MVHD", jsonMVHD);
    } else if (memcmp(data + 4, MOOV_UDTA_TYPE, 4) == 0) {
      json_object *jsonUDTA = jsonUDTAAtom(data);
      json_object_object_add(jobj, "UDTA", jsonUDTA);
    } else if (memcmp(data + 4, MOOV_IODS_TYPE, 4) == 0) {
    } else if (memcmp(data + 4, MOOV_TRAK_TYPE, 4) == 0) {
      json_object *jsonTRAK = jsonTRAKAtom(data);
      json_object_array_add(jsonTRAKArr, jsonTRAK);
    } else {
      break;
    }
    data += bytesToInt(data);
  }
  json_object_object_add(jobj, "TRAK", jsonTRAKArr);
  return jobj;
}

json_object *jsonFTYPAtom(void *buf, unsigned int atom_size) {
  json_object *jobj;
  jobj = json_object_new_object();
  char *temp = (char *)malloc(MAX_STR_BUF_SIZE);
  if (temp != NULL) {
    json_object_object_add(jobj, "Atom Size", json_object_new_int64(atom_size));
    json_object_object_add(jobj, "Atom Type",
                           json_object_new_string_len((char *)FTYP_TYPE, 4));
    byteToString(&temp, MAX_STR_BUF_SIZE, buf, 4);
    json_object_object_add(jobj, "Major Brand", json_object_new_string(temp));
    byteToHexString(&temp, MAX_STR_BUF_SIZE, buf + 4, 4);
    json_object_object_add(jobj, "Minor Version", json_object_new_string(temp));
    byteToString(&temp, MAX_STR_BUF_SIZE, buf + 8, 4);
    json_object_object_add(jobj, "Compatible Brand",
                           json_object_new_string(temp));
    byteToHexString(&temp, MAX_STR_BUF_SIZE, buf, 12);
    json_object_object_add(jobj, "Raw", json_object_new_string(temp));
    free(temp);
  }

  return jobj;
}
