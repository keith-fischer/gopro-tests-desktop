/*
* Author: NagaChaitanya Vellanki
*
*   Prints the Atoms of a MP4 files
*/

#include "mp4_meta.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void printHex(byte *buf, int len) {
  printf("(hex)");
  for (int i = 0; i < len; i++) {
    printf(" %02x", buf[i]);
  }
  printf("\n");
}

void printChars(byte *buf, int len) {
  for (int i = 0; i < len; i++) {
    printf("%c", buf[i]);
  }
  printf("\n");
}

void printHeader(void *buf) {
  HEADER *header = (HEADER *)buf;
  printf("Atom Name: ");
  printChars(header->name, 4);
  printf("Atom Size: ");
  printf(" (%u bytes) ", bytesToInt(header->size));
  printHex(header->size, 4);
}

void printDashes(void) {
  printf("-----------------------------------------------------------------\n");
}

unsigned int bytesToInt(byte *buf) {
  unsigned int b1 = (buf[0] << 24);
  unsigned int b2 = (buf[1] << 16);
  unsigned int b3 = (buf[2] << 8);
  unsigned int b4 = buf[3];
  return (b1 | b2 | b3 | b4);
}

void printUDTAAtom(void *buf) {
  printDashes();
  printf("UDTA:\n");
  printHeader(buf);
  byte *data = (byte *)(buf);
  unsigned int atom_size = bytesToInt(data);
  byte *pos = (byte *)buf + atom_size;
  data += 8;
  while (data < pos) {
    atom_size = bytesToInt(data);
    printChars(data + 4, 4);
    printHeader(data);
    if (memcmp(data + 4, UDTA_GURI_TYPE, 4) == 0) {
      printf("Primary Backpack ESN: ");
      printHex(data + 8, 8);
      printf("Rig Type: ");
      printHex(data + 16, 1);
      printf("Rig Firmware Version: ");
      printHex(data + 17, 3);
      printf("Rig Size: ");
      printHex(data + 20, 2);
      printf("Node ID: ");
      printHex(data + 22, 2);
    } else if (memcmp(data + 4, UDTA_GUSI_TYPE, 4) == 0) {
      printf("Primary Camera Shot Number: ");
      printHex(data + 8, 2);
      printf("Primary Camera ESN: ");
      printHex(data + 10, 8);
      printf("Backpack Timestamp at Capture Start: ");
      printHex(data + 18, 4);
      printf("Chapter Number: ");
      printHex(data + 22, 2);
    }
    printHex(data, atom_size);
    data += atom_size;
  }
  printDashes();
}

void printTKHDAtom(void *buf) {
  byte *data = (byte *)(buf);
  printf("TKHD:\n");
  printf("Atom Size: ");
  printHex(data, 4);
  printf("Atom Name: ");
  printChars(data + 4, 4);
  printf("Version: ");
  printHex(data + 8, 1);
  printf("Flags: ");
  printHex(data + 9, 3);
  data += 12;
  for (int i = 0; i < 13; i++) {
    printf("%s:", TKHD_ATOM_DATA_CHARS[i]);
    if ((strcmp(TKHD_ATOM_DATA_CHARS[i], "Creation Time") == 0) ||
        (strcmp(TKHD_ATOM_DATA_CHARS[i], "Modification Time") == 0)) {
      unsigned int mac_seconds =
          bytesToInt(data + TKHD_ATOM_DATA_OFFSETS[i][0]);
      mac_seconds = mac_seconds - 2082844800;
      time_t seconds = mac_seconds;
      printf(" %s", asctime(gmtime(&seconds)));
    }
    printHex(data + TKHD_ATOM_DATA_OFFSETS[i][0], TKHD_ATOM_DATA_OFFSETS[i][1]);
  }

  printDashes();
}

void printMVHDAtom(void *buf) {
  byte *data = (byte *)(buf);
  printf("MVHD:\n");
  printf("Atom Size: ");
  printHex(data, 4);
  printf("Atom Name: ");
  printChars(data + 4, 4);
  printf("Version: ");
  printHex(data + 8, 1);
  printf("Flags: ");
  printHex(data + 9, 3);
  data += 12;
  unsigned int time_scale = 0;
  for (int i = 0; i < 15; i++) {
    printf("%s:", MVHD_ATOM_DATA_CHARS[i]);
    if (strcmp(MVHD_ATOM_DATA_CHARS[i], "Time Scale") == 0) {
      time_scale = bytesToInt(data + MVHD_ATOM_DATA_OFFSETS[i][0]);
    }
    if (strcmp(MVHD_ATOM_DATA_CHARS[i], "Duration") == 0) {
      printf(" (secs) %.5f ", bytesToInt(data + MVHD_ATOM_DATA_OFFSETS[i][0]) /
                                  (float)time_scale);
    }
    if ((strcmp(MVHD_ATOM_DATA_CHARS[i], "Creation Time") == 0) ||
        (strcmp(MVHD_ATOM_DATA_CHARS[i], "Modification Time") == 0)) {
      unsigned int mac_seconds =
          bytesToInt(data + MVHD_ATOM_DATA_OFFSETS[i][0]);
      mac_seconds = mac_seconds - 2082844800;
      time_t seconds = mac_seconds;
      printf(" %s", asctime(gmtime(&seconds)));
    }
    printHex(data + MVHD_ATOM_DATA_OFFSETS[i][0], MVHD_ATOM_DATA_OFFSETS[i][1]);
  }
}

void printTRAKAtom(void *buf) {
  unsigned int atom_size = bytesToInt(buf);
  byte *data = (byte *)buf;
  byte *pos = data + atom_size;
  printf("TRAK:\n");
  printHeader(buf);
  data += 8;
  while (data < pos) {
    if (memcmp(data + 4, TRAK_TKHD_TYPE, 4) == 0) {
      printTKHDAtom(data);
    } else if (memcmp(data + 4, TRAK_TREF_TYPE, 4) == 0) {

    } else if (memcmp(data + 4, TRAK_EDTS_TYPE, 4) == 0) {
    }
    data += bytesToInt(data);
  }
}

void printMOOVAtom(void *buf, unsigned int atom_size) {

  byte *data = (byte *)buf;
  byte *pos = data + atom_size;
  while (data < pos) {
    if (memcmp(data + 4, MOOV_MVHD_TYPE, 4) == 0) {
      printMVHDAtom(data);
    } else if (memcmp(data + 4, MOOV_UDTA_TYPE, 4) == 0) {
      printUDTAAtom(data);
    } else if (memcmp(data + 4, MOOV_IODS_TYPE, 4) == 0) {
    } else if (memcmp(data + 4, MOOV_TRAK_TYPE, 4) == 0) {
      printTRAKAtom(data);
    } else {
      break;
    }
    data += bytesToInt(data);
  }
}

FTYP *parseFTYPAtom(void *buf) {
  FTYP *ftyp = (FTYP *)buf;
  return ftyp;
}

void printFTYPAtom(void *buf) {
  FTYP *ftyp = parseFTYPAtom(buf);
  printDashes();
  printf("FTYP: \n");
  printf("Major Brand: ");
  printChars(ftyp->major_brand, 4);
  printf("Minor Version: ");
  printHex(ftyp->minor_version, 4);
  printf("Compatible Brand: ");
  printChars(ftyp->comp_brand, 4);
  printHex(buf, 12);
  printDashes();
}

void parseFile(char *file_name, char *atom, bool json) {
  json_object *jobj = NULL;
  if (json) {
    jobj = json_object_new_object();
    json_object_object_add(jobj, "File Name",
                           json_object_new_string(file_name));
  } else {
    printf("Parsing %s\n\n", file_name);
  }

  FILE *fp;
  fp = fopen(file_name, "rb");
  if (fp != NULL) {
    while (!feof(fp)) {
      byte buf[ATOM_HEADER_SIZE] = {0};
      if (ATOM_HEADER_SIZE != fread(buf, sizeof(byte), ATOM_HEADER_SIZE, fp)) {
        break;
      }

      unsigned int atom_size = bytesToInt(buf);
      void *data = malloc(atom_size - ATOM_HEADER_SIZE);

      if (data != NULL) {
        fread(data, sizeof(byte), atom_size - ATOM_HEADER_SIZE, fp);
        if (memcmp(buf + 4, FTYP_TYPE, 4) == 0) {

          if (json) {
            json_object *jFTYP = jsonFTYPAtom(data, atom_size);
            json_object_object_add(jobj, "FTYP", jFTYP);
          } else {
            printFTYPAtom(data);
          }
        } else if (memcmp(buf + 4, MOOV_TYPE, 4) == 0) {
          if (json) {
            struct json_object *jMOOV = jsonMOOVAtom(data, atom_size);
            json_object_object_add(jobj, "MOOV", jMOOV);
          } else {
            printMOOVAtom(data, atom_size);
          }
        }
        free(data);
      }
    }
    if (json) {
      printf("%s",
             json_object_to_json_string_ext(jobj, JSON_C_TO_STRING_PRETTY));
      json_object_put(jobj);
    }
    fclose(fp);
  }
}
