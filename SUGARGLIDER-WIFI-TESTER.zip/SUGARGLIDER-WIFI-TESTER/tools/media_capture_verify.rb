class Media_Capture_Verify

  #############################################
  # Load json
  # Iterate files
  # check if file is found in json
  # read meta data
  # read tags
  # update into json
  # validate within tolerance
  # delete out-of -tolerance spec files
  #############################################



  #############################################
  # Execution starts here
  if __FILE__ == $0
    $LOGLEVEL = $LL_INFO
    debugMsg = ''
    begin
      if Dir.exists?('/run/user/1000/gvfs/smb-share:server=pc-sqasd,share=automation2/ImageRepo')
        puts 'TRUE Image repo dir exists'
      else
        puts 'FALSE Image repo dir exists'
      end
    rescue StandardError => e
      t.log_error(e.to_s)

    end
  end
end
