require 'serialport'
require 'optparse'
require_relative '../libs/multimeter'

# Capture modes for each camera model.
# Comment out as needed for spot-testing / avoiding problematic modes.
# The RES/FPS/FOV names here are standard.
#
# RES must be one of:
# "WVGA", "720", "960", "1080", "1440", "2.7K", "4K", "2.7K_FS", "2.7K_CIN", 
# "4K_CIN", "1080_SUPER", "720_SUPER", "2.7K_SUPER", "4K_SUPER"
#
# FPS and FOV are pretty self-explanatory.
#

BACKDOOR_NTSC = [
  "4K/15/W",
  "2.7K/24/W",
  "2.7K/24/M",
  "2.7K/30/W",
  "2.7K/30/M",
  "1440/24/W",
  "1440/30/W",
  "1440/48/W",
  "1080_SUPER/24/W",
  "1080_SUPER/30/W",
  "1080_SUPER/48/W",
  "1080_SUPER/60/W",
  "1080/24/W",
  "1080/24/M",
  "1080/24/N",
  "1080/30/W",
  "1080/30/M",
  "1080/30/N",
  "1080/48/W",
  "1080/48/M",
  "1080/48/N",
  "1080/60/W",
  "1080/60/M",
  "1080/60/N",
  "960/60/W",
  "960/100/W",
  "720_SUPER/60/W",
  "720_SUPER/100/W",
  "720/30/W",
  "720/30/M",
  "720/30/N",
  "720/60/W",
  "720/60/M",
  "720/60/N",
  "720/120/W",
  "720/120/M",
  "720/120/N",
  "WVGA/240/W"]

BACKDOOR_PAL = [
  "4K/12.5/W",
  "2.7K/24/W",
  "2.7K/24/M",
  "2.7K/25/W",
  "2.7K/25/M",
  "1440/24/W",
  "1440/25/W",
  "1440/48/W",
  "1080_SUPER/24/W",
  "1080_SUPER/25/W",
  "1080_SUPER/48/W",
  "1080_SUPER/50/W",
  "1080/24/W",
  "1080/24/M",
  "1080/24/N",
  "1080/25/W",
  "1080/25/M",
  "1080/25/N",
  "1080/48/W",
  "1080/48/M",
  "1080/48/N",
  "1080/50/W",
  "1080/50/M",
  "1080/50/N",
  "960/50/W",
  "960/100/W",
  "720_SUPER/50/W",
  "720_SUPER/100/W",
  "720/25/W",
  "720/25/M",
  "720/25/N",
  "720/50/W",
  "720/50/M",
  "720/50/N",
  "720/120/W",
  "720/120/M",
  "720/120/N",
  "WVGA/240/W"]

PIPE_NTSC = [
  "4K/24/W",
  "4K/30/W",
  "4K_SUPER/24/W",
  "2.7K/24/W",
  "2.7K/24/M",
  "2.7K/30/W",
  "2.7K/30/M",
  "2.7K/48/W",
  "2.7K/48/M",
  "2.7K/60/W",
  "2.7K/60/M",
  "2.7K_SUPER/30/W",
  "2.7K_FS/30/W",
  "1440/24/W",
  "1440/30/W",
  "1440/48/W",
  "1440/60/W",
  "1440/80/W",
  "1080_SUPER/24/W",
  "1080_SUPER/30/W",
  "1080_SUPER/48/W",
  "1080_SUPER/60/W",
  "1080_SUPER/80/W",
  "1080/24/W",
  "1080/24/M",
  "1080/24/N",
  "1080/30/W",
  "1080/30/M",
  "1080/30/N",
  "1080/48/W",
  "1080/48/M",
  "1080/48/N",
  "1080/60/W",
  "1080/60/M",
  "1080/60/N",
  "1080/90/W",
  "1080/90/N",
  "1080/120/W",
  "1080/120/N",
  "960/60/W",
  "960/120/W",
  "720_SUPER/60/W",
  "720_SUPER/120/W",
  "720/30/W",
  "720/30/M",
  "720/30/N",
  "720/60/W",
  "720/60/M",
  "720/60/N",
  "720/120/W",
  "720/120/M",
  "720/120/N",
  "720/240/N",
  "WVGA/240/W"]

PIPE_PAL = [
  "4K/24/W",
  "4K/25/W",
  "4K_SUPER/24/W",
  "2.7K/24/W",
  "2.7K/24/M",
  "2.7K/25/W",
  "2.7K/25/M",
  "2.7K/50/W",
  "2.7K/50/M",
  "2.7K_SUPER/25/W",
  "2.7K_FS/25/W",
  "1440/24/W",
  "1440/25/W",
  "1440/48/W",
  "1440/50/W",
  "1440/80/W",
  "1080_SUPER/24/W",
  "1080_SUPER/25/W",
  "1080_SUPER/48/W",
  "1080_SUPER/50/W",
  "1080_SUPER/80/W",
  "1080/24/W",
  "1080/24/M",
  "1080/24/N",
  "1080/25/W",
  "1080/25/M",
  "1080/25/N",
  "1080/48/W",
  "1080/48/M",
  "1080/48/N",
  "1080/50/W",
  "1080/50/M",
  "1080/50/N",
  "1080/90/W",
  "1080/90/N",
  "1080/120/W",
  "1080/120/N",
  "960/50/W",
  "960/120/W",
  "720_SUPER/50/W",
  "720_SUPER/120/W",
  "720/25/W",
  "720/25/M",
  "720/25/N",
  "720/50/W",
  "720/50/M",
  "720/50/N",
  "720/120/W",
  "720/120/M",
  "720/120/N",
  "720/240/N",
  "WVGA/240/W"]

ROCKYPOINT_NTSC = [
  "1440/30/W", 
  "1080_SUPER/30/W",
  "1080_SUPER/48/W",
  "1080/30/W",
  "1080/30/M",
  "1080/60/W",
  "1080/60/M",
  "960/30/W",
  "960/60/W",
  "720_SUPER/30/W",
  "720_SUPER/60/W",
  "720/30/W",
  "720/30/M",
  "720/60/W",
  "720/60/M",
  "720/100/W",
  "720/100/M",
  "WVGA/120/W"]

ROCKYPOINT_PAL = [
  "1440/25/W",
  "1080_SUPER/25/W",
  "1080_SUPER/48/W",
  "1080/25/W",
  "1080/25/M",
  "1080/50/W",
  "1080/50/M",
  "960/25/W",
  "960/50/W",
  "720_SUPER/25/W",
  "720_SUPER/50/W",
  "720/25/W",
  "720/25/M",
  "720/50/W",
  "720/50/M",
  "720/100/W",
  "720/100/M",
  "WVGA/100/W"]

module Hawaii
  def delete_all()
    send_serial("t api storage all_delete")
    sleep 5.0
  end
  def set_capture_mode_video()
    send_serial("t api app mode_sub_mode video video")
    sleep 3.0
  end
  def set_video_format(fmt)
    if fmt == "NTSC"
      send_serial("t api setup video_format ntsc")
    else
      send_serial("t api setup video_format pal")
    end
    sleep 3.0
  end
  def set_capture_mode(res, fps, fov)
    set_res = {
      "WVGA"        => "wvga",
      "720"         => "720",
      "960"         => "960",
      "1080"        => "1080",
      "1440"        => "1440",
      "2.7K"        => "2.7k",
      "4K"          => "4k",
      "2.7K_FS"     => "2.7k_4:3",  # FS=Fullscreen (4:3)
      "2.7K_CIN"    => "2.7k_17:9",
      "4K_CIN"      => "4k_17:9",
      "1080_SUPER"  => "1080s",
      "720_SUPER"   => "720s",
      "2.7K_SUPER"  => "2.7ks",
      "4K_SUPER"    => "4ks",
    }[res]
    set_fov = {"W" => "wide", "M" => "medium", "N" => "narrow"}[fov]
    send_serial("t api video res_fps_fov #{set_res} #{fps} #{set_fov}")
    sleep 6.0
  end
  def start_capture()
    send_serial("t api video record_start")
  end
  def stop_capture()
    send_serial("t api video record_stop")
  end
end # end module Hawaii

module Rockypoint
  def delete_all()
    send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca DA")
    sleep 5.0
  end
  def set_capture_mode_video()
    3.times {
      send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca CM%%00")
      sleep 0.5
    }
    sleep 3.0
  end
  def set_video_format(fmt)
    3.times {
      if fmt == "NTSC"
        send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca VM%%00")
      else
        send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca VM%%01")
      end
      sleep 0.5
    }
    sleep 3.0
  end
  def set_capture_mode(res, fps, fov)
    set_res = {
      # gpsend version
      # "WVGA"        => "%00",
      # "720"         => "%01",
      # "960"         => "%02",
      # "1080"        => "%03",
      # "1440"        => "%04",
      # "1080_SUPER"  => "%09",
      # "720_SUPER"   => "%0a",
      "WVGA"        => "WVGA",
      "720"         => "720",
      "960"         => "960",
      "1080"        => "1080",
      "1440"        => "1440",
      "1080_SUPER"  => "1080S",
      "720_SUPER"   => "720S"
    }[res]
    exp_res = {
      "WVGA"        => "WVGA",
      "720"         => "720P,",
      "960"         => "960P",
      "1080"        => "1080P,",
      "1440"        => "1440",
      "1080_SUPER"  => "1080P S",
      "720_SUPER"   => "720P S"
    }[res]
    failed = true
    10.times {
      send_serial("t app video_settings")
      (failed = false; break) if expect(exp_res, timeout=0.9, limit=1.0) != nil
      #send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca VV%#{set_res}")
      send_serial("t app video_settings res #{set_res}")
      sleep(1.0)
      send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca SH%%00")
      sleep 0.5
    }
    puts "WARNING: Failed to set RES to #{res}" if failed == true

    # set_fps = {
    #     "12"    => "%00",
    #     "15"    => "%01",
    #     "24"    => "%02",
    #     "25"    => "%03",
    #     "30"    => "%04",
    #     "48"    => "%05",
    #     "50"    => "%06",
    #     "60"    => "%07",
    #     "100"   => "%08",
    #     "120"   => "%09",
    #     "240"   => "%0a",
    #     "12.5"  => "%0b"
    # }[fps]
    failed = true
    10.times {
      send_serial("t app video_settings")
      (failed = false; break) if expect(fps, timeout=0.9, limit=1.0) != nil
      #send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca FS%#{set_fps}")
      send_serial("t app video_settings fps #{fps}")
      sleep(1.0)
      send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca SH%%00")
      sleep 0.5
    }
    puts "WARNING: Failed to set FPS to #{fps}" if failed == true

    #set_fov = {"W" => "%00", "M" => "%01", "N" => "%02"}[fov]
    exp_fov = {"W" => "wide", "M" => "medium", "N" => "narrow"}[fov]
    failed = true
    10.times {
      send_serial("t app video_settings")
      (failed = false; break) if expect(exp_fov, timeout=0.9, limit=1.0) != nil
      #send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca FV%#{set_fov}")
      send_serial("t app video_settings fov #{fov}")
      sleep(3.0)
      send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca SH%%00")
      sleep 0.5
    }
    puts "WARNING: Failed to set FOV to #{fov}" if failed == true
  end #end set_capture_mode
  def start_capture()
    5.times {
      send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca SH%%01")
      sleep 0.5
    }
  end
  def stop_capture()
    5.times { 
      send_serial("lu_util exec2 /usr/local/gopro/scripts/gpsend ca SH%%00")
      sleep 1.0
    }
    sleep 5.0
  end
end

class Camera
  attr_reader :ntsc_modes, :pal_modes, :name, :build
  def initialize(dev)
    @serialport = SerialPort.new(dev, 115200)
    @release, @type, @build, @serialno = get_cam_info()
    @name = nil
    @ntsc_modes = nil
    @pal_modes = nil
    case @release
    when "HD4"
      extend Hawaii
      if @type == 1
        @name = "BACKDOOR"
        @ntsc_modes = BACKDOOR_NTSC
        @pal_modes = BACKDOOR_PAL
      elsif @type == 2
        @name = "PIPE"
        @ntsc_modes = PIPE_NTSC
        @pal_modes = PIPE_PAL
      end
    when "HD3"
      if @type == 21
        extend Rockypoint
        @name = "HALEIWA"
        @ntsc_modes = HALEIWA_NTSC
        @pal_modes = HALEIWA_PAL
      elsif @type == 22
        extend Himalayas
        @name = "HIMALAYAS"
        @ntsc_modes = HIMALAYAS_NTSC
        @pal_modes = HIMALAYAS_PAL
      end
    when "HX1"
      extend Rockypoint
      if @type == 1
        @name = "ROCKYPOINT"
        @ntsc_modes = ROCKYPOINT_NTSC
        @pal_modes = ROCKYPOINT_PAL
      end
    else
      puts "Unknown camera release: '#{@release}'.  Exiting"
      exit 1
    end
    if @name == nil or @ntsc_modes == nil or @pal_modes == nil
      puts "Unable to determine capture modes for rel=%s type=%s build=%s" \
      %[@release, @type, @build]
      exit 1
    end
    puts "name, #{@name}"
    puts "serial number, #{@serialno}"
  end # end initialize

  def get_cam_info(tries=2)
    (1..tries).each { |n|
      send_serial("cat c:\\MISC\\version.txt") # Hawaii
      sleep 0.5
      send_serial("cat d:\\MISC\\version.txt") # RP/Hal
      begin
        resp = read_serial_resp()
      rescue StandardError => e
        puts "ERROR: Unable to detect camera type."
        puts "Make sure it is on, has an SD card, and is not in power-save"
        exit
      end
      m = resp.match((/"firmware version":.*,/))
      if m != nil
        fw_ver = m[0].split(":")[1][1..-3]
        fields = fw_ver.split(".")
        cam_release = fields[0]     #HD3, HD4, HX1
        cam_type = fields[1].to_i   #1, 2, 10, 11, 21
        cam_build = fields[2..-1].join(".")  # 01.23.00
        log_info("Camera Info:")
        log_conf("release, #{cam_release}")
        log_conf("type, #{cam_type}")
        log_conf("build, #{cam_build}")
      else
        sleep(1.0)
        next if n <= tries
        log_error("Unable to determine camera model from version.txt")
        log_info("#{resp}")
        exit 1
      end
      serialno = resp.match(/serial number":"[0-9A-Z]{14}"/)[0].split(":")[1][1...-1]
      return cam_release, cam_type, cam_build, serialno
    }
  end # end get_cam_info()

  # Sends a string to the serial device
  def send_serial(s)
    log_verb("SENDING SERIAL ==> #{s}")
    @serialport.write("\r\n")
    @serialport.write(s.chomp)
    @serialport.write("\r\n")
  end

  # Returns the response if the 're' match is found.  False if otherwise.
  # The response will be all the output through time 'timeout'.
  # Time per serial port read can be controlled by setting 'limit'
  def expect(re, timeout=0.9, limit=1.0)
    # Convert all Fixnums to Strings and everything else to Regexp
    re = re.to_s if re.is_a?(Fixnum)
    re = Regexp.escape(re) if not re.is_a?(Regexp)
    start = Time.now()
    while Time.now() - start < timeout
      resp = read_serial_resp(limit)
      puts "CAMERA RESPONSE<<<<<< #{resp}" if ENV["VERBOSE"] != nil
      return resp if resp.match(re) != nil
    end
    log_debug("Expression '#{re}' not seen in #{timeout} seconds.")
    return nil
  end

  # Reads from the serial port for 'limit' seconds.
  # ALL output of interest must be received by this deadline
  def read_serial_resp(limit=1.0)
    resp = ""
    thr = Thread.new {
      while true do
        c = @serialport.getc
        resp << c
      end
    }
    result = thr.join(limit)
    thr.terminate
    # Remove invalid characters (happens a lot when board is reset)
    resp.encode!('UTF-16', 'UTF-8', :invalid => :replace, :replace => '')
    resp.encode!('UTF-8', 'UTF-16')
    # log_amba(resp)
    return resp
  end
end #end Camera class

# Sets capture mode, performs the reading, and writes the results
# Returns true on success, false on failure.
def get_multi_reading(mode, dur)
  res, fps, fov = mode.split('/')
  puts "Capturing #{dur}s video at #{res}/#{fps}/#{fov}"
  $cam.set_capture_mode(res, fps, fov)
  start_time = Time.now()
  $cam.start_capture()
  sleep 5.0
  readings = []
  $mul.clear_read_buffer() # takes 1 second by itself
  while Time.now - start_time < dur do
    val = $mul.get_reading
    readings << val
  end
  $cam.stop_capture()
  if readings != nil and readings.empty? == false
    avg = readings.reduce(:+).to_f / readings.size
    puts "Avg reading for #{res}/#{fps}/#{fov}: %01.2f#{$mul.units}" %avg
    open($fname, 'a') { |f| f.puts "%s, %s" %[mode, avg.round(2)] }
  else
    puts "WARNING: Failed to get any readings for #{mode}"
    return false
  end
  return true
end

# Just being lazy not converting all cut and pasted camera log code to 'puts'
def ltp_log(level, s)
  puts s
end

### SCRIPT STARTS HERE

# Option defaults
options = {}
options[:camport]   = nil
options[:multiport] = nil
options[:duration]  = 30
options[:outdir]    = nil
if File.directory?("/tmp")
  options[:outdir]   = "/tmp"
elsif File.directory?("C:\\Temp")
  options[:outdir]   = "C:\\Temp"
end

# Parse the command line
op = OptionParser.new do |opts|
  opts.banner = "Usage: ruby power-draw-tool.rb -c [CAMPORT] -m [METERPORT] -d [DURATION] -o [OUTPUT_DIR] -h"
  opts.on("-c", "--cam PORT", "Camera serial port (COMX, /dev/ttyUSBX)") do |o|
    options[:camport] = o
  end
  opts.on("-m", "--multimeter PORT", "MultiMeter serial port (COMX, /dev/ttyUSBX)") do |o|
    options[:multiport] = o
  end
  opts.on("-o", "--output DIR", "Output directory (default: C:\\Temp or /tmp/)") do |o|
    options[:outdir] = o
  end
  opts.on("-d", "--duration DUR", "Capture duration (default: 30 seconds") do |o|
    options[:duration] = o.to_i
  end
  opts.on("-h", "--help", "Display this message and exit") { puts op; exit }
end
op.parse!(ARGV)

# Check option validity
camport = options[:camport]
multiport = options[:multiport]
if camport == nil or multiport == nil
  puts "Must specify both camera serial port (#{camport}) " + \
       "and multimeter serial port (#{multiport})"
  puts op
  exit
end

outdir = options[:outdir]
if outdir == nil or File.directory?(outdir) == false
  puts "Unable to find output directory (#{outdir}).  Please ensure it exists."
  puts op
  exit
end

# Yes, there are a few globals.  Only used in get_multi_reading.
$cam = Camera.new(camport)
FILE_TIME_STR = "%Y-%m-%d_%H-%M-%S"
$fname = File.join(outdir, "%s-%s-%s.txt") \
%[Time.now.strftime(FILE_TIME_STR), $cam.name, $cam.build]
puts "Logging to #{$fname}"

$cam.delete_all()
$mul = Multimeter.new(multiport)
$cam.set_capture_mode_video()

$cam.set_video_format("NTSC")
$cam.ntsc_modes.each { |mode|
  get_multi_reading(mode, options[:duration])
}

$cam.set_video_format("PAL")
$cam.pal_modes.each { |mode|
  get_multi_reading(mode, options[:duration])
}
