
/*
 *  Unpublished Copyright (c) 2015 GoPro, Inc., All Rights Reserved.
 *
 *  GoPro, Inc. ("GoPro") CONFIDENTIAL
 *
 *  NOTICE: All information contained herein is, and remains the property of
 *  GoPro. The intellectual and technical concepts contained herein are
 *  proprietary to GoPro and may be covered by U.S. and Foreign Patents, patents
 *  in process, and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material is
 *  strictly forbidden unless prior written permission is obtained from GoPro.
 *  Access to the source code contained herein is hereby forbidden to anyone
 *  except current GoPro employees, managers or contractors who have executed
 *  Confidentiality and Non-disclosure agreements explicitly covering such
 *  access.
 *
 *  The copyright notice above does not evidence any actual or intended
 *  publication or disclosure of this source code, which includes information
 *  that is confidential and/or proprietary, and is a trade secret, of GoPro.
 *  ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
 *  DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
 *  CONSENT OF GOPRO IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 *  AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
 *  AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 *  DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 *  THAT IT MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 */


/**
 *
 * @gopro_profiles.h
 *
 * @brief gopro profile definitions and IDs
 *
 * @ingroup gopro_profiles
 *
 * @{
 *
 */

#ifndef GOPRO_PROFILES_H_
#define GOPRO_PROFILES_H_

/* BT SIG Assigned Short UUID for GoPro Compatible Device */
#define GP_COMPATIBLE_DEV_UUID      { 0xA5, 0xFE }

/* BT SIG Assigned Short UUID for GoPro Camera Device */
#define GP_CAMERA_UUID              { 0xA6, 0xFE }

enum UUID_ID_ENUM {
    /* The list of IDs for the GP APC Service and its characteristics */
    UUID_ID_GPAPC_SRV = 0x01,
    UUID_ID_SSID_CHAR = 0x02,
    UUID_ID_PASSWORD_CHAR = 0x03,
    UUID_ID_SWITCH_CHAR = 0x04,
    UUID_ID_STATE_CHAR = 0x05,
    UUID_ID_KEY_CHAR = 0x06,

    /* This list is for GoPro-Camera-Profile GATT Table (cam is server) */
    UUID_ID_GP_CMD_CHAR = 0x72,
    UUID_ID_GP_CMD_RESP_CHAR = 0x73,
    UUID_ID_GP_SETTINGS_CHAR = 0x74,
    UUID_ID_GP_SETTINGS_RESP_CHAR = 0x75,
    UUID_ID_GP_QUERY_CHAR = 0x76,
    UUID_ID_GP_QUERY_RESP_CHAR = 0x77,
    UUID_ID_GP_SENSOR_CHAR = 0x78,
    UUID_ID_GP_SENSOR_RESP_CHAR = 0x79,

    /* This list is for GoPro-Compatible-Device GATT Table (cam is client) */
    UUID_ID_GPC_CMD_CHAR = 0xA1,
    UUID_ID_GPC_CMD_RESP_CHAR = 0xA2,
    UUID_ID_GPC_SETTINGS_CHAR = 0xA3,
    UUID_ID_GPC_SETTINGS_RESP_CHAR = 0xA4,
    UUID_ID_GPC_QUERY_CHAR = 0xA5,
    UUID_ID_GPC_QUERY_RESP_CHAR = 0xA6,
    UUID_ID_GPC_SENSOR_CHAR = 0xA7,
    UUID_ID_GPC_SENSOR_RESP_CHAR = 0xA8,
};

/* Helper Macro to define the 128-bits GoPro UUIDs */
#define GP_UUID_CONST(UUID_ID)       { 0x1b, 0xc5, 0xd5, 0xa5, 0x02, 0x00, 0x46, 0x90, 0xe3, 0x11, 0x8d, 0xaa, UUID_ID, 0x00, 0xf9, 0xb5 }
#define GP_UUID_ID_INDEX            12 /* index of the UUID_ID in 128 bits UUID */

#endif	//GOPRO_PROFILES_H_

// @} end of gopro_profiles.h

