#ifndef Inc_mdtools
#define Inc_mdtools

// Structure that defines the known atoms used by mpeg-4 family of specifications.
typedef struct {
  char*             known_atom_name;
  char*             known_parent_atoms[5]; //max known to be tested
  unsigned int      container_state;
  int               presence_requirements;
  unsigned int      box_type;
} atomDefinition;

enum {
  PARENT_ATOM         = 0, //container atom
    SIMPLE_PARENT_ATOM  = 1,
    DUAL_STATE_ATOM     = 2, //acts as both parent (contains other atoms) & child (carries data)
    CHILD_ATOM          = 3, //atom that does NOT contain any children
    UNKNOWN_ATOM_TYPE   = 4
};

enum {
    SIMPLE_ATOM = 50,
    VERSIONED_ATOM = 51,
    EXTENDED_ATOM = 52,
    PACKED_LANG_ATOM = 53,
    UNKNOWN_ATOM = 59
};


enum {
    REQUIRED_ONCE  = 30, //means total of 1 atom per file  (or total of 1 if parent atom is required to be present)
    REQUIRED_ONE = 31, //means 1 atom per container atom; totalling many per file  (or required present if optional parent atom is present)
    REQUIRED_VARIABLE = 32, //means 1 or more atoms per container atom are required to be present
    PARENT_SPECIFIC = 33, //means (iTunes-style metadata) the atom defines how many are present; most are MAX 1 'data' atoms; 'covr' is ?unlimited?
    OPTIONAL_ONCE = 34, //means total of 1 atom per file, but not required
    OPTIONAL_ONE = 35, //means 1 atom per container atom but not required; many may be present in a file
    OPTIONAL_MANY = 36, //means more than 1 occurrence per container atom
    REQ_FAMILIAL_ONE = OPTIONAL_ONE, //means that one of the family of atoms defined by the spec is required by the parent atom
    UKNOWN_REQUIREMENTS= 38
};

#endif // Inc_mdtools

