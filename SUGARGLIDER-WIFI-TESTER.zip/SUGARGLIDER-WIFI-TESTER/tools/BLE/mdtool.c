/* mdtool.c - Metadata extractor for GoPro MP4 files
 *
 *  Usage:
 *  - mdtool -f <video file>
 *  - 'mdtool -h' prints out help/options
 *  - 'mdtool -verb' turns on verbose/debug logging
 *  - print out sensor data
 *  - print out header and other overhead info
 *
 * https://wiki.gopro.com/pages/viewpage.action?spaceKey=MET&title=Metadata+Payload+Formatting
 * TODO: detect gpmf timing and rates per sensor `(allow user settable parameters)
 * TODO: figure out why DEVC nested and longer than the data sample it itself?
 *
 * 1.4 METADATA FILE FORMAT
 *
 * Metadata is typically embedded as a text track in an MP4 or MOV container,
 * but there are applications where metadata must be stored in a separate file.
 * Although metadata tuples in the text track of a container could be concatenated together into a single binary file,
 * this would omit sample time information that is present in the container but not present in the text track.
 *
 * Recommended practice is to store samples of telemetry data from the text track
 * with additional metadata tuples that provide timing information.  Each chunk
 * of metadata corresponding to a sample from the text track should be stored
 * in the binary file as a PAYL atom that includes a PTIM atom that provides
 * the start time of the metadata chunk and a PDUR atom that provides the
 * duration of the chunk.  The start time and duration for the metadata chunk
 * should equal the start time and duration of the sample in the container.
 *
 * The binary file shall comprise the following atoms in order and nothing more:
 * A single GPMF atom with repeat count equal to 1 and containing a payload that
 * identifies the application that created the binary metadata file.
 * A single PAYH atom with repeat count equal to 1 and containing the atoms that comprise the payload file header.
 * The payload of the PAYH atom shall comprise the following atoms in any order and nothing more:
 * A single CLKN atom with repeat count equal to 1 and containing the numerator
 * of the number of clock ticks per second as an integer.
 * A single CLKD atom with repeat count equal to 1 and containing the denominator
 * of the number of clock ticks per second as an integer.
 * The payload of the PAYL atom shall comprise the following atoms in order and nothing more:
 * A single PTIM atom with repeat count equal to 1 containing the start time of the PAYL atom payload.
 * A single PDUR atom with repeat count equal to 1 containing the duration of the PAYL atom payload.
 * Zero or more DEVC atoms.
 *
 * All start times and durations should be integers in units of clock ticks provided by the CLKN and CLKD atoms.
 * The binary file should have the file extension "gpmf" (or "gpm" if and only
 * if the file system only supports three character extensions).  The "gpmf" 
 * file extension appears to not be used for any other file format.
 * The "gpm" is reported to be used for crossword puzzle files,
 * but cannot find any examples of this file or software that reads or writes this file format.
 *
 * 1.5 METADATA FILE TRANSCODING
 *
 * All atoms in the binary metadata file except the DEVC atoms shall be omitted
 * when the binary metadata file is injected into the text track of an MOV or MP4 file.
 * The payloads of the CLKN, CLKD, PTIM, and PDUR atoms shall be used to compute
 * the time and duration for the samples in the MOV or MP4 file.
 * The MOV and MP4 containers use a single atom to represent the number of clock
 * ticks per second, so that the period of the clock can never be longer than
 * one second.  The CLKD atom allows longer clock periods.
 * To simplify transcoding into MOV and MP4 containers, it is recommended that
 * the clock denominator (payload of the CLKD atom) should be 1.
 *  
 * References:
 *   Camera Metadata5 Document -> https://gopro.hostpilot.com/engineering/projects/360/Specifications/Metadata5.docx
 *   SDK - GoPro Bluetooth Low Energy v1.0.docx
 *   Metadata Requirement.docx
 *   BleMetadataDesign-0.1.docx
 */
int verbose=0;       // settable via -v <level> option
int debug=0;         // settable via -d <level> option
int show_atoms=0; // settable via -a option
int show_tags=0;  // settable via -t option
int show_raw_data=1;
int show_ramping_data=0; // settable via -sr option


#define MSGSZ 1800
#define PREAM_SZ 40
char msg1[MSGSZ];
char msg2[MSGSZ];
char *msgp=msg1;

// Key (32-bits) – FOURCC
// human readable four character names for metadata fields. Examples: of key (tag) generation. 

#define MAKETAG(d,c,b,a) (((a)<<24)|((b)<<16)|((c)<<8)|(d))  // original

// State Machine modes for looking for GPMF and Metadata
typedef enum ScanModeTypes
{
  SCAN_MODE, // look for 'moov, and 'mdat' atoms in particular, print other atoms and tags along the way
  TRAK_MODE, // look for 'trak' atom
  MDIA_MODE, // look for 'mdia' atom
  HDLR_MODE, // look for 'hdlr' atom
  GPMF_MODE, // look for 'gpmf' tag
  STBL_MODE, // look for 'stbl' atom
  STSZ_MODE, // look for 'stsz' atom
  STCO_MODE, // look for 'stco' atom
  MDAT_MODE, // look for 'mdat' atom
  DATA_MODE, // look for metadata based on stsz and stco info
} ScanModeType;
ScanModeType mode=SCAN_MODE; // start out in scan mode, exit out to scan mode when all other search modes fail

int hdlr_count=0;
int gpmf_count=0; 


// GoPro Metadata Tests
// These are bit-wise so we can run multiple tests
typedef enum TestModeTypes
{
  TEST_NONE         = 0x00000,
  GPMF_TESTS        = 0x0000F,
  TEST_GPMF_RAMPING = 0x00001,
  TEST_GPMF_NSENSORS= 0x00002,
  TEST_GPMF_TIMING  = 0x00004,
  TEST_GPMF_TAGS    = 0x00008,
  TEST_ARGUS        = 0x00010,
  TEST_KIRKWOOD     = 0x00100,
  TEST_SETTINGS     = 0x10100,

} TestModeType;
TestModeType testMode=TEST_NONE;  // default - no tests

// GPMF Tests
int gpmf_ramping_result=0;      // Test: that all sensor data within a trak(s) having sequential ramping patterns
int gpmf_tags_result=0;         // Test: that all valid tags within all gpmf structures exist
int gpmf_timing_result=0;       // Test: that timing between sensor data is consistent and at the right rate
int gpmf_nsensors_result=0;     // Test: that multiple sensors were detected
int gpmf_sensors_expected=1;   // Test: 1, otherwise assumed 2, and settable to any number > 0
int gpmf_sensors_detected=0;   // #of sensors were detected
#define MAX_SENSORS 80

typedef enum MetadataTag
{
 //function Tagtype size
 TAG_FREESPACE = MAKETAG('F','R','E','E'),//FREE c n bytes reserved for more metadata
 TAG_COLOR_MATRIX = MAKETAG('C','O','L','M'),//COLM f12 floats (4x3 matrix) 
 TAG_SATURATION = MAKETAG('S','A','T','U'),//SATU f1 float // unity 1.0 range 0 to 4
 TAG_CONTRAST = MAKETAG('C','T','R','S'),//CTRS f1 float // unity 1.0 range 0 to 4
 TAG_EXPOSURE = MAKETAG('E','X','P','S'),//EXPS f1 float // unity 1.0 range 0 to 8 
 TAG_TIMECODE = MAKETAG('T','I','M','C'),//TIMC c11 chars in format "00:00:00:00"

 TAG_ACC1 = MAKETAG('a','c','c','1'),  // device structure
 TAG_DEVC = MAKETAG('D','E','V','C'),  // device structure
 TAG_DVID = MAKETAG('D','V','I','D'),  // device/track ID
 TAG_DVNM = MAKETAG('D','V','N','M'),  // device name
 TAG_MFGI = MAKETAG('M','F','G','I'),  // 
 TAG_STRM = MAKETAG('S','T','R','M'),  // data stream
 TAG_SCAL = MAKETAG('S','C','A','L'),  // scaling factor
 TAG_SIUN = MAKETAG('S','I','U','N'),  // SI units or...
 TAG_UNIT = MAKETAG('U','N','I','T'),  // display units
 TAG_TIMO = MAKETAG('T','I','M','O'),  // time offset

 TAG_redl = MAKETAG('r','e','d','l'),
 TAG_RPMs = MAKETAG('R','P','M','S'),
 TAG_BRAK = MAKETAG('B','R','A','K'),
 TAG_MP4A = MAKETAG('m','p','4','a'),
 TAG_TMCD = MAKETAG('t','m','c','d'),
 TAG_GPMD = MAKETAG('g','p','m','d'),
 TAG_GPMF = MAKETAG('G','P','M','F'),
 TAG_SENS = MAKETAG('S','E','N','S'),  // TODO: REMOVE! this is a DUMMY tag 
 TAG_GPMFL = MAKETAG('g','p','m','f'),
 TAG_FDSC = MAKETAG('f','d','s','c'),
 TAG_AVC1 = MAKETAG('a','v','c','1'),

 /* GoPro */
 TAG_VFRH = MAKETAG('v','f','r','h'),
 TAG_GPRI = MAKETAG('g','p','r','i'),
 TAG_BPOS = MAKETAG('B','P','O','S'),
 TAG_FIRM = MAKETAG('F','I','R','M'),
 TAG_LENS = MAKETAG('L','E','N','S'),
 TAG_CAME = MAKETAG('C','A','M','E'),
 TAG_SETT = MAKETAG('S','E','T','T'),
 TAG_TIME = MAKETAG('T','I','M','E'),
 TAG_VOLT = MAKETAG('V','O','L','T'),
 TAG_GPS  = MAKETAG('G','P','S',0x0),
 TAG_OBD2 = MAKETAG('O','B','D','2'),
 TAG_GYRO = MAKETAG('G','Y','R','O'),
 TAG_AMBA = MAKETAG('A','M','B','A'),
 TAG_MUID = MAKETAG('M','U','I','D'),
 TAG_HMMT = MAKETAG('H','M','M','T'),
 TAG_BCID = MAKETAG('B','C','I','D'),

 TAG_END = MAKETAG(0x0,0x0,0x0,0x0),

} MetadataTagType;

// Type-Size-repeat ("Length") (32-bits) – Type (8-bit), Struct_Size (8-bit), Repeat (16-bit)
// Type (8-bit) -  An 'ASCII' character to definite the smallest unit of any structure
// Example 1) 8-bit character string has type 'c', a single character being smallest unit.
// Example 2) 3 16-bit Accelerometer values will have type 's', as a single value is a short.
// Data structures like in Example 2 must consist of the same Type throughout.
// Other data types:

typedef enum
{
METADATA_TYPE_STRING_ASCII = 'c', //single byte 'c' style character string
METADATA_TYPE_SIGNED_BYTE = 'b',//single byte signed number
METADATA_TYPE_UNSIGNED_BYTE = 'B', //single byte unsigned number
METADATA_TYPE_DOUBLE = 'd', //64-bit double precision float (IEEE 754)
METADATA_TYPE_FLOAT = 'f', //32-bit single precision float (IEEE 754)
METADATA_TYPE_FOURCC = 'F', //32-bit four character tag 
METADATA_TYPE_GUID = 'G', //128-bit ID (like UUID)
METADATA_TYPE_HIDDEN = 'h', //internal data not displayed (formatting not reported)
METADATA_TYPE_UNSIGNED_LONG_HEX = 'H', //32-bit integer to be displayed 0xaabbccdd
METADATA_TYPE_SIGNED_LONG = 'l',//32-bit integer
METADATA_TYPE_UNSIGNED_LONG = 'L', //32-bit integer
METADATA_TYPE_Q15_16_FIXED_POINT = 'q', // Q number Q15.16 - 16-bit signed integer (A) with 16-bit fixed point (B) for A.B value (range -32768.0 to 32767.99998). 
METADATA_TYPE_Q31_32_FIXED_POINT = 'Q', // Q number Q31.32 - 32-bit signed integer (A) with 32-bit fixed point (B) for A.B value. 
METADATA_TYPE_SIGNED_SHORT = 's',//16-bit integer
METADATA_TYPE_UNSIGNED_SHORT = 'S',//16-bit integer
METADATA_TYPE_STRING_UTF8_ = 'u', //UTF-8 formatted text string.  As the character storage size varies, the size is in bytes, not UTF characters.
METADATA_TYPE_UTC_DATE_TIME = 'U', //Date + UTC Time format yymmddhhmmss.sss - 16 bytes ASCII (years 20xx covered)
METADATA_TYPE_XML = 'x', //XML, support other systems metadata
METADATA_TYPE_COMPLEX= '?', //for sample with complex data structures, base size in bytes.  Data is either opaque, or the stream has a TYPE structure field for the sample.
METADATA_TYPE_NEST = 0, // used to nest more GPMF formatted metadata 
// Add more metadata types here
// Need to expand with multi-strings, GPS coordinate data types, etc.
} MetadataType;


int  log_fd=0;
int  logEnabled=0;      // create a log file of all messages printed
char filename[80];  // video file containing metadata
char logFile[80];      // log file name
char logDir[80];       // log directory (default is .)
char logPath[180];      // <logDir>/<logFile>
#define DEFAULT_LOGDIR "."

#include <stdlib.h> // exit(), system()
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> // sleep(), fsync()
#include <stdint.h> // uint32_t
#include <strings.h> // bzero()
#include <string.h>  // strcpy, strtok
#include <linux/types.h> // u8 u16
#include <asm/termios.h> // u8 u16

#define s8 signed char
#define s16 signed short
#define s32 signed short
#define u8 unsigned char
#define u16 unsigned short
#define u32 unsigned short
#define __IO volatile

#include "gp_ble_gatt.h"
#include "gopro_profiles.h"

#include "/usr/lib/gcc/arm-linux-gnueabihf/4.6/include/stdbool.h"
#include <stdbool.h>
#include <signal.h>
#include <wchar.h>


#include "mdtool.h"
#include "AP_AtomDefinitions.h"
int  total_known_atoms = (unsigned int)(sizeof(KnownAtoms)/sizeof(*KnownAtoms)); // needs mdtool.h & AP_AtomDefinitions.h

#define DEFAULT_FNAME "*.MP4"
#define BSZ (40280000/4*4)
       

// Forward Declarations
int trak_count=0; // current trak info
int trak_offset=0;
int trak_len=0;
int metatag_cmp(unsigned char *bufp, int taglen, char *tagname);
void gpAtomHandler();  // parse for gopro information
void printBuf(unsigned char *bptr, int nchars);
void usage();
char *getFileDate(char *fdate);
int createMetaInfoFile(char *bfile);
void chomp(const char *s);
void processArgs(int argc, char *argv[]);
int atom_check(unsigned char *boxp, unsigned int *boxlen, char *boxname);
int metatag_check(unsigned char *tagp, unsigned int *taglen, char *tagname, char *tagtype);
int dvid_to_idx(int dvid);
void mlog(char *msg);
void mlog_pre(char *msg, int skip_pre);
int mdat_offset = 0;

#define TAGLAG 4 // includes 4-byte name
#define BOXLAG 8 // includes 4-byte length and 4-byte name

char preamble[80]=".....";
int preamble_flag=0;
void mlog(char *msg)
{
  mlog_pre(msg, 0);
}
void mlog_pre(char *msg, int skip_pre)
{
  if (preamble_flag && (skip_pre!=1))
    printf(preamble);  // Preabmle goes onlyt to stdout. Logfile gets no fluff

  printf(msg);  // Preabmle goes onlyt to stdout. Logfile gets no fluff
  if (logEnabled && log_fd)
  {
    int len = strlen(msg);
    int nwrite = write(log_fd, msg, len);
  }

  if (msgp == msg1)
    msgp = msg2;
  else
    msgp = msg1;

  bzero(msgp,MSGSZ);
}

void printFatalError(char *msg, int arg1)
{
  char usrmsg[180];
  sprintf(msgp, "\n"); mlog(msgp);
  sprintf(msgp, "**************************************************************************\n"); mlog(msgp);
  sprintf(usrmsg, msg, arg1); mlog(msgp);
  sprintf(msgp, "***** %s *****\n", usrmsg); mlog(msgp);
  sprintf(msgp, "**************************************************************************\n\n"); mlog(msgp);
  exit(1);
}

unsigned int extract_4byte_uint(unsigned char *d)
{
  unsigned int ui;
  ui = ((d[0] & 0xff) << 24) | ((d[1] & 0xff) << 16) | ((d[2] & 0xff) << 8) | (d[3] & 0xff);
  return ui;
}

char *toUpperCaseN(char *s, int n)
{
  int i=0;
  while(i < n)
  {
      *s = toupper((unsigned char)*s);
      s++;
      i++;
  }
  return s;
}
char *toUpperCase(char *s)
{
  while(*s != '\0')
  {
      *s = toupper((unsigned char)*s);
      s++;
  }
  return s;
}

char *toLowerCaseN(char *str, int n)
{
  char *s = str;
  int i=0;
  while(i < n)
  {
      *s = tolower((unsigned char)*s);
      s++;
      i++;
  }
  return str;
}
char *toLowerCase(char *str)
{
  char *s = str;
  while(*s != '\0')
  {
      *s = tolower((unsigned char)*s);
      s++;
  }
  return str;
}

void printBuf(unsigned char *bptr, int nchars)
{
   int n;
   unsigned char *p = bptr;
   for (n=0; n < nchars; n++)
   {
     printf("%02x ", *p);
     // if ((n % 80) == 0)
       // printf("\n");
     p++;
   }
   // printf("\t");
   // printf("\n");
}

char *getFileDate(char *fdate)
{
  // equivalent to: system("date +%d%b%y_%H%M");
  char *cmd= "date +%d%b%y_%H%M";
  FILE *fp = popen(cmd, "r");

  fgets(fdate,20,fp);
  chomp(fdate);
  pclose(fp);
  if (debug) printf("fdate=%s\n", fdate);
  return fdate;
}

void chomp(const char *s)
{
  char *p;
  while (NULL != s && NULL != (p = strrchr(s, '\n'))){
    *p = '\0';
  }
} /* chomp */

/*
 * Place where to save output of injected metadata parser
 */
int createMetaInfoFile(char *infofile)
{
   int fd = open(infofile,  O_CREAT | O_RDWR, 0666);
   if (fd < 0)
   {
      char msg[80];
      sprintf(msg,"Error opening %s", infofile);
      perror(msg);
      exit(1);
   }
   return fd;
} // createMetaInfoFile


// given a buf ptr and length, will check to see if a tag equals the specified tagname
//
int metatag_cmp(unsigned char *bufp, int taglen, char *tagname)
{
  unsigned char *a = bufp;
  unsigned char *b = tagname;
  unsigned int tagA = MAKETAG(a[0],a[1],a[2],a[3]);
  unsigned int tagB = MAKETAG(b[0],b[1],b[2],b[3]);
  if (tagA == tagB)
    return 1;  // TRUE (found)
  else
    return 0;  // NOT found
}

// TODO!  Make sure you are boxing the tag frame correctly. SEE atom_check() bufp adjustment as example
int metatag_check(unsigned char *tagp, unsigned int *taglen, char *tagname, char *tagtype)
{
  unsigned char *b = tagp;
  unsigned int tag;
  tag = MAKETAG(b[0],b[1],b[2],b[3]);
  int found=1;

  char *s="NULL";
  if (debug>=2) printf("metatag_check=0x%x\n", tag);

  switch (tag)
  {
   case TAG_FREESPACE: s="TAG_FREESPACE"; break;
   case TAG_COLOR_MATRIX: s="TAG_COLOR_MATRIX"; break;
   case TAG_SATURATION: s="TAG_SATURATION"; break;
   case TAG_CONTRAST: s="TAG_CONTRAST"; break;
   case TAG_EXPOSURE: s="TAG_EXPOSURE"; break;
   case TAG_TIMECODE: s="TAG_TIMECODE"; break;

   case TAG_ACC1: s="TAG_ACC1"; break;
   case TAG_DEVC: s="TAG_DEVC"; break;
   case TAG_DVID: s="TAG_DVID"; break;
   case TAG_MFGI: s="TAG_MFGI"; break;
   case TAG_SCAL: s="TAG_SCAL"; break;
   case TAG_SIUN: s="TAG_SIUN"; break;
   case TAG_DVNM: s="TAG_DVNM"; break;
   case TAG_STRM: s="TAG_STRM"; break;
   case TAG_UNIT: s="TAG_UNIT"; break;
   case TAG_TIMO: s="TAG_TIMEO"; break;

   case TAG_redl: s="TAG_redl"; break;
   case TAG_RPMs: s="TAG_RPMs"; break;
   case TAG_BRAK: s="TAG_BRAK"; break;
   case TAG_MP4A: s="TAG_MP4A";break;
   case TAG_TMCD: s="TAG_TMCD";break;
   case TAG_GPMD: s="TAG_GPMD";break;
   case TAG_GPMF: s="TAG_GPMF";break;
   case TAG_SENS: s="TAG_SENS";break;  // TODO: REMOVE THIS LATER!
   case TAG_GPMFL: s="TAG_GPMFL";break;
   case TAG_FDSC: s="TAG_FDSC";break;
   case TAG_AVC1: s="TAG_AVC1";break;

   /* GoPro */
   case TAG_VFRH: s="TAG_VFRH";break; // buckhorn/kirkwood
   case TAG_GPRI: s="TAG_GPRI";break; // buckhorn/kirkwood
   case TAG_BPOS: s="TAG_BPOS";break; // buckhorn/kirkwood

   case TAG_FIRM: s="TAG_FIRM";break; 
   case TAG_LENS: s="TAG_LENS";break; 
   case TAG_CAME: s="TAG_CAME";break; 
   case TAG_SETT: s="TAG_SETT";break; 
   case TAG_TIME: s="TAG_TIME";break;
   case TAG_VOLT: s="TAG_VOLT";break;
   case TAG_GPS : s="TAG_GPS";break;
   case TAG_OBD2: s="TAG_OBD2";break;
   case TAG_GYRO: s="TAG_GYRO";break;
   case TAG_AMBA: s="TAG_AMBA";break;
   case TAG_MUID: s="TAG_MUID";break;
   case TAG_HMMT: s="TAG_HMMT";break;
   case TAG_BCID: s="TAG_BCID";break;

   default: s="UNKNOWN"; found=0;break;
  }

    /* LOWER-CASE check */
    if (!found)
    {
      unsigned int tag_lower = tag;
      toLowerCaseN((char *)&tag_lower, 4);

      found=1;
      switch (tag_lower)
      {
       case TAG_FREESPACE: s="TAG_FREESPACE"; break;
       case TAG_COLOR_MATRIX: s="TAG_COLOR_MATRIX"; break;
       case TAG_SATURATION: s="TAG_SATURATION"; break;
       case TAG_CONTRAST: s="TAG_CONTRAST"; break;
       case TAG_EXPOSURE: s="TAG_EXPOSURE"; break;
       case TAG_TIMECODE: s="TAG_TIMECODE"; break;

       case TAG_ACC1: s="TAG_ACC1"; break;
       case TAG_DEVC: s="TAG_DEVC"; break;
       case TAG_DVID: s="TAG_DVID"; break;
       case TAG_SCAL: s="TAG_SCAL"; break;
       case TAG_SIUN: s="TAG_SIUN"; break;
       case TAG_DVNM: s="TAG_DVNM"; break;
       case TAG_STRM: s="TAG_STRM"; break;
       case TAG_UNIT: s="TAG_UNIT"; break;
       case TAG_TIMO: s="TAG_TIMEO"; break;

       case TAG_redl: s="TAG_redl"; break;
       case TAG_RPMs: s="TAG_RPMs"; break;
       case TAG_BRAK: s="TAG_BRAK"; break;
       case TAG_MP4A: s="TAG_MP4A";break;
       case TAG_TMCD: s="TAG_TMCD";break;
       case TAG_GPMD: s="TAG_GPMD";break;
       case TAG_GPMF: s="TAG_GPMF";break;
       case TAG_FDSC: s="TAG_FDSC";break;
       case TAG_AVC1: s="TAG_AVC1";break;

       /* GoPro */
       case TAG_VFRH: s="TAG_VFRH";break; // buckhorn/kirkwood
       case TAG_GPRI: s="TAG_GPRI";break; // buckhorn/kirkwood
       case TAG_BPOS: s="TAG_BPOS";break; // buckhorn/kirkwood

       case TAG_FIRM: s="TAG_FIRM";break; 
       case TAG_LENS: s="TAG_LENS";break; 
       case TAG_CAME: s="TAG_CAME";break; 
       case TAG_SETT: s="TAG_SETT";break; 
       case TAG_TIME: s="TAG_TIME";break;
       case TAG_VOLT: s="TAG_VOLT";break;
       case TAG_GPS : s="TAG_GPS";break;
       case TAG_OBD2: s="TAG_OBD2";break;
       case TAG_GYRO: s="TAG_GYRO";break;
       case TAG_AMBA: s="TAG_AMBA";break;
       case TAG_MUID: s="TAG_MUID";break;
       case TAG_HMMT: s="TAG_HMMT";break;
       case TAG_BCID: s="TAG_BCID";break;

       default: s="UNKNOWN"; found=0;break;
      }
    } // if !found do  lowercase  test

    /* UPPER-CASE check */
    if (!found)
    {
      unsigned int tag_upper = tag;
      toUpperCaseN((char *)&tag_upper, 4);

      found=1;
      switch (tag_upper)
      {
       case TAG_FREESPACE: s="TAG_FREESPACE"; break;
       case TAG_COLOR_MATRIX: s="TAG_COLOR_MATRIX"; break;
       case TAG_SATURATION: s="TAG_SATURATION"; break;
       case TAG_CONTRAST: s="TAG_CONTRAST"; break;
       case TAG_EXPOSURE: s="TAG_EXPOSURE"; break;
       case TAG_TIMECODE: s="TAG_TIMECODE"; break;

       case TAG_ACC1: s="TAG_ACC1"; break;
       case TAG_DEVC: s="TAG_DEVC"; break;
       case TAG_DVID: s="TAG_DVID"; break;
       case TAG_SCAL: s="TAG_SCAL"; break;
       case TAG_SIUN: s="TAG_SIUN"; break;
       case TAG_DVNM: s="TAG_DVNM"; break;
       case TAG_STRM: s="TAG_STRM"; break;
       case TAG_UNIT: s="TAG_UNIT"; break;
       case TAG_TIMO: s="TAG_TIMEO"; break;

       case TAG_redl: s="TAG_redl"; break;
       case TAG_RPMs: s="TAG_RPMs"; break;
       case TAG_BRAK: s="TAG_BRAK"; break;
       case TAG_MP4A: s="TAG_MP4A";break;
       case TAG_TMCD: s="TAG_TMCD";break;
       case TAG_GPMD: s="TAG_GPMD";break;
       case TAG_FDSC: s="TAG_FDSC";break;
       case TAG_AVC1: s="TAG_AVC1";break;

       /* GoPro */
       case TAG_GPMF: s="TAG_GPMF";break;
       case TAG_VFRH: s="TAG_VFRH";break; // buckhorn/kirkwood
       case TAG_GPRI: s="TAG_GPRI";break; // buckhorn/kirkwood
       case TAG_BPOS: s="TAG_BPOS";break; // buckhorn/kirkwood

       case TAG_FIRM: s="TAG_FIRM";break; 
       case TAG_LENS: s="TAG_LENS";break; 
       case TAG_CAME: s="TAG_CAME";break; 
       case TAG_SETT: s="TAG_SETT";break; 
       case TAG_TIME: s="TAG_TIME";break;
       case TAG_VOLT: s="TAG_VOLT";break;
       case TAG_GPS : s="TAG_GPS";break;
       case TAG_OBD2: s="TAG_OBD2";break;
       case TAG_GYRO: s="TAG_GYRO";break;
       case TAG_AMBA: s="TAG_AMBA";break;
       case TAG_MUID: s="TAG_MUID";break;
       case TAG_HMMT: s="TAG_HMMT";break;
       case TAG_BCID: s="TAG_BCID";break;

       default: s="UNKNOWN"; found=0;break;
      }
    } // if !found do  lowercase  test


  if (found)
  {
    // printf("FOUND TAG=%s (0x%x)\n", s, tag);
    strcpy(tagname, s);
    unsigned char *b = tagp-TAGLAG;
    *tagtype = b[1];
    *taglen  = b[3];
  }
  else
  {
    *taglen = 0; // printf("TAG *NOT* found\n");
  }
  return found;

} // metatag_check()

// ASSUMPTION: boxp points to length field, next 4 bytes is name field
int atom_check(unsigned char *boxp, unsigned int *boxlen, char *boxname)
{

  char *namep = boxp+4;
  char *name;
  char tmp[5];
  int found=0;


  if ((*namep < 0x20) && (*namep > 0x7F))
    return 0;  // an atom name must start with an ASCII character

  bzero(tmp,4);
  memcpy(tmp, namep, 4);
  // name = toLowerCase(tmp);
  name = tmp;

  int n;
  for (n=0; n < total_known_atoms; n++)
  {
     if (memcmp(name, KnownAtoms[n].known_atom_name, 4) == 0)
     {
       found = 1;
       break;
     }
  }
  if (found)
  {
      memcpy(boxname, name, 4);
      boxname[4] = 0;
      unsigned char *b = boxp;
      *boxlen = ((b[0]&0xff) << 24) | ((b[1]&0xff) << 16) |  ((b[2]&0xff) << 8) | (b[3]&0xff);
      if (debug>=2)
        printf("b[0]=0x%x b[1]=0x%x b[2]=0x%x b[3]=0x%x\n", b[0], b[1], b[2], b[3]);
  }
  return found;

} // atom_check

int printNfileChars(int fd, int nchars)
{
  char *tmp = (char*)malloc(nchars);
  int n = read(fd,tmp,nchars);
  int i;
  for (i=0; i<nchars; i++)
  {
   printf("0x%02x ", tmp[i]);
  }
  printf("\n");
  free(tmp);
  lseek(fd, -n, SEEK_CUR);
  return n;
}

#define MAX_TAGNAME_LEN 10  // at least 4

struct tag
{
  char name[MAX_TAGNAME_LEN];
  unsigned int tagval;
  char type;
  int  structlen;
  int  repeat;
  int  dataLen;  // structlen * repeat
  unsigned char *data;
};

#define MAX_SAMPLE_TAGS 256  // WARNING: This is arbitrary
struct sample
{
  int size;
  unsigned int offset; // within mdat
  unsigned char* data; // The entire sample buffer including all tags/4cc info
  int numTags;
  // char sensor_name[20]; // sensor name (note: not applicable to all tags!) - initialized to ""
  // int  sensor_dvid;  // device id  (note: not applicable to all tags!) initialized to -1
  // int  sensor_idx;  // device id  (note: not applicable to all tags!) initialized to -1
  struct tag *tags[MAX_SAMPLE_TAGS];
};

struct acc1_struct
{
  int len;
  unsigned short *data;
} ACC1_DATA_STRUCT;

struct sensor
{
  int dvid;
  char name[80];
  struct acc1_struct acc1;
} sensorStruct;
struct sensor gpmf_sensor_list[MAX_SENSORS];


struct sampleList
{
  int trak_offset; // associated parent trak info
  int trak_num;

  int numSamples;
  struct sample *samples;
  int numSensors; // TODO: debatable if should be here since we have external post-processing gpmf_sensor_list
};

#define MAX_LISTS 1000
struct sampleList *sampleLists[MAX_LISTS];  // array of sample lists
int numSampleLists=0; // # lists of samples
void printSampleLists(char *desc, int numLists, struct sampleList *sls[]);

// BUG ALERT! We got one in here
int processMetaData(struct sample *sam)
{
  if (verbose>=3)
    printf("processMetaData()\n");
  unsigned char *b = sam->data;
  unsigned int tag;
  int found=1;
  int stop=0;
  char *s;

  while (stop==0)
  {
    found = 1;
    tag = MAKETAG(b[0],b[1],b[2],b[3]);
    // if (debug) printf("b - sam->dat == %d TAG=0x%x\n", (unsigned int)(b - sam->data),tag);
    switch (tag)
    {
     case TAG_FREESPACE: s="TAG_FREESPACE"; break;
     case TAG_COLOR_MATRIX: s="TAG_COLOR_MATRIX"; break;
     case TAG_SATURATION: s="TAG_SATURATION"; break;
     case TAG_CONTRAST: s="TAG_CONTRAST"; break;
     case TAG_EXPOSURE: s="TAG_EXPOSURE"; break;
     case TAG_TIMECODE: s="TAG_TIMECODE"; break;

     case TAG_ACC1: s="TAG_ACC1"; break;
     case TAG_MFGI: s="TAG_MFGI"; break;
     case TAG_DEVC: s="TAG_DEVC"; break;
     case TAG_DVID: s="TAG_DVID"; break;
     case TAG_SCAL: s="TAG_SCAL"; break;
     case TAG_SIUN: s="TAG_SIUN"; break;
     case TAG_DVNM: s="TAG_DVNM"; break;
     case TAG_STRM: s="TAG_STRM"; break;
     case TAG_UNIT: s="TAG_UNIT"; break;
     case TAG_TIMO: s="TAG_TIMEO"; break;

     case TAG_redl: s="TAG_redl"; break;
     case TAG_RPMs: s="TAG_RPMs"; break;
     case TAG_BRAK: s="TAG_BRAK"; break;
     case TAG_MP4A: s="TAG_MP4A";break;
     case TAG_TMCD: s="TAG_TMCD";break;
     case TAG_GPMD: s="TAG_GPMD";break;
     case TAG_GPMF: s="TAG_GPMF";break;
     case TAG_SENS: s="TAG_SENS";break;  // TODO: REMOVE THIS LATER!
     case TAG_GPMFL: s="TAG_GPMFL";break;
     case TAG_FDSC: s="TAG_FDSC";break;
     case TAG_AVC1: s="TAG_AVC1";break;

     /* GoPro */
     case TAG_VFRH: s="TAG_VFRH";break; // buckhorn/kirkwood
     case TAG_GPRI: s="TAG_GPRI";break; // buckhorn/kirkwood
     case TAG_BPOS: s="TAG_BPOS";break; // buckhorn/kirkwood

     case TAG_FIRM: s="TAG_FIRM";break; 
     case TAG_LENS: s="TAG_LENS";break; 
     case TAG_CAME: s="TAG_CAME";break; 
     case TAG_SETT: s="TAG_SETT";break; 
     case TAG_TIME: s="TAG_TIME";break;
     case TAG_VOLT: s="TAG_VOLT";break;
     case TAG_GPS : s="TAG_GPS";break;
     case TAG_OBD2: s="TAG_OBD2";break;
     case TAG_GYRO: s="TAG_GYRO";break;
     case TAG_AMBA: s="TAG_AMBA";break;
     case TAG_MUID: s="TAG_MUID";break;
     case TAG_HMMT: s="TAG_HMMT";break;
     case TAG_BCID: s="TAG_BCID";break;

     default: s="UNKNOWN"; found=0;break;
    }

    if (found)
    {
      struct tag *newTag = (struct tag *)malloc(sizeof(struct tag));
      bzero(newTag, sizeof(struct tag));
      sam->numTags++;
      if (sam->numTags >= MAX_SAMPLE_TAGS)
      {
        printFatalError("WARNING: REACHED MAX_SAMPLE_TAGS(%d)!!! possible code error", MAX_SAMPLE_TAGS);
      }
      sam->tags[sam->numTags-1] = newTag;

      strcpy(newTag->name, s);
      newTag->tagval = tag;
      newTag->type = b[4];
      newTag->structlen  = b[5];
      newTag->repeat  = ((b[6] & 0xff) << 8) | (b[7] & 0xff);
      if (verbose >= 3) 
      {
        sprintf(msgp,"FOUND TAG#%d=%s (%s)\n", sam->numTags, s, newTag->name); mlog(msgp);
        sprintf(msgp,"\ttype=%c(0x%x)\n", newTag->type, newTag->type); mlog(msgp);
        sprintf(msgp,"\tstructlen=%d\n", newTag->structlen); mlog(msgp);
        sprintf(msgp,"\trepeat=%d\n", newTag->repeat); mlog(msgp);
      }
      if ((newTag->type != 0) && (newTag->structlen > 0) && (tag != TAG_DEVC))
      {
        newTag->dataLen = newTag->structlen * (newTag->repeat);
        if (verbose >= 4) printf("\tdataLen=%d\n", newTag->dataLen);
        newTag->data = (unsigned char*)malloc(newTag->dataLen);
        b = &b[8]; // skip past 4cc/tag info just saved -> POINT TO DATA
        if (verbose >= 4) printf("\tmemcpy(newTag->data=0x%x, b=0x%x, newTag->dataLen=%d)\n", (int)newTag->data, (int)b, newTag->dataLen);
        memcpy(newTag->data, b, newTag->dataLen);
        b += newTag->dataLen; // point past data portion
      }
      else
      {
        b = &b[8]; // skip past 4cc/tag info just saved -> POINT TO DATA
      }
    }
    else
    {
      b++;
    }

    if (debug >= 3)
      printf("processMetaData: b - sam->dat == %d b=0x%x data=0x%x size=%d\n", (unsigned int)(b - sam->data), b, sam->data, sam->size);
    if ((b - sam->data) > (sam->size - 4))
    {
      if (debug >= 4)
      {
        printf("processMetaData: b - sam->dat == %d\n", (unsigned int)(b - sam->data));
        printf("\tsam->size - 4 == %d\n", (unsigned int)(sam->size - 4));
        printf("\tSTOPPING metadata scan...\n");
        printf("\tsam->numTags=%d\n", sam->numTags);
        printf("Sleep 5\n");
        sleep(5);
      }
      stop=1;
    }

  } // while !stop

  return sam->numTags;

} // processMetaData()  ### BUGGGY!

/* Read the MP4 file (assumption: positioned after the 'stsz' atom) for sample sizes
 * stsz atom will contain the lengths of all the gpmf samples (in the mdat atom)
 * - read the length of the lengths (# of samples)
 * - store each lenth in a stsz structured array (for later data retrieval)
 *
 * This will create the sample struct array
 * RETURN: # of samples
 */
struct sample *genStszArray(int fd, int stszLen, int *numSamples)
{
  unsigned char *tmp = (unsigned char*)malloc(stszLen);
  int n = read(fd,tmp,stszLen);
  if (n <= 11) // null (11 because that's the minimum depth we need to go into the buffer)
  {
    free(tmp);
    return 0; // null (11 because that's the minimum depth we need to go into the buffer)
  }

  int nSamples  = ((tmp[7] & 0xff)  << 24) | ((tmp[8] & 0xff)  << 16) | ((tmp[9] & 0xff)  << 8) | (tmp[10] & 0xff);
  if (verbose>=4) printf("genStszArray(): nSamples=%d, stszLen=%d, \n", nSamples, stszLen);

  if (nSamples <= 0) return 0; // null
  struct sample *newSamples;
  newSamples = (struct sample *)malloc(nSamples * sizeof(struct sample));
  bzero(newSamples, nSamples * sizeof(struct sample));

  // Now extract each sample size
  int i;
  unsigned char *sizeP=tmp+11;
  for (i=0; i<nSamples; i++)
  {
    unsigned int size  = ((sizeP[0] & 0xff)  << 24) | ((sizeP[1] & 0xff)  << 16) | ((sizeP[2] & 0xff)  << 8) | (sizeP[3] & 0xff);
    if (verbose>=4) printf("genStszArray(): size[%d]=%d\n", i, size);
    newSamples[i].size = size;
    // newSamples[i]->offset will be added later
    sizeP += 4; // goto next sample size
  }

  *numSamples = nSamples;
  return newSamples;
}

struct sample *genStcoArray(int fd, int stcoLen, struct sampleList *currSampleList, int *numSamples)
{
  unsigned char *tmp = (unsigned char*)malloc(stcoLen);
  int n = read(fd,tmp,stcoLen);
  if (n <= 3)
  {
    free(tmp);
    return 0; // null (11 because that's the minimun depth we need to go into the buffer)
  }

  int off=3; // starting offset within tmp buffer where nSamples 4-byte int is contained
  int nSamples  = ((tmp[off] & 0xff)  << 24) | ((tmp[off+1] & 0xff)  << 16) | ((tmp[off+2] & 0xff)  << 8) | (tmp[off+3] & 0xff);
  if (debug) printf("genStcoArray(): nSamples=%d\n", nSamples);

  if (nSamples <= 0)
  {
    free(tmp);
    return 0; // null
  }

  // Now extract each sample size
  int i;
  int offsets_offset=7;
  unsigned char *offP=tmp+offsets_offset;
  struct sample *samples = currSampleList->samples;
  if (debug) printf("Stco: *samples=0x%x\n", samples);
  for (i=0; i<nSamples; i++)
  {
    unsigned int offset  = ((offP[0] & 0xff)  << 24) | ((offP[1] & 0xff)  << 16) | ((offP[2] & 0xff)  << 8) | (offP[3] & 0xff);
    if (debug) printf("genStcoArray(): offset[%d]=%d\n", i, offset);
    samples->offset = offset;
    samples++;
    offP += 4; // goto next sample size
  }

  *numSamples = nSamples;
  return currSampleList->samples;
}

char *getTypeName(char type)
{
  switch (type)
  {
    case METADATA_TYPE_STRING_ASCII: return "STRING";
    case METADATA_TYPE_SIGNED_BYTE: return "SIGNED BYTE";
    case METADATA_TYPE_UNSIGNED_BYTE: return "UNSIGNED BYTE";
    case METADATA_TYPE_DOUBLE: return "DOUBLE";
    case METADATA_TYPE_FLOAT: return "FLOAT";
    case METADATA_TYPE_FOURCC: return "FOURCC";
    case METADATA_TYPE_GUID: return "GUID";
    case METADATA_TYPE_HIDDEN: return "HIDDEN";
    case METADATA_TYPE_UNSIGNED_LONG_HEX: return "unsigned long hex";
    case METADATA_TYPE_SIGNED_LONG: return "signed long";
    case METADATA_TYPE_UNSIGNED_LONG: return "unsigned long";
    case METADATA_TYPE_Q15_16_FIXED_POINT: return "Q15_16_FIXED_POINT";
    case METADATA_TYPE_Q31_32_FIXED_POINT: return "Q31_32_FIXED_POINT";
    case METADATA_TYPE_SIGNED_SHORT: return "signed short";
    case METADATA_TYPE_UNSIGNED_SHORT: return "unsigned short";
    case METADATA_TYPE_STRING_UTF8_: return "string UTF8";
    case METADATA_TYPE_UTC_DATE_TIME: return "UTC Date-Time";
    case METADATA_TYPE_XML: return "XML";
    case METADATA_TYPE_COMPLEX: return "COMPLEX";
    case METADATA_TYPE_NEST: return "Nested";
    default: return "UNKNOWN";
    // Add more metadata types here
    // Need to expand with multi-strings, GPS coordinate data types, etc.
  }
}

void printTagList(struct sample *sam)
{
  int ntags = sam->numTags;
  struct tag *tagp;
  int i;
  sprintf(msgp,"\n");mlog(msgp);
  for (i=0; i < ntags; i++)
  {
    tagp = sam->tags[i];
    sprintf(msgp,"\tTAG#%d\n", i+1);mlog(msgp);
    sprintf(msgp,"\t\tname : %s\n", tagp->name);mlog(msgp);
    sprintf(msgp,"\t\ttype : %c(0x%x) \"%s\"\n", tagp->type, tagp->type, getTypeName(tagp->type));mlog(msgp);
    sprintf(msgp,"\t\tstructlen : %d\n", tagp->structlen);mlog(msgp);
    sprintf(msgp,"\t\trepeat : %d\n", tagp->repeat);mlog(msgp);
    int r;
    unsigned char *d = tagp->data;
    for (r=0; r < tagp->repeat; r++)
    {
      switch (tagp->type)
      {
        case 'c':  // string
          sprintf(msgp,"\t\tstring : \"%s\"\n", d); mlog(msgp);
          r=tagp->repeat;
        break;

        case 'L':  // unsigned long
          sprintf(msgp,"\t\tulong : %d\n", extract_4byte_uint(d)); mlog(msgp);
          r=tagp->repeat;
        break;

        default: break;
        /*
        {
          int l;
          for (l=0; (l < tagp->structlen) && (l < 80); l++)
          {
            printf("%02x ", d[l]);
            if (!(l%16))
              printf("\n");
          }
          break;
        }
        */
      } // switch type
      d += tagp->structlen;
    }
    sprintf(msgp,"\n");mlog(msgp);
  } // for ntags
}

void printRawData(struct sample *sam)
{
  unsigned char *data = sam->data;
  int size = sam->size;
  int d;
  if (show_raw_data)
  {
    sprintf(msgp,"\t\t---RAW DATA---\n");
    strcat(msgp,"\t\t");
    mlog_pre(msgp,1);
    int maxPrint=500;
    for (d=0; (d < size) && (d < maxPrint); d++)
    {
      unsigned char v = data[d];
      if ((v >= 0x20) && (v <= 0x7F))
        {sprintf(msgp,"%c ", v);mlog_pre(msgp,1);}
      else
        {sprintf(msgp,"%02x ", v);mlog_pre(msgp,1);}
      if (!((d+1)%8))
        {sprintf(msgp,"\n\t\t");mlog_pre(msgp,1);}
    }
    if (d >= maxPrint)
        {sprintf(msgp,"PRINTING MAX %d samples", maxPrint);mlog_pre(msgp,1);}
      
  } // raw data print
  printTagList(sam);
  // sprintf(msgp,"\n");mlog_pre(msgp,1);
}

void populateData(int fd, struct sampleList *lists[], int numLists)
{
   int i;
   for (i=0; i < numSampleLists; i++)
   {
      struct sampleList *sl = sampleLists[i];
      int numSamples=sl->numSamples;
      struct sample *s = sl->samples;
      int j;
      sprintf(msgp,"\n"); mlog(msgp);
      sprintf(msgp,"GPMF TRAK LIST#%d\n", i+1); mlog(msgp);
      sprintf(msgp,"   numSamples=%d\n", numSamples); mlog(msgp);
      sprintf(msgp,"   trak_num=%d\n", sl->trak_num); mlog(msgp);
      sprintf(msgp,"   trak_offset=%d\n\n", sl->trak_offset); mlog(msgp);
      for (j=0; j<numSamples; j++)
      {

        if (debug >= 2)
        {
          printSampleLists("populateData():", numSampleLists, sampleLists);
          sleep(1);
        }
        s->data = (unsigned char*)malloc(s->size);
        bzero(s->data,s->size);
        int curr_index = lseek(fd, s->offset, SEEK_SET);
        int n = read(fd, s->data, s->size);
        if (verbose>=3)
        {
          sprintf(msgp,"  ----SAMPLE#%d)\n", j+1); mlog(msgp);
          sprintf(msgp,"\t  size   :%d\n", s->size); mlog(msgp);
          sprintf(msgp,"\t  offset :%d\n", s->offset); mlog(msgp);
          sprintf(msgp,"\t  data   :%d (nread)\n", n); mlog(msgp);
        }
        processMetaData(s);
        if (verbose>=2) 
          printRawData(s);
        s++;
      }
   }
   if (verbose>=3)
     {sprintf(msgp,"\n"); mlog(msgp);}
} // populateData

// TEST_GPMF_TAGS
// Return 1: all tags pass
// Return 0: error in one of the tags (missing atom/tag, bad value, etc)
//
int gpmf_check_tags(struct sampleList *sampleLists[] , int numSampleLists, int numSensors, struct sensor *sensors)
{
  int i;
  // {sprintf(msgp,"\n"); mlog(msgp);}
  {sprintf(msgp,"# CHECKING TAGS in GPMF format...\n"); mlog(msgp);}
  if (debug) printf("\nFUNCTION gpmf_check_tags(): %d sample list(s)\n", numSampleLists);
  int tag_test_result=0;  // must be the AND of all the founds
  int missing_tags[numSensors];
  int found_tags[numSensors]; // Don really need his
  int m;
  for(m=0; m < numSensors; m++)
  {
    missing_tags[m]=0;
    found_tags[m]=0;  
  }
  for (i=0; i < numSampleLists; i++)
  {
    struct sampleList *sl = sampleLists[i];
    int numSamples=sl->numSamples;
    struct sample *sam = sl->samples;
    if (verbose>=3) printf("Checking sample list #%d\n", i+1);
    int j;
    for (j=0; j<numSamples; j++)
    {
      int found_devc=0;
      int found_dvid=0;
      int found_dvnm=0;
      int found_strm=0;
      int found_mfgi=0;
      int found_acc1=0;
      int ntags = sam->numTags;
      struct tag *tagp;
      int i;
      if (verbose>=3) printf("\tChecking sample#%d, %d tags\n", j+1, ntags);
      unsigned long curr_dvid=-1;
      for (i=0; i < ntags; i++)
      {
        tagp = sam->tags[i];
        if (verbose>=3) printf("\t\tChecking Tag#%d\n", i+1);
        int r;
        unsigned char *d = tagp->data;

        // Check for the list of GPMF FourCC codes that should exist in each sample
        switch (tagp->tagval)
        {
          case TAG_DEVC: found_devc=1; break;
          case TAG_DVID: 
            found_dvid=1;
            unsigned char *d = tagp->data;
            curr_dvid = extract_4byte_uint(d);
            break;
          case TAG_DVNM: found_dvnm=1; break;
          case TAG_STRM: found_strm=1; break;
          case TAG_MFGI: found_mfgi=1; break;
          case TAG_ACC1: found_acc1=1; break;
          default: 
          {
            sprintf(msgp,"Unknown 4cc/tag value=0x%x (%s) in sample#%d tag#%d\n", j+1, i+1, tagp->tagval, tagp->name);
            mlog(msgp);
            break;
          }
        }
      } // iterate ntags 
      if (!(found_devc && found_dvid && found_dvnm && found_strm && found_mfgi && found_acc1))
      {
        sprintf(msgp,"Missing ");
        if (!found_devc) {strcat(msgp,"DEVC,"); missing_tags[dvid_to_idx(curr_dvid)]++;}
        if (!found_dvid) {strcat(msgp,"DVID,"); missing_tags[dvid_to_idx(curr_dvid)]++;}
        if (!found_dvnm) {strcat(msgp,"DVNM,"); missing_tags[dvid_to_idx(curr_dvid)]++;}
        if (!found_strm) {strcat(msgp,"STRM,"); missing_tags[dvid_to_idx(curr_dvid)]++;}
        if (!found_mfgi) {strcat(msgp,"MFGI,"); missing_tags[dvid_to_idx(curr_dvid)]++;}
        if (!found_acc1) {strcat(msgp,"ACC1,"); missing_tags[dvid_to_idx(curr_dvid)]++;}
        char msg2[40];
        sprintf(msg2," in sample#%d sensor(%d) dvid=%d\n", j+1, dvid_to_idx(curr_dvid)+1, curr_dvid);
        strcat(msgp, msg2);
        mlog(msgp);
      }
      else
        found_tags[dvid_to_idx(curr_dvid)]++;

      sam++;
    } // iterate samples
  } // iterate sample lists

  // tag_test_result = (!missing_tags) && found_tags;

  sprintf(msgp,"TAG Check Summary:\n");mlog(msgp);
  // pass until first missing tag found OR NO sensors were found
  tag_test_result = numSensors ? 1:0;
  for(m=0; m<numSensors;m++)
  {
    sprintf(msgp,"sensor#%d dvid=%d missing_tags=%d %s\n",m+1,sensors[m].dvid, missing_tags[m], missing_tags[m]?"BAD":"good");
    mlog(msgp);
    if (missing_tags[m] && found_tags[m])
      tag_test_result = 0;
  }

  return tag_test_result;

} // gpmf_check_tags

int dvid_to_idx(int dvid)
{
  int s;
  for (s=0; s < gpmf_sensors_detected; s++)
  {
      if (gpmf_sensor_list[s].dvid == dvid)
        return s;
  }
  printf("dvid_to_idx() ERROR: cant find dvid %d in gpmf_sensor_list\n", dvid);
  return -1; // ERROR
}
// count_acc1_data()
// Description:
//  Find 'acc1' tag, check type, get structlen, and repeat
//  and increment the #of data items per sensor, UPDATING the sensors list
//
// Returns: updated sensors list with acc1.len and allocated buffer size
//
void init_acc1_data(struct sampleList *sampleLists[] , int numSampleLists, int numSensors, struct sensor *sensors)
{
  int i;
  if (verbose>=3) printf("\nFUNCTION count_acc1_data()\n");

  // PASS#1 - count #of samples per sensor, record in sensor list
  for (i=0; i < numSampleLists; i++)
  {
    struct sampleList *sl = sampleLists[i];
    int numSamples=sl->numSamples;
    struct sample *sam = sl->samples;
    int j;
    for (j=0; j<numSamples; j++)
    {
      int ntags = sam->numTags;
      struct tag *tagp;
      int i;
      int curr_dvid=-1;
      int dvid_idx;
      for (i=0; i < ntags; i++)
      {
        tagp = sam->tags[i];
        if ((tagp->tagval == TAG_DVID) && (tagp->type=='L'))
        {
          unsigned char *d = tagp->data;
          curr_dvid = extract_4byte_uint(d);
          dvid_idx = dvid_to_idx(curr_dvid);
        }
        if ((tagp->tagval == TAG_ACC1) && (tagp->type == 'b') && (tagp->structlen==2))
        {
          // NOTE: in Greg Stewarts data sample, the 2-byte struct is either the UPPER
          // or LOWER short of an ascii-hex representation of a long unsigned int
          unsigned int ndataitems = tagp->repeat/2;
          sensors[dvid_idx].acc1.len += ndataitems; // We ASSUME that sam->sensor_dvid has already been set
          if (verbose>=3) 
          {
            sprintf(msgp,"init_acc1_data(): idx=%d dvid=%d acc1.len=%d ndataitems=%d (repeat=%d)\n",
             dvid_idx, curr_dvid, sensors[dvid_idx].acc1.len, ndataitems, tagp->repeat);
            mlog(msgp);
          }
        }
      } // iterate ntags 
      sam++;
    } // iterate samples
  } // iterate sample lists

  // ALLOCATE MEMORY for each sensor data stream
  int s;
  for (s=0; s < numSensors; s++)
  {
    int len = sensors[s].acc1.len;
    int size = len * sizeof(unsigned short);
    sensors[s].acc1.data = (unsigned short*)malloc(size);
    if (verbose>=3) printf("init_acc1_data(): idx=%d dvid=%d acc1.len=%d \tMALLOC(%d) data=0x%x\n", s, sensors[s].dvid, len, size, sensors[s].acc1.data);
    bzero(sensors[s].acc1.data, size);
  }
} // init_acc1_data

// extract_acc1_data()
// Description:
//  Find 'acc1' tag, check type, get structlen, and repeat
//  and extract data, allocate memory, and save.
//  Iterate through data ensuring that ramping pattern is maintained.
//
// Return 1: PASS: all data samples contain ramping patters witin
// Return 0: error in one of the data samples is missing a ramping patter
//
int extract_acc1_data(struct sampleList *sampleLists[] , int numSampleLists, int numSensors, struct sensor *sensors)
{
  if (verbose>=3) printf("\nFUNCTION extract_acc1_data()\n");

  int i;
  int sensor_ndata[numSensors];
  bzero(sensor_ndata, numSensors * sizeof(int));  // start all indices at 0
  for (i=0; i < numSampleLists; i++)
  {
    struct sampleList *sl = sampleLists[i];
    int numSamples=sl->numSamples;
    struct sample *sam = sl->samples;
    int j;
    for (j=0; j<numSamples; j++)
    {
      int ntags = sam->numTags;
      struct tag *tagp;
      int i;
      int curr_dvid=-1;
      int dvid_idx;
      for (i=0; i < ntags; i++)
      {
        tagp = sam->tags[i];
        if ((tagp->tagval == TAG_DVID) && (tagp->type=='L'))
        {
          unsigned char *d = tagp->data;
          curr_dvid = extract_4byte_uint(d);
          if (verbose >=4)
          {
            printf("extract_acc1_data: curr_dvid=%d\n", curr_dvid);
          }

          dvid_idx = dvid_to_idx(curr_dvid);
        }
        if ((tagp->tagval == TAG_ACC1) && (tagp->type == 'b') && (tagp->structlen==2))
        {
          unsigned char *d = (unsigned char *)tagp->data;
          if (debug)
          {
            int x;
            for (x=0; x < tagp->dataLen; x++)
              printf("%02x ", tagp->data[x]);
            printf("\n");
          }
          // NOTE: in Greg Stewarts data sample, the 2-byte struct is either the UPPER
          // or LOWER short of an ascii-hex representation of a long unsigned int
          int r;
          if (dvid_idx < 0)
          {
            printf ("WARNING: dvid_idx=%d, SKIPPING ACC1 extraction, but printing data (len=%d) here...\n", dvid_idx, tagp->dataLen);
            int x;
            for (x=0; x < tagp->dataLen; x++)
              printf("%02x ", tagp->data[x]);
            printf("\n");
            continue;
          }
          for (r=0; r<tagp->repeat/2; r++)
          {
            unsigned char s[(2 * tagp->structlen) + 1];
            bzero(s,(2 * tagp->structlen) + 1);
            memcpy(s, d, 2 * tagp->structlen);
            unsigned int newValue;
            sscanf(s,"%d", &newValue);
            if (verbose>=4) printf("newValue=%d r=%d tag#%d sample#=%d/%d\n", newValue,r, i,j,numSamples);
            if (sensor_ndata[dvid_idx] >= sensors[dvid_idx].acc1.len)
            {
              printf("ERROR: extract_accc1() REACHED MAX ACC1(%d) data points! sensor_ndata[dvid_idx=%d]=%d Exiting check\n", sensors[dvid_idx].acc1.len, dvid_idx, sensor_ndata[dvid_idx]);
              printf("sleep 5");
              sleep(5);
              break;
            }
            else
            {
              sensors[dvid_idx].acc1.data[sensor_ndata[dvid_idx]] = newValue;
              sensor_ndata[dvid_idx]++; // #of data samples extracted
            }
            d += (tagp->structlen * 2);
          }
        }
      } // iterate ntags 
      sam++;
    } // iterate samples
  } // iterate sample lists

} // extract_acc1_data

// TEST_GPMF_RAMPING
// Description:
//  Find 'acc1' tag, check type, get structlen, and repeat
//  and extract data, allocate memory, and save.
//  Iterate through data ensuring that ramping pattern is maintained.
//
// Return 1: PASS: all data samples contain ramping patters witin
// Return 0: error in one of the data samples is missing a ramping patter
//
// int gpmf_check_ramping(struct sampleList *sampleLists[] , int numSampleLists, int numSensors, struct sensor *sensors)
int gpmf_check_ramping(int numSensors, struct sensor *sensors)
{
  int i;
  if (verbose>=3) printf("\nFUNCTION gpmf_check_ramping()\n");
  int ramping_test_result[numSensors];
  int final_ramping_result;

  {sprintf(msgp,"\n"); mlog(msgp);}
  {sprintf(msgp,"# CHECKING RAMPING PATTERN...\n"); mlog(msgp);}
  unsigned short last_value=0;
  int skips[numSensors];
  int delta[numSensors];
  int s;
  for (s=0; s < numSensors; s++)
  {
    delta[s] = 1;
    skips[s] = 0;
  }
  for (s=0; s < numSensors; s++)
  {
    int npatterns = sensors[s].acc1.len;
    for (i=0; i<npatterns; i++)
    {
      unsigned short acc1Val = sensors[s].acc1.data[i];
      if ((i==1) && !(acc1Val % 1111))
      {
        delta[s] = 1111;  // OLD ramping pattern to support
      }
        
      // print and check for monotomically increasing values
      if (show_ramping_data)
      {
        sprintf(msgp, "sensor#%d(%02d) %04d ", s+1, i+1,  acc1Val);
        mlog(msgp);
        if (i==0)
          {sprintf(msgp,"\n"); mlog(msgp);}
      }
      if (i > 0)
      {
        if ((acc1Val - last_value) != delta[s])
        {
          if ((delta[s]==1111) && (last_value==9999) && (acc1Val==1111))
          {
            if (show_ramping_data) {sprintf(msgp,"\n"); mlog(msgp);}
          }
          else
          {
            skips[s]++;
            if (verbose < 2)
              sprintf(msgp,"WARNING: ramping pattern FAILURE sensor#%d dvid=%d @i=%d curr_value=%4d last_value=%4d\n", s+1, sensors[s].dvid, i, acc1Val, last_value);
            else 
              sprintf(msgp,"#WARNING: ramping pattern FAILURE curr_value=%d last_value=%d\n", acc1Val, last_value);
            mlog(msgp);
            if (debug) sleep(3);
          }
        }
        else
        {
          if (show_ramping_data) {sprintf(msgp,"\n"); mlog(msgp);}
        }
      }
      last_value = acc1Val;
    }
  } // numSensors

  final_ramping_result= numSensors ? 1:0;
  sprintf(msgp,"Ramp Check Summary:\n");
  mlog(msgp);
  for (s=0; s < numSensors; s++)
  {
    ramping_test_result[s] = (skips[s]==0) && (sensors[s].acc1.len > 0);
    if (!ramping_test_result[s])
      final_ramping_result=0;
    sprintf(msgp,"sensor#%d dvid=%d datapoints=%-4d \tdelta=%d \tskips=%d \tramping_result=%s\n",
          s+1, sensors[s].dvid, sensors[s].acc1.len, delta[s], skips[s], ramping_test_result[s]?"good":"BAD");
    mlog(msgp);
  }

  return final_ramping_result;

} // gpmf_check_ramping

// TEST_GPMF_TIMING
// Return 1: PASS gpmf sample timing rates
// Return 0: error in one of the time codes (inconsistent)
//
int gpmf_check_timing(struct sampleList *sampleLists[] , int numSampleLists)
{
  int i;
  if (verbose>=3) printf("\nFUNCTION gpmf_check_timing(): %d sample list(s)\n", numSampleLists);
  int timing_test_result=0;  // must be the OR of all the founds
  int missing_timing=0;
  for (i=0; i < numSampleLists; i++)
  {
    struct sampleList *sl = sampleLists[i];
    int numSamples=sl->numSamples;
    struct sample *sam = sl->samples;
    if (verbose>=3) printf("Checking sample list #%d\n", i+1);
    int j;
    for (j=0; j<numSamples; j++)
    {
      int ntags = sam->numTags;
      struct tag *tagp;
      int i;
      if (verbose>=3) printf("\tChecking sample#%d, %d tags\n", j+1, ntags);
      for (i=0; i < ntags; i++)
      {
        tagp = sam->tags[i];
        int r;
        unsigned char *d = tagp->data;

      } // iterate ntags 
      sam++;
    } // iterate samples
  } // iterate sample lists

  // timing_test_result = !missing_timing;

  return timing_test_result;

} // gpmf_check_timing


// TEST_GPMF_NSENSORS
// Return 1: PASS we detect metadata from 'n' sensors
// Return 0: error in one or more sensors not found
//
int gpmf_check_sensors(struct sampleList *sampleLists[] , int numSampleLists, int sensors_expected, int *sensors_detected, struct sensor *sensors)
{
  int i;
  if (verbose>=3) 
  {
    sprintf(msgp,"\nFUNCTION gpmf_check_sensors(): %d sample list(s) sensors expected:%d\n", numSampleLists, sensors_expected);
    mlog(msgp);
  }
  int nsensor_test_result=0;  // must be the OR of all the founds
  int nsensors=0;
  for (i=0; i < numSampleLists; i++)
  {
    struct sampleList *sl = sampleLists[i];
    int numSamples=sl->numSamples;
    struct sample *sam = sl->samples;
    if (verbose>=3) printf("Checking sample list #%d\n", i+1);
    int j;
    int newsensor=-1;
    int needname=0;
    for (j=0; j<numSamples; j++)
    {
      int ntags = sam->numTags;
      struct tag *tagp;
      int i;
      if (verbose>=3) printf("\tChecking sample#%d, %d tags\n", j+1, ntags);
      int foundnew=0;
      for (i=0; i < ntags; i++)
      {
        foundnew=1;
        tagp = sam->tags[i];
        unsigned char *d = tagp->data;
        if ((tagp->tagval == TAG_DVID) && (tagp->type=='L'))
        {
          int n;
          unsigned long dvid = extract_4byte_uint(d);
          for (n=0; n < nsensors; n++)
          {
            // check existing list
            if (verbose >= 4)
              printf("sensors[%d].dvid==%d name=%s  dvid=%d nsensors=%d", n, sensors[n].dvid, sensors[n].name, dvid, nsensors);
            if (sensors[n].dvid == dvid)  // already exist/accounted for
            {
              foundnew=0;
              if (verbose >= 4)
                printf(" exists, foundnew=0\n");
            }
            else
              if (verbose >= 4)
                printf("\n");
          }
          if (foundnew)
          {
            newsensor = nsensors;
            if (verbose >= 3)
              printf("NEW SENSOR(%d) FOUND: dvid=%d sample#%d\n", newsensor, dvid, j);
            sensors[newsensor].dvid = dvid;
            sensors[newsensor].acc1.len = 0;  // to be filled in later 
            sensors[newsensor].acc1.data = 0; // null pointer to data
            // DEPRECATEDsam->sensor_idx = newsensor;
            nsensors++;
            needname=1;
          }

        } 
        // Now when come across the Device Name (DVNM), copy down the new sensor name, if any
        if (needname && foundnew && (newsensor>=0) && (tagp->tagval == TAG_DVNM) && (tagp->type=='c'))
        {
          strcpy(sensors[newsensor].name, d);
          if (verbose >=3)
            printf("NEW SENSOR(%d) NAME: name=%s\n", newsensor, sensors[newsensor].name);
          foundnew=0;
          needname=0;
        }
      } // iterate ntags 
      sam++;
    } // iterate samples
  } // iterate sample lists

  nsensor_test_result = (sensors_expected == nsensors);
  *sensors_detected = nsensors;

  return nsensor_test_result;

} // gpmf_check_sensors

void printTestModes(int testmode)
{
  {sprintf(msgp,"testModes \t\t:"); mlog(msgp);}
  if (testmode == TEST_NONE) {sprintf(msgp," NONE");mlog_pre(msgp,1);return;}
  if (testmode & TEST_GPMF_RAMPING)     {sprintf(msgp," GPMF-RAMPING"); mlog_pre(msgp,1);}
  if (testmode & TEST_GPMF_NSENSORS)    {sprintf(msgp," BLE-NSENSORS"); mlog_pre(msgp,1);}
  if (testmode & TEST_GPMF_TIMING)      {sprintf(msgp," GPMF-TIMING"); mlog_pre(msgp,1);}
  if (testmode & TEST_GPMF_TAGS)        {sprintf(msgp," GPMF-TAGS"); mlog_pre(msgp,1);}
  if (testmode & TEST_ARGUS)            {sprintf(msgp," ARGUS"); mlog_pre(msgp,1);}
  if (testmode & TEST_KIRKWOOD)         {sprintf(msgp," KIRKWOOD"); mlog_pre(msgp,1);}
  if (testmode & TEST_SETTINGS)         {sprintf(msgp," SETTINGS"); mlog_pre(msgp,1);}
  {sprintf(msgp,"\n"); mlog_pre(msgp,1);}
}

void processArgs(int argc, char *argv[])
{
  int i;

  int f_option_found=0;  // mandatory option, unless specifying -h

  for (i = 1; i < argc; i++)  /* Skip argv[0] (program name). */
  {
      if (strcmp(argv[i], "-all") == 0) 
      {
      }
      else if ((strcmp(argv[i], "-l") == 0) 
            || (strcmp(argv[i], "-log") == 0) )
      {
        logEnabled = 1;
      }
      else if (strcmp(argv[i], "-f") == 0) 
      {
        i++;
        strcpy((char *)filename, (const char*)argv[i]);  /* Convert string to int. */
        f_option_found=1;
      }
      else if ((strcmp(argv[i], "-a") == 0) 
            || (strcmp(argv[i], "-atoms") == 0) )
      {
        show_atoms=1;
      }
      else if ((strcmp(argv[i], "-sr") == 0) 
            || (strcmp(argv[i], "-showrampdata") == 0) )
      {
        show_ramping_data=1;
      }
      else if ((strcmp(argv[i], "-t") == 0) 
            || (strcmp(argv[i], "-tags") == 0) )
      {
        show_tags=1;
      }
      else if (strcmp(argv[i], "-h") == 0) 
      {
        usage();
      }

      /****** multiple args *******/
      else if (strcmp(argv[i], "-pre") == 0) 
      {
        i++;
        sscanf(argv[i], "%d", &preamble_flag);
      }
      else if (strcmp(argv[i], "-preamble") == 0)
      {
        i++;
        strcpy(preamble, argv[i]);
      }
      else if ((strcmp(argv[i], "-ld") == 0) 
            || (strcmp(argv[i], "-logdir") == 0) )
      {
        i++;
        strcpy(logDir,argv[i]);
      }
      else if ((strcmp(argv[i], "-verb") == 0) 
            || (strcmp(argv[i], "-v") == 0) )
      {
        i++;
        sscanf(argv[i], "%d", &verbose);
      }
      else if ((strcmp(argv[i], "-debug") == 0) 
            || (strcmp(argv[i], "-d") == 0) )
      {
        i++;
        sscanf(argv[i], "%d", &debug);
      }
      else if (strcmp(argv[i], "-test") == 0) 
      {
        i++;
        char test_name[80];
        bzero(test_name,80);
        strcpy(test_name, argv[i]);
        toLowerCase(test_name);
        if (!strcmp(test_name,"gpmf"))
          testMode |= GPMF_TESTS;
        else if (!strcmp(test_name,"argus"))
          testMode |= TEST_ARGUS;
        else if (!strcmp(test_name,"kirkwood"))
          testMode |= TEST_KIRKWOOD;
      }
      else if (strcmp(argv[i], "-sensors") == 0) 
      {
        i++;
        sscanf(argv[i], "%d", &gpmf_sensors_expected);
      }
  } // for all args

  if (!f_option_found)
  {
    printf("\n***** Ooops...MUST SPECIFY the -f option! *****\n");
    usage();
  }
} // processArgs

void usage()
{
  printf("\nusage:\n");
  printf("\t-h               \t\t: print usage\n");
  printf("\t-f <file>        \t\t: video file containing metadata\n");
  printf("\t-test <gpmf|argus|kirkwood> \t: test to run\n");
  printf("\t-sensors <#> \t\t\t: number of sensors expected (default:1)\n");
  printf("\t-l|-log          \t\t: enable logging to a file (\"meta-<date>-<file>.log\")\n");
  printf("\t-ld|-logdir <path> \t\t: set logging path (default is . curr directory)\n");
  printf("\t-a|-atoms        \t\t: display all atoms found\n");
  printf("\t-t|-tags         \t\t: display all tags found\n");
  printf("\t-sr|-showrampdata         \t\t: shows ramping data values of all sensors\n");
  printf("\t-v|-verb <level:1-n/off:0>      : show/hide detailed messages\n");
  printf("\t-d|-debug <level:1-n/off:0>     : show/hide detailed messages\n");
  printf("\t-pre <0=off,1=on>       : allow prepending of specified chars before every message(For SUGARGLIDER logs)\n");
  printf("\t-preamble <string>      : set the preamble message/string\n");
  printf("\n");
  exit(1);
}

void printOptions()
{
  {sprintf(msgp,"\n"); mlog(msgp);}
  sprintf(msgp, "Settings:\n"); mlog(msgp);
  {sprintf(msgp,"VIDEO FILENAME \t\t: %s\n"   , filename); mlog(msgp);}
  if (verbose) {sprintf(msgp,"verbose \t\t: %d\n"          , verbose); mlog(msgp);}
  if (debug)   {sprintf(msgp,"debug \t\t: %d\n"          , debug); mlog(msgp);}
  if (logEnabled) {sprintf(msgp,"logEnabled \t\t: %d\n"       , logEnabled); mlog(msgp);}
  if (logEnabled) {sprintf(msgp,"logFile \t\t: %s\n"          , logPath); mlog(msgp);}
  if (show_tags) {sprintf(msgp,"show tags \t\t: ON\n"      ); mlog(msgp);}
  if (show_atoms) {sprintf(msgp,"show atoms \t\t: ON\n"      ); mlog(msgp);}
  printTestModes(testMode);
  if (testMode & TEST_GPMF_NSENSORS) {sprintf(msgp,"sensors expected \t: %d\n" , gpmf_sensors_expected); mlog(msgp);}
  {sprintf(msgp,"\n"); mlog(msgp);}
  sleep(3);
} // printOptions

void printTagValues()
{
  unsigned int x;
  char *s;
  x=TAG_STRM; s="TAG_STRM"; printf("%s=0x%x\n", s, x);
  x=TAG_MFGI; s="TAG_MFGI"; printf("%s=0x%x\n", s, x);
  x=TAG_FREESPACE; s="TAG_FREESPACE"; printf("%s=0x%x\n", s, x);
  x=TAG_COLOR_MATRIX; s="TAG_COLOR_MATRIX"; printf("%s=0x%x\n", s, x);
  x=TAG_SATURATION; s="TAG_SATURATION"; printf("%s=0x%x\n", s, x);
  x=TAG_CONTRAST; s="TAG_CONTRAST"; printf("%s=0x%x\n", s, x);
  x=TAG_EXPOSURE; s="TAG_EXPOSURE"; printf("%s=0x%x\n", s, x);
  x=TAG_TIMECODE; s="TAG_TIMECODE"; printf("%s=0x%x\n", s, x);
  x=TAG_DEVC; s="TAG_DEVC"; printf("%s=0x%x\n", s, x);
  x=TAG_DVID; s="TAG_DVID"; printf("%s=0x%x\n", s, x);
  x=TAG_DVNM; s="TAG_DVNM"; printf("%s=0x%x\n", s, x);
  x=TAG_UNIT; s="TAG_UNIT"; printf("%s=0x%x\n", s, x);
  x=TAG_redl; s="TAG_redl"; printf("%s=0x%x\n", s, x);
  x=TAG_RPMs; s="TAG_RPMs"; printf("%s=0x%x\n", s, x);
  x=TAG_BRAK; s="TAG_BRAK"; printf("%s=0x%x\n", s, x);
  x=TAG_MP4A; s="TAG_MP4A";printf("%s=0x%x\n", s, x);
  x=TAG_TMCD; s="TAG_TMCD";printf("%s=0x%x\n", s, x);
  x=TAG_GPMD; s="TAG_GPMD";printf("%s=0x%x\n", s, x);
  x=TAG_FDSC; s="TAG_FDSC";printf("%s=0x%x\n", s, x);
  x=TAG_AVC1; s="TAG_AVC1";printf("%s=0x%x\n", s, x);
  x=TAG_VFRH; s="TAG_VFRH";printf("%s=0x%x\n", s, x);
  x=TAG_GPRI; s="TAG_GPRI";printf("%s=0x%x\n", s, x);
  x=TAG_BPOS; s="TAG_BPOS";printf("%s=0x%x\n", s, x);
}

void printSampleLists(char *desc, int numLists, struct sampleList *sls[])
{
  int l;
  printf("\n%s: numSampleLists=%d\n", desc, numSampleLists);
  for (l=0; l < numLists; l++)
  {
    struct sample *s = sls[l]->samples;
    int ns = sls[l]->numSamples;
    int i;
    for (i=0; i<ns; i++)
    {
      printf ("sample s[%d].size=%d\n", i, s[i].size);
    }
  }
}

int main (int argc, char *argv[])
{
  if (debug)
    printTagValues();

  if (debug)printf("Total Known Atoms = %d\n", total_known_atoms);
  strcpy(filename, DEFAULT_FNAME);
  bzero(logFile,80);
  bzero(logDir,80);
  bzero(logPath,80);
  strcpy(logDir, DEFAULT_LOGDIR);

  // Get OPTIONS
  processArgs(argc, argv);

  char *infile = filename;
  if (debug) printf("PARSING metadata file\t: %s\n", infile);
  int fd = open(infile,  O_RDONLY);

  if (fd < 0)
  {
    char tmp[80];
    sprintf(tmp,"Error opening %s", infile);
    perror(tmp);
    exit(1);
  }

  if (debug)printf("%s opened ok\n", infile);

  int logWrites=0; 

  if (logEnabled)
  {
   char fdate[80];
   bzero(fdate,80);
   getFileDate(fdate);
   if (debug) printf("fdate=%s\n",fdate);
   // char *mp4_pos = (char *)strcasestr((const char *)infile, (const char *)".");
   char *mp4_pos = (char *)index((const char *)infile, (int)'.');
   if (debug) printf("mp4_pos=%s\n",mp4_pos);
   char *slash_pos = (char *)rindex((const char *)infile, (int)'/');  // get the last trailing slash
   if (debug) printf("slash_pos=%s\n",slash_pos);
   if (!slash_pos)
     slash_pos = infile;
   else
     slash_pos++;
   if (debug) printf("slash_pos=%s\n",slash_pos);
   char *basename = strndup(slash_pos, mp4_pos - slash_pos);
   if (debug) printf("basename=%s\n",basename);
   // sprintf(logFile, "%s-%s-%s.log", "mdtool", fdate, basename);  // TOO long -- just use the filebase and append .log
   sprintf(logFile, "mdtool-%s.log", basename);
   if (debug) printf("logFile=%s\n",logFile);
   if (debug) printf("logDir=%s\n",logDir);
   sprintf(logPath,"%s/%s", logDir, logFile);
   if (debug){ sprintf(msgp,"mdtool metadata log\t: %s\n", logPath); mlog(msgp);}
   log_fd = createMetaInfoFile(logPath);
  }
  else
  {
   log_fd = 0;
   sprintf(logFile, "(none)");
  }

  if (debug) printf("Allocating buffer size of %d\n", BSZ);
  unsigned char *buf = (unsigned char *)malloc(BSZ);
  bzero(buf,BSZ);

  int nread=0;
  int bufread=0;
  int nwrite;
  unsigned char *p;
  int n;
  int berrors=0;
  int nerrors=0;
  int charcount=0;
  unsigned char box[116];
  unsigned char *boxp;
  unsigned char *tagp;
  bzero(box,16);
  int boxlen=0;
  char boxname[5];
  int  taglen=0;
  char tagname[180];
  char tagtype;
  int atom_count=0;
  int tag_count=0;
  int last_box_index=0;
  int last_tag_index=0;
  int diff=0;

  int delay=0.1;
  int file_index=0;
  int seek_len=0;
  bzero(msgp,MSGSZ);

  printOptions();
  sleep(2); // pause so intro info can be read/seen

  int offset;
  int index;
  index=0;  // index location in file to atoms and tags
  int boxframe=0;
  int tagframe=0;
  int findtags=1;
  int findatoms=1;

  int curr_index = 0;
  /*
   // Should MATCH THIS: 

   // Atom ftyp @ 0        of size: 20, ends @ 20
   // Atom mdat @ 20       of size: 89413702, ends @ 89413722
   // Atom moov @ 89413722 of size: 44222, ends @ 89457944  <<< MISSING
   // Atom mvhd @ 89413730 of size: 108, ends @ 89413838    <<< MISSING
   // Atom udta @ 89413838 of size: 887, ends @ 89414725

   ---ATOM:"ftyp" @ 0 len=20 index=0 (diff=0)
   ---ATOM:"mdat" @ 20 len=89413702 index=20 (diff=20)
        89413731=lseek(3, 89413731, 1)
   ---ATOM:"udta" @ 89413838 len=887 index=136 (diff=116)
  */



  while(1)
  {

    // PSUEDO-Circular-buffer
    if ((boxframe > 0) && (boxframe < BOXLAG)) // EDGE case: copy data remaining at end of buffer
    {
      // Wraparound buffer handling
      // since boxframe is bigger than a tag frame, just copy the boxframe to cover any tag data
      //
      memcpy(buf, boxp, boxframe); // copy any data left at the end of the buffer already read in
      p       = buf+boxframe;  // start the buf ptr
      bufread = boxframe;
      // note: boxframe and tagframe values stay intact and proceed from beginning of buffer
      bzero(p,BSZ-boxframe); // zero out remaining buffer
    }
    else
    {  
      // Normal reset
      p    = buf;
      bufread=0;
      bzero(buf,BSZ);
    }
    tagp = buf;  // reset tag frame pointer
    boxp = buf;  // reset atom box framne pointer

    /* Algorithm:
    * 1. read 1 char at a time until synced up to a box/atom/tag frame
    * 2. REPEAT: reading characters UNTIL next BOX/ATOM/TAG is detected
    * 3. reset buf ptr and boxframes if reached end of buffer. Copy remaning box/tag frame info to beginning of buffer
    * 4. ADVANCED: use length bit to SEEK FORWARD in the MP4 file and skip unecessary unwanted information
    */
    do  // read until buffer is full then wrap around again
    {
      n = read(fd, p, 1);

      if (n > 0)
      {
        file_index++; // overall file index
        nread++;      // total read from file
        bufread++;    // bufptr tracker
        boxframe++;   // # of bytes past boxp: keep reading chars until we have a boxframe of BOXLAG length
        tagframe++;   // # of bytes past tagp: keep reading chars until we have a boxframe of TAGLAG length

        if (bufread >= BSZ)
        {
          if (debug) {
            sprintf(msgp, "REACHED END OF BUFFER!\n"); mlog(msgp);
          }
          break; // go to outer while loop and reset buffer pointers (p, tagp, boxp), reset bufread counter
        }

        if (debug==2)
        {
         sprintf(msgp, "p=0x%x (%c) nread=%d\n",*p, *p, nread);
         mlog(msgp);
        }

        if (findtags)
        {
          tagtype = '?';
          if ( (tagframe >= TAGLAG) && metatag_check(tagp, &taglen, tagname, &tagtype))
          {
           int tagindex = file_index;
           diff = tagindex - last_tag_index;
           if (show_tags)
           {
             sprintf(msgp,
             "\t\"%s\" @ %d len=%d type=%c(0x%x) index=%d\n", tagname, tagindex-TAGLAG, taglen, tagtype, tagtype, file_index);
             mlog(msgp);
           }
           tagframe=0; // reset the tagframe and start scanning all over again
           last_tag_index = tagindex;
           tag_count++;
           tagp = p-TAGLAG;
          }
        }
        if (findatoms)
        {
          bzero(boxname,5);

          // ASSUMPTION: boxp points to length field, next 4 bytes is name field
          if (boxframe >= BOXLAG) 
          {
           if (atom_check(boxp, &boxlen, boxname))
           {
             // int boxindex = boxp-buf;
             int boxindex = file_index;
             diff = boxindex - last_box_index;
             int offset = nread-8-1;

             // if ((mode==SCAN_MODE) && show_atoms)
             if (show_atoms)
             {
               sprintf(msgp,"---ATOM:\"%s\" @ %d len=%d index=%d (diff=%d)\n", boxname, offset, boxlen,boxindex,diff);
               mlog(msgp);
             }

             // gpAtomHandler();  // parse for gopro information
             switch (mode) 
             {
               case SCAN_MODE:
               {
                 if (!memcmp(boxname, "mdat", 4))
                 {
                   // SAVE the mdat offset
                   mdat_offset = offset;
                   if (debug) {sprintf(msgp,"*mdat offset=%d\n", mdat_offset);mlog(msgp);}
                   curr_index = lseek(fd, boxlen-2-8, SEEK_CUR);
                   file_index = curr_index;
                   if (debug) {sprintf(msgp,"\t\t%d=lseek(%d, %d, %d)\n", curr_index,fd, file_index, SEEK_CUR); mlog(msgp);}
                   nread = curr_index;
                 }
                 else if (!memcmp(boxname, "moov", 4))
                 {
                   mode = TRAK_MODE;
                   if (debug) printf("\t***FOUND 'moov' atom, entering TRAK_MODE\n");
                   if (verbose>=1) {sprintf(msgp,"MOOV atom found @%d\n", offset); mlog(msgp);}
                 }
                 break;
               }
               case TRAK_MODE:
               {
                 if (!memcmp(boxname, "trak", 4))
                 {
                   trak_offset = offset; // remember this  because we need to seek out of this
                   trak_len    = boxlen; // remember this  because we need to seek to next trak
                   trak_count++;
                   mode = MDIA_MODE;
                   // if (verbose>=3) printf("\t***FOUND 'trak(#%d @%d)' atom, entering MDIA_MODE\n",trak_count,trak_offset);
                   if (verbose>=1) {sprintf(msgp,"TRAK atom found trak=%d @%d\n", trak_count, offset); mlog(msgp);}
                 }
                 break;
               }
               case MDIA_MODE:
               {
                 if (!memcmp(boxname, "mdia", 4))
                 {
                   mode = HDLR_MODE;
                   if (debug) printf("\t***FOUND 'mdia' atom, entering HDLR_MODE\n");
                   if (verbose>=1) {sprintf(msgp,"MDIA atom found in trak=%d @%d\n", trak_count, offset); mlog(msgp);}
                 }
                 break;
               }
               case HDLR_MODE:
               {
                 if (!memcmp(boxname, "hdlr", 4))
                 {
                   hdlr_count++;
                   if (boxlen == 42)
                   {
                     mode = GPMF_MODE;
                     if (verbose>=1) {sprintf(msgp,"HDLR atom found in trak=%d @%d\n", trak_count, offset); mlog(msgp);}
                     if (debug) printf("\t***FOUND 'hdlr(%d)' atom, searching for GPMF tag\n", hdlr_count);
                     // Check the next 12-bytes to make sure "gpmf" is at the last 4 bytes
                     // If so, read the following
                     // 1. stsz (size of data)
                     // 2. stco (offset of data from beginning of file inside mdat section?)
                   }
                   else 
                   {
                     if (verbose) {sprintf(msgp,"hdlr length=%d NOT EQUAL to 42, exiting to SCAN_MODE\n", boxlen);mlog(msgp);}
                     mode = TRAK_MODE;
                   }
                 }
                 break;
               }
               case GPMF_MODE:
               {
                 if (debug)
                 {
          #define SZ 20
                   char tmp[SZ];
                   n = read(fd,tmp,SZ);
                   int i;
                   for (i=0; i<SZ; i++)
                   {
                     printf("0x%02x ", tmp[i]);
                   }
                   printf("\n");
                   printf("SWITCHING to TRAK_MODE\n");
                   mode = TRAK_MODE;
                   break;
                 }

                 if (!memcmp(boxname, "gpmf", 4) || !memcmp(tagname, "gpmf", 4))
                 {
                   gpmf_count++;
                   if (verbose>=1) 
                   {
                     sprintf(msgp,"GPMF tag FOUND in trak=%d @%d, gpmf count=%d\n",trak_count, trak_offset, gpmf_count);
                     mlog(msgp);
                   }
                   if (debug) {sprintf(msgp,"\t\tFOUND 'gpmf(%d)' tag, entering STBL_MODE\n",gpmf_count);mlog(msgp);}
                   mode = STBL_MODE;
                 }
                 else
                 {
                   if (verbose>=3) 
                   {
                     sprintf(msgp, "\t\t-- No gpmf in this trak=%d @%d tag=%s atom=%s, EXITING to  HDLR_MODE\n",
                             trak_count, trak_offset, tagname,boxname);
                     mlog(msgp);
                   }
                   mode = HDLR_MODE;
                 }
                 break;
               }
               case STBL_MODE:
               {
                 if (!memcmp(boxname, "stbl", 4))
                 {
                   if (verbose>=1) {sprintf(msgp,"STBL atom found trak=%d @%d\n", trak_count, offset); mlog(msgp);}
                   if (debug) {sprintf(msgp,"\t***FOUND 'stbl' atom, entering STSZ_MODE\n"); mlog(msgp);}
                   mode = STSZ_MODE;
                 }
                 break;
               }
               case STSZ_MODE:
               {
                 if (!memcmp(boxname, "stsz", 4))
                 {
                   if (debug) {sprintf(msgp,"\t***FOUND 'stsz' atom, entering STCO_MODE\n"); mlog(msgp);}
                   if (debug)
                   {
                     int nr = printNfileChars(fd,boxlen-BOXLAG);
                   }
                   /* stsz atom will contain the lengths of all the gpmf samples (in the mdat atom)
                    * - read the length of the lengths
                    * - store each lenth in a stsz structured array (for later data retrieval)
                    */
                   int numSamples=0;

                   // subtract BOXLAG-1 because we already read the length and 'stsz' box (8 byte)
                   struct sample *samples = genStszArray(fd, boxlen-BOXLAG-1,&numSamples); 
                   if (samples <= 0)
                   {
                      sprintf(msgp,"ERROR collect stsz sizes samples=0x%x! Returning to TRAK_MODE\n", (unsigned int)samples);
                      mlog(msgp);
                      mode = TRAK_MODE;
                   }
                   else
                   {
                     struct sampleList *sampleListp = (struct sampleList *)malloc(sizeof(struct sampleList));
                     numSampleLists++; // increment # of sample lists found
                     sampleLists[numSampleLists-1] = sampleListp;
                     sampleLists[numSampleLists-1]->numSamples = numSamples;
                     sampleLists[numSampleLists-1]->samples = samples;
                     sampleLists[numSampleLists-1]->trak_num = trak_count;
                     sampleLists[numSampleLists-1]->trak_offset = trak_offset;
                     // if (verbose>=2) 
                       // printSampleLists("STSZ_MODE",numSampleLists, sampleLists);
                     mode = STCO_MODE; // now enter mode to get the data offsets within mdat
                     if (verbose>=1) 
                     {
                       sprintf(msgp,"STSZ atom found in trak=%d @%d, %d samples\n", trak_count, offset, numSamples);
                       mlog(msgp);
                     }
                   }
                 }
                 break;
               }
               case STCO_MODE:
               {
                 if (!memcmp(boxname, "stco", 4))
                 {
                   if (debug)
                   {
                     int nr = printNfileChars(fd,boxlen-BOXLAG);
                   }
                   /* stco atom will contain the offsets of all the gpmf samples in the current trak (in the mdat atom)
                    * - read the number of the offsets contained in the stco atom
                    * - store each offset in a sample structured array (for later data retrieval)
                    */
                   int numSamples=0;

                   // subtract BOXLAG-1 because we already read the length and 'stsz' box (8 byte)
                   // ***TODO: need compare numSamples with that found in genStszArray()
                   // ***TODO: need GLOBAL struct that contains sample size AND the array
                   struct sample *samples = genStcoArray(fd, boxlen-BOXLAG-1,sampleLists[numSampleLists-1], &numSamples); 
                   if (samples <= 0) // should return the same list generated by genStszArray()
                   {
                      printf("ERROR collect stco sizes samples=0x%x! Returning to TRAK_MODE\n", (unsigned int)samples);
                      mode = TRAK_MODE;
                   }
                   else if (numSamples != sampleLists[numSampleLists-1]->numSamples)
                   {
                      sprintf(msgp, "ERROR collect stco.numSamples(%d) != stsz.numSamples! Returning to TRAK_MODE\n",
                        numSamples, sampleLists[numSampleLists-1]->numSamples);
                      mlog(msgp);
                      mode = TRAK_MODE;
                   }
                   else
                   {
                     if (debug) printf("\t***FOUND 'stco' atom and info, entering DATA_MODE\n");
                     if (verbose>=1) 
                     {
                       sprintf(msgp,"STCO atom found in trak=%d @%d, %d samples\n", trak_count, offset, numSamples);
                       mlog(msgp);
                     }
                     // if (verbose>=2) 
                       // printSampleLists("STCO_MODE",numSampleLists, sampleLists);
                     mode = DATA_MODE;
                   }
                 }
                 break;
               }
               case DATA_MODE:
               {
                 // Using the STSZ and STCO information, search for the BLE metadata in the
                 // MDAT atom. Offsets should be relative to beginning of file
                 {
                   if (debug) printf("***NOW LOOK FOR THE DATA in MDAT\n");
                   if (verbose>=1) {sprintf(msgp,"Searching MDAT @offset=$d=%d @%d\n", mdat_offset); mlog(msgp);}
                   // if (verbose>=2) 
                     // printSampleLists("DATA_MODE", numSampleLists, sampleLists);
                   mode = TRAK_MODE;
                 }
                 break;
               }
               default:
               {
                 sprintf(msgp,"UNKNOWN state: mode=%d, defaulting to SCAN_MODE\n", mode);
                 mlog(msgp);
                 mode = SCAN_MODE;
                 break;
               }
             } // switch mode state machine

             // if (boxlen > 10000000)
             /* TEMPORARY TEST: see if we can find atoms within atom MDAT (don't seek over it)
               if (boxlen > 500000)
               {
                 // file_index = boxlen-BOXLAG-1; // ?
                 curr_index = lseek(fd, boxlen-2-8, SEEK_CUR);
                 file_index = curr_index;
                 sprintf(msgp,"\t\t%d=lseek(%d, %d, %d)\n", curr_index,fd, file_index, SEEK_CUR); mlog(msgp);
                 nread = curr_index;
               }
             */ // skip over MDAT

             boxframe=0; // reset the boxframe and start reading all over again
             boxp = p-BOXLAG;
             last_box_index = boxindex;
             atom_count++;

           } // atom_check()

          } // boxframe >= BOXLAG

          charcount++;
          if ((debug>=2) && (charcount > 50))
          {
            sprintf(msgp,"\n"); mlog(msgp);
            charcount=0;
          }
        } // findatoms

        if (nread > TAGLAG)
          tagp++; // bump the tag pointer (lags 4 bytes behind fileptr)

        if (nread > BOXLAG)
          boxp++; // bump the atom box ptr (lags 8 bytes behind fileptr)

        p++; // bump buf pointer

      } // n > 0

      else //  EXIT CONDITION: n (bytes read) <= 0
      {
        nerrors++;
        if (nerrors > 0)
        {

         if (testMode & GPMF_TESTS)
         {
           if (numSampleLists > 0)
           {
             populateData(fd, sampleLists, numSampleLists);
             
             bzero(gpmf_sensor_list, MAX_SENSORS*sizeof(struct sensor));
             gpmf_check_sensors(sampleLists, numSampleLists, gpmf_sensors_expected,
                                                        (int *)&gpmf_sensors_detected, &gpmf_sensor_list[0]); 
             init_acc1_data(sampleLists, numSampleLists, gpmf_sensors_detected, gpmf_sensor_list);
             extract_acc1_data(sampleLists, numSampleLists, gpmf_sensors_detected, gpmf_sensor_list);
           }

           if (verbose>=3)
           {
             int i;
             for (i=0; i < numSampleLists; i++)
             {
                struct sampleList *sl = sampleLists[i];
                int numSamples=sl->numSamples;
                struct sample *s = sl->samples;
                int j;
                sprintf(msgp,"DATA SAMPLE LIST SUMMARY#%d\n", i+1); mlog(msgp);
                sprintf(msgp,"\tnumSamples=%d\n", numSamples); mlog(msgp);
                for (j=0; j<numSamples; j++)
                {
                  sprintf(msgp,"\t%d)size   :%d\n", j+1, s->size); mlog(msgp);
                  sprintf(msgp,"\t  offset  :%d\n", s->offset); mlog(msgp);
                  sprintf(msgp,"\t  numTags :%d\n", s->numTags); mlog(msgp);
                  s++;
                }
                sprintf(msgp,"\n"); mlog(msgp);
             }
           } // verbose printout

           if (testMode & TEST_GPMF_TAGS)
           {
              // Test: that all valid tags within all gpmf structures exist
              gpmf_tags_result = gpmf_check_tags(sampleLists, numSampleLists, gpmf_sensors_detected, gpmf_sensor_list);
           }
           if (testMode & TEST_GPMF_NSENSORS)
           {
              // Test: that multiple sensors were detected
              gpmf_nsensors_result = (gpmf_sensors_expected == gpmf_sensors_detected);
           }
           if (testMode & TEST_GPMF_RAMPING)
           {
              // Test: that all sensor data within a trak(s) having sequential ramping patterns
              gpmf_ramping_result = gpmf_check_ramping(gpmf_sensors_detected, gpmf_sensor_list);
           }
           if (testMode & TEST_GPMF_TIMING)
           {
              // Test: that timing between sensor data is consistent and at the right rate
              gpmf_timing_result= gpmf_check_timing(sampleLists, numSampleLists);
           }
           int n;
           {sprintf(msgp,"\n"); mlog(msgp);}
           sprintf(msgp, "# GPMF SENSORS FOUND\n");  mlog(msgp);
           if (!gpmf_sensors_detected)
           {
             sprintf(msgp, "NO sensors found\n");
             mlog(msgp);
           }
           else
           {
             for (n=0; n < gpmf_sensors_detected; n++)
             {
               sprintf(msgp, "sensor#%d dvid=%d name=\"%s\"\n", n+1, gpmf_sensor_list[n].dvid, gpmf_sensor_list[n].name);
               mlog(msgp);
             }
           }

           // GPMF test results
           // IMPORTANT! These exact strings are used to determine PASS/FAIL results by SUGARGLIDER-WIFI-TESTER
           // DO **NOT** CHANGE THESE without making corresponding changes to test_ble_metadata.rb
           //
           {sprintf(msgp,"\n"); mlog(msgp);}
           sprintf(msgp, "# TEST RESULTS:\n");  mlog(msgp);
           sprintf(msgp,
             "GPMF_RAMP_TEST \t\t: %s\n", (testMode & TEST_GPMF_RAMPING)?(gpmf_ramping_result?"PASS":"FAIL"):"NONE"); mlog(msgp);
           sprintf(msgp,
             "GPMF_TAGS_TEST \t\t: %s\n", (testMode & TEST_GPMF_TAGS)?(gpmf_tags_result?"PASS":"FAIL"):"NONE"); mlog(msgp);
           // sprintf(msgp,
             // "GPMF_TIMING_TEST \t: %s\n", (testMode & TEST_GPMF_TIMING)?(gpmf_timing_result?"PASS":"FAIL"):"NONE"); mlog(msgp);
           sprintf(msgp,
             "GPMF_NSENSOR_TEST \t: %s, expected=%d detected=%d\n",
               (testMode & TEST_GPMF_NSENSORS)?(gpmf_nsensors_result?"PASS":"FAIL"):"NONE",
                 gpmf_sensors_expected, gpmf_sensors_detected); 
           mlog(msgp);
         } // GPMF TESTS

         if ((verbose>=2) || show_atoms || show_tags)
         {
           sprintf(msgp,"\n*****************************\n"); mlog(msgp);
           sprintf(msgp,"ATOM COUNT  : %d\n", atom_count); mlog(msgp);
           sprintf(msgp,"TAG  COUNT  : %d\n", tag_count); mlog(msgp);
           sprintf(msgp,"TRAK COUNT  : %d\n", trak_count); mlog(msgp);
           sprintf(msgp,"HDLR COUNT  : %d\n", hdlr_count); mlog(msgp);
           sprintf(msgp,"GPMF COUNT  : %d\n", gpmf_count); mlog(msgp);
           sprintf(msgp,"SAMPLE LISTS: %d\n", numSampleLists); mlog(msgp);
           sprintf(msgp,"*****************************\n\n"); mlog(msgp);
           sprintf(msgp, "\n\n");  mlog(msgp);
         }
         if (logEnabled)
         {
           sprintf(msgp,"See LOG FILE: \"more %s\"\n\n", logPath); mlog(msgp);
         }
         else if (debug)
         {
           sprintf(msgp,"No LOG FILE (disabled)\n\n"); mlog(msgp);
         }
         {sprintf(msgp,"\n"); mlog(msgp);}
         sprintf(msgp,"DONE parsing video file: %s\n\n", filename); mlog(msgp);


         if (log_fd > 0)
           close(log_fd);
         exit(0);
        }
      }

    } while ( (bufread < (BSZ-16)));

    if (logEnabled && (log_fd > 0))
     fsync(log_fd);   // FLUSH the output to the binary log file

  } // while 1

} // mdtool.c main
