/*
 *  Unpublished Copyright (c) 2015 GoPro, Inc., All Rights Reserved.
 *
 *  GoPro, Inc. ("GoPro") CONFIDENTIAL
 *
 *  NOTICE: All information contained herein is, and remains the property of
 *  GoPro. The intellectual and technical concepts contained herein are
 *  proprietary to GoPro and may be covered by U.S. and Foreign Patents, patents
 *  in process, and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material is
 *  strictly forbidden unless prior written permission is obtained from GoPro.
 *  Access to the source code contained herein is hereby forbidden to anyone
 *  except current GoPro employees, managers or contractors who have executed
 *  Confidentiality and Non-disclosure agreements explicitly covering such
 *  access.
 *
 *  The copyright notice above does not evidence any actual or intended
 *  publication or disclosure of this source code, which includes information
 *  that is confidential and/or proprietary, and is a trade secret, of GoPro.
 *  ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
 *  DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
 *  CONSENT OF GOPRO IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 *  AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
 *  AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 *  DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 *  THAT IT MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 */

/**
 *
 * @gp_ble_gatt.h
 *
 * @brief Header File for the GoPro BLE GATT Services.
 *
 */

#ifndef GP_BLE_GATT_H_
#define GP_BLE_GATT_H_

#include <stdint.h>

/* Define the Version Numer of this Header File */
#define GP_BLE_API_MAJOR    0
#define GP_BLE_API_MINOR    93      /* based on the specification 0.93 */

#ifndef __packed
  #define __packed __attribute__((packed))
#endif

/* Name of Msg Queues */
#define BleMqNameToBleSdk       "/Mq_to_BleSdk"
#define BleMqNameToBabyBlue     "/Mq_to_Babyblue"

/* Define the various characteristic attribute offsets. It is based on the index to the GP_COMP_Service[] */
enum _GP_STR_ID {
    GP_STR_ID_CONTROL = 0,          /* The first one must be 0. */
    GP_STR_ID_RESERVED0 = 1,
    GP_STR_ID_CMD_CHAR = 2,
    GP_STR_ID_CMD_CCC = 3,
    GP_STR_ID_CMD_RESP_CHAR = 4,
    GP_STR_ID_CMD_RESP_CCC = 5,
    GP_STR_ID_RESERVED1 = 6,
    GP_STR_ID_SETTINGS_CHAR = 7,
    GP_STR_ID_SETTINGS_CCC = 8,
    GP_STR_ID_SETTINGS_RESP_CHAR = 9,
    GP_STR_ID_SETTINGS_RESP_CCC = 10,
    GP_STR_ID_RESERVED2 = 11,
    GP_STR_ID_QUERY_CHAR = 12,
    GP_STR_ID_QUERY_CCC = 13,
    GP_STR_ID_QUERY_RESP_CHAR = 14,
    GP_STR_ID_QUERY_RESP_CCC = 15,
    GP_STR_ID_RESERVED3 = 16,
    GP_STR_ID_SENSOR_CHAR = 17,
    GP_STR_ID_SENSOR_CCC = 18,
    GP_STR_ID_SENSOR_RESP_CHAR = 19,
    GP_STR_ID_SENSOR_RESP_CCC = 20,
    GP_STR_ID_MAX,
};

#define MAC_ADDR_LEN    6               /* Length of IEEE 802.11 MAC Address */

/* Copy the 6 octets of MAC Address */
#define CP_MAC_ADDR(dst, src)   ((uint8_t *)dst)[0]=((uint8_t *)src)[0];\
                                ((uint8_t *)dst)[1]=((uint8_t *)src)[1];\
                                ((uint8_t *)dst)[2]=((uint8_t *)src)[2];\
                                ((uint8_t *)dst)[3]=((uint8_t *)src)[3];\
                                ((uint8_t *)dst)[4]=((uint8_t *)src)[4];\
                                ((uint8_t *)dst)[5]=((uint8_t *)src)[5];\

/* Define the maximum size of payload data that a BLE Read and Write can do. */
#define GP_MAX_GATT_WRITE_DATA_LEN      80

/* Max Number of Buffers in BLE GATT Data Message Queue */
#define GP_BLE_MSGQ_MAX_NUM_BUFS        100

/* Parameter Structure when event_type is GP_GATT_STREAM_EVENT_TYPE_Conn */
typedef struct {
    uint8_t mac_addr[MAC_ADDR_LEN];
    uint8_t mtu_size;       /* Max size in bytes of each data packet */
} __packed Gp_Ble_Strm_Conn_Struc;

/* Parameter Structure when event_type is GP_GATT_STREAM_EVENT_TYPE_Disconn */
typedef struct {
    uint8_t mac_addr[MAC_ADDR_LEN];
} __packed Gp_Ble_Strm_Disconn_Struc;

/* Parameter Structure when event_type is GP_GATT_STREAM_EVENT_TYPE_Ntfy_CCC */
typedef struct {
    //uint8_t stream_id;
    uint8_t notify_CC_ID;   /* ID of the Char. Config. whose notification is changed */
    uint8_t enable_notify;  /* Is notification enabled? */
} __packed Gp_Ble_Strm_Ntfy_CCC_Struc;

/* Parameter Structure when event_type is GP_GATT_STREAM_EVENT_TYPE_Data */
typedef struct {
    uint8_t stream_id;
    uint8_t data_len;
    uint8_t data[GP_MAX_GATT_WRITE_DATA_LEN];
} __packed Gp_Ble_Strm_Data_Pkt_Struc;

/* Enum of Packet Types to fill in packet_type field of Gp_Ble_Gatt_Stream_Struc */
enum GP_GATT_STREAM_EVENT_TYPE {
    GP_GATT_STREAM_EVENT_TYPE_Conn = 0,
    GP_GATT_STREAM_EVENT_TYPE_Disconn = 1,
    GP_GATT_STREAM_EVENT_TYPE_Data = 2,
    GP_GATT_STREAM_EVENT_TYPE_Ntfy_CCC = 3,

    GP_GATT_STREAM_EVENT_Reserved = 128,    /* All enum above this range is reserved. Please do not use. */

};

/* Format of the packets send in the GATT Control or Data Stream */
typedef struct _Gp_Ble_Gatt_Stream_Struc
{
    uint8_t         event_type;         /* Packet Type. See GP_GATT_STREAM_EVENT_TYPE */
    uint8_t         conn_id;            /* Connection ID */
    union {
        /* Parameter when event_type is GP_GATT_STREAM_EVENT_TYPE_Conn */
        Gp_Ble_Strm_Conn_Struc          connect;
        /* Parameter when event_type is GP_GATT_STREAM_EVENT_TYPE_Disconn */
        Gp_Ble_Strm_Disconn_Struc       disconnect;
        /* Parameter when event_type is GP_GATT_STREAM_EVENT_TYPE_Data */
        Gp_Ble_Strm_Data_Pkt_Struc      data_pkt;
        /* Parameter when event_type is GP_GATT_STREAM_EVENT_TYPE_Ntfy_CCC */
        Gp_Ble_Strm_Ntfy_CCC_Struc      ntfy_CCC;
    };
} __packed Gp_Ble_Gatt_Stream_Struc;

/* Define the maximum header size for each buffer in BLE GATT Msg Queue. */
#define GP_MAX_GATT_HEADER_LEN          (offsetof(Gp_Ble_Gatt_Stream_Struc, data_pkt) + offsetof(Gp_Ble_Strm_Data_Pkt_Struc, data))

/* Max size of each Buffer in BLE GATT Data Message Queue */
#define GP_BLE_MSGQ_MAX_BUF_SIZE        (GP_MAX_GATT_WRITE_DATA_LEN + GP_MAX_GATT_HEADER_LEN)


/************************************************************************************
 * Below are definitions for the common message data structure formats
 ***********************************************************************************/

/**
 * BL Stack configuration parameters
 */
typedef enum
{
    BL_CONFIGURE_AUTO_CONNECT = 0
} BL_configure_settings_t;


/* List of BL command id indexes */
#define BLE_CMD_START_STOP_SCAN     1
#define BLE_START_PAIRING           2
#define BLE_CANCEL_PAIRING          3
#define BLE_GET_SCAN_LIST           4
#define BLE_CMD_RESERVED0           5
#define BLE_GET_WHITELIST           6
#define BLE_CONFIG_WL_DEVICE        7
#define BLE_CONFIG                  8
#define BLE_GET_PAIRING_STATUS      9
#define BLE_GET_CONFIG              10

typedef struct bd_addr_d
{
   uint8_t BD_ADDR0;
   uint8_t BD_ADDR1;
   uint8_t BD_ADDR2;
   uint8_t BD_ADDR3;
   uint8_t BD_ADDR4;
   uint8_t BD_ADDR5;
} __attribute__ ((__packed__)) bd_addr_t;

/* Format of BL command parameters */
typedef struct bleSdkCmd_d {
    unsigned char cmd_id;
    union {
        unsigned char scan_cmd;
        struct {
            bd_addr_t   mac_addr;
            uint8_t     addr_type;
        } start_stop_pairing;
        struct {
            uint8_t first_idx;
            uint8_t num_idxs;
        } get_scan_list; // Also used for whitelist
        struct {
            uint8_t     bit_pos;
            uint8_t     new_val;
            bd_addr_t   mac_addr;
        } config_wl_dev;
        struct {
            uint8_t     setting;
            uint8_t     param;
        } config_ble;
    } cmd_arg;
} __packed bleSdkCmd_t;

/* Format of scan result response header */
typedef struct scan_list_resp_d {
    uint8_t     scan_id;
    uint8_t     total_num_entries;
    uint8_t     first_idx;
    uint8_t     num_entries;
    uint8_t     scan_recs[];
} __packed scan_list_resp_t;

/* Format of the scan response individual scan records
   a table of this structure is pointed by scan_list_resp_t.scan_recs */
typedef struct scan_list_record_d {
    bd_addr_t    mac_addr;
    uint8_t      Address_Type;
    int8_t       RSSI;
    uint8_t      Dev_Name_Offset;
    uint8_t      Dev_Name_Len;
    uint8_t      UUID_128bit_Offset;
    uint8_t      UUID_128bit_Len;
    uint8_t      UUID_16bit_Offset;
    uint8_t      UUID_16bit_Len;
    uint8_t      Man_Spec_Offset;
    uint8_t      Man_Spec_Len;
    uint8_t      Adv_Data_Off;
    uint8_t      Adv_Data_Len;
    uint8_t      Scan_Data_Off;
    uint8_t      Scan_Data_Len;
    uint8_t      Raw_Adv_Data[31];
    uint8_t      Raw_Scan_Data[31];
} __packed scan_list_record_t;

/* format of whitelist record entry */
typedef struct whitelist_record_d {
    bd_addr_t   mac_addr;
    uint16_t    peer_attr;
    uint8_t     dev_name_offset;
    uint8_t     dev_name_len;
    uint8_t     bin_data[31];
} __packed whitelist_record_t;

/* format of whitelist response header */
typedef struct whitelist_resp_d {
    uint8_t     list_id;
    uint8_t     total_recs;
    uint8_t     first_rec;
    uint8_t     num_recs;
    whitelist_record_t recs[];
} __packed whitelist_resp_t;

/* Possible value for the pair status */
typedef enum {
    pair_status_idle        = 0,
    pair_status_connecting  = 1,
    pair_status_connected   = 2,
    pair_status_paired      = 3,
} pair_status_type;

/* Format for get pair status response header */
typedef struct pair_status_d {
    uint8_t status;         /* Use the pair_status_type definitions for this field */
} __packed pair_status_t;

typedef struct ble_config_d {
    uint8_t auto_conn;
} __packed ble_config_t;

/* Bitmap of Peer Device Attributes */
#define PEER_ATTRIB_ACTIVE_POS      0
#define PEER_ATTRIB_CONNECTED_POS   1
#define PEER_ATTRIB_WHITELISTED_POS 2
#define PEER_ATTRIB_MITM_POS        3
#define PEER_ATTRIB_AUTO_CONN_POS   4
#define PEER_ATTRIB_HAVE_SEC_POS    5
#define PEER_ATTRIB_SLAVE_POS       6
#define PEER_ATTRIB_MASTER_POS      7

#define PEER_ATTRIB_ACTIVE          (1<<PEER_ATTRIB_ACTIVE_POS)
#define PEER_ATTRIB_CONNECTED       (1<<PEER_ATTRIB_CONNECTED_POS)      /* A runtime flag */
#define PEER_ATTRIB_WHITELISTED     (1<<PEER_ATTRIB_WHITELISTED_POS)
#define PEER_ATTRIB_MITM            (1<<PEER_ATTRIB_MITM_POS)           /* SSP with MITM (1) or Just-Works (0). NA when !PEER_ATTRIB_HAVE_SEC */
#define PEER_ATTRIB_AUTO_CONN       (1<<PEER_ATTRIB_AUTO_CONN_POS)      /* NA when !PEER_ATTRIB_SLAVE */
#define PEER_ATTRIB_HAVE_SEC        (1<<PEER_ATTRIB_HAVE_SEC_POS)       /* Pairing with SSP */
#define PEER_ATTRIB_SLAVE           (1<<PEER_ATTRIB_SLAVE_POS)          /* Peer is a slave (peripheral) */
#define PEER_ATTRIB_MASTER          (1<<PEER_ATTRIB_MASTER_POS)         /* Peer is a Master (central). Note: Some devices can be both slave and master */

/* Peer attributes for a GoPro Mobile App-like device. Used for default. */
#define BLE_PEER_ATTRIB_MOBILE      (PEER_ATTRIB_ACTIVE|PEER_ATTRIB_WHITELISTED|PEER_ATTRIB_MITM|PEER_ATTRIB_HAVE_SEC|PEER_ATTRIB_MASTER)

#endif  //GP_BLE_GATT_H_

