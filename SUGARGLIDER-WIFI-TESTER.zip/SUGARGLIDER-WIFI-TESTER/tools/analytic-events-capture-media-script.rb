### analytic-events-capture-media-script.rb
# Cycles through all the modes/options and records media.
# The goal is to generate the majority of analytics events and have them
# associated with a media capture to verify that the dashboard captures this
# information correctly.

# To run a single mode use the --mode [MODE] argument
# Valid modes are:
# "VIDEO"
# "VIDEO_LOOPING"
# "VIDEO_PIV"
# "VIDEO_TIMELAPSE"
# "PHOTO"
# "PHOTO_CONTINUOUS"
# "PHOTO_NIGHT"
# "BURST"
# "TIMELAPSE"
# "NIGHTLAPSE"

# To run a single setting over all RES/FPS/FOV use the --filter [SETTING[=VALUE]]
# argument.  The =VALUE is optional to pin to a single value for that setting
# Example 1: --filter video_spot_metering
# Example 2: --filter video_spot_metering=ON

require_relative '../libs/camera'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require 'set'
require 'pp'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = get_wifi_camera(@options[:ip], @options[:pc],
      @options[:serialdev], @options[:logfile])
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
    @video_settings = {
      # RES/FPS/FOV handled individually
      # Mode-specific settings handled individually as well
      :video_spot_metering      => @camera.video_spot_metering_api2.keys,
      :video_low_light          => @camera.video_low_light_api2.keys,
      :video_pt_wb              => @camera.get_protune_white_balance,
      :video_pt_color           => @camera.get_protune_color,
      :video_pt_sharp           => @camera.get_protune_sharpness,
      :video_pt_ev              => @camera.get_protune_exposure,
      :video_pt_iso_mode        => @camera.get_video_protune_iso_modes,
      :video_pt_shutter_speed   => @camera.get_video_protune_shutter_speeds,
      :video_pt_iso             => @camera.get_video_protune_iso,
    }
    @photo_settings = {
      # RES handled individually
      # Mode-specific settings handled individually as well
      :photo_spot_metering      => @camera.photo_spot_metering_api2.keys,
      :photo_pt_wb              => @camera.get_protune_white_balance,
      :photo_pt_color           => @camera.get_protune_color,
      :photo_pt_sharp           => @camera.get_protune_sharpness,
      :photo_pt_ev              => @camera.get_protune_exposure,
      :photo_pt_iso             => @camera.get_photo_protune_iso,
      :photo_pt_iso_min         => @camera.get_photo_protune_iso,
    }
    @multi_photo_settings = {
      # RES handled individually
      # Mode-specific settings handled individually as well
      :multi_photo_spot_meter   => @camera.photo_spot_metering_api2.keys,
      :multi_photo_pt_wb        => @camera.get_protune_white_balance,
      :multi_photo_pt_color     => @camera.get_protune_color,
      :multi_photo_pt_sharp     => @camera.get_protune_sharpness,
      :multi_photo_pt_ev        => @camera.get_protune_exposure,
      :multi_photo_pt_iso       => @camera.get_photo_protune_iso,
      :multi_photo_pt_iso_min   => @camera.get_photo_protune_iso,
    }
    @setup_settings = {
      :setup_orientation        => @camera.setup_orientation_api2.keys,
      :setup_led                => @camera.setup_led_api2.keys,
      :setup_beep_volume        => @camera.setup_beep_api2.keys,
      :setup_osd                => @camera.setup_osd_api2.keys,
      :setup_default_mode       => @camera.setup_default_mode_api2.keys,
      :setup_lcd_auto_off       => @camera.setup_lcd_auto_off_api2.keys,
      :setup_lcd_brightness     => @camera.setup_lcd_brightness_api2.keys,
      :setup_lcd_lock           => @camera.setup_lcd_lock_api2.keys,
      :setup_lcd_display        => @camera.setup_lcd_display_api2.keys,
      :send_locate_camera_api2  => [1, 0],
    }
    # Commands whose symbols should be called directly
    # i.e. NOT through the camera set() method
    @call_direct = Set.new([:send_locate_camera_api2])
    # Skip to help if necessary
    filter_help if @options[:filter] == "help"
    # Finally set the defaults and GO
    set_defaults() # reset to defaults
    @camera.clear_analytics()
  end

  def runtest()
    m = @options[:mode_cm]
    if @options[:filter] != nil
      iterate_setting
    else
      test_video_mode       if m == nil or m == "VIDEO"
      test_video_looping    if m == nil or m == "VIDEO_LOOPING"
      test_video_piv        if m == nil or m == "VIDEO_PIV"
      test_video_timelapse  if m == nil or m == "VIDEO_TIMELAPSE"
      test_photo_mode       if m == nil or m == "PHOTO"
      test_photo_continuous if m == nil or m == "PHOTO_CONTINUOUS"
      test_photo_night      if m == nil or m == "PHOTO_NIGHT"
      test_burst            if m == nil or m == "BURST"
      test_timelapse        if m == nil or m == "TIMELAPSE"
      test_nightlapse       if m == nil or m == "NIGHTLAPSE"
    end
  end

  def cleanup()
    @host.kill_status_process() if @host
  end

  # For modes requiring shutter OFF to end capture (VIDEO/XLapse) @duration
  # refers to the length of media to capture.  For self-terminating modes
  # (Photo, etc.) it refers to busy timeout.
  def set_and_capture(cmd, args)
    args.each { |arg|
      log_info("Setting #{cmd.to_s} to #{arg} and capturing media")
      if @call_direct.include?(cmd)
        @camera.method(cmd).call(arg)
      else
        @camera.set(cmd, arg)
      end
      @camera.start_capture()
      if @stop_required == true
        sleep @duration
        @camera.stop_capture()
      else
        @camera.wait_until_not_busy(0.5, @duration)
      end
    }
  end

  def test_video_mode
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("VIDEO")

    # RES
    set_and_capture(:video_resolution, @camera.get_video_resolution())

    # FPS
    already_set = Set.new
    ["PAL", "NTSC"].each { |vf|
      @camera.set_video_format(vf)
      @camera.get_video_resolution.each { |res|
        all_fps = @camera.get_fps_ntsc(res) if vf == "NTSC"
        all_fps = @camera.get_fps_pal(res) if vf == "PAL"
        log_verb(all_fps)
        fps_arr = []
        all_fps.each { |fps|
          fps_arr << fps if not already_set.include?(fps)
          already_set << fps
        }
        if not fps_arr.empty?
          @camera.set_video_resolution(res)
          set_and_capture(:video_fps, fps_arr)
        end
      }
    }

    # FOV
    log_info("Setting NTSC/1080/30")
    @camera.set_video_format("NTSC")
    @camera.set_video_resolution("1080")
    @camera.set_video_fps("30")
    set_and_capture(:video_fov, @camera.get_video_fov("1080", "30"))

    # Spot-meter
    set_and_capture(:video_spot_metering, @camera.video_spot_metering_api2.keys)

    # Low-light
    if @camera.video_low_light_support?("1080", "60")
      log_info("Setting NTSC/1080/60")
      @camera.set_video_format("NTSC")
      @camera.set_video_resolution("1080")
      @camera.set_video_fps("60")
      set_and_capture(:video_low_light, @camera.video_low_light_api2.keys)
    end

    # ProTune
    if @camera.video_protune_support?
      log_info("Setting NTSC/1080/30 PT ON")
      @camera.set_video_format("NTSC")
      @camera.set_video_resolution("1080")
      @camera.set_video_fps("30")
      @camera.set_video_protune("ON")
      [
        :video_pt_wb            ,
        :video_pt_color         ,
        :video_pt_sharp         ,
        :video_pt_ev            ,
        :video_pt_iso_mode      ,
        :video_pt_shutter_speed ,
        :video_pt_iso           ,
      ].each { |cmd|
        set_and_capture(cmd, @video_settings[cmd])
      }
      test_protune_video_shutter_speed
    end

    # Other settings
    log_info("Setting NTSC/1080/30 PT OFF")
    @camera.set_video_format("NTSC")
    @camera.set_video_resolution("1080")
    @camera.set_video_fps("30")
    @camera.set_video_protune("OFF")
    @setup_settings.keys.each { |cmd|
      set_and_capture(cmd, @setup_settings[cmd])
    }

    # Tag Hilights
    tag_limit = @camera.hilight_tag_limit
    @camera.start_capture()
    (1..(tag_limit+2)).each { |n|
      log_info("Tagging hilight #{n} of #{tag_limit}")
      @camera.tag_hilight()
      sleep(1.5)
    }
    @camera.stop_capture()
  end

  def test_video_looping
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("VIDEO_LOOPING")

    log_info("Setting NTSC/1080/30")
    @camera.set_video_format("NTSC")
    @camera.set_video_resolution("1080")
    @camera.set_video_fps("30")
    @camera.set_video_protune("ON")
    set_and_capture(:video_looping, @camera.get_video_looping_intervals)
  end

  def test_video_piv
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("VIDEO_PIV")

    log_info("Setting NTSC/1080/30")
    @camera.set_video_format("NTSC")
    @camera.set_video_resolution("1080")
    @camera.set_video_fps("30")
    @camera.set_video_protune("ON")
    set_and_capture(:video_piv, @camera.get_video_piv_intervals)
  end

  def test_video_timelapse
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("VIDEO_TIMELAPSE")

    res = @camera.get_video_timelapse_resolution[0]
    log_info("Setting NTSC/#{res}")
    @camera.set_video_format("NTSC")
    @camera.set_video_resolution(res)
    set_and_capture(:video_timelapse, @camera.get_video_timelapse_intervals)
  end

  def test_photo_mode
    @duration = 2
    @stop_required = false
    @camera.set_capture_mode("PHOTO")

    # # RES
    # set_and_capture(:photo_resolution, @camera.get_photo_resolutions())

    # # Spot meter
    # set_and_capture(:photo_spot_metering, @camera.photo_spot_metering_api2.keys)

    # ProTune
    if @camera.photo_protune_support?
    #   set_and_capture(:photo_pt_wb,       @camera.get_protune_white_balance)
    #   set_and_capture(:photo_pt_color,    @camera.get_protune_color)
    #   set_and_capture(:photo_pt_sharp,    @camera.get_protune_sharpness)
    #   set_and_capture(:photo_pt_ev,       @camera.get_protune_exposure)
    #   @camera.set_photo_protune_iso_min(@camera.get_photo_protune_iso.min)
    #   set_and_capture(:photo_pt_iso,      @camera.get_photo_protune_iso)
      @camera.set_photo_protune_iso(@camera.get_photo_protune_iso.max)
      set_and_capture(:photo_pt_iso_min,  @camera.get_photo_protune_iso)
    end
  end

  def test_photo_continuous
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("PHOTO_CONTINUOUS")
    set_and_capture(:photo_continuous, @camera.get_photo_continuous_rates)
  end

  def test_photo_night
    @duration = 60
    @stop_required = false
    @camera.set_capture_mode("PHOTO_NIGHT")
    set_and_capture(:photo_shutter_ev,
      @camera.get_photo_shutter_exposure_intervals)
  end

  def test_burst
    @duration = 60
    @stop_required = false
    @camera.set_capture_mode("BURST")
    # set_and_capture(:multi_photo_burst, @camera.get_multi_photo_burst_rates)

    # # Multi-shot protune
    # @camera.set_multi_photo_burst(@camera.get_multi_photo_burst_rates.min)
    # set_and_capture(:multi_photo_pt_wb,       @camera.get_protune_white_balance)
    # set_and_capture(:multi_photo_pt_color,    @camera.get_protune_color)
    # set_and_capture(:multi_photo_pt_sharp,    @camera.get_protune_sharpness)
    # set_and_capture(:multi_photo_pt_ev,       @camera.get_protune_exposure)
    @camera.set_multi_photo_protune_iso_min(@camera.get_photo_protune_iso.min)
    set_and_capture(:multi_photo_pt_iso,      @camera.get_photo_protune_iso)
    @camera.set_multi_photo_protune_iso(@camera.get_photo_protune_iso.max)
    set_and_capture(:multi_photo_pt_iso_min,  @camera.get_photo_protune_iso)
  end

  def test_timelapse
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("TIMELAPSE")
    set_and_capture(:multi_photo_timelapse,
      @camera.get_multi_photo_timelapse_rates)
  end

  def test_nightlapse
    @duration = 5
    @stop_required = true
    @camera.set_capture_mode("NIGHTLAPSE")
    set_and_capture(:multi_photo_nightlapse,
      @camera.get_multi_photo_nightlapse_rates)
  end

  def test_protune_video_shutter_speed
    already_set = Set.new
    already_fps = Set.new
    ["PAL", "NTSC"].each { |vf|
      log_info("Setting #{vf}")
      @camera.set_video_format(vf)
      @camera.get_video_resolution.each { |res|
        all_fps = @camera.get_fps_ntsc(res) if vf == "NTSC"
        all_fps = @camera.get_fps_pal(res) if vf == "PAL"
        all_shutters = @camera.get_video_protune_shutter_speeds
        all_fps.each { |fps|
          next if already_fps.include?(fps)
          shutter_arr = []
          all_shutters.each { |sh|
            if not already_set.include?(sh)
              if sh == "AUTO"
                shutter_arr << sh
                already_set << sh
              else
                x = sh.split("/")[1].to_f
                y = fps.to_f
                # puts "sh=#{sh}, x=#{x}, y=#{y}, x/y=#{x/y}, x%y=#{x%y}"
                if ((x/y) <= 4) and ((x%y) == 0)
                  shutter_arr << sh
                  already_set << sh
                end
              end
            end
          }
          # pp already_set
          if not shutter_arr.empty?
            log_info("Setting #{res}/#{fps}")
            @camera.set_video_resolution(res)
            @camera.set_video_fps(fps)
            set_and_capture(:video_pt_shutter_speed, shutter_arr)
          end
          already_fps << fps
        } # fps
      } # res
    } # NTSC/PAL
  end

  def iterate_setting()
    mode = @options[:mode_cm]
    setting, val = @options[:filter].split("=")
    @filter_matched = false
    # Iterate setting over video captures if no mode specified
    # unless it is a photo-specific setting
    if mode == nil
      mode = "VIDEO" # default
      mode = "PHOTO" if setting.match(/photo/)
      mode = "BURST" if setting.match(/multi_shot/)
    end

    if [nil, "VIDEO", "VIDEO_PIV", "VIDEO_LOOPING", "VIDEO_TIMELAPSE"].include?(mode)
      mode = "VIDEO" if mode == nil
      @video_settings.each { |s, all_vals|
        next if s.to_s.match(setting) == nil
        execute_filtered(mode, setting, val, s, all_vals)
      }
    end

    if [nil, "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"].include?(mode)
      mode = "VIDEO" if mode == nil
      @photo_settings.each { |s, all_vals|
        next if s.to_s.match(setting) == nil
        execute_filtered(mode, setting, val, s, all_vals)
      }
    end

    if [nil, "BURST", "TIMELAPSE", "NIGHTLAPSE"].include?(mode)
      mode = "VIDEO" if mode == nil
      @multi_photo_settings.each { |s, all_vals|
        next if s.to_s.match(setting) == nil
        execute_filtered(mode, setting, val, s, all_vals)
      }
    end

    mode = "VIDEO" if mode == nil
    @setup_settings.each { |s, all_vals|
      next if s.to_s.match(setting) == nil
      execute_filtered(mode, setting, val, s, all_vals)
    }
    filter_help(supported_settings) if @filter_matched == false
  end

  def execute_filtered(mode, mysetting, myval, camsetting, camvals)
    @filter_matched = true
    log_info("Matched #{mysetting} with setting #{camsetting}")
    log_info("Using mode #{mode}")
    @camera.set_capture_mode(mode)

    # If we want to lock the setting on a single value
    if myval != nil and camvals.include?(myval) == false
      log_warn("*"*80)
      log_warn("*** Can't find value #{myval} in #{camsetting} -- #{camvals}")
      log_warn("*"*80)
      pp myval, camvals
    else
      # If not specified, use all values.  If specified, make into array
      vals = (myval == nil) ? camvals : [myval]
    end
    vals.each { |v|
      case mode
      when "VIDEO", "VIDEO_PIV", "VIDEO_TIMELAPSE", "VIDEO_LOOPING"
        @duration = 5
        @stop_required = true
        all_cap_modes = get_all_vm_res_fps_fov(mode)
        log_verb("Running over #{all_cap_modes.pretty_inspect}")
        all_cap_modes.each { |vf, res, fps, fov|
          log_info("Setting #{vf}/#{res}/#{fps}/#{fov} and capturing")
          @camera.set_video_format(vf)
          @camera.set_video_resolution(res)
          @camera.set_video_fps(fps)
          @camera.set_video_fov(fov)
          set_and_capture(camsetting, [v])
        }
      when "PHOTO", "PHOTO_NIGHT"
        @duration = 60
        @stop_required = false
        @camera.get_photo_resolutions.each { |res|
          log_info("Setting resolution to #{res}")
          @camera.set_photo_resolution(res)
          set_and_capture(camsetting, [v])
        }
      when "PHOTO_CONTINUOUS"
        @duration = 5
        @stop_required = true
        @camera.get_photo_resolutions.each { |res|
          log_info("Setting resolution to #{res}")
          @camera.set_photo_resolution(res)
          set_and_capture(camsetting, [v])
        }
      when "BURST"
        @duration = 60
        @stop_required = false
        @camera.get_photo_resolutions.each { |res|
          log_info("Setting resolution to #{res}")
          @camera.set_multi_photo_resolution(res)
          set_and_capture(camsetting, [v])
        }
      when "TIMELAPSE", "NIGHTLAPSE"
        @duration = 5
        @stop_required = true
        @camera.get_photo_resolutions.each { |res|
          log_info("Setting resolution to #{res}")
          @camera.set_multi_photo_resolution(res)
          set_and_capture(camsetting, [v])
        }
      end
    } # myvals
  end

  def filter_help()
    puts "No filter matches '#{@options[:filter]}'"
    str = "Supported modes (--camera_mode [MODE]) MODE = "
    str += "VIDEO, VIDEO_LOOPING, VIDEO_PIV, "
    str += "PHOTO, PHOTO_CONTINUOUS, PHOTO_NIGHT, "
    str += "BURST, TIMELAPSE, NIGHTLAPSE"
    puts str
    puts "Supported filter strings and values:"
    puts "Can do setting only (i.e. orientation') or also do 'STRING=VAL'"
    puts "to specify setting value (i.e. orientation=UP)"
    pp @video_settings
    pp @photo_settings
    pp @multi_photo_settings
    pp @setup_settings
    exit 1
  end

  # Get all the [vm, res, fps, fov] combinations for a given MODE
  def get_all_vm_res_fps_fov(mode)
    ret = []
    ["NTSC", "PAL"].each { |vm|
      case mode
      when "VIDEO", "VIDEO_LOOPING", "VIDEO_PIV"
        @camera.get_video_resolution.each { |res|
          all_fps = @camera.get_fps_ntsc(res) if vm == "NTSC"
          all_fps = @camera.get_fps_pal(res) if vm == "PAL"
          all_fps.each { |fps|
            @camera.get_video_fov(res, fps).each { |fov|
              if mode == "VIDEO_LOOPING"
                next if @camera.video_looping_support?(res, fps, fov)
              elsif mode == "VIDEO_PIV"
                next if @camera.video_piv_support?(res, fps, fov)
              end
              ret << [vm, res, fps, fov]
            }
          }
        }
      when "VIDEO_TIMELAPSE"
        all_res = @camera.get_video_timelapse_resolution()
        all_res.each { |res|
          if mode == "NTSC"
            fps = @camera.video_timelapse_capture_modes[res][:ntsc_fps]
          else
            fps = @camera.video_timelapse_capture_modes[res][:pal_fps]
          end
          fov = "W"
          ret << [vm, res, fps, fov]
        }
      else
        raise "Unknown camera mode #{mode}"
      end
    }
    return ret
  end # get_all_vm_res_fps_fov
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    #:ip, :pc, :set_defaults,
    use_options = [ :logfile, :verb, :filter, :mode_cm]
    options = t.parse_options(ARGV, use_options)
    options[:ip] = "10.5.5.9"
    options[:pc] = "goprohero"
    options[:set_defaults] = true
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    $LOGLEVEL = $LL_DEBUG if $DEBUG
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
