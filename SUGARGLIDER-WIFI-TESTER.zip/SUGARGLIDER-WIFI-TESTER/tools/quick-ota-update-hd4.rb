# OTA update script for HD4 cameras.  Performs a single OTA update.
# Requires: 
#   - Ruby 1.9.3+
#   - Multipart post gem (gem install multipart-post)
#   - HTTP persistent gem (gem install net-http-persistent)
#   - OTA update firmware file
#
# Note:  The OTA update firmware file is a ZIP file with all necessary
# necessary files at the TOP level (e.g. not in any directories)
######################################
# Do not just zip up the UPDATE folder
######################################
# In Linux, this can be created with the following command:
# "zip OTAUPDATE.zip camera_firmware.bin camera_loaders.bin hd4_update.txt"
#
# Instructions:
#   - Put camera into GOPRO APP mode (may require to pair with smart device first)
#   - Connect to camera AP
#   - Run script: ruby quick-ota-update-hd4.rb 10.5.5.9 /path/to/update.zip

require 'digest'
require 'net/http/persistent'
require 'net/http/post/multipart'
require 'open-uri'
require 'uri'
require 'fileutils'

def calculate_sha1_digest_of(filename)
  buffer = ''
  sha1 = Digest::SHA1.new
  File.open(filename) do |f|
    while not f.eof do
      f.read(4096, buffer)
      sha1.update(buffer)
    end
  end
  return sha1.to_s
end

def http_get(url)
  puts "#{Time.now} \t #{url}"
  begin
    $http.request(URI(url))
  rescue Timeout::Error,
  Errno::ECONNRESET,
  Errno::EHOSTUNREACH,
  Errno::EHOSTDOWN,
  Errno::ECONNREFUSED,
  Errno::ENETUNREACH => e
    puts "HTTP ERROR => #{e.to_s}"
    puts e.backtrace.join("\n")
    puts "Exiting..."
    exit 1
  rescue StandardError => e
    puts "OTHER ERROR => #{e.to_s}"
    puts e.backtrace.join("\n")
    puts "Exiting..."
    exit 1
  end
end

# depends on https://github.com/nicksieger/multipart-post
# gem install multipart-post
def upload_firmware(fw_fname)
  fw_sha = calculate_sha1_digest_of(fw_fname)
  uri = URI.parse("http://10.5.5.9:8080/gp/gpUpdate")
  puts "Uploading #{fw_fname} (sha1=#{fw_sha}) to #{uri}"

  # Craft the request
  post = Net::HTTP::Post::Multipart.new uri.path,
    "DirectToSD" => '1',
    "sha1" => fw_sha,
    "update" => "submit",
    "file" => UploadIO.new(File.new(fw_fname), "application/zip", "firmware.gpu")
  begin
    response = Net::HTTP.start(uri.host, uri.port, :read_timeout => 300) { |http|
      http.request(post)
    }
  rescue StandardError => e
    puts e.to_s
    puts e.backtrace.join("\n")
    puts "ERROR: HTTP POST failed."
    return nil
  end
  return response
end

def do_wifi_fw_update()
  puts "Entering OTA Update Mode..."
  http_get("http://10.5.5.9/gp/gpControl/command/fwupdate/download/start")
  ret = upload_firmware($FW_FILE)
  if ret == nil
    puts "ERROR: Uploading OTA file failed"
    exit 1
  end
  sleep 5.0
  puts "HTTP status code=#{ret.code}, body=#{ret.body}"
  puts "Starting OTA Update (if download was successful)..."
  return true
end

def usage()
  puts "Usage: ruby quick-ota-update-hd4.rb [CAM_IP] [FW_FILE]"
  puts "Example: ruby quick-ota-update-hd4.rb 10.5.5.9 OTAUPDATE.zip"
  exit 1
end

# script starts here
$CAM_IP  = ARGV[0]
$FW_FILE = ARGV[1]
if $CAM_IP == nil
  puts "Camera IP is required"
  usage()
elsif $FW_FILE == nil or !File.exists?($FW_FILE)
  puts "Cannot find firmware file (#{$FW_FILE})"
  usage()
end

$http = Net::HTTP::Persistent.new($CAM_IP)
ret = do_wifi_fw_update()
