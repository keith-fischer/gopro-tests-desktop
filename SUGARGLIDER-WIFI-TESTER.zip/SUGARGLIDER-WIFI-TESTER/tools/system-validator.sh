#!/bin/bash

# Programs to check for: - DONE to AtomicParsley
# - ruby & version
# - gem
# - curl
# - wget
# - vim
# - git
# - minicom
# - AtomicParsley
# - java
# - exiv2 - used by muid test
# Required gems: - DONE
# - hex_string
# - multipart-post
# - net-http-persistent
# - json
# - serialport
# - dnssd

# TODO:
# - libssl-dev - How to determine?
# - libavahi-compat-libdnssd-dev - Determine by looking for correct directories?
# - ffprobe
# - jpegquality
# - mp4v2-utils or mpeg4ip-utils
# - imagemagick

# Power cable networking connected doohicky? - TODO

echo -e "\e[91mPLEASE NOTE: This tool is far from finished.\e[0m"
echo ""
echo -e "\e[96mValidating your system...\e[0m"

# Check for if running as root.
#if [[ $EUID -ne 0 ]]; then
#  echo -e "Script is running with root permissions."
#fi

# ruby & ruby version
echo -e "\e[93m  Checking for ruby...\e[0m"
HAZ_RUBY=`which ruby`
if [ $HAZ_RUBY ]
then
  echo -e "\e[92m    Found ruby: \e[94m${HAZ_RUBY}\e[0m"
  HAZ_VERSION=`ruby --version`
  HAZ_VERSION=($HAZ_VERSION)
  echo -e "\e[92m    Found ruby version: \e[94m${HAZ_VERSION[1]}\e[0m"
else
  echo -e "\e[91m    Could not find ruby.\e[0m"
fi

# gem & gems
echo -e "\e[93m  Checking for gem...\e[0m"
HAZ_GEM=`which gem`
if [ $HAZ_GEM ]
then
  echo -e "\e[92m    Found gem: \e[94m${HAZ_GEM}\e[0m"
  echo -e "\e[93m    Checking for required gems...\e[0m"
  HAZ_GEMS=`gem list --no-verbose`
  HAZ_GEMS=($HAZ_GEMS)
  GEMS=("hex_string" "multipart-post" "net-http-persistent" "json" "serialport" "dnssd")
  for i in "${!GEMS[@]}"
  do 
    echo -e "\e[93m      Checking for ${GEMS[i]}...\e[0m"
    [[ "${HAZ_GEMS[@]}" =~ "${GEMS[i]}" ]] && \
    echo -e "\e[92m        Found ${GEMS[i]}.\e[0m" || \
    echo -e "\e[91m        Could not find ${GEMS[i]}.\e[0m"
  done
else
  echo -e "\e[91m    No gem. Can't validate installed gems either.\e[0m"
fi

# other programs
PROGS=("curl" "wget" "vim" "git" "minicom" "AtomicParsley" "java" "exiv2")
for i in "${!PROGS[@]}"
do
  echo -e "\e[93m  Checking for ${PROGS[i]}...\e[0m"
  HAZ_PROG=`which ${PROGS[i]}`
  if [ $HAZ_PROG ]
  then
    echo -e "\e[92m    Found ${PROGS[i]} at: \e[94m${HAZ_PROG}\e[0m"
  else
    echo -e "\e[91m    Could not find ${PROGS[i]}.\e[0m"
  fi
done

echo -e "\e[96mValidating complete.\e[0m"
echo ""
