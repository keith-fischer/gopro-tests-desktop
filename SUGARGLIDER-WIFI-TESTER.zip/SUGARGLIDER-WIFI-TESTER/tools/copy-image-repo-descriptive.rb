require 'fileutils'
require 'yaml'
require 'json'
#require 'optparse'
#require 'smb'
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/utils'

# require_relative '../libs/camera_mode_banner'


def processfiles(options)
  rc= false
  return rc if options == nil
  #validate input info
  path = options['-src'].to_s
  if path.length>0 and path.include?('smb:')
    #if not SMB::Dir.exist?("smb://PC-SQASD.gopro.lcl/Automation2/ImageRepo/")
      puts 'Invalid options[\'-src\']'
      return rc
    #end
  else
    if not Dir.exist?(path)
      puts "Invalid path: #{path}"
      return rc
    end
  end
  jname = File.basename(path)
  jpath = path+'/'+jname+'.json'


  jobj = Utils.loadJSON(jpath)
  if jobj[0]
    imagelist = jobj[1] if jobj[1]
    imageidx, imagemode = makeindex(imagelist,jpath)
    rc = true
  else
    puts 'NOT FOUND ImageList JSON'

  end


  return rc
end

def renamefile(oldf,newf)
  rc = false
  diro,fileo,exto = Utils.getpathparts(oldf)
  dir,file,ext = Utils.getpathparts(newf)

  mp4 = file+ext
  lrv = file+'.LRV'
  thm = file+'.THM'

  mp4o = fileo+ext
  lrvo = fileo+'.LRV'
  thmo = fileo+'.THM'

  if File.exist?(oldf)
    File.rename(oldf,newf)
    if File.exist?(newf)
      rc= true
      puts 'rename:'+oldf+'<>'+newf
    else
      puts 'FAILED rename:'+oldf+'<>'+newf
    end
  end
  return rc
end

def findnextfileindex(counter,mp4)
  rc = false

  numstr = counter.to_s.rjust(4, '0')

  dir,file,ext = Utils.getpathparts(mp4)
  gpname = file[0..3]
  newmp4 = gpname+numstr+ext
  newname = dir+'/'+newmp4
  while File.exist?(newname)
    counter += 1
    numstr = counter.to_s.rjust(4, '0')
    newmp4 = gpname+numstr+ext
    newname = dir+'/'+newmp4
  end
  newlrv = gpname+numstr+'.LRV'
  newthm = gpname+numstr+'.THM'
  #puts 'Reindex:'+file+'.MP4'+'<>'+newmp4

  if renamefile(mp4,newname)
    newname = dir+'/'+newlrv
    oldname = dir+'/'+file+'.LRV'

    if renamefile(oldname,newname)
      newname = dir+'/'+newthm
      oldname = dir+'/'+file+'.THM'
      #puts 'Reindex:'+file+'.LRV'+'<>'+newlrv

       if not renamefile(oldname,newname)
          puts 'Failed reindex:'+file+ext+'<>'+newthm
       else
         rc=true
       end

    else
      puts 'Failed reindex:'+file+ext+'<>'+newlrv

    end
  else
    puts 'Failed reindex:'+file+ext+'<>'+newmp4
  end

  return rc, counter, dir, newmp4, newlrv, newthm
end

def makeindex(imagelist,jpath)
  rc = false
  imageidx = {}
  imagemode = {}
  imagerpt =[]
  counter = 0
  rpt=0
  renamecount = 0
  deletecount=0
  imagecount=imagelist.length
  imagelist.each_index { |id|
    puts id.to_s + '#######################'
    if id==3
      id=3
    end
    counter += 1
    parentname = File.basename(imagelist[id]['path'])
    mp4 = imagelist[id]['mp4']

    mode = imagelist[id]['camera']

    dir,file,ext = Utils.getpathparts(jpath)
    gppath = dir + '/' + parentname+'/'+mp4
    if File.exists?(gppath)
      rc, counter, dir2, newmp4, newlrv, newthm = findnextfileindex(counter, gppath)
      if rc
        imagelist[id]['mp4']=newmp4
        imagelist[id]['lrv']=newlrv
        imagelist[id]['thm']=newthm
        imageidx[newmp4]=mode
        imagemode[mode]=newmp4
        imagerpt[rpt]=mode+ ' = ' +mp4+'>>'+newmp4
        rpt +=1
        Utils.saveText(dir+'/'+file+'.txt',imagerpt.join("\n"))
        #jobj[1]=imagelist
        puts 'save json' + newmp4
        Utils.saveJSON(jpath, imagelist)
        renamecount+=1
        rc=true
      end
    else
      #  filename = File.basename(f, File.extname(f))
      # File.rename(f, folder_path + filename.capitalize + File.extname(f))
      rc = false
      item = imagelist.delete_at(id)
      puts 'DELETE: '+gppath
      puts item.to_s
      #jobj[1]=imagelist
      Utils.saveJSON(jpath,imagelist)
      deletecount+=1
      imagerpt[rpt]='DELETE:'+mode+ ' = ' +gppath
      rpt +=1
      txt = imagerpt.join("\n")
      Utils.saveText(dir+'/'+file+'.txt',txt)
    end
  }
  puts 'rename='+renamecount.to_s
  puts 'delete='+deletecount.to_s
  puts 'total='+imagecount.to_s

  return imageidx, imagemode
end

# #iterate filelog
# #check file path
# #orphan files get renamed
# def validatelist
#   return false if @imagelist == nil || @imagelist.length==0
#   @imagelist.each_index { |id|
#     repopath = @imagelist[id]['path']
#     mp4 = @imagelist[id]['mp4']
#     gppath = repopath + '/' + mp4
#
#     if File.exists?(gppath)
#       #@imagelist[id]['validate']=true
#       puts 'FOUND: '+gppath
#       idx = getindexfromname("GOPR",mp4)
#
#     else
#       #  filename = File.basename(f, File.extname(f))
#       # File.rename(f, folder_path + filename.capitalize + File.extname(f))
#       item = @imagelist.delete_at(id)
#       puts 'DELETE: '+gppath
#     end
#   }
#   @imagelist.each_index { |id|
#     @modemap[@imagelist[id]['camera']]=id  #last dupe overides previous
#   }
#
# end

def getoptions(argv)
  rc =false
  # op = OptionParser.new(argv)
  # options = {}
  # check if there are even set of params given
  if ARGV.count.odd?
    puts 'invalid number of arguments'
    exit 1
  end

  # holds key/value pair of cl params {key1 => value1, key2 => valye2, ...}
  opts = {}

  (ARGV.count/2).times do |i|
    k,v = ARGV.shift(2)
    opts[k] = v # create k/v pair
  end

  # set defaults if no params are given
  if opts.key?('-src')
    rc = true
  end
  return rc, opts
end
#############################################
# Execution starts here
# Reindex the image files
# copy image file to alternate repo with descriptive name
# Iterate json for file rename and map back into json and file
# create a map log file
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO

  begin
    rc, options = getoptions(ARGV)
    if not rc
      puts "Failed: no -src directory or -dst directory"
      puts "EXAMPLE: -src 'smb://PC-SQASD.gopro.lcl/Automation2/ImageRepo/PIPE-02.00.00X' -dst 'smb://PC-SQASD.gopro.lcl/Automation2/ImageRepoDesriptive'"
    end
    options[:platform] = Utils.os()
    options[:projroot] = Utils.getprojroot()
    options[:config_info] = YAML.load_file("#{options[:projroot]}/config/media_mgr.conf")
    options[:image_repo] = options[:config_info]['ImageRepo']
    options[:image_repo2] = options[:config_info]['ImageRepo2'] #fwqa

    rc= processfiles(options)
    if rc
      puts 'processfiles Success'
    else
      puts 'processfiles Failed'
    end

    puts('Done')
    

  rescue StandardError => e
    puts(e.to_s)
    puts(e.backtrace.join("\n"))
  end
end

