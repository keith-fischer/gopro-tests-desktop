require 'base64'
require 'rest-client'
require_relative '../libs/wifi_camera'
class Camera_mode_banner


  def initialize(ip,port, info)
    @baseurl = ip
    @port = port
	@info = ""
	@info =info if info != nil
  end
  #http://localhost:8080/api/CtrlMsg/getCtrlMsg/?cmdname=SetBanner?cmdvalue=bW9kZS1WSURFT3xzdWJtb2RlLVZpZGVvfGZvcm1hdC1OVFNDfHJlcy0yLjdLfGZwcy02MHxmb3YtV2lkZXxsb3dsaWdodC1PTnxzcG90LU9OfHByb3R1bmUtT058d2hpdGUtNTUwMEt8Y29sb3ItR29Qcm8gQ29sb3J8aXNvLTY0MDB8c2hhcnAtSGlnaHxldmMtLTEuMA==?cmddata=QQQQQQQQQQ
  def prepinfoforbanner(modeinfo)
    #"mode-[[mode]]|submode-[[submode]]|format-[[format]]|res-[[res]]|fps-[[fps]]|fov-[[fov]]|lowlight-[[lowlight]]|spot-[[spot]]|protune-[[protune]]|white-[[white]]|color-[[color]]|iso-[[iso]]|sharp-[[sharp]]|evc-[[evc]]"
    strmodeinfo = modeinfo.to_s
    return strmodeinfo
  end

  def setbanner(mode_banner,mode_label)
    mode_info = prepinfoforbanner(mode_banner)
    b64 = Base64.strict_encode64(mode_info)
    b64=b64.gsub("\n", "")
    b64=b64.gsub(", nil",'' )
	  @info = Base64.strict_encode64(mode_label)
    req = "http://#{@baseurl}:#{@port}/api/CtrlMsg/getCtrlMsg/?cmdname=SetBanner?cmdvalue=#{b64}?cmddata=#{@info}"
    puts req
    #puts 'http://192.168.52.111:8081/api/CtrlMsg/getCtrlMsg/?cmdname=SetBanner?cmdvalue=bW9kZS1WSURFT3xzdWJtb2RlLVZpZGVvfGZvcm1hdC1OVFNDfHJlcy0yLjdLfGZwcy02MHxmb3YtV2lkZXxsb3dsaWdodC1PTnxzcG90LU9OfHByb3R1bmUtT058d2hpdGUtNTUwMEt8Y29sb3ItR29Qcm8gQ29sb3J8aXNvLTY0MDB8c2hhcnAtSGlnaHxldmMtLTEuMA==?cmddata=QQQQQQQQQQ'

    return sendHttp(req)
  end

  def setlabel(mode_label)
    @info = Base64.strict_encode64(mode_label)
    req = "http://#{@baseurl}:#{@port}/api/CtrlMsg/getCtrlMsg/?cmdname=SetLabel?cmdvalue=?cmddata=#{@info}"
    puts req
    #puts 'http://192.168.52.111:8081/api/CtrlMsg/getCtrlMsg/?cmdname=SetBanner?cmdvalue=bW9kZS1WSURFT3xzdWJtb2RlLVZpZGVvfGZvcm1hdC1OVFNDfHJlcy0yLjdLfGZwcy02MHxmb3YtV2lkZXxsb3dsaWdodC1PTnxzcG90LU9OfHByb3R1bmUtT058d2hpdGUtNTUwMEt8Y29sb3ItR29Qcm8gQ29sb3J8aXNvLTY0MDB8c2hhcnAtSGlnaHxldmMtLTEuMA==?cmddata=QQQQQQQQQQ'

    return sendHttp(req)
  end

  def sendHttp(req)
    rc = nil
    begin
      #http://127.0.0.1:8888/reporttestcase/runid=11891
      # _URL = "http://#{ENV['TR_IP_PORT']}/reporttestcase/runid=#{runid}"
      #response = RestClient.get(req,:content_type => 'text') # 'application/json')

      puts "Update banner: #{req}"
      response = RestClient.get req # 'application/json')
      if response
        #"<CtrlMsg xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://schemas.datacontract.org/2004/07/SelfhostWebApi"><CommandData></CommandData><CommandName>SetBanner</CommandName><CommandSuccess>false</CommandSuccess><CommandValue>WyJgbmlsXQ==</CommandValue></CtrlMsg>"
        if response.include? "<CommandSuccess>true<"
          puts ("Success")
        else
          puts ("FAILED <CommandSuccess>true<") #{response.status}" )
        end
        rc = response
      else
        puts ("FAILED Banner Display Update")
        puts (req)
      end

    rescue => e
      puts ("ERROR Banner Display Update:" + req)
      puts (e.message)
    end
    return rc
  end
end