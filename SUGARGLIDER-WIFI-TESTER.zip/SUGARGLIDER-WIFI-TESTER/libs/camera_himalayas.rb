module Himalayas
  def init
    @name = "HIMALAYAS"
    log_verb("Instantiating #{name} camera")
    @remote_api = 2  #remote smarty api version 2 (ie http://10.5.5.9/gp/gpControl/setting/1/0)
    @data_log_model = 17  # Camera model number for analytics purposes
    @analytics_version = "0.0.0"

    @audio_channels       = 1     #in phase 1
    @audio_codec          = "aac"
    @audio_sample_rate    = 48000
    @audio_bitrate        = 64    #in kbps per channel.
    @avc_profile_level    = "MAIN"  # Same as Uluwatu
    # Support for changing preview bitrate via BV command
    @chg_prev_br_support  = nil #TBD
    # Support for changing preview resolution via BV command
    @chg_prev_res_support = true
    @colorspace           = "yuvj420p"
    @video_codec          = "h264"
    @total_lrv_bitrate    = 0.8 #Mbps, (includes video + audio + data)
    @hilight_tag_limit    = 100

    #video
    @video_low_light_support    = false
    @video_protune_support      = false
    @video_timelapse_support    = false
    @video_piv_support          = false
    @video_looping_support      = true
    @looping_is_video_setting   = true
    #photo
    @photo_spot_metering_support      = true
    @photo_continuous_support         = false
    @photo_night_support              = false
    @photo_protune_support            = false
    #multi_photo
    @multi_photo_spot_metering_support = true
    @multi_photo_nightlapse_support    = false
    @multi_photo_protune_support       = false

    # preview stream testing flag
    @test_preview_stream     = false

    #photo's preview stream
    @photo_ts = {
      :lrv_aspect_ratio => "4:3",
      :lrv_width        => 320,
      :lrv_height       => 240
    }

    @capabilities = { #cc
      :has_camera_roll      => true, #TBD?
      :has_ota              => true,  #over the air firmware update
      :has_ltp              => true, #TBD?
      :has_3D               => false,
      :has_ccl              => true,   #camera control library #TBD?
    }

    @defaults = {
      :setup_video_format     => "NTSC",
      :video_looping          => "OFF", #p70
      :video_resolution       => "720_SUPER",
      :video_fps              => "60",
      :video_fov              => "W",
      :video_low_light        => "ON", #see p33 Himalaya spec ON for 720S
      :video_spot_metering    => "OFF",
      :photo_resolution       => "8WIDE",
      :photo_spot_metering    => "OFF",
      :multi_photo_resolution => "8WIDE",
      :multi_photo_burst      => "10_2",
      :multi_photo_timelapse  => "0.5",
      :multi_photo_spot_meter => "OFF",
      :setup_orientation      => "UP",
      :setup_led              => "BOTH",
      :setup_beep             => "ON"
    }

    #Initial camera setup before executing any tests
    @setup = {
      :setup_led              => "BOTH",
      :setup_beep             => "ON"
    }

    # Commands that don't have prerequisites  #TBD - verify these settings
    # Wifi commands to test
    @cmds = [
      :setup_beep,
      :setup_led,
      :video_spot_metering,
      :photo_spot_metering,
      :multi_photo_spot_meter,
      :setup_orientation,
      :setup_video_format
      #HALEIWA: :setup_lcd_brightness,
      #HALEIWA: :setup_lcd_auto_off
    ]

    # TBD? can we leave this in for Himalaya? Haleiwa ONLY?
    # Data structure for preview specifications
    # Basically come in 2 flavors.  Fullscreen and Widescreen
    # Fullscreen is 4:3 and widescreen is anything >4:3
    @preview = {
      # QVGA, WQVGA.  bitrate in bps
      "LOW" => {
      :bitrate => {
      :LOW  => 311040,
      :MED  => 500000,
      :HIGH => 750000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 240,
      :width_fs         => 320, # QVGA
      :width_ws         => 432, # WQVGA
      },
      # VGA, QVGA.  bitrate in bps
      "HIGH" => {
      :bitrate => {
      :LOW  => 1221120,
      :MED  => 2000000,
      :HIGH => 3000000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 480,
      :width_fs         => 640, # QVGA
      :width_ws         => 848, # WQVGA
      },
    }

    #TBD looping_chapter_len is NOT in the Himalaya spec
    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 5,
      "120"   => 5,
      "MAX"   => 5,
    }

    #TBD chapter size is NOT in the Himalaya spec
    # File size limit for videos after which it is split
    @chapter_size = 2<<30 # 2 GB

    #TBD no reference to LRV in the spec
    #TBD no reference to THM in the spec
    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    @video_capture_modes = {
      "1080"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      },
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => false,
      :looping    => true,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 9.99,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,  #p33 in the spec
      :looping    => true,
      },
      } # end fps
      }, # end 1080
      "720_SUPER"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => false,
      :looping    => true,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,  #p33 spec
      :looping    => true,
      },
      } # end fps
      }, # end 720_SUPER
      "720"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => false,
      :looping    => true,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => false,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => false,
      :looping    => true,
      },
      } # end fps
      }, # end 720
    } # end @video_capture_modes

    # Photo Modes
    @photo_modes = {
      "8WIDE" => {
      :width        => 3264,
      :height       => 2448,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 97.0,
      :burst => {
      "10_2"  => { :min_quality  => 97.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 97.0 },
      "5"   => { :min_quality  => 97.0 },
      "10"  => { :min_quality  => 97.0 },
      "30"  => { :min_quality  => 97.0 },
      "60"  => { :min_quality  => 97.0 },
      }, # end time_lapse modes
      }, # end 8WIDE
    } # end PHOTO mode
  end # end init
end # end module Rockypoint
