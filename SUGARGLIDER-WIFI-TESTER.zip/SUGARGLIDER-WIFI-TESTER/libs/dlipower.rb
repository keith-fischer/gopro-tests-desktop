# dlipower.rb

require 'base64'
require 'net/http'
require_relative 'log_utils'

$STATUS_OFF = "OFF"
$STATUS_ON  = "ON"
$STATUS_UNK = "UNK"

class PowerStrip
  include LogUtils
  attr_accessor
  attr_reader
  
  def initialize(ip, user, pw)
    if [ip, user, pw].include?(nil)
      log_warn("Not initializing powerstrip due to NIL arg(s)")
      log_warn("(ip=#{ip}, user=#{user}, pw=#{pw})")
      return nil
    end
    @ip = ip
    @username = user
    @password = pw
    @name = nil
    @status = [$STATUS_UNK]*8
    @wait_after_cmd = 2.0
  end
  
  # url is 
  def http_get(url)
    uri = URI.parse("http://#{@ip}/#{url}")
    log_debug(uri)
    
    http = Net::HTTP.new(uri.host, uri.port)
    req = Net::HTTP::Get.new(uri.request_uri)
    req.basic_auth(@username, @password)
    log_debug(http)
      
    retries = 3
    retry_interval = 5
    (1..retries).each { |n|
      begin
        resp = http.request(req)
      rescue StandardError => e
        log_error("HTTP ERROR => " << e.to_s)
        sleep retry_interval
        next
      end
      resp_code = resp.code.to_i
      err_msg = resp.body.to_s
      if resp_code == 200
        return resp.body
      elsif resp_code == 400
        err_msg  = "Item not found"
      elsif resp_code == 403
        err_msg = "No permission to perform requested action"
      elsif resp_code >= 500
        err_msg = "Socket busy"
      end
      log_warn(err_msg)
      sleep retry_interval
    }
    return nil    
  end # end http_get
  
  # True on success, false on failure
  def turn_off(n_outlet)
    ret = http_get("outlet?#{n_outlet}=OFF")
    sleep @wait_after_cmd
    return ret != nil
  end
  
  # True on success, false on failure
  def turn_on(n_outlet)
    ret = http_get("outlet?#{n_outlet}=ON")
    sleep @wait_after_cmd
    return ret != nil
  end
  
  # True on success, false on failure
  def cycle_outlet(n_outlet, delay=3)
    ret = turn_off(n_outlet)
    if ret == false
      log_warn("Turning OFF outlet #{n_outlet} failed")
      return false
    end
    delay = delay - @wait_after_cmd
    sleep delay if delay > 0
    ret = turn_on(n_outlet)
    if ret == false
      log_warn("Turning ON outlet #{n_outlet} failed")
      return false
    end
    sleep 5
    return true
  end
  
  # True on success, false on failure.  Results in @status
  def get_status()
    result = []
    data = http_get("index.htm")
    return false if data == nil
    re = /outlet.\d=(ON|OFF)/
    m = data.scan(re) # Returns an array of arrays [["ON"], ["OFF"], ...]
    return false if m.length != 8
    m.each { |outlet|
      # Status is the opposite of what is on the page 
      # (i.e. outlet is OFF so page displays link to turn it ON)
      if outlet[0] == "ON"
        result << $STATUS_OFF
      else
        result << $STATUS_ON
      end
    }
    @status = result
    log_info("Outlet Status  #{@status}")
    return true
  end  
end # end class PowerStrip

if __FILE__ == $0
  ip = "192.168.0.100"
  user = "admin"
  pw = "1234"
  ps = PowerStrip.new(ip, user, pw)
  #ps.turn_on(8)
  ps.cycle_outlet(8)
  #ps.turn_off(8)
  ps.get_status
end
