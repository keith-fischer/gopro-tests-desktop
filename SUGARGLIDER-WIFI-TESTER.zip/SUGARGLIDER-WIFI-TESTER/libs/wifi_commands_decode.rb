module WifiCommandsDecode
  def wifi_success;  0; end

  def wifi_fail; 1; end

  # wifi-style hex string to int
  def wifi_hstoi(hs)
    hs_arr = hs.split("%")
    hs_arr.reject!{ |h| h.empty? }
    return hs_arr.map { |h| h.to_i(16) }
  end

  # wifi style int to hex string. 12 => %0c
  def wifi_itohs(i)
    return "%" + "%02x" %i
  end

  def decode_lcd(resp, param, expected=nil)
    wifi_pass  = resp.body[0].ord == wifi_success
    detected  = wifi_itohs(resp.body[1].ord)  # region of the screen
    if expected == nil
      expected  = wifi_hstoi(param)[0]
    end
    log_debug("param=%s, expected=%s, detected=%s" \
    %[param, expected, detected])
    retval = {
      :wifi_pass => wifi_pass,
      :detected => detected,
      :expected => expected,
      :data     => resp.body[2..122].unpack('H*')[0],
      :success  => (wifi_pass and (detected == expected)),
    }
    return retval
  end

  # 'expected' not used
  def decode_status_secondary(resp, ignored_param=nil, expected=nil)
    success = (resp.length >= 7)
    ret = {
      :wifi_pass                 => true,
      # Same as 'sx' (decoded in camera.rb)
      :photos_available         => resp.body[0..1].unpack("H*")[0].to_i(16),
      :photos_on_card           => resp.body[2..3].unpack("H*")[0].to_i(16),
      :video_minutes_available  => resp.body[4..5].unpack("H*")[0].to_i(16),
      :videos_on_card           => resp.body[6..7].unpack("H*")[0].to_i(16),
      :bacpac_major_ver         => resp.body[8].ord,
      :bacpac_minor_ver         => resp.body[9].ord,
      :success                  => success,
    }
    return ret
  end

  # Decode methods to do simple checking for pass/fail and expected values
  def decode_wifi_pass_fail(resp, ignored_args=nil, expected=nil)
    wifi_pass = resp.body[0].ord == wifi_success
    retval = {
      :wifi_pass => wifi_pass,
      :success  => wifi_pass,
    }
    return retval
  end

  # If 'expected' or param is supplied, :success will filled in
  # param - The key passed to wifi command
  # expected - The expected value of the detected byte in 'wifi hex'
  #           (usually wifi_cmd[key] => expected)
  def decode_1byte_option(resp, param, expected=nil)
    wifi_pass = resp.body[0].ord == wifi_success
    detected = wifi_itohs(resp.body[1].ord)
    log_debug("param=%s, expected=%s, detected=%s" \
    %[param, expected, detected])

    if expected == nil and param == nil
      expected = success = "unknown"
    end

    #set
    if expected != nil
      success = (wifi_pass and (detected.to_s.upcase == expected.to_s.upcase))

      retval = {
        :wifi_pass => wifi_pass,
        :detected => detected.upcase,
        :expected => expected.upcase,
        :success  => success
      }

      #get
    else
      success = wifi_pass

      retval = {
        :wifi_pass => wifi_pass,
        :detected => detected.upcase,
        :success  => success
      }
    end

    return retval
  end

  # 'expected' not used
  def decode_battery_level(resp, param, expected=nil)
    wifi_pass = resp.body[0].ord == wifi_success
    level = resp.body[1].ord
    valid_level = (0 <= level) and (level <= 100)
    retval = {
      :wifi_pass => wifi_pass,
      :level    => level,
      :success  => (wifi_pass and valid_level),
    }
    return retval
  end

  def decode_bacpac_se(resp, param, expected=nil)
    retval = {
      :ok                         => resp.body[0].ord == 0,
      :success                    => resp.body[0].ord == 0,
      :battery                    => resp.body[1].ord,
      :wifi_mode                  => resp.body[2].ord,
      :bluetooth_mode             => resp.body[3].ord,
      :wifi_rssi                  => resp.body[4].ord,
      :shutter                    => resp.body[5].ord == 1,
      :preview_status             => resp.body[8].ord >> 4,
      :preview_mode               => resp.body[8].ord & 0x0F,
      :camera_power               => resp.body[9].ord == 1,
      :wifi_error_recovery_active  => resp.body[10].ord == 1,
      :camera_ready               => resp.body[11].ord == 1,
      :camera_model               => resp.body[12].ord,
      :camera_protocol_version    => resp.body[13].ord,
      :camera_attached            => resp.body[14].ord == 1,
    }
    return retval
  end

  def decode_bacpac_cv(resp, param, expected=nil)
    wifi_pass   = resp.body[0].ord == wifi_success
    ver_maj     = resp.body[1].ord & 0xF0
    ver_min     = resp.body[1].ord & 0x0F
    mdl         = resp.body[2].ord
    id          = resp.body[3..4].unpack("H*")[0].to_i(16)
    boot_maj    = resp.body[5].ord
    boot_min    = resp.body[6].ord
    boot_bld    = resp.body[7].ord
    rev         = resp.body[8].ord
    major       = resp.body[9].ord
    minor       = resp.body[10].ord
    build       = resp.body[11].ord
    mac1        = resp.body[12].unpack("H*")[0]
    mac2        = resp.body[13].unpack("H*")[0]
    mac3        = resp.body[14].unpack("H*")[0]
    mac4        = resp.body[15].unpack("H*")[0]
    mac5        = resp.body[16].unpack("H*")[0]
    mac6        = resp.body[17].unpack("H*")[0]
    ssid        = resp.body[19..-1]
    # Some of the fields don't seem useful, so not including here
    retval = {
      :wifi_pass   => wifi_pass,
      :success     => wifi_pass,
      :wifi_ver    => [major, minor, build, rev].join("."),
      :mac         => [mac1, mac2, mac3, mac4, mac5, mac6].join(":"),
      :ssid        => ssid,
    }
    return retval
  end

  def decode_ap_key(resp, param, expected=nil)
    wifi_pass   = resp.body[0].ord == wifi_success
    ap_key      = resp.body[2..-1]
    retval = {
      :wifi_pass  => wifi_pass,
      :success    => wifi_pass,
      :ap_key     => ap_key,
    }
    return retval
  end

  # Return the key associated with a value for a certain command
  # Forcing upcase comparison
  def val2key(hash, value)
    val = value.upcase if value.is_a? String
    val = wifi_itohs(value) if value.is_a? Fixnum
    hash.each { |k, v|
      next if [:set, :get, :ret].include?(k)
      if v.is_a? String
        return k if v.upcase == val
      else
        return k if v == val
      end
    }
    return nil
  end

  def decode_api2_resp(resp, expected_value, status_value)
    if not http_resp_ok(resp) or expected_value == nil or status_value == nil
      flag_success = false
    else
      flag_success = expected_value.to_s.upcase == status_value.to_s.upcase
    end

    retval = {
      :success => flag_success,
      :detected => status_value.to_s.upcase,
      :expected => expected_value.to_s.upcase,
    }
    return retval
  end
end
