
class ConvertToPackets
  def initialize
  end # initialize

  def convert(button_list)
    result = []
    button_list.each do |pair|
      
    end
  end # convert
end # class ConvertToPackets
