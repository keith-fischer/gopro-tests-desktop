#!/usr/bin/env ruby

# gccb_commands_hero3plus.rb

# Module to hold hashes for well-formed GCCB Hero3+ commands
#
# These are well-formed in the following sense
#
#  - Have :set and :get commands
#

module GCCBCommands_Hero3plus
    
  # Plan: 
  #
  #   Use the :get/:set format way below (as Wifi and Serial ifaces do)
  #   BUT reference the pipe_hex_cmds symbols to get the actual command strings
  #   EVEN BETTER: have the :get/:set reference a method that will then reference the pipe_hex_cmds
  #
  # Reference:
  #
  #  Hero3+-GCCB-JS060415.docx
  #  "GCCB Request / Responses - Hero3+ Silver" -> https://wiki.gopro.com/pages/viewpage.action?pageId=44500292
  #  "GCCB Request / Responses - Hero3+ Black"  -> https://wiki.gopro.com/pages/viewpage.action?pageId=43782897
  #  "How to connect GCCB with Camera"          -> https://wiki.gopro.com/display/BD/How+to+connect+GCCB+with+Camera
  #  "Camera Kit For HeroBus" -> https://wiki.gopro.com/pages/viewpage.action?spaceKey=BD&title=Camera+Kit+for+HeroBus
  #
  # Note: the GCCB Hero3+ api is not in any way similar to the Hero4 GCCB api
  #

  # Hero3+
  # Resolutions:
  #  0x00: 848x480 (480p)
  #  0x01: 1280x720 (720p)
  #  0x02: 1280x960 (960p)
  #  0x03: 1920x1080 (1080p)
  #  0x04: 1920x1440 (1440p)
  #  0x05: 2704x1524 (2.7k-16:9)
  #  0x06: 3840x2160 (4k-16:9)
  #  0x07: 2704x1440 (2.7k-17:9)
  #  0x08: 4096x2160 (4k-17:9)
  #  0x09: 1920x1080 (1080p-SuperView)
  #  0x0A: 1280x720 (720p-SuperView)

  # FPS:
  #  0x00: 12 FPS
  #  0x01: 15 FPS
  #  0x02: 24 FPS
  #  0x03: 25 FPS
  #  0x04: 30 FPS
  #  0x05: 48 FPS
  #  0x06: 50 FPS
  #  0x07: 60 FPS
  #  0x08: 100 FPS
  #  0x09: 120 FPS
  #  0x0A: 240 FPS
  #  0x0B: 12.5 FPS

  # FOV
  #  0x00: Wide
  #  0x01: Medium
  #  0x02: Narrow


  # RES/FPS valid combinations: (page 23 in GCCB-Hero3plus.docx)
  #  4k/4k-17:9 15,      12.5, 12
  #  1.7k/2.7k 17:9      30,25,24
  #  1440                48,30,25,24
  #  1080                60,50,48,30,25,24
  #  1080 SUPER          60,50,48,30,25,24
  #  960                 100,60,50
  #  720                 120,100,60,50
  #  720  SUPER          100,60,50


  ##################################################################
  # VIDEO MODE
  ##################################################################

  # Reference:
  #  https://wiki.gopro.com/pages/viewpage.action?pageId=11698363
  def supported_fps_hero3plus
    {
      "NTSC" => ["12","15",  "24","30","48","60","100","120","240"],
      "PAL"  => ["12","12.5","24","25","48","50","100","240"],
    }
  end
  # Hero4, Hero3+ Supported Modes
  def supported_video_settings_hero3plus
    {
      "4K-17:9" => [  
        ["NTSC","PAL","12","WIDE","BLACK_PLUS"],    # NEW
      ],
      "2.7K-16:9" => [                              # NEW
        ["NTSC","30","WIDE","MEDIUM","BLACK_PLUS"],
        ["PAL","25","WIDE","MEDIUM","BLACK_PLUS"],
      ],
      "2.7K-17:9" => [                              # NEW
        ["NTSC","PAL","24","WIDE","MEDIUM","BLACK_PLUS"],
      ],
      #"4K_SUPER" => [
      "4K-16:9" => [
        ["NTSC","PAL","24","WIDE","PIPE"],
      ],
      "2.7K"    => [
        #["NTSC","60","WIDE","MEDIUM","PIPE"],       # missing from GCCB spec
        #["PAL","50","WIDE","MEDIUM","PIPE"],        # missing from GCCB spec
        #["NTSC","PAL","48","WIDE","MEDIUM","PIPE","BACKDOOR"],      # missing from GCCB spec
        ["NTSC","30","WIDE","MEDIUM","PIPE","BACKDOOR"],
        ["PAL","25","WIDE","MEDIUM","PIPE","BACKDOOR"],
        ["NTSC","PAL","24","WIDE","MEDIUM","PIPE","BACKDOOR"],
      ],
      #"2.7K_SUPER" => [     # ENTIRE format is missing from GCCB spec
        #["NTSC","30","WIDE","PIPE"],
        #["PAL","25","WIDE","PIPE"],
      #],
      #"2.7K_FS" => [     # ENTIRE format is missing from GCCB spec
        #["NTSC","30","WIDE","PIPE"],
        #["PAL","25","WIDE","PIPE"],
      #],
      "1440"    => [
        #["NTSC","PAL","80","WIDE","PIPE""],             # missing from GCCB spec
        #["NTSC","60","WIDE","PIPE"],                # missing from GCCB spec
        #["PAL","50","WIDE","PIPE"],             # missing from GCCB spec
        ["NTSC","PAL","48","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","30","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["PAL","25","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","PAL","24","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","15","WIDE","BLACK_PLUS"],   # NEW 9.22
        ["PAL","12.5","WIDE","BLACK_PLUS"],  # NEW 9.22
      ],
      "1080"    => [
        #["NTSC","PAL","120","WIDE","NARROW","PIPE"],                # missing from GCCB spec
        #["NTSC","PAL","90","WIDE","NARROW","PIPE"],             # missing from GCCB spec
        ["NTSC","60","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["PAL","50","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["NTSC","PAL","48","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","30","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["PAL","25","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["NTSC","PAL","24","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","BLACK_PLUS"],
      ],
      "1080_SUPER"    => [
        #["NTSC","PAL","80","WIDE","PIPE"],  # GCCB spec is WRONG, missing for PIPE
        ["NTSC","60","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["PAL","50","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","PAL","48","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","30","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["PAL","25","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","PAL","24","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
      ],
      "960"    => [
        #["NTSC","PAL","120","WIDE","NARROW","PIPE"],  # GCCB spec is WRONG, missing for PIPE
        ["NTSC","PAL","100","WIDE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","60","WIDE","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["PAL","50","WIDE","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["NTSC","PAL","48","WIDE","BLACK_PLUS"],
        ["NTSC","30","WIDE","SILVER_PLUS"],
        ["PAL","25","WIDE","SILVER_PLUS"],
      ],
      "720"    => [
        #["NTSC","PAL","240","NARROW","PIPE"],  # GCCB spec is WRONG, missing for PIPE
        #["NTSC","PAL","120","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],  # TODO: TEST if this still works on Hero4

        # TODO: Test the BLACK_PLUS on the next two settings
        ["NTSC","120","WIDE","MEDIUM","NARROW","SILVER_PLUS","BLACK_PLUS"],   # NEW *But* should not be MEDIUM for BLACK_PLUS(?)
        ["PAL","100","WIDE","MEDIUM","NARROW","SILVER_PLUS","BLACK_PLUS"],    # NEW


        ["NTSC","60","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],
        ["PAL","50","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS","BLACK_PLUS"],

        ["NTSC","30","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS"],
        ["PAL","25","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR","SILVER_PLUS"],
      ],
      "720_SUPER"    => [
        ["NTSC","PAL","100","WIDE","BLACK_PLUS"], 
        ["NTSC","60","WIDE","BLACK_PLUS"],
        [ "PAL","50","WIDE","BLACK_PLUS"],
        ["NTSC","PAL","48","WIDE","BLACK_PLUS"],
      ],
      "480"    => [   # "WVGA" 
        ["NTSC","PAL","240","WIDE","PIPE","BACKDOOR","BLACK_PLUS"],
        ["NTSC","120","WIDE","SILVER_PLUS"],  # NEW
        ["PAL","100","WIDE","SILVER_PLUS"],   # NEW
        ["NTSC","60","WIDE","SILVER_PLUS"],   # NEW
        ["PAL","50","WIDE","SILVER_PLUS"],    # NEW
      ],
    }
  end

  def vid_res_cmds
    {
      :name       => "video_resolution_cmds",
      :set        => "VV %s",                     # resolution value in hex
      :get        => "vv",
      :settings   => {
        "480"         => 0x00, # 848x480
        "720"         => 0x01, # 1280x720
        "960"         => 0x02, # 1280x960
        "1080"        => 0x03, # 1920x1080
        "1440"        => 0x04, # 1920x1440
        "2.7K-16:9"   => 0x05, # 2704x1524 # also known as 2.7K_CIN(?)
        "4K-16:9"     => 0x06, # 3840-2160 # also known as 4K_CIN(?)

        "2.7K-17:9"   => 0x07, # 2704x1440 # also known as (?)
        "4K-17:9"     => 0x08, # 4096-2160 # also known as (?)
        "1080_SUPER"  => 0x09, # 1920x1080
        "720_SUPER"   => 'A', # 1280x720 use ASCII 'A' instead of int hex value 0x0A because of :set format of "VV %s"
      }
    }
  end
  def vid_fps_cmds
    {
      :name       => "video_fps_cmds",
      :set        => "FS %s",                   # frame-rate in hex
      :get        => "fs",
      :settings   => {
        "12"     => 0x00,
        "15"     => 0x01,
        "24"     => 0x02,
        "25"     => 0x03,
        "30"     => 0x04,
        "48"     => 0x05,
        "50"     => 0x06,
        "60"     => 0x07,
        "100"    => 0x08,
        "120"    => 0x09,
        "240"    => 0x0A,  # TODO: TESTME! will this work? Or do I need 'A'
        "12.5"   => 0x0B,  # TODO: TESTME! will this work? Or do I need 'B'
      }
    }
  end
  def vid_fov_cmds
    {
      :name       => "video_fov_cmds",
      :set        => "FV %s",                 # FOV setting in hex
      :get        => "fv",
      :settings   => {
        "WIDE"    => 0x00, # W
        "MEDIUM"  => 0x01, # M
        "NARROW"  => 0x02, # N
      }
    }
  end

  def start_video_trigger_cmds
    {
      :name       => "start video trigger_shutter_cmds",
      :set        => "SH 1", 
    }
  end

  def stop_video_trigger_cmds
    {
      :name       => "stop video trigger_shutter_cmds",
      :set        => "SH 0",
    }
  end

  def start_photo_trigger_cmds 
    {
      :name       => "start photo trigger_shutter_cmds",
      :set        => "SH 1",
    }
  end

  def stop_photo_trigger_cmds 
    {
      :name       => "stop photo trigger_shutter_cmds",
      :set        => "SH 0",
    }
  end

  def start_multi_trigger_cmds 
    {
      :name       => "start multi trigger_shutter_cmds",
      :set        => "SH 1",
    }
  end

  def stop_multi_trigger_cmds   # Note: there is no command to stop burst mode, because capturing stops automatically
    {
      :name       => "stop multi trigger_shutter_cmds",
      :set        => "SH 0",
    }
  end

  def trigger_shutter_cmds
    {
      :name       => "trigger shutter commands",
      :set        => "SH %s",     #
      :get        => "sh",     #
      :settings   => {
        "STOP"    => 0,
        "START"   => 1, 
      }
    }
  end


  def mode_cmds
    {
      :name       => "camera mode cmds",

      :set        => "CM %s",         # <setting name>
      :get        => "cm",
      :settings   => {                               
        "VIDEO"             => 0x00,
        "PHOTO"             => 0x01,
        "BURST"        => 0x02,
        "TIMELAPSE"         => 0x03,
      },
    }
  end

  def gccb_error_codes 
    {
      "0" => "OK",
      "FC" => "Invalid command",
    }
  end
  
  def video_looping_cmds
    {
      :name       => "video_looping_cmds",
      :set        => "LO %s",
      :get        => "lo",
      :settings   => {
        "OFF"           => 0x00,
        "5"             => 0x01,
        "20"            => 0x02,
        "60"            => 0x03,
        "120"           => 0x04,
        "MAX"           => 0x05,
      },
  }
  end

  def video_lowlight_cmds    # BLACK_PLUS only (does not work for SILVER_PLUS)
    {
      :name       => "video_lowlight_cmds",
      :set        => "LW %s",
      :get        => "lw",
      :settings   => {
        "OFF"            => 0x00,
        "ON"             => 0x01,
      },
    }
  end
  
  def exposure_mode_cmds
    {
      :name       => "exposure_mode_cmds",
      :set        => "EX %s",
      :get        => "ex",
      :settings   => {
        "CENTER-WEIGHTED"  => 0x00,  # "Center-Weighted"
        "SPOT-METERING"    => 0x01,  # "Spot-Metering"
      },
    }
  end
    
  def video_protune_cmds    # NOT supported in SILVER_PLUS
    {
      :name       => "video_protune_cmds",
      :set        => "PT %s",
      :get        => "pt",
      :settings   => {                               # invert this to get ":gettings"
        "OFF"            => 0x00,
        "ON"             => 0x01,
        "RESET"          => 0x02,
      },
    }
  end
  
  # For compatibility
  def protune_cmds
    video_protune
  end
  
  def white_balance_cmds
    {
      :name   => "white_balance_cmds",
      :set    => "WB %s",
      :get    => "wb",
      :settings => {
        "AUTO"  => 0x00,
        "3000K" => 0x01,
        "5500K" => 0x02,
        "6500K" => 0x03,
        "RAW"   => 0x04,
      }
    }
  end

  def color_cmds  # NOT working for at least SILVER_PLUS
    {
      :name   => "color_cmds",
      :set    => "CO %s",
      :get    => "co",
      :settings => {
        "STANDARD"  => 0x00,
        "NEUTRAL"   => 0x01,
      }
    }
  end
  
  def iso_cmds # NOT working for at least SILVER_PLUS
    {
      :name   => "iso_cmds",
      :set    => "GA %s",
      :get    => "ga",
      :settings => {
        "6400"    => 0x00,
        "1600"    => 0x01,
        "400"     => 0x02,
      }
    }
  end
  
  def sharpness_cmds # NOT working for at least SILVER_PLUS
    {
      :name   => "sharpness_cmds",
      :set    => "SP %s",
      :get    => "sp",
      :settings => {
      "HIGH"  => 0x00,
      "MED"   => 0x01,
      "LOW"   => 0x02,
      }
    }
  end
  
  # TODO: compare this to Hawaii spec
  def video_protune_exposure_cmds
    {
      :name       => "video_protune_exposure_cmds",
      :set        => "EV %s",
      :get        => "ev",
      :settings   => {
        "+5"            => '14',
        "+4.5"          => '13',
        "+4"            => '12',
        "+3.5"          => '11',
        "+3"            => '10',
        "+2.5"          => 'F',
        "+2"            => 'E',
        "+1.5"          => 'D',
        "+1"            => 'C',
        "+0.5"          => 'B',
        "+0"            => 'A',
        "-0.5"          => 0x09,
        "-1"            => 0x08,
        "-1.5"          => 0x07,
        "-2"            => 0x06,
        "-2.5"            => 0x05,
        "-3"            => 0x04,
        "-3.5"            => 0x03,
        "-4"            => 0x02,
        "-4.5"            => 0x01,
        "-5"            => 0x00,
      },
    }
  end
  
  ##################################################################
  # PHOTO MODE
  ##################################################################
  
  def photo_res_cmds
    {
      :name       => "photo resolution commands",
      :set        => "PR %s",
      :get        => "pr",
      :settings   => {
        "5MED"    => 0x03,
        "7WIDE"   => 0x04,
        "12WIDE"  => 0x05, # BLACK_PLUS only
        "7MED"    => 0x06, # BLACK_PLUS only
        "10WIDE"  => 0x08, # SILVER_PLUS only
      }
    }
  end
  
  def photo_sps_cmds
    {
      :name       => "photo sps (continous rate) commands",
      :set        => "CS %s", # <rate>
      :get        => "cs",
      :settings   => {
        "1"  => 0x00,
        "3"  => 0x03,
        "5"  => 0x05,
        "10" => "A", # NOTE: a value of 0x0A does not work. Must be an ascii 'A'
      },
    }
  end
  
  def video_piv_cmds
    {
      :name       => "photo_in_video_cmds",
      :set        => "PN %s",
      :get        => "pn",
      :settings   => {
        "OFF" => 0x00,
        "5"   => 0x01,    # every 5 seconds
        "10"  => 0x02,    # 10s
        "30"  => 0x03,    # 30s
        "60"  => 0x04,    # 60s
      },
    }
  end
  
  
  ##################################################################
  # MULTI-SHOT
  ##################################################################
  
  def multi_burst_cmds
    {
      :name       => "multi_burst_cmds",
      :set        => "BU %s",
      :get        => "bu",
      :settings   => {
        "3_1"   => 0x00,
        "5_1"   => 0x01,
        "10_1"  => 0x02,
        "10_2"  => 0x03,
        "30_1"  => 0x04,
        "30_2"  => 0x05,
        "30_3"  => 0x06,
      },
    }
  end
  
  def multi_timelapse_interval_cmds
    {
      :name       => "multi_timelapse_interval_cmds",
      :set        => "TI %s",
      :get        => "ti",
      :settings   => {
        "0.5"          => 0x00,
        "1"            => 0x01,
        "2"            => 0x02,
        "5"            => 0x05,
        "10"           => "A",
        "30"           => "1E",
        "60"           => "3C",
      },
    }
  end
  

  ##################################################################
  # SETUP/SETTINGS
  ##################################################################

  def entire_camera_status_cmds
    {
      :get         => "se",
    }
  end

  def orientation_cmds
    {
      :set    => "UP %s",
      :get    => "up",
      :settings => {
      "UP"    => 0x00,
      "DOWN"  => 0x01,
      }
    }
  end
  
  def default_mode_cmds
    {
      :name     => "default mode cmds",
      :set      => "DM %s",
      :get      => "dm",
      :settings => {
        "VIDEO"       => 0x00,
        "PHOTO"       => 0x01,
        "BURST"       => 0x02,
        "TIMELAPSE"   => 0x03,
        #"BROADCAST"   => ?
        #"PLAYBACK"    => ?
        #"SETTINGS"    => ?
      }
    }
  end
  
  # One-Button Mode "Quick Capture Mode"
  def obm_cmds
    {
      :name     => "One_ButtonMode_Cmds",
      :set      => "OB %s",
      :get      => "ob",
      :settings => {
        "OFF"  => 0x00,     # OBM disabled
        "ON"   => 0x01,     # OBM enabled
      },
    }
  end

  def led_cmds
    {
      :set      => "LB %s",
      :get      => "lb",
      :settings => {
        "OFF"   => 0x00,  # set & get values  # none (off)
        "2"     => 0x01,  # set & get values  # front, back
        "4"     => 0x02,  # set & get values  # top,botton,front,back
      }
    }
  end
  
  def beep_sound_cmds
    {
    :set      => "BS %s",
    :get      => "bs",
    :settings => {                               # invert this to get ":gettings"
      "0"       => 0x00,  # set & get values
      "70"      => 0x01,  # set & get values
      "100"     => 0x02,  # set & get values
    }
  }
  end
  
  def vid_mode_cmds  # aka video format
    {
      :name     => "video_mode_cmds",
      :set      => "VM %d",
      :get      => "vm",
      :settings => {
        "NTSC"  => 0x00,
        "PAL"   => 0x01,
      },
    }
  end
  
  def power_on_cmds
    {
      :name     => "power_on_cmds",
      :set      => "!", 
    }
  end

  def power_off_cmds
    {
      :name     => "power_off_cmds",
      :set      => "PW %s",
      :settings => {
        "OFF"  => 0x00,
      },

      # NOTE: there is not GET response for this command. BUT the command response does COME before power off:
      # send_serial: "PW 0"
      # ................... RESPONSE PKT ...................
      # >(C1)+(03)+(50)+(57)+(00)-<
      # >(C0)+(02)+(00)+(00)+<

    }
  end

  def locate_camera_cmds
    {
      :name     => "locate_camera_cmds",
      :set      => "LL %s",
      :get      => "ll",
      :settings => {
        "OFF"   => 0x00,
        "ON"    => 0x01,
      },
    }
  end
  def camera_time_cmds
    {
      :name     => "camera_time_cmds",
      :set      => "TM %s",
      :get      => "tm",
      :month    => {
        "1" => "Jan",
        "2" => "Feb",
        "3" => "Mar",
        "4" => "Apr",
        "5" => "May",
        "6" => "Jun",
        "7" => "Jul",
        "8" => "Aug",
        "9" => "Sep",
        "10" => "Oct",
        "11" => "Nov",
        "12" => "Dec",
      }
    }
  end
  
  def auto_off_cmds
    {
      :name     => "auto_off_cmds",
      :set      => "AO %s",
      :get      => "ao",
      :settings => {                               # invert this to get ":gettings"
        "NEVER" => 0x00,  
        "1"     => 0x01,  # 1 minute delay
        "2"     => 0x02,  # 2 minute delay
        "5"     => 0x03,  # 5 minute delay
      },
    }
  end
  
  def version_cmds
    {
      :name       => "version_cmds",
      :get        => "cv",
      :get_resp   => "C0 %s %s %s", # length, error, <PERCENT>
    }
  end

  def battery_level_cmds
    {
      :name       => "battery_level_cmds",
      # NOTE: there are no set commands for this
      :get        => "bl",
      :get_resp   => "C0 %s %s %s", # length, error, <PERCENT>
      # PERCENT : 0x00 - 0x64  (represents 0 to 100)
    }
  end

  # BLACK_PLUS ONLY! (does not work with SILVER_PLUS)
  def audio_input_cmds
    {
      :name      => "audio_input_source_cmds",
      :set       => "AI %s",
      :get       => "ai",
      :settings  => {
        "INTERNAL-MIC" => 0x00,
        "HERO_BUS" => 0x01,
      }
    }
  end

  def video_output_cmds
    {
      :name      => "CVBS Video Output Port Commands",
      :set       => "VO %s",
      :get       => "vo",      # does NOT work! - ULU-140
      :settings  => {
        "USB_AV"   => 0x00,
        "HERO_BUS" => 0x01,
      }
    }
  end

  def busy_status_cmds; { :get => "t api system busy_status" }; end

  ##################################################################
  # PLAYBACK
  ##################################################################
  def playback_osd_cmds  # OnScreenDisplay(OSD) BACKDOOR ONLY COMMAND, unless PIPE has a bacpac installed
    {
      :name       => "playback_osd_cmds",
      :set        => "DS %s",
      :get        => "ds",
      :settings   => {
        "OFF"            => 0x00, # OSD disabled
        "ON"             => 0x01, # OSD enabled
      },
    }
  end

  ##################################################################
  # STORAGE
  ##################################################################
  
  def format_sdcard_cmds
    {
      :name     => "format_sdcard_cmds",
      :set      => "FO",
    }
  end

  def delete_last_cmds
    {
      :name     => "delete_last_cmds",
      :set      => "DL",
    }
  end

  def delete_all_cmds
    {
      :name     => "delete_all_cmds",
      :set      => "DA",
    }
  end


  ##################################################################
  # WIRELESS
  ##################################################################
  
  ##################################################################
  # FWUPDATE
  ##################################################################
  
  ###########################################################################
  # VID_FEATURE_AVAIL
  ###########################################################################
  
  ###########################################################################
  # BROADCAST MODE
  ###########################################################################
  
  #############################################################################
  #  Non-API utility commands
  #############################################################################

end # module GCCBCommands_Hero3plus

if __FILE__ == $0

   puts "gccb_commands_hero3plus.rb:  TESTING 1 2 3"

end
