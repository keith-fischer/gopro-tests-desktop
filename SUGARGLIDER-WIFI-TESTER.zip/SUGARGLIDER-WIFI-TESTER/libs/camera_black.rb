require_relative 'camera'

module Black
  def init
    @name = "BLACK"
    log_verb("Instantiating #{name} camera")
    @remote_api = 1  #remote smarty api version 1 (ie http://10.5.5.9:80/camera/TI?t=goprohero1&p=%01)
  
    @audio_channels         = 2
    @audio_codec            = "aac"
    @audio_sample_rate      = 48000
    @audio_bitrate          = 64    # in kbps per channel.
    @avc_profile_level      = "HIGH"
    # Support for changing preview bitrate via BV command
    @chg_prev_br_support    = false
    # Support for changing preview resolution via BV command
    @chg_prev_res_support   = false
    @colorspace             = "yuvj420p"
    @video_protune_bitrate  = 45 # Unsupported
    @video_codec            = "h264"
    @video_piv_intervals    = ["5", "10", "30", "60"]
    @video_lrv_bitrate      = 0.7
    @total_lrv_bitrate      = 0.8  # Mbps, (includes video + audio + data)

    #video
    @video_protune_support  = true
    @video_looping_support  = true

    #share video/photo/multi_photo protune value. Split where necessary
    @protune_white_balance_values = ["AUTO", "3000K", "5500K", "6500K", "RAW"]
    @protune_color_values         = [nil]
    @protune_sharpness_values     = [nil]
    @protune_exposure_values      = [nil]
    @photo_protune_iso_values     = [nil]
    @video_protune_iso_values     = [nil]

    #video
    @video_piv_support          = true
    @video_looping_support      = true
    @video_low_light_support    = true
    @video_protune_support      = true
    #photo
    @photo_continuous_support   = true

    @video_protune_vars = {
      :video_pt_color   => false,
      :video_pt_iso     => false,
      :video_pt_sharp   => false,
      :video_pt_ev      => false,
      :video_pt_wb      => true
    }

    @capabilities = { #cc
      :has_camera_roll      => true,
      :has_ota              => false,  #over the air firmware update
      :has_ltp              => true,
      :has_3D               => true,
      :has_ccl              => false,   #camera control library
    }

    @defaults = {
      :locate_ll            => "OFF",
      :setup_video_format   => "NTSC",
      :video_resolution     => "1440",
      :video_protune        => "OFF",
      :video_fps            => "48",
      :video_fov            => "W",
      :video_low_light      => "OFF",
      :video_looping        => "OFF",
      #      :video_piv            => "OFF",  reset piv different way because setting piv to unsupported res causes camera to restart
      :photo_resolution     => "12WIDE",
      :multi_shot_burst     => "30_1",
      :multi_shot_timelapse => "0.5",
      :setup_default_mode   => "VIDEO",
      :setup_orientation    => "OFF",
      :video_spot_metering  => "OFF",
      :photo_continuous     => "1",
      :setup_led            => "4",
      :setup_beep           => "100",
      :setup_osd            => "ON",
      :mode_cm              => "VIDEO",
    }

    @setup = {
      :mode_cm                => "VIDEO",
      :setup_orientation      => "UP",
      :setup_led              => "4",
      :setup_beep             => "100",
      :setup_osd              => "ON",
    }

    # Commands that don't have prerequisites
    # Wifi commands to test
    @cmds = [
      :setup_beep,
      :setup_default_mode,
      :setup_led,
      :video_spot_metering,
      :setup_orientation,
      :setup_video_format,
      :locate_ll,
      :mode_cm,
    ]

    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    @video_capture_modes = {
      "4K_CIN"  =>  {
      :width  => 4096,
      :height => 2160,
      :aspect_ratio => "256:135",
      :protune => true,
      :fps    => {
      "12"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 35,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 11.99,
      :piv      => false,
      :looping  => false,
      },
      } # end fps
      }, # end 4K_CIN
      "4K"  =>  {
      :width  => 3840,
      :height => 2160,
      :aspect_ratio => "16:9",
      :protune => true,
      :fps    => {
      "12.5"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 35,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 12.5,
      :piv      => false,
      :looping  => false,
      },
      "15"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 35,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 14.99,
      :piv      => false,
      :looping  => false,
      },
      } # end fps
      }, # end 4K
      "2.7K_CIN"  =>  {
      :width  => 2704,
      :height => 1440,
      :aspect_ratio => "169:90",
      :protune => true,
      :fps    => {
      "24"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 35,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 23.98,
      :piv      => false,
      :looping  => false,
      },
      } # end fps
      }, # end 2.7K_CIN
      "2.7K"  =>  {
      :width  => 2704,
      :height => 1524,
      :aspect_ratio => "676:381",
      :protune => true,
      :fps    => {
      "25"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 35,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 25,
      :piv      => false,
      :looping  => false,
      },
      "30"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 35,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 29.97,
      :piv      => false,
      :looping  => false,
      },
      } # end fps
      }, # end 2.7K
      "1440"  =>  {
      :width  => 1920,
      :height => 1440,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :fps    => {
      "24"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 23.98,
      :frame_rate => 23.98,
      :piv      => true,
      :looping  => true,
      :piv      => false,
      },
      "25"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 25,
      :looping  => true,
      :piv      => false,
      },
      "30"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 29.97,
      :looping  => true,
      :piv      => false,
      },
      "48"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 47.95,
      :piv      => false,
      :looping  => false,
      }
      } # end fps
      }, # end 1440
      "1080"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 23.98,
      :frame_rate => 23.98,
      :piv      => true,
      :looping  => true,
      },
      "25"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 25,
      :piv      => true,
      :looping  => true,
      },
      "30"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 29.97,
      :piv      => true,
      :looping  => true,
      },
      "48"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 23.98,
      :frame_rate => 47.95,
      :looping  => true,
      :piv      => false,
      },
      "50"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 50,
      :looping  => true,
      :piv      => false,
      },
      "60" => {
      :fov      => ["W", "M", "N"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 59.94,
      :looping  => true,
      :piv      => false,
      }
      } # end fps
      }, # end 1080
      "960"  =>  {
      :width  => 1280,
      :height => 960,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :fps    => {
      "48"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 23.98,
      :frame_rate => 47.95,
      :protune  => false,
      :looping  => true,
      :piv      => false,
      },
      "100"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 100,
      :piv      => false,
      :looping  => false,
      },
      } # end fps
      }, # end 960
      "720"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "50"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 50,
      :piv      => true,
      :looping  => true,
      },
      "60"  => {
      :fov      => ["W", "M", "N"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 29.97,
      :timecode => false,
      :frame_rate => 59.94,
      :piv      => true,
      :looping  => true,
      },
      "100" => {
      :fov      => ["W", "N"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 30,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 100,
      :piv      => false,
      :looping  => false,
      },
      "120" => {
      :fov      => ["W", "N"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 30,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 119.88,
      :piv      => false,
      :looping  => false,
      }
      } # end fps
      }, # end 720
      "WVGA"  =>  {
      :width  => 848,
      :height => 480,
      :aspect_ratio => "53:30",
      :protune => false,
      :fps    => {
      "240" => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 240,
      :piv      => false,
      :looping  => false,
      }
      } # end fps
      } # end WVGA
    } # end @video_capture_modes

    # Photo Modes
    @photo_modes = {
      "5MED" => {
      :width        => 2560,
      :height       => 1920,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :piv => {
      "5"   => { :min_quality  => 98.0 },
      "10"   => { :min_quality  => 98.0 },
      "30"   => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end piv
      :sps => {
      #      1   => { :min_quality  => 98.0 },
      "3"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 5MED
      "7MED" => {
      :width        => 3000,
      :height       => 2250,
      :min_size     => 2100, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :piv => {
      "5"   => { :min_quality  => 98.0 },
      "10"   => { :min_quality  => 98.0 },
      "30"   => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end piv
      :sps => {
      #      1   => { :min_quality  => 98.0 },
      "3"   => { :min_quality  => 95.0 },
      "5"   => { :min_quality  => 95.0 },
      "10"  => { :min_quality  => 95.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 7MED
      "7WIDE" => {
      :width        => 3000,
      :height       => 2250,
      :min_size     => 2100, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :piv => {
      "5"   => { :min_quality  => 98.0 },
      "10"   => { :min_quality  => 98.0 },
      "30"   => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end piv
      :sps => {
      #      1   => { :min_quality  => 98.0 },
      "3"   => { :min_quality  => 95.0 },
      "5"   => { :min_quality  => 95.0 },
      "10"  => { :min_quality  => 95.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 7WIDE
      "12WIDE" => {
      :width        => 4000,
      :height       => 3000,
      :min_size     => 3600, # KB
      :min_psnr     => 35,
      :min_quality  => 98.0,
      :piv => {
      "5"   => { :min_quality  => 98.0 },
      "10"   => { :min_quality  => 98.0 },
      "30"   => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end piv
      :sps => {
      #      1   => { :min_quality  => 98.0 },
      "3"   => { :min_quality  => 94.0 },
      "5"   => { :min_quality  => 94.0 },
      "10"  => { :min_quality  => 94.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse mode
      }, # end 12WIDE
    } # end PHOTO mode

    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 15,
      "120"   => 15,
      "MAX" => 15,
    }

    @screens = {
      :wireless_settings => [ \
      "0000000000000000000f000000000000000f1fffffffffffff8f3fffffffffffffcf3" + \
      "fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffff" + \
      "ffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3ffffffffff" + \
      "fffcf3f1c6eeeec618fcf3eebaeeedbaf77cf"]
    }

  end # end initialize

end #module
