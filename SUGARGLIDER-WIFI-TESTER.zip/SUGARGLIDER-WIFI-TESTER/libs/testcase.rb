require "optparse"

require_relative "log_utils"
require_relative "test_utils"

class TestCase
  include LogUtils

  attr_accessor :hard_fail
  def initialize
    @test_file = nil
    @tc_name = "UNK_TEST_CASE"
    @assertion_failed = false
    @hard_fail = false
    @reset_on_failure = false
    @autoconnect = false
  end

  def display_git_info()
    info = `git log | head -n 1`
    log_info("Git: #{info}")
  end

  def set_tc_name(s)
    @tc_name = s
    @camera.tc_name = s if defined? @camera
    log_info("Starting test #{@tc_name}")
  end

  # Assertion helpers
  # Return failure string if assertion fails, nil if it passes
  # Will raise if soft=false
  def assert(val, msg="Value is false", soft=true)
    return nil if val == true
    log_info("Assertion failure (%s is false). %s" %[val, msg])
    @assertion_failed = true
    raise(AssertionError, msg) if soft == false
    return msg
  end

  def assert_equal(val1, val2, msg="Values are not equal", soft=true)
    return nil if val1 == val2
    log_info("assert_equal failure (%s==%s is false). %s" %[val1, val2, msg])
    @assertion_failed = true
    raise(AssertionError, msg) if soft == false
    return msg
  end

  def assert_delta(val1, val2, delta, msg="Difference > delta", soft=true)
    return nil if (val1.to_f - val2.to_f).abs <= delta
    log_info("assert_delta failure (abs(%s-%s) >= %s). %s" %[val1, val2, delta, msg])
    @assertion_failed = true
    raise(AssertionError, msg) if soft == false
    return msg
  end

  # The fail method overrides a built-in that raises RuntimeError.
  def fail(msg="", reset=false)
    log_fail(msg)
    @assertion_failed = true
    cam_comm = false
    cam_alive = false
    # For following, do only if camera/api supports ip
    if defined? @camera.ip
      cam_comm = @host.wait_for_wifi_camera(@camera.ip, 10)
      log_verb("Camera Wi-Fi still alive? #{cam_comm.inspect}")
      cam_alive = @camera.is_alive?
    end
    if (cam_comm == false) or (cam_alive == false )or \
    (@reset_on_failure == true and reset == true)
      if defined?(tu_reset_camera) == "method"
        tu_reset_camera()
      else
        log_warn("Would reset but no 'tu_reset_camera' function defined")
      end
    end
  end

  def pass(msg=""); log_pass(msg); end

  # Tests an array to see if it contains failure strings
  def has_failure?(fail_arr, reset=false)
    fail_arr.flatten!(1)
    fail_arr.compact!
    log_debug("has_failure?() array=%s, empty?=%s" %[fail_arr, fail_arr.empty?])
    return false if fail_arr.empty?
    fail(fail_arr.join("\n"), reset)
    return true
  end

  # Provide common options for test scripts
  # argv - The arguments to parse (99.9% of the time should be ARGV)
  # opts_arr - Array of options to support.
  #            Set to 'nil' to automatically support ALL the options
  # TODO: extra_opts - Any extra options the test script wants to parse
  # Returns a populated 'options' hash
  def parse_options(argv, opts_arr=[], extra_opts=[], quiet=false)
    # Defaults
    options = {}
    # Camera communication and I/O options
    options[:ip]          = nil
    options[:pc]          = nil
    options[:serialdev]   = nil
    options[:masterdev]   = nil
    options[:slavedev]    = nil
    options[:gccbdev]     = nil
    options[:ble]      = nil
    options[:rc_info]     = nil
    options[:logfile]     = nil

    # Programmable power strip options
    options[:power_ip]    = "192.168.0.100"
    options[:power_usr]   = "admin"
    options[:power_pwd]   = "1234"
    options[:battoutlet]  = nil
    options[:usboutlet]   = nil
    # PUSHY button-pushing interface
    options[:pushy]       = nil
    # SPINNY camera-orientation-setting interface
    options[:spinny]      = nil

    # Video capture mode
    options[:video_timelapse] = nil
    options[:video_looping]   = nil
    options[:video_piv]       = nil
    # Video capture options
    options[:video_resolution]    = nil
    options[:video_fps]           = nil
    options[:video_fov]           = nil
    options[:video_spot_metering] = nil
    options[:video_low_light]     = nil
    # Photo capture mode
    options[:photo_single]        = false
    options[:photo_night]         = false
    options[:photo_continuous]    = nil
    # Photo capture options
    options[:photo_resolution]    = nil
    options[:photo_shutter_ev]    = nil
    options[:photo_spot_metering] = nil
    #Multi-photo capture mode
    options[:multi_photo_burst]       = nil
    options[:multi_photo_nightlapse]  = nil
    options[:multi_photo_timelapse]   = nil
    #Multi-photo capture options
    options[:multi_photo_resolution]  = nil
    options[:multi_photo_shutter_ev]  = nil
    options[:multi_photo_spot_meter]  = nil
    options[:min_pes_pho]             = 2
    options[:min_pes_len]             = 5
    # Other capture options
    options[:video_dft_submode]       = nil
    options[:photo_dft_submode]       = nil
    options[:multi_photo_dft_submode] = nil
    options[:setup_default_mode]      = nil
    options[:def_video_submode]       = nil
    options[:def_photo_submode]       = nil
    options[:def_multi_submode]       = nil
    options[:setup_osd]               = nil
    options[:setup_led]               = nil
    options[:setup_beep]              = nil
    options[:setup_orientation]       = nil
    # Video ProTune options
    options[:video_pt]        = nil
    options[:video_pt_wb]     = nil
    options[:video_pt_color]  = nil
    options[:video_pt_ev]     = nil
    options[:video_pt_sharp]  = nil
    options[:video_pt_iso]    = nil
    # Photo ProTune options
    options[:photo_pt]          = nil
    options[:photo_pt_wb]       = nil
    options[:photo_pt_color]    = nil
    options[:photo_pt_ev]       = nil
    options[:photo_pt_sharp]    = nil
    options[:photo_pt_iso]      = nil
    #Multi-photo Protune options
    options[:multi_photo_pt]          = nil
    options[:multi_photo_pt_wb]       = nil
    options[:multi_photo_pt_color]    = nil
    options[:multi_photo_pt_ev]       = nil
    options[:multi_photo_pt_sharp]    = nil
    options[:multi_photo_pt_iso]      = nil
    options[:multi_photo_shutter_ev]  = nil
    #Voice Control options
    options[:vc_lang]   = "eng-us"
    options[:vc_input]  = "piper"
    options[:vc_command] = nil
    #MTP options
    options[:mtp_ip]    = nil
    options[:mtp_port]  = nil
    options[:mtp_os]    = nil
    # Test-run options
    options[:filter]              = nil
    options[:mode_cm]             = nil
    options[:n_iter]              = nil
    options[:fw_file]             = nil
    options[:base_fw_file]        = nil
    options[:quickcapture]        = nil
    options[:ntsc_only]           = false
    options[:pal_only]            = false
    options[:duration]            = nil
    options[:duration_range_low]  = nil
    options[:duration_range_high] = nil
    options[:tag_interval]        = nil
    options[:save_dir]            = nil
    options[:shuffle]             = false
    options[:seed]                = nil # Set only as an argument to shuffle
    options[:quick]               = nil
    options[:full]                = false
    options[:set_defaults]        = false
    options[:dryrun]              = false
    options[:verb]                = false
    options[:permissive]          = false
    options[:reset_on_failure]    = nil
    options[:range_min]           = 0
    options[:range_max]           = -1
    options[:test_delay]          = nil # Delays to be used at the test level
    options[:io_delay]            = nil # Delays at the camera API level (serial, gccb, etc.)
    options[:pause]               = nil # Can be used to pause IO, pause tests, etc.
    options[:stress]              = nil # run stress tests
    # Used only for the media generating tool.
    options[:skip_initial_format] = false
    options[:format_afterwards]   = false
    options[:skip_upload]         = false
    options[:upload_to]           = nil
    # Used to keep media from tests.
    options[:keep_media]          = nil
    options[:download_media]      = nil

    #Data Analytics options
    options[:analytic_file]           = nil
    options[:generate_analytic_file]  = false
    options[:analytic_version]        = nil
    options[:model]                   = "PIPE"

    # Argus options
    options[:media_dir]               = nil

    # transcoding options
    options[:delete_trv]              = false

    # Allow a way to get ALL the options, if desired
    opts_arr = options.keys() if opts_arr == nil

    op = OptionParser.new do |opts|
      opts.banner = ""
      opts.separator ''
      #
      # Camera communication and I/O options
      #
      opts.on("", "--ip IPADDR", "The IP address of the camera") \
      { |o| options[:ip] = o } if opts_arr.include?(:ip)
      opts.on("", "--pc PAIRINGCODE", "The pairing code of the camera") \
      { |o| options[:pc] = o } if opts_arr.include?(:pc)
      opts.on("", "--serial DEVICE", "The serial device (e.g. /dev/ttyUSB0)") \
      { |o| options[:serialdev] = o } if opts_arr.include?(:serialdev)
      opts.on("", "--master DEVICE", "The serial port of master device (e.g. /dev/ttyUSB0)") \
      { |o| options[:masterdev] = o } if opts_arr.include?(:masterdev)
      opts.on("", "--slave DEVICE", "The serial port of slave device (e.g. /dev/ttyUSB0)") \
      { |o| options[:slavedev] = o } if opts_arr.include?(:slavedev)
      opts.on("", "--ble", "Run as BLE device") \
      { |o| options[:ble] = true } if opts_arr.include?(:ble)
      opts.on("", "--gccb DEVICE", "The gccb device (e.g. /dev/ttyACM0)") \
      { |o| options[:gccbdev] = o } if opts_arr.include?(:gccbdev)
      opts.on("", "--rc_info RC_INFO_FILE", "The file describing the RC setup.") \
      { |o| options[:rc_info] = o } if opts_arr.include?(:rc_info)
      opts.on("", "--logfile FILE", "Sets the log file location (default $HOME)") \
      { |o| options[:logfile] = o } # Always available
      #
      # Programmable power strip options
      #
      opts.on("", "--powerstrip IP", "IP of the programmable power strip") \
      { |o| options[:power_ip] = o } if opts_arr.include?(:power_ip)
      opts.on("", "--power_usr USER", "Username to use with the power strip") \
      { |o| options[:power_usr] = o } if opts_arr.include?(:power_usr)
      opts.on("", "--power_pwd PASS", "Password to use with the power strip") \
      { |o| options[:power_pwd] = o } if opts_arr.include?(:power_pwd)
      opts.on("", "--battoutlet #", "Oulet # connected to the camera battery") \
      { |o| options[:battoutlet] = o } if opts_arr.include?(:battoutlet)
      opts.on("", "--usboutlet #", "Outlet # connected to the camera USB") \
      { |o| options[:usboutlet] = o } if opts_arr.include?(:usboutlet)
      #
      # PUSHY programmable button pusher interface
      #
      opts.on("", "--pushy 'P S W'", "PUSHY outputs for P, S, and W buttons") \
      { |o| options[:pushy] = o } # Just include no matter what
      #
      # SPINNY programmable spinning interface
      #
      opts.on("", "--spinny DEV", "SPINNY serial device DEV (e.g. /dev/ttyUSB2)") \
      { |o| options[:spinny] = o if opts_arr.include?(:spinny)}
      #
      # Video capture mode
      #
      opts.on("", "--timelapse VALUE", "Video timelapse (PES) [0.5|1|2|5|10|30|60]") \
      { |o| options[:video_timelapse] = o} if opts_arr.include?(:video_timelapse)
      opts.on("", "--looping VAL", "Set looping to VAL [OFF|5|20|60|120|MAX]") \
      { |o| options[:video_looping] = o } if opts_arr.include?(:video_looping)
      opts.on("", "--piv VAL", "Set photo-in-video to VAL [5|10|30|60]") \
      { |o| options[:video_piv] = o } if opts_arr.include?(:video_piv)
      #
      # Video capture options
      #
      opts.on("", "--res RESOLUTION", "Only test a specific video resolution") \
      { |o| options[:video_resolution] = o } if opts_arr.include?(:video_resolution)
      opts.on("", "--fps FPS", "Only test a specific video fps") \
      { |o| options[:video_fps] = o } if opts_arr.include?(:video_fps)
      opts.on("", "--fov W|M|N|S", "Only test a specific video fov") \
      { |o| options[:video_fov] = o } if opts_arr.include?(:video_fov)
      opts.on("", "--spot OFF|ON", "Set video spot-metering (default OFF)") \
      { |o| options[:video_spot_metering] = o } if opts_arr.include?(:video_spot_metering)
      opts.on("", "--low_light ON|OFF", "Enable low-light mode on applicable RES/FPS") \
      { |o| options[:video_low_light] = o } if opts_arr.include?(:video_low_light)
      #
      # Photo capture mode and options
      #
      opts.on("", "--continuous VALUE", "Photo continuous shooting mode (if supported) [1|3|5|10]") \
      { |o| options[:photo_continuous] = o } if opts_arr.include?(:photo_continuous)
      opts.on("", "--res RESOLUTION", "Photo single/night/continuous res [5|7|8]MED [5|7|8|10|11|12]WIDE") \
      { |o| options[:photo_resolution] = o } if opts_arr.include?(:photo_resolution)
      opts.on("", "--spot OFF|ON", "Photo spot-metering (default OFF)") \
      { |o| options[:photo_spot_metering] = o } if opts_arr.include?(:photo_spot_metering)
      #
      # Multi-photo capture mode
      #
      opts.on("", "--burst VALUE", "Multi-photo burst mode [3_1|5_1|10_1|30_1|30_2|30_3]") \
      { |o| options[:multi_photo_burst] = o } if opts_arr.include?(:multi_photo_burst)
      opts.on("", "--nightlapse VAL", "Multi-photo night_lapse [CONTINUOUS|4|5|10|15|20|30|60|120|300|1800|3600]") \
      { |o| options[:multi_photo_nightlapse] = o } if opts_arr.include?(:multi_photo_nightlapse)
      opts.on("", "--timelapse VALUE", "Multi-photo time lapse (PES) [0.5|1|2|5|10|30|60]") \
      { |o| options[:multi_photo_timelapse] = o} if opts_arr.include?(:multi_photo_timelapse)
      #
      # Multi-photo capture options
      #
      opts.on("", "--res RESOLUTION", "Multi-photo resolution [5|7|8]MED [5|7|8|10|11|12]WIDE") \
      { |o| options[:multi_photo_resolution] = o } if opts_arr.include?(:multi_photo_resolution)
      opts.on("", "--shutter_ev VALUE", "Multi-photo shutter exposure length [AUTO|2|5|10|15|20|30]") \
      { |o| options[:multi_photo_shutter_ev] = o } if opts_arr.include?(:multi_photo_shutter_ev)
      opts.on("", "--spot OFF|ON", "Multi-photo spot-metering (default OFF)") \
      { |o| options[:multi_photo_spot_meter] = o } if opts_arr.include?(:multi_photo_spot_meter)
      opts.on("", "--min_pes_photos N", "Min # of photos to take in time-lapse tests (default 2)") \
      { |o| options[:min_pes_pho] = o } if opts_arr.include?(:min_pes_pho)
      opts.on("", "--min_pes_length N", "Min # of capture seconds in time-lapse tests (default 5)") \
      { |o| options[:min_pes_len] = o } if opts_arr.include?(:min_pes_len)
      #
      # Voice Control options
      #
      opts.on("", "--vc_lang LANG", "VoiceControl Language (default: eng-us)[chi|eng-aus|eng-uk|eng-us|fre|ger|ita|jpn|kor|spa-eu|spa_na] ") \
      { |o| options[:vc_lang] = o } if opts_arr.include?(:vc_lang)
      opts.on("", "--vc_input INPUT", "VoiceControl Input (default: piper)[piper|sniper] ") \
      { |o| options[:vc_input] = o } if opts_arr.include?(:vc_input)
      opts.on("", "--vc_cmd CMD", "VoiceControl Command (default: no specific command) ") \
      { |o| options[:vc_command] = o } if opts_arr.include?(:vc_command)
      #
      # Other capture options
      #
      opts.on("", "--default_submode SUBMODE", "Default sub-mode [VIDEO|LOOPING|PIV] (default VIDEO)") \
      { |o| options[:video_dft_submode] = o } if opts_arr.include?(:video_dft_submode)
      opts.on("", "--default_submode SUBMODE", "Default sub-mode [SINGLE|CONTINUOUS|NIGHT] (default SINGLE)") \
      { |o| options[:photo_dft_submode] = o } if opts_arr.include?(:photo_dft_submode)
      opts.on("", "--default_submode SUBMODE", "Default sub-mode [BURST|TIMELAPSE]NIGHTLAPSE (default BURST)") \
      { |o| options[:multi_photo_dft_submode] = o } if opts_arr.include?(:multi_photo_dft_submode)
      opts.on("", "--default_mode MODE", "Default mode [VIDEO|PHOTO|BURST|TIMELAPSE] (default VIDEO)") \
      { |o| options[:setup_default_mode] = o } if opts_arr.include?(:setup_default_mode)
      opts.on("", "--osd OFF|ON", "Set the on-screen display (default ON)") \
      { |o| options[:setup_osd] = o } if opts_arr.include?(:setup_osd)
      opts.on("", "--led 0|2|4", "Set # of LEDS (default 4)") \
      { |o| options[:setup_led] = o } if opts_arr.include?(:setup_led)
      opts.on("", "--beep 0|40|70|100", "Set beep volume (default 100)") \
      { |o| options[:setup_beep] = o } if opts_arr.include?(:setup_beep)
      opts.on("", "--upd UP|DOWN", "Set UpD [AUTO|UP|DOWN] (default AUTO(Hero4), UP(Hero3))") \
      { |o| options[:setup_orientation] = o } if opts_arr.include?(:setup_orientation)
      #
      # Video ProTune options
      #
      opts.on("", "--pt OFF|ON", "Enable Video ProTune (if available)") \
      { |o| options[:video_pt] = o } if opts_arr.include?(:video_pt)
      opts.on("", "--pt_wb STR", "Video protune white balance [AUTO|3000K|5500K|6500K|RAW] (default AUTO)") \
      { |o| options[:video_pt_wb] = o } if opts_arr.include?(:video_pt_wb)
      opts.on("", "--pt_color STR", "Video protune color setting [GOPRO|FLAT] (default GOPRO)") \
      { |o| options[:video_pt_color] = o } if opts_arr.include?(:video_pt_color)
      opts.on("", "--pt_iso STR", "Video protune ISO setting [6400|1600|400] (default 6400)") \
      { |o| options[:video_pt_iso] = o } if opts_arr.include?(:video_pt_iso)
      opts.on("", "--pt_sharp STR", "Video protune sharpness [HIGH|MED|LOW] (default HIGH)") \
      { |o| options[:video_pt_sharp] = o } if opts_arr.include?(:video_pt_sharp)
      opts.on("", "--pt_ev VALUE", "Video protune exposure [-2.0|-1.5|-1.0|-0.5|0|0.5|1.0|1.5|2.0] (default 0)") \
      { |o| options[:video_pt_ev] = o } if opts_arr.include?(:video_pt_ev)
      #
      # Photo ProTune options
      #
      opts.on("", "--pt OFF|ON", "Enable Photo ProTune (if available)") \
      { |o| options[:photo_pt] = o } if opts_arr.include?(:photo_pt)
      opts.on("", "--pt_wb STR", "Auto white balance [AUTO|3000K|5500K|6500K|RAW] (default AUTO)") \
      { |o| options[:photo_pt_wb] = o } if opts_arr.include?(:photo_pt_wb)
      opts.on("", "--pt_color STR", "Change color setting [GOPRO|FLAT] (default GOPRO)") \
      { |o| options[:photo_pt_color] = o } if opts_arr.include?(:photo_pt_color)
      opts.on("", "--pt_iso STR", "Change ISO setting [100|200|400|800] (default 800)") \
      { |o| options[:photo_pt_iso] = o } if opts_arr.include?(:photo_pt_iso)
      opts.on("", "--pt_sharp STR", "Change sharpening [HIGH|MED|LOW] (default HIGH)") \
      { |o| options[:photo_pt_sharp] = o } if opts_arr.include?(:photo_pt_sharp)
      opts.on("", "--pt_ev VALUE", "Change exposure [-2.0|-1.5|-1.0|-0.5|0|0.5|1.0|1.5|2.0] (default 0)") \
      { |o| options[:photo_pt_ev] = o } if opts_arr.include?(:photo_pt_ev)
      opts.on("", "--shutter_ev VALUE", "Change photo shutter exposure [AUTO|2|5|10|15|20|30]") \
      { |o| options[:photo_shutter_ev] = o } if opts_arr.include?(:photo_shutter_ev)
      #
      # Multi-Photo ProTune options
      #
      opts.on("", "--pt OFF|ON", "Enable Photo ProTune OFF|ON (if available)") \
      { |o| options[:multi_photo_pt] = o } if opts_arr.include?(:multi_photo_pt)
      opts.on("", "--pt_wb STR", "Auto white balance [AUTO|3000K|5500K|6500K|RAW] (default AUTO)") \
      { |o| options[:multi_photo_pt_wb] = o } if opts_arr.include?(:multi_photo_pt_wb)
      opts.on("", "--pt_color STR", "Change color setting GOPRO|FLAT (default GOPRO)") \
      { |o| options[:multi_photo_pt_color] = o } if opts_arr.include?(:multi_photo_pt_color)
      opts.on("", "--pt_iso VALUE", "Change ISO setting [100|200|400|800](default 800)") \
      { |o| options[:multi_photo_pt_iso] = o} if opts_arr.include?(:multi_photo_pt_iso)
      opts.on("", "--pt_sharp STR", "Change sharpening HIGH|MED|LOW (default HIGH)") \
      { |o| options[:multi_photo_pt_sharp] = o } if opts_arr.include?(:multi_photo_pt_sharp)
      opts.on("", "--pt_ev STR", "Change exposure [-2.0|-1.5|-1.0|-0.5|0|0.5|1.0|1.5|2.0] (default 0)") \
      { |o| options[:multi_photo_pt_ev] = o } if opts_arr.include?(:multi_photo_pt_ev)
      opts.on("", "--shutter_ev VALUE", "Change photo shutter exposure [AUTO|2|5|10|15|20|30]") \
      { |o| options[:multi_photo_shutter_ev] = o } if opts_arr.include?(:multi_photo_shutter_ev)
      opts.on("", "--keep_media", "Keep the existing media on the SD card.") \
      { |o| options[:keep_media] = true } if opts_arr.include?(:keep_media)
      #
      # Data Analytics options
      #
      opts.on("", "--analytic_file FILE", "Data Analytics file to process") \
      { |o| options[:analytic_file] = o } if opts_arr.include?(:analytic_file)
      opts.on("", "--generate_analytic_file", "Generate analytic file using two-letter commands") \
      { |o| options[:generate_analytic_file] = true } if opts_arr.include?(:generate_analytic_file)
      opts.on("", "--analytic_version VER", "Parse data analytics version VER (0.0.0/0.1.0)") \
      { |o| options[:analytic_version] = o } if opts_arr.include?(:analytic_version)
      opts.on("", "--model MODEL", "Camera model [BACKDOOR|PIPE|ROCKYPOINT|HALEIWA|HIMALAYAS]") \
      { |o| options[:model] = o } if opts_arr.include?(:model)
      #
      # MTP options
      #
      opts.on("", "--mtp_ip IP", "IP of system which camera is currently connecting to") \
      { |o| options[:mtp_ip] = o } if opts_arr.include?(:mtp_ip)
      opts.on("", "--mtp_port PORT", "Port which NodeJS is listening on") \
      { |o| options[:mtp_port] = o } if opts_arr.include?(:mtp_port)
      opts.on("", "--mtp_os OS", "MAC or WIN of system which camera is currently connecting to") \
      { |o| options[:mtp_os] = o } if opts_arr.include?(:mtp_os)
      #
      # Media Maker Tool options
      #
      opts.on("", "--skip_initial_format", "Prevents existing media from being removed from SD card.") \
      { |o| options[:skip_initial_format] = true } if opts_arr.include?(:skip_initial_format)
      opts.on("", "--format_afterwards", "Removes generated media from the card between capture modes..") \
      { |o| options[:format_afterwards] = true } if opts_arr.include?(:format_afterwards)
      opts.on("", "--skip_upload", "Causes the media to not be uploaded to network drive.") \
      { |o| options[:skip_upload] = true } if opts_arr.include?(:skip_upload)
      opts.on("", "--upload_to FILE", "Specifies the location to upload the media to.") \
      { |o| options[:upload_to] = o } if opts_arr.include?(:upload_to)
      #
      # Test run options
      #
      opts.on("", "--filter [STRING]", "Filter the tests in some way based on STRING") \
      { |o| options[:filter] = o } if opts_arr.include?(:filter)
      opts.on("", "--camera_mode MODE", "Set initial camera mode [VIDEO|VIDEO_TIMELAPSE|PHOTO|BURST|TIMELAPSE|SETTINGS]") \
      { |o| options[:mode_cm] = o } if opts_arr.include?(:mode_cm)
      opts.on("", "--iterations N", "Perform N iterations of the test.") \
      { |o| options[:n_iter] = o } if opts_arr.include?(:n_iter)
      opts.on("", "--to_firmware FILE", "OTA firmware file to install to") \
      { |o| options[:fw_file] = o } if opts_arr.include?(:fw_file)
      opts.on("", "--fr_firmware FILE", "OTA firmware file to install from") \
      { |o| options[:base_fw_file] = o } if opts_arr.include?(:base_fw_file)
      opts.on("", "--duration SECS", "Seconds, or range of seconds (L:H), to wait or encode") \
      { |o| options[:duration] = o } if opts_arr.include?(:duration)
      opts.on("", "--tag_interval SECS", "Seconds between tagging hilights") \
      { |o| options[:tag_interval] = o } if opts_arr.include?(:tag_interval)
      opts.on("", "--shuffle [SEED]", "Randomly mix the order of the tests") \
      { |o| options[:shuffle] = true; options[:seed] = o } if opts_arr.include?(:shuffle)
      opts.on("", "--save_dir DIR", "Directory in which to save downloaded files (default /tmp)") \
      { |o| options[:save_dir] = o } if opts_arr.include?(:save_dir)
      opts.on("", "--quickcapture ON|OFF", "Turn quickcapture on (default OFF)") \
      { |o| options[:quickcapture] = o } if opts_arr.include?(:quickcapture)
      opts.on("", "--ntsc_only", "Only do NTSC frame-rates (default False)") \
      { |o| options[:ntsc_only] = true } if opts_arr.include?(:ntsc_only)
      opts.on("", "--pal_only", "Only do PAL frame-rates (default False)") \
      { |o| options[:pal_only] = true } if opts_arr.include?(:pal_only)
      opts.on("", "--quick", "Run a quick version of the test (if supported)") \
      { |o| options[:quick] = true } if opts_arr.include?(:quick)
      opts.on("", "--full", "Run a long version of the test (if supported)") \
      { |o| options[:full] = true } if opts_arr.include?(:full)
      opts.on("", "--dryrun", "Exit after parsing (and dumping) options") \
      { |o| options[:dryrun] = true }
      opts.on("", "--stress", "Run stress tests only") \
      { |o| options[:stress] = true }
      opts.on("", "--set_defaults", "Set camera to defaults") \
      { |o| options[:set_defaults] = true } if opts_arr.include?(:set_defaults)
      opts.on("", "--verb", "Verbose logging") \
      { |o| options[:verb] = true }
      opts.on("", "--permissive", "Follow any applicable workarounds in the code") \
      { |o| options[:permissive] = true }
      opts.on("", "--reset_on_failure", "Attempt camera reset on test fail.") \
      { |o| @reset_on_failure = true } if opts_arr.include?(:reset_on_failure)
      opts.on("", "--autoconnect", "Use if sharing one host Wi-Fi among multiple cameras") \
      { |o| @autoconnect = true }
      opts.on("", "--range R", "Only run loops within the range R='X:Y' (default 0:-1)") \
      { |o| options[:range_min] = o.split(":")[0].to_i
        options[:range_max] = o.split(":")[1].to_i } if opts_arr.include?(:range)
      opts.on("", "--pause", "general purpose pause between tests/operations (hit Enter to continue)") \
      { |o| options[:pause] = o} if opts_arr.include?(:pause)
      opts.on("", "--test_delay VALUE", "delay in seconds between individual tests") \
      { |o| options[:test_delay] = o} if opts_arr.include?(:test_delay)
      opts.on("", "--io_delay VALUE", "delay in seconds between IO operations") \
      { |o| options[:io_delay] = o} if opts_arr.include?(:io_delay)
      opts.on("", "--download_media DIR", "Download media to DIR after test") \
      { |o| options[:download_media] = o} if opts_arr.include?(:download_media)
      opts.on("", "--media_dir DIR", "Directory Containing Argus video files. Default $PWD") \
      { |o| options[:media_dir] = o} if opts_arr.include?(:media_dir)
      opts.on("", "--delete_trv", "Delete the TRV file after transcoding") \
      { |o| options[:delete_trv] = true} if opts_arr.include?(:delete_trv)

      # Features that can be toggled on.
      opts.on("", "--raw OFF|ON", "Set RAW photo mode setting.") \
      { |o| options[:raw] = o} if opts_arr.include?(:raw)
      opts.on("", "--wdr OFF|ON", "Set Wide Dynamic Range setting.") \
      { |o| options[:wdr] = o} if opts_arr.include?(:wdr)
      opts.on("", "--awf OFF|WIND|STEREO", "Set Audio Wind Filter setting.") \
      { |o| options[:awf] = o} if opts_arr.include?(:awf)
      opts.on("", "--eis OFF|ON", "Set Image Stabalization setting.") \
      { |o| options[:eis] = o} if opts_arr.include?(:eis)

      opts.on("-h", "--help", "Display this message and exit") {
        begin
          puts op
        rescue StandardError => e
          log_error("CRASH!! A long-option string in testcase.rb::parse_options() might be too long.")
          log_info("28 characters max!")
          log_info(e.to_s + "\n" + e.backtrace.join("\n"))
        ensure
          exit 1
        end
      }
    end
    op.parse(argv)

    if options[:logfile] == nil
      log_warn("No log file specified.  Screen output only.") if quiet == false
    else
      $LOG_FILE = options[:logfile]
      #      log_conf("Log file set to #{$LOG_FILE}")
    end

    # Now that the log file is defined, log the git hash of the commit being used.
    display_git_info()

    if options[:shuffle] == true
      if options[:seed] != false
        seed = options[:seed].to_i
      else
        seed = srand >> 100
      end
      @shuffle = true
      srand seed
    end

    # Parse out duration ranges if there's a range in duration.
    if options[:duration] and options[:duration].include?(":")
      low, dummy, high = options[:duration].partition(":")
      options[:duration_range_low] = low.to_i
      options[:duration_range_high] = high.to_i
    end

    # Exit if just a dryrun.  Good for debugging roster files
    if options[:dryrun] == true
      log_info("=========== DRYRUN ===========")
      require 'pp'
      pp options
      exit 0
    elsif quiet == false
      log_conf("starttime, #{Time.now().strftime($LOG_TIME_STR)}")
      log_conf("cmd, #{$0} %s" %argv.join(" "))
      options.each { |k, v|
        log_conf("#{k.to_s}, #{v}") if options[:verb] or v != nil
      }
    end
    return options
  end

  def set_defaults
    log_info("Setting defaults")
    @camera.defaults.each { |k, v|
      if @camera.already_set?(k, v)[0]
        log_verb("set_defaults - #{k.to_s} already set to #{v.to_s}")
      else
        log_verb("set_defaults - setting #{k.to_s} to #{v.to_s}")
        @camera.set(k, v)
      end
    }
    log_info("Done setting defaults")
  end

  def set_options()
    log_info("Setting initial camera setup")
    if @camera.interfaces.include?(:wifi)
      #turn off settings that get camera out of the norm (ie looping, photo-in-video, protune)
      if @camera.video_protune_support?
        @camera.set_video_protune("OFF")
      end

      tu_reset_looping_off if @camera.remote_api_version == 1
      tu_reset_piv_off if @camera.remote_api_version == 1
      if @camera.photo_continuous_support? == true and @camera.get_photo_continuous_rates().include?(1)
        @camera.set_photo_continuous(1)
      end

      if @options[:set_defaults] == true
        @camera.defaults.each { |k, v|
          next if k == :video_pt and !@camera.video_protune_support?
          next if k == :photo_continuous and !@camera.photo_continuous_support?

          if @options[k] != nil
            @camera.set(@camera.method(k).call(), @options[k]) if !@camera.already_set?(k, @options[k])
          else
            @camera.set(@camera.method(k).call(), v) if !@camera.already_set?(k, v)
          end
        }
      else
        #Initial camera setup
        @camera.setup.each{ |k, v|
          @camera.set(k, v)
        }

        #remove key not in setup list
        defaults_keys = @camera.setup.keys
        options = @options.reject {|k,v|
          !defaults_keys.include?(k)
        }

        #remove key with nil value
        options.reject!{ |k,v| v == nil }

        #Overwrite setting if needed
        options.each {|k, v|
          @camera.set(k, v) if v != "ALL"
        }
        # Really we should call methods of the Camera class to avoid dependencies in
        # wifi_commands and serial_commands
      end
    else # serial interface
      if @options[:set_defaults] == true
        log_info("Resetting user settings to factory defaults...")
        @camera.do_factory_reset("USER")
      end
      set_flag = false
      @options.each { |k, v|
        next if v == nil
        case(k)
        when :video_piv
          @camera.set_video_piv(v)
        when :video_spot_metering
          @camera.set_video_spot_metering(v)
        when :video_low_light
          @camera.set_video_low_light(v)
        when :video_pt
          @camera.set_video_protune(v)
        when :video_pt_wb
          set_video_protune_white_balance(v)
        when :video_pt_color
          set_video_protune_color(v)
        when :video_pt_iso
          set_video_protune_iso(v)
        when :video_pt_sharp
          set_video_protune_sharpness(v)
        when :video_pt_ev
          set_video_protune_exposure(v)
        when :photo_spot_metering
          @camera.set_photo_spot_metering(v)
        when :multi_photo_spot_meter
          @camera.set_multi_spot_metering(v)
        when :setup_default_mode
          @camera.set_default_capture_mode(v)
        when :def_video_submode
          @camera.set_video_def_sub_mode(v)
        when :def_photo_submode
          @camera.set_photo_def_sub_mode(v)
        when :def_multi_photo_submode
          @camera.set_multi_def_sub_mode(v)
        when :setup_osd
          @camera.set_osd(v)
        when :setup_led
          @camera.set_led(v)
        when :setup_beep
          @camera.set_beep_volume(v)
        when :setup_orientation
          @camera.set_orientation(v)
        when :quickcapture
          @camera.set_quickcapture(v)
          # TODO
          # lcd brightness/timeout/lock?
          # others?
        else
          # log_warn(
          #   "Skipping setting #{k} to #{v}.  Add to Testcase.set_options() if you want it.")
          next
        end
        log_info("Setting #{k} to #{v}")
        set_flag = true
      }
    end
    # Only bother saving and rebooting if something was actually set
    if set_flag == true
      log_info("Saving settings and rebooting camera")
      @camera.save_settings()
      sleep(3.0)
      @camera.do_reset()
    end
  end # end set_options()

  def final_actions()
    @camera.pushy.close() if @camera != nil and @camera.pushy != nil
    # To support log parsing of individual test runs
    log_conf("endtime, #{Time.now().strftime($LOG_TIME_STR)}")
  end
end

if __FILE__ == $0
  tc = TestCase.new
  opts = tc.parse_options(ARGV, nil)
  puts "testcase.rb called directly from the command line."
end
