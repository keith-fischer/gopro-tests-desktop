module Rockypoint
  def init
    @name = "ROCKYPOINT"
    log_verb("Instantiating #{name} camera")
    @remote_api = 2  #remote smarty api version 2 (ie http://10.5.5.9/gp/gpControl/setting/1/0)
    @data_log_model = 16  # Camera model number for analytics purposes
    @analytics_version = "0.1.0"

    @audio_channels       = 1
    @audio_codec          = "aac"
    @audio_sample_rate    = 32000
    @audio_bitrate        = 64    #in kbps per channel.
    @avc_profile_level    = "MAIN"  # Same as Uluwatu
    # Support for changing preview bitrate via BV command
    @chg_prev_br_support  = nil #TBD
    # Support for changing preview resolution via BV command
    @chg_prev_res_support = true
    @colorspace           = "yuvj420p"
    @video_codec          = "h264"
    @total_lrv_bitrate    = 0.7
    @hilight_tag_limit    = 100

    #video
    @video_low_light_support    = true
    @video_protune_support      = true
    @video_timelapse_support    = false
    @video_piv_support          = false
    @video_looping_support      = true
    #photo
    @photo_spot_metering_support      = true
    @photo_continuous_support         = false
    @photo_night_support              = false
    @photo_protune_support            = false
    #multi_photo
    @multi_photo_spot_metering_support = true
    @multi_photo_nightlapse_support    = false
    @multi_photo_protune_support       = false

    # Share video/photo/multi_photo protune value. Split where necessary
    @video_protune_modes          = ["VIDEO"]
    @protune_white_balance_values = [nil]
    @protune_color_values         = [nil]
    @protune_sharpness_values     = ["OFF", "ON"]
    @protune_exposure_values      = [nil]
    # @photo_protune_iso_values     = [100, 200, 400, 800]
    @video_protune_iso_values     = ["1600", "400"]

    # @video_piv_intervals     = [5, 10, 30, 60]
    # @photo_shutter_exposure  = ["AUTO", "2", "5", "10", "15", "20", "30"]
    # @multi_shutter_exposure  = ['AUTO', "2", "5", "10", "15", "20", "30"]

    # preview stream testing flag
    @test_preview_stream     = false

    #photo's preview stream
    @photo_ts = {
      :lrv_aspect_ratio => "4:3",
      :lrv_width        => 320,
      :lrv_height       => 240
    }

    @capabilities = { #cc
      :has_camera_roll      => true,
      :has_ota              => true,  #over the air firmware update
      :has_ltp              => true,
      :has_3D               => false,
      :has_ccl              => true,   #camera control library
    }

    @defaults = {
      :setup_video_format     => "NTSC",
      :video_submode          => "VIDEO",
      :video_timelapse        => "0.5",
      :video_looping          => "5",
      :video_resolution       => "1080_SUPER",
      :video_fps              => "30",
      :video_fov              => "W",
      :video_low_light        => "ON",
      :video_spot_metering    => "OFF",
      :video_pt_wb            => nil,
      :video_pt_color         => nil,
      :video_pt_sharp         => "ON",
      :video_pt_iso           => "1600",
      :video_pt_ev            => nil,
      :photo_submode          => "PHOTO",
      :photo_resolution       => "8WIDE",
      :photo_spot_metering    => "OFF",
      :multi_photo_submode    => "TIMELAPSE",
      :multi_photo_resolution => "8WIDE",
      :multi_photo_burst      => "5_1",
      :multi_photo_timelapse  => "0.5",
      :multi_photo_spot_meter => "OFF",
      :setup_default_mode     => "VIDEO",
      :setup_orientation      => "UP",
      :setup_led              => "4",
      :setup_beep             => "100",
    }

    #Initial camera setup before executing any tests
    @setup = {
      :setup_led              => "ON",
      :setup_beep             => "100",
    }

    # Commands that don't have prerequisites
    # Wifi commands to test
    @cmds = [
      :setup_beep,
      :setup_default_mode,
      :setup_led,
      :video_spot_metering,
      :photo_spot_metering,
      :multi_photo_spot_meter,
      :setup_orientation,
      :setup_video_format,
    ]

    # Data structure for preview specifications
    # Basically come in 2 flavors.  Fullscreen and Widescreen
    # Fullscreen is 4:3 and widescreen is anything >4:3
    @preview = {
      # QVGA, WQVGA.  bitrate in bps
      "LOW" => {
      :bitrate => {
      :LOW  => 311040,
      :MED  => 500000,
      :HIGH => 750000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 240,
      :width_fs         => 320, # QVGA
      :width_ws         => 432, # WQVGA
      },
      # VGA, QVGA.  bitrate in bps
      "HIGH" => {
      :bitrate => {
      :LOW  => 1221120,
      :MED  => 2000000,
      :HIGH => 3000000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 480,
      :width_fs         => 640, # QVGA
      :width_ws         => 848, # WQVGA
      },
    }

    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 5,
      "120"   => 5,
      "MAX"   => 5,
    }

    # File size limit for videos after which it is split
    @chapter_size = 2<<30 # 2 GB

    @video_protune_vars = {
      :video_pt_color   => false,
      :video_pt_iso     => true,
      :video_pt_sharp   => true,
      :video_pt_ev      => false,
      :video_pt_wb      => false
    }

    # @photo_protune_vars = {
    #   :photo_pt_color   => true,
    #   :photo_pt_iso     => true,
    #   :photo_pt_sharp   => true,
    #   :photo_pt_ev      => true,
    #   :photo_pt_wb      => true
    # }

    # @multi_photo_protune_vars = {
    #   :multi_photo_pt_color   => true,
    #   :multi_photo_pt_iso     => true,
    #   :multi_photo_pt_sharp   => true,
    #   :multi_photo_pt_ev      => true,
    #   :multi_photo_pt_wb      => true
    # }

    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    @video_capture_modes = {
      "1440"  =>  {
      :width  => 1920,
      :height => 1440,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :time_lapse => false,
      :fps    => {
      "25"  => {
      :fov        => ["W"],
      :fov_protune => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping => true,
      :piv        => false,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      "30"  => {
      :fov        => ["W"],
      :fov_protune => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 14.99,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping => true,
      :piv        => false,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      } # end fps
      }, # end 1440
      "1080_SUPER"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => false,
      :fps    => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 14.99,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping => true,
      :piv        => false,
      },
      "48"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 11.99,
      :lrv_timecode => false,
      :timecode   => false,
      :frame_rate => 47.95,
      :low_light  => true,
      :looping => true,
      :piv        => false,
      },
      } # end fps
      }, # end 1080_SUPER
      "1080"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => false,
      :fps    => {
      "25"  => {
      :fov        => ["W", "M"],
      :fov_protune => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      "30"  => {
      :fov        => ["W", "M"],
      :fov_protune => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 14.99,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      "50"  => {
      :fov        => ["W", "M"],
      :fov_protune => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :piv        => false,
      :looping    => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      "60"  => {
      :fov        => ["W", "M"],
      :fov_protune => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 9.99,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :piv        => false,
      :looping    => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      } # end fps
      }, # end 1080
      "960"  =>  {
      :width  => 1280,
      :height => 960,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :time_lapse => false,
      :fps    => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping => true,
      :protune => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping => true,
      :protune => false,
      },
      "50"  => {
      :fov        => ["W"],
      :fov_protune => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping => true,
      :piv        => false,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      "60"  => {
      :fov        => ["W"],
      :fov_protune => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping => true,
      :piv        => false,
      :pt_lrv     => true,
      :pt_thm     => true,
      },
      } # end fps
      }, # end 960
      "720_SUPER"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => false,
      :fps    => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping => true,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping => true,
      },
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping => true,
      :piv        => false,
      },
      } # end fps
      }, # end 720_SUPER
      "720"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => true,
      :fps    => {
      "25"  => {
      :fov        => ["W", "M"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping => true,
      },
      "30"  => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping => true,
      },
      "50"  => {
      :fov        => ["W", "M"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping => true,
      },
      "60"  => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping => true,
      # :piv_fov    => ["M"],
      },
      "100" => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :timecode   => false,
      :frame_rate => 100,
      :low_light  => true,
      },
      } # end fps
      }, # end 720
      "WVGA"  =>  {
      :width  => 856,  # SHOULD BE 848, but known bug in FFPROBE
      :height => 480,
      :aspect_ratio => "107:60",
      :protune => false,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => false,
      :fps    => {
      "100" => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 25,
      :timecode   => false,
      :frame_rate => 100,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "120" => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 27.5,
      :pt_bitrate => 27.5,
      :thm        => true,
      :lrv_fps    => 29.97,
      :timecode   => false,
      :frame_rate => 119.88,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      }
      } # end fps
      } # end WVGA
    } # end @video_capture_modes

    # Photo Modes
    @photo_modes = {
      "5MED" => {
      :width        => 2720,
      :height       => 2040,
      :min_size     => 1500, # KB
      :min_psnr     => 31.0, # May raise if camera noise is reduced.
      :min_quality  => 98.0,
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 5MED
      "8WIDE" => {
      :width        => 3264,
      :height       => 2448,
      :min_size     => 1800, # KB
      :min_psnr     => 31.0, # May raise if camera noise is reduced.
      :min_quality  => 98.0,
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 7WIDE
    } # end PHOTO mode
  end # end init
end # end module Rockypoint
