require "open3"
require_relative "log_utils"

class TestRunner
  include LogUtils
  attr_accessor :cam, :cmd, :test_file,
    :start_time, :end_time, :duration,
    :passed, :failed, :skipped, :errors, :total,
    :exitstat, :log_file, :warns

  def initialize(cam)
    # A copy of the camera object running this test
    @cam = cam
    # Command that is run to start the test
    @cmd  = ""
    @test_file = ""
    # Run options
    @run_options = []
    # Time objects
    @start_time = nil
    @end_time   = nil
    @duration   = nil  # 24 hour max.  Will wrap around otherwise.
    # Integer counters
    @total    = 0
    # Array of Arrays to hold test results
    # Elements are of the form [result, tc-name, msg]
    # See log_utils.rb::parse_log_result() for details
    @passed   = []
    @failed   = []
    @skipped  = []
    @errors   = []
    @warns    = []
    # Type (Process::Status)
    @exitstat = nil
    # Logging location
    @log_file = nil
  end

  def run(cmd)
    log_verb("testHandler.rb::TestRunner @cam.autoconnect=#{@cam.autoconnect}")
    log_verb("@cam.interfaces=#{@cam.interfaces}")
    # Add the IP, pairing code, and log file to the command
    cmd += " --ip #{@cam.ip}"           if defined?(@cam.ip)
    cmd += " --pc #{@cam.pairing_code}" if defined?(@cam.pairing_code)
    if defined?(@cam.dev) and not @cam.interfaces.include?(:gccb) # Serial camera
      cmd += " --serial #{@cam.dev}"
    end
    if defined?(@cam.serial_iface) and @cam.serial_iface != nil
      cmd += " --serial #{@cam.serial_iface}"  # Wi-Fi camera
    end
    cmd += " --logfile #{@log_file}"          if @log_file != nil
    cmd += " --usboutlet #{@cam.usboutlet}"   if @cam.usboutlet != nil
    cmd += " --battoutlet #{@cam.battoutlet}" if @cam.battoutlet != nil
    cmd += " --autoconnect"                   if @cam.autoconnect == true
    cmd += " --pushy \"#{@cam.pushy}\""       if @cam.pushy != nil
    # Hackitty Hack to get FW info to our BAT test
    if cmd.match(/test_.*_bat/) != nil and @cam.fw_file != nil
      cmd += " --to_firmware #{@cam.fw_file}"
    end
    @cmd = cmd # Save the command details for later

    # Start the actual test
    log_verb("Calling TestRunner::run(#{cmd})")
    @test_file = File.basename(cmd.split()[1])
    @start_time = Time.now
    Open3.popen3(cmd) do |stdin, stdout, stderr, wait_thr|
      while line = stdout.gets
        parse_output(line)
      end
      @exitstat = wait_thr.value
    end
    @end_time = Time.now
    time_obj = Time.new(2000) + (@end_time - @start_time)
    @duration = time_obj.strftime("%H:%M:%S")
    log_verb("Testrun instance variables:\n#{dump_members()}")
  end

  # parse_log_result() is in log_utils.rb
  def parse_output(line)
    puts line
    if line.match(ltp_re_str($PASS))
      @total  += 1
      @passed << parse_log_result(line)
    elsif line.match(ltp_re_str($FAIL))
      @total  += 1
      @failed << parse_log_result(line)
    elsif line.match(ltp_re_str($SKIP))
      @total   += 1
      @skipped << parse_log_result(line)
    elsif line.match(ltp_re_str($ERR))
      @total  += 1
      @errors << parse_log_result(line)
    elsif line.match(ltp_re_str($WARN))
      @total += 1
      @warns << parse_log_result(line)
    elsif line.match(ltp_re_str($CONF))
      # Can pull out any interesting conf parameters here
      # and save ofr later in results obj
      temp = line.split(":")[1].split(",")
      key = temp[0].strip()
      val = temp[1].strip()
      if key == "media_dir"
        @cam.media_dir = val
      end
    end
  end

  def dump_members
    ret = <<-eos
    @cam          = #{@cam}
    @cmd          = #{@cmd}
    @test_file    = #{@test_file}
    @run_options  = #{@run_options}
    @start_time   = #{@start_time}
    @end_time     = #{@end_time}
    @duration     = #{@duration}
    @passed       = #{@passed}
    @failed       = #{@failed}
    @skipped      = #{@skipped}
    @errors       = #{@errors}
    @warns        = #{@warns}
    @total        = #{@total}
    @exitstat     = #{@exitstat}
    @log_file     = #{@log_file}
    eos
  end
end # end TestRunner class


if __FILE__ == $0
  require_relative 'wifi_camera.rb'
  $LOGLEVEL = $LL_VERB
  # args are serial device, command (must be quoted)
  # i.e. /dev/ttyUSB0, "ruby tests/test1.rb"
  c = get_camera("wifi", "10.5.5.9", "goprohero")
  tr = TestRunner.new(c)
  cmd = "ruby ../tests/test_video_metadata.rb --res 1080 --fps 30 --fov W --pt OFF"
  tr.run(cmd)
  require_relative 'resultsHandler'
  rH = ResultsHandler.new([tr])
  puts rH.standard_report()
end
