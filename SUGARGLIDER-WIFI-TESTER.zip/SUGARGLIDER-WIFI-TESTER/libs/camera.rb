# camera.rb
##require 'net/http/persistent'
require 'json'
require 'uri'
require 'set'

require_relative 'exitcodes'
require_relative 'log_utils'
require_relative 'metadata'
require_relative 'wifi_commands'
require_relative 'pushy'

# Factory functions that return approprite camera objects
def get_camera(iface, ip=nil, pc=nil, serial_dev=nil, mtp_port=nil, mtp_os=nil, gccb_dev=nil, rc_info=nil, log_path=nil, ble=nil)


  # log_info("iface=#{iface} ip=#{ip} pc=#{pc} serial_dev=#{serial_dev} gccb_dev=#{gccb_dev} log_path=#{log_path} ble=#{ble}")
  if iface == 'serial'
    require_relative 'serial_camera'
    return SerialCamera.new(serial_dev)
  elsif iface == 'gccb'
    require_relative 'gccb_camera'
    return GCCBCamera.new(gccb_dev, serial_dev, log_path)
  elsif iface == 'rc'
    require_relative 'rc_camera'
    return RCCamera.new(rc_info)
  elsif iface == 'wifi'
    require_relative 'wifi_camera'
    return WifiCamera.new(ip, pc, serial_dev, log_path)
  elsif iface == 'mtp'
    require_relative 'mtp_camera'
    return MTPCamera.new(ip, mtp_port, mtp_os)
  elsif iface == 'ble'
    require_relative 'ble_api'
    return BLEdevice.new(ip, pc, ble, serial_dev)
  else
    log_info("You get nothing! You lose! Good day sir!")
    return nil
  end
end

def get_gccb_camera(gccb_dev, cam_serial_log=nil, log_path=nil)
  get_camera('gccb', nil, nil, cam_serial_log, nil, nil, gccb_dev, nil, log_path, nil)
end

def get_rc_cameras(rc_info)
  get_camera('rc', nil, nil, nil, nil, nil, nil, rc_info)
end

def get_serial_camera(dev)
  get_camera('serial', nil, nil, dev, nil, nil, nil)
end

def get_wifi_camera(ip, pc=nil, serial=nil, log_path=nil)
  get_camera('wifi', ip, pc, serial, nil, nil, nil, nil, log_path)
end

def get_mtp_camera(ip, mtp_port, mtp_os)
  get_camera('mtp', ip, nil, nil, mtp_port, mtp_os, nil)
end

def get_ble_device(ip, pc=nil, ble=nil, cam_serial_log=nil)
  get_camera('ble', ip, pc, cam_serial_log, nil, nil, nil, nil, nil, ble)
end


class Camera
  include LogUtils
  include WifiCommands

  attr_accessor :interfaces, :powerstrip, :battoutlet, :usboutlet,
  :build, :tc_name, :pushy
  attr_reader :name
  def initialize
    @interfaces = []
    @name       = "UNK_NAME"
    @build      = "UNK_BUILD"
    @powerstrip = nil
    @battoutlet = nil
    @usboutlet  = nil
    @tc_name    = "UNK_TEST_CASE"
    @pushy      = nil
  end

  ##################################################################
  # GETTERS for model-specific settings (RES, FPS, FOV, etc.)
  ##################################################################

  def get_cmds(); @cmds; end

  # Get all the video resolutions supported by the camera
  def get_video_resolution(); return @video_capture_modes.keys(); end

  def get_video_timelapse_resolution; return @video_timelapse_capture_modes.keys; end

  def get_video_timelapse_fov(res)
    ret = @video_timelapse_capture_modes[res][:fov]
    # Not all cameras have timelapse FOVs.
    # Those that don't are always Wide FOVs.
    ret ? ret : ["W"]
  end

  # Get all the FPS supported at a particular resolution
  def get_video_fps(res); return @video_capture_modes[res][:fps].keys(); end

  # Get all the FOV supported at a particular (res, fps) combo
  def get_video_fov(res, fps, pt=nil)
    if pt == "ON" and @video_capture_modes[res][:fps][fps].has_key?(:fov_protune)
      return @video_capture_modes[res][:fps][fps][:fov_protune]
    else
      return @video_capture_modes[res][:fps][fps][:fov]
    end
  end

  # Returns a SET of all video FOVs used on the camera.
  # Useful for determining single-FOV cameras (Bolinas, Haleiwa, Himalayas, etc.)
  def get_all_fovs()
    ret = Set.new
    get_video_resolution().each { |res|
      get_video_fps(res).each { |fps|
        get_video_fov(res, fps).each { |fov|
          ret << fov
        }
      }
    }
    return ret.to_a
  end

  # Returns true if a particular capture mode (res, fps) is NTSC
  def is_ntsc?(res, fps); return @video_capture_modes[res][:fps][fps][:ntsc]; end

  # Returns true if a particular capture mode (res, fps) is PAL
  def is_pal?(res, fps); return @video_capture_modes[res][:fps][fps][:pal]; end

  # Get all the NTSC FPS supported at a particular resolution
  def get_fps_ntsc(res); return get_video_fps(res).reject {|f| is_ntsc?(res, f) == false}; end

  # Get all the PAL FPS supported at a particular resolution
  def get_fps_pal(res); return get_video_fps(res).reject {|f| is_pal?(res, f) == false}; end

  # Get the allowable resolutions for preview
  def get_preview_resolutions(); return @preview.keys(); end

  # Get the allowable bitrates for a particular preview resolution
  def get_preview_bitrates(res); return @preview[res][:bitrate].keys(); end

  # Returns true if a given RES/FPS should produce a low-res file
  def has_lrv?(res, fps, fov, pt="OFF")
    myhash = @video_capture_modes[res][:fps][fps]
    if pt == "ON" and myhash.has_key?(:pt_lrv)
      pt_lrv = myhash[:pt_lrv]
    else
      pt_lrv = true
    end
    fov_lrv = myhash.has_key?(:fov_lrv) ? myhash[:fov_lrv].include?(fov) : true
    lrv_fps = myhash[:lrv_fps] != false

    return pt_lrv & fov_lrv & lrv_fps
  end

  def video_timelapse_has_lrv?(vm, res)
    vm == "NTSC" ? @video_timelapse_capture_modes[res][:lrv_ntsc_fps] != false : @video_timelapse_capture_modes[res][:lrv_pal_fps] != false
  end

  # Returns true if a given RES/FPS should produce a thumbnail file
  def has_thm?(res, fps, pt = "OFF")

    if pt == "ON"
      pt_thm = @video_capture_modes[res][:fps][fps].has_key?(:pt_thm) ? @video_capture_modes[res][:fps][fps][:pt_thm] : false
      return pt_thm
    end

    @video_capture_modes[res][:fps][fps].has_key?(:thm) ? @video_capture_modes[res][:fps][fps][:thm] : false
  end

  def video_timelapse_has_thm?(res)
    @video_timelapse_capture_modes[res].has_key?(:thm) ? @video_timelapse_capture_modes[res][:thm] : false
  end

  def mp4_has_timecode?(res, fps)
    @video_capture_modes[res][:fps][fps].has_key?(:timecode) ? @video_capture_modes[res][:fps][fps][:timecode] : false
  end

  def lrv_has_timecode?(res, fps)
    @video_capture_modes[res][:fps][fps].has_key?(:lrv_timecode) ? @video_capture_modes[res][:fps][fps][:lrv_timecode] : false
  end

  # Return true if a given RES/FPS support in given mode (NTSC/PAL)
  def mode_supported?(mode, res, fps)
    mode.upcase == "NTSC" ? is_ntsc?(res, fps) : is_pal?(res, fps)
  end

  # Return lrv aspect ration
  def get_lrv_aspect_ratio(res); @video_capture_modes[res][:lrv_aspect_ratio]; end

  # Return the LRV width
  def get_lrv_width(res, fps)
    ret = 0
    if @video_capture_modes[res][:fps][fps].has_key?(:lrv_width)
      ret = @video_capture_modes[res][:fps][fps][:lrv_width]
    elsif @video_capture_modes[res].has_key?(:lrv_width)
      ret = @video_capture_modes[res][:lrv_width]
    else
      log_warn("No :lrv_width key found!")
    end
    return ret
  end

  # Return the LRV height
  def get_lrv_height(res, fps)
    ret = 0
    if @video_capture_modes[res][:fps][fps].has_key?(:lrv_height)
      ret = @video_capture_modes[res][:fps][fps][:lrv_height]
    elsif @video_capture_modes[res].has_key?(:lrv_height)
      ret = @video_capture_modes[res][:lrv_height]
    else
      log_warn("No :lrv_height key found!")
    end
    return ret
  end

  # Return the LRV FPS for a given RES/FPS
  def get_lrv_fps(res, fps)
    return @video_capture_modes[res][:fps][fps][:lrv_fps]
  end

  # Return the total LRV bitrate (video + audio + data).
  def get_lrv_bitrate(res, fps)
    ret = @total_lrv_bitrate
    if @video_capture_modes[res][:fps][fps].has_key?(:lrv_bitrate)
      ret = @video_capture_modes[res][:fps][fps][:lrv_bitrate]
    end
    return ret
  end

  # Return video timelapse lrv bitrate
  def get_video_timelapse_lrv_bitrate(res, fps=nil)
    ret = @total_video_timelapse_lrv_bitrate
    if res != nil and @video_timelapse_capture_modes[res].has_key?(:lrv_bitrate)
      ret = @video_timelapse_capture_modes[res][:lrv_bitrate]
    elsif res != nil and fps != nil
      if @video_timelapse_capture_modes[res][:fps][fps].has_key?(:lrv_bitrate)
        ret = @video_timelapse_capture_modes[res][:fps][fps][:lrv_bitrate]
      end
    end
    return ret
  end

  # Return the available parameters for a given cmd_hash
  def get_set_params(cmd_hash)
    keys = cmd_hash.keys()
    keys.delete(:set)
    keys.delete(:get)
    keys.delete(:ret)
    keys
  end

  # Get the PIV values
  def get_video_piv_intervals()
    defined?(@video_piv_intervals) != nil ? @video_piv_intervals : {}
  end

  def get_video_timelapse_intervals()
    # Same values as photo modes, so just use the first one
    res = @photo_modes.keys()[0]
    return @photo_modes[res][:time_lapse].keys()
  end
=begin
  def get_video_timelapse_res()
    ret = []
    @video_capture_modes.each { |key, val|
      if val.has_key?(:time_lapse) and val[:time_lapse] == true
        ret << key
      end
    }
    return ret
  end
=end

  # Returns looping chapter length (in min) value
  def get_video_looping_intervals(); return @looping_chapter_len.keys(); end

  def get_video_protune_vars
    defined?(@video_protune_vars) != nil ? @video_protune_vars : []
  end

  def get_protune_white_balance
    defined?(@protune_white_balance_values) != nil ? @protune_white_balance_values : []
  end

  def get_protune_color
    defined?(@protune_color_values) != nil ? @protune_color_values : []
  end

  def get_protune_sharpness
    defined?(@protune_sharpness_values) != nil ? @protune_sharpness_values : []
  end

  def get_protune_exposure
    defined?(@protune_exposure_values) != nil ? @protune_exposure_values : []
  end

  def get_video_protune_iso_modes
    defined?(@video_protune_iso_modes) != nil ? @video_protune_iso_modes : []
  end

  def get_video_protune_shutter_speeds
    defined?(@protune_shutter_speeds) != nil ? @protune_shutter_speeds : []
  end

  def get_photo_protune_iso
    defined?(@photo_protune_iso_values) != nil ? @photo_protune_iso_values : []
  end

  def get_photo_protune_iso_min
    defined?(@photo_protune_iso_min_values) != nil ? @photo_protune_iso_min_values : []
  end

  def get_video_protune_iso
    defined?(@video_protune_iso_values) != nil ? @video_protune_iso_values : []
  end

  # Returns true if a given RES/FPS supports PIV
  def video_piv_support?(res=nil, fps=nil, fov=nil)
    ret = defined?(@video_piv_support) != nil ? @video_piv_support : false
    if res != nil and fps != nil
      if fov != nil and @video_capture_modes[res][:fps][fps].has_key?(:piv_fov)
        if @video_capture_modes[res][:fps][fps][:piv_fov].include?(fov)
          ret = true
        else
          ret = false
        end
      elsif @video_capture_modes[res][:fps][fps].has_key?(:piv)
        ret = @video_capture_modes[res][:fps][fps][:piv]
      else
        ret = false
      end
    end
    return ret
  end

  # Default is TRUE so we don't have to go back through all previous cameras
  def video_spot_metering_support?
    !@video_spot_metering_support.nil? ? @video_spot_metering_support : true
  end

  # Returns true or false depending if a give res/fps combination should support eis.
  def video_eis_support?(res, fps)
    @video_capture_modes[res][:fps][fps][:eis] ? true : false
  end

  # Returns true if a given res/fps supports looping
  # FOV is an unused arg, but is included to maintain consistent a function signature
  # with other  XXXX_support? functions for metaprogramming purposes
  # (see test_serial_commands.rb)
  def video_looping_support?(res=nil, fps=nil, fov=nil)
    ret = defined?(@video_looping_support) != nil ? @video_looping_support : false
    if res != nil and fps != nil
      @video_capture_modes[res][:fps][fps].has_key?(:looping) ? ret &= @video_capture_modes[res][:fps][fps][:looping] : ret &= false
    end
    ret
  end

  # Returns true if a given resolution supports video-time-lapse
  # FPS/FOV are unused, but included to maintain consistent a function signature
  # with other  XXXX_support? functions for metaprogramming purposes
  # (see test_serial_commands.rb)
  def video_timelapse_support?(res=nil, fps=nil, fov=nil)
    ret = defined?(@video_timelapse_support) != nil ? @video_timelapse_support : false

    if res != nil
      if @video_timelapse_capture_modes.has_key?(res)
        ret = true
      else
        ret = false
      end
    end
=begin
    if res != nil and fps != nil
      if @video_capture_modes[res][:fps][fps].has_key?(:time_lapse)
        ret &= @video_capture_modes[res][:fps][fps][:time_lapse]
      else
        ret &= false
      end
    end
=end
    return ret
  end

  # Returns true if a given RES/FPS supports the low-light setting. ( set @video_low_light_support = true) only if user can change options via camera and/or app)
  # FOV is an unused arg, but is included to maintain consistent a function signature
  # with other  XXXX_support? functions for metaprogramming purposes
  # (see test_serial_commands.rb)
  def video_low_light_support?(res=nil, fps=nil, fov=nil)
    ret = defined?(@video_low_light_support) != nil ? @video_low_light_support : false
    if res != nil and fps != nil
      @video_capture_modes[res][:fps][fps].has_key?(:low_light) ? ret &= @video_capture_modes[res][:fps][fps][:low_light] : ret &= false
    end
    #    log_warn("No low-light support information found") if ret == nil
    return ret
  end

  # If no arguments specified, returns true if the camera supports ProTune.
  # If RES or RES/FPS specified, returns true if that mode supports ProTune
  # FOV is an unused arg, but is included to maintain consistent a function signature
  # with other  XXXX_support? functions for metaprogramming purposes
  # (see test_serial_commands.rb)
  def video_protune_support?(res=nil, fps=nil, fov=nil)
    ret = defined?(@video_protune_support) != nil ? @video_protune_support : false
    if res != nil and @video_capture_modes[res].has_key?(:protune)
      ret &= @video_capture_modes[res][:protune]
      if fps != nil and @video_capture_modes[res][:fps][fps].has_key?(:protune)
        ret &= @video_capture_modes[res][:fps][fps][:protune]
      end
    end
    return ret
  end

  # Returns true if jello-slayer is available for a give RES/FPS/FOV
  def video_jello_slayer_support?(res, fps, fov)
    # Jello-slayer is OUT for now
    ret = false
    # if res != nil and fps != nil and fov != nil
    #   if @video_capture_modes[res][:fps][fps].has_key?(:jello_slayer)
    #     if @video_capture_modes[res][:fps][fps].has_key?(:jello_slayer_fov)
    #       ret = true if @video_capture_modes[res][:fps][fps][:jello_slayer_fov].include?(fov)
    #     else
    #       ret = @video_capture_modes[res][:fps][fps][:jello_slayer]
    #     end
    #   end
    # end
    return ret
  end

  # Returns the bitrate of a given RES/FPS capture mode
  # pt - true/false (return the protune bitrate)
  def get_bitrate(res, fps, pt="OFF", fov="W")
    if pt == "OFF"
      br = @video_capture_modes[res][:fps][fps][:bitrate]
    elsif @video_capture_modes[res][:fps][fps].has_key?(:pt_bitrate)
      # HD4 has differing protune bitrates depending on res/fps
      br = @video_capture_modes[res][:fps][fps][:pt_bitrate]
      # It's worse than that on HD5. The bitrate varies based on the fov too.
      # When this occurs, the pt_bitrate is a hash of fov => values.
      if br.is_a?(Hash)
        br = br[fov]
      end
    elsif @video_protune_bitrate != nil
      # HD3 has a single protune bitrate
      br = @video_protune_bitrate
    else
      log_error("No bitrate found for res=#{res}/fps=#{fps} (protune=#{pt})")
      br = 0
    end
    return br
  end

  # Return kbps.
  def get_audio_bitrate
    return @audio_bitrate * @audio_channels
  end

  def get_video_timelapse_bitrate(res)
    br = 0
    if @video_timelapse_capture_modes[res].has_key?(:bitrate)
      br = @video_timelapse_capture_modes[res][:bitrate]
    end
    return br
  end

  # A flag if the firmware implementation is such that Video looping is really
  # a setting within the VIDEO mode.  This causes lots of weird things in
  # settings.
  # Affected cameras: Hero3/+, Himalayas, Haleiwa, Rockypoint?
  def looping_is_video_setting?()
    return true if @looping_is_video_setting == true
    return false
  end

  def get_clip_and_save_durations()
    @clip_and_save_durations
  end

  def has_raw_support?
    @has_raw_support
  end

  def has_wdr_support?
    @has_wdr_support
  end

  def has_eis_support?
    @has_eis_support
  end

  def has_awf_support?
    @has_awf_support
  end

  ###############################################################
  # Photo parameter methods
  ###############################################################

  # Get the available photo resolutions
  def get_photo_resolutions(); return @photo_modes.keys(); end

  #Return true if photo spot metering support
  def photo_spot_metering_support?
    defined?(@photo_spot_metering_support) != nil ? @photo_spot_metering_support : false
  end

  #Return true if multi_photo spot metering support
  def multi_photo_spot_metering_support?
    defined?(@multi_photo_spot_metering_support) != nil ? @multi_photo_spot_metering_support : false
  end

  # Get the available SPS (continuous shot) modes for a given photo resolution
  def get_photo_continuous_rates(res=nil)
    res = @photo_modes.keys[0] if res == nil
    @photo_modes[res].has_key?(:sps) ? @photo_modes[res][:sps].keys() : []
  end

  # Get the available burst modes for a given photo resolution
  def get_multi_photo_burst_rates(res=nil);
    res = @photo_modes.keys[0] if res == nil
    @photo_modes[res].has_key?(:burst) ? @photo_modes[res][:burst].keys() : []
  end

  # Get the available time-lapse modes for a given photo resolution
  def get_multi_photo_timelapse_rates(res=nil)
    res = @photo_modes.keys[0] if res == nil
    @photo_modes[res].has_key?(:time_lapse) ? @photo_modes[res][:time_lapse].keys() : []
  end

  # Get the available night-lapse modes for a given photo resolution
  def get_multi_photo_nightlapse_rates(res=nil)
    res = @photo_modes.keys[0] if res == nil
    @photo_modes[res].has_key?(:night_lapse) ? @photo_modes[res][:night_lapse].keys() : []
  end

  # Get the available photo exposure values (if applicable)
  def get_photo_shutter_exposure_intervals()
    defined?(@photo_shutter_exposure) != nil ? @photo_shutter_exposure : []
  end

  # Get the available photo exposure values (if applicable)
  def get_multi_shutter_exposure_intervals()
    defined?(@multi_shutter_exposure) != nil ? @multi_shutter_exposure : []
  end

  def get_photo_protune_vars
    defined?(@photo_protune_vars) != nil ? @photo_protune_vars : []
  end

  def get_multi_photo_protune_vars
    defined?(@multi_photo_protune_vars) != nil ? @multi_photo_protune_vars : []
  end

  # Returns true if the camera supports photo continuous (sps)
  def photo_continuous_support?(res=nil)
    ret = defined?(@photo_continuous_support) != nil ? @photo_continuous_support : false
    if res != nil
      ret &= @photo_modes[res].has_key?(:sps)
    end
    ret
  end

  def photo_night_support?()
    defined?(@photo_night_support) != nil ? @photo_night_support : false
  end

  def photo_protune_support?
    defined?(@photo_protune_support) != nil ? @photo_protune_support : false
  end

  def multi_photo_nightlapse_support?(res=nil)
    ret = defined?(@multi_photo_nightlapse_support) != nil ? @multi_photo_nightlapse_support : false
    if res != nil
      ret &= @photo_modes[res].has_key?(:night_lapse)
    end
    ret
  end

  def multi_photo_protune_support?
    defined?(@multi_photo_protune_support) != nil ? @multi_photo_protune_support : false
  end

  def get_capabilities; return @capabilities; end

  # General useful methods

  # Returns true if a given resolution aspect ratio is fullscreen
  def is_fullscreen?(res)
    ar = @video_capture_modes[res][:aspect_ratio]
    ar_f = ar.split(":")[0].to_f / ar.split(":")[1].to_f
    log_verb("Is fullscreen?  Aspect ratio = #{ar} (%0.2f)" %ar_f)
    return ar_f <= (4.0/3.0)
  end

  # Get the lowest bitrate capture mode on the camera.
  # Useful for running looping tests with smaller SD cards
  def get_lowest_bitrate_mode()
    min = ret_fps = ret_res = nil
    get_video_resolution().each { |res|
      get_fps_ntsc(res).each { |fps|
        br = @video_capture_modes[res][:fps][fps][:bitrate]
        if min == nil or br < min
          min = br
          ret_res = res
          ret_fps = fps
        end
      }
    }
    return ret_res, ret_fps
  end

  #AVC profile level. see ticket 15033, 15031.
  def get_profile_level(res, fps, pt)
    width = @video_capture_modes[res][:width].to_i
    height = @video_capture_modes[res][:height].to_i
    bitrate = get_bitrate(res, fps, pt)
    log_info(
    "Get AVC level for #{width}x#{height} #{fps} FPS, br=#{bitrate} Mbps")
    return get_profile_level_raw(width, height, fps, bitrate)
  end

  def get_lrv_profile_level(res, fps, pt="OFF")
    width = get_lrv_width(res, fps)
    height = get_lrv_height(res, fps)
    lrv_fps = get_lrv_fps(res, fps)
    bitrate = get_lrv_bitrate(res, fps)
    log_info(
    "Get AVC level for #{width}x#{height} #{lrv_fps} FPS, br=#{bitrate} Mbps")
    return get_profile_level_raw(width, height, lrv_fps, bitrate)
  end

  # Returns the AVC 'HIGH' Profile level for a given width, height, fps, and bitrate
  def get_profile_level_raw(width, height, fps, bitrate)
    maxFS_level = maxMBPS_level = maxBR_level = 0
    maxBR = bitrate * 1000000 * 1.1
    maxFS = width * height / 256
    maxMBPS = (maxFS * fps.to_f).to_i

    # Get level for the decoding speed (max macroblocks per second)
    [ [13, 11880], [21, 19800],  [22, 20250],  [30, 40500],  [31, 108000], [32, 216000],
      [40, 245760], [41, 245760], [42, 522240], [50, 589824], [51, 983040],
    ].each { |level, mbps|
      if mbps >= maxMBPS.to_i
        maxMBPS_level = level
        break
      end
    }

    # Get level for frame-size
    [ [13, 396], [21, 792], [22, 1620], [30, 1620], [31, 3600], [32, 5120],
      [40, 8192], [41, 8192], [42, 8704], [50, 22080], [51, 36864]
    ].each { |level, frame_size|
      if frame_size >= maxFS.to_i
        maxFS_level = level
        break
      end
    }

    # Get level for max bit-rate
    # High profile is 25% higher
    if @avc_profile_level == "HIGH"
      bitrate_levels = [
        [13, 960000],
        [20, 2500000],
        [21, 5000000],
        [22, 5000000],
        [30, 12500000],
        [31, 17500000],
        [32, 25000000],
        [40, 25000000],
        [41, 62500000],
        [42, 62500000],
        [50, 168750000],
        [51, 300000000]]
    else  # Baseline/Extended/Main profile
      bitrate_levels = [
        [13, 768000],
        [20, 2000000],
        [21, 4000000],
        [22, 4000000],
        [30, 10000000],
        [31, 14000000],
        [32, 20000000],
        [40, 20000000],
        [41, 50000000],
        [42, 50000000],
        [50, 135000000],
        [51, 240000000]]
    end
    bitrate_levels.each {|key, value|
      if value >= maxBR.to_i
        maxBR_level = key
        break
      end
    }

    log_info("AVC level MBlk/s=%s (%s), FrameSize=%s (%s), MaxBitRate=%0.2f (%s)" \
    %[maxMBPS, maxMBPS_level, maxFS, maxFS_level, maxBR/1000000, maxBR_level])
    return [maxMBPS_level, maxFS_level, maxBR_level].max
  end

  # See if the camera is alive and reboot if not.
  # Return status, msg.
  # status is true on success, false on fail.
  # msg holds information on pass/fail reason.
  def detect_crash_and_reboot()
    # Check if camera is still alive
    if not is_alive?
      log_warn("Camera has crashed!! Resetting board.")
      if reset_board == false
        log_error("Reset unsuccessful.  Exiting.")
        exit 1
      end
      return false, "Camera unresponsive"
    end
    return true, "Camera is alive"
  end

  # Abstract methods that should be overridden in sub-classes
  def abstract()
    e = NoMethodError.new("Abstract method not overridden in sub-class!")
    e.set_backtrace(caller())
    raise e
  end

  # Set the camera capture mode (VIDEO|SINGLE|CONTINUOUS|NIGHT
  # |BURST|TIME_LAPSE|NIGHT_LAPSE).
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_capture_mode(mode); abstract; end

  ###########################################################################
  # VIDEO METHODS
  ###########################################################################
  # Sets the default sub-mode for multi-shot mode
  def set_video_def_sub_mode(x); abstract; end

  # Set the video resolution.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_resolution(x); abstract; end

  # Set the video FPS.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_fps(x); abstract; end

  # Set the video FOV.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_fov(x); abstract; end

  # Set the video time-lapse interval
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_timelapse(x); abstract; end

  # Set the picture-in-video interval.
  # (caller should check that PIV is supported for given RES/FPS first)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_piv(x); abstract; end

  # Set the video looping interval
  # (caller should check that looping is supported for given RES/FPS first)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_looping(x); abstract; end

  # Turns automatic low-light adaptable FPS ON or OFF
  # (caller should check that low_light is supported for given RES/FPS first)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_low_light(x); abstract; end

  # Sets spot metering ON or OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_spot_metering(x); abstract; end

  # Turns video ProTune ON/OFF on cameras that support separate
  # video/photo ProTune settings.  Otherwise sets global ProTune ON/OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune(x); abstract; end

  # Set the ProTune white-balance
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_white_balance(x); abstract; end

  # Set the ProTune color
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_color(x); abstract; end

  # Set the ProTune ISO setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_iso(x); abstract; end

  # Set the ProTune ISO mode setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_iso_mode(x); abstract; end

  # Set the ProTune manual shutter speed setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_shutter_speed(x); abstract; end

  # Set the ProTune sharpness setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_sharpness(x); abstract; end

  # Set the ProTune exposure setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_protune_exposure(x); abstract; end

  # Set the video capture mode (NTSC/PAL, RES, FPS, FOV)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_format(vm, r, fs, fv); abstract; end

  # Sets the Electronic Image Stabilization  setting (ON, OFF)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_eis(x); abstract; end

  # Sets the Audio Wind Filter setting (ON, OFF)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_video_awf(x); abstract; end

  # Starts video capture.  # retries as an optional argument.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def start_capture(retries=2); abstract; end

  # Stops video capture.  # retries as an optional argument.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def stop_capture(retries=2); abstract; end

  # Sets MODE, ProTune, RES, FPS, FOV and captures a video of length
  # 'duration' and trying 'retries' times.
  # Returns result (true/false) and msg (explaining result)
  # On success 'msg' will hold the video filename
  def capture_video(res, fps, fov, duration, retries); abstract; end

  ###########################################################################
  # PHOTO METHODS
  ###########################################################################
  # Sets the default sub-mode for multi-shot mode
  def set_photo_def_sub_mode(x); abstract; end

  # Sets the photo resolution
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_resolution(x); abstract; end

  # Sets the continuous shooting setting (SPS, shots-per-second)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_continuous(x); abstract; end

  # Sets the photo exposure value (outside of ProTune settings)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_shutter_exposure(x); abstract; end

  # Sets the photo SPOT metering to ON or OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_spot_metering(x); abstract; end

  # Turns photo ProTune ON/OFF on cameras that support separate
  # video/photo ProTune settings.  Otherwise sets global ProTune ON/OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune(x); abstract; end

  # Set the ProTune white-balance setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune_white_balance(x); abstract; end

  # Set the ProTune color setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune_color(x); abstract; end

  # Set the ProTune ISO setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune_iso(x); abstract; end

  # Set the ProTune ISO MIN setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune_iso_min(x); abstract; end

  # Set the ProTune sharpness setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune_sharpness(x); abstract; end

  # Set the ProTune exposure setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_photo_protune_exposure(x); abstract; end

  # Set the RAW image setting.
  # Returns res (true/false) and msg (explaining result).
  def set_photo_raw(x); abstract; end

  # Set the Wide Dynamic Range setting.
  # Returns res (true/false) and msg (explaining result).
  def set_photo_wdr(x); abstract; end

  # Capture a photo in single shot mode
  # Returns result (true/false) and msg (explaining result)
  def capture_photo_single(res, sps, retries); abstract; end

  # Capture photos in continuous shooting mode
  # Returns result (true/false) and msg (explaining result)
  def capture_photo_continuous(res, rate, duration, retries); abstract; end

  # Capture a photo in night_photo mode
  # Returns result (true/false) and msg (explaining result)
  def capture_photo_night(res, retries); abstract; end

  ###########################################################################
  # MULTI-SHOT METHODS
  ###########################################################################
  # Sets the default sub-mode for multi-shot mode
  def set_multi_def_sub_mode(x); abstract; end

  # Sets the photo resolution for multi-shot modes
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_photo_resolution(x); abstract; end

  # Set the burst value.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_photo_burst(burst); abstract; end

  # Set the time-lapse value.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_photo_timelapse(pes); abstract; end

  # Set the night-lapse value.
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_photo_nightlapse(x); abstract; end

  # Sets the photo SPOT metering to ON or OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_spot_metering(x); abstract; end

  # Sets the shutter exposure value (night-lapse)
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_shutter_exposure(x); abstract; end

  # Turns photo ProTune ON/OFF on cameras that support separate
  # video/photo ProTune settings.  Otherwise sets global ProTune ON/OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune(x); abstract; end

  # Set the ProTune white-balance setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune_white_balance(x); abstract; end

  # Set the ProTune color setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune_color(x); abstract; end

  # Set the ProTune ISO setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune_iso(x); abstract; end

  # Set the ProTune ISO MIN setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune_iso_min(x); abstract; end

  # Set the ProTune sharpness setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune_sharpness(x); abstract; end

  # Set the ProTune exposure setting
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_protune_exposure(x); abstract; end

  # Turns multi-shot capture ON or OFF
  # Returns [result (true/false), msg (reason)].
  # Result is true if successful, false if not.
  def set_multi_capture(x); abstract; end

  ###########################################################################
  # Additional Capture Methods
  ###########################################################################

  # Capture a burst
  # Returns result (true/false) and msg (explaining result)
  def capture_multi_photo_burst(res, burst_mode, retries); abstract; end

  # Capture a time-lapse
  # Returns result (true/false) and msg (explaining result)
  def capture_multi_photo_timelapse(res, pes_interval, min_photos, min_length, retries)
    abstract
  end

  # Capture a night-lapse
  # Returns result (true/false) and msg (explaining result)
  def capture_photo_nightlapse(res, pes_interval, min_photos, min_length, retries)
    abstract
  end

  # Capture a looping video
  # Returns result (true/false) and msg (explaining result)
  def capture_looping(vm, res, fps, fov, loo, duration, setonly=false, orient=nil, ll=nil, spot=nil)
    abstract
  end

  ###########################################################################
  # Camera Setup METHODS
  ###########################################################################
  # Set the default capture mode
  def set_default_capture_mode(x); abstract; end

  # Set on-screen display ON or OFF
  def set_osd(x); abstract; end

  # Set number of LEDs to 0, 2, or 4
  def set_led(x); abstract; end

  # Set the beep volume
  def set_beep_sound(x); abstract; end

  # Set the camera orientation to AUTO, UP, or DOWN
  def set_orientation(x); return set(:setup_orientation, x); end

  # Set LCD auto-off (sleep-timer)
  def set_lcd_auto_off(x); abstract; end

  ###########################################################################
  # Media-List METHODS
  ###########################################################################
  # Returns a list of all files under DCIM on the SD card
  def get_medialist(); abstract; end

  # Returns the name of the last video encoded.  Nil on failure
  def get_last_video(); abstract; end

  # Downloads a given file_name (e.g. GOPRO1234.MP4) to directory 'to_dir'
  # Returns result (true/false) and msg (explaining result)
  # On success 'msg' will hold local full path to the file
  def download_media(file_name, to_dir); abstract; end

  # Downloads all media to the directory 'to_dir'
  # Returns result (true/false) and msg (explaining result)
  def download_all_media(to_dir, stop_after=nil); abstract; end

  ###########################################################################
  # Testing Utility methods
  ###########################################################################
  # Returns true if the camera is still alive, false if not
  def is_alive?(); abstract; end

  # HARD reset (power-cut) Returns true on success, false if not
  def reset_board(); abstract; end

  # SOFT reset (power-cut) Returns true on success, false if not
  def do_reset(); abstract; end

  # Returns the minutes available for video recording at
  # the current RES/FPS/FOV
  def get_mins_avail(); abstract; end

  # Returns the number of images remaining that can be taken.
  def get_photos_avail(); abstract; end

  # Returns the number of videos on the camera
  # (may span multiple files on the SD card)
  def get_n_videos(); abstract; end

  # Returns the number of photos on the camera
  # (may span multiple files on the SD card)
  def get_n_photos(); abstract; end

  # Deletes a single file on the camera
  # Returns true, status_msg on success
  # Returns false, status_msg on failure
  def delete_single_file(f); abstract; end

  # Deletes all the media on the camera
  # Returns true, status_msg on success
  # Returns false, status_msg on failure
  def delete_all_media(); abstract; end

  # Returns the Wi-Fi SSID of the camera
  def get_wifi_ssid(); abstract; end

  ###########################################################################
  # PUSHY methods
  ###########################################################################
  def pushy_power()
    log_debug("Pressing P button")
    @pushy.push(@pushy.pButton, 1)
  end

  def pushy_shutter()
    log_debug("Pressing S button")
    @pushy.push(@pushy.sButton, 1)
  end

  def pushy_wifi()
    log_debug("Pressing W button")
    @pushy.push(@pushy.wButton, 1)
  end

  def pushy_hard_reset()
    @pushy.push(@pushy.pButton, 10)
    sleep 2
    # Don't turn back on in the case of Rocky
    if ["ROCKYPOINT"].include?(@name) == false
      @pushy.push(@pushy.pButton, 1)
      sleep 5
    end
  end

  def pushy_enable_wifi()
    if ["ROCKYPOINT"].include?(@name) == true
      @pushy.push(@pushy.wButton, 1)
      sleep 3
      @pushy.push(@pushy.wButton, 1)
      sleep 1
      # There is 1 more W button press for FW 01.01.35 and on
      # since the Wi-Fi menu moved to after the settings meny
      if @build >= "01.35"
        @pushy.push(@pushy.wButton, 1)
        sleep 1
      end
      @pushy.push(@pushy.sButton, 1)
      sleep 5
    else
      @pushy.push(@pushy.wButton, 4)
      sleep 5
    end
  end
end # end class Camera

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  # c = get_serial_camera("PIPE", "/dev/ttyUSB0")
  # p c.get_bitrate("4K", 30)
  # p c.get_bitrate("1080", 60, false)
  # p c.get_bitrate("1080", 60, true)
  c = get_wifi_camera("10.5.5.9", "goproher")
  p c.build

  #puts c.get_multek
  # puts c.get_low_bitrate_mode
  #  JSON.parse(c.get_medialist().body)
  #  while true
  #    puts c.get_multek
  #    break
  #  end
end
