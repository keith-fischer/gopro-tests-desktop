# Holds metadata definitions used by both Camera and Host classes
# to ensure they match up for tests
# Values are filled in within the Camera and Host classes
class VideoMetadata
  attr_accessor \
    :audio_channels, 
    :audio_codec, 
    :audio_sample_rate,
    :audio_bitrate,
    :aspect_ratio,
    :video_bitrate, 
    :colorspace, 
    :creation_time,
    :frame_rate, 
    :has_timecode,
    :timecode,
    :height, 
    :valid, 
    :width, 
    :video_codec,
    :profile_level
    
  def initialize
    @audio_channels     = nil
    @audio_codec        = nil
    @audio_sample_rate  = nil
    @audio_bitrate      = nil
    @aspect_ratio       = nil
    @video_bitrate      = nil
    @colorspace         = nil
    @creation_time      = nil
    @frame_rate         = nil
    @has_timecode       = nil
    @timecode           = nil
    @height             = nil
    @valid              = nil
    @width              = nil
    @video_codec        = nil
    @profile_level      = nil
  end

  # A method to determine if any fields of the metadata have changed from nil.
  def has_values?
    return true if @audio_channels    != nil
    return true if @audio_codec       != nil
    return true if @audio_sample_rate != nil
    return true if @audio_bitrate     != nil
    return true if @aspect_ratio      != nil
    return true if @video_bitrate     != nil
    return true if @colorspace        != nil
    return true if @creation_time     != nil
    return true if @frame_rate        != nil
    # This could be set to false even if no metadata is found.
    #return false if @has_timecode      != nil
    return true if @timecode          != nil
    return true if @height            != nil
    return true if @valid             != nil
    return true if @width             != nil
    return true if @video_codec       != nil
    return true if @profile_level     != nil
    return false
  end # is_anything_set?

  def bitrate
    puts("WARN : Metadata.bitrate is no longer used! Returning value of video_bitrate instead.")
    @video_bitrate
  end

  def bitrate=(val)
    puts("WARN : Metadata.bitrate is no longer used! Assigning value to video_bitrate instead.")
    @video_bitrate = val
  end
end

if __FILE__ == $0
  meta = VideoMetadata.new()
  meta.audio_channels = 2
  meta.width = 1080
  meta.instance_variables.each { |name|
    value = meta.instance_variable_get("#{name}")
    puts "#{name} = #{value}"
  }
end
