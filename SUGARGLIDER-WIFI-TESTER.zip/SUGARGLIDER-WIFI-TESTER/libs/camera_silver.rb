require_relative 'camera'

module Silver
  def init
    @name = "SILVER"
    log_verb("Instantiating #{name} camera")
    @remote_api = 1  #remote smarty api version 1 (ie http://10.5.5.9:80/camera/TI?t=goprohero1&p=%01)

    @audio_channels         = 2
    @audio_codec            = "aac"
    @audio_sample_rate      = 48000
    @audio_bitrate          = 64    # in kbps per channel.
    @avc_profile_level      = "MAIN"
    # Support for changing preview bitrate via BV command
    @chg_prev_br_support    = false
    # Support for changing preview resolution via BV command
    @chg_prev_res_support   = false
    @colorspace             = "yuv420p"
    @video_protune_bitrate  = 35 # Unsupported
    @video_codec            = "h264"
    @video_lrv_bitrate      = 0.7
    @total_lrv_bitrate      = 0.8  # Mbps, (includes video + audio + data)

    #video
    @video_protune_support  = true
    @video_looping_support  = true

    #share video/photo/multi_photo protune value. Split where necessary
    @protune_white_balance_values = ["AUTO", "3000K", "5500K", "6500K", "RAW"]
    @protune_color_values         = [nil]
    @protune_sharpness_values     = [nil]
    @protune_exposure_values      = [nil]
    @photo_protune_iso_values     = [nil]
    @video_protune_iso_values     = [nil]

    @video_protune_vars = {
      :video_pt_color   => false,
      :video_pt_iso     => false,
      :video_pt_sharp   => false,
      :video_pt_ev      => false,
      :video_pt_wb      => true
    }

    @capabilities = { #cc
      :has_camera_roll      => true,
      :has_ota              => false,  #over the air firmware update
      :has_ltp              => true,
      :has_3D               => false,
      :has_ccl              => false,   #camera control library
    }

    @defaults = {
      :locate_ll            => "OFF",
      :setup_video_format   => "NTSC",
      :video_resolution     => "960",
      :video_fps            => "48",
      :video_low_light      => "OFF", #do not delete even low light isn't support
      :video_looping        => "OFF",
      :photo_resolution     => "11WIDE",
      :multi_shot_timelapse => "0.5",
      :setup_default_mode   => "VIDEO",
      :setup_orientation    => "OFF",
      :video_spot_metering  => "OFF",
      :setup_led            => "4",
      :setup_beep           => "100",
      :setup_osd            => "ON",
      :mode_cm              => "VIDEO",
    }

    @setup = {
      :mode_cm                => "VIDEO",
      :setup_orientation      => "UP",
      :setup_led              => "4",
      :setup_beep             => "100",
      :setup_osd              => "ON",
    }

    # Commands that don't have prerequisites
    # Wifi commands to test
    @cmds = [
      :setup_beep,
      :setup_default_mode,
      :setup_led,
      :video_spot_metering,
      :setup_orientation,
      :setup_video_format,
      :locate_ll,
      :mode_cm,
    ]

    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    @video_capture_modes = {
      "1080"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :protune => true,
      :fps    => {
      "24"  => {
      :fov      => ["W", "M", "N"],
      :fov_protune => ["W", "M"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 15,
      :thm      => true,
      :lrv_fps  => 23.98,
      :frame_rate => 23.98,
      :looping  => true,
      },
      "25"  => {
      :fov      => ["W", "M", "N"],
      :fov_protune => ["W", "M"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 25,
      :looping  => true,
      },
      "30"  => {
      :fov      => ["W", "M", "N"],
      :fov_protune => ["W", "M"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 29.97,
      :looping  => true,
      }
      } #fps
      }, # end 1080
      "960"  =>  {
      :width  => 1280,
      :height => 960,
      :aspect_ratio => "4:3",
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :protune => true,
      :fps    => {
      "25"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 25,
      :looping  => true,
      },
      "30"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 29.97,
      :looping  => true,
      },
      "48"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 23.98,
      :frame_rate => 47.95,
      :looping  => true,
      },
      "50"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 50,
      :looping  => true,
      }
      } # end fps
      }, # end 960
      "720"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :protune => true,
      :fps    => {
      "25"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 25,
      :looping  => true,
      :protune  => false
      },
      "30"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 20,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 29.97,
      :looping  => true,
      :protune  => false
      },
      "50"  => {
      :fov      => ["W"],
      :ntsc     => false,
      :pal      => true,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 25,
      :frame_rate => 50,
      :looping  => true,
      },
      "60"  => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => false,
      :bitrate  => 30,
      :thm      => true,
      :lrv_fps  => 29.97,
      :frame_rate => 59.94,
      :looping  => true,
      }

      } # end fps
      }, # end 720
      "WVGA"  =>  {
      :width  => 848,
      :height => 480,
      :aspect_ratio => "53:30",
      :protune => false,
      :fps    => {
      "120" => {
      :fov      => ["W"],
      :ntsc     => true,
      :pal      => true,
      :bitrate  => 30,
      :thm      => false,
      :lrv_fps  => false,
      :frame_rate => 119.88,
      :looping  => false,
      }
      } # end fps
      } # end WVGA
    } # end @video_capture_modes

    # Photo Modes
    @photo_modes = {
      "5MED" => {
      :width        => 2592,
      :height       => 1944,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 5MED
      "5WIDE" => {
      :width        => 2592,
      :height       => 1944,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 }
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 5WIDE
      "8MED" => {
      :width        => 3200,
      :height       => 1920,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 }
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      }, # end 5WIDE
      "11WIDE" => {
      :width        => 3840,
      :height       => 1920,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 }
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      } # end 11WIDE
    } # end PHOTO mode

    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 15,
      "120"   => 15,
      "MAX" => 15,
    }

    @screens = {
      :wireless_settings => [ \
      "0000000000000000000f000000000000000f1fffffffffffff8f3fffffffffffffcf3" + \
      "fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffff" + \
      "ffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3ffffffffff" + \
      "fffcf3f1c6eeeec618fcf3eebaeeedbaf77cf"]
    }

  end # end initialize

end #module
