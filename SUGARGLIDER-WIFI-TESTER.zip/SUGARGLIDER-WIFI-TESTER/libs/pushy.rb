#######################################################################################
### Sugarglider interface for PUSHY - An automated camera button pusher
### based on the work of Juanita DeSouza, GoPro Automation QAE intern, Summer 2015
#######################################################################################
### Description: The functions provided will allow interfacing with the USB 
### software-controlled relay (Phidgets InterfaceKit 0/0/4 board)
####################################################################################### 
### Linux Software requirements: 
### - Phidgets driver
### 	- sudo apt-get install libusb-1.0-0-dev
### 	- cd /tmp
### 	- wget -O phi.tgz http://www.phidgets.com/downloads/libraries/libphidget.tar.gz
### 	- tar -xf phi.tgz
### 	- cd libphidget-2.1.8.20150410
### 	- ./configure && make && sudo make install
### - Ruby gems
### 	- gem install ffi phidgets-ffi
### - UDEV rules
###   - sudo vim /etc/udev/rules.d/51-phidget.rules
###   - For Ubuntu:  ATTRS{idVendor}=="06c2",ATTRS{idProduct}=="0040",MODE="0666"
###   - For Raspberry Pi: ATTRS{idVendor}=="06c2", ATTRS{idProduct}=="0040", 
###                       SUBSYSTEMS=="usb", ACTION=="add", MODE="0666", GROUP="plugdev" 
###   - sudo service udev restart
#######################################################################################
### Setup instructions:  
### - Connect phidget to host computer via USB
### - Test with 'ruby pushy.rb [P output] [S output] [W output]'
### - Example:  If outputs 0, 1, and 2 are connected to POWER, SHUTTER, WIFI buttons
###             ruby pushy.rb 0 1 2
#######################################################################################
### Programming examples:  See unit tests at bottom of file 
#######################################################################################
begin
  require 'phidgets-ffi'
rescue LoadError, RuntimeError => e 
  puts "Phidgets gem not found.  Pushy will be unavailable." + \
    "  Install with 'gem install ffi phidgets-ffi'"
end
require_relative 'log_utils'

class Pushy
  include LogUtils
  attr_accessor :pButton, :sButton, :wButton
  attr_reader :success

  # Filter by serial_number if multiple boards are connected
  # Use server_id and password to connect across a network
  # opts = {:serial_number => 99999, :server_id => ‘myserver’, :password => nil}
  def initialize(out_p, out_s, out_w, opts=nil, &block)
    @success = false
    log_debug("Library Version: #{Phidgets::FFI.library_version}")
    log_debug("Instantiating Phidget")
    if [out_p, out_s, out_w].include?(nil)
      log_warn("Not initializing powerstrip due to NIL arg(s)")
      log_warn("(out_p=#{out_p}, out_s=#{out_s}, out_w=#{out_w})")
      raise RuntimeError
    end
    begin
      @ifkit = Phidgets::InterfaceKit.new(opts)
      @ifkit.wait_for_attachment(3000)  # ms

      @ifkit.on_error do |device, obj, code, description|
        log_warn("Phidgets Error #{code}: #{description}")
      end
      @was_closed = false
      log_debug("Class: #{@ifkit.device_class}")
      log_debug("Id: #{@ifkit.id}")
      log_debug("Serial number: #{@ifkit.serial_number}")
      log_debug("Version: #{@ifkit.version}")

      # Map buttons to outputs on the Phidgets board
      # Remember for ROCKYPOINT out_p = out_s
      @pButton, @sButton, @wButton = out_p.to_i, out_s.to_i, out_w.to_i
      log_verb("Mapping P_BUTTON=%s, S_BUTTON=%s, W_BUTTON=%s"\
        %[@pButton, @sButton, @wButton])
    rescue Phidgets::Error::Timeout
      raise("Timed out waiting for attach")
    rescue Phidgets::Error, StandardError => e
      raise("Caught error instantiating Pushy: #{e.to_s}")
    end

    @ifkit.outputs[0].state = false
    @ifkit.outputs[1].state = false
    @ifkit.outputs[2].state = false
    @ifkit.outputs[3].state = false
    @success = true
    log_info("Phidget %s (S/N %s) instantiated successfully." \
      %[@ifkit.id, @ifkit.serial_number])
    if block_given?
      instance_eval(&block)
      @ifkit.close() if @was_closed == false
    end
  end

  # Push button 'b' for 't' seconds.  Blocking call.
  def push(b, t)
    log_debug("Setting output #{b} to 'true' for #{t}s")
    @ifkit.wait_for_attachment(1000)
    @ifkit.outputs[b].state = true
    sleep t
    @ifkit.wait_for_attachment(1000)
    @ifkit.outputs[b].state = false
  end

  def close()
    begin
      @ifkit.wait_for_attachment(1000)
      @ifkit.outputs[0].state = false
      @ifkit.wait_for_attachment(1000)
      @ifkit.outputs[1].state = false
      @ifkit.wait_for_attachment(1000)
      @ifkit.outputs[2].state = false
      @ifkit.wait_for_attachment(1000)
      @ifkit.outputs[3].state = false
    rescue
      log_warn("Caught error #{e.to_s} setting all outputs to false.")
    end
    begin
      @ifkit.close()
    rescue StandardError => e
      log_warn("Caught error #{e.to_s} closing phidget.")
    ensure
      @was_closed = true
    end
  end # end close()

end # end Pushy

def quick_test()
  # Basic connection and unit test here
  $LOGLEVEL = $LL_DEBUG
  puts "Non-block version"
  p = Pushy.new(0, 1, 2)
  if p.success == true
    p.push(p.pButton, 1)
    sleep 1
    p.push(p.sButton, 1)
    sleep 1
    p.push(p.wButton, 1)
    sleep 1
    p.close()  # MUST remember to close!
  end
  puts "DONE!"

  puts "Block version"
  Pushy.new(0, 1, 2) { |p|
    break if p.success == false
    p.push(p.pButton, 1)
    sleep 1
    p.push(p.sButton, 1)
    sleep 1
    p.push(p.wButton, 1)
    sleep 1
    # No need to close(), but okay if you accidentally do.
  }
  puts "DONE!"
end

# Run through the first 3 modes and capture media
def hawaii_demo(cycles=10)
  p = Pushy.new(0, 1, 2)
  return if p.success != true
  cycles.times { |n|
    puts "Demo cycle #{n}"
    p.push(p.pButton, 1) # Power on
    sleep 5
    p.push(p.sButton, 1) # Capture video
    sleep 10
    p.push(p.sButton, 1)
    sleep 3
    p.push(p.pButton, 1) # Photo mode
    sleep 3
    p.push(p.sButton, 1) # Capture photo
    sleep 3
    p.push(p.pButton, 1) # Burst mode
    sleep 3
    p.push(p.sButton, 1) # Capture burst
    sleep 15
    p.push(p.pButton, 4) # Power off
    sleep 10
  }
end

def rp_demo(cycles=10)
  p = Pushy.new(0, 0, 1)
  return if p.success != true
  cycles.times { |n|
    puts "Demo cycle #{n}"
    p.push(p.pButton, 1)
    sleep 20
    p.push(p.pButton, 1)
    sleep 10
    p.push(p.pButton, 4)
    sleep 20
    p.push(p.pButton, 1)
    sleep 10
  }
end

if __FILE__ == $0
  # quick_test()
  hawaii_demo()
  # rp_demo()
end

