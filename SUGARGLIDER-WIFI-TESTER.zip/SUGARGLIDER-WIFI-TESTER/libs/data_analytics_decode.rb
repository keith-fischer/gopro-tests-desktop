module Data_analytics_decode
  def decode_data_log_version_major(b);     return b.hex; end
  def decode_data_log_version_minor(b);     return b.hex; end
  def decode_data_log_version_revision(b);  return b.hex; end
  def decode_camera_model(b);               return b.hex; end
  def decode_camera_fw_major(b);            return b.hex; end
  def decode_camera_fw_minor(b);            return b.hex; end
  def decode_camera_fw_revision(b);         return b.hex; end
  def decode_video_mins_available_msb(b);   return b.hex; end
  def decode_video_mins_available_lsb(b);   return b.hex; end
  def decode_videos_on_card_msb(b);         return b.hex; end
  def decode_videos_on_card_lsb(b);         return b.hex; end
  def decode_photos_on_card_msb(b);         return b.hex; end
  def decode_photos_on_card_lsb(b);         return b.hex; end
  def decode_photos_available_msb(b);       return b.hex; end
  def decode_photos_available_lsb(b);       return b.hex; end

  def decode_flag_1(p)
    on = []
    p = p.hex
    on << "BOSS_READY"        if (p >> 7) & 0x01 == 1
    on << "LOCATE"            if (p >> 6) & 0x01 == 1
    on << "PAL"               if (p >> 5) & 0x01 == 1
    on << "NTSC"              if (p >> 5) & 0x01 == 0
    on << "ON_SCREEN_DISPLAY" if (p >> 4) & 0x01 == 1
    on << "QUICK_CAPTURE"     if (p >> 3) & 0x01 == 1
    on << "ORIENT_DOWN"       if (p >> 2) & 0x01 == 1
    on << "ORIENT_UP"         if (p >> 2) & 0x01 == 0
    on << "ORIENT_AUTO"       if (p >> 2) & 0x01 == 0 # For RKPT
    on << "VIDEO_LIVE_FEED"   if (p >> 1) & 0x01 == 1
    on << "PREVIEW_ACTIVE"    if (p >> 0) & 0x01 == 1
    on.join(" / ")
  end

  def decode_flag_2(p)
    on = []
    p = p.hex
    on << "PROTUNE_COLOR"     if (p >> 7) & 0x01 == 1
    on << "LOW_LIGHT"         if (p >> 6) & 0x01 == 1
    on << "CANCEL_OTA_UPDATE" if (p >> 5) & 0x01 == 1
    on << "OTA_FW_UPDATE"     if (p >> 4) & 0x01 == 1
    on << "SD_CARD_ERROR"     if (p >> 3) & 0x01 == 1
    on << "PREVIEW_AVAILABLE" if (p >> 2) & 0x01 == 1
    on << "PROTUNE_ON"        if (p >> 1) & 0x01 == 1
    on << "PROTUNE_OFF"       if (p >> 1) & 0x01 == 0
    on << "CAMERA_BUSY"       if (p >> 0) & 0x01 == 1
    on.join(" / ")
  end

  def decode_flag_3(p)
    on = []
    p = p.hex
    on << "FORMAT_MM:HH"            if (p >> 7) & 0x01 == 1
    on << "FORMAT_HH:MM"            if (p >> 7) & 0x01 == 0
    on << "OVER_TEMP_SHUTDOWN"      if (p >> 6) & 0x01 == 1
    on << "3D_CAMERAS_INCOMPATIBLE" if (p >> 5) & 0x01 == 1
    on << "3D_READY"                if (p >> 4) & 0x01 == 1
    on << "BOMBIE_ATTACHED"         if (p >> 3) & 0x01 == 1
    on << "LCD_ATTACHED"            if (p >> 2) & 0x01 == 1
    on << "BROADCASTING"            if (p >> 1) & 0x01 == 1
    on << "UPLOADING"               if (p >> 0) & 0x01 == 1
    on.join(" / ")

  end

  def decode_flag_4(p)
    on = []
    p = p.hex
    on << "RESERVED"                      if (p >> 7) & 0x01 == 1
    on << "RESERVED"                      if (p >> 6) & 0x01 == 1
    on << "RESERVED"                      if (p >> 5) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 4) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_LOW"         if (p >> 2) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_MED"         if (p >> 2) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_HIGH"        if (p >> 2) & 0x03 == 0
    on << "PROTUNE_GAIN"                  if (p >> 0) & 0x03 == 1
    on.join(" / ")
  end

  def decode_flag_4_rpv00(p)
    on = []
    p = p.hex
    on << "RESERVED"                      if (p >> 7) & 0x01 == 1
    on << "RESERVED"                      if (p >> 6) & 0x01 == 1
    on << "RESERVED"                      if (p >> 5) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 4) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_OFF"         if (p >> 2) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_ON"          if (p >> 2) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_UNUSED"      if (p >> 2) & 0x03 == 0
    on << "PROTUNE_GAIN"                  if (p >> 0) & 0x03 == 1
    on.join(" / ")
  end

  # Protune settings flag for PHOTO mode(s)
  # Also used for MULTI_SHOT ProTune decode (flag_6) because they are exactly the same
  def decode_flag_5(p)
    on = []
    p = p.hex
    on << "RESERVED_BIT_7"                if (p >> 7) & 0x01 == 1
    on << "RESERVED_BIT_6"                if (p >> 6) & 0x01 == 1
    on << "RESERVED_BIT_5"                if (p >> 5) & 0x01 == 1
    on << "PROTUNE_SHARPNESS_LOW"         if (p >> 3) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_MED"         if (p >> 3) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_HIGH"        if (p >> 3) & 0x03 == 0
    on << "PROTUNE_COLOR"                 if (p >> 2) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 1) & 0x01 == 1
    on << "PROTUNE_ON"                    if (p >> 0) & 0x01 == 1
    on.join(" / ")
  end

  def decode_field_changed(p)
    on = []
    p = p.hex
    (0..7).each { |n|
      on << "FIELD_#{n}_CHANGED" if (p >> n) & 0x01 == 1
    }
    return on.join(" / ")
  end

  def decode_video_looping_counter_hour(p)
    p.to_i(16)
  end

  def decode_video_looping_counter_min(p)
    p.to_i(16)
  end

  def decode_video_looping_counter_sec(p)
    p.to_i(16)
  end

  def decode_external_battery_level(p)
    p.to_i(16)
  end

  def decode_temperature_read(p)
    p.to_i(16)
  end

  def decode_hash_on_off(p)
    {
      "00" => "OFF",
      "01" => "ON"
    }[p]
  end

  def decode_hash_param_not_used(p)
    {
      "ff" => "NOT_USED"
    }[p]
  end

  def decode_hash_modified_by(p)
    {
      "00" => "CAMERA",
      "01" => "GOPRO_APP",
      "02" => "GCCB",
      "03" => "RC",
      "04" => "T_CMD",
      "05" => "NETWORK",
      "06" => "DESKTOP",
    }[p]
  end

  def decode_hash_charging_status(p)
    {
      "00" => "NOT_CHARGING",
      "01" => "CHARGING"
    }[p]
  end

  def decode_hash_wifi_connection_status(p)
    {
      "00" => "NOT_CONNECTED",
      "01" => "SEARCHING_CONNECTING",
      "02" => "CONNECTED"
    }[p]
  end

  def decode_hash_wifi_mode(p)
    {
      "00" => "OFF",
      "01" => "AP_NEW",
      "02" => "AP_PREV",
      "03" => "STN_RC_NEW",
      "04" => "STN_RC_PREV",
      "05" => "STN"
    }[p]
  end

  def decode_hash_p_button_pressed(p)
    {
      "00" => "P_NO_ACTION",
      "01" => "P_SHORT_PRESS",
      "02" => "P_LONG_PRESS"
    }[p]
  end

  def decode_hash_s_button_pressed(p)
    {
      "00" => "S_NO_ACTION",
      "01" => "S_SHORT_PRESS",
      "02" => "S_LONG_PRESS"
    }[p]
  end

  def decode_hash_w_button_pressed(p)
    {
      "00" => "W_NO_ACTION",
      "01" => "W_SHORT_PRESS",
      "02" => "W_LONG_PRESS"
    }[p]
  end

  def decode_hash_camera_mode(p)
    {
      "00" => "VIDEO",
      "01" => "PHOTO",
      "02" => "BURST",
      "03" => "TIMELAPSE",
      "04" => "10_SEC_TIMER",
      "05" => "PLAYBACK",
      "06" => "RC_MULTI_MODE",
      "07" => "SETTINGS",
      "08" => "DUAL_MASTER",
      "09" => "BROADCAST",
      "0a" => "FW_UPDATE",
      "0b" => "MTP",
      "0c" => "SOS",
      "0d" => "VIDEO_PIV",
      "0e" => "VIDEO_LOOPING",
      "0f" => "VIDEO_TIMELAPSE",
      "10" => "PHOTO_CONTINUOUS",
      "11" => "PHOTO_NIGHT",
      "12" => "NIGHTLAPSE",
    }[p]
  end

  def decode_hash_default_mode(p)
    {
      "00" => "VIDEO",
      "01" => "PHOTO",
      "02" => "BURST",
      "03" => "TIMELAPSE",
      "04" => "10_SEC_TIMER",
      "05" => "PLAYBACK",
      "06" => "RC_MULTI_MODE",
      "07" => "SETTINGS",
      "08" => "DUAL_MASTER",
      "09" => "BROADCAST",
      "0a" => "FW_UPDATE",
      "0b" => "MTP",
      "0c" => "SOS",
      "0d" => "VIDEO_PIV",
      "0e" => "VIDEO_LOOPING",
      "0f" => "VIDEO_TIMELAPSE",
      "10" => "PHOTO_CONTINUOUS",
      "11" => "PHOTO_NIGHT",
      "12" => "NIGHTLAPSE",
    }[p]
  end

  # def decode_hash_default_mode(p)
  #   {
  #     "00" => "VIDEO",
  #     "01" => "PHOTO",
  #     "02" => "BURST",
  #     "03" => "TIME_LAPSE"
  #   }[p]
  # end

  def decode_hash_time_lapse_interval(p)
    {
      "00" => "0.5",
      "01" => "1",
      "02" => "2",
      "05" => "5",
      "0a" => "10",
      "1e" => "30",
      "3c" => "60"
    }[p]
  end

  def decode_hash_night_lapse_interval(p)
    {
      "02" => "4",
      "03" => "5",
      "04" => "10",
      "05" => "15",
      "06" => "20",
      "07" => "30",
      "08" => "60",
      "09" => "120",
      "0a" => "300",
      "0b" => "1800",
      "0c" => "3600",
      "0d" => "CONTINUOUS",
    }[p]
  end

  def decode_hash_auto_power_off(p)
    {
      "00" => "0",
      "01" => "60",
      "02" => "120",
      "03" => "300",
      "04" => "180",
      "ff" => "INVALID",
    }[p]
  end

  def decode_hash_field_of_view(p)
    {
      "00" => "W",
      "01" => "M",
      "02" => "N"
    }[p]
  end

  def decode_hash_photo_resolution(p)
    {
      "00" => "11WIDE",
      "01" => "8MED",
      "02" => "5WIDE",
      "03" => "5MED",
      "04" => "7WIDE",
      "05" => "12WIDE",
      "06" => "7MED",
      "07" => "8WIDE",
      "08" => "10WIDE"
    }[p]
  end

  def decode_hash_video_resolution_fps(p)
    {
      "00" => "WVGA_60/50",
      "01" => "WVGA_120/100",
      "02" => "720_30/25",
      "03" => "720_60_50",
      "04" => "960_30/25",
      "05" => "960_48_50",
      "06" => "1080_30/25"
    }[p]
  end

  def decode_hash_audio_input(p)
    {
      "00" => "ON_CAMERA_MICROPHONE",
      "01" => "HEROBUS",
      "02" => "MIX",
      "03" => "AUDIO_JACK"
    }[p]
  end

  def decode_hash_audio_output(p)
    {
      "00" => "NONE",
      "01" => "ON_CAMERA_SPEAKER",
      "02" => "HEROBUS",
      "03" => "USB_COMBO_CABLE",
      "04" => "HDMI"
    }[p]
  end

  def decode_hash_beep_sound(p)
    {
      "00" => "BEEP_0",
      "01" => "BEEP_70",
      "02" => "BEEP_100",
      "03" => "BEEP_40"
    }[p]
  end

  def decode_hash_beep_sound_hal(p)
    {
      "00" => "BEEP_OFF",
      "02" => "BEEP_ON",
    }[p]
  end

  def decode_hash_led_blink(p)
    {
      "00" => "0",
      "01" => "2",
      "02" => "4"
    }[p]
  end

  def decode_hash_led_blink_rp(p)
    {
      "00" => "OFF",
      "01" => "ON"
    }[p]
  end

  def decode_hash_led_blink_hal(p)
    {
      "00" => "OFF",
      "01" => "BOTH",
      # "02" => 4, # Hawaii only
      "03" => "FRONT",
      "04" => "BACK",
    }[p]
  end

  def decode_hash_battery_level(p)
    {
      "00" => "10_PERCENT",
      "01" => "20_PERCENT_0_BAR",
      "02" => "40_PERCENT_1_BAR",
      "03" => "70_PERCENT_2_BAR",
      "04" => "100_PERCENT_3_BAR"
    }[p]
  end

  def decode_hash_usb_mode(p)
    {
      "00" => "EXTERNAL",
      "01" => "WIFI_RNDIS_FULL_SPEED",
      "02" => "HEROBUS_MSD",
      "03" => "WIFI_RNDIS_HIGH_SPEED"
    }[p]
  end

  def decode_hash_shutter_status(p)
    {
      "00" => "OFF",
      "01" => "ON",
      "02" => "TOGGLE",
      "03" => "LONG_PRESS"
    }[p]
  end

  def decode_hash_hls_segment_size(p)
    {
      "00" => "0.266_SECOND_SEGMENT_SIZE",
      "01" => "1_SECOND_SEGMENT_SIZE"
    }[p]
  end

  def decode_hash_burst_value(p)
    {
      "00" => "3_1",
      "01" => "5_1",
      "02" => "10_1",
      "03" => "10_2",
      "04" => "30_1",
      "05" => "30_2",
      "06" => "30_3",
      "07" => "10_3",
      "08" => "30_6",
    }[p]
  end

  def decode_hash_continuous_shots_value(p)
    {
      "00" => "SINGLE",
      "03" => "3",
      "05" => "5",
      "0a" => "10",
    }[p]
  end

  def decode_hash_night_photo_shutter_exposure(p)
    {
      "00" => "AUTO",
      "02" => "2",
      "05" => "5",
      "0a" => "10",
      "0f" => "15",
      "14" => "20",
      "1e" => "30",
    }[p]
  end

  def decode_hash_night_lapse_shutter_exposure(p)
    {
      "00" => "AUTO",
      "02" => "2",
      "05" => "5",
      "0a" => "10",
      "0f" => "15",
      "14" => "20",
      "1e" => "30",
    }[p]
  end

  def decode_hash_white_balance_value(p)
    {
      "00" => "AUTO",
      "01" => "3000K",
      "02" => "5500K",
      "03" => "6500K",
      "04" => "RAW"
    }[p]
  end

  def decode_hash_white_balance_value_hawaiip4(p)
    {
      "00" => "AUTO",
      "01" => "3000K",
      "02" => "5500K",
      "03" => "6500K",
      "04" => "RAW",
      "05" => "4000K",
      "06" => "4800K",
      "07" => "6000K",
    }[p]
  end

  def decode_hash_video_protune_iso_value(p)
    {
      "00" => "6400",
      "01" => "1600",
      "02" => "400",
    }[p]
  end

  def decode_hash_video_protune_iso_value_hawaiip4(p)
    {
      "00" => "6400",
      "01" => "1600",
      "02" => "400",
      "03" => "3200",
      "04" => "800",
      "05" => "1200",
      "06" => "1000",
      "07" => "200",
      "08" => "100",
      "09" => "AUTO",
    }[p]
  end

  def decode_hash_photo_protune_iso_value(p)
    {
      "00" => "800",
      "01" => "400",
      "02" => "200",
      "03" => "100",
      "04" => "AUTO",
    }[p]
  end

  def decode_hash_photo_in_video_value(p)
    {
      "00" => "OFF",
      "01" => "5_SEC",
      "02" => "10_SEC",
      "03" => "30_SEC",
      "04" => "60_SEC"
    }[p]
  end

  def decode_hash_looping_value(p)
    {
      "00" => "OFF",
      "01" => "5",
      "02" => "20",
      "03" => "60",
      "04" => "120",
      "05" => "MAX"
    }[p]
  end

  def decode_hash_time_lapse_style(p)
    {
      "00" => "VIDEO",
      "01" => "PHOTO"
    }[p]
  end

  def decode_hash_video_resolution(p)
    {
      "00" => "WVGA",
      "01" => "720",
      "02" => "960",
      "03" => "1080",
      "04" => "1440",
      "05" => "2.7K",
      "06" => "4K",
      "07" => "2.7K_CIN",
      "08" => "4K_CIN",
      "09" => "1080_SUPER",
      "0a" => "720_SUPER",
      "0b" => "2.7K_FS",
      "0c" => "2.7K_SUPER",
      "0d" => "4K_SUPER",
    }[p]
  end

  def decode_hash_frame_per_second(p)
    {
      "00" => "12",
      "01" => "15",
      "02" => "24",
      "03" => "25",
      "04" => "30",
      "05" => "48",
      "06" => "50",
      "07" => "60",
      "08" => "100",
      "09" => "120",
      "0a" => "240",
      "0b" => "12.5",
      "0c" => "80",
      "0d" => "90",
    }[p]
  end

  def decode_hash_exposure_compensation(p)
    {
      "00" => "-5.0",
      "01" => "-4.5",
      "02" => "-4.0",
      "03" => "-3.5",
      "04" => "-3.0",
      "05" => "-2.5",
      "06" => "-2.0",
      "07" => "-1.5",
      "08" => "-1.0",
      "09" => "-0.5",
      "0a" => "0",
      "0b" => "0.5",
      "0c" => "1.0",
      "0d" => "1.5",
      "0e" => "2.0",
      "0f" => "2.5",
      "10" => "3.0",
      "11" => "3.5",
      "12" => "4.0",
      "13" => "4.5",
      "14" => "5.0"
    }[p]
  end

  def decode_hash_temperature_warning(p)
    {
      "00" => "NO_WARNING",
      "01" => "OVER_TEMP",
      "02" => "UNDER_TEMP"
    }[p]
  end

  def decode_hash_sd_card_warning(p)
    {
      "00" => "NO_WARNING",
      "01" => "SD_CARD_INSERTED",
      "02" => "SD_CARD_EJECTED",
      "03" => "NO_SD_CARD",
      "04" => "FULL_SD_CARD",
      "05" => "SD_CARD_ERROR"
    }[p]
  end

  def decode_hash_battery_low_shutdown_warning(p)
    {
      "01" => "BATTERY_LOW_SHUTDOWN_WARNING"
    }[p]
  end

  def decode_fake_test_event(p)
    {
      "00" => "FAKE_P1",
      "aa" => "FAKE_P2",
      "55" => "FAKE_P3",
    }[p]
  end

  def decode_lcd_volume(p)
    {
      "00" => "0",
      "01" => "1",
      "02" => "2",
      "03" => "3",
      "04" => "4",
      "05" => "5",
      "06" => "6",
      "07" => "7",
      "08" => "8",
      "09" => "9",
      "0a" => "10",
    }[p]
  end

  def decode_lcd_brightness(p)
    {
      "00" => "DIM",
      "01" => "LOW",
      "02" => "MED",
      "03" => "HIGH",
    }[p]
  end

  def decode_lcd_brightness_haleiwa_v000(p)
    {
      "00" => "OFF",
      "01" => "RESERVED",
      "02" => "RESERVED",
      "03" => "ON",
    }[p]
  end

  def decode_lcd_sleep(p)
    {
      "00" => "0",
      "01" => "60",
      "02" => "120",
      "03" => "180",
      "04" => "300",
    }[p]
  end

  def decode_capture_parameter_mode(p)
    {
      "00" => "VIDEO",
      "01" => "PHOTO",
      "02" => "MULTI_SHOT",
      "03" => "TIMELAPSE",
      "04" => "NIGHTLAPSE",
      "05" => "PHOTO_NIGHT",
    }[p]
  end

  def decode_capture_parameter_all_modes(p)
    {
      "00" => "VIDEO",
      "01" => "PHOTO",
      "02" => "BURST",
      "03" => "VIDEO_PIV",
      "04" => "VIDEO_LOOPING",
      "05" => "PHOTO_CONTINUOUS",
      "06" => "PHOTO_NIGHT",
      "07" => "TIMELAPSE",
      "08" => "NIGHTLAPSE",
      "09" => "VIDEO_TIMELAPSE",
    }[p]
  end

  # def decode_capture_parameter_video_modes(p)
  #   {
  #     "00" => "VIDEO",
  #     "01" => "VIDEO_PIV",
  #     "02" => "VIDEO_LOOPING",
  #     "07" => "VIDEO_TIMELAPSE",
  #   }[p]
  # end

  def decode_capture_parameter_photo_modes(p)
    {
      "00" => "PHOTO",
      "01" => "PHOTO_CONTINUOUS",
      "02" => "PHOTO_NIGHT",
    }[p]
  end

  def decode_capture_parameter_multishot_modes(p)
    {
      "00" => "BURST",
      "01" => "TIMELAPSE",
      "02" => "NIGHTLAPSE",
    }[p]
  end

  def decode_delete_file(p)
    {
      "00" => "DELETE_LAST",
      "01" => "DELETE_FILE",
      "02" => "DELETE_GROUP",
      "03" => "DELETE_ALL",
    }[p]
  end

  def decode_delete_cancel(p)
    {
      "00" => "OK",
      "01" => "CANCELED",
    }[p]
  end

  def decode_highlight_tag(p)
    {
      "01" => "TAG_INSERTED",
      "02" => "TAG_LIMIT_REACHED",
    }[p]
  end

  def decode_highlight_tag_hawaiip4(p)
    {
      "00" => "TAG_REMOVED",
      "01" => "TAG_INSERTED",
      "02" => "TAG_LIMIT_REACHED",
    }[p]
  end

  def decode_highlight_tag_mode(p)
    {
      "00" => "ENCODE",
      "01" => "PLAYBACK",
    }[p]
  end

  # Upon valid decode and basic check, will return "YEAR" + year
  # so test can search for "YEAR" string in P1 for a pass
  def decode_mfg_year(p)
    begin
      y = p.hex.to_i + 2014
      return "YEAR_#{y}"
    rescue StandardError
      log_warn("Unable to parse mfg year (#{p}).  Is it a hex string?")
      return "UNKNOWN"
    end
  end

  # Upon valid decode and basic check, will return "WEEK" + week
  # so test can search for "WEEK" string in P1 for a pass
  def decode_mfg_week(p)
    begin
      w = p.hex.to_i
      if (w < 0 or w > 52)
        log_warn("Invalid week (#{w})")
        return w.to_s
      else
        return "WEEK_#{w}"
      end
    rescue StandardError
      log_warn("Unable to parse mfg week (#{p}).  Is it a hex string?")
      return "UNKNOWN"
    end
  end

  def decode_camera_accessory(p)
    on = []
    p = p.hex
    # HeroBus (3 bits)
    on << "GENERIC"         if (p >> 5) & 0x07 == 5
    on << "LUNADA"          if (p >> 5) & 0x07 == 4
    on << "3D_SECONDARY"    if (p >> 5) & 0x07 == 3
    on << "3D_PRIMARY"      if (p >> 5) & 0x07 == 2
    on << "BOMBIE"          if (p >> 5) & 0x07 == 1
    on << "NO_BACPAC"       if (p >> 5) & 0x07 == 0
    # Cables (3 bits)
    on << "KIRKWOOD"        if (p >> 2) & 0x07 == 7
    on << "MICROPHONE"      if (p >> 2) & 0x07 == 6
    on << "AV_CABLE"        if (p >> 2) & 0x07 == 5
    on << "OCTOPUS"         if (p >> 2) & 0x07 == 4
    on << "DEBUG"           if (p >> 2) & 0x07 == 3
    on << "CHARGER"         if (p >> 2) & 0x07 == 2
    on << "USB_MSC"         if (p >> 2) & 0x07 == 1
    on << "NO_CABLE"        if (p >> 2) & 0x07 == 0
    # HDMI
    on << "4K_HDMI"         if (p >> 0) & 0x03 == 2
    on << "1080_HDMI"       if (p >> 0) & 0x03 == 1
    on << "NO_HDMI"         if (p >> 0) & 0x03 == 0
    on.join(" / ")
  end

  def decode_playback_action(p)
    {
      "00" => "START",
      "01" => "STOP",
      "02" => "PAUSE",
      "03" => "RESUME",
      "04" => "NEXT",
      "05" => "PREVIOUS",
      "06" => "FAST_FORWARD",
      "07" => "REWIND",
      "08" => "TAG_NEXT",
      "09" => "TAG_PREV",
      "0a" => "TRANSCODE_START",
      "0b" => "TRANSCODE_FAIL",
      "0c" => "TRANSCODE_CANCEL",
      "0d" => "SELECT_FILE",
      "0e" => "UNSELECT_FILE",
    }[p]
  end

  def decode_file_type(p)
    {
      "00" => "SINGLE",
      "01" => "GROUP",
      "02" => "ALL",
    }[p]
  end

  def decode_protune_settings(p)
    on = []
    p = p.hex
    on << "PROTUNE_MODE_TBD5"             if (p >> 5) & 0x07 == 5
    on << "PROTUNE_MODE_TBD4"             if (p >> 5) & 0x07 == 4
    on << "PROTUNE_MODE_TIMELAPSE"        if (p >> 5) & 0x07 == 3
    on << "PROTUNE_MODE_BURST"            if (p >> 5) & 0x07 == 2
    on << "PROTUNE_MODE_PHOTO"            if (p >> 5) & 0x07 == 1
    on << "PROTUNE_MODE_VIDEO"            if (p >> 5) & 0x07 == 0
    on << "PROTUNE_SHARPNESS_LOW"         if (p >> 3) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_MED"         if (p >> 3) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_HIGH"        if (p >> 3) & 0x03 == 0
    on << "PROTUNE_COLOR"                 if (p >> 2) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 1) & 0x01 == 1
    on << "PROTUNE_ON"                    if (p >> 0) & 0x01 == 1
    on << "PROTUNE_OFF"                   if (p >> 0) & 0x01 == 0
    on.join(" / ")
  end

  def decode_video_protune_settings(p)
    on = []
    p = p.hex
    on << "PROTUNE_SUBMODE_5"             if (p >> 5) & 0x07 == 5
    on << "PROTUNE_SUBMODE_4"             if (p >> 5) & 0x07 == 4
    on << "PROTUNE_SUBMODE_3"             if (p >> 5) & 0x07 == 3
    on << "PROTUNE_SUBMODE_2"             if (p >> 5) & 0x07 == 2
    on << "PROTUNE_SUBMODE_1"             if (p >> 5) & 0x07 == 1
    on << "PROTUNE_SUBMODE_VIDEO"         if (p >> 5) & 0x07 == 0
    on << "PROTUNE_SHARPNESS_LOW"         if (p >> 3) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_MED"         if (p >> 3) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_HIGH"        if (p >> 3) & 0x03 == 0
    on << "PROTUNE_COLOR"                 if (p >> 2) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 1) & 0x01 == 1
    on << "PROTUNE_ON"                    if (p >> 0) & 0x01 == 1
    on << "PROTUNE_OFF"                   if (p >> 0) & 0x01 == 0
    on.join(" / ")
  end

  def decode_video_protune_settings_rpv01(p)
    on = []
    p = p.hex
    on << "PROTUNE_SUBMODE_5"             if (p >> 5) & 0x07 == 5
    on << "PROTUNE_SUBMODE_4"             if (p >> 5) & 0x07 == 4
    on << "PROTUNE_SUBMODE_3"             if (p >> 5) & 0x07 == 3
    on << "PROTUNE_SUBMODE_2"             if (p >> 5) & 0x07 == 2
    on << "PROTUNE_SUBMODE_1"             if (p >> 5) & 0x07 == 1
    on << "PROTUNE_SUBMODE_VIDEO"         if (p >> 5) & 0x07 == 0
    on << "PROTUNE_SHARPNESS_OFF"         if (p >> 3) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_ON"          if (p >> 3) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_UNUSED"      if (p >> 3) & 0x03 == 0
    on << "PROTUNE_COLOR"                 if (p >> 2) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 1) & 0x01 == 1
    on << "PROTUNE_SETTINGS_DEFAULT"      if (p >> 1) & 0x01 == 0
    on << "PROTUNE_ON"                    if (p >> 0) & 0x01 == 1
    on << "PROTUNE_OFF"                   if (p >> 0) & 0x01 == 0
    on.join(" / ")
  end

  def decode_photo_protune_settings(p)
    on = []
    p = p.hex
    on << "PROTUNE_SUBMODE_5"             if (p >> 5) & 0x07 == 5
    on << "PROTUNE_SUBMODE_4"             if (p >> 5) & 0x07 == 4
    on << "PROTUNE_SUBMODE_3"             if (p >> 5) & 0x07 == 3
    on << "PROTUNE_SUBMODE_PHOTO_NIGHT"   if (p >> 5) & 0x07 == 2
    on << "PROTUNE_SUBMODE_PHOTO_CONTINUOUS" if (p >> 5) & 0x07 == 1
    on << "PROTUNE_SUBMODE_PHOTO"         if (p >> 5) & 0x07 == 0
    on << "PROTUNE_SHARPNESS_LOW"         if (p >> 3) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_MED"         if (p >> 3) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_HIGH"        if (p >> 3) & 0x03 == 0
    on << "PROTUNE_COLOR"                 if (p >> 2) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 1) & 0x01 == 1
    on << "PROTUNE_ON"                    if (p >> 0) & 0x01 == 1
    on << "PROTUNE_OFF"                   if (p >> 0) & 0x01 == 0
    on.join(" / ")
  end

  def decode_multi_shot_protune_settings(p)
    on = []
    p = p.hex
    on << "PROTUNE_SUBMODE_5"             if (p >> 5) & 0x07 == 5
    on << "PROTUNE_SUBMODE_4"             if (p >> 5) & 0x07 == 4
    on << "PROTUNE_SUBMODE_3"             if (p >> 5) & 0x07 == 3
    on << "PROTUNE_SUBMODE_NIGHTLAPSE"    if (p >> 5) & 0x07 == 2
    on << "PROTUNE_SUBMODE_TIMELAPSE"     if (p >> 5) & 0x07 == 1
    on << "PROTUNE_SUBMODE_BURST"         if (p >> 5) & 0x07 == 0
    on << "PROTUNE_SHARPNESS_LOW"         if (p >> 3) & 0x03 == 2
    on << "PROTUNE_SHARPNESS_MED"         if (p >> 3) & 0x03 == 1
    on << "PROTUNE_SHARPNESS_HIGH"        if (p >> 3) & 0x03 == 0
    on << "PROTUNE_COLOR"                 if (p >> 2) & 0x01 == 1
    on << "PROTUNE_SETTINGS_NOT_DEFAULT"  if (p >> 1) & 0x01 == 1
    on << "PROTUNE_ON"                    if (p >> 0) & 0x01 == 1
    on << "PROTUNE_OFF"                   if (p >> 0) & 0x01 == 0
    on.join(" / ")
  end

  # def decode_user_settings(p)
  #   on = []
  #   p = p.hex
  #   on << "RESERVED_BIT_7"    if (p >> 7) & 0x01 == 1
  #   on << "LOW_LIGHT"         if (p >> 6) & 0x01 == 1
  #   on << "LOCATE"            if (p >> 5) & 0x01 == 1
  #   on << "ON_SCREEN_DISPLAY" if (p >> 4) & 0x01 == 1
  #   on << "QUICK_CAPTURE"     if (p >> 3) & 0x01 == 1
  #   on << "UPSIDE_DOWN"       if (p >> 2) & 0x01 == 1
  #   on << "VIDEO_LIVE_FEED"   if (p >> 1) & 0x01 == 1
  #   on << "NTSC"              if (p >> 0) & 0x01 == 1
  #   on << "PAL"               if (p >> 0) & 0x01 == 0
  #   on.join(" / ")
  # end

  def decode_user_settings(p)
    on = []
    p = p.hex
    on << "LOW_LIGHT_ON"      if (p >> 7) & 0x01 == 1
    on << "LOW_LIGHT_OFF"     if (p >> 7) & 0x01 == 0
    on << "LOCATE_ON"         if (p >> 6) & 0x01 == 1
    on << "LOCATE_OFF"        if (p >> 6) & 0x01 == 0
    on << "ON_SCREEN_DISPLAY_ON"  if (p >> 5) & 0x01 == 1
    on << "ON_SCREEN_DISPLAY_OFF" if (p >> 5) & 0x01 == 0
    on << "QUICK_CAPTURE_ON"  if (p >> 4) & 0x01 == 1
    on << "QUICK_CAPTURE_OFF" if (p >> 4) & 0x01 == 0
    on << "ORIENT_DOWN"       if (p >> 2) & 0x03 == 2
    on << "ORIENT_UP"         if (p >> 2) & 0x03 == 1
    on << "ORIENT_AUTO"       if (p >> 2) & 0x03 == 0
    on << "VIDEO_LIVE_FEED"   if (p >> 1) & 0x01 == 1
    on << "PAL"               if (p >> 0) & 0x01 == 1
    on << "NTSC"              if (p >> 0) & 0x01 == 0
    on.join(" / ")
  end

  def decode_broadcast_mode(p)
    {
      "00" => "BROADCAST_ONLY",
      "01" => "BROADCAST_RECORD",
    }[p]
  end

  def decode_broadcast_privacy_mode(p)
    {
      "00" => "ALWAYS_ASK",
      "01" => "PUBLIC",
      "02" => "HIDDEN",
    }[p]
  end

  def decode_fw_update_status(p)
    on = []
    p = p.hex
    on << "OTA_SUCCESS" if (p >> 7) & 0x01 == 1
    on << "OTA_ERROR"   if (p >> 6) & 0x01 == 1
    on << "OTA_CANCEL"  if (p >> 5) & 0x01 == 1
    on << "OTA_START"   if (p >> 4) & 0x01 == 1
    on << "FW_SUCCESS"  if (p >> 3) & 0x01 == 1
    on << "FW_ERROR"    if (p >> 2) & 0x01 == 1
    on << "FW_CANCEL"   if (p >> 1) & 0x01 == 1
    on << "FW_START"    if (p >> 0) & 0x01 == 1
    on.join(" / ")
  end

  def decode_delete_mode(p)
    {
      "00" => "SETTINGS",
      "01" => "PLAYBACK",
      }[p]
  end

  def decode_camera_status(p)
    on = []
    p = p.hex
    on << "RESERVED_BIT_7"                if (p >> 7) & 0x01 == 1
    on << "RESERVED_BIT_6"                if (p >> 6) & 0x01 == 1
    on << "RESERVED_BIT_5"                if (p >> 5) & 0x01 == 1
    on << "RESERVED_BIT_4"                if (p >> 4) & 0x01 == 1
    on << "RESERVED_BIT_3"                if (p >> 3) & 0x01 == 1
    on << "RESERVED_BIT_2"                if (p >> 2) & 0x01 == 1
    on << "RESERVED_BIT_1"                if (p >> 1) & 0x01 == 1
    on << "STATUS_BUSY"                   if (p >> 0) & 0x01 == 1
    on.join(" / ")
  end

  def decode_button_id(p)
    {
      "00" => "P_BUTTON",
      "01" => "S_BUTTON",
      "02" => "W_BUTTON",
      "03" => "LCD_BUTTON",
    }[p]
  end

  def decode_button_action(p)
    {
      "00" => "NO_ACTION",
      "01" => "SHORT_PRESS",
      "02" => "LONG_PRESS",
      "03" => "EXTRA_LONG_PRESS",
    }[p]
  end

  def decode_rtc_val(p)
    p.to_i(16)
  end

  def decode_spot_meter_mode(p)
    {
      "00" => "VIDEO",
      "01" => "VIDEO_PIV",
      "02" => "VIDEO_LOOPING",
      "03" => "PHOTO",
      "04" => "PHOTO_CONTINUOUS",
      "05" => "PHOTO_NIGHT",
      "06" => "RC_MULTI_MODE",
      "07" => "BURST",
      "08" => "TIMELAPSE",
      "09" => "NIGHTLAPSE",
    }[p]
  end

  def decode_reset(p)
    {
      "00" => "RESET_CANCEL",
      "01" => "RESET_OK",
    }[p]
  end

  def decode_language(p)
    {
      "00" => "ENGLISH",
      "01" => "SIMP_CHINESE",
    }[p]
  end

  def decode_video_protune_shutter_speed(p)
    {
      "00"  => "AUTO",
      "01"  => "1/12.5",
      "02"  => "1/15",
      "03"  => "1/24",
      "04"  => "1/25",
      "05"  => "1/30",
      "06"  => "1/48",
      "07"  => "1/50",
      "08"  => "1/60",
      "09"  => "1/80",
      "0a"  => "1/90",
      "0b"  => "1/96",
      "0c"  => "1/100",
      "0d"  => "1/120",
      "0e"  => "1/160",
      "0f"  => "1/180",
      "10"  => "1/192",
      "11"  => "1/200",
      "12"  => "1/240",
      "13"  => "1/320",
      "14"  => "1/360",
      "15"  => "1/400",
      "16"  => "1/480",
      "17"  => "1/960",
    }[p]
  end

  def decode_hash_video_protune_iso_mode(p)
    {
      "00" => "MAX",
      "01" => "LOCK",
    }[p]
  end

  def decode_hash_protune_reset(p)
    {
      "00" => "PROTUNE_RESET_CANCEL",
      "01" => "PROTUNE_RESET",
    }[p]
  end

  def decode_playback_media_filter_type(p)
    {
      "00" => "ALL",
      "01" => "VIDEOS",
      "02" => "PHOTOS",
      "03" => "CLIPS",
      "04" => "HILIGHTED",
    }[p]
  end

  def decode_hash_battery_type(p)
    {
      "00" => "INTERNAL_BATT",
      "01" => "EXTERNAL_BATT",
    }[p]
  end

  def decode_firmware_update_error(p)
    {
      "01" => "FIRMWARE_UPDATE_FAILURE_WARNING"
    }[p]
  end

  def decode_power_save_mode(p)
    {
      "00" => "IDLE_MODE_EXIT",
      "01" => "IDLE_MODE_ENTER"
    }[p]
  end

  def decode_data_analytics_full(p)
    {
      "01" => "DATA_ANALYTICS_FULL_WARNING"
    }[p]
  end

  def decode_light_value(p)
    {
      "00" => "BRIGHT_LIGHT",
      "01" => "MEDIUM_LIGHT",
      "02" => "LOW_LIGHT",
    }[p]
  end

  def decode_highlight_tag_mode_media_type(p)
    on = []
    p = p.hex
    on << "RESERVED_BIT_7"        if (p >> 7) & 0x01 == 1
    on << "NIGHTLAPSE"            if (p >> 3) & 0x0F == 8
    on << "TIMELAPSE"             if (p >> 3) & 0x0F == 7
    on << "BURST"                 if (p >> 3) & 0x0F == 6
    on << "PHOTO_NIGHT"           if (p >> 3) & 0x0F == 5
    on << "PHOTO_CONTINUOUS"      if (p >> 3) & 0x0F == 4
    on << "PHOTO"                 if (p >> 3) & 0x0F == 3
    on << "VIDEO_LOOPING"         if (p >> 3) & 0x0F == 2
    on << "VIDEO_TIMELAPSE"       if (p >> 3) & 0x0F == 1
    on << "VIDEO"                 if (p >> 3) & 0x0F == 0
    on << "PLAYBACK"              if p & 0x03 == 1
    on << "ENCODE"                if p & 0x03 == 0
    on.join(" / ")
  end

end
