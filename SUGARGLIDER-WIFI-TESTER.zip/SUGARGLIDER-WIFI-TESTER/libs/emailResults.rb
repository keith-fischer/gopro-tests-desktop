require "net/smtp"
require "time"
require_relative 'log_utils'

# NOTE: ONLY A SINGLE ATTACHMENT IS SUPPORTED CURRENTLY
# This is enforced in the add_attachment() method

class MailServer
  include LogUtils
  
  attr_accessor :from_addr, :to_addr
  attr_reader :content
  # Used for messages with attachments
  @@delimiter = "DELIM"
  
  # Mail server settings.
  # GMail server_addr="smtp.gmail.com", server_port=587
  # Office365 server_addr="smtp.office365.com", server_port=587
  #    Notes: username MUST include '@gopro.com'
  #           username MUST match @from.addr
  #           portion of username after '@' MUST == @domain
  def initialize(username, password)
    @username = username
    @password = password
    @server_addr = "smtp.office365.com"
    @server_port = 587
    @domain = "gopro.com"
    @smtp = Net::SMTP.new(@server_addr, @server_port)
    @smtp.enable_starttls()
    @content = nil
    @from_addr = nil
    @to_addr = nil
    @attachments = []
  end

  def build_message(subject, message)
    if @attachments.count > 0
      build_attachment_html_message(subject, message)
    else
      build_html_message(subject, message)
    end
  end

  def build_html_message(subject, message)
    @content = <<END_OF_CONTENT
From: #{@from_addr}
To: #{@to_addr}
MIME-Version: 1.0
Content-type: text/html
Subject: #{subject}
Date: #{Time.now.rfc2822}

#{message}
END_OF_CONTENT
  end

  def build_attachment_html_message(subject, message)
    header = <<END_OF_CONTENT
From: #{@from_addr}
To: #{@to_addr}
MIME-Version: 1.0
Content-type: multipart/mixed; boundary=#{@@delimiter}
Subject: #{subject}
Date: #{Time.now.rfc2822}
--#{@@delimiter}
END_OF_CONTENT

    body = <<END_OF_CONTENT
Content-type: text/html
Content-Transfer-Encoding: 8bit

#{message}
--#{@@delimiter}
END_OF_CONTENT

    attachments = ""
    current = 1
    limit = @attachments.count
    @attachments.each do |a|
      # Read the file into an array an ecode in base64
      encoded_file = [File.read(a)].pack("m")
      attachments += <<END_OF_CONTENT
Content-type: multipart/mixed; boundary=#{@@delimiter}
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename="#{File.basename(a)}"

#{encoded_file}
END_OF_CONTENT
      if current < limit
        current += 1
        attachments += "--#{@@delimiter}\n"
      else
        attachments += "--#{@@delimiter}--\n"
      end
    end #@attachments.each

    @content = header + body + attachments
    return true
  end

  def add_attachment(f)
    if not File.exists?(f)
      log_warn("Attachment #{f} not found.  Skipping")
      return false
    elsif @attachments.count > 0
      log_warn("Only one attachment supported at a time. Skipping #{f}")
      return false
    else
      @attachments << f
    end
    return true
  end

  def send
    if (@to_addr == nil) or (@from_addr == nil)
      log_error("Both to/from addresses must be specified")
    elsif @content == nil
      log_error("Cannot send empty message")
    else
      begin
        @smtp.start(@domain, @username, @password, :login) do
          @smtp.send_message(@content, from_addr, to_addr)
        end
      rescue StandardError => e
        log_error("Unable to send message: #{e}")
        return
      end
      log_info("Message sent!")
    end
  end
end

if __FILE__ == $0
  # Quick Test
  gm = MailServer.new("qaauto_gopro@gopro.com", "jRwu4UKtv")
  gm.from_addr = "qaauto_gopro@gopro.com"
  gm.to_addr = "cdana@gopro.com"
#gm.add_attachment("/tmp/test_attach.tar.bz2")
  gm.build_message("test subject", "<p>Hello<br>GoPro!")
  puts gm.content
  gm.send
end
