
# Note: Argus cameras are limited to the following:
#
#   modes      : VIDEO, VIDEO_TIMELAPSE
#   resolution : 2.7K
#   FOV        : W
#   format     : NTSC,PAL
#

module Argus

  def init

    # @name = "ARGUS"

    log_verb("Instantiating #{name} camera")
    @remote_api = 2  #remote smarty api version 2 (ie http://10.5.5.9/gp/gpControl/setting/1/0)
    @data_log_model = 13  # Camera model number for analytics purposes
    @analytics_version = "0.2.0"

    @audio_channels       = 2
    @audio_codec          = "aac"
    @audio_bitrate        = 64    #in kbps per channel.
    @audio_sample_rate    = 48000
    @avc_profile_level    = "HIGH"
    @video_codec          = "h264"
    @colorspace           = "yuvj420p"
    @hilight_tag_limit    = 80

    # Support for changing preview bitrate via BV command
    @chg_prev_br_support  = true
    # Support for changing preview resolution via BV command
    @chg_prev_res_support = true

    @total_video_timelapse_lrv_bitrate = 1.5 #Mbps, (includes video + audio + data)
    @total_lrv_bitrate    = 0.8        #Mbps, (includes video + audio + data)

    #video
    @video_low_light_support    = true
    @video_protune_support      = true
    @video_timelapse_support    = true
    @video_piv_support          = false
    @video_looping_support      = false
    #photo
    @photo_spot_metering_support = false
    @photo_night_support         = false
    @photo_continuous_support    = false
    @photo_protune_support       = false
    #multi_photo
    @multi_photo_spot_metering_support = false
    @multi_photo_nightlapse_support    = false
    @multi_photo_protune_support       = false

    #share video/photo/multi_photo protune value. Split where necessary
    @video_protune_modes          = ["VIDEO"]
    @photo_protune_modes          = [] # photo not supported
    @multi_protune_modes          = [] # multi not supported

    @protune_white_balance_values = ["3000K", "5500K", "6500K", "RAW"]
    @protune_color_values         = ["NEUTRAL"]
    @protune_sharpness_values     = ["LOW", "MED", "HIGH"]
    @protune_exposure_values      = ["-2.0", "-1.5", "-1.0", "-0.5",
                                     "0", "0.5", "1.0", "1.5", "2.0"]
    @photo_protune_iso_values     = []
    @video_protune_iso_values     = ["6400", "3200", "1600", "800", "400"]

    @photo_shutter_exposure  = ["AUTO", "2", "5", "10", "15", "20", "30"]
    @multi_shutter_exposure  = ["AUTO", "2", "5", "10", "15", "20", "30"]
    @video_piv_intervals     = ["5", "10", "30", "60"]

    # preview stream testing flag
    @test_preview_stream     = true

    #photo's preview stream
    @photo_ts = {
      :lrv_aspect_ratio => "4:3",
      :lrv_width        => 320,
      :lrv_height       => 240
    }

    @capabilities = {
      :has_camera_roll      => true,
      :has_ota              => true,  #over the air firmware update
      :has_ltp              => true,
      :has_3D               => true,
      :has_ccl              => true,   #camera control library
    }

    @defaults = {
      :setup_video_format     => "NTSC",
      :video_submode          => "VIDEO",
      :video_timelapse        => "2.0",
      :video_looping          => "5",
      :video_piv              => "5",
      :video_resolution       => "2.7K",
      :video_fps              => "30",
      :video_fov              => "W",
      :video_low_light        => "OFF",
      :video_spot_metering    => "OFF",
      :video_pt               => "OFF",
      :video_pt_wb            => "AUTO",
      :video_pt_color         => "STANDARD",
      :video_pt_ev            => "0",
      :video_pt_sharp         => "HIGH",
      :video_pt_iso           => "1600",
      :photo_submode          => "SINGLE",
      :photo_resolution       => "12WIDE",
      :photo_continuous       => "3",
      :photo_shutter_ev       => "AUTO",
      :photo_pt               => "OFF",
      :photo_pt_wb            => "AUTO",
      :photo_pt_color         => "STANDARD",
      :photo_pt_ev            => "0",
      :photo_pt_sharp         => "HIGH",
      :photo_pt_iso           => "800",
      :photo_spot_metering    => "OFF",
      :multi_photo_submode    => "BURST",
      :multi_photo_resolution => "12WIDE",
      :multi_photo_burst      => "30_1",
      :multi_photo_timelapse  => "0.5",
      :multi_photo_shutter_ev => "AUTO",
      :multi_photo_nightlapse => "CONTINUOUS",
      :multi_photo_pt         => "OFF",
      :multi_photo_pt_wb      => "AUTO",
      :multi_photo_pt_color   => "STANDARD",
      :multi_photo_pt_ev      => "0",
      :multi_photo_pt_sharp   => "HIGH",
      :multi_photo_pt_iso     => "800",
      :multi_photo_spot_meter => "OFF",
      :setup_default_mode     => "VIDEO",
      :setup_orientation      => "UP",
      :setup_led              => "4",
      :setup_beep             => "100",
      :setup_osd              => "ON",
      :setup_quick_capture    => "OFF",
      :setup_auto_off         => "0",     #NEVER
      :setup_lcd_brightness   => "HIGH",
      :setup_lcd_lock         => "ON",
      :setup_lcd_auto_off     => "60",
      #      :setup_lcd_display      => "ON"
      #      :setup_stream_gop_size
      #      :setup_stream_idr_interval
      #      :setup_stream_bit_rate
      #      :setup_stream_window_size
    }

    #Initial camera setup before executing any tests
    @setup = {
      :setup_led              => "4",
      :setup_beep             => "100",
    }

    # Commands that don't have prerequisites
    # Wifi commands to test
    @cmds = [
      :video_dft_submode,
      :photo_dft_submode,
      :multi_photo_dft_submode,
      :setup_beep,
      :setup_default_mode,
      :setup_led,
      :video_spot_metering,
      :setup_video_format,
      :setup_osd,
      :setup_auto_off,      #NEVER
    ]

    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 5,
      "120"   => 5,
      "MAX"   => 5,
    }

    # File size limit for videos after which it is split
    @chapter_size = 4<<30 # 4 GB

    @video_protune_vars = {
      :video_pt_color => true,
      :video_pt_iso   => true,
      :video_pt_sharp => true,
      :video_pt_ev    => true,
      :video_pt_wb    => true
    }

    @photo_protune_vars = {
      :photo_pt_color  => false,
      :photo_pt_iso    => false,
      :photo_pt_sharp  => false,
      :photo_pt_ev     => false,
      :photo_pt_wb     => false
    }

    @multi_photo_protune_vars = {
      :multi_photo_pt_color   => false,
      :multi_photo_pt_iso     => false,
      :multi_photo_pt_sharp   => false,
      :multi_photo_pt_ev      => false,
      :multi_photo_pt_wb      => false
    }

    # Data structure for preview specifications
    # Basically come in 2 flavors.  Fullscreen and Widescreen
    # Fullscreen is 4:3 and widescreen is anything >4:3
    @preview = {
      # QVGA, WQVGA.  bitrate in bps
      "LOW" => {
      :bitrate => {
      :LOW  => 311040,
      :MED  => 500000,
      :HIGH => 750000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 240,
      :width_fs         => 320, # QVGA
      :width_ws         => 432, # WQVGA
      },
      # VGA, QVGA.  bitrate in bps
      "HIGH" => {
      :bitrate => {
      :LOW  => 1221120,
      :MED  => 2000000,
      :HIGH => 3000000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 480,
      :width_fs         => 640, # QVGA
      :width_ws         => 848, # WQVGA
      },
    }

    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    # certain resolution is available for certain mode (ie video single, video time lapse)
    # :video = single video
    # :piv => photo-in-video
    # :looping = video looping
    @video_capture_modes = {
      "2.7K"  =>  {
      :width  => 2704,
      :height => 1520,
      :aspect_ratio => "169:95",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
          "25"  => {
          :fov        => ["W"],
          :ntsc       => false,
          :pal        => true,
          :bitrate    => 45,
          :pt_bitrate => 45,
          :thm        => true,
          :lrv_fps    => 25,
          :pt_lrv     => true,
          :pt_thm     => true,
          :lrv_timecode => true,
          :timecode   => true,
          :frame_rate => 25,
          :low_light  => false,
          :jello_slayer => true,
          :looping    => false,
          :piv        => false,
          },
          "30"  => {
          :fov        => ["W"],
          :ntsc       => true,
          :pal        => false,
          :bitrate    => 45,
          :pt_bitrate => 45,
          :thm        => true,
          :lrv_fps    => 29.97,
          :pt_lrv     => true,
          :pt_thm     => true,
          :lrv_timecode => true,
          :timecode   => true,
          :frame_rate => 29.97,
          :low_light  => false,
          :jello_slayer => true,
          :looping    => false,
          :piv        => false,
          },
        } # end fps
      }, # end 2.7K
    } # end @video_capture_modes

    @video_timelapse_capture_modes = {
      "2.7K_FS" => {
      :width  => 2704,
      :height => 2028,
      :aspect_ratio => "4:3",
      :ntsc_fps => 29.97,
      :pal_fps => 25,
      :bitrate => 45,
      :timecode   => true,
      :thm => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :lrv_ntsc_fps => 29.97,
      :lrv_pal_fps => 25,
      :lrv_timecode => true,
      }
    }

    #N/A on Argus # Photo Modes 

    @screens = {
      :wireless_settings => [ \
      "0000000000000000000f000000000000000f1fffffffffffff8f3fffffffffffffcf3" + \
      "fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffff" + \
      "ffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3ffffffffff" + \
      "fffcf3f1c6eeeec618fcf3eebaeeedbaf77cf"]
    }

  end # end init
end # end Argus
