# resultsHandler class
require 'optparse'
require 'set'
require 'date'
require 'thread'
require 'socket' # For host name/ip info only

require_relative 'testrail'
require_relative 'emailResults'
require_relative 'log_utils'
require_relative 'testHandler'
# Inputs: An array of TestRunner objects

# Outputs:
# 1) Standard report string
# 2) E-mail results
# 3) Update TestRail

class ResultsHandler
  include LogUtils
  attr_reader :release, :type, :build, :name
  # See TestRunner for available members
  def initialize(results_arr, build_override=nil)
    # Convenience for variables that should be the same for all cams
    @release  = nil
    @type     = nil
    @build    = nil
    @name     = nil
    @hostname = Socket.gethostname
    @hostip   = get_host_gopro_ip()
    @currtime = Time.now().strftime("%Y-%m-%d %H:%M:%S")
    # Group results by camera IP/serial device
    @results = {}
    results_arr.each { |r|
      if build_override != nil
        r.cam.build = build_override
      end
      @release = r.cam.release if @release == nil
      @type    = r.cam.type if @type == nil
      @build   = r.cam.build if @build == nil
      @name    = r.cam.name if @name == nil
      @results[r.cam.addr] = [] if not @results.has_key?(r.cam.addr)
      @results[r.cam.addr] << r
    }
    log_verb("release=%s, type=%s, build=%s, name=%s" \
      %[@release, @type, @build, @name])
    if @build == nil
      log_warn("Build must be specified!")
      exit 1
    end
  end

  def get_host_gopro_ip()
    addrinfo = Socket.ip_address_list.reject { |ai|
      !ai.ipv4? or \
      ai.ipv4_loopback? or
      ai.ip_address.match("10.5.5") or \
      ai.ip_address.match("192.168") }
    ip = (addrinfo.length > 0) ? addrinfo[0].ip_address : "Unknown IP"
    return ip
  end

  # Return the formatted string for displaying a result in the standard report
  # r - The result object
  # tc - The test-case result array (e.g. ["PASS", test1, "test passed"])
  def format_result_str(r, tc)
    s = "    "
    s += r.test_file.to_s + " : "
    s += tc[1].to_s.strip + " :: "
    s += tc[0].to_s.strip + " "
    s += tc[2].to_s.strip.split(",").join("\n")
    return s + "\n"
  end

  def format_result_html(r, tc, all=false)
    s = "<li>"
    s += r.test_file.to_s + " : " if all == true
    s += tc[1].to_s.strip
    s += " :: "                 if all == true
    s += tc[0].to_s.strip + " " if all == true
    s += tc[2].to_s.strip       if all == true
    s += "\n"
    return s
  end

  def format_result_info(r, tc)
    s = "    "
    s += tc[1].to_s.strip
    s += tc[2].to_s.strip.split("\n").join("\n")
    return s + "\n"
  end

  def format_result_info_html(r, tc)
    s = "<li>"
    s += tc[1].to_s.strip
    s += tc[2].to_s.strip.split("     ").join("\n")
    s += "\n"
    return s
  end

  # Returns a string of all the passes in a results object
  def get_passes(r)
    s = ""
    r.passed.each { |p| s += format_result_str(r, p) }
    return s
  end

  # Returns a string comprising a standard report
  def standard_report()
    s = "=========Standard Report=========\n"
    # Iterate over all IPs
    ##    require 'pp'; pp @results
    @results.each { |dev, r_arr|
      cam = nil
      r_arr.each { |r|
        if r.cam != nil
          cam = r.cam
          break
        end
      }
      next if cam == nil
      # Iterate over results objects
      # Test run statistics
      s += "Generated at #{@currtime} by #{ENV["USER"]}@#{@hostname} (#{@hostip})\n"
      if cam.media_dir != nil
        s += "Any media will be in #{cam.media_dir}\n\n"
      end
      s += "#{cam.name} @#{dev} build #{cam.build}\n"
      s += "  Test File (Duration) (PASS, FAIL, SKIP, ERROR) (Exit Code)\n"
      r_arr.each { |r|
        s += "    %s (Dur. %s) (PASS=%s, FAIL=%s, SKIP=%s, ERROR=%s) (Exit=%s)\n" \
        %[File.basename(r.test_file), r.duration,
          r.passed.length, r.failed.length, r.skipped.length, r.errors.length,
          r.exitstat.exitstatus]
      }
      s += "  Detail Test-Case Passes\n"
      r_arr.each { |r|
        r.passed.each { |tc| s += format_result_str(r, tc) } }
      s += "  Detail Test-Case Skips\n"
      r_arr.each { |r|
        r.skipped.each { |tc| s += format_result_str(r, tc) } }
      s += "  Detail Test-Case Errors/Failures\n"
      r_arr.each { |r|
        r.failed.each { |tc| s += format_result_str(r, tc) }
        r.errors.each { |tc| s += format_result_str(r, tc) }

      if ["test_hawaii_bat.rb", "test_australia_bat.rb", "test_margaretriver_bat.rb"].include?(r.test_file)
          s += "  Other Information:\n"
          r.warns.each { |tc| s += format_result_info(r, tc) }
        end
      }
      }

    # Remove colors, as I don't want them saved in any reports.
    ["\033[91m","\033[92m","\033[93m","\033[96m","\033[0m","\033[40m"].each { |xx|
      s = s.gsub(xx, "")
    }
    return s
  end

  # Returns a string comprising a standard report
  def html_standard_report()
    s = '<font face="\'Lucida Console\', Monaco, monospace" size="2">'
    s += "\n<h3>=========Standard Report=========</h3>\n"
    # Iterate over all IPs
    @results.each { |dev, r_arr|
      # Iterate over results objects
      cam = nil
      r_arr.each { |r|
        if r.cam != nil
          cam = r.cam
          break
        end
      }
      next if cam == nil
      # Test run statistics
      s += "Generated at #{@currtime} by #{ENV["USER"]}@#{@hostname} (#{@hostip})<br>\n"
      if cam.media_dir != nil
        s += "Any media will be in <a href=#{cam.media_dir}>#{cam.media_dir}</a><br>\n"
      end
      s += "<br><strong>#{cam.name} @#{dev} build #{cam.build}<br>"
      s += "Test File (Duration) (PASS, FAIL, SKIP, ERROR) (Exit Code)</strong>\n"
      s += "<ul>"
      r_arr.each { |r|
        s += "<li> %s (Dur. %s) (PASS=%s, FAIL=%s, SKIP=%s, ERROR=%s) (Exit=%s)\n" \
        %[File.basename(r.test_file), r.duration,
          r.passed.length, r.failed.length, r.skipped.length, r.errors.length,
          r.exitstat.exitstatus]
      }
      s += "</ul>"

      # SKIPPING test cases
      s += "<strong><font color=\"red\">Detail Test-Case Skips</font></strong><ul>\n"
      wrote_line = false
      r_arr.each { |r|
        next if r.skipped.length == 0
        wrote_line = true
        s += "<li>#{r.test_file}<ul>\n"
        r.skipped.each { |tc| s += format_result_html(r, tc) }
        s += "</ul>\n"
      }
      s += "<li>None\n" if wrote_line == false
      s += "</ul>"

      # ERRORS / FAILING test cases
      s += "<strong><font color=\"red\">Detail Test-Case Errors/Failures</font></strong><ul>\n"
      wrote_line = false
      r_arr.each { |r|
        next if r.failed.length == 0 and r.errors.length == 0
        wrote_line = true
        s += "<li>#{r.test_file}<ul>\n"
        r.failed.each { |tc| s += format_result_html(r, tc, all=true) }
        r.errors.each { |tc| s += format_result_html(r, tc, all=true) }
        s += "</ul>\n"
      }
      s += "<li>None\n" if wrote_line == false
      s += "</ul>\n"

      # PASSING test cases
      s += "<strong><font color=\"red\">Detail Test-Case Passes</font></strong><ul>\n"
      wrote_line = false
      r_arr.each { |r|
        next if r.passed.length == 0
        wrote_line = true
        s += "<li>#{r.test_file}<ul>\n"
        r.passed.each { |tc| s += format_result_html(r, tc) }
        s += "</ul>\n"
      }
      s += "<li>None\n" if wrote_line == false
      s += "</ul>"

      # WARNING / Other info if BAT script
      r_arr.each { |r|
        if ["test_hawaii_bat.rb", "test_australia_bat.rb", "test_margaretriver_bat.rb"].include?(r.test_file)
          s += "<strong><font color=\"red\">Other Information</font></strong><ul>\n"
          if r.warns.length == 0
            s += "<li>None\n"
            s += "</ul>"
          else
            r.warns.each { |tc| s += format_result_info_html(r, tc) }
            s += "</ul>\n"
          end
        end
      }
    }
    s += "</font>"
    # Remove colors, as I don't want them saved in any reports.
    ["\033[91m","\033[92m","\033[93m","\033[96m","\033[0m","\033[40m"].each { |xx|
      s = s.gsub(xx, "")
    }
    return s
  end

  def email_report(to_addr, subject_str, res_dir=nil, runlabel=nil)
    gm = MailServer.new("qaauto_gopro@gopro.com", "Beahero123")
    gm.from_addr = "qaauto_gopro@gopro.com"
    gm.to_addr = to_addr
    # Add the camera names and builds to the subject
    s1 = Set.new()
    @results.each { |ip, r_arr|
      r_arr.each { |r|
        cam_name_build_str = "[#{r.cam.name}_#{r.cam.build}]"
        s1.add(cam_name_build_str)
      }
    }
    subject_str += s1.to_a.join()
    subject_str += "[#{runlabel}]"
    if res_dir != nil and File.directory?(res_dir) == true
      gm.add_attachment(get_results_tar(res_dir))
    end
    # Get the results, build the message, and send
    html_report_str = html_standard_report()
    ##    puts html_report_str
    gm.build_message(subject_str, html_report_str)
    log_info("Sending results to #{gm.to_addr}")
    ###require 'pp'; pp gm
    gm.send
  end

  # 'dir' is the RUN_XX directory where all the logs were written
  def get_results_tar(dir)
    tarfile = File.path("/tmp/#{File.basename(dir)}.tar.bz2")
    if File.exists?(tarfile)
      log_info("#{tarfile} exists!  Deleting...")
      File.delete(tarfile)
    end
    files_to_tar = Dir.glob(File.join(dir, "**", "*.txt")).join(" ")
    files_to_tar += " " + Dir.glob(File.join(dir, "**", "*.log")).join(" ")
    cmd = "tar -cjf #{tarfile} #{files_to_tar} 2>&1"
    output = `#{cmd}`
    return tarfile
  end

  # Returns a link to the specified testrun (if it exists)
  # cam - A camera object (e.g. type Camera::SilverPlus)
  # proj - the Testrail project ((FWQA) Automation)
  def get_testrail_link(cam, proj="(FWQA) Automation")
    url = "https://gopro.testrail.com/index.php?/runs/"
    rail = TestRail.new(name=proj)
    suite_name = cam.name
    run_name = "#{cam.name}_#{cam.build}"
    run_id = rail.get_run_id(run_name, rail.proj_id)
    if run_id != false
      desc = "TestRail Test Run (#{run_id}) Link"
      url += "view/#{run_id}"
    else
      desc = "TestRail Automation Overview Link"
      url += "overview/#{rail.proj_id}"
    end
    return "<a href=\"#{url}\">#{desc}</a>"
  end

  # Add the results to TestRail with the following steps
  # 1) Determine if we have any configurations
  # 2) Add/Update the test run/plan for the appropriate suite
  # 3) Set the results for each of the tests
  # project - string matching the project name
  def add_results_testrail(proj_name)
    log_info("Adding results to project '#{proj_name}'")
    rail = TestRail.new(name=proj_name)
    proj_id = rail.proj_id
    proj_configs = nil

    # Get a camera object from one of the results objects
    # They should be all the same per r_arr
    @results.each { |addr, r_arr|
      #      cam = nil
      #      r_arr.each { |r|
      #        if r.cam != nil
      #          cam = r.cam
      #          break
      #        end
      #      }
      #      next if cam == nil
      #
      #      suite_name  = cam.name
      suite_name  = @name
      run_name    = ""
      config_arr  = []
      config_ids  = []
      run_id      = nil

      r_arr.each { |r|
        proj_configs = rail.get_configs(proj_id) if proj_configs == nil
        config_arr = []
        proj_configs.each { |c|
          c["configs"].each { |conf|
            config_arr << conf if r.cmd.match(conf["name"]) != nil
          }
        }
        log_debug("Found configs %s" %config_arr.to_s)
        if config_arr != []
          conf_names = config_arr.map { |c| c["name"] }
          config_ids = config_arr.map { |c| c["id"] }
        end

        run_name = "#{@name}_#{@build}"
        log_debug("suite_name=%s, run_name=%s, configs=%s" \
        %[suite_name, run_name, config_ids])

        log_info("Looking up test suite #{suite_name}")
        suite_id = rail.get_suite_id(suite_name)

        # No configurations -> test RUN
        # Yes configurations -> test PLAN
        if config_arr == []
          add_test_run_result(rail, run_name, proj_id, suite_id, r_arr)
          break
        else
          add_test_plan_result(rail, run_name, proj_id, suite_id, r, config_ids)
        end
      } # end r_arr.each
    } # end @results.each
  end

  def add_test_plan_result(rail, run_name, proj_id, suite_id, test_result, config_ids)
    case_id = rail.get_case_id(test_result.test_file, suite_id)
    plan_id = rail.add_plan_if_not_exist(run_name, proj_id)
    plan_entry_name = test_result.test_file
    ##    p plan_id, plan_entry_name, case_id
    entry_id = rail.add_plan_entry_if_not_exist(plan_id, suite_id,
    name=test_result.test_file, assign_id=nil, incl_all=false,
    case_ids=[case_id], config_ids, runs=[])

    r = nil
    test_id = nil
    rail.get_plan(plan_id)["entries"].each { |entry|
      entry["runs"].each { |run|
        next if config_ids != run["config_ids"]
        rail.get_tests(run["id"]).each { |test|
          #p test_result, test
          if test_result.test_file == test["title"]
            r = test_result
            test_id = test["id"]
            break
          end
        }
        break if r != nil
      }
      break if r != nil
    }
    if r == nil
      log_warn("No matching test found for result #{test_result.test_file}")
      return
    end

    result = rail.passed
    if r.failed.length > 0 or
    r.errors.length > 0 or
    r.exitstat.exitstatus > 0
      result = rail.failed
    end

    s = "%s (Dur. %s) (PASS=%s, FAIL=%s, SKIP=%s, ERROR=%s) (Exit=%s)\n---\n" \
    %[r.test_file, r.duration,
      r.passed.length, r.failed.length, r.skipped.length,
      r.errors.length, r.exitstat.exitstatus]
    s += "\nDetail Test-Case Passes\n---\n"
    r.passed.each { |tc| s += format_result_testrail_str(r, tc) }
    s += "\nDetail Test-Case Skips\n---\n"
    r.skipped.each { |tc| s += format_result_testrail_str(r, tc) }
    s += "\nDetail Test-Case Errors/Failures\n---\n"
    r.failed.each { |tc| s += format_result_testrail_str(r, tc) }
    r.errors.each { |tc| s += format_result_testrail_str(r, tc) }

    log_info("Adding %s (%s) to run %s -- %s (%s)" \
    %[rail.result_str[result], result, run_name, r.test_file, test_id])
    log_debug("COMMENT STR: #{s}")
    rail.add_result(test_id, result, comment=s)
  end

  def add_test_run_result(rail, run_name, proj_id, suite_id, result_arr)
    run_id = rail.add_run_if_not_exist(run_name, proj_id, suite_id)
    rail.get_tests(run_id).each { |test|
      test_fname = test["title"]
      ##      p test
      # Find matching test result
      r = nil
      result_arr.each { |res|
        if res.test_file == test_fname
          r = res
          break
        end
      }
      # If no match, log warning and go to next
      if r == nil
        log_warn("No matching test result found for #{test_fname}.  Skipping.")
        next
      end

      result = rail.passed
      if r.failed.length > 0 or
      r.errors.length > 0 or
      r.exitstat.exitstatus > 0
        result = rail.failed
      end
      test_id = test["id"]

      s = "%s (Dur. %s) (PASS=%s, FAIL=%s, SKIP=%s, ERROR=%s) (Exit=%s)\n---\n" \
      %[r.test_file, r.duration,
        r.passed.length, r.failed.length, r.skipped.length,
        r.errors.length, r.exitstat.exitstatus]
      s += "\nDetail Test-Case Passes\n---\n"
      r.passed.each { |tc| s += format_result_testrail_str(r, tc) }
      s += "\nDetail Test-Case Skips\n---\n"
      r.skipped.each { |tc| s += format_result_testrail_str(r, tc) }
      s += "\nDetail Test-Case Errors/Failures\n---\n"
      r.failed.each { |tc| s += format_result_testrail_str(r, tc) }
      r.errors.each { |tc| s += format_result_testrail_str(r, tc) }

      log_info("Adding %s (%s) to run %s -- %s (%s)" \
      %[rail.result_str[result], result, run_name, r.test_file, test_id])
      log_debug("COMMENT STR: #{s}")
      rail.add_result(test_id, result, comment=s)
    }
  end

  # Return the formatted string for a testrail result comment
  # r - The result object
  # tc - The test-case result array (e.g. ["PASS", test1, "test passed"])
  def format_result_testrail_str(r, tc)
    return "`%s :: %s %s` \n" %[tc[1], tc[0], tc[2]]
  end

  # Steps:
  # 1) Add any missing test cases to the test-suite (under test section=test filename)
  # 2) Create the test run (name = test_file + configs?)
  # 3) Set the results
  def add_individual_results(proj_name, runlabel=nil)
    rail = TestRail.new(proj_name)
    suite_name = @name
    suite_id = rail.get_suite_id(suite_name)
    test_cases = []
    @results.each { |addr, result_arr|
      result_arr.each { |res|
        tc_sec_name = res.test_file.strip
        tc_sec = rail.add_section_if_not_exist(suite_id, tc_sec_name)
        tc_sec_id = tc_sec["id"]
        curr_cases = rail.get_cases(rail.proj_id, suite_id, tc_sec_id)

        # Hash using the titles as keys for quick lookup and search
        curr_cases_hash = {}
        curr_cases.each {|c| curr_cases_hash[c["title"].strip] = c}

        # Convert results to hashes for quick lookup
        # { TEST_CASE_NAME => COMMENT }
        passes, fails, skips, errors = {}, {}, {}, {}
        res.passed.each  { |x| passes[x[1].strip] = x[2] }
        res.failed.each  { |x| fails[x[1].strip] = x[2] }
        res.skipped.each { |x| skips[x[1].strip] = x[2] }
        res.errors.each  { |x| errors[x[1].strip] = x[2] }
        all_cases = passes.keys() + fails.keys() + skips.keys() + errors.keys()
        all_cases.sort! # Might as well

        # 1) Add the missing test cases to the test-suite
        already_added = Set.new()
        all_cases.each { |c|
          if already_added.include?(c)
            log_warn("Multiple results found for test-case #{c}.")
            log_warn("Please make sure test case names are unique.")
            next
          end
          if curr_cases_hash.key?(c)
            log_info("Test case #{c} already in #{suite_name} -- #{tc_sec_name}")
            this_case = curr_cases_hash[c]
          else
            log_info("Adding test case #{c} to #{suite_name} -- #{tc_sec_name}")
            this_case = rail.add_case(tc_sec_id, c)
          end
          if passes.include?(c)
            this_case["result"] = rail.passed
            this_case["comment"] = passes[c]
          elsif fails.include?(c)
            this_case["result"] = rail.failed
            this_case["comment"] = fails[c]
          elsif errors.include?(c)
            this_case["result"] = rail.failed
            this_case["comment"] = errors[c]
          end

          test_cases << this_case
          already_added << c
        }
      } # end results_arr.each
    } # end @results.each

    # At this point all out test cases should be in the test_cases array
    # 2) Create the test run using the test case ids from above
    test_case_ids = test_cases.map { |m| m["id"] }
    run_name = "#{suite_name}_#{@build}"
    run_name += "_#{runlabel}" if runlabel != nil
    run_id = rail.get_run_id(run_name)

    if run_id == false
      log_info("Adding test run: #{run_name}")
      run_data = rail.add_run(rail.proj_id, suite_id, name=run_name, desc=nil,
      mstone_id=nil, assign_id=nil, incl_all=false, case_ids=test_case_ids)
      run_id = run_data["id"]
    else
      log_info("Updating test run: #{run_name}")
      test_case_ids += rail.get_tests(run_id).map { |m| m["case_id"] }
      post_data = {}
      post_data["include_all"] = false
      post_data["case_ids"] = test_case_ids
      run_data = rail.update_run(run_id, post_data)
    end

    # 3) Set the results
    results_arr = { :results => [] }
    test_cases.each { |t|
      if t.key?("result")
        result_str = "PASS" if t["result"] == rail.passed
        result_str = "FAIL" if t["result"] == rail.failed
        log_info("Queueing #{result_str} for #{t["title"]}")
        results_arr[:results] << {
          :status_id => t["result"],
          :case_id => t["id"],
          :comment => t["comment"]
        }
      else
        log_warn("No result found for #{t["title"]}")
      end
    }
    log_info("Sending results to TestRail.")
    rail.add_results_for_cases(run_id, results_arr)
    log_info("All done.")
  end # end add_individual_results()
end # end ResultsHandler

include LogUtils

class Cam
  attr_accessor :addr, :release, :type, :build, :name, :media_dir
  def initialize
    @addr     = nil
    @release  = nil
    @type     = nil
    @build    = nil
    @name     = nil
    @media_dir = nil
  end
end

class Status
  attr_reader :exitstatus
  def initialize
    @exitstatus = 0
  end
end

# Parses a logfile and gets the relevant information
# basically create a copy of the Testrun object
def parse_logfile(f, options=nil)
  log_info("Opening file #{f}")
  tr = TestRunner.new(Cam.new)
  # Fake some variables until we add them to logs
  # TODO: add these into logs
  #  tr.duration = "Unk."
  tr.exitstat = Status.new()
  default_mode = nil

  File.open(f, "r").each do |line|
    # In the CONF section we need
    begin
      if line.match(ltp_re_str($CONF))
        temp = line.split(":")[1].split(",")
        key = temp[0].strip()
        val = temp[1].strip()
        if val != ""
          if key == "ip"
            tr.cam.addr = val
          elsif key == "serialdev"
            tr.cam.addr = val.split("//")[-1]
          elsif key == "name"
            tr.cam.name = val
          elsif key == "release"
            tr.cam.release = val
          elsif key == "type"
            tr.cam.type = val.to_i
          elsif key == "build"
            tr.cam.build = val
          elsif key == "cmd"
            tr.cmd = val
            tr.test_file = File.basename(val.split()[0])
          elsif key == "starttime"
            tr.start_time = DateTime.strptime(val, $LOG_TIME_STR)
          elsif key == "endtime"
            tr.end_time = DateTime.strptime(val, $LOG_TIME_STR)
          elsif key == "logfile"
            tr.log_file = val
          elsif key == "setup_default_mode"
            default_mode = val
          elsif key == "media_dir"
            tr.cam.media_dir = val
          end
        end
      elsif line.match(ltp_re_str($PASS))
        temp = line.split(":")
        result, tc, msg = temp[0], temp[1], temp[2..-1].join(":")
        tr.passed << [result, tc, msg]
        tr.total += 1
      elsif line.match(ltp_re_str($FAIL))
        temp = line.split(":")
        result, tc, msg = temp[0], temp[1], temp[2..-1].join(":")
        tr.failed << [result, tc, msg]
        tr.total += 1
      elsif line.match(ltp_re_str($SKIP))
        temp = line.split(":")
        result, tc, msg = temp[0], temp[1], temp[2..-1].join(":")
        tr.skipped << [result, tc, msg]
        tr.total += 1
      elsif line.match(ltp_re_str($ERR))
        temp = line.split(":")
        result, tc, msg = temp[0], temp[1], temp[2..-1].join(":")
        tr.errors << [result, tc, msg]
        tr.total += 1
      # Don't know a better way to do it other than manually checking if its a BAT log. (TBD)
      # Puts all warnings (which includes JSON comparison ) from BAT result into Misc Information:
    elsif File.basename(f).start_with?("test_hawaii_bat") || File.basename(f).start_with?("test_australia_bat") \
        || File.basename(f).start_with?("test_margaretriver_bat")
        if line.match(ltp_re_str($WARN))
          temp = line.split(":")
          result, tc, msg = temp[0], temp[1], temp[2..-1].join(":")
          tr.warns << [result, tc, msg]
          tr.total += 1
        end
      end

    rescue ArgumentError => e
      log_warn("#{e.to_s}.  Skipping line: '#{line[0..30]}'")
    end
  end
  # Verify that we have everything we need to complete the parsing
  req_arg = [tr.cam.name, tr.cam.release, tr.cam.type, tr.cam.build]
  if req_arg.include?(nil)
    log_warn("Missing necessary camera info in log")
    log_info("name=%s, release=%s, type=%s, build=%s" %req_arg)
    log_info("'git checkout' an older resultsHandler may work")
    return nil
  end

  if tr.start_time != nil and tr.end_time != nil
    # Subtracting Date objects gets you difference in *days* and we need seconds
    diff_s = (tr.end_time - tr.start_time) * 24 * 60 * 60
    tr.duration = Time.at(diff_s).utc.strftime("%H:%M:%S")
  else
    tr.duration = "Unk."
  end

  # Add the default mode to the test-file if appropriate arg flagged
  if (options[:deflabel] == true and default_mode != nil and default_mode.length > 0)
    tr.test_file = tr.test_file + "-default_mode_#{default_mode.downcase}"
  end
  return tr
end # end parse_logfile

if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  # defaults
  options = {}
  options[:dir]           = nil
  options[:email]         = false
  email_to_addr = "fw-test-auto@gopro.com"
  options[:individual]    = false
  options[:build]         = nil
  options[:verb]          = false
  options[:runlabel]      = nil
  options[:deflabel]      = false

  op = OptionParser.new do |opts|
    opts.banner = "Usage: ruby resultsHandler.rb -d [DIR] -m -t -v -h"
    opts.on("-d", "--dir DIR", "Directory containing test run logs") \
    { |o| options[:dir] = o }
    opts.on("-m", "--mail [ADDR]", "E-mail results (default fw-test-auto@gopro.com)") \
    { |o| options[:email] = true; email_to_addr = o if o != nil }
    opts.on("-i", "--individual", "Report individual results into TestRail") \
    { |o| options[:individual] = true }
    opts.on("-v", "--verb", "Verbose logging") \
    { |o| options[:verb] = true }
    opts.on("-b", "--build BUILD_STR", "Override the build string") \
    { |o| options[:build] = o }
    opts.on("-u", "--runlabel STRING", "Label to append to the test run name") \
    { |o| options[:runlabel] = o }
    opts.on("-e", "--deflabel", "Append default mode to test file name for TestRail reporting") \
    { |o| options[:deflabel] = true }
    opts.on("-h", "--help", "Display this message and exit") \
    { puts op; exit }
  end
  op.parse!(ARGV)

  $LOGLEVEL = $LL_VERB if options[:verb] == true
  log_dir = options[:dir]
  if log_dir == nil or not File.exists?(log_dir)
    log_warn("Unable to find directory '#{log_dir}'")
    puts op
    exit 1
  end

  if File.file?(log_dir)
    r_arr = [parse_logfile(log_dir)]
  elsif File.directory?(log_dir)
    r_arr = []
    Dir.glob(File.join(log_dir, "**", "test_*.log")).each { |f|
      parsed = parse_logfile(f, options)
      r_arr << parsed if parsed != nil
    }
    if r_arr.empty?
      log_error("No valid logs found! Must begin with 'test' and end in '.log'")
      exit 1
    end
  else
    log_error("#{log_dir} is not a file or a directory?! Exiting.")
    exit 1
  end

  rh = ResultsHandler.new(r_arr, options[:build])
  puts rh.standard_report()

  if options[:individual] == true
    rh.add_individual_results("(FWQA) Automation", options[:runlabel])
  end
  if options[:email] == true
    rh.email_report(email_to_addr, "[AUTO RESULTS]", log_dir, options[:runlabel])
  end
end
