# camera.rb
require 'net/http/persistent'
require 'json'
require 'uri'
require 'fileutils'
require 'socket'
require 'timeout'
require 'pp'
require 'serialport'

require_relative 'camera'
require_relative 'exitcodes'
require_relative 'log_utils'
require_relative 'metadata'
require_relative 'wifi_commands'
require_relative 'host_utils'

class WifiCameraError < StandardError
end

class WifiCamera < Camera
  attr_accessor :ip, :port, :http_port, :pairing_code, :autoconnect,
  :serialno, :fw_file, :wait_after_cmd, :serial_iface, :system_address,
  :save_ts_file, :save_ts_filename, :squelch_status, :media_dir, :temp_json_loc
  attr_reader :screens, :release, :type, :addr, :build, :name,
  :ssid, :mac, :wifi_version,
  :analytics_version,
  :audio_channels,
  :audio_codec,
  :audio_sample_rate,
  :audio_bitrate,
  :chg_prev_br_support,
  :chg_prev_res_support,
  :colorspace,
  :video_codec,
  :defaults,
  :setup,
  :looping_chapter_len,
  :photo_modes,
  :preview,
  :protune_white_balance_values,
  :protune_color_values,
  :protune_sharpness_values,
  :protune_exposure_values,
  :photo_protune_modes,
  :photo_protune_iso_values,
  :photo_protune_iso_min_values,
  :video_protune_modes,
  :video_protune_iso_values,
  :video_capture_modes,
  :video_timelapse_capture_modes,
  :multi_protune_modes,
  :last_video_enc,
  :curr_status,
  :decoded_curr_status,
  :curr_bacpac_status,
  :remote_api_version,
  :data_log_model,
  :keepalive_thread,
  :receive_thread,
  :test_preview_stream,
  :photo_ts,
  :capture_modes,
  :chapter_size,
  :hour,
  :min,
  :sec,
  :hilight_tag_limit,
  :streaming_port,
  :settings_json_hash

  include WifiCommands
  include LogUtils
  def initialize(ip, pc, serial=nil, log_path=nil)
    super()
    @ip                   = ip  # Keeping 'ip' because it is used all over the code. Camera's access point
    @system_address       = nil
    @addr                 = ip  # 'addr' works for both wi-fi and serial
    @port                 = 80  # For wifi commands
    @http_port            = 8080   # For http server commands
    @streaming_port       = 8554
    @http                 = Net::HTTP::Persistent.new("Camera@#{ip}")
    @wait_after_cmd       = 1.0
    #    @pairing_code         = (pc != nil) ? pc : get_pairing_code()
    @pairing_code         = pc
    @interfaces           << :wifi
    @curr_status          = nil
    @decoded_curr_status  = nil # more easily readable
    @scale_mins_avail     = false
    @remote_api_version   = nil
    @settings_json_hash   = nil
    @temp_json_loc        = "/tmp/settings.json"
    @stop_requested       = false
    @receive_thread       = nil
    @keepalive_thread     = nil
    @keepalive_socket     = nil
    @save_ts_file         = false
    @serial_iface         = serial # Non-null if also has a serial interface
    @linux_iface          = nil
    @do_exit              = false
    @squelch_status       = false
    @curr_t               = 0
    @last_t               = 0

    # Capture console logs to log_path
    if @serial_iface != nil
      log_path = "/tmp/test.log" if log_path == nil
      # @linux_iface: Just assume it is serial_iface + 1
      n1 = @serial_iface[-5..-1].scan(/\d/)[0]
      n2 = n1.to_i + 1
      @linux_iface = @serial_iface[0...@serial_iface.index(n1)] + n2.to_s
      log_info("Linux serial port not specified.  Trying #{@linux_iface}")

      # Fatally exit if these fail
      if init_amba_serial_log(File.dirname(log_path), File.basename(log_path)) == false
        exit ExitCode.to_s(ExitCode::ERROR)
      elsif spawn_amba_logging_thread(@serial_iface) == false
        exit ExitCode.to_s(ExitCode::ERROR)
      end

      # Just warn if these fail
      if init_linux_serial_log(File.dirname(log_path), File.basename(log_path)) == false
        log_warn("Error initializing Linux log")
      elsif spawn_linux_logging_thread(@linux_iface) == false
        log_warn("Error spawning Linux logging thread")
      end
    end

    # First try Camera/Bacpac 'cv' commands
    log_info("Looking for camera via two-letter commands...")
    @ssid, @mac, @wifi_version  = get_bacpac_info()
    @release, @type, @build     = get_cam_info()
    # Really just need release and type to determine camera
    if [@release, @type].include?(nil)
      # Try DNS service discovery for newer cameras
      log_info("Looking for camera via mDNS...")
      info = get_cam_info_dnssd()
      if info != nil
        @serialno   = info[:sn]
        @fw_version = info[:fw]
        @mac        = info[:mac]
        @release    = info[:rel]
        @type       = info[:type]
        @build      = info[:build]
      end
    end
    if [@release, @type].include?(nil)
      # Last ditch effort to get camera info
      log_warn("camera/cv, mDNS both didn't work.  Trying settings JSON")
      get_settings_json_hash
      @ssid       = @settings_json_hash["info"]["ap_ssid"]
      @mac        = @settings_json_hash["info"]["ap_mac"]
      @serialno   = @settings_json_hash["info"]["serial_number"]
      @fw_version = @settings_json_hash["info"]["firmware_version"]
      @release    = @fw_version.split(".")[0]
      @type       = @fw_version.split(".")[1].to_i
      @build      = @fw_version.split(".")[2..-1].join(".")
    end

##### TODO: REMOVE THIS! ###################
    # NASTY KLUDGE FOR SUPERBANK. ##########
    if pc and pc.start_with?("SUPERBANK_") #
      @release = "SUPERBANK" ###############
      @type = 1 ############################
      pc.sub!(/SUPERBANK_/,"") #############
    end ####################################
############################################

    if @release == "HD3" and @type == 1 #US version
      require_relative 'camera_white'
      extend White
    elsif   @release == "HD3" and @type == 9  #europe version
      require_relative 'camera_white'
      extend White
    elsif @release == "HD3" and @type == 2
      require_relative 'camera_silver'
      extend Silver
    elsif @release == "HD3" and @type == 3
      require_relative 'camera_black'
      extend Black
    elsif @release == "HD3" and @type == 10
      require_relative 'camera_silver_plus'
      extend SilverPlus
    elsif @release == "HD3" and @type == 11
      require_relative 'camera_black_plus'
      extend BlackPlus
    elsif @release == "HD4" and @type == 1
      require_relative 'camera_backdoor'
      extend Backdoor
    elsif @release == "HD4" and @type == 2
      require_relative 'camera_pipe'
      extend Pipe
    elsif @release == "HD5" and @type == 1
      require_relative 'camera_squirrels'
      extend Squirrels
    elsif @release == "HD5" and @type == 2
      require_relative 'camera_streaky'
      extend Streaky
    elsif @release == "SUPERBANK" and @type == 1 # This probably isn't right.
      require_relative 'camera_superbank'
      extend Superbank
    elsif @release == "HD5" and @type == 3    # Still need to verify
      require_relative 'camera_margaretriver'
      extend MargaretRiver
    elsif @release == "HX1" and @type == 1
      require_relative 'camera_rockypoint'
      extend Rockypoint
      extend WifiCommands_RP_api2
    elsif @release == "HD3" and @type == 21
      require_relative 'camera_haleiwa'
      extend Haleiwa
      extend WifiCommands_HLWA_api2
    elsif @release == "HD3" and @type == 22
      require_relative 'camera_himalayas'
      extend Himalayas
      extend WifiCommands_HIMA_api2
    else
      log_error("Unsupported wifi camera (release=#{@release}, type=#{@type})")
      exit 1
    end

    init()
    log_conf("name, #{@name}")
    get_remote_api_version
    if @remote_api_version == 2
      get_settings_json_hash
      begin
        @ssid = @settings_json_hash["info"]["ap_ssid"] if @ssid == nil
        @serialno = @settings_json_hash["info"]["serial_number"] if @serialno == nil
      rescue StandardError => e
        log_warn("Unable to get SSID/CSN info from settings JSON")
        log_warn(e.to_s)
      end
    end

    log_info("Camera Info (some may be missing)")
    log_conf("serialno, #{@serialno}")
    log_conf("ssid, #{@ssid}")
    log_conf("mac, #{@mac}")
    log_conf("wifi_ver, #{@wifi_version}")
    log_conf("release, #{@release}")
    log_conf("type, #{@type}")
    log_conf("build, #{@build}")
    enable_preview() if @test_preview_stream == true
  end

  def get_remote_api_version
    if defined?(@remote_api) == nil
      log_error("Unknown remote api version")
      exit ExitCode::UNKNOWN_REMOTE_API_VERSION if @do_exit
      return false
    end
    @remote_api_version = @remote_api
  end

  def get_settings_json_hash
    @settings_json_hash = get_settings_json()
    if @settings_json_hash.empty?
      log_error("Settings JSON is empty")
      exit ExitCode::EMPTY_SETTINGS_JSON if @do_exit
      return false
    elsif @settings_json_hash.include?("error_code")
      log_error("Settings JSON has error")
      exit ExitCode::ERROR_IN_SETTINGS_JSON if @do_exit
      return false
    end
    return true
  end

  #remote_api_version =2 doesn't require pairing code
  def get_pairing_code()
    if @remote_api_version == 1
      resp = get(:bacpac_ap_key, nil, wait_time=0.5, decode=true, expected=nil,
      tries=3, interval=5, target="bacpac")
      if resp.is_a?(Hash) and resp.has_key?(:ap_key)
        log_info("AP key found: #{resp[:ap_key]}")
        return resp[:ap_key]
      else
        log_error("Unable to get AP KEY via 'sd' command")
        exit 1 if @do_exit
        return false
      end
    end
  end

  # Must be done just as SMARTY would
  def enable_preview()
    if @remote_api_version == 1
      resp = set(:preview_pv, "ON", wait_time=0.5, decode=true, expected=nil,
      tries=3, interval=5, target="camera")
      if resp.is_a?(Hash) and resp.has_key?(:success) and resp[:success] == true
        log_info("Preview enabled successfully")
      else
        log_error("Unable to turn on preview")
        exit 1 if @do_exit
        return false
      end
    end
  end

  def get_bacpac_info()
    ssid, mac, wifi_ver = nil, nil, nil
    begin
      resp = decode_bacpac_cv(get_bacpac_resp(bacpac_cv[:get], nil, false), nil)
    rescue WifiCameraError => e
      log_warn(e.to_s)
    end
    if resp.is_a?(Hash) and resp.has_key?(:success) and resp[:success] == true
      ssid, mac, wifi_ver = resp[:ssid], resp[:mac], resp[:wifi_ver]
    else
      log_warn("Unable to retrieve bacpac information")
    end
    return ssid, mac, wifi_ver
  end

  def get_cam_info()
    cam_release, cam_type, cam_build = nil, nil, nil
    begin
      cam_info_resp = get_camera_resp(cam_info[:get], nil, false)
    rescue WifiCameraError => e
      log_warn(e.to_s)
    end
    if not http_resp_ok(cam_info_resp) or \
      cam_info_resp == nil or \
      cam_info_resp.body == nil
        log_warn("Unable to retrieve camera information")
    else
      cam_release = cam_info_resp.body[4..6].to_s
      cam_type    = cam_info_resp.body[8..9].to_i
      case cam_release
      when "HD4", "HD5"
        # Example: HD4.02.01.02.00 --> '01.02.00'
        cam_build = cam_info_resp.body[11..18].to_s
      else
        # Example: HX1.01.00.24 --> '00.24'
        cam_build   = cam_info_resp.body[11..15].to_s
      end
    end
    return cam_release, cam_type, cam_build
  end

  def update_cam_info()
    @release, @type, @build = get_cam_info()
  end

  def update_cam_info_dnssd()
    cam_info = get_cam_info_dnssd()
    @release = cam_info[:rel]
    @type = cam_info[:type]
    @build = cam_info[:build]
  end

  # Get camera info via DNS Service discovery (aka mDNS)
  # Should work on HAWAII/RKPT/HAL
  # Will need to be modified if >1 camera is on the WLAN
  # Returns nil on failure
  def get_cam_info_dnssd()
    begin
      #Check if dnssd gem is not loaded
      raise if Gem.loaded_specs.keys.include?("dnssd") == false and (require 'dnssd') != true
    rescue LoadError, RuntimeError => e
      log_warn("'dnssd' gem failed to load. Unable to perform mDNS discovery.")
      return nil
    end

    wake_reply = web_reply = nil
    begin
      timeout(5) {
        DNSSD.browse('_gopro-wake._udp') { |r| wake_reply = r } # QCA chip
        DNSSD.browse('_gopro-web._tcp') { |r| web_reply = r } # A9
        while wake_reply == nil and web_reply == nil
          sleep 1
        end
      }
    rescue Timeout::Error
    end

    info = nil
    if wake_reply == nil
      log_warn("Did not see any gopro-wake service.  Is camera connected?")
      if web_reply == nil
        log_warn("Did not see gopro-web service.  Is camera awake?")
      else
        log_warn("Somehow see gopro-web service without wake service.")
      end
    else
      # At least we got the wake reply, which is what we use to resolve
      info = dnssd_resolve(wake_reply)
    end
    return dnssd_parse_wake(info)
  end

  def dnssd_resolve(reply)
    log_info("Resolving #{reply.fullname}")
    result = nil
    begin
      timeout(5) {
        DNSSD.resolve(reply) { |r| result = r }
        while result == nil
          sleep 1
        end
      }
    rescue Timeout::Error
    end
    log_warn("Resolving failed") if result == nil
    return result
  end

  def dnssd_parse_wake(info)
    return nil if info == nil
    t = info.text_record
    ver = t["protocol_version"].to_i
    {
      1 => {
      :sn     => info.name,
      :mac    => t["mac_address"],
      :fw     => t["fw_version"],
      :rel    => t["fw_version"][0..2],
      :type   => t["fw_version"][4..5].to_i,
      :build  => t["fw_version"][7..-1],
      }
    }[ver]
  end

  # Used for gpControl throttling to reduce fifo overruns, unpredictable camera behavior
  # Keep a miniumum of a 500ms gap between any wifi commands or queries to the camera
  # TODO: Include host_util::wget(), curl(), curlable?() in this timing as well
  def wifi_throttle(id="")
    @last_t = @curr_t
    @curr_t = (Time.now.to_f * 1000.0).to_i # time in ms
    t_diff = @curr_t - @last_t
    if (t_diff < 500)
      t_sleep = (500.0-t_diff)/1000.0
      log_debug("#{id}->wifi_throttle: t_sleep=#{t_sleep}s")
      sleep(t_sleep)
    end
  end

  def http_get_noraise(url, do_retry=true)
    try = 1
    retries = 4
    retry_interval = 5
    wifi_throttle("http_get")
    begin
      @http.open_timeout = 10
      @http.request(URI(url))  # THIS IS THE RETURN VALUE if there are no errors
    rescue Timeout::Error,
    Errno::ECONNRESET,
    Errno::EHOSTUNREACH,
    Errno::EHOSTDOWN,
    Errno::ECONNREFUSED,
    Errno::ENETUNREACH,
    Net::HTTP::Persistent::Error => e
      return nil, "Communication error.  Not retrying." if do_retry != true
      if try <= retries
        sleep retry_interval
        log_warn("#{Time.now} \t Retrying #{try} \t #{e.message} #{url}")
        try += 1
        if try > 3
          log_info("This retry includes bouncing the wifi connection on the host.")
          temp_host = Host.new
          temp_host.bounce_wifi()
          sleep( 10 )
        end
        if try > 2
          log_info("This retry includes a shutdown and recreation of the connection.")
          @http.shutdown
          @http = Net::HTTP::Persistent.new("Camera@#{ip}")
        end
        retry
      else
        s = "Unable to communicate from host to camera (#{@ip})"
        log_warn(s)
        return nil, s
      end
    rescue StandardError => e
      s = "OTHER ERROR => #{e.to_s}"
      log_warn(s)
      return nil, s
    end
  end

  def http_get(url, do_retry=true)
    log_info("#{Time.now} \t #{url}")
    try = 1
    retries = 3
    retry_interval = 5
    wifi_throttle("http_get")
    begin
      @http.open_timeout = 10
      @http.request(URI(url))
    rescue Timeout::Error,
    Errno::ECONNRESET,
    Errno::EHOSTUNREACH,
    Errno::EHOSTDOWN,
    Errno::ECONNREFUSED,
    Errno::ENETUNREACH,
    Net::HTTP::Persistent::Error => e
      raise WifiCameraError, "Communication error.  Not retrying." if do_retry != true
      if try <= retries
        sleep retry_interval
        log_warn("#{Time.now} \t Retrying #{try} \t #{e.message} #{url}")
        try += 1
        if try > 2
          log_warn("This retry includes a shutdown and recreation of the connection.")
          @http.shutdown
          @http = Net::HTTP::Persistent.new("Camera@#{ip}")
        end
        retry
      else
        s = "Unable to communicate from host to camera (#{@ip})"
        if @do_exit
          log_error(s)
          exit ExitCode::NO_CONNECTION
        end
        log_warn(s)
        raise WifiCameraError, s
      end
    rescue StandardError => e
      s = "OTHER ERROR => #{e.to_s}"
      if @do_exit
        log_error(s)
        exit ExitCode::ERROR
      end
      log_warn(s)
      raise WifiCameraError, s
    end
  end

  def make_url(ip, port, target, cmd, param=nil)
    param_str = @pairing_code == nil ? "" : "?t=#{@pairing_code}"
    param_str += param == nil ? "" : "&p=#{param}"
    return "http://#{ip}:#{port}/#{target}/#{cmd}#{param_str}"
  end

  def make_camera_url(cmd, param); return make_url(@ip, @port, 'camera', cmd, param); end

  def make_bacpac_url(cmd, param); return make_url(@ip, @port, 'bacpac', cmd, param); end

  def make_ota_update_url(); return "http://#{@ip}:#{@http_port}/gp/gpUpdate"; end

  def make_gpcontrol_url; "http://#{@ip}/gp/gpControl"; end

  def make_gpexec_url; "http://#{ip}/gp/gpExec"; end

  def make_status_url; "#{make_gpcontrol_url}/status" ; end

  def get_camera_resp(cmd, param=nil, do_retry=true)
    return http_get(make_camera_url(cmd, param), do_retry)
  end

  def get_bacpac_resp(cmd, param=nil, do_retry=true)
    return http_get(make_bacpac_url(cmd, param), do_retry)
  end

  def get_gpmedialist()
    url = "http://#{@ip}:#{@http_port}/gp/gpMediaList"
    http_get(url)
  end

  def get_metadata(file)
    url = "http://#{@ip}/gp/gpMediaMetadata?p=#{file}&t=exif"
    return http_get(url)
  end

  def get_parsed_gpmedialist
    sleep 3
    begin
      resp = get_gpmedialist
      JSON.parse(resp.body)
    rescue StandardError, WifiCameraError
      if @do_exit
        log_error("Unable to get/parse gpMediaList")
        exit ExitCode::ERROR_PARSING_GPMEDIALIST
      else
        log_warn("Unable to get/parse gpMediaList")
        return false
      end
    end
  end

  # Created to support test_wifi_stress.rb w/o raising exceptions
  def http_gpcontrol_check
    begin
      resp = http_get_noraise(make_status_url)
      JSON.parse(resp.body)
    rescue StandardError, WifiCameraError
      log_warn("Unable to parse settings json")
      return false
    end
  end

  def get_settings_json
    begin
      resp = http_get(make_gpcontrol_url)
      JSON.parse(resp.body)
    rescue StandardError, WifiCameraError
      if @do_exit
        log_error("Unable to parse settings json")
        exit ExitCode::ERROR_PARSING_SETTINGS_JSON
      else
        log_warn("Unable to parse settings json")
        return false
      end
    end
  end

  #get status json
  def send_status_api2
    http_get(make_status_url)
  end

  #update camera settings
  def send_setting_api2(id, value)
    url = "#{make_gpcontrol_url}/setting/#{id}/#{value}"
    http_get(url)
  end

  # Change mode only.
  # Does not seem to error on invalid input,
  # however status will be 255 for mode field
  def send_mode(mode_value)
    url = "#{make_gpcontrol_url}/command/mode?p=#{mode_value}"
    http_get(url)
  end

  #change mode and submode
  def send_mode_submode_api2(mode_value, submode_value)
    url = "#{make_gpcontrol_url}/command/sub_mode?mode=#{mode_value}&sub_mode=#{submode_value}"
    http_get(url)
  end

  #shutter: /command/shutter
  def send_shutter_api2(value)
    url = "#{make_gpcontrol_url}/command/shutter?p=#{value}"
    http_get(url)
  end

  #date_time - in hex
  #year - start with 2000. 2014 means 0x0E
  #hour - military time. 4pm mean 0x10
  #Example to set 2014-07-17 4:36pm => p=%0E%07%11%10%24%00
  def send_date_time_api2(date_time)
    url = "#{make_gpcontrol_url}/command/setup/date_time?p=#{date_time}"
    http_get(url)
  end

  #video protune reset
  def send_video_protune_reset
    url = "#{make_gpcontrol_url}/command/video/protune/reset"
    http_get(url)
  end

  #photo protune reset
  def send_photo_protune_reset
    url = "#{make_gpcontrol_url}/command/photo/protune/reset"
    http_get(url)
  end

  #multi_photo protune reset
  def send_multi_photo_protune_reset
    url = "#{make_gpcontrol_url}/command/multi_shot/protune/reset"
    http_get(url)
  end

  #delete all:
  def send_delete_all_api2
    url = "#{make_gpcontrol_url}/command/storage/delete/all"
    http_get(url)
  end

  #delete last
  def send_delete_last_api2
    url = "#{make_gpcontrol_url}/command/storage/delete/last"
    http_get(url)
  end

  #delete a file
  def send_delete_file_api2(filename)
    url = "#{make_gpcontrol_url}/command/storage/delete?p=#{filename}"
    http_get(url)
  end

  # Hilight tag (tag my moments)
  def send_tag_hilight_api2()
    url = "#{make_gpcontrol_url}/command/storage/tag_moment"
    http_get(url)
  end

  def send_tag_hilight_playback_api2(f, offset)
    url = "#{make_gpcontrol_url}/command/storage/tag_moment/playback?p=#{f}&tag=#{offset}"
    http_get(url)
  end

  #locate camera: 1 = ON, 0 = OFF
  def send_locate_camera_api2(value)
    url = "#{make_gpcontrol_url}/command/system/locate?p=#{value}"
    http_get(url)
  end

  def send_camera_sleep_api2
    url = "#{make_gpcontrol_url}/command/system/sleep"
    http_get(url)
  end

  #OTA Start
  def send_fwupdate_start
    url = "#{make_gpcontrol_url}/command/fwupdate/download/start"
    http_get(url)
  end

  #OTA Done
  def send_fwupdate_done
    url = "#{make_gpcontrol_url}/command/fwupdate/download/done"
    http_get(url)
  end

  # OTA Cancel download
  def send_fwdownload_cancel
    url = "#{make_gpcontrol_url}/command/fwupdate/download/cancel"
    http_get(url)
  end

  def send_live_stream_start
    url = "#{make_gpcontrol_url}/execute?p1=gpStream&c1=restart"
    http_get(url)
  end

  def send_live_stream_start_v2
    url = "#{make_gpcontrol_url}/execute?p1=gpStream&a1=proto_v2&c1=restart"
    http_get(url)
  end

  def send_live_stream_stop
    url = "#{make_gpcontrol_url}/execute?p1=gpStream&c1=stop"
    http_get(url)
  end

  def get_analytics_url; "#{make_gpcontrol_url}/analytics/get"; end

  def get_analytics; http_get(get_analytics_url); end

  def clear_analytics_url; "#{make_gpcontrol_url}/analytics/clear"; end

  def clear_analytics; http_get(clear_analytics_url); end

  # Returns true if HTTP response code is OK (200).
  # Input is the returned value of @http.request (called in http_get())
  def http_resp_ok(resp)
    return false if defined?(resp.code) == nil
    begin
      r = resp.code.to_i
    rescue StandardError => e
      log_error("Error reading http response: #{e.to_s}")
      return false
    end
    # TODO: make sure Http has these class vars.
    if r == 200
      log_verb("HTTP status OK (#{r})")
      return true
    else
      log_debug("HTTP status (#{r}) not OK (200)")
      log_debug("Check command validity / pairing code?") if r == 410
      return false
    end
  end

  # Send a command to the camera and optionally verify the state/retry
  # Args:
  #   wifi_cmd:    One of the methods (name) from wifi.rb (e.g. "vid_res")
  #   key:        The human-readable setting (e.g. "1080")
  #   wait_time:  Time to wait after issuing the command
  #   decode:     Decode the response into a hash (see wifi_decode.rb)
  #   expected:   Expected value of the response.  Only used if decode=true
  #               nil - Match detected == key
  #               [VALUE] - Match detected == [VALUE]
  #   tries:      Number of attempts to retry a command
  #   interval:   Time to wait between command retries
  #   target:     "camera" or "bacpac"
  #   get:        Override set and do a get instead
  #
  # Returns:
  #   http response on success
  #   false on failure
  # TODO: add bacpac argument so bacpac can use this too
  def set(wifi_name, key=nil, wait_time=@wait_after_cmd, decode=true, expected=nil,
    tries=3, interval=5, target="camera", get=false)

    #    wait_until_not_busy if (wifi_name != :shutter_sh and @remote_api_version == 2)
    wait_until_not_busy if wifi_name != :shutter_sh

    return set_api2(wifi_name, key) if @remote_api_version == 2 && !get

    wifi_cmd = method(wifi_name).call()

    # Just for script debugging.  Should not hit in real runs.
    if (key != nil) and !(wifi_cmd.has_key?(key))
      #TODO: should be the NAME of the wifi_cmd variable... wifi_cmd.__name__ or something?
      puts "Param #{key} not found for wifi cmd #{wifi_cmd}"
      puts "Check script"
      return false
    end

    # Choose SET or GET
    cam_cmd = (get == true) ? :get : :set

    # Some commands use the key while others just use :set/:get
    if key == nil
      value = nil
      param_str = ""
    else
      value = wifi_cmd[key]
      param_str = "val=#{key} (#{value})"
    end
    log_info("#{target} #{cam_cmd} cmd=#{wifi_cmd[cam_cmd]} #{param_str}")

    # If the :set or :get commands return bad HTTP response, retry them
    (1..tries).each do |n|
      log_verb("Try #{n} of #{tries}")

      # Issue the command to the camera or bacpac
      resp = get_camera_resp(wifi_cmd[cam_cmd], value) if target == "camera"
      resp = get_bacpac_resp(wifi_cmd[cam_cmd], value) if target == "bacpac"

      if http_resp_ok(resp)
        sleep wait_time if wait_time > 0.0

        # No further waiting or processing if decode is false (useful for OTA update)
        return resp if decode == false

        if expected == nil
          if get
            return decode_resp(wifi_cmd, nil, resp, nil)
            #set
          else
            return decode_resp(wifi_cmd, key, resp, wifi_cmd[key])
          end
        else
          return decode_resp(wifi_cmd, key, resp, wifi_cmd[expected])
        end
      end

      if defined?(resp.code)
        s = "Bad HTTP response #{resp.code}. Retrying in #{interval} seconds."
      else
        s = "Bad HTTP response (resp=#{resp}). Retrying in #{interval} seconds."
      end
      log_warn(s)
      sleep interval

    end # end :set/:get command retries loop

    # Just log INFO and assume caller handles logging test failure/error
    log_info("Command retries timed out")
    return false
  end # end set

  def set_api2(wifi_name, key, wait_time=@wait_after_cmd, decode=true)
    # Initialize response structure via the decode function
    # Should yield {:success=> false, :expected=> nil, :detected=> nil}
    retval = decode_api2_resp(nil, nil, nil)

    id, expected_value = get_id_value(wifi_name, key)
    # Should not hit in finished scripts.
    # If you do hit this it means some values in wifi_commands.rb needs to be updated
    if id == nil or expected_value == nil
      log_warn("nil id (#{id}) or expected value (#{expected_value}).")
      return nil
    end

    resp = send_setting_api2(id, expected_value)
    sleep wait_time if wait_time > 0.0
    if not http_resp_ok(resp)
      if defined?(resp.code) == nil
        s = "#{resp}"
      else
        s = "#{resp.code}"
      end
      log_warn("Bad HTTP response (#{s})")
      return retval
    end

    if decode
      wait_until_not_busy(interval=1.0, timeout=5)
      refresh_status
      status_value = get_setting_status_api2_by_id(id)
      retval = decode_api2_resp(resp, expected_value, status_value)
    else
      retval = resp
    end

    return retval
  end

  # Convenience command to perform a GET
  def get(wifi_cmd, key=nil, wait_time=@wait_after_cmd, decode=true, expected=true,
    tries=3, interval=5, target="camera")
    set(wifi_cmd, key, wait_time, decode, expected, tries, interval, target, get=true)
  end

  # Returns true or false on success
  # Returns nil, msg on failure
  def already_set?(wifi_name, key)
    #log_info("Checking already set #{wifi_name} - #{key}")
    set = false, "#{wifi_name} not already set to #{key}"

    if @remote_api_version == 1
      sleep 1
      if method(wifi_name).call[key].to_s.upcase == wifi_itohs(get_status(wifi_name)).to_s.upcase
        set = true, "#{wifi_name} already set to #{key}"
      else
        set = false, "#{wifi_name} not already set to #{key}"
      end
    end

    if @remote_api_version == 2
      id, expected_value = get_id_value(wifi_name, key)
      return nil, "Could not get id_value of #{wifi_name} with #{key}" if id == nil

      status_value = get_setting_status_api2_by_id(id) #SAVE
      return nil, "Could not get status value of #{wifi_name} with #{key}" if status_value == false

      set = status_value.to_s.upcase == expected_value.to_s.upcase, "#{wifi_name} already set to #{key}"
    end
    return set
  end

  #After each set, do further checking to make sure camera is really set. First do a GET, then check in SX
  def saved_in_sx?(wifi_cmd, key)
    get = false

    #verify using GET
    expected = method(wifi_cmd).call[key]
    resp = get_camera_resp(method(wifi_cmd).call[:get])

    if http_resp_ok(resp)
      sleep 0.5
      detected = wifi_itohs(resp.body[1].ord)
      get = (detected.to_s.upcase == expected.to_s.upcase)
    else
      if defined?(resp.code) == nil
        s = "#{resp}"
      else
        s = "#{resp.code}"
      end
      log_warn("Bad HTTP response (#{s})")
    end

    #verify in SX
    sx = already_set?(wifi_cmd, key)[0]
    return get &= sx
  end

  # Call the decode method
  # wifi_cmd - The wifi command hash (e.g. vid_res)
  # key - Value that was set (e.g. "1080")
  # resp - The http_get response returned from http_get()
  # exp - The expected value. Used to determine command success
  def decode_resp(wifi_cmd, key, resp, exp)
    if wifi_cmd.has_key?(:ret)
      return wifi_cmd[:ret].call(resp, wifi_cmd[key], exp)
    else
      log_warn("wifi command does not have ':ret' key.")
      log_warn("Consider adding or skipping decode (expected=nil)")
      return false
    end
  end

  def set_orientation(o)
    a_set = already_set?(:setup_orientation, o)

    if a_set[0] == false
      success = false
      resp = set(:setup_orientation, o)

      success = (saved_in_sx?(:setup_orientation, o) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set orientation to #{o} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set orientation to #{o} successful"
  end

  # Set the capture mode
  # See available modes in wifi_commands.rb
  def set_capture_mode(m)
    return set_capture_mode_api2(m) if @remote_api_version == 2

    a_set = already_set?(:mode_cm, m)

    # Set the value if not already set
    if a_set[0] == false
      success = false
      resp = set(:mode_cm, m) if @remote_api_version == 1

      success = (saved_in_sx?(:mode_cm, m) && resp[:success]) if @remote_api_version == 1
      success = resp[:success] if @remote_api_version == 2

      return false, "Set capture mode to #{m} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Capture mode set to #{m} successfully"
  end

  def get_current_capture_mode()
    if @remote_api_version != 2
      log_warn("WifiCamera.get_current_capture_mode() is for api2 only. Returning nil.")
      return nil
    end
    capture_mode_mapping_api2.keys.each do |mode|
      return mode if is_current_capture_mode?(mode)
    end
    return nil
  end # get_current_capture_mode

  def is_current_capture_mode?(m)
    if @remote_api_version != 2
      log_warn("WifiCamera.is_current_capture_mode?() is for api2 only. Returning nil.")
      return nil
    end
    # Find values we'll need.
    path = capture_mode_mapping_api2[m]
    mode_index = get_level_1_index(path)
    mode_value = @settings_json_hash["modes"][mode_index]["value"]
    mode_value = mode_index if mode_value == nil # If no value field is present.
    return nil if mode_value == nil
    case path
    when 'video'
      submode_id, submode_value = get_id_value(:video_submode, m)
    when 'photo'
      submode_id, submode_value = get_id_value(:photo_submode, m)
    when 'multi_shot'
      submode_id, submode_value = get_id_value(:multi_photo_submode, m)
    else
      return nil
    end
    # Get current mode's values.
    cur_submode = get_status_api2(:submode)
    cur_mode = get_status_api2(:mode)
    # Returns true if the current mode values match, or false if they do not.
    return ((cur_submode.to_s.upcase == submode_value.to_s.upcase) and (cur_mode.to_s.upcase == mode_value.to_s.upcase))
  end # is_current_capture_mode?

  def set_capture_mode_api2(m)
    path = capture_mode_mapping_api2[m]
    mode_index = get_level_1_index(path)
    mode_value = @settings_json_hash["modes"][mode_index]["value"]
    mode_value = mode_index if mode_value == nil # If no value field is present.
    return false, "Failed to switch to capture mode #{m} because #{path} path isn't found in settings.json" if mode_value == nil

    case path
    when 'video'
      submode_id, submode_value = get_id_value(:video_submode, m)
    when 'photo'
      submode_id, submode_value = get_id_value(:photo_submode, m)
    when 'multi_shot'
      submode_id, submode_value = get_id_value(:multi_photo_submode, m)
    else
      return false, "Failed to switch to capture mode #{m} because of unknown modes #{path}"
    end
    #check current mode
    cur_submode = get_status_api2(:submode)
    cur_mode = get_status_api2(:mode)

    #set if current mode isn't equal new mode
    if cur_submode.to_s.upcase != submode_value.to_s.upcase || cur_mode.to_s.upcase != mode_value.to_s.upcase
      #set mode
      resp = send_mode_submode_api2(mode_value, submode_value)

      actual_submode = get_status_api2(:submode)
      actual_mode = get_status_api2(:mode)

      if actual_mode.to_s.upcase != mode_value.to_s.upcase
        msg = "Failed to switch to capture mode #{m} because mode is incorrect." + \
        "Expected: #{mode_value}. Actual: #{actual_mode}"
        return false, msg
      end
      if actual_submode.to_s.upcase != submode_value.to_s.upcase
        msg = "Failed to switch to capture mode #{m} because submode is incorrect." + \
        "Expected: #{submode_value}. Actual: #{actual_submode}"
        return false, msg
      end
    end
    return true, "Capture mode set to #{m} successfully"
  end

  def set_video(vm, r, fs, fv)
    vm = vm.upcase
    ret, msg = set_video_format(vm)
    return ret, msg if ret == false
    log_verb(msg)
    sleep(0.5)
    ret, msg = set_video_resolution(r)
    return ret, msg if ret == false
    log_verb(msg)
    sleep(0.5)
    ret, msg = set_video_fps(fs)
    return ret, msg if ret == false
    log_verb(msg)
    sleep(0.5)
    ret, msg = set_video_fov(fv)
    return ret, msg if ret == false
    log_verb(msg)
    sleep(0.5)
    return true, "#{vm}/#{r}/#{fs}/#{fv} set successfully"
  end

  # vm is either NTSC|PAL
  def set_video_format(vm)
    a_set = already_set?(:setup_video_format, vm)

    if a_set[0] == false
      success = false
      resp = set(:setup_video_format, vm)

      success = (saved_in_sx?(:setup_video_format, vm) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set video mode to #{vm} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set video mode to #{vm} successful"
  end

  def set_video_resolution(r)
    a_set = already_set?(:video_resolution, r)

    if a_set[0] == false
      success = false
      resp = set(:video_resolution, r)

      success = (saved_in_sx?(:video_resolution, r) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set RES to #{r} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set RES to #{r} successful"
  end

  def set_video_fps(fs)
    a_set = already_set?(:video_fps, fs)

    if a_set[0] == false
      success = false
      resp = set(:video_fps, fs)
      success = (saved_in_sx?(:video_fps, fs) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set FPS to #{fs} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set FPS to #{fs} successful"
  end

  def set_video_fov(fv, force=false)
    # ### XXX: Workaround for ULU-20.  Enable preview if HTTP resp is 410 - Gone
    # ### BEGIN WORKAROUND
    # if @name == "SILVER_PLUS"
    #   return true, "FOV already correct setting" if already_set?(:video_fov, fv)
    #   resp = get_camera_resp(video_fov[:set], video_fov[fv])
    #   begin
    #     r = resp.code.to_i
    #   rescue StandardError => e
    #     return false, "Error reading http response: #{e.to_s}"
    #   end
    #   if r == 410
    #     log_warn("SILVER_PLUS WORKAROUND to set FV.  Enabling preview")
    #     enable_preview()
    #   end
    # end
    # ### END WORKAROUND
    a_set = already_set?(:video_fov, fv)

    if a_set[0] == false or force == true
      success = false
      resp = set(:video_fov, fv)
      success = (saved_in_sx?(:video_fov, fv) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set FOV to #{fv} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set FOV to #{fv} successful"
  end

  def set_video_timelapse(t)
    a_set = already_set?(:video_timelapse, t)

    if a_set[0] == false
      success = false
      resp = set(:video_timelapse, t)
      success = (saved_in_sx?(:video_timelapse, t) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set video timelapse interval to #{p} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set video timelapse interval to #{t} successful"
  end

  # We need to use lower-level functions on this because it returns
  # HTTP 410 if it cannot set looping due to SD card capacity, ProTune,
  # or unsupported RES/FPS combo
  def set_video_looping(lo)
    return set_video_looping_api2(lo) if @remote_api_version == 2

    sleep 1
    resp = get_camera_resp(video_looping[:set], video_looping[lo])
    sleep 1
    if http_resp_ok(resp)
      resp = get(:video_looping, key=nil, wait_time=1.0, decode=true, expected=lo)
      if resp[:success] == true
        return true, "Set video looping to #{lo} successful"
      else
        return false, "Set video looping failed (mode not supported)"
      end
    end
    return false, "Set video looping to #{lo} failed (bad HTTP resp)"
  end

  def set_video_looping_api2(lo)
    a_set = already_set?(:video_looping, lo)
    if a_set[0] == false
      resp = set(:video_looping, lo)

      return false, "Set VIDEO LOOPING to #{lo} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !resp[:success]

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set VIDEO LOOPING to #{lo} successful"
  end

  def set_video_piv(p)
    a_set = already_set?(:video_piv, p)

    if a_set[0] == false
      success = false
      resp = set(:video_piv, p)
      success = (saved_in_sx?(:video_piv, p) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set PIV to #{p} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set PIV to #{p} successful"
  end

  def set_video_low_light(l)
    a_set = already_set?(:video_low_light, l)

    if a_set[0] == false
      success = false
      resp = set(:video_low_light, l)

      success = (saved_in_sx?(:video_low_light, l) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set LOW LIGHT to #{l} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set LOW LIGHT to #{l} successful"
  end

  def set_video_spot_metering(p)
    a_set = already_set?(:video_spot_metering, p)

    if a_set[0] == false
      success = false
      resp = set(:video_spot_metering, p)
      success = (saved_in_sx?(:video_spot_metering, p) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set Video Spot Metering to #{p} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set Video Spot Metering to #{p} successful"
  end

  def set_video_protune(p, force=false)
    a_set = already_set?(:video_pt, p)

    if a_set[0] == false or force == true
      success = false
      resp = set(:video_pt, p)
      success = (saved_in_sx?(:video_pt, p) && resp[:success]) if @remote_api_version == 1
      success = resp[:success] if @remote_api_version == 2
      if success
        log_info("Video ProTune set to #{p} successful")
      else
        return false, "Set ProTune to #{p} failed (exp=%s, act=%s)" \
        %[resp[:expected], resp[:detected]]
      end
    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Video ProTune is #{p}"
  end

  def set_video_protune_white_balance(w)
    a_set = already_set?(:video_pt_wb, w)

    if a_set[0] == false
      success = false
      resp = set(:video_pt_wb, w)

      success = (saved_in_sx?(:video_pt_wb, w) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set Video WHITE BALANCE to #{w} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set Video WHITE BALANCE to #{w} successful"
  end

  def set_video_protune_color(c)
    a_set = already_set?(:video_pt_color, c)

    if a_set[0] == false
      success = false
      resp = set(:video_pt_color, c)

      success = (saved_in_sx?(:video_pt_color, c) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set Video COLOR to #{c} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set Video COLOR to #{c} successful"
  end

  def set_video_protune_iso(i)
    a_set = already_set?(:video_pt_iso, i)

    if a_set[0] == false
      success = false
      resp = set(:video_pt_iso, i)

      success = (saved_in_sx?(:video_pt_iso, i) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set ISO to #{i} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[1] == nil
      return false, a_set[1]
    end
    return true, "Set ISO to #{i} successful"
  end

  def set_video_protune_iso_mode(i)
    return false, "Command not supported in API v1" if @remote_api_version < 2
    curr_iso_min = get_setting_name_by_sym_api2(:video_pt_iso_mode, refresh=true)
    return true, "ISO_MIN already set to #{i}" if i == curr_iso_min
    resp = set(:video_pt_iso_mode, i)
    if !resp[:success]
      return false, "Set ISO_MIN to #{i} failed (exp=%s, act=%s)" \
        %[resp[:expected], resp[:detected]]
    else
      return true, "Set ISO_MIN to #{i} successful"
    end
  end

  def set_video_protune_shutter_speed(i)
    return false, "Command not supported in API v1" if @remote_api_version < 2
    curr_iso_min = get_setting_name_by_sym_api2(:video_pt_shutter_speed, refresh=true)
    return true, "Shutter speed already set to #{i}" if i == curr_iso_min
    resp = set(:video_pt_shutter_speed, i)
    if !resp[:success]
      return false, "Set shutter speed to #{i} failed (exp=%s, act=%s)" \
        %[resp[:expected], resp[:detected]]
    else
      return true, "Set shutter speed to #{i} successful"
    end
  end

  def set_video_protune_sharpness(s)
    a_set = already_set?(:video_pt_sharp, s)

    if a_set[0] == false
      success = false
      resp = set(:video_pt_sharp, s)

      success = (saved_in_sx?(:video_pt_sharp, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set Video SHARPNESS to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set Video SHARPNESS to #{s} successful"
  end

  def set_video_protune_exposure(e)
    a_set = already_set?(:video_pt_ev, e)

    if a_set[0] == false
      success = false
      resp = set(:video_pt_ev, e)

      success = (saved_in_sx?(:video_pt_ev, e) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set Video Protune EXPOSURE to #{e} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set Video Protune EXPOSURE to #{e} successful"
  end

  def set_photo_resolution(r, force=false)
    a_set = already_set?(:photo_resolution, r)

    if a_set[0] == false or force == true
      success = false
      resp = set(:photo_resolution, r)
      success = (saved_in_sx?(:photo_resolution, r) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set PHOTO_RES to #{r} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set PHOTO_RES to #{r} successful"
  end

  def set_photo_continuous(s)
    a_set = already_set?(:photo_continuous, s)

    if a_set[0] == false
      success = false
      resp = set(:photo_continuous, s)
      success = (saved_in_sx?(:photo_continuous, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set SPS to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set SPS to #{s} successful"
  end

  def set_multi_photo_burst(b, force=false)
    a_set = already_set?(:multi_photo_burst, b)

    if a_set[0] == false or force == true
      success = false
      resp = set(:multi_photo_burst, b)
      success = (saved_in_sx?(:multi_photo_burst, b) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set BURST to #{b} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set BURST to #{b} successful"
  end

  def set_multi_photo_timelapse(t)
    a_set = already_set?(:multi_photo_timelapse, t)

    if a_set[0] == false
      succes = false
      resp = set(:multi_photo_timelapse, t)
      success = (saved_in_sx?(:multi_photo_timelapse, t) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set TIME_LAPSE to #{t} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set TIME_LAPSE to #{t} successful"
  end

  def set_multi_photo_nightlapse(n)
    a_set = already_set?(:multi_photo_nightlapse, n)

    if a_set[0] == false
      succes = false
      resp = set(:multi_photo_nightlapse, n)
      success = (saved_in_sx?(:multi_photo_nightlapse, n) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set PHOTO NIGHTLAPSE to #{n} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set PHOTO NIGHTLAPSE to #{n} successful"
  end

  def set_photo_spot_metering(s)
    a_set = already_set?(:photo_spot_metering, s)

    if a_set[0] == false
      success = false
      resp = set(:photo_spot_metering, s)
      success = (saved_in_sx?(:photo_spot_metering, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set PHOTO Spot Metering to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set PHOTO Spot Metering to #{s} successful"
  end

  def set_photo_shutter_exposure(s)
    a_set = already_set?(:photo_shutter_ev, s)

    if a_set[0] == false
      success = false
      resp = set(:photo_shutter_ev, s)
      success = (saved_in_sx?(:photo_shutter_ev, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set PHOTO shutter exposure to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set PHOTO shutter exposure to #{s} successful"
  end

  def set_photo_protune(p)
    a_set = already_set?(:photo_pt, p)

    if a_set[0] == false
      success = false
      resp = set(:photo_pt, p)
      success = (saved_in_sx?(:photo_pt, p) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set Photo ProTune to #{p} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set Photo ProTune to #{p} successful"
  end

  def set_photo_protune_white_balance(w)
    a_set = already_set?(:photo_pt_wb, w)

    if a_set[0] == false
      success = false
      resp = set(:photo_pt_wb, w)

      success = (saved_in_sx?(:photo_pt_wb, w) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set WHITE BALANCE to #{w} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set WHITE BALANCE to #{w} successful"
  end

  def set_photo_protune_color(c)
    a_set = already_set?(:photo_pt_color, c)

    if a_set[0] == false
      success = false
      resp = set(:photo_pt_color, c)

      success = (saved_in_sx?(:photo_pt_color, c) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set COLOR to #{c} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set COLOR to #{c} successful"
  end

  def set_photo_protune_iso(i)
    a_set = already_set?(:photo_pt_iso, i)

    if a_set[0] == false
      success = false
      resp = set(:photo_pt_iso, i)

      if @remote_api_version < 2
        success = (saved_in_sx?(:photo_pt_iso, i) && resp[:success])
      else
        success = resp[:success]
        curr_iso_min = get_setting_name_by_sym_api2(:photo_pt_iso_min, refresh=false)
        if (curr_iso_min != nil) and (i < curr_iso_min)
          log_warn("Requested ISO_MAX(%s) < ISO_MIN(%s).  Strange things may happen." \
            %[i, curr_iso_min])
        end
      end

      return false, "Set ISO to #{i} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set ISO to #{i} successful"
  end

  # Hawaii Phase 4 new setting
  def set_photo_protune_iso_min(i)
    return false, "Command not supported in API v1" if @remote_api_version < 2

    curr_iso_min = get_setting_name_by_sym_api2(:photo_pt_iso_min, refresh=true)
    return false, "Unsupported command or command not found" if curr_iso_min == nil
    return true, "ISO_MIN already set to #{i}" if i == curr_iso_min
    curr_iso_max = get_setting_name_by_sym_api2(:photo_pt_iso, refresh=false)
    if i > curr_iso_max
      log_warn("Requested ISO_MIN(%s) > ISO_MAX(%s).  Strange things may happen." \
        %[i, curr_iso_max])
    end

    resp = set(:photo_pt_iso_min, i)
    if !resp[:success]
      return false, "Set ISO_MIN to #{i} failed (exp=%s, act=%s)" \
        %[resp[:expected], resp[:detected]]
    else
      return true, "Set ISO_MIN to #{i} successful"
    end
  end

  def set_photo_protune_sharpness(s)
    a_set = already_set?(:photo_pt_sharp, s)

    if a_set[0] == false
      success = false
      resp = set(:photo_pt_sharp, s)

      success = (saved_in_sx?(:photo_pt_sharp, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set SHARPNESS to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set SHARPNESS to #{s} successful"
  end

  def set_photo_protune_exposure(e)
    a_set = already_set?(:photo_pt_ev, e)

    if a_set[0] == false
      success = false
      resp = set(:photo_pt_ev, e)

      success = (saved_in_sx?(:photo_pt_ev, e) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set EXPOSURE to #{e} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set EXPOSURE to #{e} successful"
  end

  def set_multi_photo_resolution(r, force=false)
    a_set = already_set?(:multi_photo_resolution, r)

    if a_set[0] == false or force == true
      success = false
      resp = set(:multi_photo_resolution, r)
      success = (saved_in_sx?(:multi_photo_resolution, r) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set multi_photo_RES to #{r} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set multi_photo_RES to #{r} successful"
  end

  def set_multi_photo_spot_metering(s)
    a_set = already_set?(:multi_photo_spot_meter, s)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_spot_meter, s)
      success = (saved_in_sx?(:multi_photo_spot_meter, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set multi_photo Spot Metering to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set multi_photo Spot Metering to #{s} successful"
  end

  def set_multi_photo_shutter_exposure(s)
    a_set = already_set?(:multi_photo_shutter_ev, s)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_shutter_ev, s)
      success = (saved_in_sx?(:multi_photo_shutter_ev, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set MULTI_PHOTO shutter exposure to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set MULTI_PHOTO shutter exposure to #{s} successful"
  end

  def set_multi_photo_protune(p)
    a_set = already_set?(:multi_photo_pt, p)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_pt, p)
      success = (saved_in_sx?(:multi_photo_pt, p) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set multi_photo ProTune to #{p} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set multi_photo ProTune to #{p} successful"
  end

  def set_multi_photo_protune_white_balance(w)
    a_set = already_set?(:multi_photo_pt_wb, w)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_pt_wb, w)

      success = (saved_in_sx?(:multi_photo_pt_wb, w) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set WHITE BALANCE to #{w} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set WHITE BALANCE to #{w} successful"
  end

  def set_multi_photo_protune_color(c)
    a_set = already_set?(:multi_photo_pt_color, c)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_pt_color, c)

      success = (saved_in_sx?(:multi_photo_pt_color, c) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set COLOR to #{c} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set COLOR to #{c} successful"
  end

  def set_multi_photo_protune_iso(i)
    a_set = already_set?(:multi_photo_pt_iso, i)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_pt_iso, i)

      if @remote_api_version < 2
        success = (saved_in_sx?(:multi_photo_pt_iso, i) && resp[:success])
      else
        success = resp[:success]
        curr_iso_min = get_setting_name_by_sym_api2(:multi_photo_pt_iso_min, refresh=false)
        if (curr_iso_min != nil) and (i < curr_iso_min)
          log_warn("Requested ISO_MAX(%s) < ISO_MIN(%s).  Strange things may happen." \
            %[i, curr_iso_min])
        end
      end

      return false, "Set ISO to #{i} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set ISO to #{i} successful"
  end

  # Hawaii Phase 4 new setting
  def set_multi_photo_protune_iso_min(i)
    return false, "Command not supported in API v1" if @remote_api_version < 2

    curr_iso_min = get_setting_name_by_sym_api2(:multi_photo_pt_iso_min, refresh=true)
    return false, "Unsupported command or command not found" if curr_iso_min == nil
    return true, "ISO_MIN already set to #{i}" if i == curr_iso_min
    curr_iso_max = get_setting_name_by_sym_api2(:multi_photo_pt_iso, refresh=false)
    if i > curr_iso_max
      log_warn("Requested ISO_MIN(%s) > ISO_MAX(%s).  Strange things may happen." \
        %[i, curr_iso_max])
    end

    resp = set(:multi_photo_pt_iso_min, i)
    if !resp[:success]
      return false, "Set ISO_MIN to #{i} failed (exp=%s, act=%s)" \
        %[resp[:expected], resp[:detected]]
    else
      return true, "Set ISO_MIN to #{i} successful"
    end
  end

  def set_multi_photo_protune_sharpness(s)
    a_set = already_set?(:multi_photo_pt_sharp, s)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_pt_sharp, s)

      success = (saved_in_sx?(:multi_photo_pt_sharp, s) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set SHARPNESS to #{s} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set SHARPNESS to #{s} successful"
  end

  def set_multi_photo_protune_exposure(e)
    a_set = already_set?(:multi_photo_pt_ev, e)

    if a_set[0] == false
      success = false
      resp = set(:multi_photo_pt_ev, e)

      success = (saved_in_sx?(:multi_photo_pt_ev, e) && resp[:success]) if @remote_api_version == 1

      success = resp[:success] if @remote_api_version == 2

      return false, "Set EXPOSURE to #{e} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success

    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set EXPOSURE to #{e} successful"
  end

  #This setting isn't saved in sx
  def set_preview_resolution(r)
    # Only actually set if there are multiple resolutions possible
    if get_preview_resolutions().length > 1
      resp = set(:preview_resolution, r)
      return false, "Set preview res to #{r} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if resp[:success] != true
      return true, "Set preview res to #{r} successful"
    else
      return true, "Not setting preview resolution b/c only one supported"
    end
  end

  #This setting isn't saved in sx
  def set_preview_bitrate(r, b)
    # Only actually set if there are multiple bitrates possible
    if get_preview_bitrates(r).length > 1
      resp = set(:preview_bitrate, b)
      return false, "Set preview bitrate to #{b} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if resp[:success] != true
      return true, "Set preview bitrate to #{b} successful"
    else
      return true, "Not setting preview bitrate b/c only one supported"
    end
  end

  def start_capture(r=2)

    return start_capture_api2 if @remote_api_version == 2
    set(:shutter_sh, "ON", wait_time=0, decode=false, expected=nil)
=begin
    #NOTE - It is really hard to get busy status bit on single photo. Comment out for now
    b = false
    for n in (1..3)
      set(:shutter_sh, "ON", wait_time=0, decode=false, expected=nil)
      sleep 1.0
      break if (b=busy?)
      break if (b=shutter_on?)
    end
    return true, "Capture started successfully" if b
    return false, "Error starting capture" if !b
=end
  end

  def start_capture_api2
    resp = send_shutter_api2(1)
=begin
    #NOTE - It is really hard to get busy status bit on single photo. Comment out for now
    if busy?
      return true, "Capture started successfully"
    else
      return false, "Error starting capture"
    end
=end
  end

  def stop_capture(tries=3)
    (1..tries).each { |t|
      if @remote_api_version == 2
        resp = send_shutter_api2(0)
      else
        set(:shutter_sh, "OFF", wait_time=1.0, decode=false, expected=nil)
      end
      sleep(2.0)
      wait_until_not_busy(interval=1.0, timeout=5)
      break if not busy?
      sleep(2.0)
    }
    return true, "Capture stopped successfully" if !busy?
    return false, "Error stopping capture" if busy?
  end

  def set_single_video_settings(vm, res, fps, fov, orient=nil, ll=nil, spot=nil, p=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
    begin
      log_verb("Setting #{vm} #{res}/#{fps}/#{fov} single video values")
      ret, msg = set_capture_mode("VIDEO")
      return false, msg if ret == false
      log_info(msg)

      ret, msg = set_video(vm, res, fps, fov)
      return false, msg if ret == false
      log_info(msg)

      if p != nil and video_protune_support? == true
        ret, msg = set_video_protune(p)
        return false, msg if ret == false
        log_info(msg)
      end

      if orient != nil
        ret, msg = set_orientation(orient)
        return false, msg if ret == false
        log_info(msg)
      end

      if spot != nil
        ret, msg = set_video_spot_metering(spot)
        return false, msg if ret == false
        log_info(msg)
      end

      if ll != nil
        ret, msg = set_video_low_light(ll)
        return false, msg if ret == false
        log_info(msg)
      end

      if wb != nil
        ret, msg = set_video_protune_white_balance(wb)
        return false, msg if ret == false
        log_info(msg)
      end

      if co != nil
        ret, msg = set_video_protune_color(co)
        return false, msg if ret == false
        log_info(msg)
      end

      if iso != nil
        ret, msg = set_video_protune_iso(iso)
        return false, msg if ret == false
        log_info(msg)
      end

      if sh != nil
        ret, msg = set_video_protune_sharpness(sh)
        return false, msg if ret == false
        log_info(msg)
      end

      if ex != nil
        ret, msg = set_video_protune_exposure(ex)
        return false, msg if ret == false
        log_info(msg)
      end

      return true, "Setting defined video values successfully"

    rescue WifiCameraError => e
      return false, e.message
    end # end begin/rescue
  end # end set_single_video_Settings

  def process_single_video_capture(duration)
    log_info("Capturing #{duration} seconds video")

    start_capture()
    @save_ts_file = true

    #check stream_supported bit
    stream_supported_value = get_status(:stream_supported)
    stream_enabled_value = get_status(:stream_enabled)
    log_info("#{Time.now} Capturing - stream_supported #{stream_supported_value} \t stream_enabled #{stream_enabled_value}")

    sleep duration.to_f

    @save_ts_file = false
    stop_capture()

    return stream_supported_value
  end

  def capture_video(vm, res, fps, fov, duration, orient=nil, ll=nil, spot=nil, p=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    (1..retries).each { |n|
      begin
        log_verb("Capturing #{res}/#{fps}/#{fov} video (Try #{n} of #{retries})")
        ret, msg = set_capture_mode("VIDEO")
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        # On most cameras we must set video resolution before changing protune!
        # Except Rockypoint! We must turn it OFF if it is not explicitly ON
        if ["ROCKYPOINT", "BLACK_PLUS"].include?(@name) and p != "ON"
          ret, msg = set_video_protune("OFF", force=true)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        ret, msg = set_video(vm, res, fps, fov)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        if p != nil and video_protune_support? == true
          ret, msg = set_video_protune(p)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_video_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ll != nil
          ret, msg = set_video_low_light(ll)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if wb != nil
          ret, msg = set_video_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if co != nil
          ret, msg = set_video_protune_color(co)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if iso != nil
          ret, msg = set_video_protune_iso(iso)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if sh != nil
          ret, msg = set_video_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ex != nil
          ret, msg = set_video_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        log_info("Capturing #{duration} seconds video")
        ret, msg = start_capture()
        if ret == false; next if n < retries; return false, msg; end

        sleep duration.to_f
        ret, msg = stop_capture()
        if ret == false; next if n < retries; return false, msg; end

        return true, "Video captured successfully"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    } # end for n in retries
  end # end capture video

  def capture_videoKF(vm, res, fps, fov, duration, orient=nil, ll=nil, spot=nil, p=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    (1..retries).each { |n|
      begin
        ltp_log($VERB, "Capturing #{res}/#{fps}/#{fov} video (Try #{n} of #{retries})")
        ret, msg = set_capture_mode("VIDEO")
        if ret == false; next if n < retries; return false, msg; end
        ltp_log($INFO, msg)

        # On most cameras we must set video resolution before changing protune!
        # Except Rockypoint! We must turn it OFF if it is not explicitly ON
        if ["ROCKYPOINT", "BLACK_PLUS"].include?(@name) and p != "ON"
          ret, msg = set_video_protune("OFF")
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        ret, msg = set_video(vm, res, fps, fov)
        if ret == false; next if n < retries; return false, msg; end
        ltp_log($INFO, msg)

        if p != nil and video_protune_support? == true
          ret, msg = set_video_protune(p)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if spot != nil
          ret, msg = set_video_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if ll != nil
          ret, msg = set_video_low_light(ll)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if wb != nil
          ret, msg = set_video_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if co != nil
          ret, msg = set_video_protune_color(co)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if iso != nil
          ret, msg = set_video_protune_iso(iso)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if sh != nil
          ret, msg = set_video_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        if ex != nil
          ret, msg = set_video_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          ltp_log($INFO, msg)
        end

        ltp_log($INFO, "Capturing #{duration} seconds video")
        ret, msg = start_capture()
        if ret == false; next if n < retries; return false, msg; end
        dur=duration.to_f
        if dur >3 # tag for duration greater than 3 sec
          sleeptime=dur/4
          for s in 1..3
            sleep sleeptime.to_f
            tag_ret, tag_msg = tag_hilight
            if not tag_ret
              ltp_log($WARN, tag_msg)
              ltp_log($WARN, "Retry Hilight")
              tag_ret, tag_msg = tag_hilight
              if not tag_ret
                ltp_log($WARN, tag_msg)
              else
                ltp_log($INFO, tag_msg)
              end
            else
              ltp_log($INFO, tag_msg)
            end
          end
          sleep sleeptime.to_f
        else
          ltp_log($INFO, 'Skip tagging: duration too short')
          sleep dur
        end
        
        ret, msg = stop_capture()
        if ret == false; next if n < retries; return false, msg; end

        return true, "Video captured successfully"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    } # end for n in retries
  end # end capture video

  def capture_piv(vm, res, fps, fov, piv, duration, orient=nil, ll=nil, spot=nil)
    retries=2
    for n in 1..retries
      begin
        ret, msg = set_capture_mode("VIDEO_PIV") if @remote_api_version == 2
        ret, msg = set_capture_mode("VIDEO") if @remote_api_version == 1
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_video(vm, res, fps, fov)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_video_piv(piv)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_video_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ll != nil
          ret, msg = set_video_low_light(ll)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        ret, msg = start_capture()
        if ret == false; next if n < retries; return false, msg; end
        sleep duration.to_f
        ret, msg = stop_capture()
        if ret == false; next if n < retries; return false, msg; end

        return true, "Video captured successfully"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end # end for n in 1..retries
  end # end capture_piv

  # Capture looping video
  def capture_looping(vm, res, fps, fov, loo, duration, setonly=false, orient=nil, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      begin
        ret, msg = set_capture_mode("VIDEO_LOOPING") if @remote_api_version == 2
        ret, msg = set_capture_mode("VIDEO") if @remote_api_version == 1
        if ret == false; next if n < retries; return false, msg; end

        # Have to set video mode first to determine minutes remaining
        ret, msg = set_video(vm, res, fps, fov)
        if ret == false; next if n < retries; return false, msg; end

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_video_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ll != nil
          ret, msg = set_video_low_light(ll)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        min_avail = get_mins_avail()
        sleep 0.5

        min_reqd = duration.to_f / 60
        sleep 0.5

        ret, msg = set_video_looping(loo)
        if ret == false
          if min_reqd > min_avail
            # Camera should refuse to enable looping
            log_info(msg)
            log_skip("Insufficient space on SD card (req=#{min_reqd} > avail=#{min_avail})")
          else
            return false, msg
          end
        else
          if min_reqd > min_avail
            # Camera should have refused to enable looping due to SD capacity
            return fail, "Camera ret. HTTP=200 despite insufficinet space req=#{min_reqd} > avail=#{min_avail}"
          end
        end

        if setonly
          return true, "Setting successful"
        end

        ret, msg = start_capture()
        if ret == false; next if n < retries; return false, msg; end
        sleep duration.to_f
        ret, msg = stop_capture()
        if ret == false; next if n < retries; return false, msg; end

        return true, "Done capture looping."
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    }
    return false, "Failed to set/capture looping"
  end

  # Capture video_timelapse (Only care about res)
  def capture_video_timelapse(vm, res, fov, pes, duration, orient=nil)
    retries = 2
    for n in (1..retries)
      begin
        log_verb("Capturing #{res} video timelapse (Try #{n} of #{retries})")
        ret, msg = set_capture_mode("VIDEO_TIMELAPSE")
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        vm = vm.upcase
        ret, msg = set_video_format(vm)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_video_resolution(res)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_video_fov(fov)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_video_timelapse(pes)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        log_info("#{vm}/#{res}/#{fov}/#{pes} set successfully")
        log_info("Starting video capture")
        ret, msg = start_capture()
        if ret == false; next if n < retries; return false, msg; end
        sleep duration.to_f
        ret, msg = stop_capture()
        if ret == false; next if n < retries; return false, msg; end

        return true, "Video timelapse captured successfully"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
  end

  # Captures a photo in single photo mode
  def capture_photo_single(res, orient=nil, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries=2
    for n in (1..retries)
      begin
        ret, msg = set_capture_mode("PHOTO")
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_photo_resolution(res)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        if @remote_api_version == 1 && photo_continuous_support?
          ret, msg = set_photo_continuous("1")
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_photo_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if pt != nil
          ret, mesg = set_photo_protune(pt)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if wb != nil
          ret, msg = set_photo_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if col != nil
          ret, msg = set_photo_protune_color(col)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if iso != nil
          ret, msg = set_photo_protune_iso(iso)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if sh != nil
          ret, msg = set_photo_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ex != nil
          ret, msg = set_photo_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        sleep(3.0)
        log_info("Capturing single photo")
        ret, msg = start_capture
        if ret == false; next if n < retries; return false, msg; end
        wait_until_not_busy
        return true, "Done capturing photo"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
    return false, "Failed to capture photo"
  end

  # Captures photo in continuous mode
  def capture_photo_continuous(res, sps, duration, orient=nil, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    for n in (1..retries)
      begin
        ret, msg = set_capture_mode("PHOTO") if @remote_api_version == 1
        ret, msg = set_capture_mode("PHOTO_CONTINUOUS") if @remote_api_version == 2
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_photo_resolution(res)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        ret, msg = set_photo_continuous(sps)
        if ret == false; next if n < retries; return false, msg; end
        log_info(msg)

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_photo_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if pt != nil
          ret, mesg = set_photo_protune(pt)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if wb != nil
          ret, msg = set_photo_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if col != nil
          ret, msg = set_photo_protune_color(col)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if iso != nil
          ret, msg = set_photo_protune_iso(iso)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if sh != nil
          ret, msg = set_photo_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ex != nil
          ret, msg = set_photo_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        log_info("Capturing continuous at rate=#{sps}, duration=#{duration}")

        ret, msg = start_capture
        if ret == false; next if n < retries; return false, msg; end

        sleep duration.to_f

        ret, msg = stop_capture
        if ret == false; next if n < retries; return false, msg; end

        wait_until_not_busy

        return true, "Done capturing continuous photo(s)"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
    return false, "Failed to capture continous photo"
  end

  # Captures night photo
  def capture_photo_night(res, duration, orient=nil, spot=nil, se=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    for n in (1..retries)
      begin
        ret, msg = set_capture_mode("PHOTO_NIGHT")
        if ret == false; next if n < retries;return false, msg;end
        log_info(msg)

        ret, msg = set_photo_resolution(res)
        if ret == false; next if n < retries;return false, msg;end
        log_info(msg)

        if @remote_api_version != 1
          if orient != nil
            ret, msg = set_orientation(orient)
            if ret == false; next if n < retries; return false, msg; end
            log_info(msg)
          end

          if spot != nil
            ret, msg = set_photo_spot_metering(spot)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end

          if pt != nil
            ret, msg = set_photo_protune(pt)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end
          if se != nil
            ret, msg = set_photo_shutter_exposure(se)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end

          if iso != nil
            ret, msg = set_photo_protune_iso(iso)
            if ret == false; next if n < retries; return false, msg; end
            log_info(msg)
          end

          if wb != nil
            ret, msg =  set_photo_protune_white_balance(wb)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end

          if col != nil
            ret, msg =  set_photo_protune_color(col)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end

          if sh != nil
            ret, msg =  set_photo_protune_sharpness(sh)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end

          if ex != nil
            ret, msg =  set_photo_protune_exposure(ex)
            if ret == false; next if n < retries;return false, msg;end
            log_info(msg)
          end
        end

        log_info("Capturing night photo")
        ret, msg = start_capture
        if ret == false; next if n < retries;return false, msg;end

        sleep duration.to_f

        wait_until_not_busy()

        return true, "Done capturing night photo(s)"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
    return false, "Failed to capture night photo"
  end

  # Take burst-mode photos (and optionally save them locally)
  # Return # of photos before and after if successful
  # Return false if failed
  def capture_multi_photo_burst(res, bu, orient=nil, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    for n in (1..retries)
      begin
        ret, msg = set_capture_mode("BURST")
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        ret, msg = set_multi_photo_resolution(res)
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        ret, msg = set_multi_photo_burst(bu)
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_multi_photo_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if pt != nil
          ret, mesg = set_multi_photo_protune(pt)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if wb != nil
          ret, msg = set_multi_photo_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if col != nil
          ret, msg = set_multi_photo_protune_color(col)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if iso != nil
          ret, msg = set_multi_photo_protune_iso(iso)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if sh != nil
          ret, msg = set_multi_photo_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ex != nil
          ret, msg = set_multi_photo_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        3.times {
          ret, msg = start_capture
          sleep 0.4
          break if busy?
        }
        if ret == false;next if n < retries;return false, msg;end

        wait_until_not_busy()

        return true, "Done capturing burst photo(s)"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
    return false, "Failed to capture burst"
  end

  # Take 'pes_length' seconds of time-lapse footage or enough for min_photos,
  # whichever is greater (and optionally save them locally)
  # Return false if failed
  def capture_multi_photo_timelapse(res, pes, duration, orient=nil, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries=2
    for n in (1..retries)
      begin
        ret, msg = set_capture_mode("TIMELAPSE")
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        ret, msg = set_multi_photo_resolution(res)
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        ret, msg = set_multi_photo_timelapse(pes)
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_multi_photo_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if pt != nil
          ret, mesg = set_multi_photo_protune(pt)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if wb != nil
          ret, msg = set_multi_photo_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if col != nil
          ret, msg = set_multi_photo_protune_color(col)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if iso != nil
          ret, msg = set_multi_photo_protune_iso(iso)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if sh != nil
          ret, msg = set_multi_photo_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ex != nil
          ret, msg = set_multi_photo_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        timeout = 10.0
        start_time = Time.now()
        while (Time.now() - start_time) < timeout
          ret, msg = start_capture
          sleep 2.0
          break if busy?
        end

        if ret == false;next if n < retries;return false, msg;end

        sleep duration.to_f

        ret, msg = stop_capture
        if ret == false;next if n < retries;return false, msg;end

        wait_until_not_busy(interval=1.0, timeout=30)

        return true, "Done capturing time lapse photo(s)"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
    return false, "Failed to capture time-lapse"
  end

  def capture_multi_photo_nightlapse(res, pes, duration, orient=nil, spot=nil, se=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    for n in (1..retries)
      begin
        ret, msg = set_capture_mode("NIGHTLAPSE")
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        ret, msg = set_multi_photo_resolution(res)
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        # We need to set the shutter exposure before the nightlapse interval.
        # This is because not all interval values can be set at all shutter values.
        if se != nil
          ret, msg = set_multi_photo_shutter_exposure(se)
          if ret == false; next if n < retries;return false, msg;end
          log_info(msg)
        end

        ret, msg = set_multi_photo_nightlapse(pes)
        if ret == false;next if n < retries;return false, msg;end
        log_info(msg)

        if orient != nil
          ret, msg = set_orientation(orient)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if spot != nil
          ret, msg = set_multi_photo_spot_metering(spot)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if pt != nil
          ret, mesg = set_multi_photo_protune(pt)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if wb != nil
          ret, msg = set_multi_photo_protune_white_balance(wb)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if col != nil
          ret, msg = set_multi_photo_protune_color(col)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if sh != nil
          ret, msg = set_multi_photo_protune_sharpness(sh)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        if ex != nil
          ret, msg = set_multi_photo_protune_exposure(ex)
          if ret == false; next if n < retries; return false, msg; end
          log_info(msg)
        end

        ret, msg = start_capture
        if ret == false; next if n < retries; return false, msg; end

        sleep duration.to_f

        ret, msg = stop_capture
        if ret == false; next if n < retries; return false, msg; end

        wait_until_not_busy(interval=1.0, timeout=30)
        sleep 1.0

        return true, "Done capturing nightlapse photo(s)"
      rescue WifiCameraError => e
        next if n < retries
        return false, e.message
      end # end begin/rescue
    end
    return false, "Failed to capture nightlapse photo"
  end

  def ok?()
    # log_verb("Checking OK...")
    return get_status(:ok)
  end

  def api2_camera_power_on_ok?(tries=3)
    h = Host.new()
    tries.times { |n|
      log_info("Waking up camera @%s (try %d of %d)" %[@ip, n+1, tries])
      h.wol(@ip, @mac)
      return true if h.wait_for_wifi_camera(@ip, timeout=15, interval=1.0) == true
    }
    log_warn("Unable to connect to camera after #{tries} tries.")
    return false
  end

  def start_streaming_protocol()
    temp = ""
    use_segment_number = -1
    got_first_frame = false
    skip_save_file = false

    @keepalive_socket = UDPSocket.new
    @stop_requested = false

    @receive_socket = UDPSocket.new
    @receive_socket.setsockopt(Socket::SOL_SOCKET, Socket::SO_REUSEADDR, true)
    @receive_socket.bind(@system_address, @streaming_port)

    @keepalive_thread = Thread.new {
      while !@stop_requested
        @keepalive_socket.send("_GPHD_:0:0:2:0", 0, @ip, @streaming_port)
        sleep 3
      end
    }

    @receive_thread = Thread.new {
      while(true)
        skip_save_file == false
        #Read Timeout. By design, resoutions that do not support streaming, no packet will be seen
        result = IO.select([@receive_socket], nil, nil, 2)  #wait for event to be ready in 2 sec timeout (in this case readable data at receive_socket)
        if result != nil
          msg = @receive_socket.recvfrom(1328)[0]
          byte0, r1, r2, segment_number, segment_size, datagram_number_hi, datagram_number_lo, datagram_size_hi, datagram_size_lo = msg.unpack('CCCCNCCCC')
          datagram_number = (datagram_number_hi << 8) + datagram_number_lo
          datagram_size = (datagram_size_hi << 8) + datagram_size_lo

          if @tracker_datagram_number != nil && @tracker_segment_number != nil
            if @tracker_segment_number == segment_number && datagram_number != @tracker_datagram_number + 1
              log_debug("Missing datagram number #{@tracker_datagram_number + 1} \t segment number #{segment_number}")
              got_first_frame = false
              use_segment_number = -1
              temp.clear
              skip_save_file == true
            end
          end
          @tracker_datagram_number = datagram_number
          @tracker_segment_number = segment_number

          if @save_ts_file == true and skip_save_file == false
            if datagram_number == 0 and use_segment_number == -1
              if got_first_frame != true
                got_first_frame = true
                use_segment_number = segment_number
                log_info("#{Time.now} use_segment_number #{use_segment_number}")
              end
            elsif use_segment_number != -1 and use_segment_number != segment_number
              log_info("#{Time.now} \t write to file \t segment_number #{use_segment_number} \t total write size #{temp.length}")
              File.open(@save_ts_filename, 'wb') { |file| file.write(temp) }
              log_info("Complete packet")
              got_first_frame = false
              use_segment_number = -1
              temp.clear
              @tracker_datagram_number = nil
              @tracker_segment_number = nil
              @save_ts_file = false
            end

            if use_segment_number == segment_number
              log_debug("#{Time.now} \t save to memory \t datagram_number #{datagram_number} \t segment_number #{segment_number} \t datagram_size #{datagram_size} \t before save file #{temp.length}")
              temp.concat(msg[12, datagram_size])
            end
          end
        end
      end #while
    } #receive_thread
  end #method

  def stop_streaming_protocol
    log_verb("Stopping streaming protocol")
    @stop_requested = true
    @receive_thread.exit
    @keepalive_thread.join
    @receive_socket.close
    @keepalive_socket.close
  end

  def bacpac_ok?(); return get_bacpac_status(:ok); end

  #only applicable to remote_api_version 1
  def wait_until_ok(interval=0.3, timeout=30)
    # log_verb("Waiting until OK")
    cam_ok = false
    bp_ok = false
    start = Time.now
    while ((Time.now - start) < timeout)
      cam_ok = true if (cam_ok == false and ok?)
      bp_ok = true if (bp_ok == false and bacpac_ok?)
      return true if (cam_ok and bp_ok)
      log_verb("OK flag status: cam=#{cam_ok}, bp=#{bp_ok}...")
      sleep interval
    end
    log_warn("Busy wait timed out (#{timeout}s)!")
    return false
  end

  # Returns true or false on success
  # Nil on failure
  def busy?
    # log_verb("Checking busy...")
    if @remote_api_version == 2
      b = get_status_api2(:busy)
      return nil if b == false
      return b.to_s == '1'
    elsif @remote_api_version == 1
      b = get_status(:busy)
      return nil if b == false
      return b == 1
    end
  end

  # Returns true or false on success
  # Nil on failure
  def shutter_on?
    s = get_status(:shutter)
    log_verb("Shutter status == #{s == 1}")
    return nil if s == false
    return s == 1
  end

  # Returns true or false on success
  # Nil on failure
  def wait_until_not_busy(interval=0.5, timeout=30)
    # log_verb("Waiting until not busy")
    start = Time.now
    while ((Time.now - start) < timeout)
      b = busy?
      if b == nil
        log_warn("Failed to determine if camera is busy")
        return nil
      end
      return true if not busy?
      log_verb("Camera busy...")
      sleep interval
    end
    log_warn("Busy wait timed out (#{timeout}s)!")
    log_info("Exiting #{__method__}")
    return false
  end

  def is_alive?()
    begin
      ret, msg = set_capture_mode("PHOTO")
      return false if ret == false
      ret, msg = set_capture_mode("VIDEO")
      return false if ret == false
    rescue StandardError
      return false
    end
    return true
  end

  def get_mp4_files_from_webserver()
    ret = []
    url = "http://10.5.5.9:8080/videos/DCIM/"
    resp = http_get(url).body
    resp.scan(/[0-9]{3}GOPRO/).uniq.each { |dir|
      url = "http://10.5.5.9:8080/videos/DCIM/#{dir}/"
      resp = http_get(url).body
      resp.scan(/G...[0-9]{4}.MP4/).uniq.each { |file|
        ret << "#{dir}/#{file}"
      }
      sleep 1
    }
    return ret
  end

  def get_media_url(f)
    return "http://#{@ip}:#{@http_port}/videos/DCIM/#{f}"
  end

  def get_last_mp4_url()
    "http://#{@ip}:#{@http_port}/videos/DCIM/#{get_last_media("MP4", hash=false)}"
  end

  def get_last_jpg_url()
    "http://#{@ip}:#{@http_port}/videos/DCIM/#{get_last_media("JPG", hash=false)}"
  end

  # Override Camera.get_last_video()

  #For JPG, return name of first file for group (ie burst, sps, photo-in-video)
  #suffix is either 'MP4' or 'JPG'
  #if hash=false, return 'dir/n' (ie 100GOPRO/G0010929.MP4). if hash=true, return hash
  # (ie {"n":"G0019587.MP4","g":"1","b":"9587","l":"9594","mod":"1357844012","s":"11843464","t":"b","m":[]}]}]})
  def get_last_media(suffix, hash=false)
    parsed = get_parsed_gpmedialist
    return false if parsed == false
    folder = parsed["media"].pop
    if folder == nil
      return ""
    else
      dir = folder["d"]
      f = folder["fs"].pop
      return "" if f == nil
      n = f["n"]
      name, ext = n.split('.')

      if ext == suffix
        hash == true ?  f : "#{dir}/#{n}"
      elsif ext != suffix    #need to do a second pop in the case of photo-in-video
        f = folder["fs"].pop
        n = f["n"]
        name, ext = n.split('.')

        if ext == suffix
          hash == true ? f : "#{dir}/#{n}"
        else
          return ""
        end
      end
    end
  end

  #return from gpmedialist
  def get_group_type(s)
    {
      "BURST" => "b",
      "TIME_LAPSE" => "t",
      "SPS" => "c"
    }[s]
  end

  # Download some file_name (e.g. 100GOPRO/GOPR0001.JPG) to a local directory
  # If to_fname is specified, save it locally as that, otherwise use the
  # same base filename as on the camera.
  def download_media(file_name, to_dir, to_fname=nil)
    if not File.directory?(to_dir)
      log_verb("Making directory #{to_dir}")
      FileUtils.mkdir_p(to_dir)
    end
    fname = (to_fname == nil) ? File.basename(file_name) : to_fname
    to_file = File.join(to_dir, fname)
    url = get_media_url(file_name)
    log_verb("Downloading #{file_name} to #{to_file}")
    resp = http_get(url)
    if http_resp_ok(resp)
      File.open(to_file, mode="wb") { |f| f.write(resp.body)}
    else
      return false, "Unable to download #{url} to destination #{to_file}"
    end
    return true, to_file
  end

  # Download some file_name (e.g. 100GOPRO/GOPR0001.JPG) to a local directory
  # If to_fname is specified, save it locally as that, otherwise use the 
  # same base filename as on the camera.
  # to_dir always contains the subdir /100GOPRO/
  def download_mediaKF(cam_file_name, to_dir, local_fname=nil)
    if not File.directory?(to_dir)
      ltp_log($VERB, "Making directory #{to_dir}")
      FileUtils.mkdir_p(to_dir)
    end
    #chris
    fname = (local_fname == nil) ? cam_file_name : local_fname
    # to_file = File.join(to_dir, fname)
    # url = get_media_url(cam_file_name)
    # ltp_log($VERB, "Downloading #{cam_file_name} to #{to_file}")

    to_file = File.join(to_dir, fname)
    dir_parent = File.basename(to_dir)
    url = get_media_url(dir_parent + '/' + cam_file_name)
    ltp_log($VERB, "Downloading #{cam_file_name} to #{to_file}")
    resp = http_get(url)
    if http_resp_ok(resp)
      File.open(to_file, mode="wb") { |f| f.write(resp.body)}
    else
      return false, "Unable to download #{url} to destination #{to_file}"
    end
    return true, to_file
  end


  def download_last_media(to_dir)
    if not File.directory?(to_dir)
      log_verb("Making directory #{to_dir}")
      FileUtils.mkdir_p(to_dir)
    end
    parsed = get_parsed_gpmedialist
    folder = parsed["media"].pop
    dir = folder["d"]
    f = folder["fs"].pop
    name = f["n"]
    fullpath = "#{dir}/#{name}"
    download_media(fullpath, to_dir)
    return File.join(to_dir, name)
  end

  # Returns a list of media with all groups enumerated as files
  # Can be filtered with suffix arg (e.g. for only 'MP4' files)
  def get_medialist(suffix=nil)
    ret = []
    parsed = get_parsed_gpmedialist
    #    log_info(parsed)
    return false if parsed == false
    if ( !parsed.has_key?("id") && !parsed.has_key?("media") )
      log_error( "Bad medialist value: #{parsed}")
      exit ExitCode::ERROR_PARSING_GPMEDIALIST
    end
    parsed["media"].each do |folder|
      dir = folder["d"]
      folder["fs"].each do |f|
        name = f["n"]
        next if suffix != nil and suffix != name.split(".")[1]
        size = f["s"].to_i
        group = (f["g"] == nil) ? false : f["g"].to_i
        file_details_str = "name=%s, dir=%s, size=%s, group=%s, " \
        %[name, dir, size, group]
        if not group
          fullname = "#{dir}/#{name}"
          log_verb(file_details_str)
          ret << fullname
        else
          first = f["b"].to_i
          last = f["l"].to_i
          type = f["t"]
          ###type = get_photo_type(nc, fullname)
          miss = f["m"]
          file_details_str += "first=%s, last=%s, type=%s, miss=%s" \
          %[first, last, type, miss]
          log_verb(file_details_str)
          prefix, ext = name.split(".")
          (first..last).each { |i|
            # Skip if file is listed as 'missing'
            next if miss.include?(i.to_s)
            # Replace the last i.to_s.length digits with current i.to_s digits
            file = prefix[0..-(i.to_s.length + 1)] + i.to_s
            fullname = "#{dir}/#{file}.#{ext}"
            ret << fullname
          }
        end # if not group
      end # end folder.each
    end # end "media".each
    return ret
  end

  # Download all media on the SD card
  # Optionally stop after N files by setting stop_after=N
  def download_all_media(to_dir, stop_after=nil)
    if not File.directory?(to_dir)
      log_verb("Making directory #{to_dir}")
      FileUtils.mkdir_p(to_dir)
    end
    n = 0
    get_medialist().each { |f|

      #To keep camera alive, from going into power saving mode in 5 minutes. Downloading burst photo of 30 might take longer than 5 minutes.
      get_status(:ok)

      ret, msg = download_media(f, to_dir)
      (return false, msg) if ret == false
      n += 1
      break if stop_after != nil and n > stop_after
    }
    return true, "#{n} files downloaded"
  end

  # Delete a single file
  def delete_single_file(f)
    wait_until_not_busy
    if @remote_api_version == 1
      cmd = delete_file[:set]
      # Filename sent as hex-length prefixed string
      param = "%#{f.length.to_s(16)}#{f}"
      resp = get_camera_resp(cmd, param)
    else
      resp = send_delete_file_api2(f)
    end
    return resp
  end

  # Delete a single group of files
  def delete_single_group(g)
    wait_until_not_busy
    if @remote_api_version == 1
      cmd = delete_group[:set]
      # Filename sent as hex-length prefixed string
      param = "%#{g.length.to_s(16)}#{g}"
      resp = get_camera_resp(cmd, param)
    end
    return resp
  end

  # Delete the last file encoded
  def delete_last_file()
    wait_until_not_busy
    if @remote_api_version == 1
      cmd = delete_last[:set]
      resp = get_camera_resp(cmd)
    else
      resp = send_delete_last_api2
    end
    wait_until_not_busy()
    return resp
  end

  # Override Camera.delete_all_media()
  def delete_all_media(force=false)
    wait_until_not_busy
    if @remote_api_version == 1
      wait_until_ok()
      if (status(:photos_on_card) > 0 or
      status(:videos_on_card) > 0 or
      force == true)
        set(:delete_all, key=nil, wait_time=1, decode=false)
        wait_until_not_busy()
        wait_until_ok()
      else
        log_verb("Skipping (DA) delete b/c is empty and force==false")
      end
      return true
    end

    if @remote_api_version == 2

      photos_on_card = get_status_api2(:photos_on_card)
      photos_on_card=0 if photos_on_card == false

      videos_on_card = get_status_api2(:videos_on_card)
      videos_on_card=0 if videos_on_card == false

      if (photos_on_card.to_i > 0 or videos_on_card.to_i > 0 or force == true)
        log_info("Deleting all media")
        send_delete_all_api2
        wait_until_not_busy()
        sleep(2)
      else
        log_verb("Skipping (DA) delete b/c is empty and force==false")
      end
      return true
    end
  end

  def get_lcd_section(s)
    get(:lcd_display, s, wait_time=0, decode=true)
  end

  # Return a string of the multek
  # str0 and str1 represent "0" and "1" bits (must be the same length)
  # Double-chars look better (closer to square pixels of multek)
  def get_multek(str0="  ", str1="00")
    width = 64
    output = ""
    arr = []
    for i in (0..4)
      # Keep trying to get first part of MulTek
      if i == 0
        n_retries = 10
        n = 1
        while n < n_retries
          retval = get(lcd_display, i, wait_time=0.5)
          break if retval != false and retval[:success] == true
          n += 1
        end
      else
        retval = get(lcd_display, i, wait_time=0)
      end
      return log_warn("Unable to get MulTek") if retval == false
      return log_warn("get_multek unsuccessful") if retval[:success] == false
      data = retval[:data]
      bits = ""
      data.each_char { |c| bits += "%04b" %c.hex }
      # Data comes out last bit first, so we must reverse it
      bits.reverse.each_char { |b| output += (b == "0") ? str0 : str1 }
      # Each line must be reversed as well
      tmp_arr = []
      tmp_arr << output.slice!(0...(width*str0.size)).reverse while output.size > 0
      # Prepend to final array
      arr.unshift(tmp_arr)
    end
    return arr
  end

  #Path (must be in this format) - http://10.5.5.9:8080/videos/DCIM/100GOPRO/G0090236.MP4
  def media_exists?(path)
    resp = nil
    Net::HTTP.start(@ip, @http_port) { |http|
      resp = http.head(path[20..-1])
    }
    return http_resp_ok(resp)
  end

  def get_n_videos()
    return get_status(:videos_on_card)
  end

  #Return true video minutes available. If time_remaining_format = 0, video_minutes_available in hh::mm.
  #If time_remaining_format = 1, video_minutes_available in mm:ss
  def get_mins_avail()
    format = 1 # 0
    mins_avail = get_status(:video_minutes_available)
    sleep(0.5)
    format = get_status(:time_remaining_format) if @remote_api_version == 1

    format == 1 ? mins_avail/60 : mins_avail
  end

  # Returns the number of images remaining, as reported by the camera.
  def get_photos_avail()
    get_status(:photos_available)
  end

  def get_n_photos()
    return get_status(:photos_on_card)
  end

  def status(key)
    return get_status(key) if @curr_status == nil
    retval = @curr_status[key]
    log_debug("status[%s] => %s" %[key, retval])
    return retval
  end

  def get_status(key)
    return get_status_api2(key) if @remote_api_version == 2

    begin
      resp = get_camera_resp(status_sx[:get])
      stat = resp.body
      raise if http_resp_ok(resp) != true
    rescue StandardError => e
      log_error("Error retrieving camera info (sx).  Is pairing code '#{@pairing_code}' correct?")
      exit ExitCode::SE_SX_ERROR if @do_exit
      return false
    end
    # Sometimes status will only return :ok == 1
    if stat.length == 1
      @curr_status = { :ok => stat[0].ord == 0 }
      retval = @curr_status.has_key?(key) ? @curr_status[key] : false
      log_verb("get_status[%s] => %s" %[key, retval])
      return retval
    end

    # Normal case
    @curr_status = {
      :ok                       => stat[0].ord == 0,
      :mode_cm                  => stat[1].ord,
      :microphone_mode          => stat[2].ord,
      :setup_default_mode       => stat[3].ord,
      :video_spot_metering      => stat[4].ord,
      :multi_photo_timelapse          => stat[5].ord,
      :setup_auto_off                 => stat[6].ord,
      :video_fov                => stat[7].ord, #field of view
      :photo_resolution         => stat[8].ord, #photo_resolution
      :multi_photo_resolution   => stat[8].ord, #multi_photo_resolution to be compatible with remote api2
      :video_resolution_fps     => stat[9].ord,
      :audio_input              => stat[10].ord,
      :playback_mode            => stat[11].ord,
      # Position syntax: Hours:Minutes:Seconds-frame
      :position                 => "%s:%s:%s-%s" \
      %[(stat[12].ord << 24), stat[13].ord << 16,stat[14].ord << 8, (stat[15].ord)],
      :setup_beep               => stat[16].ord,
      :setup_led                => stat[17].ord,
      # Flags 1
      :boss_ready               => ((stat[18].ord >> 7) & 0x01),
      :locate_ll                => ((stat[18].ord >> 6) & 0x01),
      :setup_video_format       =>  ((stat[18].ord >> 5) & 0x01),  #recording_mode
      :setup_osd                => ((stat[18].ord >> 4) & 0x01), #on_screen_display
      :quick_capture_active     => ((stat[18].ord >> 3) & 0x01),
      :setup_orientation        => ((stat[18].ord >> 2) & 0x01),  #upside down
      :video_live_feed          => ((stat[18].ord >> 1) & 0x01),
      :preview_pv               => ((stat[18].ord >> 0) & 0x01), #preview active
      :battery                  => stat[19].ord,
      :usb_mode                 => stat[20].ord,
      # 2-Byte fields
      :photos_available         => stat[21..22].unpack("H*")[0].to_i(16),
      :photos_on_card           => stat[23..24].unpack("H*")[0].to_i(16),
      #      :video_minutes_available  => calc_mins_avail(stat[25..26].unpack("H*")[0].to_i(16)),
      :video_minutes_available  =>  stat[25..26].unpack("H*")[0].to_i(16),
      :videos_on_card           => stat[27..28].unpack("H*")[0].to_i(16),
      :shutter_sh               => stat[29].ord,
      # Flags 2
      :video_pt_color           => ((stat[30].ord >> 7) & 0x01),
      :video_low_light          => ((stat[30].ord >> 6) & 0x01),
      :cancel_ota               => ((stat[30].ord >> 5) & 0x01),
      :ota_fw_update            => ((stat[30].ord >> 4) & 0x01),
      :sd_status                => ((stat[30].ord >> 3) & 0x01),
      :preview_available        => ((stat[30].ord >> 2) & 0x01),
      :video_pt                 => ((stat[30].ord >> 1) & 0x01),
      :busy                     => ((stat[30].ord >> 0) & 0x01),

      :hls_segment_size         => stat[31].ord,
      :multi_photo_burst        => stat[32].ord,
      :photo_continuous         => stat[33].ord,  #continuous_shot
      :video_pt_wb              => stat[34].ord,
      :video_piv                => stat[36].ord,  #photo-in-video
      :video_looping            => stat[37].ord,
      # Position syntax: Hours:Minutes:Seconds-frame
      :loop_position            => "%s:%s:%s-%s" \
      %[(stat[41].ord << 24), stat[42].ord << 16,
      stat[43].ord << 8, (stat[44].ord)],

      #Flags 3
      #time_remaining_format relates to video_minutes_available. If time_remaining_format = 0, video_minutes_available in hh::mm. If time_remaining_format = 1, video_minutes_available in mm:ss
      :time_remaining_format => ((stat[46].ord >> 7) & 0x01),

      :video_resolution          => stat[50].ord,
      :video_fps                  => stat[51].ord,

      # Flags 4 (2-bit fields)
      :protune_settings_not_default => ((stat[52].ord >> 4) & 0x03),
      :video_pt_sharp               => ((stat[52].ord >> 2) & 0x03),
      :video_pt_iso                 => ((stat[52].ord >> 0) & 0x03), #gain

      :video_pt_ev                  => stat[53].ord
    }
    retval = @curr_status[key]
    log_debug("get_status[%s] => %s" %[key, retval])
    return retval
  end

  def parse_status_api2(refresh)
    if refresh == true or @curr_status ==nil
      resp = send_status_api2
      begin
        parsed = JSON.parse(resp.body)
      rescue StandardError => e
        s = "Error Parsing Status JSON (#{e.message})"
        if @do_exit
          log_error(s)
          exit ExitCode::ERROR_PARSING_STATUS_JSON
        else
          log_warn(s)
          return false
        end
      end
      @curr_status = parsed
    end
    return @curr_status
  end

  # Example: wifi_name = :video_spot_metering
  def get_setting_status_api2_by_name(wifi_name)
    # log_verb("Getting status by name API2")
    id, value = get_id_value(wifi_name)
    return get_setting_status_api2_by_id(id)
  end

  # Example: id = 54
  def get_setting_status_api2_by_id(id)
    # log_verb("Getting status by ID API2")
    retries = 1
    for i in 1..retries
      parsed = parse_status_api2(false)
      return false if parsed == false
      if parsed["settings"] == nil and i < retries
        sleep 5
        log_info("Retry sending status command...")
      elsif parsed["settings"] == nil and i >= retries
        (log_error("/status doesn't contain key settings")
        exit ExitCode::NON_EXISTING_SETTINGS_KEY) if @do_exit
        return false
      else
        break
      end
    end
    parsed["settings"][id.to_s]
  end

  def get_status_api2(key)
    # log_verb("Getting status API2")
    retries = 1
    for i in 1..retries
      sleep(0.5)
      parsed = parse_status_api2(true)
      return false if parsed == false
      if parsed["status"] == nil and i < retries
        sleep 5
        log_info("Retry sending status command...")
      elsif parsed["status"] == nil and i >= retries
        (log_error("/status doesn't contain key status")
        exit ExitCode::NON_EXISTING_STATUS_KEY) if @do_exit
        return false
      else
        break
      end
    end
    id = status_api2_mapping[key]
    parsed["status"][id]
  end

  def refresh_status
    return parse_status_api2(true)
  end

  # Returns the SugarGlider name of the current setting
  # 'sym' is the top-level key of @camera.setting
  # E.g. get_setting_name_by_sym(:video_resolution) ==> "1080_SUPER"
  def get_setting_name_by_sym_api2(sym, refresh=true)
    log_verb("Looking up current setting for #{sym}")
    keys = setting[sym]
    # Descend through level1 (l1), level2 (l2), and options
    @settings_json_hash["modes"].each { |mode|
      if mode["path_segment"] == keys['l1']
        mode["settings"].each { |setting|
          if setting["path_segment"] == keys['l2']
            id = setting["id"]
            val = parse_status_api2(refresh)["settings"][id.to_s]
            setting["options"].each { |opt|
              if opt["value"] == val
                # Get gpControl-specific name of the option (varies by camera)
                gp_name = opt["display_name"]
                # Backwards lookup to consistent SugarGlider name
                lookup_hash = method(keys['method']).call()
                sg_name = lookup_hash.key(gp_name)
                log_warn("Unable to find key for %s in %s" \
                %[gp_name, lookup_hash]) if sg_name == nil
                return sg_name
              end
            } # options
            log_warn("Level 3 -- No value matching %s found in %s" \
            %[val, setting["options"]])
            return nil
          end
        } # settings
        log_warn("Level 2 -- No path_segment named %s found in %s" \
        %[keys['l2'], mode["settings"]])
        return nil
      end
    } # modes
    log_warn("Level 1 -- No path_segment named %s found in %s}" \
    %[keys['l1'], @settings_json_hash['modes']])
    return nil
  end

  def get_cc_status(key)
    begin
      resp = get_camera_resp(status_cc[:get])
      stat = resp.body
      raise if stat == nil
    rescue StandardError => e
      log_error("Error retrieving camera info (cc)")
      exit ExitCode::UNSUCCESSFUL if @do_exit
      return false
    end

    if resp.code != '200'
      log_error("Error retrieving camera info (cc)")
      exit ExitCode::UNSUCCESSFUL if @do_exit
      return false
    end

    # Normal case
    @curr_status = {
      :ok               => stat[0].ord == 0,
      :has_camera_roll  => ((stat[31].ord & 0x01) != 0) ? 1 : 0,
      :has_ota          => ((stat[31].ord & 0x02) != 0) ? 1 : 0,
      :has_ltp          => ((stat[31].ord & 0x04) != 0) ? 1 : 0,
      :has_3D           => ((stat[31].ord & 0x08) != 0) ? 1 : 0,
      :has_ccl          => ((stat[31].ord & 0x10) != 0) ? 1 : 0,
    }
    retval = @curr_status[key]
    log_debug("get_cc_status[%s] => %s" %[key, retval])
    return retval
  end

  def calc_mins_avail(m)
    return m/60 if m > 1200
    return m
  end

  # the video_minutes_available in get_status returns seconds if < 60 minutes
  # available.  To keep things consistent we force it to return minutes if it
  # has ever reported over 600.
  def calc_mins_avail2(m)
    log_info("calc_mins_avail:: m=#{m}, @scale=#{@scale_mins_avail}")
    return m/60 if @scale_mins_avail == true
    if m > 600
      log_info("Setting scale=true!")
      @scale_mins_avail = true
      return m/60
    end
    return m
  end

  def update_decoded_status()
    @decoded_curr_status = {
      :ok                    => @curr_status[:ok],
      :mode_cm               => val2key(mode_cm, @curr_status[:mode_cm]),
      :microphone_mode       => @curr_status[:microphone_mode],
      :setup_default_mode    => val2key(setup_default_mode, @curr_status[:setup_default_mode]),
      :video_spot_metering   => val2key(video_spot_metering, @curr_status[:video_spot_metering]),
      :multi_photo_timelapse => val2key(multi_photo_timelapse, @curr_status[:multi_photo_timelapse]),
      :setup_auto_off        => val2key(setup_auto_off, @curr_status[:setup_auto_off]),
      :video_fov             => val2key(video_fov, @curr_status[:video_fov]),  #field of view
      :photo_resolution      => val2key(photo_resolution, @curr_status[:photo_resolution]),
      :multi_photo_resolution => val2key(multi_photo_resolution, @curr_status[:multi_photo_resolution]),
      :video_resolution_fps  => @curr_status[:video_resolution_fps],
      :audio_input          => val2key(audio_input, @curr_status[:audio_input]),
      :playback_mode        => val2key(playback_mode, @curr_status[:playback_mode]),
      :position             => @curr_status[:position],
      :setup_beep           => val2key(setup_beep, @curr_status[:setup_beep]),
      :setup_led                  => val2key(setup_led, @curr_status[:setup_led]),
      :boss_ready           => @curr_status[:boss_ready],
      :locate_ll               => val2key(locate_ll, @curr_status[:locate_ll]),
      :setup_video_format   => val2key(setup_video_format, @curr_status[:setup_video_format]),  #recording mode
      :setup_osd                  => val2key(setup_osd, @curr_status[:setup_osd]),  #on_screen_display
      :quick_capture_active => val2key(obm, @curr_status[:quick_capture_active]),
      :setup_orientation    => val2key(setup_orientation, @curr_status[:setup_orientation]),  #upside down
      :video_live_feed      => @curr_status[:video_live_feed],
      :preview_pv           => @curr_status[:preview_pv],   #preview_active
      :battery              => @curr_status[:battery],
      :usb_mode             => @curr_status[:usb_mode],
      :photos_available         => @curr_status[:photos_available],
      :photos_on_card           => @curr_status[:photos_on_card],
      :video_minutes_available  => @curr_status[:video_minutes_available],
      :videos_on_card           => @curr_status[:videos_on_card],
      :shutter_sh               => @curr_status[:shutter_sh],
      :video_pt_color           => val2key(video_pt_color, @curr_status[:video_pt_color]),
      :video_low_light          => @curr_status[:video_low_light],
      #      :low_light2         => @curr_status[:low_light2],
      :cancel_ota         => @curr_status[:cancel_ota],
      :ota_fw_update      => @curr_status[:ota_fw_update],
      :preview_available  => @curr_status[:preview_available],
      :video_pt           => @curr_status[:video_pt],
      :busy               => @curr_status[:busy],
      :hls_segment_size   => @curr_status[:hls_segment_size],
      :multi_photo_burst  => val2key(multi_photo_burst, @curr_status[:multi_photo_burst]),
      :photo_continuous   => val2key(photo_continuous, @curr_status[:photo_continuous]), #continuous_shot
      :video_pt_wb        => @curr_status[:video_pt_wb],
      :video_piv          => val2key(video_piv, @curr_status[:video_piv]),
      :video_looping      => val2key(video_looping, @curr_status[:video_looping]),
      :loop_position      => @curr_status[:loop_position],
      :video_resolution   => val2key(video_resolution, @curr_status[:video_resolution]),
      :video_fps          => val2key(video_fps, @curr_status[:video_fps]),
      :video_pt_sharp     => val2key(video_pt_sharp, @curr_status[:video_pt_sharp]),
      :video_pt_iso       => val2key(video_pt_iso, @curr_status[:video_pt_iso]),  #gain
      :video_pt_ev        => val2key(video_pt_ev, @curr_status[:video_pt_ev]),
    }
  end

  def decoded_status(key)
    return @decoded_curr_status[key]
  end

  def bacpac_status(key)
    return get_bacpac_status(key) if @curr_bacpac_status == nil
    retval = @curr_bacpac_status[key]
    log_debug("bacpac_status[%s] => %s" %[key, retval])
    return retval
  end

  def get_bacpac_status(key)
    resp = get(:status_se, nil, wait_time=0.5, decode=true, expected=nil,
    tries=3, interval=5, target="bacpac")
    if resp.is_a?(Hash) and resp.has_key?(:success) and resp[:success] == true
      @curr_bacpac_status = resp
    else
      log_error("Error retrieving camera info")
      exit ExitCode::SE_SX_ERROR if @do_exit
      return false
    end
    retval = @curr_bacpac_status[key]
    log_debug("get_bacpac_status[%s] => %s" %[key, retval])
    return retval
  end

  def get_bacpac_status2(key)
    stat = get_bacpac_resp(status_se[:get]).body
    if stat == nil
      log_error("Error retrieving camera info")
      exit ExitCode::SE_SX_ERROR if @do_exit
      return false
    end
    @curr_bacpac_status = {
      :ok                         => stat[0].ord == 0,
      :battery                    => stat[1].ord,
      :wifi_mode                  => stat[2].ord,
      :bluetooth_mode             => stat[3].ord,
      :wifi_rssi                  => stat[4].ord,
      :shutter                    => stat[5].ord == 1,
      :preview_status             => stat[8].ord >> 4,
      :preview_mode               => stat[8].ord & 0x0F,
      :camera_power               => stat[9].ord == 1,
      :wifi_error_recovery_active  => stat[10].ord == 1,
      :camera_ready               => stat[11].ord == 1,
      :camera_model               => stat[12].ord,
      :camera_protocol_version    => stat[13].ord,
      :camera_attached            => stat[14].ord == 1,
    }
    retval = @curr_bacpac_status[key]
    log_debug("get_bacpac_status[%s] => %s" %[key, retval])
    return retval
  end

  def get_level_1_index(v)
    @settings_json_hash['modes'].index{|i| i['path_segment'].to_s == v.to_s}
  end

  def get_level_2_index(l1, v)
    @settings_json_hash['modes'][l1]['settings'].index{|i| i['path_segment'].to_s == v.to_s}
  end

  def get_level_3_index(l1, l2, v)
    @settings_json_hash['modes'][l1]['settings'][l2]['options'].index{|i| i['display_name'].to_s == v.to_s}
  end

  #Ex: wifi_name = :photo_pt_wb, k = "AUTO"
  def get_id_value(wifi_name, k=nil)
    value = nil
    hash = setting[wifi_name]
    (log_warn("Unable to find command #{wifi_name}"); return nil) if hash == nil

    l1_index = get_level_1_index(hash['l1'])
    (log_warn("Unable to find l1 index in #{hash}"); return nil) if l1_index == nil

    l2_index = get_level_2_index(l1_index, hash['l2'])
    (log_warn("Unable to find l2 index in #{hash}"); return nil) if l2_index == nil

    id = @settings_json_hash['modes'][l1_index]['settings'][l2_index]['id']

    if k != nil
      option = method(hash['method']).call[k]

      l3_index = get_level_3_index(l1_index, l2_index, option)
      if l3_index == nil
        p @settings_json_hash['modes'][l1_index]['settings'][l2_index]['options']
        p option
        log_warn("key=#{k}")
        log_warn("Unable to find l3 index in #{hash} via #{option}")
        # raise Exception
        return nil
      end
      value = @settings_json_hash['modes'][l1_index]['settings'][l2_index]['options'][l3_index]['value']
      log_warn("#{wifi_name} has no value #{k}") if value == nil
    end

    return id, value
  end

  def set_default_capture_mode(x)
    a_set = already_set?(:setup_default_mode, x)

    if a_set[0] == false
      success = false
      resp = set(:setup_default_mode, x)
      success = resp[:success]
      return false, "Set video default sub-mode to #{x} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success
    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set video default sub-mode to #{x} successful"
  end

  def set_video_def_sub_mode(x)
    return false, "Default sub-mode set not valid in API v1" if @remote_api_version == 1

    a_set = already_set?(:video_dft_submode, x)
    if a_set[0] == false
      success = false
      resp = set(:video_dft_submode, x)
      success = resp[:success]
      return false, "Set video default sub-mode to #{x} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success
    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set video default sub-mode to #{x} successful"
  end

  def set_photo_def_sub_mode(x)
    return false, "Default sub-mode set not valid in API v1" if @remote_api_version == 1

    a_set = already_set?(:photo_dft_submode, x)
    if a_set[0] == false
      success = false
      resp = set(:photo_dft_submode, x)
      success = resp[:success]
      return false, "Set photo default sub-mode to #{x} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success
    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set photo default sub-mode to #{x} successful"
  end

  def set_multi_def_sub_mode(x)
    return false, "Default sub-mode set not valid in API v1" if @remote_api_version == 1

    a_set = already_set?(:multi_photo_dft_submode, x)
    if a_set[0] == false
      success = false
      resp = set(:multi_photo_dft_submode, x)
      success = resp[:success]
      return false, "Set multi_shot default sub-mode to #{x} failed (exp=%s, act=%s)" \
      %[resp[:expected], resp[:detected]] if !success
    elsif a_set[0] == nil
      return false, a_set[1]
    end
    return true, "Set multi_shot default sub-mode to #{x} successful"
  end

  def set_default_mode_sub_mode(x)
    if ["VIDEO", "VIDEO_TIMELAPSE", "VIDEO_PIV", "VIDEO_LOOPING"].include?(x)
      ret, msg = set_default_capture_mode("VIDEO")
      return ret, msg if ret == false
      ret, msg = set_video_def_sub_mode(x) if @remote_api_version == 2
      return ret, msg if ret == false
    elsif ["PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"].include?(x)
      ret, msg = set_default_capture_mode("PHOTO")
      return ret, msg if ret == false
      ret, msg = set_photo_def_sub_mode(x) if @remote_api_version == 2
      return ret, msg if ret == false
    elsif ["BURST", "TIMELAPSE", "NIGHTLAPSE"].include?(x)
      ret, msg = set_default_capture_mode("MULTI_SHOT")
      return ret, msg if ret == false
      ret, msg = set_multi_def_sub_mode(x) if @remote_api_version == 2
      return ret, msg if ret == false
    else
      log_warn("Unrecognized mode #{x}")
      return false, "Failed to set default mode/sub-mode"
    end
    return true, "Successfully set mode/sub-mode to #{x}"
  end

  def set_quick_capture(x)
    if @remote_api_version == 1
      if !already_set?(:obm, x)[0]
        resp = set(:obm, x)
      else
        return true, "OBM already set to #{x}"
      end
    elsif @remote_api_version == 2
      if !already_set?(:setup_quick_capture, x)[0]
        resp = set(:setup_quick_capture, x)
      else
        return true, "Quick-capture already set to #{x}"
      end
    end
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set quick-capture/OBM to #{x}"
    else
      return ret, "Set quick-capture/OBM to #{x} unsuccessful"
    end
  end

  def set_osd(x)
    if !already_set?(:setup_osd, x)[0]
      resp = set(:setup_osd, x)
      ret = resp[:success]
      if ret == true
        return ret, "Successfully set OSD to #{x}"
      else
        return ret, "Set OSD to #{x} unsuccessful"
      end
    else
      return true, "OSD already set to #{x}"
    end
  end

  def set_led(x)
    resp = set(:setup_led, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set LED to #{x}"
    else
      return ret, "Set LED to #{x} unsuccessful"
    end
  end

  def set_beep_volume(x)
    resp = set(:setup_beep, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set beep volume to #{x}"
    else
      return ret, "Setting beep volume to #{x} unsuccessful"
    end
  end

  def set_lcd_brightness(x)
    resp = set(:setup_lcd_brightness, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set lcd brightness to #{x}"
    else
      return ret, "Setting lcd brightness to #{x} unsuccessful"
    end
  end

  def set_lcd_lock(x)
    resp = set(:setup_lcd_lock, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set lcd lock to #{x}"
    else
      return ret, "Setting lcd lock to #{x} unsuccessful"
    end
  end

  def set_lcd_display(x)
    resp = set(:setup_lcd_display, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set lcd display to #{x}"
    else
      return ret, "Setting lcd display to #{x} unsuccessful"
    end
  end

  def tag_hilight()
    if @remote_api_version == 2
      if http_resp_ok(send_tag_hilight_api2())
        return true, "Hilight tag successful"
      else
        return false, "Hilight tag failed"
      end
    else
      return false, "Hilight tagging not supported on api != 2"
    end
  end

  def set_lcd_auto_off(x)
    resp = {}
    3.times {
      resp = set(:setup_lcd_auto_off, x)
      break if resp[:success]
      log_warn("Retrying (this command usually fails on first try)")
      sleep 1
    }
    return true, "LCD auto-off successful" if resp[:success]
    return false, "LCD auto-off failed"
  end

  # Additional settings that can be toggled.
  def set_photo_raw(x) # ON|OFF
    resp = set(:photo_raw, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set RAW image setting to #{x}."
    else
      return ret, "Setting RAW image setting to #{x} was unsuccessful."
    end
  end

  def set_photo_wdr(x) # ON|OFF
    resp = set(:photo_wdr, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set Wide Dynamic Range setting to #{x}."
    else
      return ret, "Setting Wide Dynamic Range setting to #{x} was unsuccessful."
    end
  end

  def set_video_eis(x) # ON|OFF
    resp = set(:video_eis, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set Electronic Image Stabilization setting to #{x}."
    else
      return ret, "Setting Electronic Image Stabilization setting to #{x} was unsuccessful."
    end
  end

  def set_video_awf(x) # Not exactly a toggle: OFF|WIND|STEREO
    resp = set(:video_awf, x)
    ret = resp[:success]
    if ret == true
      return ret, "Successfully set Audio Wind Filter setting to #{x}."
    else
      return ret, "Setting Audio Wind Filter setting to #{x} was unsuccessful."
    end
  end

  ### Serial commands section.
  def send_serial( cmd, squelch_warning=false )
    log_warn("Called send_serial() on a wifi camera. This is probably not what you want.") unless squelch_warning
    return false, "Serial_iface isn't defined." unless @serial_iface
    tmp_serial_port = SerialPort.new(@serial_iface, 115200)
    return false, "Couldn't connect to the serial_iface." unless tmp_serial_port
    log_info("SENDING SERIAL ==> #{cmd}")
    tmp_serial_port.write("\r\n")
    tmp_serial_port.write(cmd.chomp)
    tmp_serial_port.write("\r\n")
    return true, "Sent serial command: #{cmd}"
  end # End send_serial()

  ### BLE section
  #
  def ble_state
    url = "#{make_gpcontrol_url}/command/ble/pairing_available"
    # http_get(url)
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_pairing_phase(phaseName)
    if (phaseName=="enter")
      phase = 1
    elsif (phaseName=="exit")
      phase = 0
    else
      log_error("wifi_camera.rb ble_pairing ERROR:")
      return false
    end
    url = "#{make_gpcontrol_url}/command/ble/pairing_phase?p=#{phase}"
    cmd = "curl -X GET #{url}"
    # puts "ble_pairing_phase: cmd=#{cmd}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_get_autoconnect
    url = "#{make_gpcontrol_url}/command/ble/configure"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_set_autoconnect(enable_disable)
    url = "#{make_gpcontrol_url}/command/ble/configure?auto_connect=#{enable_disable}"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_scan(start_stop)
    url = "#{make_gpcontrol_url}/command/ble/scan?p=#{start_stop}"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_scan_list(index=-1)
    if index==-1
      url = "#{make_gpcontrol_url}/command/ble/scan/list"
    else
      url = "#{make_gpcontrol_url}/command/ble/scan/list?p=#{index}"
    end
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_pair_start(address, type)
    url = "#{make_gpcontrol_url}/command/ble/pair/start?device=#{address}&address_type=#{type}"
    cmd = "curl -X GET #{url}"
    # puts "ble_pair_start: cmd=#{cmd}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_pair_cancel(address, type)
    url = "#{make_gpcontrol_url}/command/ble/pair/cancel?device=#{address}&address_type=#{type}"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_pair_status
    url = "#{make_gpcontrol_url}/command/ble/pair/status"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_whitelist_list(index=-1)
    if index==-1
      url = "#{make_gpcontrol_url}/command/ble/whitelist/list"
    else
      url = "#{make_gpcontrol_url}/command/ble/whitelist/list?p=#{index}"
    end
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  # This can be used to add/remove a device from the whitelist
  # This can ALSO be used to ENABLE/DISABLE a device connection to the camera
  #
  def ble_whitelist_remove(address)
    url = "#{make_gpcontrol_url}/command/ble/whitelist/list/configure?device=#{address}&remove=1"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

  def ble_whitelist_autoconnect(address, enable_disable)
    url = "#{make_gpcontrol_url}/command/ble/whitelist/list/configure?device=#{address}"
    url += "&auto_connect=#{enable_disable}"
    cmd = "curl -X GET #{url}"
    h = Host.new()
    o, e, s = h.sys_exec(cmd)
    return o
  end

end # end class Camera

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  c = get_wifi_camera("10.5.5.9", "goprohero1")
  # c.setup_lcd_brightness_api2.keys.each { |x| c.set_lcd_brightness(x)}
  # c.setup_lcd_lock_api2.keys.each { |x| c.set_lcd_lock(x) }
  # c.setup_lcd_display_api2.keys.each { |x| c.set_lcd_display(x)}
  # c.setup_lcd_auto_off_api2.keys.each { |x| c.set_lcd_auto_off(x)}

  # c.set(:video_pt_iso_mode, "LOCK")
  # c.set(:video_pt_iso_mode, "MAX")
  # ["100", "200", "400", "800"].each { |iso|
  #   c.set(:photo_pt_iso_min, iso)
  # }
  # ["100", "200", "400", "800"].each { |iso|
  #   c.set(:multi_photo_pt_iso_min, iso )
  # }
  # c.set_photo_protune_iso("400")
  # ["100", "200", "400", "400", "800", "200"].each { |iso|
  #   c.set_photo_protune_iso_min(iso)
  # }

  # ["100", "200", "400", "400", "800"].each { |iso|
  #   c.set_photo_protune_iso(iso)
  # }
  # ["100", "200", "400", "800"].each { |iso|
  #   c.set(:multi_photo_pt_iso, iso )
  # }
  # c.capture_multi_photo_burst("8WIDE", "5_1")
  # c = get_camera("wifi", "10.5.5.9")
  # p c.get_status(:preview_pv) == 1
  # exit 1
  # require 'pp'
  # pp c.set(c.preview_pv, "ON", wait_time=0.5, decode=true, expected=nil,
  # tries=3, interval=5, target="bacpac")
  # pp c.get(c.bacpac_cv, nil, wait_time=0.5, decode=true, expected=nil,
  # tries=3, interval=5, target="bacpac")
  # pp c.get(c.bacpac_ap_key, nil, wait_time=0.5, decode=true, expected=nil,
  # tries=3, interval=5, target="bacpac")
  # c.get_bacpac_status(:ok)
  # pp c.curr_bacpac_status
  #puts c.get_multek
  # puts c.get_low_bitrate_mode
  #  JSON.parse(c.get_medialist().body)
  #  while true
  #    puts c.get_multek
  #    break
  #  end
  # c.ble_scan_start()
end
