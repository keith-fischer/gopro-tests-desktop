#Specifically use to parse responsed information
require_relative 'log_utils'

module MTPUtils
  include LogUtils
  def search_string(str, search_value)
    found = ""
    lines = str.lines()
    lines.each {|line|
      if line.match(search_value)
        found = line
        break
      end
    }
    found
  end

  def split_string(line, delimeter)
    splitted = line.split(delimeter)
    final_split = []
    splitted.each {|s|
      final_split.push(s.strip)
    }
    final_split
  end

  def success_response?(str)
    case @os
    when "MAC"
      rc_line = search_string(str.body, "responseCode")

      splitted = rc_line.split(':')
      if splitted[1].include?("0x2001")
        return true, splitted[1]
      else
        return false, splitted[1]
      end
    when "WIN"

    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
  end

  def parse_device_version(data)
    splitted = data.split(':')
    splitted1 = splitted[1].split('.')
    release = splitted1[0].lstrip
    type = splitted1[1].to_i
    build = splitted1.join(".").chomp
    return release, type, build
  end

  def parse_device_build(str)
    (log_error("Unsuccessful http code #{str.code}"); exit ExitCode::MTP_UNSUCCESSFUL_HTTP_CODE) if str.code != '200'

    res, msg = success_response?(str)
    (log_error("Unsuccessful response code #{msg}"); exit ExitCode::MTP_UNSUCCESSFUL_RESPONSE_CODE) if res == false

    case @os
    when "MAC"
      info = search_string(str.body, "Device Version:")
      if !info.empty?()
        return parse_device_version(info)
      else
        log_error("Unable to get device version and info")
        exit ExitCode::MTP_NO_BUILD_INFO
      end
    when "WIN"

    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
  end

  def analyze_storage_info(str)
    failure_arr = []
    res = success_response?(str)
    return failure_arr << "Error response code #{res[1]}" if res[0] == false

    case @os
    when "MAC"
      expected_hash = mac_expected_storage_info

      expected_hash.each { |k, v|
        line = search_string(str.body, k)
        splitted = split_string(line, ':')

        failure_arr << "Incorrect storage info. Expected: #{k} = #{v}. Actual: #{splitted[0]} = #{splitted[1]}" if splitted[1].nil? or v != splitted[1]
      }
      line = search_string(str.body, 'max capacity')
      splitted = split_string(line, ':')
      failure_arr << "Max capacity field is empty" if splitted[1].nil? or splitted[1].empty?

      line = search_string(str.body, 'free space')
      splitted = split_string(line, ':')
      failure_arr << "Free space field is empty" if splitted[1].nil? or splitted[1].empty?

    when "WIN"

    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    failure_arr
  end

  def analyze_num_objects(str)
    failure_arr = []
    res = success_response?(str)
    return failure_arr << "Error response code #{res[1]}" if res[0] == false

    line = search_string(str.body, "Number of objects")
    splitted = split_string(line, ':')
    failure_arr << "Unable to find number of objects" if splitted[1].nil? or splitted[1].empty?
    failure_arr
  end

  #verify response code is a successful one
  def analyze_object_handles(str)
    failure_arr = []
    res = success_response?(str)
    failure_arr << "Error response code #{res[1]}" if res[0] == false
    failure_arr
  end
  
  #return list of object handles. Doesn't verify response code
  def win_get_object_handles
    
  end

  def parse_getccl_resp(str)
    val_line = search_string(str.body, "0:")

    splitted = val_line.split(':')

    res, msg = success_response?(str)

    ret = {
      :success => res,
      :responseCode => msg,
      :value => toGetString(splitted[1])
    }
    ret
  end

  def toSendHexString(v)
    newv = v[/\d\w/]
    return "0x#{newv}"
  end

  def toGetString(v)
    v[/\d\w/]
  end

  def mac_expected_storage_info
    {
      'storage Type' => "0004 - Removable RAM",
      'file system type' => "0003 - DCF (DCIM Camera File)",
      #max capability and free space will be verify separately, that field isn't empty,
      'access capability' => "0002 - Read-only with object deletion",
      'free objects' => "ffffffff",
      'description' => "External Memory",
      'volume ID' => "MTP Device"
    }
  end

  def win_expected_storage_info
    {
      'Storage type' => "4",
      'File system type' => "3",
      #max capability and free space will be verify separately, that field isn't empty,
      'Access capability' => "2",
      'Free space in objects' => "4294967295",
      'Storage description' => "External Memory",
      'Volume identifier' => "MTP Device"
    }
  end
end
