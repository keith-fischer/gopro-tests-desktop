# installHandler

# 1) Connects to camera
# 2) Downloads appropriate file if not already local
# 3) OTA updates the camera
# 4) Waits for the update to complete and camera to come back

require 'digest'
require 'net/http'
require 'net/http/post/multipart'
require 'open-uri'
require 'uri'
require 'fileutils'

require_relative 'camera'
require_relative 'host_utils'
require_relative 'log_utils'
require_relative 'exitcodes'

class InstallHandler
  attr_reader :fw_cam, :fw_ver, :fw_rel
  include LogUtils
  # 'remote_ota_file' can either be a full URL or just the ota file
  # (e.g. HD3.10.1.16.ota.zip)
  # 'local_ota_file' should be a full path if specified
  def initialize(cam_obj, remote_ota_file, local_ota_file="")
    if remote_ota_file == nil
      log_error("Please specify build to install")
      exit 1
    else
      log_verb("Initializing installHandler with #{remote_ota_file}")
    end
    @cam  = cam_obj
    @host = Host.new()
    @fw_rel, @fw_cam, @fw_ver  = parse_ota_fw_fname(remote_ota_file)
    exit 1 if check_fw_matches_camera == false
    if @cam.interfaces.include?(:wifi)
      @ota_url  = make_fw_url(remote_ota_file)
    else
      @ota_url = remote_ota_file
    end
    @local_ota_file   = local_ota_file
  end

  # Returns camera type / fw ver from filename (Example: HD3.10.1.16.ota.zip)
  def parse_ota_fw_fname(f)
    case @cam.release
    when "HD4", "HD5"
      #HD4.02.01.02.00 - field[0] = HD4, field[1] = 02, field[2..4] = '01.02.00'
      fields = File.basename(f).split(".")
      return fields[0], fields[1], fields[2..4].join(".")
    else
      #HX1.01.00.24 - field[0] = HX1, field[1] = 01, field[2..3] = '00.24'
      fields = File.basename(f).split(".")
      return fields[0], fields[1], fields[2..3].join(".")
    end
  end

  def check_fw_matches_camera()
    case @fw_rel
    when "HD4", "HD5"
      if @fw_cam != "XX" and @cam.type.to_i != @fw_cam.to_i
        log_error("Camera type (%s) does not match firmware type (%s)" \
          %[ @cam.type, @fw_cam])
        return false
      end
    else
      if @cam.type.to_i != @fw_cam.to_i
        log_error("Camera type (%s) does not match firmware type (%s)" \
          %[@cam.type, @fw_cam])
        return false
      end
    end
    return true
  end

  def make_fw_url(f)
    return f if f[0..3] == "http"
    url_base = "http://goprofwbuild1.gopro.lcl/builds"
    case f[0..5]
    when "HD5.XX"
      c = "Australia/Release" if @cam.type.to_i==2
      c = "Margaret_River" if @cam.type.to_i==3
    when "HD3.10"
      c = "Uluwatu"
    when "HD3.11"
      c = "Bawa"
    when "HD4.XX"
      fw_ver = f[7..14]
      if fw_ver < "03.01.00" or fw_ver >= "03.05.00"
        c = "Banzai/Release"
      else
        c = "Hawaii-Phase4/Release"
      end
    when "HD3.21"
      c = "Haleiwa"
    when "HD3.22"
      c = "Himalayas"
    when "HX1.01"
      c = "RockyPoint"
    end
    return "%s/%s/%s" %[url_base, c, f]
  end

  def calculate_sha1_digest_of(filename)
    buffer = ''
    sha1 = Digest::SHA1.new
    File.open(filename) do |f|
      while not f.eof do
        f.read(4096, buffer)
        sha1.update(buffer)
      end
    end
    return sha1.to_s
  end

  # depends on https://github.com/nicksieger/multipart-post
  # gem install multipart-post
  def upload_firmware(fw_fname, cancel_upload=false)
    fw_sha = calculate_sha1_digest_of(fw_fname)
    uri = URI.parse(@cam.make_ota_update_url())
    log_info("Uploading #{fw_fname} (sha1=#{fw_sha}) to #{uri}")
    post = Net::HTTP::Post::Multipart.new uri.path,
    "DirectToSD" => '1',
    "sha1" => fw_sha,
    "update" => "submit",
    "file" => UploadIO.new(File.new(fw_fname), "application/zip", "firmware.gpu")
    thr = nil
    begin
      response = Net::HTTP.start(uri.host, uri.port, :read_timeout => 300) do |http|
        # Start a thread that will stop the upload in 10 seconds if we're doing a cancel.
        if cancel_upload
          # Installer cancels the upload by telling camera to cancel its download.
          log_info("Cancel firmware update message will be sent in 10 seconds...")
          thr = Thread.new {
            sleep(10.0)
            @cam.send_fwdownload_cancel()
            log_info("Cancel firmware update message sent.")
            http.finish # This ends the post (by causing an error?)
          }
        end
        # Do the upload.
        http.request(post)
      end
    rescue StandardError
      # RP and HAL sometimes reboot before sending HTTP_OK.
      # If they disappear, then they are updating
      # TODO - Remove when HLWA-647 and RKPT-1112 is fixed
      if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@cam.name)
        5.times {
          sleep 2.0
          if @host.curlable?(@cam.ip) == false
            log_warn("Camera cut off the HTTP response, but still initiated restart")
            return Net::HTTPResponse.new(1.0, "200", "OK")
          end
        }
      end
      log_error("HTTP POST failed.") unless cancel_upload
      thr.join if cancel_upload
      return nil
    end

    return response
  end

  def do_ota_update(do_sleep, cancel_upload=false)
    log_info("Downloading file #{@ota_url} if not already local")
    fw_fname = @host.wget(@ota_url, @local_ota_file)
    if fw_fname == false
      log_error("FW file download unsuccessful")
      exit ExitCode::DOWNLOAD_FAILED
    end
    if @cam.interfaces.include?(:wifi)
      return do_wifi_fw_update(fw_fname, do_sleep, cancel_upload)
    else
      log_warn("Ignoring option to cancel upload on serial this camera.") if cancel_upload
      return do_serial_fw_update(fw_fname)
    end
  end

  def do_wifi_fw_update(fw_fname, do_sleep, cancel_upload=false)
    if File.size(fw_fname) == 0
      log_error("Build #{fw_fname} filesize is 0")
      exit ExitCode::DOWNLOAD_FAILED
    elsif File.size(fw_fname) < 1000000
      log_error("Build #{fw_fname} filesize is too small to be real.")
      exit ExitCode::DOWNLOAD_FAILED
    end

    log_info("Entering OTA Update Mode...")
    r = nil
    retry_times = cancel_upload ? 1 : 2
    retry_times.times { |n|
      @cam.set(:ota_mode, "ON") if @cam.remote_api_version == 1
      @cam.send_fwupdate_start if @cam.remote_api_version == 2
      r = upload_firmware(fw_fname, cancel_upload)
      break if r != nil or n == retry_times - 1
      sleep 5.0
      log_info("Retrying OTA Upload...")
    }
    # Rework logic depending on what cancelling it actually returns.
    if cancel_upload
      log_info("Uploading OTA file cancelled, as requested.")
      return true
    end
    if r == nil
      log_error("Uploading OTA file failed")
      exit ExitCode::OTA_FAILED
    end

    begin
      log_verb("HTTP status code=#{r.code}, body=#{r.body}")
    rescue StandardError
      log_verb("HTTP status code=#{r.code}, no body")
    end
    log_info("#{Time.now} Starting OTA Update...")

    if @cam.remote_api_version == 1
      @cam.set(:start_ota_update, "ON", wait_time=1.0, decode=false)
      t_sleep = 45
    elsif @cam.release == "HX1" # Only wait for 15 seconds for RP
      t_sleep = 15
    elsif @cam.release == "HD3" # Himalayas, Haleiwa
      t_sleep = 20
    elsif @cam.release == "HD5"
      t_sleep = 100
    else
      # All other api==2 cameras wait 45 seconds
      t_sleep = 45
    end
    log_info("Sleeping for #{t_sleep} seconds before polling for camera...")
    sleep t_sleep

    ###TBD XXX TODO remove Australia Workaround.  Reset camera and Wi-Fi.
    #if @cam.release == "HD5"
    #  log_info("#"*80)
    #  log_info("Australia OTA workaround.  Resetting camera and Wi-Fi")
    #  log_info("#"*80)
    #  log_info("First sleeping for 120 more seconds")
    #  sleep 120
    #  return australia_reset()
    #end

    if do_sleep == true
      if @host.is_raspberry_pi?()
        camera_rdy = false
        10.times do
          camera_rdy = @host.wait_for_wifi_camera(@cam.ip, timeout=15)
          @host.bounce_wifi() if not camera_rdy
        end
        return camera_rdy
      else
        return @host.wait_for_wifi_camera(@cam.ip, timeout=250)
      end
    else
      #autoconnect is true
      return true
    end
  end

  def australia_reset()
    require_relative 'test_utils'
    require_relative 'dlipower'
    powerstrip = PowerStrip.new("192.168.0.100","admin","1234")
    (puts "Powerstrip is nil!"; return false) if powerstrip == nil
    outlet = @cam.battoutlet
    result = false
    3.times { |t|
      2.times { |n|
        log_info("Try #{n+1} of 3 waiting for Wi-Fi")
        @host.send_serial("t api system reset force", @cam.serial_iface)
        sleep(30)
        2.times {
          @host.send_serial("t api wireless mode app", @cam.serial_iface)
          sleep 1
        }
        if @host.is_raspberry_pi?()
          camera_rdy = false
          2.times do
            @host.bounce_wifi() if not camera_rdy
            camera_rdy = @host.wait_for_wifi_camera(@cam.ip, timeout=25)
          end
          result = camera_rdy
          break if result == true
        else
          result = @host.wait_for_wifi_camera(@cam.ip, timeout=250)
          break if result == true
        end
      }
      break if result == true
      powerstrip.turn_off(outlet) if outlet != nil
      sleep 3.0
      powerstrip.turn_on(outlet) if outlet != nil
      sleep 20
    }
    return result
  end

  def do_serial_ota_fw_update()
    #@host.acquire_lock(@host.WIFI_LOCK)
    cam_ip = "10.5.5.9"
    wifi_cam = nil
    if @host.pingable?(cam_ip) or @host.curlable?(cam_ip)
      # Match MAC addresses
      wifi_cam = get_wifi_camera(cam_ip)
      wifi_cam_mac = wifi_cam.mac.tr(":", "")
      if @cam.wifi_mac == wifi_cam_mac
        log_info("Camera found (serial=#{@cam.wifi_mac}, wifi=#{wifi_cam_mac})")
      else
        log_info("Camera does not match (serial=#{@cam.wifi_mac}, wifi=#{wifi_cam_mac})")
        wifi_cam = nil
      end
    end

    if wifi_cam == nil
      ssid, pc = @cam.enable_app_mode()
      if ssid == false
        log_error("Unable to enable APP mode on camera")
        return false
      else
        sleep(15)
        retries = 5
        (1..retries).each { |n|
          ret = @host.connect_camera(ssid, cam_ip, pc)
          if ret == false
            log_warn("Retrying host association with AP")
            sleep 5
            next
          end
          if @host.wait_for_wifi_camera(cam_ip, timeout=30) == true
            break
          else
            if n < retries
              log_info("Retrying Wi-Fi connection (#{n+1} of #{retries})")
              next
            else
              log_error("Unable to connect to camera Wi-Fi")
              return false
            end
          end
        }
      end
    end # end wifi_cam == nil
    wifi_cam = get_wifi_camera(cam_ip)
    ih = InstallHandler.new(wifi_cam, @ota_url)
    return ih.do_ota_update(true)
  end # end do_serial_ota_update

  # Perform a firmware update over serial connection
  # fw_bin - The camera_firmware.bin file
  # update_txt - The update.txt file.  Will be generated if not specified
  # settings_in - The settings_in file.
  # The firmware update requires a fake battery inserted and powered because
  # the camera checks battery levels before doing a FW update
  def do_serial_fw_update(update_txt=nil, settings_in=nil)
    curr_cam_build_rev = @cam.get_build_id
    log_info("Current build revision = #{curr_cam_build_rev}")
    if @battoutlet == nil
      return false, "Unable to perform FW update without fake battery"
    end
    build_page = @ota_url.split("artifact")[0]
    build_rev = @host.get_build_revision(build_page)

    log_info("New build revision = #{build_rev}")
    local_fw_name= "#{File.basename(@ota_url, ".bin")}-#{build_rev[0..7]}.bin"
    local_fw_bin = @host.wget(@ota_url, File.join("/tmp", local_fw_name))

    if local_fw_bin == nil or local_fw_bin == false
      log_warn("Unable to find camera firmware file '#{local_fw_bin}'")
      return false, "FW Update unsuccessful"
    end
    if update_txt != nil and not File.exists?(update_txt)
      log_warn("Unable to find update file '#{update_txt}'")
      return false, "FW Update unsuccessful"
    else
      update_txt = File.join("/tmp", "hd4_update.txt")
      File.open(update_txt, "w") { |f|
        f.puts("OPTIONS:10\r\nCAMERA:1\r\nHIBER:1\r\n\r\n")
      }
    end
    if settings_in != nil and not File.exists?(settings_in)
      log_warn("Unable to find settings file #{settings_in}")
      return false, "FW Update unsuccessful"
    end

    mount_point = @cam.is_mounted?
    mount_point = @cam.enter_mass_storage_mode() if mount_point == false
    update_dir = File.join(mount_point, "update")
    fw_bin_on_camera = File.join(update_dir, "camera_firmware.bin")
    File.delete(fw_bin_on_camera) if File.exists?(fw_bin_on_camera)

    FileUtils.mkdir(update_dir) if not File.directory?(update_dir)
    @host.copy_file(local_fw_bin, fw_bin_on_camera)
    @host.copy_file(update_txt, update_dir) if update_txt != nil
    @host.copy_file(settings_in, update_dir) if settings_in != nil
    sleep(3.0)

    # Check that copy was successful
    if @host.cksum_equal?(fw_bin_on_camera, local_fw_bin) == false
      return false, "Firmware file copy error.  Update unsuccessful"
    end
    log_verb("Done copying file.  Exiting mass-storage-mode")
    @host.sys_exec("umount #{mount_point}")
    sleep(2.0)
    @cam.exit_mass_storage_mode()
    sleep(5.0)

    log_verb("Turning on fake battery")
    @powerstrip.turn_on(@cam.battoutlet)
    sleep(5.0)

    log_verb("Starting FW update process")
    @cam.send_serial("t appc fwupdate ready")
    sleep 5
    if @cam.expect("*** UPDATE COMPLETE ***", timeout=45) == nil
      ret, msg = false, "Did not see update complete message"
    else
      curr_cam_build_rev = @cam.get_build_id
      if curr_cam_build_rev != nil and curr_cam_build_rev == build_rev[0...7]
        ret, msg = true, "Firmware update successful"
      else
        ret, msg = false, "Build mismatch. Cam=#{curr_cam_build_rev}, FW=#{build_rev}"
      end
    end
    log_verb("Turning off fake battery")
    @powerstrip.turn_off(@cam.battoutlet)
    return ret, msg
  end # end do_serial_fw_update()
end # end InstallHandler

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  #c = get_wifi_camera("10.5.5.9")
  c = get_serial_camera("/dev/ttyUSB0")
  #  ih = InstallHandler.new(c, "http://goprofwbuild1.gopro.lcl:8080/job/Banzai-Release/lastSuccessfulBuild/artifact/BANZAI/build/camera_firmware.bin")
  ih = InstallHandler.new(c, "HD4.XX.00.24.00.ota.zip")
  #  puts "Camera model of FW file: #{ih.fw_cam}"
  #  puts "Firmware version of FW file: #{ih.fw_ver}"
  #  ih.do_ota_update()
  p ih.do_serial_ota_fw_update()
end
