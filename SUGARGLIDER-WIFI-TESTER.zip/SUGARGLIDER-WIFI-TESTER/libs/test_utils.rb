# TestUtils module
# Commonly used high-level functions to simplify test creation
# These will throw warnings, errors, failures, and exceptions
# so to help keep track, all functions are prepended by "tu_"

require_relative 'log_utils'

require 'fileutils'

module TestUtils
  include LogUtils
  def tu_get_video_res_with_protune(cameraO=nil, optionsA=nil, quiet=false)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    ntsc_params = []   #ntsc non protune & protune
    pal_params = []    #pal non protune & protune

    ["NTSC", "PAL"].each do |video_mode|
      next if video_mode == "NTSC" and options[:pal_only]
      next if video_mode == "PAL"  and options[:ntsc_only]
      camera.get_video_resolution().each do |res|
        next if options[:video_resolution] != nil and not options[:video_resolution].split(",").include?(res)
        camera.get_video_fps(res).each do |fps|
          next if options[:video_fps] != nil and options[:video_fps].to_i != fps.to_i
          next if !camera.mode_supported?(video_mode, res, fps)
          camera.get_video_fov(res, fps).each do |fov|
            next if options[:video_fov] != nil and options[:video_fov] != fov
            ["UP", "DOWN"].each do |orient|
              next if use_option(options, :setup_orientation, orient) == false
              #              next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
              ["OFF", "ON"].each() do |spot|
                if !camera.video_spot_metering_support?
                  spot = nil if spot == "OFF"
                  next if spot == "ON" # Avoid duplicate tests
                else
                  next if use_option(options, :video_spot_metering, spot) == false
                end
                ["OFF", "ON"].each() do |ll|
                  next if use_option(options, :video_low_light, ll) == false
                  ll = nil if !camera.video_low_light_support?(res, fps)

                  # ProTune OFF case
                  pt = "OFF"
                  if options[:video_pt] != "ON"
                    entry = [video_mode, res, fps, fov, orient, ll, spot, pt, nil, nil, nil, nil, nil]
                    if video_mode == "NTSC"
                      ntsc_params << entry
                    else
                      pal_params << entry
                    end
                    log_verb("Adding [%s, %s, %s, %s, orient=%s, ll=%s, spot=%s, pt=%s]" %entry[0..7]) if !quiet
                  end

                  if camera.video_protune_support?(res, fps)
                    if options[:video_pt] == "ON" || options[:video_pt] == nil
                      pt = "ON"
                      # Some cameras (RKPT) don't support all FOV with ProTune
                      next if !camera.get_video_fov(res, fps, pt).include?(fov)
                      camera.get_protune_white_balance.each{ |wb|
                        next if use_option(options, :video_pt_wb, wb) == false
                        camera.get_protune_color.each { |co|
                          next if use_option(options, :video_pt_color, co) == false
                          camera.get_protune_sharpness.each { |sh|
                            next if use_option(options, :video_pt_sharp, sh) == false
                            camera.get_video_protune_iso.each { |iso|
                              next if use_option(options, :video_pt_iso, iso) == false
                              camera.get_protune_exposure.each {|ex|
                                next if use_option(options, :video_pt_ev, ex) == false
                                entry = [video_mode, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex]
                                if video_mode == "NTSC"
                                  ntsc_params << entry
                                else
                                  pal_params << entry
                                end
                                s = "Adding [%s, %s, %s, %s, orient= %s, ll=%s, spot=%s, pt=%s, %s, %s, %s, %s, %s]" \
                                %entry
                                log_verb(s) if !quiet
                              }#exposure
                            }#iso
                          }#sharpness
                        } #color
                      }#white balance
                    end #protune ON?
                  end #protune support?
                  break if ll == nil
                end # ll
              end #spot
            end # orientation
          end # fov
        end # fps
      end # res
    end # video_mode (ntsc/pal)

    ntsc_params.shuffle! if options[:shuffle]
    pal_params.shuffle! if options[:shuffle]

    ret = []
    ret << ntsc_params
    ret << pal_params
    return ret
  end

  def tu_get_looping_res(cameraO=nil, optionsA=nil, quiet=false)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options

    # From above: [video_mode, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex]
    tp = tu_get_video_res_with_protune(camera, options, true).flatten(1)

    # Remove any settings for which looping is not supported.
    tp.reject! { |n|
      res, fps, fov = n[1..3]
      camera.video_looping_support?(res, fps, fov) == false
    }
    # Remove any settings that have protune on.
    tp.reject! { |n| pt = n[7]; pt == "ON" }

    # Make final array
    test_params = []
    tp.each { |vm, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex|
      camera.get_video_looping_intervals().each { |loo|
        next if options[:video_looping] != nil and not options[:video_looping].split(",").include?(loo.to_s)
        entry = [vm, res, fps, fov, loo, orient, ll, spot]
        test_params << entry
        log_verb("Adding looping [%s, %s, %s, %s, loop=%s, orient=%s, ll=%s, spot=%s]" %entry) if !quiet
      }
    }
    return test_params
  end

  def tu_get_piv_res(cameraO=nil, optionsA=nil, quiet=false)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options

    # From above: [video_mode, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex]
    tp = tu_get_video_res_with_protune(camera, options, true).flatten(1)

    # Make final array
    test_params = []
    tp.each { |vm, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex|
      next if pt == "ON"  #PIV isn't supported in protune mode
      next if !camera.video_piv_support?(res, fps, fov)
      camera.get_video_piv_intervals().each { |piv|
        next if options[:video_piv] != nil and options[:video_piv].to_s != piv.to_s
        entry = [vm, res, fps, fov, piv, orient, ll, spot]
        test_params << entry
        log_verb("Adding piv [%s, %s, %s, %s, piv=%s, orientation=%s, ll=%s, spot=%s]" %entry) if !quiet
      }
    }

    return test_params
  end

  def tu_get_video_timelapse_res(cameraO=nil, optionsA=nil, quiet=false)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    ["NTSC", "PAL"].each { |vm|
      next if vm == "NTSC" and options[:pal_only]
      next if vm == "PAL"  and options[:ntsc_only]
      camera.get_video_timelapse_resolution.each {|res|
        next if options[:video_resolution] != nil and options[:video_resolution] != res
        camera.get_video_timelapse_fov(res).each { |fov|
          next if options[:video_fov] != nil and options[:video_fov] != fov
          camera.get_video_timelapse_intervals().each { |pes|
            next if options[:video_timelapse] != nil and options[:video_timelapse].to_f != pes.to_f
            ["UP", "DOWN"].each { |orient|
              next if use_option(options, :setup_orientation, orient) == false
              #              next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
              entry = [vm, res, fov, pes, orient]
              test_params << entry
              log_verb("Adding video-timelapse [%s, %s, %s, %s, %s]" %entry) if !quiet
            }
          }
        }
      }
    }
    return test_params
  end

  def tu_basename(f)
    if f.split("\\").length > 1
      file = f.split("\\")[-1]
    else
      file = File.basename(f)
    end
    return file
  end

  # Analyzes filename conformance to specification
  # Possible 'type' values include
  # VIDEO - single video / first video in chapter / video file for PIV
  #         time-lapse-as-video
  # CHAPTERED_VIDEO - Subsequent video files after file-size limit reached
  # LOOPING_VIDEO - Looping enabled videos
  # PHOTO - single photo/night photo
  # BURST - Images captured in burst
  # TIME_LAPSE - For images captured during time-lapse
  # NIGHT_LAPSE - For images captured during night-lapse
  # SPS - For images captured during continuous shot
  # PIV - For the images captured during picture-in-video
  def tu_analyze_file_name(type, file)
    log_info("Checking file name convention for #{type} (#{file})")
    failed_arr = []
    case type
    when "VIDEO"
      mp4_re = /GOPR[0-9]{4}.MP4/
      if file.match(mp4_re) == nil
        failed_arr << "Video file (#{file}) does not conform to GOPRXXXX.MP4"
      end
    when "CHAPTERED_VIDEO"
      mp4_re = /GP[0-9]{6}.MP4/
      if file.match(mp4_re) == nil
        failed_arr << "Video file (#{file}) does not conform to GPYYXXXX.MP4"
      end
    when "LOOPING_VIDEO"
      mp4_re = /G[0-9]{7}.MP4/
      if file.match(mp4_re) == nil
        failed_arr << "Video file (#{file}) does not conform to GYYYXXXX.MP4"
      end
    when "PHOTO", "PHOTO_NIGHT"
      jpg_re = /GOPR[0-9]{4}.JPG/
      if file.match(jpg_re) == nil
        failed_arr << "IMAGE file (#{file}) does not conform to GOPRXXXX.JPG"
      end
    when "BURST", "TIMELAPSE", "NIGHTLAPSE", "SPS", "PIV"
      jpg_re = /G[0-9]{7}.JPG/
      if file.match(jpg_re) == nil
        failed_arr << "IMAGE file (#{file}) does not conform to GYYYXXXX.JPG"
      end
    else
      failed_arr << "Unknown capture mode when analyzing filename"
    end
    failed_arr
  end

  def tu_wifi_analyze_video_metadata(file, p, res, fps, fov)
    log_info("Checking MP4 metadata")

    mp4file = @camera.get_media_url(file)
    lrvfile = thmfile = nil

    lrvfile = mp4file[0..-4] + "LRV" if @camera.has_lrv?(res, fps, fov, p)
    thmfile = mp4file[0..-4] + "THM" if @camera.has_thm?(res, fps, p)

    # Metadata should match expectations
    # Failure messages will be added to the failed array
    failed_arr = []

    # Compare the MP4 file
    exp = VideoMetadata.new()
    exp.aspect_ratio       = @camera.video_capture_modes[res][:aspect_ratio]
    exp.audio_channels     = @camera.audio_channels
    exp.audio_codec        = @camera.audio_codec
    exp.audio_sample_rate  = @camera.audio_sample_rate
    exp.audio_bitrate      = @camera.get_audio_bitrate.round(2)
    # The video bitrate is the total bitrate minus the audio bitrate (adjusted for different units).
    exp.video_bitrate      = (@camera.get_bitrate(res, fps, p, fov) - (exp.audio_bitrate/1000.0)).round(2)
    exp.colorspace         = @camera.colorspace
    exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:frame_rate]
    exp.has_timecode       = @camera.mp4_has_timecode?(res,fps)
    exp.height             = @camera.video_capture_modes[res][:height]
    exp.video_codec        = @camera.video_codec
    exp.width              = @camera.video_capture_modes[res][:width]
    exp.profile_level      = @camera.get_profile_level(res, fps, p)

    act = @host.get_video_metadata(mp4file)
    if act == nil
      failed_arr << "Unable to open MP4 video file"
    elsif act.has_values? # If it has meaningful values, verify them.
      log_info("Checking MP4 file metadata")
      #      failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio,
      #      "aspect_ratio (exp=#{exp.aspect_ratio} != act=#{act.aspect_ratio})")
      failed_arr << assert_equal(exp.audio_channels, act.audio_channels,
                                 "audio_channels (exp=#{exp.audio_channels} != act=#{act.audio_channels})")
      failed_arr << assert_equal(exp.audio_codec, act.audio_codec,
                                 "audio_codec (exp=#{exp.audio_codec} != act=#{act.audio_codec})")
      failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate,
                                 "audio_sample_rate (exp=#{exp.audio_sample_rate} != act=#{act.audio_sample_rate})")
      failed_arr << assert_delta(exp.audio_bitrate, act.audio_bitrate, exp.audio_bitrate*0.15,
                                 "audio bitrate (exp=%0.2f not within %s of act=%0.2f)" \
                                 %[exp.audio_bitrate, "15%", act.audio_bitrate])
      failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
                                 "video bitrate (exp=%0.2f not within %s of act=%0.2f)" \
                                 %[exp.video_bitrate, "15%", act.video_bitrate])
      failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                 "colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                 "frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
      failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
                                 "has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
      #verify timecode accuracy - Not testing due to intermittent time drift in firmware
      #      if exp.has_timecode == true
      #        failed_arr << assert_equal(true, tu_valid_timecode?("MP4", fps, act.creation_time, act.timecode),
      #        "timecode time accuracy is off")
      #      end
      failed_arr << assert_equal(exp.width, act.width,
                                 "width (exp=#{exp.width} != act=#{act.width})")
      failed_arr << assert_equal(exp.height, act.height,
                                 "height (exp=#{exp.height} != act=#{act.height})")
      failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                 "video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
      failed_arr << assert_equal(exp.profile_level, act.profile_level,
                                 "AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")

      #Metadata info output only
      log_info("MP4 Metadata Info")
      #      log_info("MP4 aspect ratio - expected: #{exp.aspect_ratio}, actual: #{act.aspect_ratio}")
      log_info("MP4 audio channels - expected: #{exp.audio_channels}, actual #{act.audio_channels}")
      log_info("MP4 audio codec - expected: #{exp.audio_codec}, actual #{act.audio_codec}")
      log_info("MP4 audio sample rate - expected: #{exp.audio_sample_rate}, actual #{act.audio_sample_rate}")
      log_info("MP4 audio bitrate - expected: #{exp.audio_bitrate}, actual #{act.audio_bitrate}")
      log_info("MP4 video bitrate - expected: #{exp.video_bitrate}, actual #{act.video_bitrate}")
      log_info("MP4 colorspace - expected: #{exp.colorspace}, actual #{act.colorspace}")
      log_info("MP4 frame rate - expected: #{exp.frame_rate}, actual #{act.frame_rate}")
      log_info("MP4 has_timecode? - expected: #{exp.has_timecode}, actual #{act.has_timecode}")
      log_info("MP4 width - expected: #{exp.width}, actual #{act.width}")
      log_info("MP4 height - expected: #{exp.height}, actual #{act.height}")
      log_info("MP4 video codec- expected: #{exp.video_codec}, actual #{act.video_codec}")
      log_info("MP4 avc profile level - expected: #{exp.profile_level}, actual #{act.profile_level}")
    else
      failed_arr << "Metadata for MP4 file had no useful fields that weren't nil."
    end

    sleep 1

    # Compare the LRV file (if applicable)
    if lrvfile != nil
      exp = VideoMetadata.new()
      exp.aspect_ratio       = @camera.video_capture_modes[res][:lrv_aspect_ratio]
      exp.audio_channels     = @camera.audio_channels
      exp.audio_codec        = @camera.audio_codec
      exp.audio_sample_rate  = @camera.audio_sample_rate
      exp.audio_bitrate      = @camera.get_audio_bitrate.round(2)
      # The video bitrate is the total bitrate minus the audio bitrate (adjusted for different units).
      exp.video_bitrate      = (@camera.get_lrv_bitrate(res, fps) - (exp.audio_bitrate/1000.0)).round(2)
      exp.colorspace         = @camera.colorspace
      exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:lrv_fps]
      exp.has_timecode       = @camera.lrv_has_timecode?(res, fps)
      exp.height             = @camera.get_lrv_height(res, fps)
      exp.video_codec        = @camera.video_codec
      exp.width              = @camera.get_lrv_width(res, fps)
      exp.profile_level      = @camera.get_lrv_profile_level(res, fps)

      act = @host.get_video_metadata(lrvfile)
      if act == nil
        failed_arr << "Unable to open LRV video file"
      elsif act.has_values?
        log_info("Checking LRV file metadata")
        # Not testing aspect ratio because the actual value is just the ratio width:height reduced.
        # Basically, so long as the width and height are correct, we don't need to check this too.
        # We could remove this check for MP4s too, but their w:h ratio is exact, and won't cause false negatives.
        #failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio,
        #"lrv aspect_ratio (exp=#{exp.aspect_ratio} != act=#{act.aspect_ratio})")
        failed_arr << assert_equal(exp.audio_channels, act.audio_channels,
                                   "lrv_audio_channels (exp=#{exp.audio_channels} != act=#{act.audio_channels})")
        failed_arr << assert_equal(exp.audio_codec, act.audio_codec,
                                   "lrv_audio_codec (exp=#{exp.audio_codec} != act=#{act.audio_codec})")
        failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate,
                                   "lrv_audio_sample_rate (exp=#{exp.audio_sample_rate} != act=#{act.audio_sample_rate})")
        failed_arr << assert_delta(exp.audio_bitrate, act.audio_bitrate, exp.audio_bitrate*0.15,
                                   "audio bitrate (exp=%0.2f not within %s of act=%0.2f)" \
                                   %[exp.audio_bitrate, "15%", act.audio_bitrate])
        failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
                                   "lrv video bitrate (exp=%0.2f not within %s of act=%0.2f)" \
                                   %[exp.video_bitrate, "15%", act.video_bitrate])
        failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                   "lrv colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
        failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                   "lrv frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
        failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
                                   "lrv has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
        #verify timecode accuracy - Not testing due to intermittent time drift in firmware
        #        if exp.has_timecode == true
        #          failed_arr << assert_equal(true, tu_valid_timecode?("LRV", fps, act.creation_time, act.timecode),
        #          "lrv timecode time accuracy is off")
        #        end
        failed_arr << assert_equal(exp.width, act.width,
                                   "lrv_width (exp=#{exp.width} != act=#{act.width})")
        failed_arr << assert_equal(exp.height, act.height,
                                   "lrv_height (exp=#{exp.height} != act=#{act.height})")
        failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                   "lrv_video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
        failed_arr << assert_equal(exp.profile_level, act.profile_level,
                                   "LRV AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")

        #Metadata info output only
        log_info("LRV Metadata Info")
        #log_info("LRV aspect ratio - expected: #{exp.aspect_ratio}, actual: #{act.aspect_ratio}")
        log_info("LRV audio channels - expected: #{exp.audio_channels}, actual #{act.audio_channels}")
        log_info("LRV audio codec - expected: #{exp.audio_codec}, actual #{act.audio_codec}")
        log_info("LRV audio sample rate - expected: #{exp.audio_sample_rate}, actual #{act.audio_sample_rate}")
        log_info("LRV audio bitrate - expected: #{exp.audio_bitrate}, actual #{act.audio_bitrate}")
        log_info("LRV video bitrate - expected: #{exp.video_bitrate}, actual #{act.video_bitrate}")
        log_info("LRV colorspace - expected: #{exp.colorspace}, actual #{act.colorspace}")
        log_info("LRV frame rate - expected: #{exp.frame_rate}, actual #{act.frame_rate}")
        log_info("LRV has_timecode? - expected: #{exp.has_timecode}, actual #{act.has_timecode}")
        log_info("LRV width - expected: #{exp.width}, actual #{act.width}")
        log_info("LRV height - expected: #{exp.height}, actual #{act.height}")
        log_info("LRV video codec- expected: #{exp.video_codec}, actual #{act.video_codec}")
        log_info("LRV avc profile level - expected: #{exp.profile_level}, actual #{act.profile_level}")
      else
        failed_arr << "Metadata for LRV file had no useful fields that weren't nil."
      end
    end # end lrvfile != nil
    return failed_arr
  end

  def tu_wifi_analyze_video_timelapse_metadata(file, vm, res)
    log_info("Checking metadata")

    mp4file = @camera.get_media_url(file)
    lrvfile = mp4file[0..-4] + "LRV"
    thmfile = mp4file[0..-4] + "THM"

    # Metadata should match expectations
    # Failure messages will be added to the failed array
    failed_arr = []

    # Compare the MP4 file.
    # Since no audio in video timelapse, no audio metadata will exist.
    exp = VideoMetadata.new()
    exp.aspect_ratio       = @camera.video_timelapse_capture_modes[res][:aspect_ratio]
    exp.video_bitrate      = @camera.get_video_timelapse_bitrate(res)
    exp.colorspace         = @camera.colorspace
    exp.frame_rate         = vm == "NTSC" ? @camera.video_timelapse_capture_modes[res][:ntsc_fps] : @camera.video_timelapse_capture_modes[res][:pal_fps]
    exp.has_timecode       = @camera.video_timelapse_capture_modes[res][:timecode]
    exp.height             = @camera.video_timelapse_capture_modes[res][:height]
    exp.width              = @camera.video_timelapse_capture_modes[res][:width]
    exp.video_codec        = @camera.video_codec
    exp.profile_level      = @camera.get_profile_level_raw(exp.width, exp.height, exp.frame_rate, exp.video_bitrate)

    act = @host.get_video_metadata(mp4file)
    if act == nil
      failed_arr << "Unable to open MP4 video file"
    else
      log_info("Checking MP4 file metadata")
      #      failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio,
      #      "aspect_ratio (exp=#{exp.aspect_ratio} != act=#{act.aspect_ratio})")
      failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
                                 "video_bitrate (exp=#{exp.video_bitrate} not within 15% of act=#{act.video_bitrate})")
      failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                 "colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                 "frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
      failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
                                 "has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
      failed_arr << assert_equal(exp.width, act.width,
                                 "width (exp=#{exp.width} != act=#{act.width})")
      failed_arr << assert_equal(exp.height, act.height,
                                 "height (exp=#{exp.height} != act=#{act.height})")
      failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                 "video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
      failed_arr << assert_equal(exp.profile_level, act.profile_level,
                                 "AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")
    end

    # Compare the LRV file (if applicable)
    if lrvfile != nil
      exp = VideoMetadata.new()
      exp.aspect_ratio       = @camera.video_timelapse_capture_modes[res][:lrv_aspect_ratio]
      exp.video_bitrate      = @camera.get_video_timelapse_lrv_bitrate(res)
      exp.colorspace         = @camera.colorspace
      exp.frame_rate         = vm == "NTSC" ? @camera.video_timelapse_capture_modes[res][:lrv_ntsc_fps] : @camera.video_timelapse_capture_modes[res][:lrv_pal_fps]
      exp.has_timecode       = @camera.video_timelapse_capture_modes[res][:lrv_timecode]
      exp.height             = @camera.video_timelapse_capture_modes[res][:lrv_height]
      exp.width              = @camera.video_timelapse_capture_modes[res][:lrv_width]
      exp.video_codec        = @camera.video_codec
      exp.profile_level      = @camera.get_profile_level_raw(exp.width, exp.height, exp.frame_rate, exp.video_bitrate)

      act = @host.get_video_metadata(lrvfile)
      if act == nil
        failed_arr << "Unable to open LRV video file"
      else
        log_info("Checking LRV file metadata")
        failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
                                   "lrv_video_bitrate (exp=#{exp.video_bitrate} not within 15% of act=#{act.video_bitrate})")
        #        failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio,
        #        "aspect_ratio (exp=#{exp.aspect_ratio} != act=#{act.aspect_ratio})")
        failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                   "lrv colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
        failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                   "lrv frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
        failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
                                   "lrv has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
        failed_arr << assert_equal(exp.width, act.width,
                                   "lrv_width (exp=#{exp.width} != act=#{act.width})")
        failed_arr << assert_equal(exp.height, act.height,
                                   "lrv_height (exp=#{exp.height} != act=#{act.height})")
        failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                   "lrv_video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
        failed_arr << assert_equal(exp.profile_level, act.profile_level,
                                   "LRV AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")
      end
    end # end lrvfile != nil
    return failed_arr
  end

  #ts file during capture.
  def tu_analyze_mpeg_ts_captured_metadata(full_path, p, res, fps, fov)
    log_info("Checking mpeg ts (stream) metadata #{full_path}")
    failed_arr = []

    exp = VideoMetadata.new()
    exp.aspect_ratio       = @camera.video_capture_modes[res][:lrv_aspect_ratio]
    exp.audio_channels     = @camera.audio_channels
    exp.audio_codec        = @camera.audio_codec
    exp.audio_sample_rate  = @camera.audio_sample_rate
    #    exp.video_bitrate            = @camera.get_bitrate(res, fps, p, fov)   #video bitrate - commenting out for now since bit_rate sometimes not exposed
    #timecode doesn't exist in preview streaming (ts)
    exp.colorspace         = @camera.colorspace
    exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:lrv_fps]
    exp.height             = @camera.video_capture_modes[res][:lrv_height]
    exp.video_codec        = @camera.video_codec
    exp.width              = @camera.video_capture_modes[res][:lrv_width]
    # The expected width is actually *almost* this value. It's the next largest multiple of 16.
    # See comments on STK-1455 for the reasoning here, if you like.
    exp.width = ( exp.width / 16.0 ).ceil * 16

    # exp.profile_level = @camera.get_profile_level(res, fps, p) - commenting out for now
    # since bit_rate sometimes not exposed.

    act = @host.get_mpeg_ts_metadata(full_path)
    if act == nil
      failed_arr << "Unable to open mpeg ts video file #{full_path}"
    else
      failed_arr << assert_equal(exp.audio_channels, act.audio_channels,
                                 "#{full_path} streaming (ts) audio_channels (exp=#{exp.audio_channels} != act=#{act.audio_channels})")
      failed_arr << assert_equal(exp.audio_codec, act.audio_codec,
                                 "#{full_path} streaming (ts) audio_codec (exp=#{exp.audio_codec} != act=#{act.audio_codec})")
      failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate,
                                 "#{full_path} streaming (ts) audio_sample_rate (exp=#{exp.audio_sample_rate} != act=#{act.audio_sample_rate})")
      #      failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
      #      "streaming (ts) bitrate (exp=#{exp.video_bitrate} not within 15% of act=#{act.video_bitrate})")
      failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                 "#{full_path} streaming (ts) colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                 "#{full_path} streaming (ts) frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
      failed_arr << assert_equal(exp.width, act.width,
                                 "#{full_path} streaming (ts) width (exp=#{exp.width} != act=#{act.width})")
      failed_arr << assert_equal(exp.height, act.height,
                                 "#{full_path} streaming (ts) height (exp=#{exp.height} != act=#{act.height})")
      failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                 "#{full_path} streaming (ts) video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
      #      failed_arr << assert_equal(exp.profile_level, act.profile_level,
      #      "streaming (ts) AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")
    end
    failed_arr
  end

  #ts file during video mode idle (ie video single, video time lapse, video looping, photo in video)
  def tu_analyze_mpeg_ts_idled_metadata(full_path, vm, p, res, fps, fov)
    log_info("Checking mpeg ts (stream) metadata #{full_path}")
    failed_arr = []

    exp = VideoMetadata.new()
    exp.aspect_ratio       = @camera.video_capture_modes[res][:lrv_aspect_ratio]
    exp.audio_channels     = @camera.audio_channels
    exp.audio_codec        = @camera.audio_codec
    exp.audio_sample_rate  = @camera.audio_sample_rate
    #    exp.video_bitrate            = @camera.get_bitrate(res, fps, p, fov)   #video bitrate - commenting out for now since bit_rate sometimes not exposed
    exp.colorspace         = @camera.colorspace
    #During idling, preview stream is always available, even if lrv exists. Expected NTSC fps = 29.97, Expected PAL fps = 25
    exp.frame_rate = (vm == "NTSC") ? 29.97 : 25
    #timecode doesn't exist in preview streaming (ts)
    #    exp.has_timecode       = @camera.mp4_has_timecode?(res,fps)
    exp.height             = @camera.video_capture_modes[res][:lrv_height]
    exp.video_codec        = @camera.video_codec
    exp.width              = @camera.video_capture_modes[res][:lrv_width]
    # The expected width is actually *almost* this value. It's the next largest multiple of 16.
    # See comments on STK-1455 for the reasoning here, if you like.
    exp.width = ( exp.width / 16.0 ).ceil * 16

    #    exp.profile_level = @camera.get_profile_level(res, fps, p)
    #video bitrate - commenting out for now since bit_rate sometimes not exposed

    act = @host.get_mpeg_ts_metadata(full_path)
    if act == nil
      failed_arr << "Unable to open mpeg ts video file #{full_path}"
    else
      failed_arr << assert_equal(exp.audio_channels, act.audio_channels,
                                 "#{full_path} streaming (ts) audio_channels (exp=#{exp.audio_channels} != act=#{act.audio_channels})")
      failed_arr << assert_equal(exp.audio_codec, act.audio_codec,
                                 "#{full_path} streaming (ts) audio_codec (exp=#{exp.audio_codec} != act=#{act.audio_codec})")
      failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate,
                                 "#{full_path} streaming (ts) audio_sample_rate (exp=#{exp.audio_sample_rate} != act=#{act.audio_sample_rate})")
      #      failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
      #      "streaming (ts) bitrate (exp=#{exp.video_bitrate} not within 15% of act=#{act.video_bitrate})")
      failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                 "#{full_path} streaming (ts) colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                 "#{full_path} streaming (ts) frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
      #timecode doesn't exist in preview streaming (ts)
      #      failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
      #      "#{full_path} streaming (ts) has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
      failed_arr << assert_equal(exp.width, act.width,
                                 "#{full_path} streaming (ts) width (exp=#{exp.width} != act=#{act.width})")
      failed_arr << assert_equal(exp.height, act.height,
                                 "#{full_path} streaming (ts) height (exp=#{exp.height} != act=#{act.height})")
      failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                 "#{full_path} streaming (ts) video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
      #      failed_arr << assert_equal(exp.profile_level, act.profile_level,
      #      "streaming (ts) AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")
    end
    failed_arr
  end

  #ts file during photo mode idle (ie photo, photo night, burst, time lapse, night lapse)
  #No audio in photo mode so no audio metadata information
  def tu_analyze_photo_ts_idled_metadata(full_path, vm)
    log_info("Checking mpeg ts (stream) metadata #{full_path}")
    failed_arr = []

    exp = VideoMetadata.new()
    exp.aspect_ratio       = @camera.photo_ts[:lrv_aspect_ratio]
    #    exp.video_bitrate            = @camera.get_bitrate(res, fps, p, fov)   #video bitrate - commenting out for now since bit_rate sometimes not exposed
    exp.colorspace         = @camera.colorspace
    exp.video_codec        = @camera.video_codec
    #During idling, preview stream is always available, even if lrv exists. Expected NTSC fps = 29.97, Expected PAL fps = 25
    exp.frame_rate         = (vm == "NTSC") ? 29.97 : 25
    exp.height             = @camera.photo_ts[:lrv_height]
    exp.width              = @camera.photo_ts[:lrv_width]
    #    exp.profile_level      = @camera.get_profile_level(res, fps, p)    #video bitrate - commenting out for now since bit_rate sometimes not exposed

    act = @host.get_mpeg_ts_metadata(full_path)
    if act == nil
      failed_arr << "Unable to open mpeg ts video file #{full_path}"
    else
      #      failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio,
      #      "#{full_path} streaming (ts) aspect_ratio (exp=#{exp.aspect_ratio} != act=#{act.aspect_ratio})")
      failed_arr << assert_equal(exp.colorspace, act.colorspace,
                                 "#{full_path} streaming (ts) colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
                                 "#{full_path} streaming (ts) frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
      failed_arr << assert_equal(exp.width, act.width,
                                 "#{full_path} streaming (ts) width (exp=#{exp.width} != act=#{act.width})")
      failed_arr << assert_equal(exp.height, act.height,
                                 "#{full_path} streaming (ts) height (exp=#{exp.height} != act=#{act.height})")
      failed_arr << assert_equal(exp.video_codec, act.video_codec,
                                 "#{full_path} streaming (ts) video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
    end
    failed_arr
  end

  def tu_save_idle_stream(filename, expired=5)
    #Remove old ts file
    File.delete(filename) if File.exists?(filename)
    @camera.save_ts_filename = filename
    log_info("Saving ts file #{filename}")
    @camera.save_ts_file = true

    # When a packet is missing in a stream, we wait for next stream.
    # If in 5 seconds that it can't save a whole stream, we timeout and fail the test.
    start = Time.now
    timeout = start + expired
    isTimeout = false
    while true
      sleep 1
      break if File.exists?(filename)
      isTimeout = Time.now > timeout
      break if isTimeout
    end
    @camera.save_ts_file = false
    return isTimeout
  end

  def tu_wifi_verfiy_low_light(res, fps)
    failed_arr = []

    if @camera.video_low_light_support?(res, fps) == true
      log_info("Checking low light")

      if @camera.status(:video_low_light) == 0
        ret = @camera.set_video_low_light("ON")
        failed_arr.push(ret[1]) if ret[0] == false
      end

    end
    failed_arr
  end

  # Checks that expected media actually resides on the SD card via HTTP
  # mp4file - Full http address to the media file
  # p - Protune setting ["OFF"|"ON"]
  # res, fps - Resolution and FPS respectively
  # exp_thm - true/false whether a THM file is expected
  def tu_wifi_check_media_existence(type, mp4file, vm, p, res, fps, fov, exp_thm=true)
    full_mp4file = @camera.get_media_url(mp4file)
    failed_arr = []
    full_lrvfile = full_mp4file[0..-4] + "LRV"
    full_thmfile = full_mp4file[0..-4] + "THM"

    log_info("Checking MP4 file existence over http or web server")
    exp = true
    act = @camera.media_exists?(full_mp4file)
    failed_arr << assert_equal(exp, act,
                               "MP4 file doesn't exist on web server (exp=#{exp}, act=#{act})")

    log_info("Checking LRV file existence over http or web server")
    exp = type == "VIDEO" ? @camera.has_lrv?(res, fps, fov, p) : @camera.video_timelapse_has_lrv?(vm, res)
    act = @camera.media_exists?(full_lrvfile)
    failed_arr << assert_equal(exp, act,
                               "LRV file presence on web server (exp=#{exp}, act=#{act})")

    log_info("Checking THM file existence over http or web server")
    exp = type =="VIDEO" ? (@camera.has_thm?(res, fps, p) and exp_thm) : @camera.video_timelapse_has_thm?(res)
    act = @camera.media_exists?(full_thmfile)
    failed_arr << assert_equal(exp, act,
                               "THM file presence on web server (exp=#{exp}, act=#{act})")

    return failed_arr
  end

  # Gets the offset of a specific MP4 atom name
  # Requires AtomicParsley (sudo apt-get install atomicparsley)
  # Returns offset on success, nil on failure
  def tu_get_atom_offset(f, atom)
    o, e, s = @host.sys_exec("which AtomicParsley")
    if not s.success?
      log_error("Unable to find AtomicParsley.  Is it installed?")
      exit 1
    end

    if not File.exists?(f)
      log_warn("Unable to find file at #{f}")
      return nil
    end

    # Grab the atom offset from atomicparsley
    offset = nil
    cmd = "AtomicParsley #{f} -T"
    o, e, s = @host.sys_exec(cmd)
    if not s.success?
      log_warn("#{cmd} failed! Error: #{e}")
      return nil
    end
    o.each_line { |l|
      # Search for the Hero Moment (HMMT) atom
      if l.match("Atom #{atom}") != nil
        # Output example: "Atom HMMT @ 117688066 of size: 412, ends @ 117688478"
        offset = l.split()[3].to_i
        break
      end
    }
    if offset == nil or offset == 0
      log_warn("Unable to get #{atom} atom offset from AtomicParsley output: #{o}")
      return nil
    end
    log_verb("Found atom #{atom} at offset #{offset}")
    return offset
  end

  # Reads the atom directly (as opposed to using some other tool to get the offset)
  # Type is usually a string name.  Case-sensetive.  4 bytes only.
  # Use instead of get_offset especially when only partially downloading file
  def tu_get_atom(file, type, len)
    offset = 0
    File.open(file, "rb") { |f|
      until f.eof?
        f.read(1) != type[0] ? offset += 1 : \
        f.read(1) != type[1] ? offset += 1 : \
        f.read(1) != type[2] ? offset += 1 : \
        f.read(1) != type[3] ? offset += 1 : (return f.read(len))
      end
    }
    return nil
  end

  # Returns an array of the hilight tags (in ms) on success (or [] if none)
  # Returns nil on error
  def tu_read_hilight_tags(f)
    # 4 Bytes atom info (after size/name) + 4 bytes/tag
    data = tu_get_atom(f, "HMMT", (4+4*@camera.hilight_tag_limit))
    return nil if data == nil
    count = data[0...4].unpack("H*")[0].to_i(16)
    tags = []
    (1..count).each { |n|
      tags << data[n*4...(n+1)*4].unpack("H*")[0].to_i(16)
    }
    log_verb("Tags found (ms): #{tags}")
    return tags
  end

  # # Returns an array of the hilight tags (in ms) on success (or [] if none)
  # # Returns nil on error
  # # Requires AtomicParsley (sudo apt-get install atomicparsley)
  # def tu_read_hilight_tags(f)
  #   offset = tu_get_atom_offset(f, "HMMT")
  #   return nil if offset == nil
  #   # Atom format:
  #   # 4 bytes - atom size
  #   # 4 bytes - atom type (HMMT)
  #   # 4 bytes - number of tags
  #   # 400 bytes - tags (up to 100)
  #   # Each tag is 4 bytes equal to the offset (in ms) from the start of the file
  #   size = File.binread(f, 4, offset).unpack("H*")[0].to_i(16)
  #   type = File.binread(f, 4, offset+4) # "HMMT"
  #   count = File.binread(f, 4, offset+8).unpack("H*")[0].to_i(16)
  #   tags = []
  #   (1..count).each { |n|
  #     tags << File.binread(f, 4, offset+8+(4*n)).unpack("H*")[0].to_i(16)
  #   }
  #   log_verb("Tags found (ms): #{tags}")
  #   return tags
  # end

  # The first four 32-bit words (0-3) are the 128-bit MD5 encrypted serial number.
  # The last four 32-bit words (4-7) are as follows:
  #   31                               15     12           6           0
  #    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  #    |    Year                       | Month |  Day      |   Hour    |  word 4
  #    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  #    |  Top 16-bits millisecond tick |Version|  Minutes  | Seconds   |  word 5
  #    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  #    |Bottom 16-bits millisecond tick|         Reserved set to zero  |  word 6
  #    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  #    |                         Reserved set to zero                  |  word 7
  #    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
  #
  # Takes as an argument the MUID bytes as a hex string (BIG-ENDIAN!)
  # (i.e. byte_str.unpack("H*")[0])
  #
  # Returns the MUID values in a hash
  # {
  # :md5sn => md5sn,
  # :year => year, :month => month, :day => day, :hour => hour,
  # :top_ms => top_ms, :version => version, :mins => mins, :secs => secs,
  # :bot_ms => bot_ms, :rsvd1 => rsvd1, :rsvd2 => rsvd2,
  # }
  # Returns nil on error
  def read_muid(muid_hex_string)
    begin
      md5sn = muid_hex_string[0...32]
      ts1   = muid_hex_string[32...40]
      ts2   = muid_hex_string[40...48]
      ts3   = muid_hex_string[48...56]
      ts4   = muid_hex_string[56...64]

      year    = ts1[0...4].to_i(16)
      month   = ts1[4...8].to_i(16) >> 12 & 0x0F
      day     = ts1[4...8].to_i(16) >> 6 & 0x3F
      hour    = ts1[4...8].to_i(16) & 0x3F

      top_ms  = ts2[0...4].to_i(16)
      version = ts2[0...4].to_i(16) >> 12 & 0x0F
      mins    = ts2[4...8].to_i(16) >> 6 & 0x3F
      secs    = ts2[4...8].to_i(16) & 0x3F

      bot_ms  = ts3[0...4].to_i(16)
      rsvd1   = ts3[4...8].to_i(16)

      rsvd2   = ts4.to_i(16)
      return {
        :md5sn => md5sn,
        :year => year, :month => month, :day => day, :hour => hour,
        :top_ms => top_ms, :version => version, :mins => mins, :secs => secs,
        :bot_ms => bot_ms, :rsvd1 => rsvd1, :rsvd2 => rsvd2,
      }
    rescue StandardError => e
      log_warn(e.to_s)
      log_warn(e.backtrace)
    end
    return nil
  end

  # Reads the MUID out of a video file (or a piece of one)
  # Previous version required AtomicParsley (sudo apt-get install atomicparsley)
  # but it did not like partial file downloads required to handle chaptered video.
  def tu_read_muid_mp4(f)
    # offset = tu_get_atom_offset_aparsley(f, "MUID")
    # return nil if offset == nil
    # data  = File.binread(f, 40, offset)
    # p data
    # size  = data[0...4].to_i(16)
    # type  = data[4...8]
    # muid_hash = read_muid(data[8..-1].unpack("H*")[0])

    # Atom length is 40 bytes.  get_atom() returns after the first 8 bytes.
    # Remaining MUID length is 32 bytes.
    data = tu_get_atom(f, "MUID", 32)
    return nil if data == nil
    muid_hash = read_muid(data.unpack("H*")[0])
    return muid_hash
  end

  # Requires exiv2
  def tu_read_muid_jpg(f)
    o, e, s = @host.sys_exec("which exiv2")
    if not s.success?
      log_error("Unable to find exiv2.  Is it installed?")
      exit 1
    end

    if not File.exists?(f)
      log_warn("Unable to find file at #{f}")
      return nil
    end

    # Grab the atom offset from atomicparsley
    offset = nil
    cmd = "exiv2 -Pnv -b #{f} | grep MakerNote"
    o, e, s = @host.sys_exec(cmd)
    if not s.success?
      log_warn("#{cmd} failed! Error: #{e}")
      return nil
    end
    # Read into an array of integers
    data = o.split()[1..-1].map! { |m| m.to_i }
    # Pack into unsigned chars and interpret as hex
    # MUID is located at bytes 64-96 --> hex nibbles 128-192
    d = data.pack("C*").unpack("H*")[0][128...192]
    return read_muid(d)
  end

  # Swaps the endianness of a hex string ('1234' -> '3412')
  def swap_endianness(hex_str)
    ret = ""
    hex_str.chars.to_a.each_slice(2) { |c1, c2| ret.prepend(c1+c2) }
    return ret
  end

  #camera roll verification
  def tu_wifi_analyze_gpmedialist_params(mode, vm=nil, pt=nil, res=nil, fps=nil, fov=nil)
    log_info("Checking gpMediaList parameters for mode #{mode}")
    sleep(0.5)
    failed_arr = []

    case mode

    #For individual video, video in piv, video looping
    when "VIDEO"
      cur_media_hash = @camera.get_last_media("MP4", hash=true)
      failed_arr << "gpMediaList returns single video as group" if cur_media_hash.has_key?("g") == true

      if @camera.has_lrv?(res, fps, fov, pt)
        failed_arr << "gpMediaList has incorrect ls parameter when LRV file should exist" if cur_media_hash["ls"] == "-1"
      else
        failed_arr << "gpMediaList has incorrect ls parameter when LRV file should not exist" if cur_media_hash["ls"] != "-1"
      end

    when "VIDEO_TIMELAPSE"
      cur_media_hash = @camera.get_last_media("MP4", hash=true)
      failed_arr << "gpMediaList returns video timelapse as group" if cur_media_hash.has_key?("g") == true

      if @camera.video_timelapse_has_lrv?(vm, res)
        failed_arr << "gpMediaList has incorrect ls parameter when LRV file should exist" if cur_media_hash["ls"] == "-1"
      else
        failed_arr << "gpMediaList has incorrect ls parameter when LRV file should not exist" if cur_media_hash["ls"] != "-1"
      end

    when "PHOTO", "PHOTO_NIGHT"
      cur_media_hash = @camera.get_last_media("JPG", hash=true)

      # check gpmedialist DOESN'T returns as group
      failed_arr << "Single photo is returned as group" if cur_media_hash.has_key?("g")

    when "BURST"
      cur_media_hash = @camera.get_last_media("JPG", hash=true)

      # check gpmedialist returns as group
      failed_arr << "Burst isn't returned as group" if !cur_media_hash.has_key?("g")

      #check gpmedialist returns correct group type
      failed_arr << "gpmedialist returns incorrect group type for burst" if cur_media_hash["t"] != @camera.get_group_type(mode)

    when "TIMELAPSE"
      cur_media_hash = @camera.get_last_media("JPG", hash=true)

      # check gpmedialist returns as group
      failed_arr << "Time lapse isn't returned as group" if !cur_media_hash.has_key?("g")

    #TODO
    #checking gpmedialist returns correct group type
    #https://goprodev.fogbugz.com/default.asp?12862
    #      failed_arr << "gpmedialist returns incorrect group type for time lapse" if cur_media_hash["t"] != @camera.get_group_type(mode)

    when "NIGHTLAPSE"
      cur_media_hash = @camera.get_last_media("JPG", hash=true)

      # check gpmedialist returns as group
      failed_arr << "Time lapse isn't returned as group" if !cur_media_hash.has_key?("g")

    #TODO
    #checking gpmedialist returns correct group type
    #https://goprodev.fogbugz.com/default.asp?12862
    #      failed_arr << "gpmedialist returns incorrect group type for time lapse" if cur_media_hash["t"] != @camera.get_group_type(mode)
    when "PIV" #photo only
      cur_media_hash = @camera.get_last_media("JPG", hash=true)

      # check gpmedialist returns as group
      failed_arr << "Photo-in-video isn't returned as group" if !cur_media_hash.has_key?("g")

    #TODO
    #check gpmedialist returns correct group type
    #https://goprodev.fogbugz.com/default.asp?12862
    #      failed_arr << "gpmedialist returns incorrect group type for photo-in-video" if cur_media_hash["t"] != @camera.get_group_type(mode)
    when "SPS"
      cur_media_hash = @camera.get_last_media("JPG", hash=true)

      # check gpmedialist returns as group
      failed_arr << "Continuous shot isn't returned as group" if !cur_media_hash.has_key?("g")
    else
      failed_arr << "Unknown mode when verifying gpMediaList params"
    end

    failed_arr << "gpMediaList has m (modified time) value less than 0 or empty" if cur_media_hash["mod"].to_i <=0 || cur_media_hash["mod"] == ""

    failed_arr << "gpMediaList has s (size) value less than 0 or empty" if cur_media_hash["s"].to_i <=0 || cur_media_hash["s"] == ""

    failed_arr
  end

  def tu_analyze_photo_metadata(full_path, type, res, value)
    log_info("Checking metadata")

    failed_arr = []
    jpg_name = File.basename(full_path)
    meta = @host.get_img_metadata(full_path)
    # Format
    exp = "JPEG"
    act = meta[:format]
    failed_arr << assert_equal(exp, act, "Format: Exp (#{exp}) != actual (#{act})")
    # Width
    exp = @camera.photo_modes[res][:width]
    act = meta[:width]
    failed_arr << assert_equal(exp, act, "Width: Exp (#{exp}) != actual (#{act})")
    # Height
    exp = @camera.photo_modes[res][:height]
    act = meta[:height]
    failed_arr << assert_equal(exp, act, "Height: Exp (#{exp}) != actual (#{act})")
    failed_arr
  end

  # Return looping minutes required
  def tu_get_looping_min_reqd(camera, looping)
    min_reqd = 0
    if  looping == "MAX"
      min_reqd =  camera.looping_chapter_len[looping] + 5 # 5 is for padding
    elsif looping == "OFF"
      min_reqd = 0
    else
      min_reqd = looping.to_i + camera.looping_chapter_len[looping] + 5 # 5 is for padding
    end
    min_reqd
  end

  # Gets the full directory path for downloads
  # Path will be /base_dir/res/mode/value_str (e.g. /tmp/5MED/burst/3_1)
  def tu_get_download_dir(base_dir, res, mode, val=nil)
    if val == nil
      val_str = ""
    elsif mode == "pes" and val < 1
      val_str = "%0.1f" %val  # Make "0.5" second time-lapse pretty
    else
      val_str = val.to_s
    end
    return File.join(base_dir, res.to_s, mode.to_s, val_str)
  end

  # 1) Leave blank => Run only default values
  # 2) Leave blank but specify --full => Running all possibilities for all options
  # 3) Setting option to VAL => Run only VAL for that option
  # 4) Setting option to ALL => Run all possibilities for that option
  def use_option(options, sym, val)
    if options[sym] == nil
      # Case 1 & 2
      if @camera.defaults[sym].to_s == val.to_s or options[:full] == true
        return true
      else
        return false
      end
    else
      # Case 3 & 4
      if options[sym].to_s == val.to_s or options[sym].to_s == "ALL"
        return true
      else
        return false
      end
    end
  end

  # For photo single only.
  def tu_get_photo_test_params(cameraO=nil, optionsA=nil)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    camera.get_photo_resolutions.each { |res|
      next if options[:photo_resolution] != nil and options[:photo_resolution] != res
      ["UP", "DOWN"].each{ |orient|
        next if use_option(options, :setup_orientation, orient) == false
        #        next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
        ["OFF", "ON"].each { |spot|
          spot = nil if !camera.photo_spot_metering_support?
          (next if use_option(options, :photo_spot_metering, spot) == false) if camera.photo_spot_metering_support?
          if options[:photo_pt] == "OFF" || options[:photo_pt] == nil
            pt = camera.photo_protune_support? ? "OFF" : nil
            if !test_params.include?([res, orient, spot, pt, nil, nil, nil, nil, nil])
              log_verb("Adding test [%s, orient=%s, spot=%s, pt=%s]" %[res, orient, spot, pt])
              test_params << [res, orient, spot, pt, nil, nil, nil, nil, nil]
            end
          end

          if camera.photo_protune_support?
            if options[:photo_pt] == "ON" || options[:photo_pt] == nil
              pt = "ON"
              camera.get_protune_white_balance.each { |wb|
                next if use_option(options, :photo_pt_wb, wb) == false
                camera.get_protune_color.each { |col|
                  next if use_option(options, :photo_pt_color, col) == false
                  camera.get_photo_protune_iso.each { |iso|
                    next if use_option(options, :photo_pt_iso, iso) == false
                    camera.get_protune_sharpness.each { |sh|
                      next if use_option(options, :photo_pt_sharp, sh) == false
                      camera.get_protune_exposure.each { |ex|
                        next if use_option(options, :photo_pt_ev, ex) == false
                        log_verb("Adding test [%s, %s, spot=%s, pt=%s, wb=%s, col=%s, iso=%s, sh=%s, ex=%s]" \
                                 %[res, orient, spot, pt, wb, col, iso, sh, ex])
                        test_params << [res, orient, spot, pt, wb, col, sh, iso, ex]
                      } # exposure
                    } # sharpness
                  } # iso
                } # color
              } # white balance
            end # protune ON?
          end # protune support?
        } # spot metering
      } # orientation
    } # resolution
    return test_params
  end

  #For photo night only.
  #Quick = run only default vars (non-protune & protune)
  #Full = run all vars/permutation (non-protune & protune)
  def tu_get_photo_night_test_params(cameraO=nil, optionsA=nil)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    camera.get_photo_resolutions().each { |res|
      next if options[:photo_resolution] != nil and options[:photo_resolution] != res
      ["UP", "DOWN"].each{ |orient|
        next if use_option(options, :setup_orientation, orient) == false
        #        next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
        ["OFF", "ON"].each { |spot|
          spot = nil if !camera.photo_spot_metering_support?
          (next if use_option(options, :photo_spot_metering, spot) == false) if camera.photo_spot_metering_support?
          camera.get_photo_shutter_exposure_intervals.each { |se|
            next if use_option(options, :photo_shutter_ev, se) == false

            if options[:photo_pt] == "OFF" || options[:photo_pt] == nil
              pt = camera.photo_protune_support? ? "OFF" : nil
              if !test_params.include?([res, orient, spot, se, pt, nil, nil, nil, nil])
                log_verb("Adding test [%s, %s, spot=%s, shutter=%s, pt=%s]" %[res, orient, spot, se, pt])
                test_params << [res, orient, spot, se, pt, nil, nil, nil, nil, nil]
              end
            end

            if camera.photo_protune_support?
              if options[:photo_pt] == "ON" || options[:photo_pt] == nil
                pt = "ON"
                camera.get_protune_white_balance.each { |wb|
                  #Default wb = 5500K if shutter not AUTO, else wb = "AUTO"
                  if se != "AUTO"
                    next if wb == "AUTO"
                    next if options[:photo_pt_wb] != nil and options[:photo_pt_wb] != "ALL" and options[:photo_pt_wb] != wb
                    wb = "5500K" if options[:photo_pt_wb] == nil and options[:full] == false
                  else
                    next if use_option(options, :photo_pt_wb, wb) == false
                  end
                  camera.get_protune_color.each { |col|
                    next if use_option(options, :photo_pt_color, col) == false
                    camera.get_photo_protune_iso.each { |iso|
                      next if use_option(options, :photo_pt_iso, iso) == false
                      camera.get_protune_sharpness.each { |sh|
                        next if use_option(options, :photo_pt_sharp, sh) == false
                        camera.get_protune_exposure.each { |ex|
                          if se != "AUTO"
                            ex = nil
                          else
                            next if use_option(options, :photo_pt_ev, ex) == false
                          end
                          if !test_params.include?([res, orient, spot, se, pt, wb, col, sh, iso, ex])
                            log_verb("Adding test [%s, %s, spot=%s, se=%s, pt=%s, wb=%s, col=%s, sh=%s, iso=%s, ex=%s]" \
                                     %[res, orient, spot, se, pt, wb, col, sh, iso, ex])
                            test_params << [res, orient, spot, se, pt, wb, col, sh, iso, ex]
                          end
                        } # exposure
                      } # sharpness
                    } # iso
                  } # color
                } # white balance
              end # protune ON?
            end # protune support?
          } # shutter exposure
        } # end spot metering
      } # orientation
    } # end get_photo_resolutions
    return test_params
  end

  def tu_get_photo_continuous_test_params(cameraO=nil, optionsA=nil)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    camera.get_photo_resolutions().each { |res|
      next if options[:photo_resolution] != nil and options[:photo_resolution] != res
      camera.get_photo_continuous_rates(res).each { |sps|
        next if options[:photo_continuous] != nil and options[:photo_continuous] != sps
        ["UP", "DOWN"].each{ |orient|
          next if use_option(options, :setup_orientation, orient) == false
          #          next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
          ["OFF", "ON"].each{ |spot|
            spot = nil if !camera.photo_spot_metering_support?
            (next if use_option(options, :photo_spot_metering, spot) == false) if camera.photo_spot_metering_support?
            if options[:photo_pt] == "OFF" || options[:photo_pt] == nil
              pt = camera.photo_protune_support? ? "OFF" : nil
              if !test_params.include?([res, sps, orient, spot, pt, nil, nil, nil, nil, nil])
                log_verb("Adding test [%s, sps=%s, %s, spot=%s pt=%s]" %[res, sps, orient, spot, pt])
                test_params << [res, sps, orient, spot, pt, nil, nil, nil, nil, nil]
              end
            end

            if camera.photo_protune_support?
              if options[:photo_pt] == "ON" || options[:photo_pt] == nil
                pt = "ON"
                camera.get_protune_white_balance.each { |wb|
                  next if use_option(options, :photo_pt_wb, wb) == false
                  camera.get_protune_color.each { |col|
                    next if use_option(options, :photo_pt_color, col) == false
                    camera.get_photo_protune_iso.each { |iso|
                      next if use_option(options, :photo_pt_iso, iso) == false
                      camera.get_protune_sharpness.each { |sh|
                        next if use_option(options, :photo_pt_sharp, sh) == false
                        camera.get_protune_exposure.each { |ex|
                          next if use_option(options, :photo_pt_ev, ex) == false
                          log_verb("Adding test [%s, sps=%s, %s, spot=%s, pt=%s, wb=%s, col=%s, iso=%s, sh=%s, ex=%s]" \
                                   %[res, sps, orient, spot, pt, wb, col, iso, sh, ex])
                          test_params << [res, sps, orient, spot, pt, wb, col, sh, iso, ex]
                        } # end exp
                      } # end sharp
                    } # end iso
                  } # end col
                } # end wb
              end #protune ON?
            end # protune support?
          } # end spot
        } # orientation
      } # end get_photo_continuous_rate
    } # end get_photo_resolutions
    test_params
  end

  def tu_get_multi_photo_burst_test_params(cameraO=nil, optionsA=nil)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    camera.get_photo_resolutions().each { |res|
      next if options[:multi_photo_resolution] != nil and options[:multi_photo_resolution] != res
      camera.get_multi_photo_burst_rates(res).each { |bu|
        next if options[:multi_photo_burst] != nil and options[:multi_photo_burst] != bu
        ["UP", "DOWN"].each{ |orient|
          next if use_option(options, :setup_orientation, orient) == false
          #          next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
          ["OFF", "ON"].each{ |spot|
            spot = nil if !camera.multi_photo_spot_metering_support?
            (next if use_option(options, :multi_photo_spot_meter, spot) == false) if camera.multi_photo_spot_metering_support?

            if options[:multi_photo_pt] == "OFF" || options[:multi_photo_pt] == nil
              pt = camera.multi_photo_protune_support? ? "OFF" : nil
              if !test_params.include?([res, bu, orient, spot, pt, nil, nil, nil, nil, nil])
                log_verb("Adding test [%s, bu=%s, %s, spot=%s pt=%s]" %[res, bu, orient, spot, pt])
                test_params << [res, bu, orient, spot, pt, nil, nil, nil, nil, nil]
              end
            end

            if camera.multi_photo_protune_support?
              if options[:multi_photo_pt] == "ON" || options[:multi_photo_pt] == nil
                pt = "ON"
                camera.get_protune_white_balance.each { |wb|
                  next if use_option(options, :multi_photo_pt_wb, wb) == false
                  camera.get_protune_color.each { |col|
                    next if use_option(options, :multi_photo_pt_color, col) == false
                    camera.get_photo_protune_iso.each { |iso|
                      next if use_option(options, :multi_photo_pt_iso, iso) == false
                      camera.get_protune_sharpness.each { |sh|
                        next if use_option(options, :multi_photo_pt_sharp, sh) == false
                        camera.get_protune_exposure.each { |ex|
                          next if use_option(options, :multi_photo_pt_ev, ex) == false
                          log_verb("Adding test [%s, bu=%s, %s, spot=%s, pt=%s, wb=%s, col=%s, sh=%s, ex=%s]" \
                                   %[res, bu, orient, spot, pt, wb, col, iso, sh, ex])
                          test_params << [res, bu, orient, spot, pt, wb, col, sh, iso, ex]
                        } # end exp
                      } # end sharp
                    } # end iso
                  } # end col
                } # end wb
              end #protune ON?
            end # protune support?
          } # end spot
        } # orientation
      } # end get_multi_multi_photo_burst
    } # end get_multi_photo_resolutions
    test_params
  end

  def tu_get_multi_photo_timelapse_test_params(cameraO=nil, optionsA=nil)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    camera.get_photo_resolutions().each { |res|
      next if options[:multi_photo_resolution] != nil and options[:multi_photo_resolution] != res
      camera.get_multi_photo_timelapse_rates(res).each { |pes|
        next if options[:multi_photo_timelapse] != nil and options[:multi_photo_timelapse] != pes.to_s
        ["UP", "DOWN"].each{ |orient|
          next if use_option(options, :setup_orientation, orient) == false
          #          next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
          ["OFF", "ON"].each{ |spot|
            spot = nil if !camera.multi_photo_spot_metering_support?
            (next if use_option(options, :multi_photo_spot_meter, spot) == false) if camera.multi_photo_spot_metering_support?
            if options[:multi_photo_pt] == "OFF" || options[:multi_photo_pt] == nil
              pt = camera.multi_photo_protune_support? ? "OFF" : nil
              if !test_params.include?([res, pes, orient, spot, pt, nil, nil, nil, nil, nil])
                log_verb("Adding test [%s, pes=%s, %s, spot=%s pt=%s]" %[res, pes, orient, spot, pt])
                test_params << [res, pes, orient, spot, pt, nil, nil, nil, nil, nil]
              end
            end

            if camera.multi_photo_protune_support?
              if options[:multi_photo_pt] == "ON" || options[:multi_photo_pt] == nil
                pt = "ON"
                camera.get_protune_white_balance.each { |wb|
                  next if use_option(options, :multi_photo_pt_wb, wb) == false
                  camera.get_protune_color.each { |col|
                    next if use_option(options, :multi_photo_pt_color, col) == false
                    camera.get_photo_protune_iso.each { |iso|
                      next if use_option(options, :multi_photo_pt_iso, iso) == false
                      camera.get_protune_sharpness.each { |sh|
                        next if use_option(options, :multi_photo_pt_sharp, sh) == false
                        camera.get_protune_exposure.each { |ex|
                          next if use_option(options, :multi_photo_pt_ev, ex) == false
                          log_verb("Adding test [%s, pes=%s, %s, spot=%s, pt=%s, wb=%s, col=%s, sh=%s, ex=%s]" \
                                   %[res, pes, orient, spot, pt, wb, col, iso, sh, ex])
                          test_params << [res, pes, orient, spot, pt, wb, col, sh, iso, ex]
                        } # end exp
                      } # end sharp
                    } # end iso
                  } # end col
                } # end wb
              end #protune ON?
            end # protune support?
          } # end spot
        } #orientation
      } # end get_multi_photo_timelapse
    } # end get_photo_resolutions
    test_params
  end

  def tu_get_multi_photo_nightlapse_test_params(cameraO=nil, optionsA=nil)
    camera = cameraO != nil ? cameraO : @camera
    options = optionsA != nil ? optionsA : @options
    test_params = []

    camera.get_photo_resolutions().each { |res|
      next if options[:multi_photo_resolution] != nil and options[:multi_photo_resolution] != res
      camera.get_multi_photo_nightlapse_rates(res).each { |pes|
        next if options[:multi_photo_nightlapse] != nil and options[:multi_photo_nightlapse] != pes.to_s
        ["UP", "DOWN"].each{ |orient|
          next if use_option(options, :setup_orientation, orient) == false
          #          next if options[:setup_orientation] != nil and options[:setup_orientation] != orient
          ["OFF", "ON"].each{ |spot|
            spot = nil if !camera.multi_photo_spot_metering_support?
            (next if use_option(options, :multi_photo_spot_meter, spot) == false) if camera.multi_photo_spot_metering_support?
            camera.get_multi_shutter_exposure_intervals.each { |se|
              # Shutter interval cannot be greater than time-lapse interval
              next if se != 'AUTO' and pes != 'CONTINUOUS' and se.to_i >= pes.to_i
              next if use_option(options, :multi_photo_shutter_ev, se) == false
              if options[:multi_photo_pt] == "OFF" || options[:multi_photo_pt] == nil
                pt = camera.multi_photo_protune_support? ? "OFF" : nil
                if !test_params.include?([res, pes, orient, spot, se, pt, nil, nil, nil, nil])
                  log_verb("Adding test [%s, pes=%s, %s, spot=%s shutter=%s pt=%s ]" %[res, pes, orient, spot, se, pt])
                  test_params << [res, pes, orient, spot, se, pt, nil, nil, nil]
                end
              end

              if camera.multi_photo_protune_support?
                if options[:multi_photo_pt] == "ON" || options[:multi_photo_pt] == nil
                  pt = "ON"
                  #              camera.get_multi_shutter_exposure_intervals.each { |se|
                  #                # Shutter interval cannot be greater than time-lapse interval
                  #                next if se != 'AUTO' and pes != 'CONTINUOUS' and se.to_i >= pes.to_i
                  #                next if use_option(options, :multi_photo_shutter_ev, se) == false
                  camera.get_protune_white_balance.each { |wb|
                    #Default wb = 5500K if shutter not AUTO, else wb = "AUTO"
                    if se != "AUTO"
                      next if wb == "AUTO"
                      next if options[:multi_photo_pt_wb] != nil and options[:multi_photo_pt_wb] != "ALL" and options[:multi_photo_pt_wb] != wb
                      wb = "5500K" if options[:multi_photo_pt_wb] == nil and options[:full] == false
                    else
                      next if use_option(options, :multi_photo_pt_wb, wb) == false
                    end
                    camera.get_protune_color.each { |col|
                      next if use_option(options, :multi_photo_pt_color, col) == false
                      camera.get_photo_protune_iso.each { |iso|
                        next if use_option(options, :multi_photo_pt_iso, iso) == false
                        camera.get_protune_sharpness.each { |sh|
                          next if use_option(options, :multi_photo_pt_sharp, sh) == false
                          camera.get_protune_exposure.each { |ex|
                            if se != "AUTO"
                              ex = nil
                            else
                              next if use_option(options, :multi_photo_pt_ev, ex) == false
                            end
                            if !test_params.include?([res, pes, orient, spot, se, pt, wb, col, sh, iso, ex])
                              log_verb("Adding test [%s, pes=%s, %s, spot=%s, se=%s, pt=%s, wb=%s, col=%s, iso=%s, sh=%s, ex=%s]" \
                                       %[res, pes, orient, spot, se, pt, wb, col, iso, sh, ex])
                              test_params << [res, pes, orient, spot, se, pt, wb, col, sh, iso, ex]
                            end
                          } # end exp
                        } # end sharp
                      } # end iso
                    } # end col
                  } # end wb
                end #protune ON?
              end # protune support?
            } # end se
          } # end spot
        } #orientation
      } # end get_multi_photo_nightlapse
    } # end get_photo_resolutions
    test_params
  end

  #:vc_lang = "1 lang", --shuffle - randomize tests within that 1 language, based on input device (piper/sniper)
  #:vc_lang = "ALL", --shuffle - randomize tests across ALL languages, based on input device (piper/sniper)
  def tu_get_voice_commands_test_params()
    test_params = []
    cam_state = []

    if (!@data_hash.has_key?(@options[:vc_lang]) && @options[:vc_lang] != "ALL")
      return test_params, cam_state 
    end

    @data_hash.keys.each { |lang|
      if @options[:vc_lang] == "ALL" || @options[:vc_lang] == lang
        @data_hash[lang].keys.each { |input|
          if input.downcase.include?(@options[:vc_input])
            @data_hash[lang][input].keys.each { |state|
              cam_state << state
              @data_hash[lang][input][state].each {|command, audio_file|

                next if !@options[:vc_command].nil? && @options[:vc_command] != command.downcase

                ltp_log($VERB,"Adding test [lang=%s, input=%s, state=%s, command=%s, audio_file=%s]" \
                                           %[lang, input, state, command, audio_file])
                test_params << [lang, input, state, command, audio_file]

              }#end command
            }#end state
          end #input
        } #end input type
      end #lang
    } #end lang

    camera_state = cam_state.uniq()
    test_params.shuffle! if @options[:shuffle]
    return test_params, camera_state

  end

  # In Bawa, only some resolutions supports looping, and sometimes setting looping to
  # unsupported res will cause camera to restart
  # This function appropriately turns looping off by first setting camera to supported
  # res beforehand
  def tu_reset_looping_off
    if @camera.release == "HD3" and @camera.video_looping_support?
      if @camera.already_set?(:video_looping, "OFF")[0] == false
        # Hard-code to 1080/30/W.  It's just easier
        vm, res, fps, fov = "NTSC", "1080", "30", "W"
        # # Just take the first one in the list
        # vm, res, fps, fov = tu_get_looping_res(@camera, @options, quiet=true)[0]
        log_info("Disabling looping, but first setting to #{vm} #{res}/#{fps}/#{fov}")
        @camera.set_video(vm, res, fps, fov)
        @camera.set_video_looping("OFF")
      end
    end
  end

  # In Bawa, only some resolutions supports photo-in-video(piv), and sometimes setting
  # piv to unsupported res will cause camera to restart
  # This function appropriately turns piv off by first setting camera to supported res
  # beforehand
  def tu_reset_piv_off
    if @camera.release == "HD3" and @camera.video_piv_support?
      if @camera.already_set?(:video_piv, "OFF")[0] == false
        # Hard-code to 1080/30/W.  It's just easier
        vm, res, fps, fov = "NTSC", "1080", "30", "W"
        # # Just take the first one in the list
        # vm, res, fps, fov = tu_get_piv_res(@camera, @options, quiet=true)[0]
        log_info("Disabling PIV, but first setting to #{vm} #{res}/#{fps}/#{fov}")
        @camera.set_video(vm, res, fps, fov)
        @camera.set_video_piv("OFF")
      end
    end
  end

  def tu_get_cmd_hash(cmd_symbol)
    if @camera.remote_api_version == 1 || @camera.interfaces.include?(:serial)
      return @camera.method(cmd_symbol).call
    end

    if @camera.remote_api_version == 2 && @camera.interfaces.include?(:wifi)
      return @camera.method(@camera.setting[cmd_symbol]['method']).call
    end
    return []
  end

  def tu_reset_pushy()
    3.times { |n|
      log_info("Try #{n+1} of 3")
      @camera.pushy_hard_reset()
      @camera.pushy_enable_wifi()
      sleep(15)
      @host.bounce_wifi
      if @autoconnect == true
        next if @host.wait_for_beacons(@camera.ssid) == false
        # In the autoconnect case we need to wait for beaconing
        # and then manually connect.
        return true if @host.connect_camera(@camera.ssid,
                                            @camera.ip, @camera.pairing_code) == true
      # Otherwise just keep trying until the WPA supplicant makes the connection
      # to the already-known network
      else
        ret = @host.wait_for_wifi_camera(@options[:ip], timeout=60, interval=5, @camera.mac)
        return true if ret == true
        log_warn("Failed to connect back to camera Wi-Fi.  Resetting camera again")
      end
    }
    log_error("Max retries exhausted.  Giving up.")
    exit ExitCode::ERROR
  end

  # Reset the camera without involving a camera object
  # Must have powerstrip and serial info available in @options
  # As well as a Host object
  def tu_reset_camera(pmic=false)
    log_info("Resetting camera")
    # If PUSHY is available, use it
    if (defined? @camera) and (@camera.pushy != nil) and (@camera.pushy.success == true)
      tu_reset_pushy()
      return
    end

    # Otherwise use old powerstrip method
    powerstrip = PowerStrip.new(@options[:power_ip],
                                @options[:power_usr], @options[:power_pwd])
    outlet1 = @options[:battoutlet]
    outlet2 = @options[:usboutlet]

    if pmic == false
      if powerstrip == nil
        log_warn("Unable to reset power without powerstrip information")
        return false
      elsif outlet1 == nil and outlet2 == nil
        log_warn("No powerstrip outlet specified for cycling")
        return false
      end
    end

    # Include the APP mode command for each camera model.
    # They will all be sent
    name = (@camera != nil) ? @camera.name : "*"
    case name
    when "BACKDOOR", "PIPE","ARGUS"
      pmic_cmd = "t as3715 reset"
      wifi_cmd = "t api wireless mode app"
    when "ARGUS", "STREAKY", "SQUIRRELS"
      pmic_cmd = "t api system reset force"
      wifi_cmd = "t api wireless mode app"
    when "ROCKYPOINT", "HALEIWA", "HIMALAYAS"
      pmic_cmd = "t as3715 reset"
      wifi_cmd = "t wireless enable on"
    when "*"
      pmic_cmd = "t as3715 reset"
      wifi_cmd = "t wireless enable on\r\nt api wireless mode app"
    else
      log_warn("#{@camera.name} does not have Wi-Fi enable command.  Cannot restart")
      return false
    end

    dev = @options[:serialdev]
    if dev == nil or @host.verify_serial_port(dev) == false
      log_warn("Unable to recover camera with no serial interface")
      return false
    end
    if pmic == true
      3.times {
        while @host.wait_for_wifi_camera(@options[:ip], timeout=1, interval=1) == true do
          @host.send_serial(pmic_cmd, dev)
          sleep 5.0
        end
        sleep 5.0
        3.times {
          @host.send_serial(wifi_cmd, dev)
          sleep 0.5
        }
        ret = @host.wait_for_wifi_camera(@options[:ip], timeout=60, interval=5)
        return true if ret == true
        log_warn("Failed to connect back to camera Wi-Fi.  Resetting camera again")
      }
    else
      5.times {
        powerstrip.turn_off(outlet1) if outlet1 != nil
        powerstrip.turn_off(outlet2) if outlet2 != nil
        sleep 3.0
        powerstrip.turn_on(outlet2) if outlet2 != nil
        powerstrip.turn_on(outlet1) if outlet1 != nil
        sleep 15

        3.times {
          @host.send_serial(wifi_cmd, dev)
          sleep 0.5
        }
        if @host.is_raspberry_pi?
          @host.bounce_wifi
        else
          next if @host.wait_for_beacons(@camera.ssid) == false
        end

        # In the autoconnect case we need to wait for beaconing
        # and then manually connect.
        if @autoconnect == true
          return true if @host.connect_camera(@camera.ssid,
                                              @camera.ip, @camera.pairing_code) == true
        # Otherwise just keep trying until the WPA supplicant makes the connection
        # to the already-known network
        else
          ret = @host.wait_for_wifi_camera(@options[:ip], timeout=120, interval=5)
          if ret == true
            log_info("Camera recovered successfully")
            return true
          end
          log_warn("Failed to connect back to camera Wi-Fi.  Resetting camera again")
        end
      }
    end
    log_error("Max retries exhausted.  Giving up.")
    exit ExitCode::ERROR
  end # end tu_reset_camera

  # Return a camera object -- resetting if necessary
  def tu_get_camera()
    3.times {
      begin

        if @options[:ip] != nil and @options[:pc] != nil
          @camera = get_wifi_camera(@options[:ip], @options[:pc], @options[:serialdev], @options[:logfile])
        elsif @options[:ble] != nil
          @camera = get_ble_device(@options[:ip], @options[:pc], @options[:ble], @options[:serialdev], @options[:logfile])
        elsif @options[:gccbdev] != nil
          @camera = get_gccb_camera(@options[:gccbdev], @options[:serialdev], @options[:logfile])
        elsif @options[:rc_info] != nil
          @camera = get_rc_cameras(@options[:rc_info])
        elsif @options[:serialdev] != nil
          @camera = get_serial_camera(@options[:serialdev])
        else
          log_error("Must specify either model/serial, ip/pc, gccbdev, rc_info, or ble")
          exit ExitCode::ERROR
        end
        return @camera if @camera != nil
      rescue StandardError => e
        log_warn(e.to_s)
        tu_reset_camera()
      end

    }
    log_error("Unable to instantiate a valid camera object.")
    exit ExitCode::ERROR
  end # end tu_get_camera

  # Returns true if test should be skipped based on counter (c) and range
  # (rmin, rmax).  rmax <= 0 signifies 'run til the end'.
  def tu_should_skip(c, rmin, rmax)
    if c < rmin
      log_info("Skipping test ##{c} (range_min = #{rmin})")
      return true
    elsif rmax <= 0
      return false
    elsif c > rmax
      log_info("Skipping test ##{c} (range_max = #{rmax})")
      return true
    else
      return false
    end
  end

  # Previously existing methods that are now removed.
  def tu_method_removed(); log_error("#{caller[0].split(" ").last.gsub("\'","").gsub("\`","")}() is gone, so don't use it! Exiting."); exit 1; end

  def tu_valid_timecode?(*a);         tu_method_removed(); end

  def tu_analyze_mp4_fov (*a);        tu_method_removed(); end

  def tu_get_video_test_params(*a);   tu_method_removed(); end

  def tu_settings_valid?(*a);         tu_method_removed(); end

  def tu_set_video_settings(*a);      tu_method_removed(); end

  def tu_capture_video(*a);           tu_method_removed(); end

  def tu_get_protune_looping_res(*a); tu_method_removed(); end

  def tu_get_expected_n_photos(*a);   tu_method_removed(); end

  def tu_take_photo(*a);              tu_method_removed(); end

  def tu_take_burst(*a);              tu_method_removed(); end

  def tu_take_time_lapse(*a);         tu_method_removed(); end

  def tu_image_metadata_checks(*a);   tu_method_removed(); end

  def tu_pause_check()
    if @options[:pause]
      puts("TEST PAUSED: (hit Enter to continue)")
      inp = STDIN.gets
    end
  end

  # Called for a test case before generating media.
  # Pass in the medialist if there is one, otherwise it will get it.
  def tu_map_media_before( before_list=nil )
    #log_debug( "tu_map_media_before(): Called with before_list: #{before_list}" )
    if before_list
      @map_media_before_list = before_list
    else
      @map_media_before_list = @camera.get_medialist()
    end
    #log_debug( "tu_map_media_before(): Saved before list of #{@map_media_before_list}" )
  end

  # Called for a test case after capturing.
  # Pass in the script file name, testcase name, and medialist if there is one.
  def tu_map_media_after( script_name, test_case_name, after_list=nil )
    #log_debug( "tu_map_media_after(): Called with after_list: #{after_list}" )
    #log debug( "tu_map_media_after(): Script: #{script_name} Test Case: #{test_case_name}" )
    if after_list
      @map_media_after_list = after_list
    else
      @map_media_after_list = @camera.get_medialist()
    end
    #log_debug( "tu_map_media_after(): saved after list of #{@map_media_after_list}" )
    unless @map_media_after_list
      log_warn( "tu_map_media_after(): Medialist post-capture is empty! Adding no mappings." )
      return
    end
    if @map_media_before_list
      map_media_list = @map_media_after_list - @map_media_before_list
    else
      map_media_list = @map_media_after_list
    end
    return tu_map_media_list( script_name, test_case_name, map_media_list )
  end

  # Works the same as tu_map_media_after, but without subtracting the before list.
  # Actually, that one calls this one once it's sorted out the media list.
  def tu_map_media_list( script_name, test_case_name, map_media_list)
    #log_debug( "tu_map_media_list(): Called with map_media_list: #{map_media_list}" )
    #log_debug( "tu_map_media_list(): Script: #{script_name} Test Case: #{test_case_name}" )
    unless @map_media_result
      @map_media_result = ""
      #log_debug( "tu_map_media_list(): Blanking out results since none found." )
    end
    map_media_list.each { |filename|
      @map_media_result += "#{script_name} #{test_case_name} #{filename}\n"
      #log_debug( "tu_map_media_list(): Added to results: #{script_name} #{test_case_name} #{filename}" )
    }
  end

  # Dumps the saved maedia mapping output to a file in the output directory.
  def tu_map_media_done()
    #log_debug( "tu_map_media_done(): Called. Dumping results to file, screen if verbose." )
    # For now, print it out!
    #@options[:logfile]
    if @map_media_result
      # Print out the list of media if verbose.
      @map_media_result.split("\n").each { |mapping|
        log_verb( "MEDIA: #{mapping}" )
      }
      # Save the list of media if there's a log file happening.
      # Save it to the same directory, but called mapped_media.txt.
      if( @options[:logfile] )
        map_file = File.join(File.dirname(@options[:logfile]), "mapped_media.txt")
        #log_warn( "MEDIA_MAP_FILE: #{map_file}" )
        File.open(map_file, "a") { |file| file.write(@map_media_result) }
      end
    end
  end

  def tu_keep_or_delete_all_media()
    if @options[:keep_media]
      log_info("Not deleting existing media.")
    else
      @camera.delete_all_media()
    end
  end

  def tu_verify_sd_status(do_exit=true)
    if @camera.interfaces.include?(:wifi)
      exiting = do_exit ? " Exiting." : ""
      sd_status = @camera.get_status(:sd_status)
      case sd_status
      when 0
        log_info("SD card status is Okay (0). Testing can commence.")
      when 1
        log_error("SD card status is Full (1). Can't encode new media on it!" + exiting )
        exit(1) if do_exit
      when 2
        log_error("SD card status is Missing (2). Can't encode new media without one!" + exiting )
        exit(2) if do_exit
      when 3
        log_error("SD card status is Error (3). Can't encode new media on it!" + exiting )
        exit(3) if do_exit
      end
    else
      log_warn("Checking SD card status only works for wifi cameras. Skipping this check.")
    end
  end

  def tu_save_media(runtype = "INDIVIDUAL")
    dir = @options[:download_media] if @options
    if dir == nil
      return
    end

    log_info("Attempting to save media")
    if not File.directory?(dir)
      log_warn("Unable to find #{dir} to save media")
      return
    end

    datetime = ENV["START_TIME"]
    datetime = Time.now.strftime("%Y-%m-%d-%I-%M-%p") if datetime == nil
    cam_dir = "%s.%02d.%s_%s" %[@camera.release, @camera.type, @camera.build, datetime]
    #If we are specifying a BAT run, then use this directory structure
    media_dir = if dir.match("/mnt/gopro-share/BAT")
                  File.join(dir, @camera.name, @camera.build, datetime)
                else
                  File.join(dir, cam_dir, File.basename(@test_file, ".rb"))
                end
    begin
      log_info("Making #{media_dir}")
      FileUtils::mkdir_p(media_dir)
    rescue StandardError => e
      log_warn(e.to_s)
      return
    end

    # If it is the very special location /mnt/gopro-share
    # We log it as the windows share so the resultshandler can be all fancy
    # report_dir = ""
    report_dir = if dir.match("/mnt/gopro-share/BAT")
                   "\\\\shares.gopro.lcl\\FWQA_Build_Medias\\#{runtype}\\#{@camera.name}\\#{@camera.build}\\#{datetime}"
                 elsif dir.match("/mnt/gopro-share/INDIVIDUAL")
                   "\\\\shares.gopro.lcl\\FWQA_Build_Medias\\#{runtype}\\#{cam_dir}"
                 elsif dir.match("/mnt/gopro-share")
                   "\\\\shares.gopro.lcl\\FWQA\\automation\\#{cam_dir}"
                 else
                   media_dir
                 end
    log_conf("media_dir, #{report_dir}")

    log_info("Downloading media to #{media_dir}")
    @camera.get_medialist().each { |f|
      url = @camera.get_media_url(f)
      @host.wget(url, media_dir)
    }
    return
  end

end # end module
