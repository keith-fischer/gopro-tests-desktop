#!/usr/bin/env ruby

# gccb_commands.rb

# Module to hold hashes for Hero4 (Pipe and Backdoor) GCCB commands
#
# These are well-formed in the following sense
#
#  - Have :set and :get commands
#

module GCCBCommands
    
  # Plan: 
  #
  #   Use the :get/:set format way below (as Wifi and Serial ifaces do)
  #   BUT reference the pipe_hex_cmds symbols to get the actual command strings
  #   EVEN BETTER: have the :get/:set reference a method that will then reference the pipe_hex_cmds
  #
  # Reference:
  #
  #   Hero4-GCCB-latest_18Aug2015.docx
  #   ~/qa/GCCB/Functionality Matrix_TEMPLATE-Final-Linda-1dec15.xlsx
  #

  ##################################################################
  # GCCB BUS 
  ##################################################################
  def zz_cmds 
    {
      :name       => "ZZ Commands",
      :set        => "ZZ 0 0 %s %s",                     # payload byte1, payload byte2
      :set_resp   => "%s %s 0 0 10 %s %s",               # length, ACK, payload byte1, payload byte2, payload byte3

      :payload_byte1   => {
        "I2C_speed"        => 1,
        "Ready"            => 2,
        "FirmwareVersion"  => 3,
        "ProtocolVersion"  => 4,
        "Capabilities"     => 5,
        "PollingFrequency" => 6,
        "PollingMode"      => 7,
       },
      :payload_byte2   => {
        "Standard "   => 0,
        "Ready"       => 1,
        "BuildVer"    => "%s",  # "HD4.0x.MM.mm.rr"
        "ProtoVer"    => "%s",  # MM, mm, rr
        "Capabilities_1"       => 0,
        "Capabilities_2"       => 0,
       },
      :i2c_speeds   => {
        "Standard"                      => 0, 
        "Fast"                          => 1, 
        "Fast+"                         => 2, 
        "High"                          => 3, 
      },
      :capabilities_1   => {
        "FUTURE_Battery_Support"            => 0x00, # Bit0
        "FUTURE_Charging_Port_Present"      => 0x02, # Bit1
        "FUTURE_Camera_Charging_Support"    => 0x04, # Bit2
        "External_Mic_Support"              => 0x08, # Bit3
        "CVBS_Support"               => 0x10, # Bit4
        "USB_Support"                => 0x20, # Bit5
        "RESERVED6"                         => 0x40, # Bit6
        "RESERVED7"                         => 0x80, # Bit7
      },
      :capabilities_2   => {
        "RESERVED"                          => 0x80, # Bit7
      },
    }
  end


  ##################################################################
  # VIDEO MODE
  ##################################################################

  # Reference:
  #  https://wiki.gopro.com/pages/viewpage.action?pageId=11698363
  def supported_fps_hawaii
    {
      "NTSC" =>  ["15","24","30","48","60","80","90","100","120","240"],
      "PAL" => ["12.5","24","25","48","50","80","90","100","120","240"],
    }
  end
  def supported_video_settings
    {
      "4K" => [
        ["NTSC","30","WIDE","PIPE"],
        ["PAL","25","WIDE","PIPE"],
        ["NTSC","PAL","24","WIDE","PIPE"],
        #["NTSC","15","WIDE","BACKDOOR"],  # missing from GCCB spec
        #["PAL","12.5","WIDE","BACKDOOR"],  # missing from GCCB spec
      ],
      "4K_SUPER" => [
        ["NTSC","PAL","24","WIDE","PIPE"],
      ],
      "2.7K"    => [
        #["NTSC","60","WIDE","MEDIUM","PIPE"],       # missing from GCCB spec
        #["PAL","50","WIDE","MEDIUM","PIPE"],        # missing from GCCB spec
        #["NTSC","PAL","48","WIDE","MEDIUM","PIPE","BACKDOOR"],      # missing from GCCB spec
        ["NTSC","30","WIDE","MEDIUM","PIPE","BACKDOOR"],
        ["PAL","25","WIDE","MEDIUM","PIPE","BACKDOOR"],
        ["NTSC","PAL","24","WIDE","MEDIUM","PIPE","BACKDOOR"],
      ],
      #"2.7K_SUPER" => [     # ENTIRE format is missing from GCCB spec
        #["NTSC","30","WIDE","PIPE"],
        #["PAL","25","WIDE","PIPE"],
      #],
      "2.7K_FS" => [     # ENTIRE format is missing from GCCB spec
        ["NTSC","30","WIDE","PIPE"],
        ["PAL","25","WIDE","PIPE"],
      ],
      "1440"    => [
        #["NTSC","PAL","80","WIDE","PIPE""],             # missing from GCCB spec
        #["NTSC","60","WIDE","PIPE"],                # missing from GCCB spec
        #["PAL","50","WIDE","PIPE"],             # missing from GCCB spec
        ["NTSC","PAL","48","WIDE","PIPE","BACKDOOR"],
        ["NTSC","30","WIDE","PIPE","BACKDOOR"],
        ["PAL","25","WIDE","PIPE","BACKDOOR"],
        ["NTSC","PAL","24","WIDE","PIPE","BACKDOOR"],
      ],
      "1080"    => [
        #["NTSC","PAL","120","WIDE","NARROW","PIPE"],                # missing from GCCB spec
        #["NTSC","PAL","90","WIDE","NARROW","PIPE"],             # missing from GCCB spec
        ["NTSC","60","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["PAL","50","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["NTSC","PAL","48","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["NTSC","30","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["PAL","25","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["NTSC","PAL","24","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
      ],
      "1080_SUPER"    => [
        #["NTSC","PAL","80","WIDE","PIPE"],  # GCCB spec is WRONG, missing for PIPE
        ["NTSC","60","WIDE","PIPE","BACKDOOR"],
        ["PAL","50","WIDE","PIPE","BACKDOOR"],
        ["NTSC","PAL","48","WIDE","PIPE","BACKDOOR"],
        ["NTSC","30","WIDE","PIPE","BACKDOOR"],
        ["PAL","25","WIDE","PIPE","BACKDOOR"],
        ["NTSC","PAL","24","WIDE","PIPE","BACKDOOR"],
      ],
      "960"    => [
        #["NTSC","PAL","120","WIDE","NARROW","PIPE"],  # GCCB spec is WRONG, missing for PIPE
        ["NTSC","PAL","100","WIDE","BACKDOOR"],
        ["NTSC","60","WIDE","PIPE","BACKDOOR"],
        ["PAL","50","WIDE","PIPE","BACKDOOR"],
      ],
      "720"    => [
        #["NTSC","PAL","240","NARROW","PIPE"],  # GCCB spec is WRONG, missing for PIPE
        ["NTSC","PAL","120","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["NTSC","60","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["PAL","50","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["NTSC","30","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
        ["PAL","25","WIDE","MEDIUM","NARROW","PIPE","BACKDOOR"],
      ],
      "720_SUPER"    => [
        ["NTSC","PAL","120","WIDE","PIPE"],     # The GCCB spec is WRONG for PIPE, does not mention 120FPS at all
        ["NTSC","PAL","100","WIDE","BACKDOOR"],
        ["NTSC","60","WIDE","PIPE","BACKDOOR"],
        [ "PAL","50","WIDE","PIPE","BACKDOOR"],
      ],
      "WVGA"    => [
        ["NTSC","PAL","240","WIDE","PIPE","BACKDOOR"],
      ],
    }
  end

  def video_cmds  # These command formats are used for all 3 video settings (res,fps,fov)
    {
      :name       => "video_cmds",
      :set        => "YY 0 0 %s 2 3 0 3 %s %s %s",         # chan_id, RESOLUTION, FPS, FOV
      :set_resp   => "A %s 0 0 10 %s 2 3 %s 0 0",          # ack, chan_id, error
      :get        => "YY 0 0 %s 2 2 0 0",                  # chan_id
      :get_resp   => "D %s 0 0 10 %s 2 2 %s 0 3 %s %s %s", # ack, chan_id, error, RESOLUTION, FPS, FOV
      # Used to extract params
      #:get_regx   => /^D (\d+) 0 0 10 (\d+) 2 2 (\d+) 0 3 (\d+) (\d+) (\d+$)/,  
      :get_regx   => /^D (\w+) 0 0 10 (\w+) 2 2 (\w+) 0 3 (\w+) (\w+) (\w+$)/, # ack, chan_id, error, RESOLUTION, FPS, FOV

    }
  end
  def vid_res_cmds
    {
      :name       => "video_res_cmds",
      :set        => video_cmds[:set],
      :set_resp   => video_cmds[:set_resp],
      :get        => video_cmds[:get],
      :get_resp   => video_cmds[:get_resp],
      :settings   => {                                     # invert this to get ":gettings"
        "4K_CIN"      => 0x00, # 4K 16:9
        "4K"          => 0x01,
        "4K_SUPER"    => 0x02,
        "2.7K_CIN"    => 0x03, # 2.7K 16:9
        "2.7K"        => 0x04,
        "2.7K_SUPER"  => 0x05,
        "2.7K_FS"     => 0x06, # 2.7K 4:3 (FS==Fullscreen)
        "1440"        => 0x07,
        "1080_SUPER"  => 0x08,
        "1080"        => 0x09,
        "960"         => 0x0A,
        "720_SUPER"   => 0x0B,
        "720"         => 0x0C,
        "WVGA"        => 0x0D,
      }
    }
  end
  def vid_fps_cmds
    {
      :name       => "video_fps_cmds",
      :set        => video_cmds[:set],
      :set_resp   => video_cmds[:set_resp],
      :get        => video_cmds[:get],
      :get_resp   => video_cmds[:get_resp],
      :settings   => {                                     # invert this to get ":gettings"
        "240"     => 0x00,
        "120"     => 0x01,
        "100"     => 0x02,
        "90"      => 0x03,
        "80"      => 0x04,
        "60"      => 0x05,
        "50"      => 0x06,
        "48"      => 0x07,
        "30"      => 0x08,
        "25"      => 0x09,
        "24"      => 0x0A,
        "14"      => 0x0B,
        "12.5"    => 0x0C,
      }
    }
  end
  def vid_fov_cmds
    {
      :name       => "video_fov_cmds",
      :set        => video_cmds[:set],
      :set_resp   => video_cmds[:set_resp],
      :get        => video_cmds[:get],
      :get_resp   => video_cmds[:get_resp],
      :settings   => {                                     # invert this to get ":gettings"
        "WIDE"    => 0x00, # W
        "MEDIUM"  => 0x01, # M
        "NARROW"  => 0x02, # N
      }
    }
  end

  def start_video_trigger_cmds
    {
      :name       => "start video trigger_shutter_cmds",
      :set        => "YY 0 0 %s 2 1B 0 0",             # chan_id
      :set_resp   => "A %s 0 0 10 %s 2 1B %s 0 0",     # ack, chan_id, error
    }
  end

  def stop_video_trigger_cmds
    {
      :name       => "stop video trigger_shutter_cmds",
      :set        => "YY 0 0 %s 2 1C 0 0",             # chan_id
      :set_resp   => "A %s 0 0 10 %s 2 1C %s 0 0",     # ack, chan_id, error
    }
  end

  def start_photo_trigger_cmds 
    {
      :name       => "start photo trigger_shutter_cmds",
      :set        => "YY 0 0 %s 3 17 0 0",             # chan_id
      :set_resp   => "A %s 0 0 10 %s 3 17 %s 0 0",     # ack, chan_id, error
    }
  end

  def stop_photo_trigger_cmds 
    {
      :name       => "stop photo trigger_shutter_cmds",
      :set        => "YY 0 0 %s 3 18 0 0",             # chan_id
      :set_resp   => "A %s 0 0 10 %s 3 18 %s 0 0",     # ack, chan_id, error
    }
  end

  def start_multi_trigger_cmds 
    {
      :name       => "start multi trigger_shutter_cmds",
      :set        => "YY 0 0 %s 4 1B 0 0",        # chan_id
      :set_resp   => "A %s 0 0 10 %s 4 1B %s 0 0",     # ack, chan_id, error
    }
  end

  def stop_multi_trigger_cmds 
    {
      :name       => "stop multi trigger_shutter_cmds",
      :set        => "YY 0 0 %s 4 1C 0 0",             # chan_id
      :set_resp   => "A %s 0 0 10 %s 4 1C %s 0 0",     # ack, chan_id, error
    }
  end

  def mode_cmds
    {
      :name       => "camera mode cmds",
      #:set       => "YY 0 0 %{ch} 1 1 0 1 %{mode}", # experimental
      #:get       => "YY 0 0 %{ch} 1 0 0 0",         # experimental

      :set        => "YY 0 0 %s 1 1 0 1 %s",         # chan_id, mode
      :set_resp   => "A %s 0 0 10 %s 1 1 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 1 0 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 1 0 %s 0 1 %s", # ack, chan_id, error, camera mode value
      :settings   => {                               # invert this to get ":gettings"
        "VIDEO"             => 0x00,
        "PHOTO"             => 0x01,
        "MULTI_SHOT"        => 0x02,
        "BROADCAST"         => 0x03, # WIFI - not implemented yet
        "PLAYBACK"          => 0x04, # Apparently this is NOT a valid mode
        "SETTINGS"          => 0x05,
      },
      :submodes   => {                               # invert this to get ":gettings"
        "VIDEO"             => video_sub_mode_cmds,       # pointer to submode hash
        "PHOTO"             => photo_sub_mode_cmds,       # pointer to submode hash
        "MULTI_SHOT"        => multi_sub_mode_cmds,
        "PLAYBACK"          => nil,
        "BROADCAST"         => nil,
        "SETTINGS"          => nil,
      }
    }
  end

  def gccb_error_codes 
    {
      "0" => "OK",
      "FC" => "Invalid command",
    }
  end
  
  # GCCB command formats for setting/getting the submodes for VIDEO, PHOTO, MULTI_SHOT
  def submode_cmds()
    {
      :name       => "submode_cmds",
      :set      => "YY 0 0 %s 1 3 0 1 %s",         # SET COMMAND  FORMAT: channel_id, submode
      :set_resp => "A %s 0 0 10 %s 1 3 %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 1 2 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 1 2 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, submode
    }
  end

  # These command formats apply to all 3 modes (VIDEO, PHOTO, MULTI_SHOT)
  def default_submode_get_cmds
    {
      :get      => "YY 0 0 %s 1 2 0 1",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 1 2 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, submode
    }
  end

  def video_sub_mode_cmds
    {
      :name     => "video_sub_mode_cmds",
      :set      => submode_cmds[:set],
      :set_resp => submode_cmds[:set_resp],
      :get      => submode_cmds[:get],
      :get_resp => submode_cmds[:get_resp],
      :settings => {                               # invert this to get ":gettings"
        "VIDEO"      => 0x00,  # set & get values
        "TIME_LAPSE" => 0x01,  # set & get values
        "PIV"        => 0x02,  # set & get values
        "LOOPING"    => 0x03,  # set & get values
      }
    }
  end
  
  def video_def_sub_mode_cmds
    {
      :name       => "default video sub mode",
      :set      => "YY 0 0 %s 2 1 0 1 %s",         # channel_id, video submode
      :set_resp => "A %s 0 0 10 %s 2 1 %s 0 0",    # ack, chan_id, error
      :get      => "YY 0 0 %s 2 0 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 2 0 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, submode
      #:get      => default_submode_get_cmds[:get],
      #:get_resp => default_submode_get_cmds[:get_resp],
      :settings => {                               # invert this to get ":gettings"
        "VIDEO"      => 0x00,  # set & get values
        "TIME_LAPSE" => 0x01,  # set & get values
        "PIV"        => 0x02,  # set & get values
        "LOOPING"    => 0x03,  # set & get values
      }
    }
  end
  
  # Photo in video
  def video_piv_interval_cmds
    {
      :name       => "video_piv_interval_cmds",
      :set        => "YY 0 0 %s 2 5 0 1 %s",         # chan_id, <video piv interval index>
      :set_resp   => "A %s 0 0 10 %s 2 5 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 4 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 4 %s 0 1 %s", # ack, chan_id, error, <video piv interval index>
      :settings   => {                               # invert this to get ":gettings"
        "OFF" => 0x00,
        "5"   => 0x01,
        "10"  => 0x02,
        "30"  => 0x03,
        "60"  => 0x04,
      },
    }
  end

  def video_looping_cmds
    {
      :name       => "video_looping_cmds",
      :set        => "YY 0 0 %s 2 7 0 1 %s",         # chan_id, <video looping time>
      :set_resp   => "A %s 0 0 10 %s 2 7 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 6 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 6 %s 0 1 %s", # ack, chan_id, error, <video looping time>
      :settings   => {                               # invert this to get ":gettings"
        "MAX"           => 0x00,
        "5"             => 0x01,
        "20"            => 0x02,
        "60"            => 0x03,
        "120"           => 0x04,
      },
  }
  end

  # def video_timelapse_rate_cmds ### See video_timelapse_interval_cmds (below)
  def video_timelapse_interval_cmds
    {
      :name       => "video_timelapse_interval_cmds",
      :set        => "YY 0 0 %s 2 D 0 1 %s",         # chan_id, <time lapse rate>
      :set_resp   => "A %s 0 0 10 %s 2 D %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 C 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 C %s 0 1 %s", # ack, chan_id, error, <time lapse rate>
      :settings   => {                               # invert this to get ":gettings"
        "0.5"          => 0x00,
        "1"            => 0x01,
        "2"            => 0x02,
        "5"            => 0x03,
        "10"           => 0x04,
        "30"           => 0x05,
        "60"           => 0x06,
      },
    }
  end
  
  
  def video_lowlight_cmds
    {
      :name       => "video_lowlight_cmds",
      :set        => "YY 0 0 %s 2 9 0 1 %s",         # chan_id, <low-light 1=ON/0=OFF>
      :set_resp   => "A %s 0 0 10 %s 2 9 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 8 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 8 %s 0 1 %s", # ack, chan_id, error, <low-light 1=ON/0=OFF>
      :settings   => {                               # invert this to get ":gettings"
        "OFF"            => 0x00,
        "ON"             => 0x01,
      },
    }
  end
    
  ### NEW as of 13nov15
  def video_spotmeter_cmds
    {
      :name       => "video_spotmeter_cmds",
      :set        => "YY 0 0 %s 2 D 0 1 %s",        # chan_id, <0:OFF 1:ON>
      :set_resp   => "A %s 0 0 10 %s 2 D %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 C 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 C %s 0 1 %s", # ack, chan_id, error, <low-light 1=ON/0=OFF>
      :settings   => {                               # invert this to get ":gettings"
      "OFF"   => 0x00,
      "ON"    => 0x01,
      },
    }
  end
  
  def video_protune_cmds
    {
      :name       => "video_protune_cmds",
      :set        => "YY 0 0 %s 2 F 0 1 %s",         # chan_id, PROTUNE_TRUE(0|1)
      :set_resp   => "A %s 0 0 10 %s 2 F %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 E 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 E %s 0 1 %s", # ack, chan_id, error, PROTUNE_TRUE(0|1)
      :settings   => {                               # invert this to get ":gettings"
        "OFF"            => 0x00,
        "ON"             => 0x01,
      },
    }
  end
  
  # For compatibility
  def protune_cmds
    video_protune
  end
  
  # 1dec15
  def video_protune_whitebalance_cmds
    {
      :name       => "video_protune_whitebalance_cmds",
      :set        => "YY 0 0 %s 2 11 0 1 %s",         # chan_id, whitebalance setting
      :set_resp   => "A %s 0 0 10 %s 2 11 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 10 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 10 %s 0 1 %s", # ack, chan_id, error, whitebalance setting
      :settings   => {                               # invert this to get ":gettings"
        "AUTO"  => 0x00,
        "3000K" => 0x01,
        "5500K" => 0x02,
        "6500K" => 0x03,
        "RAW"   => 0x04, # "native"
        "native"=> 0x04, # "native"
      },
    }
  end

  ### 1dec15
  def video_protune_color_cmds
    {
      :name       => "video_protune_color_cmds",
      :set        => "YY 0 0 %s 2 13 0 1 %s",         # chan_id, protune color index
      :set_resp   => "A %s 0 0 10 %s 2 13 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 12 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 12 %s 0 1 %s", # ack, chan_id, error, protune color index
      :settings   => {                               # invert this to get ":gettings"
      "STANDARD"    => 0x00,
      "NEUTRAL"     => 0x01,
      "gopro_color" => 0x00, # STANDARD
      "flat"        => 0x01, # NEUTRAL
      },
    }
  end
  
  # 1dec15
  def video_protune_iso_cmds
    {
      :name       => "video_protune_iso_cmds",
      :set        => "YY 0 0 %s 2 17 0 1 %s",         # chan_id, ISO index
      :set_resp   => "A %s 0 0 10 %s 2 17 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 16 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 16 %s 0 1 %s", # ack, chan_id, error, ISO index
      :settings   => {                               # invert this to get ":gettings"
        6400    => 0x00,
        1600    => 0x01,
        400     => 0x02,
      },
    }
  end
  
  # 1dec15
  def video_protune_sharpness_cmds
    {
      :name       => "video_protune_sharpness_cmds",
      :set        => "YY 0 0 %s 2 15 0 1 %s",         # chan_id, sharpness index
      :set_resp   => "A %s 0 0 10 %s 2 15 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 14 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 14 %s 0 1 %s", # ack, chan_id, error, sharpness index
      :settings   => {                               # invert this to get ":gettings"
      "HIGH"  => 0x00,
      "MED"   => 0x01,
      "LOW"   => 0x02,
      },
    }
  end
  
  # TODO: compare this to Hawaii spec
  def video_protune_exposure_cmds
    {
      :name       => "video_protune_exposure_cmds",
      :set        => "YY 0 0 %s 2 19 0 1 %s",         # chan_id, EXPOSURE_LEVEL
      :set_resp   => "A %s 0 0 10 %s 2 19 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 18 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 18 %s 0 1 %s", # ack, chan_id, error, PROTUNE_TRUE(0|1)
      :settings   => {                               # invert this to get ":gettings"
        "+2"            => 0x00,
        "+1.5"          => 0x01,
        "+1"            => 0x02,
        "+0.5"          => 0x03,
        "+0"            => 0x04,
        "-0.5"          => 0x05,
        "-1"            => 0x06,
        "-1.5"          => 0x07,
        "-2"            => 0x08,
      },
    }
  end

  # 2dec15
  def video_progress_counter_cmd
    {
      # example CMD OUT: 2 1E 0 0 4 0 0 1 2  
      # example RSP  IN: E 0 0 0 10 A7 2 1E 0 0 4 0 0 1 8  
      #
      :name       => "video_progress_counter_cmd",
      :get        => "YY 0 0 %s 2 1E 0 0",            # chan_id
      :get_resp   => "E %s 0 0 10 %s 2 1E %s 0 4 %s %s %s %s", # ack, chan_id, error, progress counter (4 digits?)

    }
  end
  
  # 2dec15
  def video_get_all_settings_cmd
    {
      # example CMD OUT: 
      # example RSP  IN: 
      #
      :name       => "video_get_all_settings_cmd",
      :get        => "YY 0 0 %s 2 1D 0 0",            # chan_id
      :get_resp   => "22 %s 0 0 10 %s 2 1D %s 0 18 0 %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", # ack, chan_id, error, <all (18) video settings>

    }
  end

  # 2dec15
  def video_get_all_resolutions_cmd
    {
      # example CMD OUT: 
      # example RSP  IN: 
      #
      :name       => "video_get_all_resolutions_cmd",
      :set        => "YY 0 0 %s 2 22 0 1 %s",          # chan_id, <filter>
      :set_resp   => "13 %s 0 0 10 %s 2 22 %s %s %s",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 22 0 1 %s",          # chan_id
      :get_resp   => "%s %s 0 0 10 %s 2 22 %s 0 %s %s %s %s %s %s %s %s %s %s",  # expected_len, ack, chan_id, error, length, <all video resolutions>
      :settings => {
        "ALL"       => 0x00,
        "PIV"       => 0x01,
        "LOWLIGHT"  => 0x02,
        "PROTUNE"   => 0x04,
        "TIMELAPSE" => 0x08,
      },
      :expected_lengths => {
        "ALL"       => 0x13,
        "PIV"       => 0x0D,
        "LOWLIGHT"  => 0x10,
        "PROTUNE"   => 0x13,
        "TIMELAPSE" => 0x0C,
      },
      :all_res      => vid_res_cmds[:settings],
    }
  end

  # 3dec15
  def video_get_all_fps_cmd
    {
      # example CMD OUT: 
      # example RSP  IN: 
      #
      :name       => "video_get_all_fps_cmd",
      :get        => "YY 0 0 %s 2 23 0 3 %s %s %s",          # chan_id <filter> <video format> <video res>
      :get_resp   => "%s %s 0 0 10 %s 2 23 %s 0 %s %s %s %s %s %s %s %s %s %s",  # expected_len, ack, chan_id, error, length, <all video fps>
      :filters => {
        "ALL"       => 0x00,
        "PIV"       => 0x01,
        "LOWLIGHT"  => 0x02,
        "PROTUNE"   => 0x04,
        "TIMELAPSE" => 0x08,
      },
      :all_fps      => vid_fps_cmds[:settings],
    }
  end

  # 3dec15
  def video_get_all_fov_cmd
    {
      # example CMD OUT: 
      # example RSP  IN: 
      #
      :name       => "video_get_all_fov_cmd",
      :get        => "YY 0 0 %s 2 24 0 4 %s %s %s %s",          # chan_id <filter> <video format> <video res> <video fps>
      :get_resp   => "%s %s 0 0 10 %s 2 24 %s 0 %s %s %s %s %s",  # expected_len, ack, chan_id, error, length, <res> <all video fovs>
        # INFO : GET response: E 0 0 0 10 EB 2 24 0 0 4 8 0 1 2 
      :filters => {
        "ALL"       => 0x00,
        "PIV"       => 0x01,
        "LOWLIGHT"  => 0x02,
        "PROTUNE"   => 0x04,
        "TIMELAPSE" => 0x08,
      },
      :all_fov      => vid_fov_cmds[:settings],
    }
  end

  # 3dec15
  def video_get_all_capabilities_cmd
    {
      # example CMD OUT: 
      # example RSP  IN: 
      #
      :name       => "video_get_all_capabilities_cmd",
      :get        => "YY 0 0 %s 2 25 0 5 %s %s %s %s %s",          # chan_id <filter> <video format> <res> <fps> <fov>
      :get_resp   => "%s %s 0 0 10 %s 2 25 %s 0 %s %s",  # expected_len, ack, chan_id, error, length, <true|false capability exists>
        # Example:
        # get_video_all_capabilities(ALL, NTSC, 1080, 30, WIDE)
        # GCCB command: YY 0 0 2B 2 25 0 5 0 0 9 8 0
        # GET response: B 0 0 0 10 43 2 25 0 0 1 1
      :filters => {
        "ALL"       => 0x00,
        "PIV"       => 0x01,
        "LOWLIGHT"  => 0x02,
        "PROTUNE"   => 0x04,
        "TIMELAPSE" => 0x08,
      },
      # :all_fov      => vid_fov_cmds[:settings],
    }
  end

  
  
  ##################################################################
  # PHOTO MODE
  ##################################################################
  def photo_sub_mode_cmds
    {
      :name       => "photo sub mode",
      :set      => submode_cmds[:set],
      :set_resp => submode_cmds[:set_resp],
      :get      => submode_cmds[:get],
      :get_resp => submode_cmds[:get_resp],
      :settings => {                               # invert this to get ":gettings"
        "SINGLE"     => 0x00,  # set & get values
        "CONTINUOUS" => 0x01,  # set & get values
        "NIGHT"      => 0x02,  # set & get values
      }
    }
  end
  
  def photo_def_sub_mode_cmds
    {
      :name       => "default photo sub mode",
      :set      => "YY 0 0 %s 3 1 0 1 %s",         # channel_id, photo submode
      :set_resp => "A %s 0 0 10 %s 3 1 %s 0 0",    # ack, chan_id, error
      :get      => "YY 0 0 %s 3 0 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 3 0 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, submode
      #:get      => default_submode_get_cmds[:get],
      #:get_resp => default_submode_get_cmds[:get_resp],
      :settings => {                               # invert this to get ":gettings"
        "SINGLE"     => 0x00,  # set & get values
        "CONTINUOUS" => 0x01,  # set & get values
        "NIGHT"      => 0x02,  # set & get values
      }
    }
  end
  
  def photo_res_cmds
    {
      :name       => "photo resolution commands",
      :set        => "YY 0 0 %s 3 3 0 1 %s",         # chan_id, <PHOTO RES>
      :set_resp   => "A %s 0 0 10 %s 3 3 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 2 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 2 %s 0 1 %s", # ack, chan_id, error, <PHOTO RES>
      :settings   => {                                     # invert this to get ":gettings"
        "12WIDE"  => 0x00,
        "7WIDE"   => 0x01,
        "7MED"    => 0x02,
        "5MED"    => 0x03,
      }
    }
  end
  
  def photo_sps_cmds
    {
      :name       => "photo sps (continous rate) commands",
      :set        => "YY 0 0 %s 3 5 0 1 %s",         # chan_id, <SHUTTER_RATE>
      :set_resp   => "A %s 0 0 10 %s 3 5 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 4 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 4 %s 0 1 %s", # ack, chan_id, error, <SHUTTER_RATE>
      :settings   => {                                     # invert this to get ":gettings"
        "3"  => 0x00,
        "5"  => 0x01,
        "10" => 0x02,
      },
    }
  end
  
  # 12.4.15
  def photo_get_all_settings_cmd
    {
      :name       => "photo_get_all_settings_cmd",
      :get        => "YY 0 0 %s 3 19 0 0",            # chan_id
      :get_resp   => "1E %s 0 0 10 %s 3 19 %s 0 14 %s %s %s %s %s %s %s %s %s %s %s %s %s %s", # ack, chan_id, error, <all (14) photo settings>
    }
  end

  # 12.4.15
  def photo_exp_cmds
    {
      :name       => "photo_exp_cmds",
      :set        => "YY 0 0 %s 3 9 0 1 %s",         # chan_id, <exposure time>
      :set_resp   => "A %s 0 0 10 %s 3 9 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 8 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 8 %s 0 1 %s", # ack, chan_id, error, <exposure time>
      :settings   => {
        "AUTO"     => 0x00,
        2          => 0x01,
        5          => 0x02,
        10         => 0x03,
        15         => 0x04,
        20         => 0x05,
        30         => 0x06,
      },
    }
  end
  
  # 12.4.15
  def photo_protune_reset_cmd
    {
      :name       => "photo_protune_reset_cmd",
      :set        => "YY 0 0 %s 3 16 0 0",        # chan_id
      :set_resp   => "A %s 0 0 10 %s 3 16 %s 0 0",    # ack, chan_id, error
    }
  end
  
  # 12.4.15
  def photo_spotmeter_cmds
    {
      :name       => "photo_spotmeter_cmds",
      :set        => "YY 0 0 %s 3 7 0 1 %s",        # chan_id, <0:OFF 1:ON>
      :set_resp   => "A %s 0 0 10 %s 3 7 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 6 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 6 %s 0 1 %s", # ack, chan_id, error, <1=ON/0=OFF>
      :settings   => {
      "OFF"   => 0x00,
      "ON"    => 0x01,
      },
    }
  end
  
  def photo_protune_cmds
    {
      :name       => "photo_protune_cmds",
      :set        => "YY 0 0 %s 3 B 0 1 %s",         # chan_id, PROTUNE_TRUE(0|1)
      :set_resp   => "A %s 0 0 10 %s 3 B %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 A 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 A %s 0 1 %s", # ack, chan_id, error, PROTUNE_TRUE(0|1)
      :settings   => {                               # invert this to get ":gettings"
        "OFF"            => 0x00,
        "ON"             => 0x01,
      },
    }
  end
  
  # 4dec15
  def photo_white_balance_cmds
    {
      :name       => "photo_whitebalance_cmds",
      :set        => "YY 0 0 %s 3 D 0 1 %s",         # chan_id, whitebalance setting
      :set_resp   => "A %s 0 0 10 %s 3 D %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 C 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 C %s 0 1 %s", # ack, chan_id, error, whitebalance setting
      :settings   => {
        "AUTO"  => 0x00,
        "3000K" => 0x01,
        "5500K" => 0x02,
        "6500K" => 0x03,
        "RAW"   => 0x04, # "native"
        "native"=> 0x04, # "native"
      },
    }
  end

  # 7dec15
  def photo_color_cmds
    {
      :name       => "photo_color_cmds",
      :set        => "YY 0 0 %s 3 F 0 1 %s",         # chan_id, protune color index
      :set_resp   => "A %s 0 0 10 %s 3 F %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 E 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 E %s 0 1 %s", # ack, chan_id, error, protune color index
      :settings   => {                               # invert this to get ":gettings"
      "STANDARD"    => 0x00,
      "NEUTRAL"     => 0x01,
      "gopro_color" => 0x00, # STANDARD
      "flat"        => 0x01, # NEUTRAL
      },
    }
  end
  
  # 4dec15
  def photo_iso_cmds
    {
      :name       => "photo_iso_cmds",
      :set        => "YY 0 0 %s 3 13 0 1 %s",         # chan_id, ISO index
      :set_resp   => "A %s 0 0 10 %s 3 13 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 12 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 12 %s 0 1 %s", # ack, chan_id, error, ISO index
      :settings   => {
        800    => 0x00,
        400    => 0x01,
        200    => 0x02,
        100    => 0x03,
      },
    }
  end
  
  # 1dec15
  def photo_sharpness_cmds
    {
      :name       => "photo_sharpness_cmds",
      :set        => "YY 0 0 %s 3 11 0 1 %s",       # chan_id, sharpness index
      :set_resp   => "A %s 0 0 10 %s 3 11 %s 0 0",  # ack, chan_id, error
      :get        => "YY 0 0 %s 3 10 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 10 %s 0 1 %s", # ack, chan_id, error, sharpness index
      :settings   => {                              # invert this to get ":gettings"
      "HIGH"  => 0x00,
      "MED"   => 0x01,
      "LOW"   => 0x02,
      },
    }
  end
  
  # 
  def photo_protune_exposure_cmds
    {
      :name       => "photo_protune_exposure_cmds",
      :set        => "YY 0 0 %s 3 15 0 1 %s",         # chan_id, EXPOSURE_LEVEL
      :set_resp   => "A %s 0 0 10 %s 3 15 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 14 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 14 %s 0 1 %s", # ack, chan_id, error, EXPOSURE_LEVEL
      :settings   => {                               # invert this to get ":gettings"
        "+2"            => 0x00,
        "+1.5"          => 0x01,
        "+1"            => 0x02,
        "+0.5"          => 0x03,
        "+0"            => 0x04,
        "-0.5"          => 0x05,
        "-1"            => 0x06,
        "-1.5"          => 0x07,
        "-2"            => 0x08,
      },
    }
  end
  
  def photo_capture_cmds
    {
      :set          => "t api photo",
      "START"       => "capture_start",
      "STOP"        => "capture_stop",
    }
  end
  
  ##################################################################
  # MULTI-SHOT
  ##################################################################
  def multi_sub_mode_cmds
    {
      :name       => "multishot sub mode",
      :set      => submode_cmds[:set],
      :set_resp => submode_cmds[:set_resp],
      :get      => submode_cmds[:get],
      :get_resp => submode_cmds[:get_resp],
      :settings => {                               # invert this to get ":gettings"
        "BURST"       => 0x00,  # set & get values
        "TIME_LAPSE"  => 0x01,  # set & get values
        "NIGHT_LAPSE" => 0x02,  # set & get values
      }
    }
  end
  
  def multi_def_sub_mode_cmds
    {
      :name       => "default multishot sub mode",
      :set      => "YY 0 0 %s 4 1 0 1 %s",         # channel_id, multi_shot submode
      :set_resp => "A %s 0 0 10 %s 4 1 %s 0 0",    # ack, chan_id, error
      :get      => "YY 0 0 %s 4 0 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 4 0 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, submode
      #:get      => default_submode_get_cmds[:get],
      #:get_resp => default_submode_get_cmds[:get_resp],
      :settings => {                               # invert this to get ":gettings"
        "BURST"       => 0x00,  # set & get values
        "TIME_LAPSE"  => 0x01,  # set & get values
        "NIGHT_LAPSE" => 0x02,  # set & get values
      }
    }
  end

  # 7dec15
  def multi_res_cmds
    {
      :name       => "multi_resolution commands",
      :set        => "YY 0 0 %s 4 3 0 1 %s",         # chan_id, <MULTI RES>
      :set_resp   => "A %s 0 0 10 %s 4 3 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 2 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 2 %s 0 1 %s", # ack, chan_id, error, <MULTI RES>
      :settings   => {
        "12WIDE"  => 0x00,
        "7WIDE"   => 0x01,
        "7MED"    => 0x02,
        "5MED"    => 0x03,
      }
    }
  end
  
  def multi_burst_cmds
    {
      :name       => "multi_burst_cmds",
      :set        => "YY 0 0 %s 4 5 0 1 %s",         # chan_id, <time lapse rate>
      :set_resp   => "A %s 0 0 10 %s 4 5 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 4 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 4 %s 0 1 %s", # ack, chan_id, error, <time lapse rate>
      :settings   => {                               # invert this to get ":gettings"
        "3_1"   => 0x00,
        "5_1"   => 0x01,
        "10_1"  => 0x02,
        "10_2"  => 0x03,
        "10_3"  => 0x04,
        "30_1"  => 0x05,
        "30_2"  => 0x06,
        "30_3"  => 0x07,
        "30_6"  => 0x08,
      },
    }
  end
  
  def multi_timelapse_interval_cmds
    {
      :name       => "multi_timelapse_interval_cmds",
      :set        => "YY 0 0 %s 4 7 0 1 %s",         # chan_id, <time lapse rate>
      :set_resp   => "A %s 0 0 10 %s 4 7 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 6 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 6 %s 0 1 %s", # ack, chan_id, error, <time lapse rate>
      :settings   => {                               # invert this to get ":gettings"
        "0.5"          => 0x00,
        "1"            => 0x01,
        "2"            => 0x02,
        "5"            => 0x03,
        "10"           => 0x04,
        "30"           => 0x05,
        "60"           => 0x06,
      },
    }
  end
  
  # 7dec15, 21mar16
  def multi_nightlapse_cmds
    {
      :name       => "multi_night_lapse_cmds",
      :set        => "YY 0 0 %s 4 9 0 1 %s",         # chan_id, <night lapse rate>
      :set_resp   => "A %s 0 0 10 %s 4 9 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 8 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 8 %s 0 1 %s", # ack, chan_id, error, <night lapse rate>
      :settings   => {

      "10s"        => "0",
      "15s"        => "1",
      "20s"        => "2",
      "30s"        => "3",
      "60s"        => "4",
      "2min"       => "5",
      "5min"       => "6",
      "30min"      => "7",
      "60min"      => "8",
      "CONTINUOUS" => "9",
      "4s"         => "A",
      "5s"         => "B",
      },
    }
  end
  
  # 7dec15
  def multi_spotmeter_cmds
    {
      :name       => "multi_spotmeter_cmds",
      :set        => "YY 0 0 %s 3 B 0 1 %s",         # chan_id, <0:OFF 1:ON>
      :set_resp   => "A %s 0 0 10 %s 3 B %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 3 A 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 3 A %s 0 1 %s", # ack, chan_id, error, <1=ON/0=OFF>
      :settings   => {
      "OFF"   => 0x00,
      "ON"    => 0x01,
      },
    }
  end
  
  def multi_protune_cmds
    {
      :name       => "multi_protune_cmds",
      :set        => "YY 0 0 %s 4 F 0 1 %s",         # chan_id, PROTUNE_TRUE(0|1)
      :set_resp   => "A %s 0 0 10 %s 4 F %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 E 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 E %s 0 1 %s", # ack, chan_id, error, PROTUNE_TRUE(0|1)
      :settings   => {                               # invert this to get ":gettings"
        "OFF"            => 0x00,
        "ON"             => 0x01,
      },
    }
  end
  
  # 7dec15
  def multi_exp_cmds
    {
      :name       => "multi_exp_cmds",
      :set        => "YY 0 0 %s 4 D 0 1 %s",         # chan_id, <exposure time>
      :set_resp   => "A %s 0 0 10 %s 4 D %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 C 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 C %s 0 1 %s", # ack, chan_id, error, <exposure time>
      :settings   => {
        "AUTO"     => 0x00,
        2          => 0x01,
        5          => 0x02,
        10         => 0x03,
        15         => 0x04,
        20         => 0x05,
        30         => 0x06,
      },
    }
  end

  # 7dec15
  def multi_white_balance_cmds
    {
      :name       => "multi_whitebalance_cmds",
      :set        => "YY 0 0 %s 4 11 0 1 %s",         # chan_id, whitebalance setting
      :set_resp   => "A %s 0 0 10 %s 4 11 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 10 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 10 %s 0 1 %s", # ack, chan_id, error, whitebalance setting
      :settings   => {
        "AUTO"  => 0x00,
        "3000K" => 0x01,
        "5500K" => 0x02,
        "6500K" => 0x03,
        "RAW"   => 0x04, # "native"
        "native"=> 0x04, # "native"
      },
    }
  end

  # 7dec15
  def multi_color_cmds
    {
      :name       => "multi_color_cmds",
      :set        => "YY 0 0 %s 4 13 0 1 %s",         # chan_id, protune color index
      :set_resp   => "A %s 0 0 10 %s 4 13 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 12 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 12 %s 0 1 %s", # ack, chan_id, error, protune color index
      :settings   => {                               # invert this to get ":gettings"
      "STANDARD"    => 0x00,
      "NEUTRAL"     => 0x01,
      "gopro_color" => 0x00, # STANDARD
      "flat"        => 0x01, # NEUTRAL
      },
    }
  end
  
  # 7dec15
  def multi_iso_cmds
    {
      :name       => "multi_iso_cmds",
      :set        => "YY 0 0 %s 4 17 0 1 %s",         # chan_id, ISO index
      :set_resp   => "A %s 0 0 10 %s 4 17 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 16 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 16 %s 0 1 %s", # ack, chan_id, error, ISO index
      :settings   => {
        800    => 0x00,
        400    => 0x01,
        200    => 0x02,
        100    => 0x03,
      },
    }
  end
  
  # 7dec15
  def multi_sharpness_cmds
    {
      :name       => "multi_sharpness_cmds",
      :set        => "YY 0 0 %s 4 15 0 1 %s",       # chan_id, sharpness index
      :set_resp   => "A %s 0 0 10 %s 4 15 %s 0 0",  # ack, chan_id, error
      :get        => "YY 0 0 %s 4 14 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 14 %s 0 1 %s", # ack, chan_id, error, sharpness index
      :settings   => {                              # invert this to get ":gettings"
      "HIGH"  => 0x00,
      "MED"   => 0x01,
      "LOW"   => 0x02,
      },
    }
  end
  
  # <-2, >2 not supported by t api commands
  def multi_protune_exposure_cmds
    {
      :name       => "multi_protune_exposure_cmds",
      :set        => "YY 0 0 %s 4 19 0 1 %s",         # chan_id, EXPOSURE_LEVEL
      :set_resp   => "A %s 0 0 10 %s 4 19 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 4 18 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 4 18 %s 0 1 %s", # ack, chan_id, error, EXPOSURE_LEVEL
      :settings   => {                               # invert this to get ":gettings"
        "+2"            => 0x00,
        "+1.5"          => 0x01,
        "+1"            => 0x02,
        "+0.5"          => 0x03,
        "+0"            => 0x04,
        "-0.5"          => 0x05,
        "-1"            => 0x06,
        "-1.5"          => 0x07,
        "-2"            => 0x08,
      },
    }
  end
  
  def multi_capture_cmds
    {
      :set          => "t api multi_shot",
      "START"       => "capture_start",
      "STOP"        => "capture_stop",
    }
  end

  # 7dec15
  def multi_protune_reset_cmd
    {
      :name       => "multi_protune_reset_cmd",
      :set        => "YY 0 0 %s 4 1A 0 0",        # chan_id
      :set_resp   => "A %s 0 0 10 %s 4 1A %s 0 0",    # ack, chan_id, error
    }
  end
  
  # 7dec15
  def multi_get_all_settings_cmd
    {
      :name       => "multi_get_all_settings_cmd",
      :get        => "YY 0 0 %s 4 1D 0 0",            # chan_id
      :get_resp   => "20 %s 0 0 10 %s 4 1D %s 0 16 %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", # ack, chan_id, error, <all (16) multi settings>
    }
  end

  # 7dec15
  def multi_get_shot_countdown_cmd
    {
      :name       => "multi_get_shot_countdown cmd",
      :get        => "YY 0 0 %s 4 1F 0 0",            # chan_id
      :get_resp   => "E %s 0 0 10 %s 4 1F %s 0 4 %s %s %s %s", # ack, chan_id, error, <1. multishots: timelapse 2. internal: 60s press shutter. 3: run command>
    }
  end

  
  ##################################################################
  # SETUP/SETTINGS/SYSTEM
  ##################################################################
  def lcd_brightness_cmds  ### NOT SUPPORTED for GCCB
    {
      :set      => "YY 0 0 %s 7 1 0 1 %s",         # SET COMMAND  FORMAT: channel_id, <brightness>
      :set_resp => "A %s 0 0 10 %s 7 1 %s 0 1",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 7 0 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 7 1 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, quick capture on/off
      :settings => {                               # invert this to get ":gettings"
      "HIGH"  => 0x00,
      "MED"   => 0x01,
      "LOW"   => 0x02,
      },
    }
  end
  
  def lcd_auto_off_cmds
    {
      :set    => "t api setup lcd_auto_off",
      :get    => "t api setup lcd_auto_off",
      "OFF"   => "never",
      60      => "1min",
      120     => "2min",
      180     => "3min",
    }
  end

  def lcd_lock_cmds
    {
      :set    => "t api setup lcd_lock",
      :get    => "t api setup lcd_lock",
      "OFF"   => "off",
      "ON"    => "on",
    }
  end
  
  def orientation_cmds
    {
      :set    => "t api setup orientation",
      :get    => "t api setup orientation",
      "AUTO"  => "auto",
      "UP"    => "up",
      "DOWN"  => "down",
    }
  end
  
  def default_mode_cmds
    {
      :set      => "YY 0 0 %s 7 B 0 1 %s",         # SET COMMAND  FORMAT: channel_id, default app mode
      :set_resp => "A %s 0 0 10 %s 7 B %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error, default app mode
      :get      => "YY 0 0 %s 7 A 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 7 A %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, default app mode
      :settings => {                               # invert this to get ":gettings"
        "VIDEO"       => 0x00,  # set & get values
        "PHOTO"       => 0x01,  # set & get values
        "MULTI_SHOT"  => 0x02,  # set & get values
        #"BROADCAST"   => ?
        #"PLAYBACK"    => ?
        #"SETTINGS"    => ?
      }
    }
  end
  
  def quick_capture_cmds
    {
      :set  => "t api setup quick_capture",
      :get  => "t api setup quick_capture",
      "OFF" => "off",
      "ON"  => "on",
    }
  end

  def obm_cmds
    {
      :set      => "YY 0 0 %s 7 D 0 1 %s",         # SET COMMAND  FORMAT: channel_id, quick capture on/off
      :set_resp => "A %s 0 0 10 %s 7 D %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 7 C 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 7 C %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, quick capture on/off
      :settings => {                               # invert this to get ":gettings"
      "OFF"  => 0x00, # False
      "ON"   => 0x01, # True
      },
    }
  end

  def led_cmds
    {
      :set      => "YY 0 0 %s 7 F 0 1 %s",         # SET COMMAND  FORMAT: channel_id, number of status lights
      :set_resp => "A %s 0 0 10 %s 7 F %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 7 E 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 7 E %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, number of status lights
      :settings => {                               # invert this to get ":gettings"
        "off"   => 0x00,  # set & get values  # none (off)
        "2"     => 0x01,  # set & get values  # front, back
        "4"     => 0x02,  # set & get values  # top,botton,front,back
      }
    }
  end
  
  def beep_sound_cmds
    {
    :set      => "YY 0 0 %s 7 11 0 1 %s",         # SET COMMAND  FORMAT: channel_id, beeper_volume
    :set_resp => "A %s 0 0 10 %s 7 11 %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error, beeper_volume
    :get      => "YY 0 0 %s 7 10 0 0",            # GET COMMAND  FORMAT: chan_id
    :get_resp => "B %s 0 0 10 %s 7 10 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, beeper_volume
    :settings => {                               # invert this to get ":gettings"
      "0"       => 0x02,  # set & get values
      "70"      => 0x01,  # set & get values
      "100"     => 0x00,  # set & get values
    }
  }
  end
  
  def vid_mode_cmds  # aka video format
    {
      :name     => "video_mode_cmds",
      :set      => "YY 0 0 %s 7 13 0 1 %s",        # channel_id,  format  (aka VIDEO_REGION)
      :set_resp => "A %s 0 0 10 %s 7 13 %s 0 0",   # ack, chan_id, error
      :get      => "YY 0 0 %s 7 12 0 0",           # chan_id
      :get_resp => "B %s 0 0 10 %s 7 12 %s 0 1 %s", # ack, chan_id, error, format

      :settings => {
        "NTSC"  => 0x00,
        "PAL"   => 0x01,
      },
    }
  end
  
  def power_off_cmds
    {
      :name     => "power_off_cmds",
      :set      => "YY 0 0 %s 8 2 0 1 %s",        # channel_id,  force
      :set_resp => "A %s 0 0 10 %s 8 2 0 %s 0",   # ack, chan_id, error
      # NOTE: there is not GET/GET-RESPONSE for this command since the power will be off

      :settings => {
        "NORMAL"  => 0x00,
        "FORCE"   => 0x01,
      },
    }
  end

  def osd_cmds
    {
      :set  => "t api setup osd",
      :get  => "t api setup osd",
      "ON"  => "on",
      "OFF" => "off",
    }
  end
  
  def locate_camera_cmds
    {
      :name     => "locate_camera_cmds",
      :set      => "YY 0 0 %s 8 D 0 1 %s",         # channel_id, <LOCATE TRUE/FALSE>
      :set_resp => "A %s 0 0 10 %s 8 D %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 8 C 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 8 C %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error, <LOCATE TRUE/FALSE)
      :settings => {
        "OFF"   => 0x00,  # false
        "ON"    => 0x01,  # true
      },
    }
  end
  def camera_time_cmds
    {
      :name     => "camera_time_cmds",
      :set      => "YY 0 0 %s 7 1B 0 7 %s",         # channel_id, "YY M DY H M S"
      :set_resp => "A %s 0 0 10 %s 7 1B %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 7 1A 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "12 %s 0 0 10 %s 7 1A %s 0 8 %s %s %s %s %s %s %s %s", # GET RESPONSE FORMAT: ack, chan_id, error, "YY M DY H M S"
      # Note: no settings for this cmd
    }
  end
  
  def auto_off_cmds
    {
      :set      => "YY 0 0 %s 7 17 0 1 %s",         # channel_id, power off delay
      :set_resp => "A %s 0 0 10 %s 7 17 %s 0 0",    # SET RESPONSE FORMAT: ack, chan_id, error
      :get      => "YY 0 0 %s 7 16 0 0",            # GET COMMAND  FORMAT: chan_id
      :get_resp => "B %s 0 0 10 %s 7 16 %s 0 1 %s", # GET RESPONSE FORMAT: ack, chan_id, error,  power off delay
      :settings => {                               # invert this to get ":gettings"
        "NEVER" => 0x00,  
        "1"     => 0x01,  # 1 minute delay
        "2"     => 0x02,  # 2 minute delay
        "3"     => 0x03,  # 3 minute delay
        "5"     => 0x04,  # 5 minute delay
      },
    }
  end
  
  def apply_settings_cmds; { :set => "t api app apply" }; end
  
  # Also known as internal_battery_info
  def battery_level_cmds
    {
      :name       => "battery_level_cmds",
      # NOTE: there are no set commands for this
      :get        => "YY 0 0 %s 8 0 0 0",            # chan_id
      :get_resp   => "D %s 0 0 10 %s 8 0 %s 0 3 %s %s %s", # ack, chan_id, error, <PERCENT> <BARS> <STATE>
      # PERCENT : 0x00 - 0x64
      # BARS    : 0-3
      # STATE   : 0% - 100%
    }
  end

  def shutdown_cmds;       { :set => "t api system shutdown" }; end
  
  def reset_cmds;          { :set => "t api system reset force" }; end

  def reset_no_force_cmds; { :set => "t api system reset not_force" }; end
  
  def beep_blink_cmds
    { 
      :set        => "t api system beep_blink",
      "STARTUP"   => "startup",
      "WARN"      => "warning",
      "NOTIFY"    => "notify",
      "SHUTDOWN"  => "shutdown",
      "ONCE"      => "once",
      "BEEP"      => "beep_once",
      "BLINK"     => "blink_once",
    }
  end

  ####### SYSTEM

  def firmware_version_cmd
    { 
      :name       => "get_firmware_version_cmd",
      :get        => "YY 0 0 %s 8 9 0 0",            # chan_id
      :get_resp   => "D %s 0 0 10 %s 8 9 %s 0 3 %s %s %s", # ack, chan_id, error, <MAJOR> <MINOR> <REV>

    }
  end

  # NEEDS IMPLEMENTATION
  def quick_capture_status_cmds; { :get => "t api system quick_capture_status" }; end

  # NEEDS IMPLEMENTATION
  def factory_reset_cmds
    {
      :set        => "t api system factory_reset",
      "USER"      => "user",
      "WIRELESS"  => "wireless",
      "ALL"       => "all",
    }
  end

  # NEEDS IMPLEMENTATION
  def lcd_available_cmds
    {
      :set        => "NEEDS IMPLEMENTATION"
    }
  end

  # Get Camera Info
  #
  # "[REQUEST]: A YY 0 0 <Channel ID> 8 11 0 0 0 
  # [RESPONSE]:  <ACK/NACK> 0 0 10 <Channel ID> 8 11 <ERROR> <Length> <Camera ID><name_Length>Camera Name> <firmware_length><Firmware Verison>
  # uint8_t camera_id :
  # uint8_t camera_name_length D:  
  # char    camera_name[]:
  # uint8_t firmware_version_length: 
  # char    firmware_version[]: "
  #
  def camera_info_cmd
    {
      :name       => "get_camera_info_cmd",
      :get        => "YY 0 0 %s 8 11 0 0",            # chan_id
      # ack, chan_id, error, <length> <id> <name_len> <name> <fw_len>  <firmware_ver>
      :get_resp   => "%s %s 0 0 10 %s 8 11 %s 0 %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
    }
  end

  def camera_busy_status_cmd
    {
      :name       => "get_camera_busy_status",
      :get        => "YY 0 0 %s 8 6 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 8 6 %s 0 1 %s", # ack, chan_id, error, temp warning <not:0 busy:1>
      :settings => {
        "NOT_BUSY"    => 0x00,
        "BUSY"        => 0x01,
      }
    }
  end

  def camera_recording_status_cmd
    {
      :name       => "get_camera_recording_status",
      :get        => "YY 0 0 %s 8 5 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 8 5 %s 0 1 %s", # ack, chan_id, error, temp warning <not:0, recording:1>
      :settings => {
        "NOT_RECORDING"    => 0x00,
        "RECORDING"        => 0x01,
      }
    }
  end

  def camera_temp_warning_cmd
    {
      :name       => "get_camera_temp_warning_cmd",
      :get        => "YY 0 0 %s 8 10 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 8 10 %s 0 1 %s", # ack, chan_id, error, temp warning <Yes:0, No:1>
      :settings => {                               # invert this to get ":gettings"
        "OK"    => 0x00,
        "WARNING" => 0x01,
      }
    }
  end

  def camera_temp_cmd
    {
      :name       => "get_camera_temp_cmd",
      :get        => "YY 0 0 %s 8 F 0 0",            # chan_id
      :get_resp   => "D %s 0 0 10 %s 8 F %s 0 3 %s %s %s", # ack, chan_id, error, <MAIN CHIP TEMP> <INTERNAL BATTERY TEMP> <IMAGE SENSOR>
    }
  end

  def language_cmds
    {
      :set       => "t api setup language",
      :get       => "t api setup language",
      "english"  => "english",
      "chinese"  => "chinese",
      "german"   => "german",
    }
  end
  
  ##################################################################
  # PLAYBACK
  ##################################################################
  def playback_osd_cmds  # OnScreenDisplay(OSD) BACKDOOR ONLY COMMAND, unless PIPE has a bacpac installed
    {
      :name       => "playback_osd_cmds",
      :set        => "YY 0 0 %s 7 15 0 1 %s",         # chan_id, <OSD ON/OFF>
      :set_resp   => "A %s 0 0 10 %s 7 15 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 7 14 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 7 14 %s 0 1 %s", # ack, chan_id, error, <OSD ON/OFF>
      :settings   => {                               # invert this to get ":gettings"
        "OFF"            => 0x00,
        "ON"             => 0x01,
      },
    }
  end
  
  def playback_start_cmds;     { :set => "t api playback start" }; end
  
  def playback_stop_cmds;      { :set => "t api playback stop" }; end
  
  def playback_pause_cmds;     { :set => "t api playback pause" }; end
  
  def playback_resume_cmds;    { :set => "t api playback resume" }; end
  
  def playback_step_cmds;      { :set => "t api playback step" }; end
  
  def playback_forward_cmds
    { 
      :set => "t api playback forward",
      "1/8X"  => "1/8x",
      "1/4X"  => "1/4x",
      "1/2X"  => "1/2x",
      "1X"    => "1x",
      "2X"    => "2x",
      "4X"    => "4x",
      "8X"    => "8x",
    }
  end
  
  def playback_backward_cmds
    { 
      :set => "t api playback backward",
      "1/8X"  => "1/8x",
      "1/4X"  => "1/4x",
      "1/2X"  => "1/2x",
      "1X"    => "1x",
      "2X"    => "2x",
      "4X"    => "4x",
      "8X"    => "8x",
    }
  end
  
  def playback_slideshow_start_cmds
    { :set    => "t api playback slideshow start" }
  end
  
  def playback_slideshow_stop_cmds
    { :set    => "t api playback slideshow stop" }
  end
  
  def playback_slideshow_multi_cmds
    { :set    => "t api playback multishot_slideshow" }
  end
  
  def playback_next_cmds;    { :set => "t api playback next_file" }; end
  
  def playback_prev_cmds;    { :set => "t api playback previous_file" }; end
  
  # TODO: Does this have args?
  def playback_tsearch_cmds; { :set => "t api playback tsearch" }; end

  ##################################################################
  # STORAGE
  ##################################################################
  def storage_tag_cmds;  { :set => "t api storage tag_moment" }; end

  # Gets list of hilight tags
  #   NOTE: only available during encoding!
  # cmd: 9 59 59 0 0 33 9 11 0 0  
  # in:   F 0 0 0 10 A7 9 11 0 0 5 0 0 0 0 0 
  # 
  def get_hilight_tags_cmd
    {
      :name      => "Get Hilight-Tags cmd",
      :get       => "YY 0 0 %s 9 11 0 0",
      # in:            F 0 0 0 10 A7 9 11 0  0  5  0  0  0  0  0 
      # in:            F 0 0 0 10 A7 9 11 0  0  5  2  0  7 ED 65  
      :get_resp  => "%s %s 0 0 10 %s 9 11 %s 0 %s %s %s %s %s %s",  # expected_len, ack, chan_id, error, length, <num tags> <timestamp of last tag captured>
    }
  end 

  # Sets the hilight tag
  # 
  def set_hilight_tag_cmd
    {
      :name      => "Set Hilight-Tag cmd",
      :set       => "YY 0 0 %s 9 C 0 0",
      :set_resp  => "A %s 0 0 10 %s 9 C %s 0 0",  # ack, chan_id, error
    }
  end 

  def photos_rem_cmds
    {
      :name      => "storage remaining_photos cmd",
      :get       => "YY 0 0 %s 9 1 0 0",
      :get_resp  => "E %s 0 0 10 %s 9 1 %s 0 4 %s %s %s %s",  # ack, chan_id, error, Remaining Photos: <byte3> <byte2> <byte1> <byte0>
    }
  end 

  # Get Remaining Video Duration command
  def vid_time_rem_cmds
    {
      :name      => "storage remaining_video_duration cmd",
      :get       => "YY 0 0 %s 9 2 0 0",
      :get_resp  => "E %s 0 0 10 %s 9 2 %s 0 4 %s %s %s %s", # ack, chan_id, error, Remaining Video Duration: <byte3> <byte2> <byte1> <byte0>
      #GET response: E  0 0 0 10 87 9 2 0 0 4 0 0 27 66  

    }
  end

  def group_photo_count_cmds;  { :get => "t api storage num_group_photos" }; end
  
  def group_video_count_cmds;  { :get => "t api storage num_group_videos" }; end
  
  def photo_count_cmds
    {
      :name      => "total photos cmd",
      :get       => "YY 0 0 %s 9 5 0 0",
      :get_resp  => "E %s 0 0 10 %s 9 5 %s 0 4 %s %s %s %s", # ack, chan_id, error, Total Photos: <byte3> <byte2> <byte1> <byte0>
    }
  end
  
  def video_count_cmds
    {
      :name      => "total videos cmd",
      :get       => "YY 0 0 %s 9 6 0 0",
      :get_resp  => "E %s 0 0 10 %s 9 6 %s 0 4 %s %s %s %s", # ack, chan_id, error, Total videos: <byte3> <byte2> <byte1> <byte0>
    }
  end
  
  # Removed in v8.00
  #def total_files_cmds;  { :get => "t api storage num_files" }; end
  
  def last_file_cmds;    { :get => "t api storage last_file" }; end
  
  def delete_one_cmds;   { :set => "t api storage file_delete" }; end
  
  def delete_last_cmds
    {
      :name     => "delete_last_cmds",
      :set      => "YY 0 0 %s 9 9 0 0 ",        # channel_id
      :set_resp => "A %s 0 0 10 %s 9 9 %s 0 0",   # ack, chan_id, error
      # Note: there are no settings and get responses for this command
    }
  end

  def delete_group_cmds; { :set => "t api storage group_file_delete" }; end
  
  def delete_all_cmds
    {
      :name     => "delete_all_cmds",
      :set      => "YY 0 0 %s 9 A 0 0 ",        # channel_id
      :set_resp => "A %s 0 0 10 %s 9 A %s 0 0",   # ack, chan_id, error
      # Note: there are no settings and get responses for this command
    }
  end

  def storage_status_event_cmds
    { 
      :name       => "storage_status_event_cmds",
      :get        => "YY 0 0 %s 9 0 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 9 0 %s 0 1 %s", # ack, chan_id, error, <sdcard status>
      :settings => {
          0x00 => "OK",
          0x01 => "FULL",
          0x02 => "REMOVED",
          0x03 => "FORMAT-ERROR",
          0x04 => "BUSY",
      }
    }
  end

  # Storage Remaining Space Get
  # 14dec15
  def storaage_remspace_cmds
    {
      :name      => "storage remanining space cmds cmd",

      # cmd:    9 59 59 0 0 1F 9 10 0 0  
      :get       => "YY 0 0 %s 9 10 0 0",

      #          in: 12  0 0 0 10 67 9 10  0 0 8 0   0  0  0  3 AD 6E  0  
      :get_resp  => "12 %s 0 0 10 %s 9 10 %s 0 8 %s %s %s %s %s %s %s %s", # ack, chan_id, error, Remaining Video Duration: <bytes 7-0 (8 bytes)>

    }
  end


  ##################################################################
  # WIRELESS
  ##################################################################
  def wireless_mode_cmds
    {
      :set      => "t api wireless mode",
      :get      => "t api wireless mode",
      "OFF"     => "off",
      "APP"     => "app",
      "RC"      => "rc",
      "NETWORK" => "network",
      "SMART"   => "smart",
    }
  end
  
  def pairing_cmds
    { 
      :set => "t api wireless pairing",
      "APP"      => "app",
      "RC"       => "rc",
      "NETWORK"  => "nw",
      "BT_AUDIO" => "bt_audio",
      "SMART"    => "app_ble",
    }
  end
  
  def pairing_stop_cmds;       { :set => "t api wireless pairing_stop" }; end
  
  def wireless_ble_cmds;       { :set => "t api wireless ble" }; end

  def wireless_status_cmds;    { :set => "t api wireless status" }; end
  
  def push_multek_cmds;        { :set => "t api wireless push_multek" }; end

  
  ##################################################################
  # FWUPDATE
  ##################################################################
  def fw_update_start_cmds;  { :set => "t api fwupdate start" }; end
  
  def fw_update_reset_cmds;  { :set => "t api fwupdate reset" }; end
  
  def boot_fw_cmds;          { :set => "t api fwupdate boot_fw" }; end
  
  ###########################################################################
  # VID_FEATURE_AVAIL
  ###########################################################################
  def piv_avail_cmds;          { :get => "t api video capability_filter_check piv" }; end

  def low_light_avail_cmds;    { :get => "t api video capability_filter_check low_light" }; end

  def protune_avail_cmds;      { :get => "t api video capability_filter_check protune" }; end

  def timelapse_avail_cmds;    { :get => "t api video capability_filter_check timelapse" }; end

  def jello_slayer_avail_cmds; { :get => "t api video capability_filter_check jello_slayer" }; end

  ###########################################################################
  # BROADCAST MODE
  ###########################################################################
  def broadcast_sub_mode_cmds
    {
      :set          => "t api app sub_mode",
      :get          => "t api app sub_mode",
      "RECORD"      => "broadcast_record",
      "BROADCAST"   => "broadcast",
    }
  end
  
  def broadcast_def_sub_mode_cmds
    {
      :set          => "t api broadcast default_sub_mode",
      :get          => "t api broadcast default_sub_mode",
      "RECORD"      => "broadcast_record",
      "BROADCAST"   => "broadcast",
    }
  end

  def broadcast_cmds
  end

  #############################################################################
  #  Non-API utility commands
  #############################################################################
  def short_press_cmds
    {
      :set            => "t button press",
      "P_BUTTON"      => "0 250",
      "S_BUTTON"      => "1 250",
      "MENU_BUTTON"   => "2 250",
      "LCD_BUTTON"    => "3 250",
    }
  end

end # module GCCBcommand api (Hawaii Phase4)

### Australia updates to api ################################################
#
# We simply overwrite the hashes that are different.
# They will be pulled in the GCCBCamera::initialize()
#
module GCCBcommands_Streaky_api
  # camera_streaky.rb:  @video_protune_iso_values     = ["6400", "1600", "400", "3200", "800"]
  def video_protune_iso_cmds
    {
      :name       => "video_protune_iso_cmds",
      :set        => "YY 0 0 %s 2 17 0 1 %s",         # chan_id, ISO index
      :set_resp   => "A %s 0 0 10 %s 2 17 %s 0 0",    # ack, chan_id, error
      :get        => "YY 0 0 %s 2 16 0 0",            # chan_id
      :get_resp   => "B %s 0 0 10 %s 2 16 %s 0 1 %s", # ack, chan_id, error, ISO index
      :settings   => {                               # invert this to get ":gettings"
        6400    => 0x00,
        3200    => 0x01,
        1600    => 0x02,
        800     => 0x03,
        400     => 0x04,
      },
    }
  end
end  # GCCBcommands_Streaky_api

### MargaretRiver updates to api ################################################
#
# We simply overwrite the hashes that are different.
# They will be pulled in the GCCBCamera::initialize()
#
module GCCBcommands_MargaretRiver_api
end  # GCCBcommands_MargaretRiver_api

if __FILE__ == $0

   puts "gccb_commands.rb:  TESTING 1 2 3"

end
