#!/usr/bin/env ruby

#######################################################
# gccb_camera.rb - Hero4 (pipe and backdoor)
#   Class for connecting and communicating with a
#   camera/board connected by a standard gccb/serial interface
#
# Instructions:
# 1) Connect GCCB board to computer (usually via USB)
# 2) Locate the serial device (probably /dev/ttyACM0)
# 3) Make it user-readable (sudo chmod 666 /dev/ttyACM0)
# 4) Run your test-file! (tests/test_gccb_commands.rb)
#

# WRONG MODE requests - Design for setting commands requested in the wrong mode
# 1. Read the mode, submode, settings  upon startup and SAVE in camera class variables
# 2. Change class variables when ever a setting is successfully changed and verified
#    Hint: do this in the api layer above "def set()", name-specific to call
# 3. Print WARNING if about to run setting command in WRONG mode
# 4. For test purposes, allow illegal commands to go through (sent)
#
# Design for VIDEO setting commands with MORE THAN ONE ARGUMENT
# 1. Resolution, FPS, and FOV are all combined in one command, however we should be able set one setting
# 2. DO THIS BY:
#    a. READ & STORE all settings in class variables for each mode/submode - are these the DEFAULTS???
#    a. allowing the command to be sent, but upon verification read all 3 settings back and STORE in class variables
#    b. next time through use CLASS variables
#
# INVALID SETTINGS
# 1. Send illegal combinations (ie 60 fps in PAL mode) and record response
# 2. Send illegal values (ie out of range index)
# 3. Do this for ALL modes and ALL settings
#

require 'fileutils'
require 'serialport'
require 'set'
require 'scanf'

require_relative 'camera'
require_relative 'host_utils'
require_relative 'log_utils'
require_relative 'gccb_commands'

class GCCBCamera < Camera
  include GCCBCommands
  include LogUtils

  attr_accessor :last_video_attempted,
  :chan_id,  # needed for every command during gccb test session (since power-up). See get_channel_id()
  :default_chan_id,
  :last_video_successful, :autoconnect,
  :save_ts_file, :save_ts_filename, :squelch_status, :media_dir,
  :debug

  attr_reader :screens, :release, :type, :addr, :dev, :log_path,

  # Use the following for determining invalid setting attempts
  :current_camera_mode,     # read during class initialization, update with any mode get command
  :current_camera_submode,  # read during class initialization, update with any submode get command

  # VIDEO current states
  :curr_video_submode,
  :curr_video_def_submode,
  :curr_video_format,       # NTSC vs PAL
  :curr_video_fps,
  :curr_video_fov,
  :curr_video_res,
  :curr_video_protune,
  :curr_video_protune_exposure,
  :curr_video_protune_whitebalance,
  :curr_video_protune_sharpness,
  :curr_video_looping,
  :curr_video_lowlight,
  :curr_video_timelapse_interval, 
  :curr_video_spot_metering,
  :curr_video_piv_interval,
  :curr_video_progress_counter,
  :curr_video_all_settings,  # [dm,res,fps,fov,piv,loop,spot,lowlt,tl,pt,color,sharp,iso,ev,wb]
  :curr_video_all_resolutions,
  :curr_video_all_fps,
  :curr_video_all_fov,

  # PHOTO current states
  :curr_photo_submode,
  :curr_photo_def_submode,
  :curr_photo_res,
  :curr_photo_protune,
  :curr_photo_protune_exposure,
  :curr_photo_continuous_rate,
  :curr_photo_spot_metering,
  :curr_photo_exposure_time,
  :curr_photo_whitebalance,
  :curr_photo_sharpness,
  :curr_photo_iso,
  :curr_photo_all_settings,

  # MULTI current states
  :curr_multi_submode,
  :curr_multi_def_submode,
  :curr_multi_res,
  :curr_multi_protune,
  :curr_multi_protune_exposure,
  :curr_multi_timelapse_interval,
  :curr_multi_burst_rate,
  :curr_multi_spot_metering,
  :curr_multi_exposure_time,
  :curr_multi_whitebalance,
  :curr_multi_sharpness,
  :curr_multi_iso,
  :curr_multi_all_settings,
  :curr_multi_nightlapse_interval,
  :curr_multi_shot_countdown,


  # SETTINGS current states
  :curr_default_mode,
  :curr_default_submode,
  :curr_pb_osd_onoff,
  :curr_battery_percent,
  :curr_battery_bars,
  :curr_battery_state,
  :curr_quick_capture_mode,
  :curr_auto_off,
  :curr_camera_time,
  :curr_locate_camera,
  :curr_lcd_brightness,
  :curr_leds,
  :curr_beeps,
  :camera_info,

  :audio_channels,
  :audio_codec,
  :audio_sample_rate,
  :avc_profile_level,
  :burst_modes,
  :chg_prev_br_support,
  :chg_prev_res_support,
  :colorspace,
  :data_log_model,
  :defaults,
  :pause_gccb_cmds,
  :looping_chapter_len,
  :multi_photo_spot_metering_support,
  :multi_photo_nightlapse_support,
  :multi_photo_protune_support,
  :multi_shutter_exposure,
  :pes_modes,
  :photo_modes,
  :photo_spot_metering_support,
  :photo_continuous_support,
  :photo_night_support,
  :photo_protune_support,
  :photo_protune_iso_values,
  :photo_shutter_exposure,

  :preview,
  :protune_white_balance_values,
  :protune_color_values,
  :protune_sharpness_values,
  :protune_exposure_values,
  :setup,
  :serial_iface,
  :linux_iface,
  :test_preview_stream,
  :video_codec,
  :video_capture_modes,
  :video_looping_support,
  :video_low_light_support,
  :video_lrv_bitrate,
  :video_piv_support,
  :video_piv_intervals,
  :video_protune_support,
  :video_protune_iso_values,
  :video_timelapse_lrv_bitrate,
  :video_timelapse_support,

  # SYSTEM current states
  :camera_busy_status,
  :curr_cpu_temp,
  :curr_battery_temp,
  :curr_sensor_temp,
  :camera_temp_warning,
  :camera_id,
  :camera_name,
  :camera_firmware_version,
  :wifi_mac, :blue_mac, :serialno, :cam_model, :board_type,

  # STORAGE current status
  :storage_status,
  :storage_space_rem,
  :photos_remaining,
  :video_duration_rem,
  :video_count,
  :photo_count,
  :semaphore,
  
  # MISC
  :wait_time,
  :retries,
  :verify

  alias_method :gccb_iface, :dev

  def get_all_camera_params()
    get_video_timelapse_interval()
    get_mode()
    get_video_format()
    get_video_sub_mode()
    get_video_settings()
=begin
    get_submode("VIDEO")
    get_submode("MULTI_SHOT")
    get_video_low_light()
    get_video_looping()
    get_video_protune()
    get_video_protune_exposure()
    get_photo_res()
    get_photo_protune()
    get_photo_protune_exposure()
    get_photo_def_sub_mode()
    get_multi_timelapse_interval()
    get_multi_protune()
    get_multi_protune_exposure()
    get_multi_protune()
    get_sps()
    get_burst()
    get_pb_osd_onoff()
    get_battery_level()
    get_quickcapture()
    get_auto_off()
    get_camera_time()
    get_locate_camera()
=end
  end

  def initialize(gccb_dev, cam_serial_log=nil, log_path=nil)
    super()
    @dev        = gccb_dev                   # e.g. /dev/ttyACM0
    @addr       = @dev.split("/")[-1]   # e.g. ttyACM0
    @baud       = 115200
    @serialport = verify_serial_port(@dev)
    @interfaces << :gccb
    @serial_iface    = cam_serial_log # e.g. /dev/ttyUSB0 Non-null if also has a serial interface (for camera&linux logs)
    @linux_iface          = nil
    @pause_gccb_cmds = false
    @gccb_io_delay = 0
    @save_ts_file         = false
    @squelch_status       = false
    @media_dir     = nil

    # The following are used as default ares to the "def set()" function call
    @wait_time  = 1.0
    @retries    = 1.0
    @verify     = true   # We want to automatically verify each setting
    @debug      = false  # turn on debug messages
    @noverify   = false   # We don't want to verify a setting
    @zz_powered_on = false
    @semaphore = Mutex.new
    @log_path  = log_path

    gccb_init()

    #start_serial_logs(log_path) # KNOWN PROBLEMS - hangs gccb interface

  end

=begin
  # Override is_alive?()
  # TODO: (placeholder) unsure of implementation or if needed so far ~RodT Feb23.16
  #       Carry-over from wifi_camera.rb
  def is_alive?(retries=3, timeout=10.0)
    for n in (1..retries) do
      #get_channel_id() # this?
      send_zz_rdy()     # or this? probably need simple api interface check command
      #return true if expect("true", timeout) != nil
      return true if expect("OK", timeout) != nil
    end
    return false
  end
=end

  def gccb_init

    @zz_powered_on = true

    # GCCB initialization
    # see reinitialize_gccb()
    gccb_power_on()
    exit if not send_zz_rdy()
    get_channel_id()

    #TODO - verify how to get camera info via GCCB or just do via wifi if enabled
    #TODO: FIXED CAMERA info for testing purposes
    ### #
    @release, @type, @build, @serialno = get_cam_info()
    ### get_cam_info()

    # get_all_camera_params()

    # READ THE CAMERA FOR CURRENT MODES and SETTINGS
    # NOTE: This information will be used to determine if any attempts
    #  to set the a submode or setting is a VALID(NTSC & 30fps or INVALID (NTSC & 25fps) combination
    #
    # 1. get the mode (& save globally)
    # 2. get the submode (& save globally)
    # 3. get the format (NTSC/PAL) (& save globally)

    if @release == "HD4" and @type == 1
      require_relative 'camera_backdoor'
      extend Backdoor
      init()
    elsif @release == "HD4" and @type == 2
      log_info("HD4 3 camera_pipe")
      require_relative 'camera_pipe'
      extend Pipe
      init()
    elsif @release == "HX1" # Only DATA ANALYTICS commands supported!
      require_relative 'camera_rockypoint'
      extend Rockypoint
      init()
    elsif @release == "HD3" and @type == 21 # Only DATA ANALYTICS commands supported!
      require_relative 'camera_haleiwa'
      extend Haleiwa
      init()
    elsif @release == "HD3" and @type == 22 # Only DATA ANALYTICS commands supported!
      require_relative 'camera_himalayas'
      extend Himalayas
      init()
    elsif @release == "HD5" and @type == 2
      require_relative 'camera_streaky'
      extend Streaky
      extend GCCBcommands_Streaky_api
    elsif @release == "HD5" and @type == 3    # Still need to verify
      require_relative 'camera_margaretriver'
      extend MargaretRiver
      extend GCCBcommands_MargaretRiver_api
    else
      log_warn("Error: Unsupported serial camera (rel=#{@release}, type=#{@type})")
      log_info("Must be rel == HD4, type == [1|2]")
      raise "Make sure camera is connected, powered on, and contains an SD card."
    end
    @host       = Host.new()
    @last_video_attempted = nil   # The last video attempt via capture_video()
    @last_video_successful = nil  # The last video success via capture_video()
    if ["BACKDOOR", "PIPE"].include?(@name)
      #TODO: see if exists for GCCB
      puts("GCCB manufacture data?")
      @wifi_mac, @blue_mac, @serialno, @cam_model, @board_type = get_manufacture_data()
    end
  end # gccb_init

  def start_serial_logs(log_path)
    # Capture console logs to log_path
    if @serial_iface != nil
      log_path = "/tmp/test.log" if log_path == nil
      # @linux_iface: Just assume it is serial_iface + 1
      n1 = @serial_iface[-5..-1].scan(/\d/)[0]
      n2 = n1.to_i + 1
      @linux_iface = @serial_iface[0...@serial_iface.index(n1)] + n2.to_s
      log_info("Linux serial port not specified.  Trying #{@linux_iface}")

      if init_amba_serial_log(File.dirname(log_path), File.basename(log_path)) == false
        puts "ERROR with init_amba_serial_log()"
      else
        puts "init_amba_serial_log() SUCCESS"
      end

      if spawn_amba_logging_thread(@serial_iface, @semaphore) == false
        puts "ERROR with spawn_amba_logging_thread()"
      else
        puts "spawn_amba_logging_thread() SUCCESS"
      end
    end
  end

  def reinitialize_gccb()
    gccb_power_on()
    send_zz_rdy()
    get_channel_id()
  end

  # Verifies that the serial port exists and is readable/writable
  def verify_serial_port(dev)
    doexit = false
    if not File.exist?(dev)
      log_warn("Serial device #{dev} not found. Is device plugged in?")
      doexit = true
    elsif not File.readable?(dev)
      log_warn("Serial device #{dev} not readable. 'sudo chmod 666 #{dev}' ?")
      doexit = true
    elsif not File.writable?(dev)
      log_warn("Serial device #{dev} not writable. 'sudo chmod 666 #{dev}' ?")
      doexit = true
    else
      begin
        serialport = SerialPort.new(dev, @baud)
      rescue StandardError => e
        log_warn("Unable to open serial port at #{dev}")
        log_warn(e.to_s + e.backtrace.join("\n"))
        doexit = true
      end
      log_info("OPENED serial port #{dev} SUCCESSFULLY")
      return serialport
    end
    exit 1 if doexit == true
  end

  def get_cam_info(tries=5)

    fwver   = zz_get_firmware_ver()
    puts "get_cam_info(): fwver=#{fwver}"
    zz_build   = fwver[7..14]
    puts "get_cam_info(): zz_build=#{zz_build}"

    result, msg, cam_id, camera_name, cam_fwver = get_camera_info()
    if result
      cam_release = cam_fwver[0,3]
    else 
      puts "ERROR #{msg}"
    end
    ### @release = "HD4"
    ### @type    = 2 # PIPE
    ### @type    = 1 # BACKDOOR
    ### @build   = "03.01.14" # HD4.02.03.01.12
    ### @serialno = "xxxx"
    ### @cam_release = @release
    ### @cam_type = @type
    ### @cam_build = @build

    cam_type    = cam_id - 11
    cam_build   = zz_build
    serialno    = "NOT AVAILABLE"

    # IMPORTANT: Note, this information is needed for TestRail via ResultsHandler
    log_conf("name, BACKDOOR")
    log_info("Camera Info:")
    log_conf("serialno, #{serialno}")
    log_conf("ssid, NOT AVAILABLE")
    log_conf("mac, NOT AVAILABLE")
    log_conf("release, #{cam_release}")
    log_conf("type, #{cam_type}")
    log_conf("build, #{cam_build}")
    return cam_release, cam_type, cam_build, serialno  # 7dec15 ~RodT only the build is real here
  end # end get_cam_info()

  def update_cam_info()
    @release, @type, @build = get_cam_info()
  end

  def get_manufacture_data()
    ###TODO:Fix this (fake data)
    wifi_mac = "wifi_mac"
    blue_mac = "blue_mac"
    serialno = "serialno"
    cam_model = @cam_type==2 ? "PIPE" : "BACKDOOR"
    board_type = "board_type"
    return wifi_mac, blue_mac, serialno, cam_model, board_type
  end

  # Reads from the serial port for 'limit' seconds.
  # ALL output of interest must be received by this deadline
  def read_serial_resp(limit=1.0)
    # gccb_init() if not @zz_powered_on
    resp = ""
    # sleep(0.5)
    thr = Thread.new {
      while true do
        # @semaphore.synchronize {
          c = @serialport.getc
          resp << c if c != nil
        # }
      end
    }
    result = thr.join(limit)
    thr.terminate
    if @debug
      puts "\n................... RESPONSE PKT ...................\n"
      puts "#{resp}"
      puts "....................................................\n"
    end
    return resp
  end

  # Sends a string to the serial device
  def send_serial(s)

    gccb_init() if not @zz_powered_on
    gccb_delay()

    gccb_pause_check()

    puts("send_serial: #{s}") if @debug
    log_info("GCCB command: #{s}")

    #SAVE: @serialport.write(s.chomp)
    #SAVE: @serialport.write("\r\n")

    @serialport.write(s) #NEW
    @serialport.write("\n\r")
  end

  # Returns the response if the 're' match is found.  False if otherwise.
  # The response will be all the output through time 'timeout'.
  # Time per serial port read can be controlled by setting 'limit'
  #
  def expect(resp_in, re)
    # Convert all Fixnums to Strings and everything else to Regexp
    if resp_in == nil
      log_warn("expect() resp_in==nil")
      return nil
    end
    if re == nil
      log_warn("expect() re(#1)==nil")
      return nil
    end
    re = re.to_s if re.is_a?(Fixnum)
    if re == nil
      log_warn("expect() re(#2)==nil")
      return nil
    end
    re = Regexp.escape(re) if not re.is_a?(Regexp)
    if re == nil
      log_warn("expect() re(#3)==nil")
      return nil
    end
    return resp_in if resp_in.match(re) != nil
    return nil
  end

  # Compare the expected response to what's read back from the GCCB camera
  def compare_responses(type, response_format, expected_value=nil, ev2=nil, ev3=nil)

    # expected good values to format
    ack      = 0
    no_error = 0
    has_arg  = false
    has_arg  = 3 if ev3 != nil
    has_arg  = 2 if ev2 != nil
    has_arg  = 1 if expected_value != nil
    ok       = true

    #response = response_format % [ack, @chan_id, no_error, arg_list]  ### Do we need ARG lists???

    response = response_format% [ack, @chan_id, no_error, expected_value, ev2, ev3]

    ## SERIAL READ
    resp_in    = read_serial_resp_in()
    expect_sts = expect(resp_in, response)

    if expect_sts == nil
      log_warn("FAILED #{type} CMD RESPONSE: command response MISMATCH")
    else
      log_info("#{type} response: #{resp_in} \t(VERIFIED)")
    end

    if has_arg
      #ok, msg, arg = check_response(resp_in, response_format, has_arg)
      ok, msg, arg, arg2, arg3 = check_response(resp_in, response_format, has_arg)
    else
      ok, msg = check_response(resp_in, response_format, has_arg)
    end
    log_warn(msg) if !ok

    return false,msg if expect_sts == nil
    return false,msg if !ok
    return true
  end

  # GET_LIST - send GCCB command to get a capabilities list from the camera
  #
  # Pass in a preformatted "cmd"
  #
  # RETURNS:
  #  - array/list of values
  #
  def get_list(hash, get_command)
    puts "GET: hash[:name] = #{hash[:name]}" if @debug
    send_serial(get_command)
    resp_in = read_serial_resp_in()
    msg=""
    ok = true
    a1=""
    a2=""
    a3=""
    a4=""
    a5=""
    a6=""
    a7=""
    a8=""
    a9=""
    a10=""
    a11=""
    a12=""
    a13=""
    a14=""
    a15=""
    a16=""
    a17=""
    a18=""
    a19=""
    a20=""
    a20=""
    a21=""
    a22=""
    a23=""
    a24=""
    a25=""
    a26=""
    a27=""
    a28=""
    a29=""
    a30=""
    a31=""
    a32=""
    a33=""
    a34=""
    a35=""
    a36=""
    actual_len, ack, chid, err, len, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12,a13,a14,a15,a16,a17,a18,a19,a20,a21,a22,a23,a24,a25,a26,a27,a28,a29,a30,a31,a32,a33,a34,a35,a36  = resp_in.scanf(hash[:get_resp])
    actual_len = actual_len.to_i(16)
    puts "get_list(): actual_len=#{actual_len} ack=#{ack} chid=#{chid} err=#{err} len=#{len}" if @debug

    # Check ACK, CHID, ERR

    if ack != "0"
      msg += " resp ERROR: BAD ACK"
      ok = false 
    end

    if chid != @chan_id  ##### KLUDGE!!! Change this to @chan_id
      msg += "ERROR: channel ids don't match #{chid} vs #{@chan_id}"
      ok = false 
    end

    if err != "0"
      msg += " resp ERROR #{err}: command FAILED\n"
      ok = false 
    end

    log_info("GET response: #{resp_in}")
    varray = [a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16,a17,a18,a19,a20,a21,a22,a23,a24,a25,a26,a27,a28,a29,a30,a31,a32,a33,a34,a35,a36]
    return ok, msg, err, len.to_i, varray   # return an array with the values in the response, and the length of the array

  end # get_list

  def get_array(hash, key=nil)
    puts "GET: hash[:name] = #{hash[:name]}" if @debug
    new_value = nil
    err = true
    if key !=  nil
      if hash[:settings] != nil
        return false, "ERROR: hash #{hash} is MISSING :settings[:key=#{key}]", err if hash[:settings][key] == nil
        # Get the NEW VALUE to set
        new_value = hash[:settings][key]
      else
        new_value = key
      end
      # Format the command with values
      get_command = hash[:get] % [ @chan_id,  new_value ]
    else
      # Format the command with chan_id only (for commands that don't take a new setting or argument
      get_command = hash[:get] % [ @chan_id ]
    end

    send_serial(get_command)
    resp_in = read_serial_resp_in()
    msg=""
    ok = true
    a1=""
    a2=""
    a3=""
    a4=""
    a5=""
    a6=""
    a7=""
    a8=""
    a9=""
    a10=""
    a11=""
    a12=""
    a13=""
    a14=""
    a15=""
    expected_len= hash[:expected_lengths][key]
    puts "get_array() expected_len= #{expected_len}"
    # expected_resp = hash[:get_resp] % [ expected_len ]
    actual_len, ack, chid, err, len, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12,a13,a14,a15  = resp_in.scanf(hash[:get_resp])
    actual_len = actual_len.to_i(16)
    puts "get_array(): actual_len=#{actual_len} ack=#{ack} chid=#{chid} err=#{err} len=#{len}" if @debug

    # Check expected len, ACK, CHID, ERR

    if actual_len != expected_len
      msg = "ERROR: BAD actual_len=#{actual_len} expected=#{expected_len}\n"
      ok = false 
    end

    if ack != "0"
      msg += ";ERROR: BAD ACK\n"
      ok = false 
    end

    if chid != @chan_id  ##### KLUDGE!!! Change this to @chan_id
      msg += "ERROR: channel ids don't match #{chid} vs #{@chan_id}"
      ok = false 
    end

    if err != "0"
      msg += ";ERROR #{err}: command FAILED\n"
      ok = false 
    end

    log_info("GET response: #{resp_in}")
    varray = [a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15]
    return ok, msg, err, len.to_i, varray   # return an array with the values in the response, and the length of the array

  end # get_array

  def get(hash, key=nil)
    puts "GET: hash[:name] = #{hash[:name]}" if @debug

    new_value = nil
    if key !=  nil
      if hash[:settings] != nil
        return false, "ERROR: hash #{hash} is MISSING :settings[:key=#{key}]", not_verified if hash[:settings][key] == nil
        # Get the NEW VALUE to set
        new_value = hash[:settings][key]
      else
        new_value = key
      end
      # Format the command with values
      get_command = hash[:get] % [ @chan_id,  new_value ]
    else
      # Format the command with chan_id only (for commands that don't take a new setting or argument
      get_command = hash[:get] % [ @chan_id ]
    end

    send_serial(get_command)
    resp_in = read_serial_resp_in()
    msg=""
    ok = true
    a1=""
    a2=""
    a3=""
    a4=""
    a5=""
    a6=""
    a7=""
    a8=""
    a9=""
    a10=""
    a11=""
    a12=""
    a13=""
    a14=""
    a15=""
    a16=""
    a17=""
    ack, chid, err, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12,a13,a14,a15,a16,a17  = resp_in.scanf(hash[:get_resp]) 

    # Check ACK, CHID, ERR

    if ack != "0"
      msg = "ERROR: BAD ACK\n"
      ok = false
    end

    if chid != @chan_id  ##### KLUDGE!!! Change this to @chan_id
      msg += "ERROR: channel ids don't match #{chid} vs #{@chan_id}"
      ok = false
    end

    if err != "0"
      msg += "ERROR #{err}: command FAILED\n"
      ok = false
    end

    log_info("GET response: #{resp_in}")
    return ok, msg, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17
  end

  # Enable/disable @debug messages
  # onoff must be either true or false
  def debug_enable(onoff)
    @debug = onoff
    puts "GCCB DEBUGGING ENABLED" if (onoff)
  end

  # Enable/disable pausing between serial commands
  def pause_enable(onoff)
    @pause_gccb_cmds = onoff
    puts "GCCB PAUSING ENABLED" if (onoff)
    STDIN.flush if onoff
  end

  # Set the internal delay between GCCB commands
  # This should be triggered by the cmdline optiobn --io_delay  :io_delay
  def set_io_delay(io_delay)
    @gccb_io_delay = io_delay.to_i
    log_info("Setting gccb_io_delay=#{@gccb_io_delay}")
  end

  def gccb_delay()
    @gccb_io_delay.times {print "."}
    print "\n"
    sleep @gccb_io_delay
  end

  def gccb_pause_check()
    if @pause_gccb_cmds
      puts "******** GCCB PAUSED: HIT <ENTER> TO CONTINUE *******"
      inp = STDIN. gets
    end
  end

  # NOTE: See gccb_commands.rb
  # 1. Format the GCCB "set" command, transmit it
  # 2. Format the GCCB "set response", if verify is true, read from camera, and compare
  # 3. Format the GCCB "get" command, transmit it, if verify is true
  # 4. Format the GCCB "get response" command, transmit it, if verify is true, and compare results
  #
  # FUNCTION: set()
  #   Set command that can be used for the well-formed API commands
  #
  # ARGS:
  #  hash      - command hash from gccb_commands.rb
  #  key       - value/arg to extract from hash[:settings] and put into gccb command
  #  wait_time - delay between sending command and checking for its response - default is 1.0s
  #  verify    - if 'true' it will send the :get command and get the :get_resp response from the camera
  #
  #  ie -
  #    :set_video_resolution  => "YY 0 0 %d 2 3 0 3 %s %s %s" # chanid, res, fps, fov
  # RETURNS:
  #     result - true|false
  #        msg - error message or ""
  #   verified - true|false
  #
  def set(hash, key, wait_time=1.0, verify=true, retries=1)

    puts "set(): hash=#{hash} key=#{key} verify=#{verify}" if @debug
    puts "set(): hash[:name]=#{hash[:name]}" if hash.has_key?(:name) if @debug

    not_verified = false  # returned if we never get to verify

    #return false, "ERROR, key is nil", not_verified if key == nil
    return false, "ERROR: hash #{hash} is MISSING the :set key", not_verified if hash[:set] == nil
    new_value = nil
    if key !=  nil
      if hash[:settings] != nil
        return false, "ERROR: hash #{hash} is MISSING :settings[:key=#{key}]", not_verified if hash[:settings][key] == nil
        # Get the NEW VALUE to set
        new_value = hash[:settings][key]
      else
        new_value = key
      end
      # Format the command with values
      set_command = hash[:set] % [ @chan_id,  new_value ]
    else
      # Format the command with chan_id only (for commands that don't take a new setting or argument
      set_command = hash[:set] % [ @chan_id ]
    end

    msg  = ""
    msg2 = ""
    result = true
    ok = true
    verified     = false  # to be set below in GET verification if verify==true

    cmd_time = nil
    cmd_time = Time.now()
    send_serial(set_command)

    #### VERIFICATION: check SET-CMD RESPONSE
    verify_set_response = true
    if verify_set_response
      puts "set():SET response verification..." if @debug
      return false, "Hash MISSING :set_resp key", not_verified if hash[:set_resp] == nil
      result, msg = compare_responses("SET",hash[:set_resp])
      puts "set():SET response result=#{result} msg=#{msg}" if @debug
      return result, msg, not_verified if !result
    end

    # Sleep any remaining time prescribed by wait_time arg.
    delay = wait_time - (Time.now() - cmd_time)
    sleep delay if delay > 0

    if verify == false
      msg = msg.to_s + "\nSkipping GET response VERIFICATION (verify==false)"
      return result, msg , not_verified
    end

    if verify == true and hash[:get] == nil
      msg = msg.to_s + "\nCANNOT VERIFY this command because hash is missing :get command"
      return result, msg , not_verified
    end

    ### VERIFICATION via CAMERA GET commands
    if verify == true and hash[:get] != nil

      puts "set():GET verification..." if @debug

      return false, msg + "\nHash MISSING :get key" if hash[:get] == nil

      get_command  = hash[:get] % [@chan_id]
      send_serial(get_command)

      result, msg2, arg = compare_responses("GET", hash[:get_resp], new_value)

      verified = true if result

      msg = msg.to_s + "\n" + msg2.to_s

    end # verify GET command

    return result, msg, verified

  end # set() -------------------------------------------------

  # Use this to set multiple keys with multiple hashes
  # - designed specifically to handle video settings
  def set_multiple(hash1, key1, hash2, key2, hash3, key3, verify=true)

    puts "set_multiple(): hash1=#{hash1} key1=#{key1} verify=#{verify}" if @debug
    puts "set_multiple(): hash1[:name]=#{hash1[:name]}" if hash1.has_key?(:name) if @debug

    not_verified = false  # returned if we never get to verify

    return false, "ERROR, key1 is nil", not_verified if key1 == nil
    return false, "ERROR, key2 is nil", not_verified if key2 == nil
    return false, "ERROR, key2 is nil", not_verified if key2 == nil
    return false, "ERROR: hash1 #{hash1} is MISSING the :set key1", not_verified if hash1[:set] == nil
    return false, "ERROR: hash2 #{hash2} is MISSING the :set key2", not_verified if hash2[:set] == nil
    return false, "ERROR: hash3 #{hash3} is MISSING the :set key3", not_verified if hash3[:set] == nil
    return false, "ERROR: hash1 #{hash1} is MISSING :settings[:key1=#{key1}]", not_verified if hash1[:settings][key1] == nil
    return false, "ERROR: hash2 #{hash2} is MISSING :settings[:key2=#{key2}]", not_verified if hash2[:settings][key2] == nil
    return false, "ERROR: hash3 #{hash3} is MISSING :settings[:key3=#{key3}]", not_verified if hash3[:settings][key3] == nil

    # Get the NEW VALUE to set
    new_value1 = hash1[:settings][key1]
    new_value1 = new_value1.to_s(16)
    new_value1.upcase!

    new_value2 = hash2[:settings][key2]
    new_value2 = new_value2.to_s(16)
    new_value2.upcase!

    new_value3 = hash3[:settings][key3]
    new_value3 = new_value3.to_s(16)
    new_value3.upcase!

    # Format the command with values
    # NOTE: just need to use one of the hashes because the all have the same format
    set_command = hash1[:set] % [ @chan_id,  new_value1, new_value2, new_value3 ]

    msg  = ""
    msg2 = ""
    result = true
    ok = true
    verified     = false  # to be set below in GET verification if verify==true

    cmd_time = nil
    cmd_time = Time.now()
    send_serial(set_command)

    #### VERIFICATION: check SET-CMD RESPONSE
    verify_set_response = true
    if verify_set_response
      puts "set_multiple():SET response verification..." if @debug
      return false, "Hash MISSING :set_resp key1", not_verified if hash1[:set_resp] == nil
      result, msg = compare_responses("SET",hash1[:set_resp])
      return result, msg, not_verified if !result
    end

    # Sleep any remaining time prescribed by wait_time arg.
    delay = wait_time - (Time.now() - cmd_time)
    sleep delay if delay > 0

    return result, msg + "\nSkipping GET response VERIFICATION (verify==false)" if verify == false

    ### VERIFICATION via CAMERA GET commands
    if verify == true

      puts "set_multiple():GET verification..." if @debug

      return false, msg + "\nHash MISSING :get key" if hash1[:get] == nil

      get_command  = hash1[:get] % [@chan_id]
      send_serial(get_command)

      result, msg2, arg = compare_responses("GET", hash1[:get_resp], new_value1, new_value2, new_value3)

      verified = true if result

      msg = msg.to_s + "\n" + msg2.to_s

    end # verify GET command

    return result, msg, verified

  end # set_multiple() -------------------------------------------------

  # GET current camera mode
  #
  def get_current_capture_mode()
    get_mode()
  end # get_current_capture_mode

  # Override set_capture_mode()
  # mode_sub_mode will take precedence, otherwise it will use just 'mode'
  # "def mode_sub_mode() is defined in gccb_commands.rb
  #
  def set_capture_mode(new_mode)

    puts "set_capture_mode(#{new_mode})" if @debug

    if ["VIDEO", "VIDEO_TIMELAPSE", "VIDEO_PIV", "VIDEO_LOOPING",
    "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT",
    "BURST", "TIMELAPSE", "NIGHTLAPSE", "BROADCAST_RECORD"].include?(new_mode)

      puts("set_capture_mode(#{new_mode})")
      ret, msg = set(mode_sub_mode_cmds, new_mode) #TODO: NEEDS WORK -- will this work in GCCB SCHEME???
      return ret, msg

    end

    if new_mode == "VIDEO"
      mode_name = "VIDEO"
      sub_mode = video_sub_mode  # point to appropriate submodes hash
      sub_name = "VIDEO"

    elsif new_mode == "PHOTO" # For backward compatibility
      mode_name = "PHOTO"
      sub_mode = photo_sub_mode  # point to appropriate submodes hash
      sub_name = "SINGLE"

    elsif ["SINGLE", "CONTINUOUS", "NIGHT"].include?(new_mode)
      mode_name = "PHOTO"
      sub_mode = photo_sub_mode  # point to appropriate submodes hash
      sub_name = new_mode

    elsif ["BURST", "TIME_LAPSE", "NIGHT_LAPSE"].include?(new_mode)
      mode_name = "MULTI_SHOT"
      sub_mode = multi_sub_mode  # point to appropriate submodes hash
      sub_name = new_mode

    elsif ["PLAYBACK", "SETTINGS", "FW_UPDATE", "MTP", "SOS"].include?(new_mode)
      # NOTE: there are NO submodes for PLAYBACK, SETTINGS, etc.
      mode_name = new_mode
      sub_mode = nil  # point to

    else
      log_warn("Mode #{new_mode} NOT valid")
      return false, "Mode #{new_mode} NOT valid"
    end

    # Set the CAMERA MODE
    ret, msg = set(mode_cmds, mode_name)
    return false, msg if ret == false

    # Set the CAMERA SUB-MODE
    if sub_mode != nil
      log_error("FIX THIS in set_capture_mode set(submode_hash...)")
      submode_hash = mode_cmds[:submodes][mode_name]
      ret, msg = set(submode_hash, sub_name)
      return false, msg if ret == false
    end

    return true, "Set mode #{new_mode} SUCCESSFUL"
  end

  ###########################################################################
  # VIDEO METHODS
  ###########################################################################

  # Check the YY command response input line for ACK, ERR, some PARAM (optional)
  #
  # Returns: ok=true|false, msg, arg(optional)
  # Input  : expected response format string
  # Description:
  #  X1. reads the response packet from the serial input
  #  2. parses out the response input line
  #  3. parses ack,channel id, error, argument(optional) from input line
  #  4. sets ok, msg, arg (optional)
  #
  #
  def check_response(inline, resp_format, has_arg)
    # @debug=true
    puts "check_response(): inline=#{inline}" if @debug
    puts "check_response(): resp_format=#{resp_format}" if @debug
    puts "check_response(): has_arg=#{has_arg}" if @debug
    arg = ""
    arg2=""
    arg3=""
    ack = "0"
    chid = "0"
    err = "0"
    if inline==nil
      log_warn("check_reponse(): ERROR! inline is NIL!")
      return false
    end
    if has_arg==1
      ack, chid, err, arg = inline.scanf(resp_format)
    elsif has_arg==2
      ack, chid, err, arg, arg2 = inline.scanf(resp_format)
    elsif has_arg==3
      ack, chid, err, arg, arg2, arg3 = inline.scanf(resp_format)
    else
      ack, chid, err = inline.scanf(resp_format)
    end

    puts "check_response() ack=#{ack} err=#{err} arg=#{arg} arg2=#{arg2} arg3=#{arg3}" if @debug

    ok = true
    msg = ""

    if ack != "0"
      msg = "ERROR: BAD ACK\n"
      ok = false
    end

    if chid != @chan_id  ##### KLUDGE!!! Change this to @chan_id
      msg += "ERROR: channel ids don't match #{chid} vs #{@chan_id}"
      ok = false
    end

    if err != "0"
      msg += "ERROR #{err}: command FAILED\n"
      ok = false
    end

    msg = "OK" if ok
    # @debug=false

    return ok, msg, arg, arg2, arg3

  end  # check_response()

  def set_video_sub_mode(x)
    verify = false
    verify = true
    result,msg,verified = set(video_sub_mode_cmds, x, @wait_time, verify, @retries)
    log_warn(msg) if !result
    @curr_video_submode = x if result and verified
    return verified
  end

  def get_video_sub_mode()
    result, msg, val = get(video_sub_mode_cmds)
    if result
      i_cmds = video_sub_mode_cmds[:settings].invert
      puts "video_sub_mode =#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_video_submode = i_cmds[val.to_i]
      return @curr_video_submode
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_sub_mode(submode_hash, x)
    verify = true
    result,msg,verified = set(submode_hash, x, @wait_time, verify, @retries)
    log_warn(msg) if !result
    return verified
  end

  def set_video_def_sub_mode(x)
    @verify = true
    result,msg,verified = set(video_def_sub_mode_cmds, x, @wait_time, @verify, @retries)
    @curr_video_def_submode = x if result and verified
    log_warn(msg) if !result
    return verified
  end

  def set_video_resolution(x)
    result, msg = set_video(@curr_video_format, x, @curr_video_fps, @curr_video_fov)
    return result
  end

  def set_video_fps(x)
    result, msg = set_video(@curr_video_format, @curr_video_res, x, @curr_video_fov)
    return result
  end

  def set_video_fov(x)
    result, msg = set_video(@curr_video_format, @curr_video_res, @curr_video_fps, x)
    return result
  end

  ## SET_VIDEO()
  #
  # This is a COMBO function - sets 4 things at once
  # NOTE: these args in are in "key" string format, not actual GCCB command values
  # NOTE: vid_fmt is presently a dummy argument (NOT SET HERE).
  #
  def set_video(vid_fmt, vid_res, vid_fps, vid_fov)

    puts "\nset_video(#{vid_fmt},#{vid_res},#{vid_fps},#{vid_fov})"
    verified = set_video_mode(vid_fmt)
    if not verified
      return verified, "ERROR trying to set video format to #{vid_fmt}"
    end
    result, msg, verified = set_multiple(vid_res_cmds, vid_res, vid_fps_cmds, vid_fps, vid_fov_cmds, vid_fov, @verify)
    @curr_video_res = vid_res if verified
    @curr_video_fps = vid_fps if verified
    @curr_video_fov = vid_fov if verified

    #SAVE
    #@curr_video_res = vid_res_cmds[:settings].invert[vid_res.to_i] if verified
    #@curr_video_fps = vid_fps_cmds[:settings].invert[vid_fps.to_i] if verified
    #@curr_video_fov = vid_fov_cmds[:settings].invert[vid_fov.to_i] if verified

    log_warn(msg) if !result
    #return false, "Unable to set video RESOLUTION to #{vid_res}" if result == false
    return verified, msg
  end

  def get_video_res(x)
    result, msg, res, fps, fov = get_video_settings()
    return fps if result
    log_warn(msg)
    puts msg if @debug
    return nil,msg
  end

  def get_video_fps()
    result, msg, res, fps, fov = get_video_settings()
    return fps if result
    log_warn(msg)
    puts msg if @debug
    return nil,msg
  end

  def get_video_settings()
    puts "get_video_settings()" if @debug
    result, msg, xres, xfps, xfov = get(vid_fps_cmds)
    if result
      ifps = vid_fps_cmds[:settings].invert
      ires = vid_res_cmds[:settings].invert
      ifov = vid_fov_cmds[:settings].invert
      # len=hex[0][0].to_i(16)  # Note: the length of the "in:" response string is in ascii HEX
      res_name = ires[xres.to_i]
      fps_name = ifps[xfps.to_i(16)]
      fov_name = ifov[xfov.to_i]
      puts "result=#{result}"
      puts "res=#{xres} #{res_name}"
      puts "fps=#{xfps} #{fps_name}"
      puts "fov=#{xfov} #{fov_name}"
      @curr_video_res = res_name
      @curr_video_fps = fps_name
      @curr_video_fov = fov_name
      return result, msg, res_name, fps_name, fov_name
    else
      puts msg
      return nil
    end
  end

  def get_video_settings_SAVE()
    puts "get_video_settings()"
    #resp, msg = get(vid_fps_cmds)
    cmd = vid_fps_cmds[:get] % @chan_id
    send_serial(cmd)
    resp = read_serial_resp()
    inline   = get_resp_in(resp)
    ##inline = inline[0][0]
    #inline = inline[0]
    #inline = inline.chomp
    ##inline = inline.to_s
    puts "inline=#{inline}"

    # inline=D 0 0 0 10 C7 2 2 0 0 3 9 8 0

    #NOT WORKING, BUT WORKS in regx.rb # video_params = inline.scan(video_cmds[:get_regx])
    ack, ch, err, res, xfps, xfov  = inline.scanf(video_cmds[:get_resp])
    ifps = vid_fps_cmds[:settings].invert
    ires = vid_res_cmds[:settings].invert
    ifov = vid_fov_cmds[:settings].invert
    puts "ack=#{ack}"
    puts "ch=#{ch}"
    puts "err=#{err}"
    puts "fps=#{xfps} #{ifps[xfps.to_i]}"
    puts "fov=#{xfov} #{ifov[xfov.to_i]}"
    puts "res=#{res} #{ires[res.to_i]}"
  end
    
  ### VIDEO PIV INTERVAL
  # 1dec15
  def set_piv(x);                  return set_video_piv_interval(x); end
  def get_piv();                   return get_video_piv_interval(); end
  def set_video_piv_interval(x)
    puts "set_video_piv_interval(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_piv_interval_cmds, x, @wait_time, @verify)
    @curr_video_piv_interval = x if verified
    return verified
  end
  def get_video_piv_interval()
    result, msg, value = get(video_piv_interval_cmds)
    if result
      i_cmds = video_piv_interval_cmds[:settings].invert
      puts "get__video_piv_interval=#{value} #{i_cmds[value.to_i]}" if @debug
      @curr_video_piv_interval = i_cmds[value.to_i]
      return @curr_video_piv_interval
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 1dec15
  def set_video_timelapse_rate(x)
    return set_video_timelapse_interval(x)
  end

  def set_video_timelapse_interval(x)
    puts "set_video_timelapse_interval(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_timelapse_interval_cmds, x, @wait_time, @verify)
    @curr_video_timelapse_interval = x if verified
    return verified
  end
  def get_video_timelapse_interval()
    result, msg, timelapse_int_val = get(video_timelapse_interval_cmds)
    if result
      i_timelapse_int_cmds = video_timelapse_interval_cmds[:settings].invert
      puts "get__video_timelapse_interval=#{timelapse_int_val} #{i_timelapse_int_cmds[timelapse_int_val.to_i]}" if @debug
      @curr_video_timelapse_interval = i_timelapse_int_cmds[timelapse_int_val.to_i]
      return @curr_video_timelapse_interval
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Set the various VIDEO LOOPING times
  def set_video_looping(x); return set_looping(x); end

  def set_looping(x)  # Named for backward compatibility
    puts "set_video_looping(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_looping_cmds, x, @wait_time, @verify)
    @curr_video_looping = x if verified
    return verified
  end

  def get_video_looping(); return get_looping(); end

  def get_looping()  # Named for backward compatibility
    result, msg, vidlooping = get(video_looping_cmds)
    if result
      ividlooping = video_looping_cmds[:settings].invert
      puts "video looping=#{vidlooping} #{ividlooping[vidlooping.to_i]}" if @debug
      @curr_video_looping = ividlooping[vidlooping.to_i]
      return @curr_video_looping
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_video_low_light(x)
    puts "set_video_lowlight(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_lowlight_cmds, x, @wait_time, @verify)
    @curr_video_lowlight = x if verified
    return verified
  end

  def get_video_low_light()
    result, msg, vid_lowlight = get(video_lowlight_cmds)
    if result
      ivid_lowlight = video_lowlight_cmds[:settings].invert
      puts "video lowlight=#{vid_lowlight} #{ivid_lowlight[vid_lowlight.to_i]}" if @debug
      @curr_video_lowlight = ivid_lowlight[vid_lowlight.to_i]
      return @curr_video_lowlight
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_video_spot_metering(x)
    puts "set_video_spot_metering(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_spotmeter_cmds, x, @wait_time, @verify)
    @curr_video_spot_metering = x if verified
    return verified
  end

  def get_video_spot_metering()
    result, msg, vid_spot_metering = get(video_spotmeter_cmds)
    if result
      ivid_spot_metering = video_spotmeter_cmds[:settings].invert
      puts "video spot_metering=#{vid_spot_metering} #{ivid_spot_metering[vid_spot_metering.to_i]}" if @debug
      @curr_video_spot_metering = ivid_spot_metering[vid_spot_metering.to_i]
      return @curr_video_spot_metering
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_video_protune(x)
    puts "set_video_protune(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_cmds, x, @wait_time, @verify)
    @curr_video_protune = x if verified
    return verified
  end

  def get_video_protune()
    result, msg, vidprotunes = get(video_protune_cmds)
    if result
      ividprotunes = video_protune_cmds[:settings].invert
      puts "video protune=#{vidprotunes} #{ividprotunes[vidprotunes.to_i]}" if @debug
      @curr_video_protune = ividprotunes[vidprotunes.to_i]
      return @curr_video_protune
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # For compatibility with WifiCamera
  def set_protune(x);               return set_video_protune(x); end

  ### VIDEO PROTUNE WHITE-BALANCE
  def set_video_protune_whitebalance(x)
    puts "set_video_protune_whitebalance(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_whitebalance_cmds, x, @wait_time, @verify)
    @curr_video_protune_whitebalance = x if verified
    return verified
  end
  def get_video_protune_whitebalance()
    result, msg, vidprotunes_wb = get(video_protune_whitebalance_cmds)
    if result
      ividprotunes_wb = video_protune_whitebalance_cmds[:settings].invert
      puts "video protune_whitebalance=#{vidprotunes_wb} #{ividprotunes_wb[vidprotunes_wb.to_i]}" if @debug
      @curr_video_protune_whitebalance = ividprotunes_wb[vidprotunes_wb.to_i]
      return @curr_video_protune_whitebalance
    else
      puts msg if @debug
      return nil,msg
    end
  end
  def set_video_white_balance(x);   return set_white_balance(x); end
  def get_video_white_balance();    return get_white_balance(); end
  def set_white_balance(x);         return set_video_protune_whitebalance(x); end
  def get_white_balance();          return get_video_protune_whitebalance(); end

  ### VIDEO PROTUNE COLOR
  def set_video_protune_color(x)
    puts "set_video_protune_color(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_color_cmds, x, @wait_time, @verify)
    @curr_video_protune_color = x if verified
    return verified
  end
  def get_video_protune_color()
    result, msg, vidprotunes_color = get(video_protune_color_cmds)
    if result
      ividprotunes_color = video_protune_color_cmds[:settings].invert
      puts "video protune_color=#{vidprotunes_color} #{ividprotunes_color[vidprotunes_color.to_i]}" if @debug
      @curr_video_protune_color = ividprotunes_color[vidprotunes_color.to_i]
      return @curr_video_protune_color
    else
      puts msg if @debug
      return nil,msg
    end
  end
  def set_video_color(x);          return set_video_protune_color(x); end
  def get_video_color();           return get_video_protune_color(); end

  ### VIDEO PROTUNE ISO 1dec15
  def set_video_protune_iso(x)
    puts "set_video_protune_iso(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_iso_cmds, x, @wait_time, @verify)
    @curr_video_protune_iso = x if verified
    return verified
  end
  def get_video_protune_iso()
    result, msg, value = get(video_protune_iso_cmds)
    if result
      icmds = video_protune_iso_cmds[:settings].invert
      puts "video protune_iso=#{value} #{icmds[value.to_i]}" if @debug
      @curr_video_protune_iso = icmds[value.to_i]
      return @curr_video_protune_iso
    else
      puts msg if @debug
      return nil,msg
    end
  end
  def set_video_iso(x);            return set_video_protune_iso(x); end
  def get_video_iso();             return get_video_protune_iso(); end

  ### VIDEO PROTUNE SHARPNESS 1dec15
  def set_video_protune_sharpness(x)
    puts "set_video_protune_sharpness(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_sharpness_cmds, x, @wait_time, @verify)
    @curr_video_protune_sharpness = x if verified
    return verified
  end
  def get_video_protune_sharpness()
    result, msg, value = get(video_protune_sharpness_cmds)
    if result
      icmds = video_protune_sharpness_cmds[:settings].invert
      puts "video protune_sharpness=#{value} #{icmds[value.to_i]}" if @debug
      @curr_video_protune_sharpness = icmds[value.to_i]
      return @curr_video_protune_sharpness
    else
      puts msg if @debug
      return nil,msg
    end
  end
  def set_video_sharpness(x);      return set_video_protune_sharpness(x); end
  def get_video_sharpness();       return get_video_protune_sharpness(); end

  # 3dec15
  # RETURNS: true or false , if camera is capable of all these settings specified
  def get_video_all_capabilities(filter, format, res, fps, fov)

    settings_list = "#{filter}, #{format}, #{res}, #{fps}, #{fov}"
    puts "get_video_all_capabilities(#{settings_list})" if @debug

    filter_val = video_get_all_capabilities_cmd[:filters][filter]
    format_val = vid_mode_cmds[:settings][format]
    res_val    = vid_res_cmds[:settings][res]
    fps_val    = vid_fps_cmds[:settings][fps]
    fov_val    = vid_fov_cmds[:settings][fov]

    get_command = video_get_all_capabilities_cmd[:get] % [ @chan_id,  filter_val, format_val, res_val, fps_val, fov_val ]

    result, msg, err, len, cap_sVal = get_list(video_get_all_capabilities_cmd, get_command)

    puts "cap_sVal=#{cap_sVal[0]}" if @debug
    capable = (cap_sVal[0]=="1") ? true : false

    if result
      puts "len=#{len} capabilities[#{filter},#{format},#{res},#{fps},#{fov}]=#{capable}" if @debug
      # icapabilities = video_get_all_capabilities_cmd[:all_capabilities].invert
      return capable, "ok"
    else
      puts msg
      return false, msg
    end
  end

  # 3dec15
  def get_video_all_fov(filter, format, res, fps)

    fov_list = "#{filter}, #{format}, #{res}, #{fps})"
    puts "get_video_all_fov(#{fov_list})" if @debug

    filter_val = video_get_all_fov_cmd[:filters][filter]
    format_val = vid_mode_cmds[:settings][format]
    res_val    = vid_res_cmds[:settings][res]
    fps_val    = vid_fps_cmds[:settings][fps]

    get_command = video_get_all_fov_cmd[:get] % [ @chan_id,  filter_val, format_val, res_val, fps_val ]

    result, msg, err, len, foves = get_list(video_get_all_fov_cmd, get_command)

    if result==true
      puts "TRUE result: len=#{len} foves[#{filter},#{format},#{res},#{fps}]=#{foves}" if @debug
      ifov = video_get_all_fov_cmd[:all_fov].invert
      @curr_video_all_fov = Array.new(len-1) # create an array that will hold 30 hex values
      n=0
      foves.each_with_index do |fov, i|
        next if i.to_i == 0  # skip the res echo field (right after the length)
        if fov != nil
          @curr_video_all_fov[n] = ifov[fov.to_i(16)] 
          n += 1
        end
      end
      puts "TRUE result: get_video_all_fov() len=#{len} #{@curr_video_all_fov}" # if @debug
      return result, "ok", @curr_video_all_fov
    else
      return result, msg, nil
    end
  end

  # 3dec15
  def get_video_all_fps(filter, format, res)

    puts "get_video_all_fps(#{filter}, #{format}, #{res})" if @debug

    filter_val = video_get_all_fps_cmd[:filters][filter]
    format_val = vid_mode_cmds[:settings][format]
    res_val    = vid_res_cmds[:settings][res]

    get_command = video_get_all_fps_cmd[:get] % [ @chan_id,  filter_val, format_val, res_val ]

    result, msg, err, len, fpses = get_list(video_get_all_fps_cmd, get_command)

    if result==true
      puts "len=#{len} fpses[#{filter},#{format},#{res}]=#{fpses}" if @debug
      ifps = video_get_all_fps_cmd[:all_fps].invert
      @curr_video_all_fps = Array.new(len) # create an array that will hold 30 hex values
      fpses.each_with_index do |fps, i|
        @curr_video_all_fps[i] = ifps[fps.to_i(16)] if fps != nil
      end
      puts "video fps[#{filter},#{format},#{res}] len=#{len} #{@curr_video_all_fps}" if @debug
      return result, "ok", @curr_video_all_fps
    else
      puts msg if @debug
      return result,msg,nil
    end
  end

  # 3dec15
  def get_video_all_resolutions(x)
    puts "get_video_all_resolutions(#{x})" if @debug
    result, msg, err, len, resolutions = get_array(video_get_all_resolutions_cmd,x)
    if result
      puts "len=#{len} resolutions[#{x}]=#{resolutions}" if @debug
      ires = video_get_all_resolutions_cmd[:all_res].invert
      @curr_video_all_resolutions = Array.new(len) # create an array that will hold 30 hex values
      resolutions.each_with_index do |res, i|
        @curr_video_all_resolutions[i] = ires[res.to_i(16)] if res != nil
      end
      puts "video #{x}_resolutions len=#{len} #{@curr_video_all_resolutions}" if @debug
      return result, "ok", @curr_video_all_resolutions
    else
      puts msg if @debug
      return result,msg,nil
    end
  end

  # 2dec15
  def get_video_all_settings()
    result, msg, dm,res,fps,fov,piv,loop,spot,lowlt,tl,pt,color,sharp,iso,ev,wb = get(video_get_all_settings_cmd)
    if result
      puts "dm=#{dm} res=#{res} fps=#{fps} fov=#{fov} piv=#{piv} loop=#{loop} spot=#{spot} lowlt=#{lowlt} tl=#{tl} pt=#{pt} color=#{color} sharp=#{sharp} iso=#{iso} ev=#{ev} wb=#{wb}"
      @curr_video_all_settings = [dm,res,fps,fov,piv,loop,spot,lowlt,tl,pt,color,sharp,iso,ev,wb]
      puts "video all_settings #{@curr_video_all_settings}" if @debug
      return result, "ok", @curr_video_all_settings
    else
      puts msg if @debug
      return result, msg, nil
    end
  end

  # 2dec15
  def get_video_progress_counter()
    result, msg, d3,d2,d1,d0 = get(video_progress_counter_cmd)
    if result
      puts "#{d3} #{d2} #{d1} #{d0}" if @debug
      @curr_video_progress_counter = (d3.to_i(16) << 24) | (d2.to_i(16) << 16) | (d1.to_i(16) << 8) | d0.to_i(16)
      puts "video progress counter #{@curr_video_progress_counter}" if @debug
      return @curr_video_progress_counter
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_video_protune_exposure(x)
    set(video_protune_exposure_cmds, x)
    puts "set_video_protune_exposure(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_exposure_cmds, x, @wait_time, @verify)
    @curr_video_protune_exposure = x if verified
    return verified
  end

  def get_video_protune_exposure()
    puts "get_video_protune_exposure()" if @debug
    result, msg, vid_exp = get(video_protune_exposure_cmds)
    if result
      ividprotunes_exp = video_protune_exposure_cmds[:settings].invert
      puts "video protune_exposure=#{vid_exp} #{ividprotunes_exp[vid_exp.to_i]}" if @debug
      @curr_video_protune_exposure = ividprotunes_exp[vid_exp.to_i]
      return @curr_video_protune_exposure
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Override start_capture()
  def start_capture(retries=2)
    # Try to poll the camera for the current capture mode.
    m = get_current_capture_mode()
    unless m
      log_warn("start_capture(): Defaulting to starting video capture.")
      m = "video"
    end
    return start_video_capture(retries) if m == "video"
    return start_photo_capture(retries) if m == "photo"
    return start_multi_capture(retries) if m == "multi_shot"
    return false, "Unknown capture mode."
  end # start_capture

  # Override stop_capture()
  def stop_capture(retries=2)
    # Try to poll the camera for the current capture mode.
    m = get_current_capture_mode()
    unless m
      log_warn("stop_capture(): Defaulting to stopping video capture.")
      m = "video"
    end
    # We should poll the camera for the current mode and do the right one.
    return stop_video_capture(retries) if m == "video"
    return stop_photo_capture(retries) if m == "photo"
    return stop_multi_capture(retries) if m == "multi_shot"
    return false, "Unknown capture mode."
  end

  # Start capturing video
  def start_video_capture(r=2)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(start_video_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Start video capture failed."
      end
    end
    return result
  end

  # Stop capturing video
  def stop_video_capture(r=2)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(stop_video_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Stop video capture failed."
      end
    end
    return result
  end

  # Start capturing photo. Relocate this?
  # I'm not sure that we should be expecting a response here.
  def start_photo_capture(r=1)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(start_photo_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Start photo capture failed."
      end
    end
    return result,msg,verified
  end

  # Stop capturing photo. Relocate this?
  def stop_photo_capture(r=2)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(stop_photo_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Stop photo capture failed."
      end
    end
    return result
  end

  # Captures video at a given RES/FPS/FOV for a given duration (in seconds)
  # Return status, msg.
  # status is true on success, false on fail.
  # msg holds information on pass/fail reason.
  def capture_video(vm, res, fps, fov, duration=5, ll=nil, spot=nil,
    pt=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
    @last_media = nil
    retries = 2

    (1..retries).each { |n|
      @last_video_attempted = nil
      log_debug("Capture video try #{n} of #{retries}")
      if set_capture_mode("VIDEO") == false
        next if n < retries
        return false, "Unable to set camera mode to VIDEO capture"
      end

      log_debug("Setting ProTune #{pt}")
      ret, msg = set_video_protune(pt)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_debug("Setting capture mode")
      ret, msg = set_video(vm, res, fps, fov)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_debug("Starting capture")
      start_time = Time.now()
      ret, msg = start_capture()
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      elapsed = Time.now() - start_time
      if duration > 5
        sleep (duration - elapsed) if (duration - elapsed) > 0
      else
        sleep duration
      end

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end # end capture_video

  def capture_piv(vm, res, fps, fov, p, duration, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      log_debug("Capture PIV try #{n} of #{retries}")
      ret, msg = set(mode, "VIDEO")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      ret, msg = set(video_sub_mode, "PIV")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      log_info("Setting PIV to #{p}s")
      ret, msg = set_piv(p)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      if ll != nil
        log_info("Setting low-light #{ll}")
        ret, msg = set_video_low_light(ll)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      if spot != nil
        log_info("Setting spot-metering #{spot}")
        ret, msg = set_video_spot_metering(spot)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      @last_video_attempted = nil
      log_debug("Setting capture mode")
      #ntsc_or_pal = (is_ntsc?(res, fps)) ? "NTSC" : "PAL"
      #ret, msg = set_video(ntsc_or_pal, res, fps, fov)
      ret, msg = set_video(vm, res, fps, fov)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_info("Starting capture for #{duration}s")
      start_time = Time.now()
      ret, msg = start_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      dur = duration - (Time.now() - start_time)
      sleep(dur) if dur > 0

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end

  def capture_looping(vm, res, fps, fov, loo, duration, setonly=false, orient=nil, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      log_debug("Capture PIV try #{n} of #{retries}")
      ret, msg = set(mode, "VIDEO")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      ret, msg = set(video_sub_mode, "LOOPING")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      log_debug("Setting capture mode to #{vm}")
      ret, msg = set_video(vm, res, fps, fov)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      log_info(msg)

      vid_remain = get_rem_videos()
      if vid_remain == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, "Unable to query # remaining videos"
      end
      log_verb("Duration=#{duration}s, Space avail=#{vid_remain}s")
      if duration > vid_remain
        return false, "Insufficient space on SD card"
      end

      log_info("Setting looping to #{loo} min.")
      ret, msg = set_looping(loo)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      if ll != nil
        log_info("Setting low-light #{ll}")
        ret, msg = set_video_low_light(ll)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      if spot != nil
        log_info("Setting spot-metering #{spot}")
        ret, msg = set_video_spot_metering(spot)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      return true, "Looping mode successfully set" if setonly == true

      @last_video_attempted = nil
      log_info("Starting capture for #{duration}s")
      start_time = Time.now()
      ret, msg = start_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      sleep(10.0)

      failed_arr = []
      lrvfile = @last_video_attempted[0..-4] + "LRV"
      exp = has_lrv?(res, fps, fov)
      act = media_exists?(lrvfile)
      if exp != act
        failed_arr << "LRV file (#{lrvfile}) presence (exp=#{exp}, act=#{act})"
      end
      log_warn("Skipping thumbnail verification on HD4 looping for now")

      dur = duration - (Time.now() - start_time)
      sleep(dur) if dur > 0

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false
        next if n < retries
        return false, status_msg
      end
      if ret == false
        next if n < retries
        return false, msg
      end
      if not failed_arr.empty?
        return false, failed_arr.join(",")
      end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end

  ###########################################################################
  # PHOTO METHODS
  ###########################################################################
  # These method names should override abstract methods in camera.rb when
  # possible to ensure test-case compatibility

  def set_photo_def_sub_mode(x)
    result,msg,verified = set(photo_def_sub_mode_cmds, x, @wait_time, @verify)
    log_warn(msg) if !result
    @curr_photo_def_submode = x if result and verified
    return verified
  end

  def get_photo_def_sub_mode()
    result, msg, submode = get(photo_def_sub_mode_cmds)
    if result
      i_cmds = photo_def_sub_mode_cmds[:settings].invert
      puts "photo default submode=#{submode} #{i_cmds[submode.to_i]}" if @debug
      @curr_photo_def_submode = i_cmds[submode.to_i]
      return @curr_photo_def_submode
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_photo_sub_mode(x)
    result,msg,verified = set(photo_sub_mode_cmds, x, @wait_time, verify)
    log_warn(msg) if !result
    @curr_photo_submode = x if result and verified
    return verified
  end

  def set_photo_res(x)
    puts "set_photo_res(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_res_cmds, x, @wait_time, @verify)
    @curr_photo_res = x if verified
    return verified
  end

  def get_photo_res()
    result, msg, photo_res = get(photo_res_cmds)
    if result
      i_cmds = photo_res_cmds[:settings].invert
      puts "photo resolution=#{photo_res} #{i_cmds[photo_res.to_i]}" if @debug
      @curr_photo_res = i_cmds[photo_res.to_i]
      return @curr_photo_res
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Photo Continuous Shutter Speed/Rate (ie - 3|5|10 photos/s
  def set_sps(x)
    puts "set photo continuous shutter rate(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_sps_cmds, x, @wait_time, @verify)
    @curr_photo_continuous_rate = x if verified
    return verified
  end

  def get_sps()
    result, msg, val = get(photo_sps_cmds)
    if result
      i_cmds = photo_sps_cmds[:settings].invert
      puts "photo continuous rate=#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_photo_continuous = i_cmds[val.to_i]
      return @curr_photo_continuous_rate
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 12.4.15
  def set_photo_spot_metering(x)
    puts "set_photo_spot_metering(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_spotmeter_cmds, x, @wait_time, @verify)
    @curr_photo_spot_metering = x if verified
    return verified
  end
  def get_photo_spot_metering()
    result, msg, photo_spot_metering = get(photo_spotmeter_cmds)
    if result
      iphoto_spot_metering = photo_spotmeter_cmds[:settings].invert
      puts "photo spot_metering=#{photo_spot_metering} #{iphoto_spot_metering[photo_spot_metering.to_i]}" if @debug
      @curr_photo_spot_metering = iphoto_spot_metering[photo_spot_metering.to_i]
      return @curr_photo_spot_metering
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_photo_protune(x)
    puts "set_photo_protune(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_protune_cmds, x, @wait_time, @verify)
    @curr_photo_protune = x if verified
    return verified
  end

  def get_photo_protune()
    result, msg, vidprotunes = get(photo_protune_cmds)
    if result
      i_cmds = photo_protune_cmds[:settings].invert
      puts "photo protune=#{vidprotunes} #{i_cmds[vidprotunes.to_i]}" if @debug
      @curr_photo_protune = i_cmds[vidprotunes.to_i]
      return @curr_photo_protune
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 4dec15
  def get_photo_all_settings()
    result, msg, dm,cm,res,cont_rate,spot,exp_time,pt,color,sharp,iso,ev,wb,iso_min= get(photo_get_all_settings_cmd)
    if result
      puts "dm=#{dm} cm=#{cm} res=#{res} cont_rate=#{cont_rate} spot=#{spot} exp_time=#{exp_time} pt=#{pt} color=#{color} sharp=#{sharp} iso=#{iso} ev=#{ev} wb=#{wb} iso_min=#{iso_min}" if @debug
      @curr_photo_all_settings = [dm,cm,res,cont_rate,spot,exp_time,pt,color,sharp,iso,ev,wb,iso_min]
      puts "photo all_settings #{@curr_photo_all_settings}" if @debug
      return @curr_photo_all_settings
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 4dec15
  # Photo Protune RESET
  def set_photo_protune_reset()
    puts "set_photo_protune_reset()" if @debug
    result,msg,verified = set(photo_protune_reset_cmd, nil, @wait_time, @noverify)
    return result
  end

  # Photo White Balance 12.4.15
  def set_photo_white_balance(x)
    puts "set_photo_white_balance(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_white_balance_cmds, x, @wait_time, @verify)
    @curr_photo_whitebalance = x if verified
    return verified
  end
  def get_photo_white_balance()
    puts "get_photo_white_balance()" if @debug
    result, msg, val = get(photo_white_balance_cmds)
    if result
      i_cmds = photo_white_balance_cmds[:settings].invert
      puts "photo protune_whitebalanceosure=#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_photo_whitebalance = i_cmds[val.to_i]
      return @curr_photo_whitebalance
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Photo Color 12.4.15
  def set_photo_color(x)
    puts "set_photo_color(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_color_cmds, x, @wait_time, @verify)
    @curr_photo_color = x if verified
    return verified
  end
  def get_photo_color()
    puts "get_photo_color()" if @debug
    result, msg, val = get(photo_color_cmds)
    if result
      i_cmds = photo_color_cmds[:settings].invert
      puts "photo color=#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_photo_color = i_cmds[val.to_i]
      return @curr_photo_color
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Photo ISO
  def set_photo_iso(x)
    puts "set_photo_iso(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_iso_cmds, x, @wait_time, @verify)
    @curr_photo_iso = x if verified
    return verified
  end
  def get_photo_iso()
    puts "get_photo_iso()" if @debug
    result, msg, value = get(photo_iso_cmds)
    if result
      i_cmds = photo_iso_cmds[:settings].invert
      puts "photo iso=#{value} #{i_cmds[value.to_i]}" if @debug
      @curr_photo_iso = i_cmds[value.to_i]
      return @curr_photo_iso
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Photo Sharpness
  def set_photo_sharpness(x)
    puts "set_photo_sharpness(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_sharpness_cmds, x, @wait_time, @verify)
    @curr_photo_sharpness = x if verified
    return verified
  end
  def get_photo_sharpness()
    puts "get_photo_sharpness()" if @debug
    result, msg, value = get(photo_sharpness_cmds)
    if result
      i_cmds = photo_sharpness_cmds[:settings].invert
      puts "photo sharpness=#{value} #{i_cmds[value.to_i]}" if @debug
      @curr_photo_sharpness = i_cmds[value.to_i]
      return @curr_photo_sharpness
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Photo Exposure Times
  def set_photo_exp(x)
    puts "set_photo_exp(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_exp_cmds, x, @wait_time, @verify)
    @curr_photo_exposure_time = x if verified
    return verified
  end
  def get_photo_exp()
    puts "get_photo_exp()" if @debug
    result, msg, exp_time = get(photo_exp_cmds)
    if result
      i_cmds = photo_exp_cmds[:settings].invert
      puts "photo protune_exposure=#{exp_time} #{i_cmds[exp_time.to_i]}" if @debug
      @curr_photo_exposure_time = i_cmds[exp_time.to_i]
      return @curr_photo_exposure_time
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_photo_protune_exposure(x)
    set(photo_protune_exposure_cmds, x)
    puts "set_photo_protune_exposure(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_protune_exposure_cmds, x, @wait_time, @verify)
    @curr_photo_protune_exposure = x if verified
    return verified
  end

  def get_photo_protune_exposure()
    puts "get_photo_protune_exposure()" if @debug
    result, msg, photo_exp = get(photo_protune_exposure_cmds)
    if result
      i_cmds = photo_protune_exposure_cmds[:settings].invert
      puts "photo protune_exposure=#{photo_exp} #{i_cmds[photo_exp.to_i]}" if @debug
      @curr_photo_protune_exposure = i_cmds[photo_exp.to_i]
      return @curr_photo_protune_exposure
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def capture_photo_single(res, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
  end

  def capture_photo_continuous(res, sps, duration=5.0, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil, quickpress=false)
  end

  ###########################################################################
  # MULTI-SHOT METHODS
  ###########################################################################

  def set_multi_sub_mode(x)
    result,msg,verified = set(multi_sub_mode_cmds, x, @wait_time, verify)
    log_warn(msg) if !result
    @curr_multi_submode = x if result and verified
    return verified
  end

  def set_multi_def_sub_mode(x);    return set(multi_def_sub_mode_cmds, x); end

  def set_multi_res(x)
    puts "set_multi_res(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_res_cmds, x, @wait_time, @verify)
    @curr_multi_res = x if verified
    return verified
  end

  def get_multi_res()
    result, msg, multi_res = get(multi_res_cmds)
    if result
      i_cmds = multi_res_cmds[:settings].invert
      puts "multi resolution=#{multi_res} #{i_cmds[multi_res.to_i]}" if @debug
      @curr_multi_res = i_cmds[multi_res.to_i]
      return @curr_multi_res
    else
      puts msg if @debug
      return nil,msg
    end
  end


  def set_multi_burst(x); return set_burst(x); end
  def get_multi_burst(x); return get_burst(); end

  def set_burst(x)
    puts "set_burst(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_burst_cmds, x, @wait_time, @verify)
    @curr_multi_burst_rate = x if verified
    return verified
  end

  def get_burst()
    result, msg, val = get(multi_burst_cmds)
    if result
      i_cmds = multi_burst_cmds[:settings].invert
      puts "multi burst rate =#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_multi_burst_rate = i_cmds[val.to_i]
      return @curr_multi_burst_rate
    else
      puts msg if @debug
      return nil,msg
    end
  end


  # 12.7.15
  def set_multi_spot_metering(x)
    puts "set_multi_spot_metering(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_spotmeter_cmds, x, @wait_time, @verify)
    @curr_multi_spot_metering = x if verified
    return verified
  end
  def get_multi_spot_metering()
    result, msg, value = get(multi_spotmeter_cmds)
    if result
      icmds = multi_spotmeter_cmds[:settings].invert
      puts "night spot_metering=#{value} #{icmds[value.to_i]}" if @debug
      @curr_multi_spot_metering = icmds[value.to_i]
      return @curr_multi_spot_metering
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 12.7.15
  def set_night_lapse(x);            return set_multi_nightlapse_interval(x); end
  def get_night_lapse(x);            return get_multi_nightlapse_interval(); end
  def set_multi_nightlapse_rate(x)
    return set_multi_nightlapse_interval(x)
  end
  def set_multi_nightlapse_interval(x)
    puts "set_multi_nightlapse_interval(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_nightlapse_cmds, x, @wait_time, @verify)
    @curr_multi_nightlapse_interval = x if verified
    return verified
  end
  def get_multi_nightlapse_interval()
    result, msg, value = get(multi_nightlapse_cmds)
    puts "nightlapse interval rate=#{value}" if @debug
    if result
      i_cmds = multi_nightlapse_cmds[:settings].invert
      puts "get_multi_nightlapse_interval=#{value} \"#{i_cmds[value.to_i]}\"" if @debug
      @curr_multi_nightlapse_interval = i_cmds[value.to_i]
      return @curr_multi_nightlapse_interval
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_time_lapse(x);            return set_multi_timelapse_interval(x); end
  def set_multi_timelapse_rate(x)
    return set_multi_timelapse_interval(x)
  end
  def set_multi_timelapse_interval(x)
    puts "set_multi_timelapse_interval(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_timelapse_interval_cmds, x, @wait_time, @verify)
    @curr_multi_timelapse_interval = x if verified
    return verified
  end

  def get_multi_timelapse_interval()
    result, msg, timelapse_int_val = get(multi_timelapse_interval_cmds)
    puts "timelapse_int_val=#{timelapse_int_val}"
    if result
      i_timelapse_int_cmds = multi_timelapse_interval_cmds[:settings].invert
      puts "get_multi_timelapse_interval=#{timelapse_int_val} \"#{i_timelapse_int_cmds[timelapse_int_val.to_i]}\"" if @debug
      @curr_multi_timelapse_interval = i_timelapse_int_cmds[timelapse_int_val.to_i]
      return @curr_multi_timelapse_interval
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_multi_protune(x)
    puts "set_multi_protune(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_protune_cmds, x, @wait_time, @verify)
    @curr_multi_protune = x if verified
    return verified
  end

  def get_multi_protune()
    result, msg, pt_onoff = get(multi_protune_cmds)
    if result
      i_cmds = multi_protune_cmds[:settings].invert
      puts "multi protune=#{pt_onoff} #{i_cmds[pt_onoff.to_i]}" if @debug
      @curr_multi_protune = i_cmds[pt_onoff.to_i]
      return @curr_multi_protune
    else
      puts msg if @debug
      return nil,msg
    end
  end


  # def set_multi_color(x);           return set(multi_color_cmds, x); end

  # def set_multi_iso(x);             return set(multi_iso_cmds, x); end

  # def set_multi_sharpness(x);       return set(_cmdsmulti_sharpness, x); end

  # 7dec15
  def get_multi_shot_countdown()
    result, msg, d3, d2, d1, d0 = get(multi_get_shot_countdown_cmd)
    if result
      puts "d0=#{d0} d1=#{d1} d2=#{d2} d3=#{d3}" if @debug
      i3 = (d3.to_i(16) << 24) 
      i2 = (d2.to_i(16) << 16) 
      i1 = (d1.to_i(16) << 8) 
      i0 = d0.to_i(16)
      puts "i0=#{i0} i1=#{i1} i2=#{i2} i3=#{i3}" if @debug
      @curr_multi_shot_countdown = (d3.to_i(16) << 24) | (d2.to_i(16) << 16) | (d1.to_i(16) << 8) | d0.to_i(16)
      puts "multi shot_countdown #{@curr_multi_shot_countdown}" if @debug
      return @curr_multi_shot_countdown
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 7dec15
  def get_multi_all_settings()
    result, msg, dm,cm,res,cont_rate,tlrate,nlrate,spot,exp_time,pt,color,sharp,iso,evcomp,wb,iso_min= get(multi_get_all_settings_cmd)
    if result
      puts "dm=#{dm} cm=#{cm} res=#{res} cont_rate=#{cont_rate} tlrate=#{tlrate} nlrate=#{nlrate} spot=#{spot} exp_time=#{exp_time} pt=#{pt} color=#{color} sharp=#{sharp} iso=#{iso} evcomp=#{evcomp} wb=#{wb} iso_min=#{iso_min}" # if @debug
      @curr_multi_all_settings = [dm,cm,res,cont_rate,tlrate,nlrate,spot,exp_time,pt,color,sharp,iso,evcomp, wb, iso_min]
      puts "multi all_settings #{@curr_multi_all_settings}" if @debug
      return @curr_multi_all_settings
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 7dec15
  # Multi Protune RESET
  def set_multi_protune_reset()
    puts "set_multi_protune_reset()" if @debug
    result,msg,verified = set(multi_protune_reset_cmd, nil, @wait_time, @noverify)
    return result
  end

  # Multi White Balance 12.7.15
  def set_multi_white_balance(x)
    puts "set_multi_white_balance(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_white_balance_cmds, x, @wait_time, @verify)
    @curr_multi_whitebalance = x if verified
    return verified
  end
  def get_multi_white_balance()
    puts "get_multi_white_balance()" if @debug
    result, msg, val = get(multi_white_balance_cmds)
    if result
      i_cmds = multi_white_balance_cmds[:settings].invert
      puts "multi white_balance=#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_multi_whitebalance = i_cmds[val.to_i]
      return @curr_multi_whitebalance
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Multi Color 12.7.15
  def set_multi_color(x)
    puts "set_multi_color(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_color_cmds, x, @wait_time, @verify)
    @curr_multi_color = x if verified
    return verified
  end
  def get_multi_color()
    puts "get_multi_color()" if @debug
    result, msg, val = get(multi_color_cmds)
    if result
      i_cmds = multi_color_cmds[:settings].invert
      puts "multi color=#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_multi_color = i_cmds[val.to_i]
      return @curr_multi_color
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Multi ISO
  def set_multi_iso(x)
    puts "set_multi_iso(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_iso_cmds, x, @wait_time, @verify)
    @curr_multi_iso = x if verified
    return verified
  end
  def get_multi_iso()
    puts "get_multi_iso()" if @debug
    result, msg, value = get(multi_iso_cmds)
    if result
      i_cmds = multi_iso_cmds[:settings].invert
      puts "multi iso=#{value} #{i_cmds[value.to_i]}" if @debug
      @curr_multi_iso = i_cmds[value.to_i]
      return @curr_multi_iso
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # Multi Sharpness
  def set_multi_sharpness(x)
    puts "set_multi_sharpness(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_sharpness_cmds, x, @wait_time, @verify)
    @curr_multi_sharpness = x if verified
    return verified
  end
  def get_multi_sharpness()
    puts "get_multi_sharpness()" if @debug
    result, msg, value = get(multi_sharpness_cmds)
    if result
      i_cmds = multi_sharpness_cmds[:settings].invert
      puts "multi sharpness=#{value} #{i_cmds[value.to_i]}" if @debug
      @curr_multi_sharpness = i_cmds[value.to_i]
      return @curr_multi_sharpness
    else
      puts msg if @debug
      return nil,msg
    end
  end


  # Multi Exposure Times
  # 12.7.15
  def set_multi_protune_shutter_exposure(x); return set_multi_exp(x); end
  def get_multi_protune_shutter_exposure(); return get_multi_exp(); end
  def set_multi_exp(x)
    puts "set_multi_exp(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_exp_cmds, x, @wait_time, @verify)
    @curr_multi_exposure_time = x if verified
    return verified
  end
  def get_multi_exp()
    puts "get_multi_exp()" if @debug
    result, msg, exp_time = get(multi_exp_cmds)
    if result
      i_cmds = multi_exp_cmds[:settings].invert
      puts "multi protune_exposure=#{exp_time} #{i_cmds[exp_time.to_i]}" if @debug
      @curr_multi_exposure_time = i_cmds[exp_time.to_i]
      return @curr_multi_exposure_time
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_multi_protune_exposure(x)
    puts "set_multi_protune_exposure(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_protune_exposure_cmds, x, @wait_time, @verify)
    @curr_multi_protune_exposure = x if verified
    return verified
  end

  def get_multi_protune_exposure()
    puts "get_multi_protune_exposure()" if @debug
    result, msg, multi_exp = get(multi_protune_exposure_cmds)
    if result
      i_cmds = multi_protune_exposure_cmds[:settings].invert
      puts "multi protune_exposure=#{multi_exp} #{i_cmds[multi_exp.to_i]}" if @debug
      @curr_multi_protune_exposure = i_cmds[multi_exp.to_i]
      return @curr_multi_protune_exposure
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_multi_capture(x);         return set(multi_capture_cmds, x); end

  # This one wasn't abstracted properly. Calls the correct method above.
  def set_multi_photo_burst(x);     return set_burst(x); end

  def capture_multi_photo_burst(res, bu, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    tries = 2
    (1..tries).each { |n|
      log_info("Capturing #{res} #{bu} burst (try #{n} of #{tries})")
      ret = false
      msg = "Failed to set multi_shot burst mode"
      (1..3).each {
        ret, msg = set(mode_sub_mode_cmds, "MULTI_BURST")
        next if ret == false
        break
      }
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_multi_res(res)
      if ret == false
        next if n < tries
        return false, msg
      end
      ret, msg = set_burst(bu)
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_multi_spot_metering(spot) if spot != nil
      if ret == false
        next if n < tries
        return false, msg
      end

      if pt !=nil
        ret, msg = set_multi_protune(pt)
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_white_balance(wb) if wb != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_color(col) if col != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_iso(iso) if iso != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_sharpness(sh) if sh != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_protune_exposure(ex) if ex != nil
        if ret == false
          next if n < tries
          return false, msg
        end
      end # end pt
      sleep(3.0)

      set(multi_capture_cmds, "START", wait_time=0, verify=false)
      resp = expect(/C:.*JPG/, timeout=5, limit=1.0)
      if resp == nil
        next if n < tries
        return false, "Burst capture failed"
      end
      matchgroup = resp.match(/C:.*JPG/)
      wait_until_not_busy(interval=1.0, timeout=30)
      return true, "Capture successful. First file=#{matchgroup[0]}"
    }
  end

  def start_multi_capture(r=3, interval=3.0)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(start_multi_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Start multi capture failed."
      end
    end
    return result
  end

  def stop_multi_capture(r=3, interval=3.0)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(stop_multi_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "stop multi capture failed."
      end
    end
    return result
  end

  def capture_multi_photo_nightlapse(res, pes, duration, orient=nil, spot=nil, pt=nil, se=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    #    iso = nil
    #    min_photos = 2
    #    min_length = 10
    capture_multi_photo_timelapse(res, pes, duration, orient, spot, pt, wb, col,
    sh, iso, ex, multi_mode="NIGHT_LAPSE", se)
  end

  ###########################################################################
  # SETUP/SETTINGS
  ###########################################################################
  def set_lcd_brightness(x)
    set(lcd_brightness_cmds, x)
    log_info("set_lcd_brightness(\"#{x}\")")
    result, msg, verified = set(lcd_brightness_cmds, x)
    if result == true
      @current_lcd_brightness = x if verified
    else
      puts "WARN: msg=#{msg}"
      puts "set_lcd_brightness() ***FAILED*** to set mode to #{@current_lcd_brightness}"
    end
    return verified
  end

  def set_lcd_auto_off(x); return set(lcd_auto_off_cmds, x); end

  def set_orientation(x); return set(orientation_cmds, x); end

  def set_default_capture_mode(x)
    set(default_mode_cmds, x)
    log_info("set_default_capture_mode(\"#{x}\")")
    result, msg, verified = set(default_mode_cmds, x)
    if result == true
      @current_default_mode = x if verified
    else
      puts "WARN: msg=#{msg}"
      puts "set_mode() ***FAILED*** to set mode to #{new_mode}"
    end
    return verified
  end

  # Quick capture mode set on/off (true/false)
  def set_obm(x)
    puts "set_obm(\"#{x}\"\)" if @debug
    result,msg,verified = set(obm_cmds, x, @wait_time, @verify)
    @curr_quick_capture_mode = x if verified
    return verified
  end

  def set_quickcapture(x); return set_obm(x); end

  def get_quickcapture()
    result, msg, val = get(obm_cmds)
    if result
      i_cmds = obm_cmds[:settings].invert
      puts "quick capture mode =#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_quick_capture_mode = i_cmds[val.to_i]
      return @curr_quick_capture_mode
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_led(x)
    puts "set_led(\"#{x}\"\)" if @debug
    result,msg,verified = set(led_cmds, x, @wait_time, @verify)
    @curr_leds = x if verified
    return verified
  end
  def get_led()
    result, msg, val = get(led_cmds)
    if result
      i_cmds = led_cmds[:settings].invert
      puts "get_led() =  #{val} #{i_cmds[val.to_i]}" if @debug
      @curr_leds = i_cmds[val.to_i]
      return @curr_leds
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_beep_sound(x); return set_beeps(x); end
  def set_beeps(x)
    puts "set_beeps(\"#{x}\"\)" if @debug
    result,msg,verified = set(beep_sound_cmds, x, @wait_time, @verify)
    @curr_beeps = x if verified
    return verified
  end
  def get_beeps()
    result, msg, val = get(beep_sound_cmds)
    if result
      i_cmds = beep_sound_cmds[:settings].invert
      puts "get_beep() =  #{val} #{i_cmds[val.to_i]}" if @debug
      @curr_beeps = i_cmds[val.to_i]
      return @curr_beeps
    else
      puts msg if @debug
      return nil,msg
    end
  end


  # Backward compatible command
  def set_osd(x); return set_pb_osd_onoff(x); end

  def set_pb_osd_onoff(x)
    puts "set playback osd(\"#{x}\"\)" if @debug
    result,msg,verified = set(playback_osd_cmds, x, @wait_time, @verify)
    @curr_pb_osd_onoff = x if verified
    return verified
  end

  def get_pb_osd_onoff()
    result, msg, val = get(playback_osd_cmds)
    if result
      i_cmds = playback_osd_cmds[:settings].invert
      puts "playback osd =#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_pb_osd_onoff = i_cmds[val.to_i]
      return @curr_pb_osd_onoff
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_locate_camera(x)
    puts "set locate camera(\"#{x}\"\)" if @debug
    result,msg,verified = set(locate_camera_cmds, x, @wait_time, @verify)
    @curr_locate_camera = x if verified
    return verified
  end

  def get_locate_camera()
    result, msg, val = get(locate_camera_cmds)
    if result
      i_cmds = locate_camera_cmds[:settings].invert
      puts "get locate_camera =#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_locate_camera = i_cmds[val.to_i]
      return @curr_locate_camera
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # EXAMPLE:
  # CMD SET: YY 0 0 <ch> 7 1B 0 7 <Y1> <Y2> <M> <D> <H> <M> <S>
  # TIME FORMAT : Y1 Y2 MON DAY HOUR MIN SEC DOW(day of week)
  # ACTUAL TIME PORTION: 7 DF 9 9 13 12 A 3
  # Y1+Y2=7DF
  # converted to int =2015
  # 2015 9 9 19 18 10, 3
  # @curr_camera_time = 2015 9 9 19 18 10 dow:3
  def set_camera_time(year,mon,day,hour,min,sec)
    puts "set_camera_time()" if @debug
    puts "#{year} #{mon} #{day} #{hour} #{min} #{sec}" if @debug
    # Split up the year into two bytes
    y1 = (year.to_i >> 8) & 0xFF
    y2 = year.to_i & 0xFF
    y1 = y1.to_s(16)
    y2 = y2.to_s(16)
    time_cmd = "%s %s %s %s %s %s %s" % [ y1, y2, mon.to_s(16), day.to_s(16), hour.to_s(16), min.to_s(16), sec.to_s(16)]
    time_cmd.upcase!
    # x is the date/time string in the following format:
    puts "set camera time_cmd== (\"#{time_cmd}\"\)" if @debug
    dont_verify = false
    result,msg,verified = set(camera_time_cmds, time_cmd, @wait_time, dont_verify)
    return result
  end

  # EXAMPLE:
  # RESPONSE: 12 0 0 0 10 13 7 1A 0 0 8 7 DF 9 9 13 12 A 3
  # TIME FORMAT : Y1 Y2 MON DAY HOUR MIN SEC DOW(day of week)
  # ACTUAL TIME PORTION: 7 DF 9 9 13 12 A 3
  # Y1+Y2=7DF
  # converted to int =2015
  # 2015 9 9 19 18 10, 3
  # @curr_camera_time = 2015 9 9 19 18 10 dow:3
  def get_camera_time()
    puts "get_camera_time()" if @debug
    result, msg, y1, y2,mon,day,hour,min,sec,dow = get(camera_time_cmds)
    puts "#{y1} #{y2} #{mon} #{day} #{hour} #{min} #{sec} #{dow}" if @debug
    year=""
    if result
      #year, mon, day, hour, min, sec  = val.scanf("%s %s %s %s %s %s")
      #is_a_str = year.is_a? String
      #puts "year.is_a string?=#{is_a_str}"
      #tmp = (y1.to_i << 8) + y2.to_i
      tmp = y1 + y2
      tmp = tmp.to_i(16)
      year = tmp.to_s
      mon  = mon.to_i(16).to_s
      day  = day.to_i(16).to_s
      hour = hour.to_i(16).to_s
      min  = min.to_i(16).to_s
      sec  = sec.to_i(16).to_s
      dow   = dow.to_i(16).to_s
      puts "#{year} #{mon} #{day} #{hour} #{min} #{sec} DayOfWeek#{dow}" if @debug
      @curr_camera_time = "%s %s %s %s %s %s" % [year, mon, day, hour, min, sec] # Can use this to re-set time
      puts "@curr_camera_time = #{@curr_camera_time}" if @debug
      return year, mon, day, hour, min, sec, dow
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def set_auto_off(x)
    puts "set power auto off(\"#{x}\"\)" if @debug
    result,msg,verified = set(auto_off_cmds, x, @wait_time, @verify)
    return result
  end

  def get_auto_off()
    result, msg, val = get(auto_off_cmds)
    if result
      i_cmds = auto_off_cmds[:settings].invert
      puts "power auto off =#{val} #{i_cmds[val.to_i]}" if @debug
      @curr_auto_off = i_cmds[val.to_i]
      return @curr_auto_off
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # NOTE: Get-verification is turned off for this gccb_camera set() call. But a good reply is checked
  def set_power_off(x)
    puts "set power off(\"#{x}\"\)" if @debug
    dont_verify = false
    result,msg,verified = set(power_off_cmds, x, @wait_time, dont_verify)
    return result
  end

  def do_apply_settings(); return set(apply_settings_cmds, nil, 1.0, false); end

  # 8dec15
  def get_camera_info()

    cmd = camera_info_cmd[:get] % @chan_id

    result, msg, err, i_len, cam_info = get_list(camera_info_cmd, cmd)

    # :get_resp   => "%s %s 0 0 10 %s 8 11 %s 0 %s %s %s %s %s %s %s %s %s %s %s %s", # total_len, ack, chan_id, error, <length> <id> <name_len> <name> <fw_len>  <firmware_ver>
    # actual_len, ack, chid, err, len, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12,a13,a14,a15  = resp_in.scanf(hash[:get_resp])

    # cmd: 9 59 59 0 0 3F 8 11 0 0  
    #                                cam_id
    #                            len cam_info[]
    #                             |  | name_len(0xD=13)                       fwlen
    #                             |  | | name....                ...(end name) |  firmware_ver...                 ...(end fwver)
    #                             |  | | |  |                                | |  |                                            |
    # in: 2A 0 0 0 10 93 8 11 0 0 20 C D 48 45 52 4F 34 20 53 69 6C 76 65 72 0 10 48 44 34 2E 30 31 2E 30 33 2E 30 31 2E 31 34 0
    # in: 2A 0 0 0 10 E3 8 11 0 0 20 C D 48 45 52 4F 34 20 53 69 6C 76 65 72 0 10 48 44 34 2E 30 31 2E 30 33 2E 30 31 2E 31 34 0  
    #
    # "[REQUEST]: A YY 0 0 <Channel ID> 8 11 0 0 0
    # [RESPONSE]:  <ACK/NACK> 0 0 10 <Channel ID> 8 11 <ERROR> <Length> <Camera ID><name_Length><Camera Name> <firmware_length><Firmware Verison>
    # uint8_t camera_id :
    # uint8_t camera_name_length D:
    # char    camera_name[]:
    # uint8_t firmware_version_length:
    # char    firmware_version[]: "

    # result, msg, length,cam_id, name_len, name, fw_len,  firmware_ver, = get(firmware_version_cmd)

    puts "get_camera_info(): result=#{result} msg=#{msg} i_len=#{i_len} cam_info=#{cam_info}" if @debug


    # Camera ID
    # cam_id = cam_info[0]
    # cam_id = [cam_info[0].to_i(16)].pack('U')  # Convert ASCII hex value to UTF8 character
    cam_id = cam_info[0].to_i(16)
    puts "cam_id=#{cam_id}" if @debug

    # Camera Name
    # get_list(): actual_len=42 ack=0 chid=E3 err=0 len=20
    # INFO : GET response: 2A 0 0 0 10 E3 8 11 0 0 20 C D 48 45 52 4F 34 20 53 69 6C 76 65 72 0 10 48 44 34 2E 30 31 2E 30 33 2E 30 31 2E 31 34 0  
    # get_camera_info(): result=true msg= i_len=20 cam_info=["C", "D", "48", "45", "52", "4F", "34", "20", "53", "69", "6C", "76", "65", "72", "0"

    name_len = cam_info[1].to_i(16)
    puts "name_len=#{name_len}" if @debug
    end_name_idx = 2 + name_len - 1
    puts "end_name_idx=#{end_name_idx}" if @debug
    name = String.new
    cam_info.each_with_index do |c,i|
      next if (i < 2) || (i > end_name_idx)
      packed = [c.to_i(16)].pack('U')  # Convert ASCII hex value to UTF8 character
      name << packed if ((i >= 2) && (i <= end_name_idx))  # utf8 packed
    end
    puts "name=#{name}" if @debug

    fwlen_idx = end_name_idx + 1
    puts "fwlen_idx=#{fwlen_idx}" if @debug

    fwlen = cam_info[fwlen_idx].to_i(16)
    puts "fwlen=#{fwlen}" if @debug

    # Firmware Version
    fw_idx = fwlen_idx + 1
    puts "fw_idx=#{fw_idx}" if @debug

    end_fw_idx = fw_idx + fwlen - 1
    puts "end_fw_idx=#{end_fw_idx}" if @debug

    # fwver = cam_info[fw_idx, end_fw_idx] ## Don't use: Get's array of packed hex chars only
    fwver = ""
    cam_info.each_with_index do |c,i|
      next if (i < fw_idx) || (i > end_fw_idx)
      packed = [c.to_i(16)].pack('U')  # Convert ASCII hex value to UTF8 character
      fwver << packed 
    end
    puts "fwver=#{fwver}" if @debug

    if result
      # fwver = major + "." + minor + "." + rev
      # puts "firmware_version = #{fwver}"
      # @firmware_version   = fwver
      @camera_id = cam_id
      @camera_name = name
      @camera_firmware_version = fwver
      return result,msg,@camera_id, @camera_name, @camera_firmware_version
    else
      puts "get_camera_info() ERROR: #{msg}"
      return nil
    end
  end # get_camera_info

  # 8dec15
  def get_firmware_ver()
    puts "get firmware version" if @debug
    result, msg, major,minor,rev = get(firmware_version_cmd)
    puts "get_firmware_ver(): result=#{result} msg=#{msg} major=#{major} minor=#{minor} rev=#{rev}" if @debug
    if result
      fwver = major + "." + minor + "." + rev
      puts "firmware_version = #{fwver}"
      @firmware_version   = fwver
      return result,msg,@firmware_version
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def get_battery_level()
    puts "get battery level" if @debug
    result,msg,percent,bars,state = get(battery_level_cmds)
    puts "get_battery_level(): result=#{result} msg=#{msg} percent=#{percent} bars=#{bars} state=#{state}" if @debug
    @curr_battery_percent = percent if result
    @curr_battery_bars    = bars    if result
    @curr_battery_state   = state   if result
    return result,msg,percent,bars,state
  end

  # 10dec15
  def get_busy_status()
    puts "get busy status" if @debug
    result,msg,busy_sts = get(camera_busy_status_cmd)
    puts "busy status=#{result} msg=#{msg} busy_sts=#{busy_sts}" if @debug
    if result
      @camera_busy_status = busy_sts.to_i==1 ? true:false  # return a boolean for this one
      return @camera_busy_status
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 10dec15
  def get_recording_status()
    puts "get recording status" if @debug
    result,msg,recording_sts = get(camera_recording_status_cmd)
    puts "recording status=#{result} msg=#{msg} recording_sts=#{recording_sts}" if @debug
    if result
      @camera_recording_status = recording_sts.to_i==1 ? true:false  # return a boolean for this one
      return @camera_recording_status
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 10dec15
  def get_cam_temp_warning()
    puts "get camera temperature warning" if @debug
    result,msg,temp_warning_flag = get(camera_temp_warning_cmd)
    puts "get_cam_temp_warning(): result=#{result} msg=#{msg} temp_warning_flag=#{temp_warning_flag}" if @debug
    if result
      icmd = camera_temp_warning_cmd[:settings].invert
      @camera_temp_warning = icmd[temp_warning_flag.to_i]
      return @camera_temp_warning
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 10dec15
  def get_cam_temperatures()
    puts "get camera temperature warning" if @debug
    result, msg, cpu_temp, batt_temp, sensor_temp = get(camera_temp_cmd)
    puts "get_cam_temperatures(): result=#{result} msg=#{msg} cpu_temp=#{cpu_temp} batt_temp=#{batt_temp} sensor_temp=#{sensor_temp}" if @debug
    if result
      @curr_cpu_temp     = cpu_temp.to_i(16)
      @curr_battery_temp = batt_temp.to_i(16)
      @curr_sensor_temp  = sensor_temp.to_i(16)
      return @curr_cpu_temp, @curr_battery_temp, @curr_sensor_temp
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def do_shutdown(); return set(shutdown_cmds, nil, 1.0, false); end

  def do_reset(force=true, timeout=30)
  end

  def do_beep_blink(x); return set(beep_blink_cmds, x); end

  def do_factory_reset(x)
  end

  def parse_yes_no(cmd, tries=2)
    (1..tries).each { |n|
      send_serial(cmd)
      re = /(^yes|^no)/
      resp = expect(re)
      if resp == nil
        next if n <= tries
        log_warn("Unable to parse yes/no from '#{resp}'")
        return false, "Unable to match yes/no"
      else
        return true if resp.match(re)[0] == "yes"
        return false if resp.match(re)[0] == "no"
      end
      return nil
    }
  end

  def parse_on_off(cmd, tries=2)
    (1..tries).each { |n|
      send_serial(cmd)
      re = /(^on|^off)/
      resp = expect(re)
      if resp == nil
        next if n <= tries
        log_warn("Unable to parse on/off from '#{resp}'")
        return false, "Unable to match on/off"
      else
        return true if resp.match(re)[0] == "on"
        return false if resp.match(re)[0] == "off"
      end
      return nil
    }
  end

  def recording?(); return parse_yes_no(recording_status[:get]); end

  def busy?(); return parse_yes_no(busy_status[:get]); end

  def save_settings()
    2.times {
      send_serial("t appc settings save")
      sleep 1
    }
  end

  # deprecated
  # def busy?(tries=3)
  #   busy_re = /record_active           [01]/
  #   (1..tries).each { |n|
  #     log_verb("Gerring status try #{n} of #{tries}")
  #     send_serial("t appc status show")
  #     resp = expect(busy_re, timeout=5.0, limit=1.0)
  #     break if resp != nil
  #   end
  #   if resp == nil
  #     log_warn("Unable to get status")
  #     return nil
  #   end
  #   stat = resp.match(busy_re)[0]
  #   p stat
  #   exit 1
  # end

  def quick_capturing?(); return parse_yes_no(quick_capture_status[:get]); end

  def wait_until_not_busy(interval=1.0, timeout=10)
    start = Time.now()
    loop {
      (recording?) ? sleep(interval) : (return true)
      log_verb("Waiting for camera not busy...")
      break if (Time.now() - start) > timeout
    }
    log_warn("Timeout waiting for camera not busy")
    return false
  end

  # Returns false if not supported, and a list of languages if supported.
  def language_support?()
    # Deem it supported if "t api setup" contains a "language" option.
    cmd = "t api setup" # Might vary on other cameras.
    send_serial(cmd)
    resp = read_serial_resp()
    return false unless resp and resp.match(/language/)
    ret = resp.match(/language.*/).to_s.match(/\[.*\]/).to_s.gsub("[","").gsub("]","").split("|")
    return ret
  end

  def get_language()
    langs = language_support?()
    return false unless langs
    cmd = language[:get] # Might vary on other cameras?
    send_serial(cmd)
    resp = read_serial_resp()
    langs.each { |lang| return lang if resp and resp.match(lang) }
    return false
  end

  # What does this do if we pass in nil?
  def set_language(x); return set(language, x); end

  ###########################################################################
  # Playback
  ###########################################################################

  def pb_start(); return set(playback_start, nil, 1.0, false); end

  def pb_stop(); return set(playback_stop, nil, 1.0, false); end

  def pb_pause(); return set(playback_pause, nil, 1.0, false); end

  def pb_resume(); return set(playback_resume, nil, 1.0, false); end

  def pb_step(); return set(playback_step, nil, 1.0, false); end

  def pb_forward(x); return set(playback_forward, x); end

  def pb_backward(x); return set(playback_forward, x); end

  def pb_start_slideshow; return set(playback_slideshow_start, nil, 1.0, false); end

  def pb_stop_slideshow; return set(playback_slideshow_stop, nil, 1.0, false); end

  def pb_multi_slideshow(); return set(playback_multi_slideshow, nil, 1.0, false); end

  def pb_next(); return set(playback_next, nil, 1.0, false); end

  def pb_prev(); return set(playback_prev, nil, 1.0, false); end

  def pb_tsearch(x); return set(playback_tsearch, x); end

  ###########################################################################
  # Storage
  ###########################################################################

  def set_tag(); return set(storage_tag, nil, 1.0, false); end

  # 12.15.15
  def get_hilight_tags()

    puts "get_hilight_tags()" if @debug

    get_command = get_hilight_tags_cmd[:get] % [ @chan_id ]

    result, msg, err, len, hls = get_list(get_hilight_tags_cmd, get_command)
    puts "result=#{result} msg=#{msg} err=#{err} len=#{len} hls=#{hls}" if @debug

    if result==true
      @num_hilight_tags = hls[0]
      @last_hilight_tag_timestamp = (hls[1].to_i(16) << 24) | (hls[2].to_i(16) << 16) | (hls[3].to_i(16) << 8) | hls[4].to_i(16)
      puts "num_tags=#{@num_hilight_tags} timestamp=#{@last_hilight_tag_timestamp}"
      return result, "ok", @num_hilight_tags, @last_hilight_tag_timestamp
    else
      puts msg if @debug
      return result,msg,nil
    end
  end

  # 12.11.15
  def set_hilight_tag()
    puts "set hilight tag()" if @debug
    dont_verify = false # meaning don't do a verify
    result,msg,verified = set(set_hilight_tag_cmd, nil, @wait_time, dont_verify)
    puts "result=#{result} msg=#{msg} verified=#{verified}"
    return result,msg
  end

  def storage_count(cmd, tries=2)
    (1..tries).each {
      send_serial(cmd)
      re = /^[0-9]{1,6}/
      resp = expect(re)
      next if resp == nil
      return resp.match(re)[0].to_i
    }
    return false
  end

  #  def get_total_files(); return storage_count(total_files[:get]); end

  # 12.11.15
  def get_photo_count()
    puts "get_photo_count()" if @debug
    result,msg,b3,b2,b1,b0 = get(photo_count_cmds)
    puts "result=#{result} msg=#{msg} b3=#{b3} b2=#{b2} b1=#{b1} b0=#{b0}"
    if result
      @photo_count = (b3.to_i(16) << 24) | (b2.to_i(16) << 16) | (b1.to_i(16) << 8) | b0.to_i(16)
      puts "@photo_count=#{@photo_count}"
      return @photo_count
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 12.11.15
  def get_video_count()
    puts "get_video_count()" if @debug
    result,msg,b3,b2,b1,b0 = get(video_count_cmds)
    puts "result=#{result} msg=#{msg} b3=#{b3} b2=#{b2} b1=#{b1} b0=#{b0}"
    if result
      @video_count = (b3.to_i(16) << 24) | (b2.to_i(16) << 16) | (b1.to_i(16) << 8) | b0.to_i(16)
      puts "@video_count=#{@video_count}"
      return @video_count
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # 12.11.15
  def get_rem_photos()
    puts "get_rem_photos" if @debug
    result,msg,b3,b2,b1,b0 = get(photos_rem_cmds)
    puts "result=#{result} msg=#{msg} b3=#{b3} b2=#{b2} b1=#{b1} b0=#{b0}"
    if result
      @photos_remaining = (b3.to_i(16) << 24) | (b2.to_i(16) << 16) | (b1.to_i(16) << 8) | b0.to_i(16)
      puts "@photos_remaining=#{@photos_remaining}"
      return @photos_remaining
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def get_photos_avail()
    return get_rem_photos()
  end

  # :storage_space_rem,

  # 12.14.15
  def get_storage_remspace()
    puts "get_storage_remspace()" if @debug
    result,msg,b7,b6,b5,b4,b3,b2,b1,b0 = get(storaage_remspace_cmds)
    puts "result=#{result} msg=#{msg} b3=#{b3} b2=#{b2} b1=#{b1} b0=#{b0}"
    if result
      @storage_space_rem = (b7.to_i(16) << 56) | (b6.to_i(16) << 48) | (b5.to_i(16) << 40) | (b4.to_i(16) << 32) | 
                           (b3.to_i(16) << 24) | (b2.to_i(16) << 16) | (b1.to_i(16) <<  8) |  b0.to_i(16)
      puts "@storage_space_rem=#{@storage_space_rem}"
      return result,msg,@storage_space_rem
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def get_rem_videos()
    puts "get_rem_videos()" if @debug
    result,msg,b3,b2,b1,b0 = get(vid_time_rem_cmds)
    puts "result=#{result} msg=#{msg} b3=#{b3} b2=#{b2} b1=#{b1} b0=#{b0}"
    if result
      @video_duration_rem = (b3.to_i(16) << 24) | (b2.to_i(16) << 16) | (b1.to_i(16) << 8) | b0.to_i(16)
      puts "@video_duration_rem=#{@video_duration_rem}"
      return @video_duration_rem
    else
      puts msg if @debug
      return nil,msg
    end
  end

  # For compatibility with WifiCamera
  def get_mins_avail()
    ret = get_rem_videos()
    if ret.to_i > 0
      return ret/60
    end
    log_warn("Unable to get remaining videos")
    return nil
  end

  def get_photo_group_count(); return storage_count(group_photo_count[:get]); end

  def get_video_group_count(); return storage_count(group_video_count[:get]); end

  def get_last_file(tries=2)
    (1..tries).each {
      send_serial(last_file[:get])
      resp = read_serial_resp()
      m = resp.match(/.{8}\.MP4/)
      return m if m != nil
      m = resp.match(/.{8}\.JPG/)
      return m if m != nil
      sleep 0.5
    }
    return false, "Unable to get last file"
  end

  def storage_delete_all()
    puts "storage_delete_all()" if @debug
    nilkey=nil # this tells set() that we don't have an arg to put in the command
    result,msg,verified = set(delete_all_cmds, nilkey, @wait_time, @verify)
    return result, msg, verified
  end

  def storage_delete_last()
    puts "storage_delete_last()" if @debug
    nilkey=nil # this tells set() that we don't have an arg to put in the command
    result,msg,verified = set(delete_last_cmds, nilkey, @wait_time, @verify)
    return result, msg, verified
  end

  # TODO: Figure out if this requires an arg?
  def storage_delete_one(x); return set(delete_one, x, 1.0, false); end

  # TODO: Figure out if this requires an arg?
  def storage_delete_group(x); return set(delete_group, x, 1.0, false); end

  # 10dec15
  def storage_status_event()
    puts "get storage status event" if @debug
    result,msg,storage_sts = get(storage_status_event_cmds)
    puts "get_storage_sts(): result=#{result} msg=#{msg} storage_sts=#{storage_sts}" if @debug
    if result
      @storage_status = storage_status_event_cmds[:settings][storage_sts.to_i]
      return @storage_status
    else
      puts msg if @debug
      return nil,msg
    end
  end


  ###########################################################################
  # WIRELESS
  ###########################################################################
  def set_wireless_mode(x)
    log_info("Setting wireless mode to #{x}")
    return set(wireless_mode, x)
  end

  def do_wifi_scan()
  end

  def do_pairing(x); return set(pairing, x, 1.0, false); end

  def do_pairing_stop(); return set(pairing_stop, nil, 1.0, false); end

  def do_wireless_ble(); return set(wireless_ble, nil, 1.0, false); end

  def do_push_multek(); return set(push_multek, nil, 1.0, false); end

  # Enable APP mode and return the ssid, pairing code of the camera
  # Returns false, false upon failure
  def enable_app_mode(ssid=nil, pc=nil)
    ssid = get_wifi_ssid() if ssid == nil
    pc = get_wifi_passphrase() if pc == nil
    if ssid != nil or pc != nil
      resp = nil
      log_info("Setting camera AP to ssid=#{ssid}, pc=#{pc}")
      3.times {
        send_serial("t api wireless ap_set #{ssid} #{pc}")
        resp = expect("SUCCESS")
        break if resp != nil
        sleep 1
      }
    else
      log_info("Using current camera wifi settings (ssid=#{ssid}, pc=#{pc})")
    end
    ret, msg = set_wireless_mode("APP")
    return ssid, pc if ret == true
    return false, false if ret == false
  end

  def get_csi(type, arg)
    ret = nil
    cmd = "t api wireless csi_get #{arg}"
    send_serial(cmd)
    resp = expect(/SUCCESS/)
    if resp == nil
      log_warn("No SUCCESS seen for arg=#{arg}")
      return ret
    end
    # TODO: Other types?
    if type == "STRING"
      re = /str - [a-zA-Z0-9_\-]+/
      resp_str = resp.match(re)
      if resp_str == nil
        log_warn("No valid string found in #{resp}")
      else
        ret = resp_str[0][6..-1].strip()
      end
    elsif type == "INT"  # Don't think any of them are floats...
      re = /value - \d+/
      resp_str = resp.match(re)
      if resp_str == nil
        log_warn("No valid number found in #{resp}")
      else
        ret = resp_str[0][8..-1].strip().to_i
      end
    end
    log_verb("Got #{arg} (#{type}) = #{ret}")
    return ret
  end

  def get_wifi_passphrase(); get_csi("STRING", "CSI_APP_PASSPHRASE"); end

  def get_wifi_ssid(); get_csi("STRING", "CSI_APP_SSID"); end

  def get_wireless_pin()
    cmd = "t appc wireless pin"
    send_serial(cmd)
    re = /^[0-9]{6}/
    resp = expect(re)
    if resp != nil
      return resp.match(re)[0].strip()
    end
    return nil
  end

  ###########################################################################
  # FW UPDATE
  ###########################################################################
  def do_fw_update_start(); return set(fw_update_start, nil, 1.0, false); end

  def do_fw_update_reset(); return set(fw_update_reset, nil, 1.0, false); end

  def do_boot_fw(); return set(boot_fw_cmds, nil, 1.0, false); end

  ###########################################################################
  # VID_FEATURE_AVAIL
  ###########################################################################
  # Takes capability-string, mode, res, fps, fov and returns whether it is supported
  # Capability strings are "piv", "low_light", "protune", "timelapse", "jello_slayer"
  def video_capability_filter_check(cap_str, m, r, fs, fv)
    cmd = method(cap_str+"_avail").call[:get]
    cmd_str = "#{cmd} #{m} #{vid_res[r]} #{fps[fs]} #{fov[fv]}"
    send_serial(cmd_str)
    re = /supported/
    resp = expect(re)
    return false, "Unable to get #{cap_str} availability" if resp == nil
    return true, true if resp.match("#{cap_str} supported") != nil
    return true, false if resp.match("#{cap_str} not supported") != nil
    return false, "Unable to read #{cap_str} support value from #{resp}"
  end

  ###########################################################################
  # Data Analytics logging methods
  ###########################################################################
  def file_exists(f)
    cmd = "ls #{f}"
    # Get basename from full path
    f_base = f.split("\\")[-1]
    2.times {
      send_serial(cmd)
      resp = read_serial_resp()
      resp.each_line { |l|
        begin
          poss_file = l.split()[6]
        rescue StandardError
          next
        end
        next if poss_file == nil
        return true if poss_file.match(f_base)
      }
    }
    return false
  end

  # Tells the camera to generate data analytics log in the MISC dir of the SD card
  # f = data_analytics.bin is the default
  def dump_analytics(f=nil)
    if ["BACKDOOR", "PIPE"].include?(@name)
      full_path = "c:\\misc\\#{f}"
      cmd = "t appc log save #{full_path}"
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
      f = "RP_data_temp.bin"
      full_path = "D:\\#{f}"
      cmd = "t app test appc_log save"
    else
      return false, "Unsupported camera (#{@name})"
    end
    3.times {
      send_serial(cmd)
      sleep 0.5
      return true, full_path if file_exists(full_path) == true
      log_verb("Retrying #{cmd}")
      sleep 2.0
    }
    return false, "Failed to dump analytics to #{f}"
  end

  def clear_analytics_buffer()
    if ["BACKDOOR", "PIPE"].include?(@name)
      cmd = "t appc log delete"
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
      cmd = "t app test appc_log delete"
    else
      return false, "Unsupported camera (#{@name})"
    end
    2.times {
      send_serial(cmd)
      sleep 0.5
      if ["BACKDOOR", "PIPE"].include?(@name)
        return true if expect("log-delete")
      elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
        return true if expect("Clear data ana")
      end
      sleep 1.0
    }
    return false
  end

  # Deletes any generic file on the SD card
  def del_analytics(f=nil)
    if ["BACKDOOR", "PIPE"].include?(@name)
      cmd = "t appc log delete #{f}"
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
      cmd = "t app test appc_log delete #{f}"
    else
      return false, "Unsupported camera (#{@name})"
    end
    return true, "del_analytics skipping delete due to nil arg" if f == nil
    2.times {
      send_serial(cmd)
      sleep 0.5
      return true, "Delete #{f} successful" if file_exists(f) == false
      sleep 1
    }
    return false, "Delete #{f} unsuccessful"
  end

  ###########################################################################
  # OTHER USEFUL METHODS
  ###########################################################################
  def enable_power_save()
    3.times {
      send_serial("t appc status power_save")
      return true if expect("av_graph_power_save_enter", 2.0) != nil
    }
    return false
  end

  def disable_power_save()
    3.times {
      send_serial("t appc status power_save_disable")
      return true if expect("Disabling Power save", 3.0) != nil
    }
    return false
  end

  def simulate_low_batt()
    2.times {
      send_serial("t appc status lowbatt")
      break if expect("LOWBATT") != nil
    }
    return true
  end

  def simulate_over_temp()
    2.times {
      send_serial("t appc status overtemp")
      break if expect("OVERTEMP") != nil
    }
    return true
  end

  def short_press_button(b)
    ret, msg = set(short_press_cmds, b, wait_time=0.5, verify=false)
    return true
  end

  def log_analytic_event(ev, p1, p2, p3)
    send_serial("t appc log rec #{ev} #{p1} #{p2} #{p3}")
  end

  def log_fake_analytic_events(n)
    send_serial("t appc log rec #{n}")
    return true if expect("Pass", 30.0) != nil
    return false
  end

  # Returns the mount point if a camera is mounted in mass-storage mode
  # Otherwise returns false
  def is_mounted?(pattern=nil)
  end

  # Turns on USB mass-storage mode and returns first camera found
  # If pattern is specified, returns first camera that matches
  def enter_mass_storage_mode(pattern=nil, retries=3, timeout=15)
    return nil
  end

  def exit_mass_storage_mode()
    send_serial(cmd)
    sleep 1
  end

  def get_first_gopro_dir(tries=3)
  end

  # Returns the full-path of all the media in the first GOPRO directory
  def get_medialist(suffix=nil, tries=3)
    dir = get_first_gopro_dir(tries)
    return [] if dir == nil
    send_serial("ls C:\\DCIM\\#{dir}\\*")
    # For very large numbers of files, the limit may be too short.
    data = ""
    (1..10).each {
      resp = read_serial_resp(limit=2.0)
      data += resp
      break if resp.match(/a:.>/) != nil
    }
    lines = data.split("\r\n")
    retval = []
    lines.each { |f|
      f.delete!("\u0000")
      fields = f.split()
      next if fields.length == 0
      next if fields[0][0] != "f" # Files only, skip directories
      (log_verb("Skipping #{f}"); next) if fields.length < 7
      fname = fields[6]
      # Skip non-matching suffix (if specified)
      next if suffix != nil and suffix != fname[-suffix.length..-1]
      retval << ["C:", "DCIM", dir, fname].join("\\")
    }
    return retval
  end

  # DEPRECATED
  def get_medialist2(suffix=nil)
    cam_root = enter_mass_storage_mode()
    if cam_root == nil
      log_warn("Camera did not appear as mass-storage-volume")
      return
    end
    if suffix == nil
      file_pattern = "*.*"
    else
      file_pattern = "*.#{suffix}"
    end
    # Matches files (file_pattern) in all subdirs (**) of DCIM
    medialist = Dir.glob(File.join(cam_root, "DCIM", "**", file_pattern))
    exit_mass_storage_mode()
    return medialist
  end

  # Override Camera.get_last_video()
  def get_last_video(); return @last_video_successful; end

  # Compatibility with Wi-fi camera
  def media_exists?(m)
    return find_file(m)
  end

  # fname is the 'basename' (i.e. GOPRxxxx.JPG) not the full path
  def find_file(fname, tries=3)
    dir = get_first_gopro_dir(tries)
    return false if dir == nil
    (1..tries).each { |n|
      send_serial("ls C:\\DCIM\\#{dir}\\*")
      resp = expect(fname, timeout=2, limit=1.0)
      return true if resp != nil
    }
    puts "returning false"
    return false
  end

  # fname is the 'basename' (i.e. GOPRxxxx.JPG) not the full path
  def find_file3(fname, tries=3)
    dir = get_first_gopro_dir(tries)
    return false if dir == nil
    (1..tries).each { |n|
      send_serial("ls C:\\DCIM\\#{dir}\\#{fname}")
      lines = read_serial_resp(limit=2.0).split("\r\n")
      lines.each { |f|
        f.delete!("\u0000")
        fields = f.split()
        next if fields.length != 7
        return true if fields[6] == fname
      }
    }
    puts "returning false"
    return false
  end

  # DEPRECATED
  def find_file2(fname)
    get_medialist().each { |f|
      return true if f.split("\\")[-1] == File.basename(fname)
    }
    return false
  end

  # Downloads a given file_name (e.g. GOPRO1234.MP4) to directory 'to_dir'
  def download_media(file_name, to_dir, retries=2)
    (1..retries).each { |n|
      log_debug("Looking for #{file_name} on camera")
      next if find_file(file_name) == false

      # File was found on the camera SD card, so let's mount it and copy it
      cam_root = enter_mass_storage_mode()
      if cam_root == nil
        log_warn("Can't find camera root in filesystem")
        return false, "Camera did not appear as mass-storage volume"
      end
      all_files = Dir.glob(File.join(cam_root, "DCIM", "**", "*.*"))
      log_verb(all_files)
      all_files.each { |f|
        if File.basename(f) == File.basename(file_name)
          if not File.directory?(to_dir)
            log_debug("Making #{to_dir}")
            FileUtils.mkdir_p(to_dir)
          end
          log_verb("Copying #{f} to #{to_dir}")
          mp4file = @host.copy_file(f, to_dir)
          lrvfile = f[0...-3] + "LRV"
          ret = @host.copy_file(lrvfile, to_dir)
          log_verb("Copied LRV file") if ret != nil
          thmfile = f[0...-3] + "THM"
          ret = @host.copy_file(thmfile, to_dir)
          log_verb("Copied THM file") if ret != nil
          sleep 3  # Very important to sleep here!
          exit_mass_storage_mode()
          return true, mp4file
        end
      }
      sleep 5
      log_debug("File not found.  Retrying...")
      exit_mass_storage_mode()
      sleep 5
    }
    return false, "File #{file_name} not found on camera"
  end

  # Downloads all media to directory 'to_dir'
  # (optionally stop after N files by setting stop_after=N)
  def download_all_media(to_dir, stop_after=nil)
    cam_root = enter_mass_storage_mode()
    if cam_root == nil
      log_warn("Camera did not appear as mass-storage-volume")
      return
    end
    all_files = Dir.glob(File.join(cam_root, "DCIM", "**", "*.*"))
    n_copied = 0
    all_files.each { |f|
      log_verb("Copying #{f} to #{to_dir}")
      mp4file = @host.copy_file(f, to_dir)
      n_copied += 1 if mp4file != nil
      break if stop_after != nil and n_copied == stop_after
    }
    exit_mass_storage_mode()
    if n_copied > 0
      return true, "#{n_copied} files copied"
    else
      return false, "File #{file_name} not found on camera"
    end
  end

  # Deletes a file on the SD card
  def delete_single_file(f)
    delfile = nil
    if File.dirname(f).length > 0
      delfile = f
    else
      all_files = get_medialist()
      all_files.each { |g|
        if File.basename(f) == File.basename(g)
          delfile = g
          break
        end
      }
    end
    if delfile == nil
      return false, "File #{f} not found on SD card"
    else
      log_debug("Deleting single file #{f}")
      send_serial("rm #{delfile}")
      return true, "File #{f} deleted"
    end
  end

  # Delete all using CCL command
  def delete_all_media()
    send_serial(delete_all[:set])
    sleep 5
  end

  def delete_all_media2()
    # Can take a LONG time if there are lots of files
    2.times {
      send_serial("rm c:\\dcim\\100gopro\\*")
      expect(/a:.>/, timeout=30, limit=1)
    }
    do_reset()
  end

  # DEPRECATED: Delete all the media on the SD card via 'rm' command
  # Use this only until an API command is given to do the same
  def delete_all_media3()
    log_debug("Deleting all files via 'rm' commands")
    send_serial("ls C:\\DCIM\\*")
    resp = read_serial_resp()
    log_verb("Looking up ***GOPRO directory")
    r = resp.match("...GOPRO")
    if r == nil or r.length < 1
      log_warn("No ***GOPRO directory found")
      return []
    end
    dir = r[0]
    send_serial("rm C:\\DCIM\\#{dir}\\*")
    sleep 3
    all_files = get_medialist()
    if all_files.length > 0
      ret = false
      msg = "Delete all media may have failed (medialist non-empty)"
    else
      ret = true
      msg = "Delete all successful"
    end
    log_debug(msg)
    return ret, msg
  end

  def already_set?(cmd="fake", args="fake")
    log_warn("already_set? method not supported on serial. Returning false")
    return false
  end

  # Boot the Hawaii camera
  def startGoPro4()
    send_serial('!\n')
    puts "please wait 20s"
    sleep 20.0
  end

  ###########################################################################
  # ZZ commands
  ###########################################################################

  def send_zz_rdy()
    log_info("send_zz_rdy()") if @debug
    #buf = 'ZZ 0 0 2 1'
    byte1 = zz_cmds[:payload_byte1]["Ready"]
    byte2 = zz_cmds[:payload_byte2]["Ready"]
    cmd   = zz_cmds[:set] % [ byte1, byte2 ]
    send_serial(cmd)

    resp_in = read_serial_resp_in()
    return false, "resp_in is NIL!" if resp_in==nil
    # Should get back:
    # in: 6 0 0 0 10 2 1
    ack, ready1, ready2 = resp_in.scanf(zz_cmds[:set_resp])

    return false, "ZZ Ready ACK failed" if ack=='1'
    return false, "ZZ Ready1 failed" if ready1!='2'
    return false, "ZZ Ready2 failed" if ready2!='1'
    return true, "OK"
  end

  def convert_resp_to_utf8(resp, cmd=nil)

    len = resp[1]

    # Delete the header information from the response line
    #resp.delete_at(0)

    puts "resp=#{resp} (after deletes)" if @debug

    if (cmd == 'firmware_version')  # get entire camera status will build an array instead of a string
      resp_utf8 = Array.new(30) # create an array that will hold 30 hex values
      resp.each_with_index do |e, i|
        resp_utf8[i] = e.hex
      end
      return resp_utf8
    end

    resp_utf8 = ""
    if (cmd == 'cs')  or (cmd == 'ti') # just return the ascii value
      puts "convert_resp_to_utf8(): cmd==ti or cs" if @extra_debug
      resp.each_with_index do |e, i|
        puts "cmd==ti e=#{e}"  if (cmd == 'ti') if @extra_debug
        resp_utf8 += e.to_i(16).to_s(16).upcase
      end
      return resp_utf8
    end
    if (cmd == 'tm')
      resp_utf8 = Array.new(6) # create an array that will hold 30 hex values
      resp.each_with_index do |e, i|
        resp_utf8[i] = e.to_i(16).to_s
      end
      return resp_utf8
    end

    needs_space = false

    resp.each do |e|

      # e.hex converts hex to decimal
      # U is the pack directive to convert from UTF-8
      packed = [e.hex].pack('U')

      # Note: skip the status byte altogether
      if (e.hex < 0x21) or ((e.hex > 0x7d) and (e.hex < 0xa1))  # check for non-printable chars
        # Append unprintable characters (ie - CR, LF, space)
        if (cmd == 'cv')
          case e.hex
          when 2
            puts "skipping value #{e}" if @extra_debug
          when 10
            puts "skipping value #{e}" if @extra_debug
            #puts "inserting NL"
            #resp_utf8 += "\n"
          when 12
            puts "ignoring formfeed #{e}" if @extra_debug
          when 21
            puts "inserting space for FACK #{e}" if @extra_debug
            resp_utf8 += " "
          when 32
            puts "inserting space for #{e}" if @extra_debug
            resp_utf8 += " "
          end # case
          #elsif (cmd == 'cs')  or (cmd == 'ti') # just return the ascii value
          #puts "cmd==ti e=#{e}"
          #resp_utf8 += e.to_i(16).to_s(16).upcase
        else
          resp_utf8 += ' ' if needs_space  # put a space between the 2-letter command and the parameter(s)
          resp_utf8 += e.hex.to_s
        end
      else # Printable characters or more special commands handled here
        if (cmd == "bl")
          resp_utf8 +=  e.hex.to_s
          # puts e.to_i(16)
        else
          resp_utf8 += [e.hex].pack('U')
        end
      end
    end # convert_resp_to_utf8

    resp_utf8.chomp!(' ') # remove trailing spaces
    puts resp_utf8.inspect if @extra_debug
    return resp_utf8

  end # convert_resp_to_utf8

  def zz_get_i2c_speed()
    log_info("zz_get_i2c_speed()") if @debug

    # SEND
    byte1 = zz_cmds[:payload_byte1]["I2C_speed"]
    byte2 = "0"
    cmd   = zz_cmds[:set] % [ byte1, byte2 ]
    send_serial(cmd)

    # RESPONSE
    resp_in = read_serial_resp_in()
    puts "resp_in=#{resp_in}"
    return nil if (resp_in == nil)
    # Should get back:
    # in: 6 0 0 0 10 2 1
    len, ack, cmd, i2c_speed = resp_in.scanf(zz_cmds[:set_resp])

    puts "len=#{len}"
    puts "ack=#{ack}"
    return nil if (len != "6")
    return nil if (ack != "0")
    puts "i2c_speed=#{i2c_speed}"

    # Example of response:
    # resp_in=6 0 0 0 10 1 0

    i_speeds = zz_cmds[:i2c_speeds].invert
    i2c_speed_name = i_speeds[i2c_speed.to_i]
    #i2c_speed_name="nil" if i2c_speed_name==nil
    puts "i2c_speed_name=#{i2c_speed_name}" if @debug
    return i2c_speed_name

  end # zz_get_i2c_speed

  def zz_get_protocol_ver()
    log_info("zz_get_protocol_ver()") if @debug

    # SEND
    byte1 = zz_cmds[:payload_byte1]["ProtocolVersion"]
    byte2 = "20"
    byte2 = "0"
    cmd   = zz_cmds[:set] % [ byte1, byte2 ]
    send_serial(cmd)

    # RESPONSE
    resp_in = read_serial_resp_in()
    puts "resp_in=#{resp_in}"
    return nil if (resp_in == nil)
    # Should get back:
    # in: 6 0 0 0 10 2 1
    len, ack, cmd, proto_ver = resp_in.scanf(zz_cmds[:set_resp])

    puts "len=#{len}"
    puts "ack=#{ack}"
    return nil if (len != "15")
    return nil if (ack != "0")

    ##### TODO: once this command gets fixed, Jira ticket#????
    #### Then put in the rest of the parsing code here
    #### 11.6.15 ~RodT

    # Example of response:
    # resp_in=
    protocol_ver = nil

    return protocol_ver

  end # zz_get_protocol_ver

  def yy_get_firmware_ver()
  end
  def zz_get_firmware_ver()
    log_info("zz_get_firmware_ver()") if @debug

    # SEND
    byte1 = zz_cmds[:payload_byte1]["FirmwareVersion"]
    byte2 = "20"
    cmd   = zz_cmds[:set] % [ byte1, byte2 ]
    send_serial(cmd)

    # RESPONSE
    resp_in = read_serial_resp_in()
    puts "resp_in=#{resp_in}"
    return nil if (resp_in == nil)
    # Should get back:
    # in: 6 0 0 0 10 2 1
    len, ack, cmd, tmp = resp_in.scanf(zz_cmds[:set_resp])

    puts "len=#{len}"
    puts "ack=#{ack}"
    return nil if (len != "15")
    return nil if (ack != "0")

    # Example of response:
    # resp_in=15 0 0 0 10 3 48 44 34 2E 30 31 2E 30 33 2E 30 31 2E 31 31 0

    # Create a set of all the firmware UTF8 characters
    #
    fw_set = resp_in.scan(/\w+/)
    return nil if fw_set==nil

    puts "fw_set=#{fw_set}"
    # Delete the header information from the response line
    fw_set.delete_at(0)
    fw_set.delete_at(0)
    fw_set.delete_at(0)
    fw_set.delete_at(0)
    fw_set.delete_at(0)
    fw_set.delete_at(0)
    fw_set.pop

    fw_utf8 = convert_resp_to_utf8(fw_set)
    puts "fw_utf8=#{fw_utf8}" if @debug
    return fw_utf8

  end # zz_get_firmware_Ver

  def zz_get_capabilities()
    log_info("zz_get_capabilties()") if @debug

    # SEND
    byte1 = zz_cmds[:payload_byte1]["Capabilities"]
    #byte2 = zz_cmds[:payload_byte2]["Capabilities_1"]
    byte2 = "10" # enable CVBS only?
    byte2 = "30" # enable both USB & CVBS
    byte2 = "20" # enable USB only?
    cmd   = zz_cmds[:set] % [ byte1, byte2 ]
    send_serial(cmd)

    # RESPONSE
    resp_in = read_serial_resp_in()
    puts "resp_in=#{resp_in}"
    return nil if (resp_in == nil)
    # Should get back:
    # in: 6 0 0 0 10 2 1
    len, ack, cmd, cap_mask = resp_in.scanf(zz_cmds[:set_resp])
    puts "len=#{len}"
    puts "ack=#{ack}"
    return nil if (len != "6")
    return nil if (ack != "0")
    i_cmds = zz_cmds[:payload_byte1].invert
    puts "cmd=#{i_cmds[cmd.to_i]}"

    # Capabilties de-masker
    #
    puts "cap_mask=#{cap_mask}"
    i_cap = zz_cmds[:capabilities_1].invert
    cap_val = cap_mask.to_i(16)
    capabilities_list =  nil
    i_cap.each do |bit, cap_name|
      and_val = bit & cap_val
      puts "cap_val(#{cap_val}) & bit(#{bit}) = #{and_val}" if @debug
      if (cap_val & bit) != 0
        puts cap_name if @debug
        capabilities_list =  "" if capabilities_list == nil
        capabilities_list = capabilities_list + " " + cap_name
      end
    end
    return capabilities_list

  end # zz_get_capabilities

  def sendZZcommand(cmdHex)
    zzcmd = 'ZZ 0 0 ' + cmdHex + '\n\r'
    send_serial(zzcmd)
  end

  def gccb_power_on()
    log_info("gccb_power_on()")
    buf='!' + "\r"
    send_serial(buf)
    sleep_time = 5.0
    puts "sleeping #{sleep_time}s..."
    sleep sleep_time
    #read_serial_resp(1.0)  # clear read buffer
  end

  def get_channel_id()
    log_info("get_channel_id()")
    cmd = 'YY 0 0 0 0 1 0 0'
    send_serial(cmd)
    #YY command
    #cmd: 9 59 59 0 0 0 0 1 0 0
    #in: B 0 0 0 10 0 0 1 0 0 1 A3   << channel ID is 'A3'
    #nresponseHandler:OK
    #resp=YY 0 0 0 0 1 0 0
    resp = read_serial_resp(1.0)
    @chan_id, @default_chan_id = resp_chanid(resp)
    return @chan_id
  end

  # Scans the GCCB response which can look like:
  #   YY command
  #   cmd: 9 59 59 0 0 0 0 1 0 0
  #   in: B 0 0 0 10 0 0 1 0 0 1 A3   << channel ID is 'A3'
  #   responseHandler:OK
  #   resp=YY 0 0 0 0 1 0 0
  #
  # and fine the "in:" line
  # Return#1: remainder of inline
  # Return#2: length of "in:" as represented in the first byte, convert from hex to decimal
  #
  def get_resp_in(resp)
    #inline = resp.scan(/^in: (\w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+)/) # B 0 0 0 10 0 0 1 0 0 1 A3
    inline = resp.scan(/^in: (\w.+)/) # B 0 0 0 10 0 0 1 0 0 1 A3
    if (inline == nil) or (inline[0] == nil) or (inline[0][0] == nil)
      msg = "NULL RESPONSES - Make sure camera is powered off first or reset the GCCB bacpac"
      log_error(msg)
      return nil
    end
    puts "inline=#{inline}" if @debug
    inline = inline[0][0]
    puts "inline[0][0]=#{inline}" if @debug
    inline = inline.to_s
    puts "inline.to_s=#{inline}" if @debug
    inline = inline.chomp
    puts "inline.chomp=#{inline}" if @debug
    return inline
  end

  # Get the response packet
  # Parse for and return just the "IN:" line
  #
  def read_serial_resp_in()
    resp_pkt = read_serial_resp()
    resp_in  = get_resp_in(resp_pkt)
    return resp_in
  end

  # return the length byte of the "in:" response
  def resp_inlen(resp)
    if resp == nil
      log_warn("resp_inlen() resp == nil")
      return
    end
    #look for "in: <len>"
    hex = resp.scan(/^in: (\w+)/)
    #DEBUG: puts "resp_inlen() hex=#{hex}"
    len=hex[0][0].to_i(16)  # Note: the length of the "in:" response string is in ascii HEX
    #DEBUG: puts "resp_inlen() len=#{len}"
    return len
  end

  def resp_chanid(resp)
    # log_info("resp_chanid()")
    #channel_id = resp.scan(/^in: \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ \w+ (\w+)/) # A3
    channel_id = get_last_byte(resp)
    #if channel_id != nil and channel_id[0] != nil and channel_id[0][0] != nil
    default_id = get_nth_byte(resp,5)
    puts "CHANNEL ID == #{channel_id}"
    puts "DEFAULT CHANNEL ID == #{default_id}"
    if channel_id != nil
      return channel_id, default_id
    else
      return 0
    end
  end

  def get_nth_byte(resp, n)
    inline = resp.scan(/^in: (\w.+)/)
    inline = inline[0][0].chomp
    len = inline[0].to_i(16)
    if n > len
      log_warn("get_nth_byte(resp,#{n}):  n > len==#{len}")
      return nil
    end
    il = inline.split(" ")
    return il[n]
  end

  def get_last_byte(resp)
    inline = resp.scan(/^in: (\w.+)/)
    return nil if inline == nil
    inline = inline[0][0].chomp
    len = inline[0].to_i(16)
    il = inline.split(" ")
    return il[len]
  end

  def set_mode(new_mode)
    log_info("set_mode(\"#{new_mode}\")")
    result, msg, verified = set(mode_cmds, new_mode)
    if result == true
      @current_camera_mode = new_mode if verified
    else
      puts "WARN: msg=#{msg}"
      puts "set_mode() ***FAILED*** to set mode to #{new_mode}"
    end
    return verified
  end

  def mode_to_name(mode)
    gettings = mode_cmds[:settings].invert
    #puts "gettings=#{gettings}"
    mode_str = gettings[mode.to_i]
  end

  # mode can either be the index value or string name as defined in mode_cmds
  def get_submode(mode)

    mode_cmds[:settings].each do |mode_name, mode_val|
      mode=mode_name if mode==mode_name or mode==mode_val
    end
    puts "get_submode(#{mode})"

    submode_hash = mode_cmds[:submodes][mode]

    # First put the camera into the correct "main" mode
    result, msg, submode = get(submode_hash)
    if result
      isubmode = submode_hash[:settings].invert
      puts "submode=#{submode} #{isubmode[submode.to_i]}"
      @current_camera_submode = submode.to_i
      return @current_camera_submode
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def get_mode()
    puts "get_mode()" if @debug
    result, msg, mode = get(mode_cmds)
    if result
      imode = mode_cmds[:settings].invert
      puts "mode=#{mode} #{imode[mode.to_i]}" if @debug
      @current_camera_mode = mode.to_i
      return @current_camera_mode
    else
      puts msg if @debug
      return nil,msg
    end
  end

  def get_mode_SAVE()

    cmd = mode_cmds[:get] % @chan_id
    send_serial(cmd)

    resp_in = read_serial_resp_in()
    response_format = mode_cmds[:get_resp]
    has_arg = 1

    ok, msg, arg = check_response(resp_in, response_format, has_arg)
    if ok
      @current_camera_mode = arg
      return @current_camera_mode
    else
      puts "WARN: #{msg}"
      return nil
    end
  end

  # VIDEO FORMAT "NTSC" vs "PAL"

  ## WARNING: this is the same as set_video_format()
  def set_video_mode(x)
    puts "set_video_mode(\"#{x}\"\)" if @debug
    result,msg,verified = set(vid_mode_cmds, x, @wait_time, @verify)
    @curr_video_format = x if verified
    return verified
  end

  def set_video_format(new_fmt) # "NTSC" or "PAL"
    puts "set_video_format(\"#{new_fmt}\"\)" if @debug
    set_video_mode(new_fmt)
  end

  def get_video_format()
    puts "get_video_format()" if @debug
    result, msg, video_format = get(vid_mode_cmds)
    if result
      i_cmds = vid_mode_cmds[:settings].invert
      vid_fmt_name = i_cmds[video_format.to_i]
      @curr_video_format = vid_fmt_name
      puts "video_format=#{video_format} #{i_cmds[video_format.to_i]}" if @debug
      return @curr_video_format
    else
      puts msg if @debug
      return nil,msg
    end

  end

end # end GCCBCamera

####### M A I N #######
if __FILE__ == $0

  $LOGLEVEL = $LL_VERB
  serial_port = "/dev/ttyACM0"
  #camera = get_gccb_camera(@options[:gccbdev])
  camera = get_gccb_camera(serial_port)
=begin

  camera.gccb_power_on()
  resp = camera.read_serial_resp(1.0)

  camera.send_zz_rdy()
  resp = camera.read_serial_resp(1.0)

  chid = camera.get_channel_id()
  #puts "chid=#{chid}\n"
  puts "camera.chan_id=#{camera.chan_id}\n"

  sleep 4
  camera.set_video_format("NTSC")
  sleep 4
  camera.set_video_format("PAL")

  sleep 4
  camera.set_beep_sound("0")
  sleep 5
  camera.set_beep_sound("70")  #NOTE: not taking w/respect to gpControl settings
  sleep 5
  camera.set_beep_sound("100")

  sleep 4
  camera.set_led("4")
  sleep 4
  camera.set_led("off")
  sleep 4
  camera.set_led("2")

  camera.set_mode("VIDEO")
  camera.set_video_sub_mode("VIDEO")
  camera.set_video_sub_mode("TIME_LAPSE")
  camera.set_video("NTSC", "1080", "30", "WIDE")
  camera.set_video_resolution("720_SUPER") # DOESN'T WORK if FPS does not equal 120 or 60

  camera.set_mode("MULTI_SHOT")
  camera.set_mode("VIDEO")
  mode = camera.get_mode()
  puts "mode=#{mode}"
  mode_str = camera.mode_to_name(mode)
  puts "CAMERA_MODE=#{mode_str}"
  #camera.set_video_sub_mode("LOOPING")
  camera.set_video_sub_mode("PIV")
  #camera.set_video_sub_mode("VIDEO")
  #camera.set_video_sub_mode("TIME_LAPSE")
  camera.get_video_sub_mode()
    sleep 3
  camera.set_video_def_sub_mode("PIV")
    sleep 3
  camera.set_video_resolution("720_SUPER")
  camera.set_video_fps("60")
  camera.set_video_fov("MEDIUM")

  camera.set_mode("PHOTO")
  camera.set_mode("MULTI_SHOT")
  camera.set_mode("PLAYBACK")
  camera.set_mode("SETTINGS")

  ### WORKS!!!
  camera.get_mode2()
  #camera.get_submode("VIDEO")
  #camera.get_submode("MULTI_SHOT")
  camera.get_submode(1)
  camera.get_video_settings()
  camera.get_video_protune()
  camera.set_looping("120")
  camera.set_video_low_light("ON")
  camera.set_video_low_light("OFF")
  camera.set_multi_timelapse_interval("5")
  camera.get_multi_timelapse_interval()
  puts "@curr_multi_timelapse_interval=#{camera.curr_multi_timelapse_interval}"
  camera.set_photo_res("7MED")
  camera.get_photo_res()
  camera.set_default_capture_mode("VIDEO")
  camera.set_video_def_sub_mode("PIV")
  camera.set_default_capture_mode("VIDEO")
  camera.set_default_capture_mode("PHOTO")
  camera.set_mode("VIDEO")
  camera.set_default_capture_mode("VIDEO")
  camera.set_video_def_sub_mode("LOOPING")
  camera.set_default_capture_mode("PHOTO")
  camera.set_photo_def_sub_mode("NIGHT")
  camera.set_photo_protune("OFF")
  camera.set_photo_protune("ON")
  camera.get_photo_protune()
  camera.set_photo_protune("OFF")
  camera.set_photo_protune_exposure("-1.5")
  camera.get_photo_protune_exposure()
  camera.set_multi_protune("ON")
  camera.get_multi_protune()
  camera.set_multi_protune_exposure("+2")
  camera.get_multi_protune_exposure()
  camera.set_multi_protune("OFF")
  camera.get_multi_protune()
  camera.set_mode("MULTI_SHOT")
  camera.set_photo_sub_mode("SINGLE")
  camera.set_photo_def_sub_mode("CONTINUOUS")
  camera.get_photo_def_sub_mode()
  camera.set_sps("3")
  camera.get_sps()
  camera.set_burst("10_3")
  camera.get_burst()
  camera.set_pb_osd_onoff("OFF")
  camera.set_pb_osd_onoff("ON")
  camera.get_pb_osd_onoff()
  camera.set_power_off("NORMAL")
  camera.set_power_off("FORCE") # NOTE: Get-verification is turned off for the gccb_camera set() call. But a good reply is checked
  res,msg,percent,bars,state = camera.get_battery_level()
  puts "get_battery_level(): result=#{result} msg=#{msg} percent=#{percent} bars=#{bars} state=#{state}" if @debug
  camera.storage_delete_last()
  camera.storage_delete_all()
  camera.get_quickcapture()
  camera.set_quickcapture("ON")
  camera.get_auto_off()
  camera.set_auto_off("5")
  year=2016; mon=1; day=2; h=3; m=4; s=5
  camera.set_camera_time(year,mon,day,h,m,s)
  camera.get_camera_time()
  camera.get_locate_camera()

  camera.set_mode("PHOTO")
  camera.set_photo_sub_mode("SINGLE")
=end

  ### TEST THIS!!! 
  # camera.debug=true

  #camera.set_mode("PLAYBACK")

  # camera.set_mode("VIDEO")
  # camera.set_video_sub_mode("VIDEO")
  #result = camera.start_video_capture() # WORKS
  #puts "result=#{result}"
  #camera.stop_video_capture()  # WORKS

  #camera.set_mode("PHOTO")
  #camera.set_photo_sub_mode("CONTINUOUS")
  #camera.start_photo_capture()  #  WORKS
  #camera.stop_photo_capture()  #  FF error (but photo shutter was not on during test - try with continuous->NOPE still FF error)

  #camera.set_mode("MULTI_SHOT")
  #camera.set_multi_sub_mode("TIME_LAPSE")
  #camera.start_multi_capture()  #  WORKS
  #sleep 10
  #camera.stop_multi_capture()  #  FF error (but photo shutter was not on during test - try with continuous->NOPE still FF error)

  # ZZ commands
  # camera.debug=true
  # cap=camera.zz_get_capabilities()   # WORKS
  # puts "zz_capabilities=#{cap}"

  # fwv =camera.zz_get_firmware_ver()   # WORKS
  # puts "fwv=#{fwv}"
  #camera.zz_get_protocol_ver()   # FAILS, ack==1
  #ispeed=camera.zz_get_i2c_speed()   # WORKS
  #puts "ispeed=#{ispeed}"

  #camera.set_lcd_brightness("HIGH")
  #camera.set_lcd_brightness("MED")
  #camera.set_lcd_brightness("LOW")

  #res,msg,percent,bars,state = camera.get_battery_level()
  #puts "get_battery_level(): result=#{result} msg=#{msg} percent=#{percent} bars=#{bars} state=#{state}" if @debug

  # camera.storage_delete_last()
  # camera.storage_delete_all()
  # camera.get_video_protune_whitebalance() # WORKS 1dec15
  #camera.set_video_protune_whitebalance("RAW") # WORKS 1dec15
  #camera.set_video_protune_whitebalance("5500K") # works
  #camera.get_video_protune_whitebalance()

  # WORKS 1dec15
  #camera.get_video_color()
  #camera.set_video_color("STANDARD")  # STANDARD, NEUTRAL, gopro_color, flat
  #camera.get_video_color()
  #camera.set_video_protune_color("flat")
  #camera.get_video_protune_color()

  # VERIFIED 1dec15
  # leds = camera.get_led(); puts "leds=#{leds}"
  # camera.set_led("4")
  # leds = camera.get_led(); puts "leds=#{leds}"
  # camera.set_led("off")
  # leds = camera.get_led(); puts "leds=#{leds}"

  # camera.set_led("2")
  # leds = camera.get_led(); puts "leds=#{leds}"

  # VERIFIED 1dec15
  #beeps = camera.get_beeps(); puts "beeps=#{beeps}"
  #camera.set_beep_sound("0")
  #beeps = camera.get_beeps(); puts "beeps=#{beeps}"
  #camera.set_beep_sound("70")  #NOTE: not taking w/respect to gpControl settings
  #beeps = camera.get_beeps(); puts "beeps=#{beeps}"
  #camera.set_beep_sound("100")
  #beeps = camera.get_beeps(); puts "beeps=#{beeps}"

  # VERIFIED 1dec15
  #spotval = camera.get_video_spot_metering(); puts "video spot-meter=#{spotval}"
  #camera.set_video_spot_metering("ON")
  #spotval = camera.get_video_spot_metering(); puts "video spot-meter=#{spotval}"
  #camera.set_video_spot_metering("OFF")
  #spotval = camera.get_video_spot_metering(); puts "video spot-meter=#{spotval}"

  # VERIFIED 1dec15
  #ti = camera.get_video_timelapse_interval(); puts "video timelapse ti=#{ti}"
  #camera.set_video_timelapse_interval("0.5")
  #ti = camera.get_video_timelapse_interval(); puts "video timelapse ti=#{ti}"
  #camera.set_video_timelapse_interval("5")
  #ti = camera.get_video_timelapse_interval(); puts "video timelapse ti=#{ti}"

  # VERIFIED 1dec15
  #def set_video_protune_sharpness(x)
  #def get_video_protune_sharpness()
  #def get_video_protune_iso()
  #def set_video_protune_iso(x)

  # VERIFIED 1dec15
  #x = camera.get_video_protune_sharpness(); puts "video protune_sharpness x=#{x}"
  #camera.set_video_protune_sharpness("MED")
  #x = camera.get_video_protune_sharpness(); puts "video protune_sharpness x=#{x}"

  #x = camera.get_video_protune_iso(); puts "video protune_iso x=#{x}"
  #camera.set_video_protune_iso(6400)
  #camera.set_video_protune_iso(400)
  #x = camera.get_video_protune_iso(); puts "video protune_iso x=#{x}"

  # VERIFIED 1dec15
  #x = camera.get_video_piv_interval(); puts "video piv value=#{x}"
  #camera.set_video_piv_interval("30")
  #x = camera.get_video_piv_interval(); puts "video piv value=#{x}"

  puts ""
  puts ""
  # camera.set_mode("VIDEO")
  # camera.set_video_sub_mode("PIV")
  # camera.start_video_capture(1)
  # sleep 5.0
  # camera.stop_video_capture(1)
  # VERIFIED 1dec15
  # camera.get_video_progress_counter()
  # camera.get_video_all_settings()

  # VERIFIED 3dec15
  # camera.get_video_all_resolutions("ALL")
  # a = camera.get_video_all_resolutions("PIV")
  # a = camera.get_video_all_resolutions("LOWLIGHT")
  # a = camera.get_video_all_resolutions("PROTUNE")
  # puts "len=#{a.length}"
  # a = camera.get_video_all_resolutions("TIMELAPSE")
  # puts "len=#{a.length}"

  # camera.get_video_all_fps("PIV","NTSC","4K")  # ERROR 0xff err code
  # camera.get_video_all_fps("PIV","NTSC","1080")
  # camera.get_video_all_fps("ALL","NTSC","4K")
  # camera.get_video_all_fps("ALL","NTSC","1080")
  # camera.get_video_all_fps("ALL","PAL","1080")

  # camera.get_video_all_fov(filter, format, res, fps)
  # camera.get_video_all_fov("ALL","NTSC", "1080", "30")
  # camera.get_video_all_capabilities("ALL", "NTSC", "1080", "30", "WIDE")

  # VERIFIED 4dec15
  # spotval = camera.get_photo_spot_metering(); puts "photo spot-meter=#{spotval}"
  # camera.set_photo_spot_metering("ON")
  # spotval = camera.get_photo_spot_metering(); puts "photo spot-meter=#{spotval}"
  # camera.set_photo_spot_metering("OFF")
  # spotval = camera.get_photo_spot_metering(); puts "photo spot-meter=#{spotval}"

  # VERIFIED 4dec15
  # x = camera.get_photo_exp(); puts "x=#{x}"
  # camera.set_photo_exp("AUTO")
  # x = camera.get_photo_exp(); puts "x=#{x}"
  # camera.set_photo_exp(30)
  # x = camera.get_photo_exp(); puts "exp=#{x}"

  # VERIFIED 4dec15
  # camera.debug=true
  # x = camera.get_photo_color(); puts "x=#{x}"
  # camera.set_photo_color("gopro_color")
  # x = camera.get_photo_color(); puts "x=#{x}"
  # camera.set_photo_color("flat")
  # x = camera.get_photo_color(); puts "color=#{x}"

  # VERIFIED 4dec15
  # x = camera.get_photo_sharpness(); puts "x=#{x}"
  # camera.set_photo_sharpness("MED")
  # x = camera.get_photo_sharpness(); puts "sharpness=#{x}"

  # VERIFIED 4dec15
  # x = camera.get_photo_iso(); puts "x=#{x}"
  # camera.set_photo_iso(400)
  # x = camera.get_photo_iso(); puts "iso=#{x}"

  # VERIFIED 4dec15
  # camera.set_video_protune("OFF")
  # x = camera.get_video_protune(); puts "protune=#{x}"
  # camera.set_photo_protune_reset()
  # spotval = camera.get_photo_spot_metering(); puts "photo spot-meter=#{spotval}"
  # x = camera.get_photo_exp(); puts "exp=#{x}"  # does NOT change after RESET
  # x = camera.get_photo_color(); puts "color=#{x}"
  # x = camera.get_photo_sharpness(); puts "sharpness=#{x}"
  # x = camera.get_photo_iso(); puts "iso=#{x}"
  # x = camera.get_video_protune(); puts "protune=#{x}"  # does NOT change after RESET

  # VERIFIED 7dec15
  # x = camera.get_photo_white_balance(); puts "white_balance{x}"
  # camera.set_photo_white_balance(400)
  # x = camera.get_photo_white_balance(); puts "white_balance=#{x}"

  # VERIFIED 4dec15
  # camera.get_photo_all_settings()

  # VERIFIED 7dec15
  # camera.debug=true
  # camera.get_multi_res()
  # camera.set_multi_res("7MED")
  # camera.get_multi_res()
  # camera.debug=true
  # x=camera.get_multi_nightlapse_interval(); puts "nightlapse rate=#{x}"
  # # camera.set_multi_nightlapse_interval("CONTINUIOUS")
  # camera.debug=false
  # camera.set_multi_nightlapse_interval("30min")
  # camera.debug=true
  # x=camera.get_multi_nightlapse_interval(); puts "nightlapse rate=#{x}"

  # spotval = camera.get_multi_spot_metering(); puts "multi spot-meter=#{spotval}"
  # camera.set_multi_spot_metering("ON")
  # spotval = camera.get_multi_spot_metering(); puts "multi spot-meter=#{spotval}"
  # camera.set_multi_spot_metering("OFF")
  # spotval = camera.get_multi_spot_metering(); puts "multi spot-meter=#{spotval}"

  # x = camera.get_multi_exp(); puts "multi exp time=#{x}"
  # camera.set_multi_exp("AUTO")
  # x = camera.get_multi_exp(); puts "multi exp time=#{x}"
  # camera.set_multi_exp(30)
  # x = camera.get_multi_exp(); puts "emulti exp timep=#{x}"

  # x = camera.get_multi_white_balance(); puts "white_balance{x}"
  # camera.set_multi_white_balance(400)
  # x = camera.get_multi_white_balance(); puts "white_balance=#{x}"


  # VERIFIED 8dec15
  # camera.debug=true
  # x = camera.get_multi_color(); puts "x=#{x}"
  # camera.set_multi_color("gopro_color")
  # x = camera.get_multi_color(); puts "x=#{x}"
  # camera.set_multi_color("flat")
  # x = camera.get_multi_color(); puts "color=#{x}"

  # x = camera.get_multi_sharpness(); puts "x=#{x}"
  # camera.set_multi_sharpness("MED")
  # x = camera.get_multi_sharpness(); puts "sharpness=#{x}"

  # x = camera.get_multi_iso(); puts "x=#{x}"
  # camera.set_multi_iso(400)
  # x = camera.get_multi_iso(); puts "iso=#{x}"

  # camera.set_photo_protune("OFF")
  # x = camera.get_photo_protune(); puts "protune=#{x}"
  # camera.set_photo_protune_reset()
  # spotval = camera.get_photo_spot_metering(); puts "photo spot-meter=#{spotval}"
  # x = camera.get_photo_exp(); puts "exp=#{x}"  # does NOT change after RESET
  # x = camera.get_photo_color(); puts "color=#{x}"
  # x = camera.get_photo_sharpness(); puts "sharpness=#{x}"
  # x = camera.get_photo_iso(); puts "iso=#{x}"
  # x = camera.get_photo_protune(); puts "protune=#{x}"  # does NOT change after RESET

  # camera.set_multi_protune("ON")
  # x = camera.get_multi_protune(); puts "protune=#{x}"
  # camera.set_multi_protune_reset()
  # spotval = camera.get_multi_spot_metering(); puts "multi spot-meter=#{spotval}"
  # x = camera.get_multi_exp(); puts "exp=#{x}"  # does NOT change after RESET
  # x = camera.get_multi_color(); puts "color=#{x}"
  # x = camera.get_multi_sharpness(); puts "sharpness=#{x}"
  # x = camera.get_multi_iso(); puts "iso=#{x}"
  # x = camera.get_multi_protune(); puts "protune=#{x}"  # does NOT change after RESET

  # camera.get_multi_all_settings()

  # puts camera.get_multi_shot_countdown()
  # sleep 5
  # puts camera.get_multi_shot_countdown()

  # VERIFIED 9dec15
  # camera.get_firmware_ver() # FAILED 8dec15
  # result,msg,id,name,ver = camera.get_camera_info() # FAILED 8dec15
  # puts "get_camera_info: result=#{result},msg=#{msg},id=#{id},name=\"#{name}\",ver=#{ver}"

  # VERIFIED 10dec15
  #
  # camera.debug=true
  # x = camera.get_cam_temp_warning(); puts "temp warning=#{x}"
  # x,y,z = camera.get_cam_temperatures(); puts "temps: cpu=#{x} battery=#{y} sensor=#{z}"
  # x = camera.get_recording_status(); puts "recording status=#{x}"
  # x = camera.storage_status_event(); puts "storage_status=#{x}"

  # VERIFIED 11dec15 (all storage commands)
  # x = camera.get_photo_count(); puts "photo_count=#{x}"
  # x = camera.get_video_count(); puts "video_count=#{x}"
  # x = camera.get_video_count(); puts "video_count=#{x}"

  # FAILED set hilight tag
  # puts "START VIDEO CAPTURE"
  # camera.start_video_capture(1)
  # puts "SLEEP 2.0s"
  # sleep 5.0
  # camera.debug=true
  # result = camera.set_hilight_tag()
  # camera.debug=false
  # puts "SLEEP 2.0s"
  # sleep 5.0
  # puts "STOP VIDEO CAPTURE"
  # camera.stop_video_capture(1)

  camera.debug=true
  # NTSC,1080_SUPER,24
  # camera.get_video_all_fov("ALL","NTSC", "1080_SUPER", "24")

  # VERIFIED 14dec15 (all storage commands)
  rs = camera.get_storage_remspace()
  puts "remaining storage=#{rs}"
  # result,msg,num_tags,last_tag_timestamp = camera.get_hilight_tags()  # verified 12.15.15

  # camera.set_video_resolution("WVGA")
  # camera.set_video("NTSC", "WVGA", "240", "WIDE")
  # camera.set_video("NTSC", "1080", "30", "WIDE")
  camera.debug=false
  puts ""

end

