#!/usr/bin/env ruby

#######################################################
# serial_camera.rb
# Class for connecting and communicating with a
# camera/board connected by a standard serial interface
# Instructions:
# 1) Connect board to computer (usually via USB)
# 2) Locate the serial device (probably /dev/ttyUSB0)
# 3) Make it user-readable (sudo chmod 666 /dev/ttyUSB0)
# 4) Run your test-file!

require 'fileutils'
require 'serialport'
require 'set'

require_relative 'camera'
require_relative 'host_utils'
require_relative 'log_utils'
require_relative 'serial_commands'

class SerialCamera < Camera
  include SerialCommands
  include LogUtils

  attr_accessor :last_video_attempted,
  :last_video_successful, :name

  attr_reader :screens, :release, :type, :addr, :dev,
  :audio_channels,
  :audio_codec,
  :audio_sample_rate,
  :avc_profile_level,
  :burst_modes,
  :chg_prev_br_support,
  :chg_prev_res_support,
  :colorspace,
  :data_log_model,
  :defaults,
  :looping_chapter_len,
  :multi_photo_spot_metering_support,
  :multi_photo_nightlapse_support,
  :multi_photo_protune_support,
  :multi_shutter_exposure,
  :pes_modes,
  :photo_modes,
  :photo_spot_metering_support,
  :photo_continuous_support,
  :photo_night_support,
  :photo_protune_support,
  :photo_protune_iso_values,
  :photo_shutter_exposure,
  :preview,
  :protune_white_balance_values,
  :protune_color_values,
  :protune_sharpness_values,
  :protune_exposure_values,
  :setup,
  :test_preview_stream,
  :video_codec,
  :video_capture_modes,
  :video_looping_support,
  :video_low_light_support,
  :video_lrv_bitrate,
  :video_piv_support,
  :video_piv_intervals,
  :video_protune_support,
  :video_protune_iso_values,
  :video_timelapse_lrv_bitrate,
  :video_timelapse_support,
  :wifi_mac, :blue_mac, :serialno, :cam_model, :board_type,
  :default_wait_time, :dont_verify,
  :pause_serial_cmds, :serial_io_delay, :mediadir

  alias_method :serial_iface, :dev

  def set_media_dirname(dir_re)
    @mediadir = dir_re
    log_info("New media search name is: #{@media_dir}")
  end

  def initialize(dev)
    super()
    @dev        = dev                   # e.g. /dev/ttyUSB0
    @addr       = @dev.split("/")[-1]   # e.g. ttyUSB0
    init_amba_serial_log("/tmp", @addr + "_#{Time.now.to_i}")
    @baud       = 115200
    @serialport = verify_serial_port(@dev)
    @serial_io_delay = 0
    @pause_serial_cmds = false
    @mediadir = "GOPRO"  # default camera directory name
    puts "parity=#{@serialport.parity()}"
    puts "read_timeout=#{@serialport.read_timeout()}"
    puts "signals=#{@serialport.signals()}"
    puts "modem_params=#{@serialport.modem_params()}"
    @interfaces << :serial
    @release, @type, @build, @serialno = get_cam_info()
    @default_wait_time = 1.0
    @pause_serial_cmds = false
    ### TODO: see AR-106 "Argus needs its own camera type"
    if @release == "HD4" and @type == 2 and @build.include?("03.50")   # Argus-specific versioning
      log_info("Found ARGUS camera")
      @name = "ARGUS"
      require_relative 'camera_argus'
      extend Argus
      init()
      @default_wait_time = 2.0
    elsif @release == "HD5" and @type == 1
      log_info("Found SQUIRRELS camera")
      require_relative 'camera_squirrels'
      extend Squirrels
      init()
    elsif @release == "HD5" and @type == 2
      log_info("Found STREAKY camera")
      require_relative 'camera_streaky'
      extend Streaky
      init()
    elsif @release == "HD5" and @type == 3
      log_info("Found MARGARETRIVER camera")
      require_relative 'camera_margaretriver'
      extend MargaretRiver
      init()
    elsif @release == "HD4" and @type == 1
      log_info("Found BACKDOOR camera")
      require_relative 'camera_backdoor'
      extend Backdoor
      init()
    elsif @release == "HD4" and @type == 2
      log_info("Found PIPE camera")
      require_relative 'camera_pipe'
      extend Pipe
      init()
    elsif @release == "HX1" # Only DATA ANALYTICS commands supported!
      require_relative 'camera_rockypoint'
      extend Rockypoint
      init()
    elsif @release == "HD3" and @type == 21 # Only DATA ANALYTICS commands supported!
      require_relative 'camera_haleiwa'
      extend Haleiwa
      init()
    elsif @release == "HD3" and @type == 22 # Only DATA ANALYTICS commands supported!
      require_relative 'camera_himalayas'
      extend Himalayas
      init()
    else
      log_error("Unsupported serial camera (rel=#{@release}, type=#{@type})")
      log_info("Must be rel == HD4, type == [1|2]")
      raise "Make sure camera is connected, powered on, and contains an SD card."
    end
    @host       = Host.new()
    @last_video_attempted = nil   # The last video attempt via capture_video()
    @last_video_successful = nil  # The last video success via capture_video()
    if ["BACKDOOR", "PIPE", "ARGUS"].include?(@name)
      @wifi_mac, @blue_mac, @serialno, @cam_model, @board_type = get_manufacture_data()
    end
  end

  # Verifies that the serial port exists and is readable/writable
  def verify_serial_port(dev)
    doexit = false
    if not File.exist?(dev)
      log_error("Serial device #{dev} not found. Is device plugged in?")
      doexit = true
    elsif not File.readable?(dev)
      log_error("Serial device #{dev} not readable. 'sudo chmod 666 #{dev}' ?")
      doexit = true
    elsif not File.writable?(dev)
      log_error("Serial device #{dev} not writable. 'sudo chmod 666 #{dev}' ?")
      doexit = true
    else
      begin
        serialport = SerialPort.new(dev, @baud)
      rescue StandardError => e
        log_error("Unable to open serial port at #{dev}")
        log_error(e.to_s + e.backtrace.join("\n"))
        doexit = true
      end
      return serialport
    end
    exit 1 if doexit == true
  end

  def get_cam_info(tries=5)
    version_cmds = [
      "cat c:\\MISC\\version.txt", # Hawaii, Argus
      "cat d:\\MISC\\version.txt", # RP/Hal
    ]
    # EXAMPLE:
    # {
    # "info version":"2.0",
    # "firmware version":"HD4.02.03.50.05",
    # "wifi mac":"d4d919c69b8e",
    # "camera type":"HERO4 Black",
    # "camera serial number":"C3121126266235",
    # }

    m = nil # Will hold match data from version.txt
    resp = nil
    (1..tries).each { |n|
      version_cmds.each { |v|
        puts "send_serial(#{v})"
        send_serial(v)
        resp = read_serial_resp()
        m = resp.match((/"firmware version":.*,/))
        break if m != nil
        sleep 0.5
      }
      break if m != nil
      sleep 0.5
    } # end tries

    if m == nil
      msg = "ERROR: Unable to detect camera type."
      log_info(msg)
      msg =  "Make sure it is on, has an SD card, and is not in power-save"
      log_info(msg)
      exit
    end

    fw_ver = m[0].split(":")[1][1..-3]
    fields = fw_ver.split(".")
    cam_release = fields[0]     #HD3, HD4, HX1
    cam_type = fields[1].to_i   #1, 2, 10, 11, 21
    cam_build = fields[2..-1].join(".")  # 01.23.00
    log_info("Camera Info:")
    log_conf("release, #{cam_release}")
    log_conf("type, #{cam_type}")
    log_conf("build, #{cam_build}")
    m = resp.match(/serial number":"[0-9A-Z]{14}"/)
    serialno = (m == nil) ? "UNK_SERIAL" : m[0].split(":")[1][1...-1]
    log_conf("serialno, #{serialno}")
    return cam_release, cam_type, cam_build, serialno
  end # end get_cam_info()

  def update_cam_info()
    @release, @type, @build = get_cam_info()
  end

  def get_manufacture_data()
    resp = nil
    3.times {
      send_serial("cat b:\\mfg.json")
      resp = expect("boardtype")
      break if resp != nil
      sleep 0.5
    }
    begin
      wifi_mac = resp.match(/"wifimac":"[0-9a-f]{12}"/)[0].split(":")[1][1...-1]
      blue_mac = resp.match(/"bluemac":"[0-9a-f]{12}"/)[0].split(":")[1][1...-1]
      serialno = resp.match(/"camerasn":"[0-9A-Z]{14}"/)[0].split(":")[1][1...-1]
      cam_model = resp.match(/"cammodel":"0x[0-9a-f]{2}"/)[0].split(":")[1][1...-1]
      board_type = resp.match(/"boardtype":"0x[0-9a-f]{2}"/)[0].split(":")[1][1...-1]
    rescue StandardError => e
      #p wifi_mac, blue_mac, serialno, cam_model, board_type
      log_warn("Unable to get manufacture data from #{resp}")
    end
    log_info("Manufacturing Data:")
    log_conf("wifi_mac, #{wifi_mac}")
    log_conf("blue_mac, #{blue_mac}")
    log_conf("serialno, #{serialno}")
    log_conf("cam_model, #{cam_model}")
    log_conf("board_type, #{board_type}")
    return wifi_mac, blue_mac, serialno, cam_model, board_type
  end

  # Reads from the serial port for 'limit' seconds.
  # ALL output of interest must be received by this deadline
  #def read_serial_resp(limit=@default_wait_time)
  def read_serial_resp(limit=1.0)
    resp = ""
    thr = Thread.new {
      while true do
        c = @serialport.getc
        resp << c
      end
    }
    result = thr.join(limit)
    thr.terminate
    # Remove invalid characters (happens a lot when board is reset)
    resp.encode!('UTF-16', 'UTF-8', :invalid => :replace, :replace => '')
    resp.encode!('UTF-8', 'UTF-16')
    log_amba(resp)
    return resp
  end

  # Sends a string to the serial device
  def send_serial(s)

    serial_delay()

    serial_pause_check()

    log_info("SENDING SERIAL ==> #{s}")
    @serialport.write("\r\n")
    @serialport.write(s.chomp)
    @serialport.write("\r\n")
  end

  # Returns the response if the 're' match is found.  False if otherwise.
  # The response will be all the output through time 'timeout'.
  # Time per serial port read can be controlled by setting 'limit'
  # def expect(re, timeout=0.9, limit=@default_wait_time)
  def expect(re, timeout=0.9, limit=1.0)
    # Convert all Fixnums to Strings and everything else to Regexp
    re = re.to_s if re.is_a?(Fixnum)
    re = Regexp.escape(re) if not re.is_a?(Regexp)
    start = Time.now()
    while Time.now() - start < timeout
      resp = read_serial_resp(limit)
      puts "CAMERA RESPONSE<<<<<< #{resp}" if ENV["VERBOSE"] != nil
      return resp if resp.match(re) != nil
    end
    log_debug("Expression '#{re}' not seen in #{timeout} seconds.")
    return nil
  end


  # Enable/disable pausing between serial commands
  def pause_enable(onoff)
    @pause_serial_cmds = onoff
    puts "SERIAL PAUSING ENABLED" if (onoff)
    STDIN.flush if onoff
  end

  # Set the internal delay between SERIAL commands
  # This should be triggered by the cmdline optiobn --io_delay  :io_delay
  def set_io_delay(io_delay)
    @serial_io_delay = io_delay.to_i
    log_info("Setting serial_io_delay=#{@serial_io_delay}")
  end

  def serial_delay()
    @serial_io_delay.times {print "."}  # prints out a '.' for every second delayed
    print "\n"
    sleep @serial_io_delay
  end

  def serial_pause_check()
    if @pause_serial_cmds
      puts "******** SERIAL PAUSED: HIT <ENTER> TO CONTINUE *******"
      inp = STDIN. gets
    end
  end

  # Set command that can be used for the well-formed API commands
  def set(hash, key, wait_time=@default_wait_time, verify=true, retries=1, expected=key)
    if key != nil
      [:set, key, expected].each { |k|
        if hash[k] == nil
          return false, "SCRIPT ERROR Hash #{hash} does not have a key '#{k}'"
        end
      }
      cmd = "%s %s" %[hash[:set], hash[key]]
    else
      return false, "SCRIPT ERROR Hash #{hash} missing :set key" if hash[:set] == nil
      cmd = "#{hash[:set]}"
    end

    cmd_time = nil
    retries.times { |n|
      cmd_time = Time.now()
      log_verb("Try #{n+1} sending command '#{cmd}'")
      send_serial(cmd)
      if verify == false
        break
      else
        resp = expect(cmd, 2.1, 0.9)
        if resp == nil
          log_warn("Command:#{cmd} not matched in response")
          sleep 2
          next
        else
          log_verb(resp)
          break
        end
      end
    } # end retries

    # Sleep any remaining time prescribed by wait_time arg.
    delay = wait_time - (Time.now() - cmd_time)
    sleep delay if delay > 0

    if verify == false
      return true, "Command sent (unverified)"
    elsif hash[:get] == nil
      return false, "ERROR Unable to verify command.  Hash missing ':get' key"
    else
      cmd = hash[:get]
      for n in (1..retries) do
        log_verb("Try #{n} sending command '#{cmd}'")
        send_serial(cmd)
        resp = expect(hash[expected])
        log_verb(resp)
        if resp == nil
          next if n < retries
          return false, "Expected value (#{hash[expected]}) not seen"
        else
          return true, "Expected value (#{hash[expected]}) seen"
        end
      end
    end # verify
  end # end def set

  # Override is_alive?()
  def is_alive?(retries=3, timeout=10.0)
    for n in (1..retries) do
      send_serial("help")
      return true if expect("true", timeout) != nil
    end
    return false
  end

  # Override reset_board()
  def reset_board(retries=3, timeout=20)
    (1..retries).each { |n|
      if @powerstrip == nil or (@battoutlet == nil and @usboutlet == nil)
        log_warn("Please manually reset the board")
      else
        log_warn("HARD RESET ==> Power cycling the board")
        @powerstrip.turn_off(@battoutlet) if @battoutlet != nil
        @powerstrip.turn_off(@usboutlet) if @usboutlet != nil
        sleep 3
        @powerstrip.turn_on(@battoutlet) if @battoutlet != nil
        @powerstrip.turn_on(@usboutlet) if @usboutlet != nil
      end
      sleep(10.0)
      if expect(/a:.>/, 20, 1) != nil
        # Make sure t-api commands came back
        send_serial("t api")
        if expect(/t api video/, 5, 1) == nil
          log_warn("'t api' commands not responding")
          next
        end
        exit_mass_storage_mode()
        return true
      end
    }
    log_warn("Board reset unsuccessful")
    return false
  end

  # Returns the hex-string corresponding to the git-revision of the build
  def get_build_id()
    resp = nil
    3.times {
      send_serial("ver")
      resp = expect("BANZAI")
      break if resp != nil
    }
    m = resp.match(/git-.{7}/)
    if m != nil
      ret = m[0][4..-2]
    else
      ret = nil
    end
    return ret
  end

  # Override set_capture_mode()
  # mode_sub_mode will take precedence, otherwise it will use just 'mode'
  def set_capture_mode(m)
    if ["VIDEO", "VIDEO_TIMELAPSE", "VIDEO_PIV", "VIDEO_LOOPING",
        "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT",
        "BURST", "TIMELAPSE", "NIGHTLAPSE", "BROADCAST_RECORD"].include?(m)
      ret, msg = set(mode_sub_mode, m)
      return ret, msg
    end
    if m == "VIDEO"
      mode_name = "VIDEO"
      sub_mode = video_sub_mode
      sub_name = "VIDEO"
    elsif m == "PHOTO" # For backward compatibility
      mode_name = "PHOTO"
      sub_mode = photo_sub_mode
      sub_name = "SINGLE"
    elsif ["SINGLE", "CONTINUOUS", "NIGHT"].include?(m)
      mode_name = "PHOTO"
      sub_mode = photo_sub_mode
      sub_name = m
    elsif ["BURST", "TIME_LAPSE", "NIGHT_LAPSE"].include?(m)
      mode_name = "MULTI_SHOT"
      sub_mode = multi_sub_mode
      sub_name = m
    elsif ["PLAYBACK", "SETTINGS", "FW_UPDATE", "MTP", "SOS"].include?(m)
      mode_name = m
      sub_mode = nil
    else
      log_warn("Mode #{m} not valid")
      return false, "Mode #{m} not valid"
    end
    ret, msg = set(mode, mode_name)
    return false, msg if ret == false
    if sub_mode != nil
      ret, msg = set(sub_mode, sub_name)
      return false, msg if ret == false
    end
    return true, "Set mode #{m} successful"
  end

  ###########################################################################
  # VIDEO METHODS
  ###########################################################################

  # Serial Command to transcode video_to_video
  # t api transcode video_to_video <filename> <create_lrv_only> <create_mp4_only> <allow_indexing> <output_res> <fps_divisor> <start_msec> <end_msec> <idr_interval> <gop M> <gop N> <output_bitrate>
  def transcode_video(filename, args = {})
    params = [
              args.fetch(:create_lrv_only, 0),
              args.fetch(:create_mp4_only, 0),
              args.fetch(:allow_indexing, 0),
              args.fetch(:output_res, 0),
              args.fetch(:fps_divisor, 0),
              args.fetch(:start_msec, 0),
              args.fetch(:end_msec, 0),
              args.fetch(:idr_interval, 0),
              args.fetch(:gop_m, 0),
              args.fetch(:gop_n, 0),
              args.fetch(:output_bitrate, 15_000_000)
             ]
    send_serial("t api transcode video_to_video #{filename} #{params.join(' ')}")
    resp = read_serial_resp(3.0)
    msg = resp.match(/Error: -(\d)+/).to_s
    if (match = resp.scan(/(Video  Input .*\n|Video Output .*\n|space needed \d*, space available \d*|Input frame rate .*\n)/))
      match.flatten.uniq.each do |data|
        log_info(data.chomp)
      end
    end
    error = if msg.empty?
              resp = read_serial_resp(10.0)
              while(match_str = resp.match(/percentage \d+ completed/)) do
                percent = match_str.to_s.match(/\d+/).to_s.to_i
                log_info("Transcoding progress: #{percent}")
                break if percent == 100
                resp = read_serial_resp(2.0)
              end
              nil
            else
              log_info("Transcoding Failed, #{msg}")
              resp.match(/Error: -(\d)+/).to_s.match(/-(\d)+/).to_s.to_i
            end
  end

  def set_video_protune_color(x)
    return set(color, x)
  end

  def set_video_protune_white_balance(x)
    return set(white_balance, x)
  end

  def set_video_protune_sharpness(x)
    return set(sharpness, x)
  end

  def set_video_protune_iso(x)
    return set(iso, x)
  end

  def set_video_protune_exposure(x)
   return set(exposure, x)
  end

  def set_video_def_sub_mode(x)
    return set(video_def_sub_mode, x)
  end

  def set_video_resolution(x);      return set(vid_res, x); end

  def set_video_fps(x);             return set(fps, x); end

  def set_video_fov(x);             return set(fov, x); end

  def set_piv(x);                   return set(piv, x); end

  def set_video_timelapse_rate(x)
    result, msg = set(video_timelapse_rate, x)
    msg = "set_video_timelapse_rate() ERROR " + msg if not result
    return result, msg
  end

  def set_looping(x);               return set(video_looping, x); end

  def set_video_looping(x);         return set(video_sub_mode, "LOOPING"); end

  def set_video_low_light(x);       return set(low_light, x); end

  def set_video_spot_metering(x);   return set(spot_metering, x); end

  def set_video_protune(x);         return set(video_protune, x); end

  # For compatibility with WifiCamera
  def set_protune(x);               return set_video_protune(x); end

  def set_video_white_balance(x);   return set(video_white_balance, x); end

  def set_video_color(x);           return set(video_color, x); end

  def set_video_iso(x);             return set(video_iso, x); end

  def set_video_sharpness(x);       return set(video_sharpness, x); end

  def set_video_eis(x);             return set(video_eis, x); end

  def set_video_awf(x);             return set(video_awf, x); end

  def set_video(vm, r, fs, fv)
    resp = nil
    tries = 2
    ret, msg = set(video_mode, vm, wait_time=3)
    return ret, msg if ret == false

    tries.times {
      cmd = "t api video res_fps_fov #{vid_res[r]} #{fps[fs]} #{fov[fv]}"
      send_serial(cmd)
      sleep(1.0)
      send_serial("")
      resp = expect(/a:.>/, 3.0, 1.0)
      break if resp != nil
      sleep(2.0)
    }
    return false, "Unable to send res_fps_fov command" if resp == nil

    tries.times {
      cmd = "t api video res_fps_fov"
      send_serial(cmd)
      resp = expect("#{vid_res[r]} #{fps[fs]} #{fov[fv]}", 2.0, 0.9)
      break if resp != nil
      sleep(2.0)
    }

    ########################UGLY WORKAROUND
    set(mode, "PHOTO", 4.0)
    sleep(2.0)
    set(mode, "VIDEO", 4.0)
    sleep(2.0)
    if resp != nil
      return true, "#{r}/#{fs}/#{fv} set successfully"
    else
      return false, "Set capture mode unsuccessful."
    end
  end

  def get_video_protune_setting(setting, regex)
     send_serial(setting)
     resp = expect(regex)
     if resp
       return resp.match(regex).to_s
     end
  end

 def get_video_protune_status
    get_video_protune_setting(video_protune[:get], /(on|off)/)
 end

 def get_video_protune_white_balance
    get_video_protune_setting(white_balance[:get], /(auto|3000k|5500k|6500k|native)/)
 end

 def get_video_protune_color
     get_video_protune_setting(color[:get], /(flat|gopro_color)/)
 end

 def get_video_protune_iso
     get_video_protune_setting(iso[:get], /(6400|3200|1600|800|400)/)
 end

 def get_video_protune_sharpness
     get_video_protune_setting(sharpness[:get], /(high|medium|low)/)
 end

 def get_video_protune_exposure
     get_video_protune_setting(exposure[:get],  /(\-2|\-1\.5|\-0\.5|0|\+0\.5|\+1|\+1\.5|\+2)/)
 end

  def get_current_capture_mode()
    send_serial(mode[:get])
    resp = expect(/(photo|video|multi_shot)/)
    if resp
      resp.split("\n").each do |l|
        return l.chomp if ["photo","video","multi_shot"].include?(l.chomp)
      end # do
    end # if
    return nil
  end # get_current_capture_mode

  # Override start_capture()
  def start_capture(retries=1)
    # Try to poll the camera for the current capture mode.
    m = get_current_capture_mode()
    unless m
      log_warn("start_capture(): Defaulting to starting video capture.")
      m = "video"
    end
    return start_video_capture(retries) if m == "video"
    return start_photo_capture(retries) if m == "photo"
    return start_multi_capture(retries) if m == "multi_shot"
    return false, "Unknown capture mode."
  end # start_capture

  # Override stop_capture()
  def stop_capture(retries=1)
    # Try to poll the camera for the current capture mode.
    m = get_current_capture_mode()
    unless m
      log_warn("stop_capture(): Defaulting to stopping video capture.")
      m = "video"
    end
    # We should poll the camera for the current mode and do the right one.
    return stop_video_capture(retries) if m == "video"
    return stop_photo_capture(retries) if m == "photo"
    return stop_multi_capture(retries) if m == "multi_shot"
    return false, "Unknown capture mode."
  end # stop_capture

  # Start capturing video.
  def start_video_capture(r=2)
    retries = r
    for n in (1..retries) do
      result, msg = set(video_record, "START", wait_time=1.0, verify=false)
      re = /C:.*MPG/
      resp = expect(re, timeout=5, limit=1.0)
      if resp == nil
        next if n < retries
        return false, "Start video capture failed. re=#{re.to_s} NOT found"
      else
        matchgroup = resp.match("C:.*MP4")
        return true, matchgroup[0]
      end
    end
  end # start_video_capture

  # Stop capturing video.
  def stop_video_capture(r=2)
    retries = r
    timeout = 10.0
    (1..retries).each { |n|
      start_time = Time.now()
      set(video_record, "STOP", wait_time=1.0, verify=false)
      sleep(3.0)
      while true
        return true, "Stop video capture successful." if not busy?
        elapsed = Time.now() - start_time
        break if elapsed > timeout
      end
    }
    return false, "Stop video capture failed."
  end # stop_video_capture

  # Start capturing photo. Relocate this?
  # I'm not sure that we should be expecting a response here.
  def start_photo_capture(r=2)
    retries = r
    for n in (1..retries) do
      set(photo_capture, "START", wait_time=1.0, verify=false)
      resp = expect(/C:.*JPG/, timeout=5, limit=1.0)
      if resp == nil
        next if n < retries
        return false, "Start photo capture failed."
      else
        matchgroup = resp.match("C:.*JPG")
        return true, matchgroup[0]
      end
    end
  end # start_photo_capture

  # Stop capturing photo. Relocate this?
  def stop_photo_capture(r=2)
    retries =
    timeout = 10.0
    (1..retries).each { |n|
      start_time = Time.now()
      set(photo_capture, "STOP", wait_time=1.0, verify=false)
      sleep(3.0)
      while true
        return true, "Stop photo capture successful." if not busy?
        elapsed = Time.now() - start_time
        break if elapsed > timeout
      end
    }
    return false, "Stop photo capture failed."
  end # stop_photo_capture

  # Captures video at a given RES/FPS/FOV for a given duration (in seconds)
  # Return status, msg.
  # status is true on success, false on fail.
  # msg holds information on pass/fail reason.
  def capture_video(vm, res, fps, fov, duration=5, ll=nil, spot=nil,
    pt=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
    @last_media = nil
    retries = 1

    (1..retries).each { |n|
      @last_video_attempted = nil
      log_debug("Capture video try #{n} of #{retries}")
      if set_capture_mode("VIDEO") == false
        next if n < retries
        return false, "Unable to set camera mode to VIDEO capture"
      end

      log_debug("Setting ProTune #{pt}")
      ret, msg = set_video_protune(pt)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_debug("Setting capture mode")
      ret, msg = set_video(vm, res, fps, fov)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_debug("Starting capture")
      start_time = Time.now()
      ret, msg = start_capture()
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      elapsed = Time.now() - start_time
      if duration > 5
        sleep (duration - elapsed) if (duration - elapsed) > 0
      else
        sleep duration
      end

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end # end capture_video

  def capture_piv(vm, res, fps, fov, p, duration, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      log_debug("Capture PIV try #{n} of #{retries}")
      ret, msg = set(mode, "VIDEO")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      ret, msg = set(video_sub_mode, "PIV")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      log_info("Setting PIV to #{p}s")
      ret, msg = set_piv(p)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      if ll != nil
        log_info("Setting low-light #{ll}")
        ret, msg = set_video_low_light(ll)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      if spot != nil
        log_info("Setting spot-metering #{spot}")
        ret, msg = set_video_spot_metering(spot)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      @last_video_attempted = nil
      log_debug("Setting capture mode")
      #ntsc_or_pal = (is_ntsc?(res, fps)) ? "NTSC" : "PAL"
      #ret, msg = set_video(ntsc_or_pal, res, fps, fov)
      ret, msg = set_video(vm, res, fps, fov)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_info("Starting capture for #{duration}s")
      start_time = Time.now()
      ret, msg = start_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      dur = duration - (Time.now() - start_time)
      sleep(dur) if dur > 0

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end

  def capture_looping(vm, res, fps, fov, loo, duration, setonly=false, orient=nil, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      log_debug("Capture PIV try #{n} of #{retries}")
      ret, msg = set(mode, "VIDEO")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      ret, msg = set(video_sub_mode, "LOOPING")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      log_debug("Setting capture mode to #{vm}")
      ret, msg = set_video(vm, res, fps, fov)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      log_info(msg)

      vid_remain = get_rem_videos()
      if vid_remain == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, "Unable to query # remaining videos"
      end
      log_verb("Duration=#{duration}s, Space avail=#{vid_remain}s")
      if duration > vid_remain
        return false, "Insufficient space on SD card"
      end

      log_info("Setting looping to #{loo} min.")
      ret, msg = set_looping(loo)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      if ll != nil
        log_info("Setting low-light #{ll}")
        ret, msg = set_video_low_light(ll)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      if spot != nil
        log_info("Setting spot-metering #{spot}")
        ret, msg = set_video_spot_metering(spot)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      return true, "Looping mode successfully set" if setonly == true

      @last_video_attempted = nil
      log_info("Starting capture for #{duration}s")
      start_time = Time.now()
      ret, msg = start_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      sleep(10.0)

      failed_arr = []
      lrvfile = @last_video_attempted[0..-4] + "LRV"
      exp = has_lrv?(res, fps, fov)
      act = media_exists?(lrvfile)
      if exp != act
        failed_arr << "LRV file (#{lrvfile}) presence (exp=#{exp}, act=#{act})"
      end
      log_warn("Skipping thumbnail verification on HD4 looping for now")

      dur = duration - (Time.now() - start_time)
      sleep(dur) if dur > 0

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false
        next if n < retries
        return false, status_msg
      end
      if ret == false
        next if n < retries
        return false, msg
      end
      if not failed_arr.empty?
        return false, failed_arr.join(",")
      end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end

  ###########################################################################
  # PHOTO METHODS
  ###########################################################################
  # These method names should override abstract methods in camera.rb when
  # possible to ensure test-case compatibility

  # serial command to transcode photo_to_video
  # t api transcode photo_to_video <filename> <allow_indexing> <sequence_count> <output_res>
  def transcode_photo(file_name, args = {})
    params = [
      args.fetch(:allow_indexing, 0),
      args.fetch(:sequence_count, 0),
      args.fetch(:output_res, 0)
    ]
    send_serial("t api transcode photo_to_video #{file_name} #{params.join(' ')}")
    resp = read_serial_resp(2.0)
    msg = resp.match(/Error: -(\d)+/).to_s
    if (match = resp.scan(/(JPEG  Input .*\n|Video Output .*\n|Input File .*\n|Output File .*\n)/))
      match.flatten.uniq.each do |data|
        log_info(data.chomp)
      end
    end
    error = if msg.empty?
              resp = read_serial_resp
              while(match_str = resp.match(/percentage \d+ completed/)) do
                percent = match_str.to_s.match(/\d+/).to_s.to_i
                log_info("Transcoding progress: #{percent}")
                break if percent == 100
                resp = read_serial_resp
              end
              nil
            else
              log_info("Transcoding Failed, #{msg}")
              resp.match(/Error: -(\d)+/).to_s.match(/-(\d)+/).to_s.to_i
            end
  end

  def set_photo_def_sub_mode(x);    return set(photo_def_sub_mode, x); end

  def set_photo_res(x);             return set(photo_res, x); end

  def set_sps(x);                   return set(sps, x); end

  def set_photo_exp(x);             return set(photo_exp, x); end

  def set_photo_spot_metering(x);   return set(photo_spot, x); end

  def set_photo_protune(x);         return set(photo_protune, x); end

  def set_photo_white_balance(x);   return set(photo_white_balance, x); end

  def set_photo_color(x);           return set(photo_color, x); end

  def set_photo_iso(x);             return set(photo_iso, x); end

  def set_photo_sharpness(x);       return set(photo_sharpness, x); end

  def set_photo_protune_exposure(x); return set(photo_protune_exposure, x); end

  def set_photo_raw(x);             return set(photo_raw, x); end

  def ser_photo_wdr(x);             return set(photo_wdr, x); end

  def capture_photo_single(res, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries=2
    (1..retries).each { |n|
      ret, msg = set_capture_mode("PHOTO")
      if ret == false
        (is_alive?) ? do_reset() : reset_board()
        next if n < retries
        return false, msg
      end

      ret, msg = set_photo_res(res)
      if ret == false
        (is_alive?) ? do_reset() : reset_board()
        next if n < retries
        return false, msg
      end

      ret, msg = set_photo_spot_metering(spot) if spot != nil
      if ret == false
        (is_alive?) ? do_reset() : reset_board()
        next if n < retries
        return false, msg
      end

      if [wb, col, iso, sh, ex] != [nil, nil, nil, nil, nil]
        ret, msg = set_photo_protune("ON")
        if ret == false
          (is_alive?) ? do_reset() : reset_board()
          next if n < retries
          return false, msg
        end
        ret, msg = set_photo_white_balance(wb) if wb != nil
        if ret == false
          (is_alive?) ? do_reset() : reset_board()
          next if n < retries
          return false, msg
        end
        ret, msg = set_photo_color(col) if col != nil
        if ret == false
          (is_alive?) ? do_reset() : reset_board()
          next if n < retries
          return false, msg
        end
        ret, msg = set_photo_iso(iso) if iso != nil
        if ret == false
          (is_alive?) ? do_reset() : reset_board()
          next if n < retries
          return false, msg
        end
        ret, msg = set_photo_sharpness(sh) if sh != nil
        if ret == false
          (is_alive?) ? do_reset() : reset_board()
          next if n < retries
          return false, msg
        end
        ret, msg = set_photo_protune_exposure(ex) if ex != nil
        if ret == false
          (is_alive?) ? do_reset() : reset_board()
          next if n < retries
          return false, msg
        end
      end

      #send_serial("t api app apply")
      sleep(3.0)
      set(photo_capture, "START", wait_time=1.0, verify=false)

      resp = expect(/C:.*JPG/, timeout=10, limit=1.0)
      if resp == nil
        (is_alive?) ? do_reset() : reset_board()
        next if n < retries
        return false, "Start capture failed"
      else
        matchgroup = resp.match(/C:.*JPG/)
        return true, matchgroup[0]
      end
    }
  end

  def capture_photo_continuous(res, sps, duration=5.0, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil, quickpress=false)
    retries = 2
    (1..retries).each { |n|
      ret, msg = set_capture_mode("CONTINUOUS")
      if ret == false; next if n < retries; return false, msg; end

      ret, msg = set_photo_res(res)
      if ret == false; next if n < retries; return false, msg; end

      ret, msg = set_sps(sps)
      if ret == false; next if n < retries; return false, msg; end

      ret, msg = set_photo_spot_metering(spot) if spot != nil
      if ret == false; next if n < retries; return false, msg; end

      if [wb, col, iso, sh, ex] != [nil, nil, nil, nil, nil]
        ret, msg = set_photo_protune("ON")
        if ret == false; next if n < retries; return false, msg; end
        ret, msg = set_photo_white_balance(wb) if wb != nil
        if ret == false; next if n < retries; return false, msg; end
        ret, msg = set_photo_color(col) if col != nil
        if ret == false; next if n < retries; return false, msg; end
        ret, msg = set_photo_iso(iso) if iso != nil
        if ret == false; next if n < retries; return false, msg; end
        ret, msg = set_photo_sharpness(sh) if sh != nil
        if ret == false; next if n < retries; return false, msg; end
        ret, msg = set_photo_protune_exposure(ex) if ex != nil
        if ret == false; next if n < retries; return false, msg; end
      end

      #send_serial("t api app apply")
      sleep(3.0)
      start_time = Time.now()
      if quickpress == true
        send_serial("t button press 1 250")
      else
        set(photo_capture, "START", wait_time=0.0, verify=false)
      end
      resp = expect(/C:.*JPG/, timeout=10, limit=1.0)

      if resp == nil
        (is_alive?) ? do_reset() : reset_board()
        next if n < retries
        return false, "Start capture failed"
      else
        t = duration - (Time.now() - start_time)
        sleep(t) if t > 0
        set(photo_capture, "STOP", wait_time=1.0, verify=false) if quickpress == false
        sleep(7.0)
        wait_until_not_busy(1.0, 15)
        matchgroup = resp.match(/C:.*JPG/)
        return true, matchgroup[0]
      end
    }
  end

  # spot metering (spot)
  # exposure value (ev),
  # white-balance (wb)
  # color (col)
  # ISO (iso)
  # sharpness (sh)
  # ProTune exposure (ex)
  #  def capture_photo_night(res, spot=nil, ev=nil, wb=nil, col=nil, iso=nil,
  #    sh=nil, ex=nil, retries=2)
  def capture_photo_night(res, duration, spot=nil, pt=nil, ev=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    retries = 2
    # Set to 0 if is set to "OFF" or "AUTO"
    if ev.is_a?(Fixnum)
      shutter_time = ev
    else
      shutter_time = 0
    end

    (1..retries).each { |n|
      ret, msg = set_capture_mode("NIGHT")
      if ret == false; next if n < retries; return false, msg; end

      ret, msg = set_photo_res(res)
      if ret == false; next if n < retries; return false, msg; end

      ret, msg = set_photo_spot_metering(spot)
      if ret == false; next if n < retries; return false, msg; end

      ret, msg = set_photo_protune(pt)
      if ret == false; next if n < retries; return false, msg; end

=begin
      if ev == "OFF" or ev == nil
        ret, msg = set_photo_protune("OFF")
        if ret == false; next if n < retries; return false, msg; end
      else
        ret, msg = set_photo_protune("ON")
        if ret == false; next if n < retries; return false, msg; end
=end

      ret, msg = set_photo_exp(ev)if ev != nil
      if ret == false; next if n < retries; return false, msg; end
      ret, msg = set_photo_white_balance(wb) if wb != nil
      if ret == false; next if n < retries; return false, msg; end
      ret, msg = set_photo_color(col) if col != nil
      if ret == false; next if n < retries; return false, msg; end
      #      ret, msg = set_photo_iso(iso) if iso != nil
      #      if ret == false; next if n < retries; return false, msg; end
      ret, msg = set_photo_sharpness(sh) if sh != nil
      if ret == false; next if n < retries; return false, msg; end
      ret, msg = set_photo_protune_exposure(ex) if ex != nil
      if ret == false; next if n < retries; return false, msg; end

      # send_serial("t api app apply")
      sleep(3.0)
      set(photo_capture, "START", wait_time=1.0, verify=false)
      sleep(duration)
      resp = expect(/C:.*JPG/, timeout=shutter_time+5, limit=1.0)
      if resp == nil
        next if n < retries
        return false, "Start capture failed"
      else
        matchgroup = resp.match(/C:.*JPG/)
        return true, matchgroup[0]
      end
    }
  end

  ###########################################################################
  # MULTI-SHOT METHODS
  ###########################################################################

  def set_multi_def_sub_mode(x);    return set(multi_def_sub_mode, x); end

  def set_multi_res(x);             return set(multi_res, x); end

  def set_burst(x);                 return set(burst, x); end

  def set_time_lapse(x);            return set(time_lapse, x); end

  def set_night_lapse(x);           return set(night_lapse, x); end

  def set_multi_spot_metering(x);   return set(multi_spot, x); end

  def set_multi_protune(x);         return set(multi_protune, x); end

  def set_multi_protune_shutter_exposure(x); return set(multi_exp, x); end

  def set_multi_white_balance(x);   return set(multi_white_balance, x); end

  def set_multi_color(x);           return set(multi_color, x); end

  def set_multi_iso(x);             return set(multi_iso, x); end

  def set_multi_sharpness(x);       return set(multi_sharpness, x); end

  def set_multi_protune_exposure(x); return set(multi_protune_exposure, x); end

  def set_multi_capture(x);         return set(multi_capture, x); end

  # This one wasn't abstracted properly. Calls the correct method above.
  def set_multi_photo_burst(x);     return set_burst(x); end

  def capture_multi_photo_burst(res, bu, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    tries = 2
    (1..tries).each { |n|
      log_info("Capturing #{res} #{bu} burst (try #{n} of #{tries})")
      ret = false
      msg = "Failed to set multi_shot burst mode"
      (1..3).each {
        ret, msg = set(mode_sub_mode, "MULTI_BURST")
        next if ret == false
        break
      }
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_multi_res(res)
      if ret == false
        next if n < tries
        return false, msg
      end
      ret, msg = set_burst(bu)
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_multi_spot_metering(spot) if spot != nil
      if ret == false
        next if n < tries
        return false, msg
      end

      if pt !=nil
        ret, msg = set_multi_protune(pt)
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_white_balance(wb) if wb != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_color(col) if col != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_iso(iso) if iso != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_sharpness(sh) if sh != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_protune_exposure(ex) if ex != nil
        if ret == false
          next if n < tries
          return false, msg
        end
      end # end pt
      sleep(3.0)

      set(multi_capture, "START", wait_time=0, verify=false)
      resp = expect(/C:.*JPG/, timeout=5, limit=1.0)
      if resp == nil
        next if n < tries
        return false, "Burst capture failed"
      end
      matchgroup = resp.match(/C:.*JPG/)
      wait_until_not_busy(interval=1.0, timeout=30)
      return true, "Capture successful. First file=#{matchgroup[0]}"
    }
  end

  def start_multi_capture(tries=3, interval=3.0)
    (1..tries).each { |n|
      set(multi_capture, "START", wait_time=0.5, verify=false)
      return true if recording?
      sleep(interval)
    }
    log_warn("Multi capture not started successfully")
    return false
  end

  def stop_multi_capture(tries=3, interval=3.0)
    (1..tries).each { |n|
      set(multi_capture, "STOP", wait_time=3.0, verify=false)
      return true if not recording?
      sleep(interval)
    }
    log_warn("Multi capture not stopped successfully")
    return false
  end

  # multi_mode can be 'TIME_LAPSE' or 'NIGHT_LAPSE'
  def capture_multi_photo_timelapse(res, pes_interval, duration, orient=nil,
    spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil, multi_mode="TIME_LAPSE", se=nil)
    tries = 2
    # TODO: Handle and use orient variable for Serial Cameras.
    log_warn("Ignoring orient variable. Serial cameras need updating to use it properly.") if orient
    (1..tries).each { |n|
      log_info(
      "Capturing #{res} #{pes_interval}s #{multi_mode} (try #{n} of #{tries})")
      ret, msg = set_capture_mode(multi_mode)
      if ret == false
        next if n < tries
        return false, msg
      end
      ret, msg = set_photo_res(res)
      if ret == false
        next if n < tries
        return false, msg
      end
      # We need to set the shutter exposure before the time/nightlapse interval.
      # This is because not all interval values can be set at all shutter values.
      # I think this function is misnamed - this isn't a protune-only setting!
      ret, msg = set_multi_protune_shutter_exposure(se) if se != nil
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_time_lapse(pes_interval) if multi_mode == "TIME_LAPSE"
      ret, msg = set_night_lapse(pes_interval) if multi_mode == "NIGHT_LAPSE"
      if ret == false
        next if n < tries
        return false, msg
      end

      if pt !=nil
        ret, msg = set_multi_protune(pt)
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_spot_metering(spot) if spot != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_white_balance(wb) if wb != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_color(col) if col != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_iso(iso) if iso != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_sharpness(sh) if sh != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_protune_exposure(ex) if ex != nil
        if ret == false
          next if n < tries
          return false, msg
        end
      end # end pt
=begin
      pes_sleep_time = [min_length, (min_photos * pes_interval)].max
      # Correction because PES takes a photo at 0s
      pes_sleep_time -= (0.5 * pes_interval)
      # Correction in case previous correction lands us right on a photo boundary
      # which is the case for 2s PES on the default settings
      pes_sleep_time -= (0.5 * pes_interval) if (pes_sleep_time == min_photos * pes_interval)

      pes_str = (pes_interval < 1) ? "%0.1f" %pes_interval : pes_interval.to_i.to_s
      log_info("Taking %ss #{multi_mode} for %0.1fs (should yield ~%d photo(s))" \
      %[pes_str, pes_sleep_time, ((pes_sleep_time/pes_interval)+1)])
=end
      #send_serial("t api app apply")
      sleep(3.0)

      start_time = Time.now()
      if start_multi_capture() == false
        (is_alive?) ? do_reset() : reset_board()
        next if n < tries
        return false, "#{multi_mode} capture failed to start"
      end
      log_info("Capture started successfully")

      # Discount any time taken to start capture from capture duration
#      sleep_time = pes_sleep_time - (Time.now() - start_time)
      sleep(duration) if duration > 0

      if stop_multi_capture() == false
        (is_alive?) ? do_reset() : reset_board()
        next if n < tries
        return false, "#{multi_mode} capture failed to stop"
      end
      return true, "Capture stopped successfully"
    }
  end # End capture_photo_time_lapse

  def capture_multi_photo_nightlapse(res, pes, duration, orient=nil, spot=nil, pt=nil, se=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
#    iso = nil
#    min_photos = 2
#    min_length = 10
    capture_multi_photo_timelapse(res, pes, duration, orient, spot, pt, wb, col,
    sh, iso, ex, multi_mode="NIGHT_LAPSE", se)
  end

  ###########################################################################
  # SETUP/SETTINGS
  ###########################################################################
  def set_lcd_brightness(x); return set(lcd_brightness, x); end

  def set_lcd_auto_off(x); return set(lcd_auto_off, x); end

  def set_orientation(x); return set(orientation, x); end

  def set_default_capture_mode(x); return set(default_mode, x); end

  def set_obm(x); return set(obm, x); end

  def set_quickcapture(x); return set_obm(x); end

  def set_led(x); return set(led, x); end

  def set_beep_sound(x); return set(beep_sound, x); end

  def set_video_mode(x)
    result, msg = set(video_mode, x)
    msg = "set_video_mode() ERROR " + msg if not result
    return result, msg
  end

  def set_osd(x); return set(osd, x); end

  def set_auto_off(x); return set(auto_off, x); end

  def do_apply_settings(); return set(apply_settings, nil, 1.0, false); end

  def get_internal_battery_info
    send_serial(internal_battery_info[:get])
    resp = read_serial_resp
    match_str = resp.match(/\d+%.*\n/).to_s.chomp
    match_str.empty? ? nil : match_str
  end

  # def get_battery_level(); return get(battery_level, nil, 1.0, false); end
  def get_battery_level()
    send_serial(battery_level[:get])
    re = /[0-9]{1,3}/
    resp = expect(re)
    return false, "Unable to get battery level" if resp == nil
    level = resp.match(re)[0].to_i
    return false, "Invalid battery level: #{level}" if not (0 <= level and level <= 100)
    return level
  end

  def get_firmware_version()
    send_serial(firmware_version[:get])
    re = /0x\h+ 0x\h+ 0x\h+/
    resp = expect(re)
    return false, 0,0,0, "Unable to firmware version" if resp == nil
    respMatchRe = resp.match(re)[0]
    va = respMatchRe.scan(/0x(\h+) 0x(\h+) 0x(\h+)/)
    va = va[0]
    major = va[0].to_i(16)
    minor = va[1].to_i(16)
    build = va[2].to_i(16)
    # TODO: do more checks here, ie: return false, "Invalid firmware version : #{level}" if not (0 <= level and level <= 100)
    n = 2 # number of leading '0' digits
    fwversion = major.to_s.rjust(n, "0") + "." + minor.to_s.rjust(n, "0") + "." + build.to_s.rjust(n, "0")
    return fwversion, major, minor, build, "OK"
  end

  # NEW 11.13.15
  # Note: use this especially if too much verbose debug messages are causing the serial
  # response handler to misinterpret or call errors on the command just sent
  #
  def set_debug(x)
    return set(debug_cmds, x, @default_wait_time, @dont_verify)
  end

  def do_shutdown(); return set(shutdown, nil, 1.0, false); end

  def do_reset(force=true, timeout=30)
    set(reset, nil, 1.0, false) if force == true
    set(reset_no_force, nil, 1.0, false) if force == false
    resp = expect("AmbaShell ;)", timeout, 1)
    return false, "Reset -- 'AmbaShell' message not seen" if resp == nil
    return true, "Reset -- AmbaShell message seen."
  end

  def do_beep_blink(x); return set(beep_blink, x); end

  def do_factory_reset(x)
    set(factory_reset, x, 1.0, false)
    resp = expect("AmbaShell ;)", 20, 1)
    return false, "Factory reset -- 'AmbaShell' message not seen" if resp == nil
    return true, "Factory reset -- AmbaShell message seen."
  end

  def parse_yes_no(cmd, tries=2)
    (1..tries).each { |n|
      send_serial(cmd)
      re = /(^yes|^no)/
      resp = expect(re)
      if resp == nil
        next if n <= tries
        log_warn("Unable to parse yes/no from '#{resp}'")
        return false, "Unable to match yes/no"
      else
        return true if resp.match(re)[0] == "yes"
        return false if resp.match(re)[0] == "no"
      end
      return nil
    }
  end

  def parse_on_off(cmd, tries=2)
    (1..tries).each { |n|
      send_serial(cmd)
      re = /(^on|^off)/
      resp = expect(re)
      if resp == nil
        next if n <= tries
        log_warn("Unable to parse on/off from '#{resp}'")
        return false, "Unable to match on/off"
      else
        return true if resp.match(re)[0] == "on"
        return false if resp.match(re)[0] == "off"
      end
      return nil
    }
  end

  def recording?
    parse_yes_no(recording_status[:get])
  end

  def busy?
    parse_yes_no(busy_status[:get])
  end

  def hot?
    parse_yes_no(temperature_warn_status[:get])
  end

  def ready?
    parse_yes_no(ready_status[:get])
  end

  def temperatures
    2.times do
      send_serial(temperature[:get])
      res = read_serial_resp
      unless res.empty?
        res = res.split(' ')
        temps = []
        res.each do |val|
           val = val.to_i
           temps << val if val != 0
        end
        return temps
      end
    end
  end

  def save_settings
    2.times {
      send_serial("t appc settings save")
      sleep 1
    }
  end

  def quick_capturing?
    parse_yes_no(quick_capture_status[:get])
  end

  def wait_until_not_busy(interval=1.0, timeout=10)
    start = Time.now()
    loop {
      (recording?) ? sleep(interval) : (return true)
      log_verb("Waiting for camera not busy...")
      break if (Time.now() - start) > timeout
    }
    log_warn("Timeout waiting for camera not busy")
    return false
  end

  # Returns false if not supported, and a list of languages if supported.
  def language_support?()
    # Deem it supported if "t api setup" contains a "language" option.
    cmd = "t api setup" # Might vary on other cameras.
    send_serial(cmd)
    resp = read_serial_resp()
    return false unless resp and resp.match(/language/)
    ret = resp.match(/language.*/).to_s.match(/\[.*\]/).to_s.gsub("[","").gsub("]","").split("|")
    return ret
  end

  def get_language()
    langs = language_support?()
    return false unless langs
    cmd = language[:get] # Might vary on other cameras?
    send_serial(cmd)
    resp = read_serial_resp()
    langs.each { |lang| return lang if resp and resp.match(lang) }
    return false
  end

  # What does this do if we pass in nil?
  def set_language(x); return set(language, x); end

  ###########################################################################
  # Playback
  ###########################################################################
  def pb_start(); return set(playback_start, nil, 1.0, false); end

  def pb_stop(); return set(playback_stop, nil, 1.0, false); end

  def pb_pause(); return set(playback_pause, nil, 1.0, false); end

  def pb_resume(); return set(playback_resume, nil, 1.0, false); end

  def pb_step(); return set(playback_step, nil, 1.0, false); end

  def pb_forward(x); return set(playback_forward, x); end

  def pb_backward(x); return set(playback_forward, x); end

  def pb_start_slideshow; return set(playback_slideshow_start, nil, 1.0, false); end

  def pb_stop_slideshow; return set(playback_slideshow_stop, nil, 1.0, false); end

  def pb_multi_slideshow(); return set(playback_multi_slideshow, nil, 1.0, false); end

  def pb_next(); return set(playback_next, nil, 1.0, false); end

  def pb_prev(); return set(playback_prev, nil, 1.0, false); end

  def pb_tsearch(x); return set(playback_tsearch, x); end

  ###########################################################################
  # Storage
  ###########################################################################

  def set_tag(); return set(storage_tag, nil, 1.0, false); end

  def storage_count(cmd, tries=2)
    (1..tries).each {
      send_serial(cmd)
      re = /^[0-9]{1,6}/
      resp = expect(re)
      next if resp == nil
      return resp.match(re)[0].to_i
    }
    return false
  end

  #  def get_total_files(); return storage_count(total_files[:get]); end

  def get_photo_count(); return storage_count(photo_count[:get]); end

  def get_video_count()
    result = storage_count(video_count[:get])
    msg = "get_video_count() ERROR" if not result
    return result, msg
  end

  def get_rem_photos(); return storage_count(photos_rem[:get]); end

  def get_rem_videos(); return storage_count(vid_time_rem[:get]); end

  # For compatibility with WifiCamera
  def get_mins_avail()
    ret = get_rem_videos()
    if ret.to_i > 0
      return ret/60
    end
    log_warn("Unable to get remaining videos")
    return nil
  end

  def get_photos_avail()
    return get_rem_photos()
  end

  def get_photo_group_count(); return storage_count(group_photo_count[:get]); end

  def get_video_group_count(); return storage_count(group_video_count[:get]); end

  def get_last_file(tries=2)
    (1..tries).each {
      send_serial(last_file[:get])
      resp = read_serial_resp()
      m = resp.match(/.{8}\.MP4/)
      return m if m != nil
      m = resp.match(/.{8}\.JPG/)
      return m if m != nil
      sleep 0.5
    }
    return false, "Unable to get last file"
  end

  def storage_delete_all()
    result, msg = set(delete_all, nil, 3.0, false)
    msg = "storage_delete_all()() ERROR " + msg if not result
    return result, msg
  end

  # TODO: Figure out if this requires an arg?
  def storage_delete_one(x); return set(delete_one, x, 1.0, false); end

  def storage_delete_last(); return set(delete_last, nil, 1.0, false); end

  # TODO: Figure out if this requires an arg?
  def storage_delete_group(x); return set(delete_group, x, 1.0, false); end

  def storage_status_event(x); return set(storage_status_event, x, 1.0, false); end

  ###########################################################################
  # WIRELESS
  ###########################################################################
  def set_wireless_mode(x)
    log_info("Setting wireless mode to #{x}")
    return set(wireless_mode, x)
  end

  def do_wifi_scan()
  end

  def do_pairing(x); return set(pairing, x, 1.0, false); end

  def do_pairing_stop(); return set(pairing_stop, nil, 1.0, false); end

  def do_wireless_ble(); return set(wireless_ble, nil, 1.0, false); end

  def do_push_multek(); return set(push_multek, nil, 1.0, false); end

  # Enable APP mode and return the ssid, pairing code of the camera
  # Returns false, false upon failure
  def enable_app_mode(ssid=nil, pc=nil)
    ssid = get_wifi_ssid() if ssid == nil
    pc = get_wifi_passphrase() if pc == nil
    if ssid != nil or pc != nil
      resp = nil
      log_info("Setting camera AP to ssid=#{ssid}, pc=#{pc}")
      3.times {
        send_serial("t api wireless ap_set #{ssid} #{pc}")
        resp = expect("SUCCESS")
        break if resp != nil
        sleep 1
      }
    else
      log_info("Using current camera wifi settings (ssid=#{ssid}, pc=#{pc})")
    end
    ret, msg = set_wireless_mode("APP")
    return ssid, pc if ret == true
    return false, false if ret == false
  end

  def get_csi(type, arg)
    ret = nil
    cmd = "t api wireless csi_get #{arg}"
    send_serial(cmd)
    resp = expect(/SUCCESS/)
    if resp == nil
      log_warn("No SUCCESS seen for arg=#{arg}")
      return ret
    end
    # TODO: Other types?
    if type == "STRING"
      re = /str - [a-zA-Z0-9_\-]+/
      resp_str = resp.match(re)
      if resp_str == nil
        log_warn("No valid string found in #{resp}")
      else
        ret = resp_str[0][6..-1].strip()
      end
    elsif type == "INT"  # Don't think any of them are floats...
      re = /value - \d+/
      resp_str = resp.match(re)
      if resp_str == nil
        log_warn("No valid number found in #{resp}")
      else
        ret = resp_str[0][8..-1].strip().to_i
      end
    end
    log_verb("Got #{arg} (#{type}) = #{ret}")
    return ret
  end

  def get_wifi_passphrase(); get_csi("STRING", "CSI_APP_PASSPHRASE"); end

  def get_wifi_ssid(); get_csi("STRING", "CSI_APP_SSID"); end

  def get_wireless_pin()
    cmd = "t appc wireless pin"
    send_serial(cmd)
    re = /^[0-9]{6}/
    resp = expect(re)
    if resp != nil
      return resp.match(re)[0].strip()
    end
    return nil
  end



  ###########################################################################
  # FW UPDATE
  ###########################################################################
  def do_fw_update_start(); return set(fw_update_start, nil, 1.0, false); end

  def do_fw_update_reset(); return set(fw_update_reset, nil, 1.0, false); end

  def do_boot_fw(); return set(boot_fw, nil, 1.0, false); end

  ###########################################################################
  # VID_FEATURE_AVAIL
  ###########################################################################
  # Takes capability-string, mode, res, fps, fov and returns whether it is supported
  # Capability strings are "piv", "low_light", "protune", "timelapse", "jello_slayer"
  def video_capability_filter_check(cap_str, m, r, fs, fv)
    cmd = method(cap_str+"_avail").call[:get]
    cmd_str = "#{cmd} #{m} #{vid_res[r]} #{fps[fs]} #{fov[fv]}"
    send_serial(cmd_str)
    re = /supported/
    resp = expect(re)
    return false, "Unable to get #{cap_str} availability" if resp == nil
    return true, true if resp.match("#{cap_str} supported") != nil
    return true, false if resp.match("#{cap_str} not supported") != nil
    return false, "Unable to read #{cap_str} support value from #{resp}"
  end

  ###########################################################################
  # Data Analytics logging methods
  ###########################################################################
  def file_exists(f)
    cmd = "ls #{f}"
    # Get basename from full path
    f_base = f.split("\\")[-1]
    2.times {
      send_serial(cmd)
      resp = read_serial_resp()
      resp.each_line { |l|
        begin
          poss_file = l.split()[6]
        rescue StandardError
          next
        end
        next if poss_file == nil
        return true if poss_file.match(f_base)
      }
    }
    return false
  end

  # Tells the camera to generate data analytics log in the MISC dir of the SD card
  # f = data_analytics.bin is the default
  def dump_analytics(f=nil)
    if ["BACKDOOR", "PIPE", "ARGUS"].include?(@name)
      full_path = "c:\\misc\\#{f}"
      cmd = "t appc log save #{full_path}"
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
      f = "RP_data_temp.bin"
      full_path = "D:\\#{f}"
      cmd = "t app test appc_log save"
    else
      return false, "Unsupported camera (#{@name})"
    end
    3.times {
      send_serial(cmd)
      sleep 0.5
      return true, full_path if file_exists(full_path) == true
      log_verb("Retrying #{cmd}")
      sleep 2.0
    }
    return false, "Failed to dump analytics to #{f}"
  end

  def clear_analytics_buffer()
    if ["BACKDOOR", "PIPE", "ARGUS"].include?(@name)
      cmd = "t appc log delete"
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
      cmd = "t app test appc_log delete"
    else
      return false, "Unsupported camera (#{@name})"
    end
    2.times {
      send_serial(cmd)
      sleep 0.5
      if ["BACKDOOR", "PIPE", "ARGUS"].include?(@name)
        return true if expect("log-delete")
      elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
        return true if expect("Clear data ana")
      end
      sleep 1.0
    }
    return false
  end

  # Deletes any generic file on the SD card
  def del_analytics(f=nil)
    if ["BACKDOOR", "PIPE", "ARGUS"].include?(@name)
      cmd = "t appc log delete #{f}"
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@name)
      cmd = "t app test appc_log delete #{f}"
    else
      return false, "Unsupported camera (#{@name})"
    end
    return true, "del_analytics skipping delete due to nil arg" if f == nil
    2.times {
      send_serial(cmd)
      sleep 0.5
      return true, "Delete #{f} successful" if file_exists(f) == false
      sleep 1
    }
    return false, "Delete #{f} unsuccessful"
  end


  ###########################################################################
  # OTHER USEFUL METHODS
  ###########################################################################
  def enable_power_save()
    3.times {
      send_serial("t appc status power_save")
      return true if expect("av_graph_power_save_enter", 2.0) != nil
    }
    return false
  end

  def disable_power_save()
    3.times {
      send_serial("t appc status power_save_disable")
      return true if expect("Disabling Power save", 3.0) != nil
    }
    return false
  end

  def simulate_low_batt()
    2.times {
      send_serial("t appc status lowbatt")
      break if expect("LOWBATT") != nil
    }
    return true
  end

  def simulate_over_temp()
    2.times {
      send_serial("t appc status overtemp")
      break if expect("OVERTEMP") != nil
    }
    return true
  end

  def short_press_button(b)
    ret, msg = set(short_press, b, wait_time=0.5, verify=false)
    return true
  end

  def log_analytic_event(ev, p1, p2, p3)
    send_serial("t appc log rec #{ev} #{p1} #{p2} #{p3}")
  end

  def log_fake_analytic_events(n)
    send_serial("t appc log rec #{n}")
    return true if expect("Pass", 30.0) != nil
    return false
  end

  # Returns the mount point if a camera is mounted in mass-storage mode
  # Otherwise returns false
  def is_mounted?(pattern=nil)
    tags = ["Ambarell", "GoPro"] # Strings seen in /dev/disk/by-id/usb*
    # If pattern is not nil, here is the grep command for it
    p_str = (pattern == nil) ? "" : "| grep #{pattern} "
    tags.each { |tag|
      cmd = "ls -l /dev/disk/by-id/usb* #{p_str} | grep #{tag} | grep part1"
      o, e, s = @host.sys_exec(cmd)
      next if not s.success?
      dev = File.basename(o.split()[-1])
      next if dev.match("sd..") == nil
      cmd = "mount | grep #{dev}"
      o, e, s = @host.sys_exec(cmd)
      next if not s.success?
      mount_point = o.split()[2]
      next if mount_point.length < 10
      log_debug("Camera found mounted at #{mount_point}")
      return mount_point
    }
    return false
  end

  # Turns on USB mass-storage mode and returns first camera found
  # If pattern is specified, returns first camera that matches
  def enter_mass_storage_mode(pattern=nil, retries=3, timeout=15)
    (1..retries).each { |n|
      cmd = "t frw usb connect"
      send_serial(cmd)
      sleep 3
      start_time = Time.now
      tags = ["Ambarell", "GoPro"] # Strings seen in /dev/disk/by-id/usb*
      # If pattern is not nil, here is the grep command for it
      p_str = (pattern == nil) ? "" : "| grep #{pattern} "
      while Time.now - start_time < timeout
        mount_point = is_mounted?(pattern)
        return mount_point if mount_point != false
        if not is_alive?
          result = reset_board
          return nil if result == false
        end
        log_debug("Still alive...")
        sleep 3
      end
    }
    return nil
  end

  def exit_mass_storage_mode()
    cmd = "t frw usb disconnect"
    # cmd, wait_time, verify, retries
    send_serial(cmd)
    sleep 1
  end

  def get_first_gopro_dir(tries=3)
    r = nil
    (1..tries).each {|n|
      #send_serial("ls C:\\DCIM\\*")  # NOTE: this does NOT work any more. Need to cd to the directory, then do an 'ls'
      send_serial("cd c:\\DCIM")
      send_serial("ls")
      resp = read_serial_resp
      log_verb("Try #{n} looking up ***#{@mediadir} directory")
      r = resp.match("#{@mediadir}")
      if r == nil or r.length < 1
        next if n < tries
      else
        break
      end
    }
    send_serial("cd a:") # Return to a:
    if r == nil
      log_warn("No ***#{@mediadir} directory found")
      return r
    else
      return r[0]
    end
  end

  # Returns the full-path of all the media in the first #{@mediadir} directory
  def get_medialist(suffix=nil, tries=3)
    dir = get_first_gopro_dir(tries)
    return [] if dir == nil
    # cmd = "ls C:\\DCIM\\#{dir}\\*" # Does not work (Hawaii)
    send_serial("cd c:\\DCIM\\#{dir}")
    send_serial("ls")
    # For very large numbers of files, the limit may be too short.
    data = ""
    (1..10).each {
      resp = read_serial_resp(limit=2.0)
      data += resp
      break if resp.match(/a:.>/) != nil
    }
    lines = data.split("\r\n")
    retval = []
    lines.each { |f|
      f.delete!("\u0000")
      fields = f.split()
      next if fields.length == 0
      next if fields[0][0] != "f" # Files only, skip directories
      (log_verb("Skipping #{f}"); next) if fields.length < 7
      fname = fields[6]
      # Skip non-matching suffix (if specified)
      next if suffix != nil and suffix != fname[-suffix.length..-1]
      retval << ["C:", "DCIM", dir, fname].join("\\")
    }
    send_serial("cd a:")
    return retval
  end

  # DEPRECATED
  def get_medialist2(suffix=nil)
    cam_root = enter_mass_storage_mode()
    if cam_root == nil
      log_error("Camera did not appear as mass-storage-volume")
      return
    end
    if suffix == nil
      file_pattern = "*.*"
    else
      file_pattern = "*.#{suffix}"
    end
    # Matches files (file_pattern) in all subdirs (**) of DCIM
    medialist = Dir.glob(File.join(cam_root, "DCIM", "**", file_pattern))
    exit_mass_storage_mode()
    return medialist
  end

  # Override Camera.get_last_video()
  def get_last_video(); return @last_video_successful; end

  # Compatibility with Wi-fi camera
  def media_exists?(m)
    return find_file(m)
  end

  # fname is the 'basename' (i.e. GOPRxxxx.JPG) not the full path
  def find_file(fname, tries=3)
    dir = get_first_gopro_dir(tries)
    return false if dir == nil
    (1..tries).each { |n|
      send_serial("cd c:\\DCIM\\#{dir}")
      send_serial("ls")
      resp = expect(fname, timeout=2, limit=1.0)
      send_serial("cd a:")
      return true if resp != nil
    }
    puts "returning false"
    return false
  end

  # fname is the 'basename' (i.e. GOPRxxxx.JPG) not the full path
  def find_file3(fname, tries=3)
    dir = get_first_gopro_dir(tries)
    return false if dir == nil
    (1..tries).each { |n|
      send_serial("cd c:\DCIM\#{dir}")
      send_serial("ls #{fname}")
      lines = read_serial_resp(limit=2.0).split("\r\n")
      lines.each { |f|
        f.delete!("\u0000")
        fields = f.split()
        next if fields.length != 7
        return true if fields[6] == fname
      }
    }
    puts "returning false"
    send_serial("cd a:")
    return false
  end

  # DEPRECATED
  def find_file2(fname)
    get_medialist().each { |f|
      return true if f.split("\\")[-1] == File.basename(fname)
    }
    return false
  end

  # Downloads a given file_name (e.g. GOPRO1234.MP4) to directory 'to_dir'
  def download_media(file_name, to_dir, retries=2)
    (1..retries).each { |n|
      log_debug("Looking for #{file_name} on camera")
      next if find_file(file_name) == false

      # File was found on the camera SD card, so let's mount it and copy it
      cam_root = enter_mass_storage_mode()
      if cam_root == nil
        log_error("Can't find camera root in filesystem")
        return false, "Camera did not appear as mass-storage volume"
      end
      all_files = Dir.glob(File.join(cam_root, "DCIM", "**", "*.*"))
      log_verb(all_files)
      all_files.each { |f|
        if File.basename(f) == File.basename(file_name)
          if not File.directory?(to_dir)
            log_debug("Making #{to_dir}")
            FileUtils.mkdir_p(to_dir)
          end
          log_verb("Copying #{f} to #{to_dir}")
          mp4file = @host.copy_file(f, to_dir)
          lrvfile = f[0...-3] + "LRV"
          ret = @host.copy_file(lrvfile, to_dir)
          log_verb("Copied LRV file") if ret != nil
          thmfile = f[0...-3] + "THM"
          ret = @host.copy_file(thmfile, to_dir)
          log_verb("Copied THM file") if ret != nil
          sleep 3  # Very important to sleep here!
          exit_mass_storage_mode()
          return true, mp4file
        end
      }
      sleep 5
      log_debug("File not found.  Retrying...")
      exit_mass_storage_mode()
      sleep 5
    }
    return false, "File #{file_name} not found on camera"
  end

  # Downloads all media to directory 'to_dir'
  # (optionally stop after N files by setting stop_after=N)
  def download_all_media(to_dir, stop_after=nil)
    cam_root = enter_mass_storage_mode()
    if cam_root == nil
      log_error("Camera did not appear as mass-storage-volume")
      return
    end
    all_files = Dir.glob(File.join(cam_root, "DCIM", "**", "*.*"))
    n_copied = 0
    all_files.each { |f|
      log_verb("Copying #{f} to #{to_dir}")
      mp4file = @host.copy_file(f, to_dir)
      n_copied += 1 if mp4file != nil
      break if stop_after != nil and n_copied == stop_after
    }
    exit_mass_storage_mode()
    if n_copied > 0
      return true, "#{n_copied} files copied"
    else
      return false, "File #{file_name} not found on camera"
    end
  end

  # Deletes a file on the SD card
  def delete_single_file(f)
    delfile = nil
    if File.dirname(f).length > 0
      delfile = f
    else
      all_files = get_medialist()
      all_files.each { |g|
        if File.basename(f) == File.basename(g)
          delfile = g
          break
        end
      }
    end
    if delfile == nil
      return false, "File #{f} not found on SD card"
    else
      log_debug("Deleting single file #{f}")
      send_serial("rm #{delfile}")
      return true, "File #{f} deleted"
    end
  end

  # Delete all using CCL command
  def delete_all_media()
    send_serial(delete_all[:set])
    sleep 5
  end

  def delete_all_media2()
    # Can take a LONG time if there are lots of files
    2.times {
      send_serial("rm c:\\dcim\\100gopro\\*")
      expect(/a:.>/, timeout=30, limit=1)
    }
    do_reset()
  end

  # DEPRECATED: Delete all the media on the SD card via 'rm' command
  # Use this only until an API command is given to do the same
  def delete_all_media3()
    log_debug("Deleting all files via 'rm' commands")
    # send_serial("ls C:\\DCIM\\*")
    send_serial("cd c:\DCIM")
    send_serial("ls")
    resp = read_serial_resp()
    log_verb("Looking up ***#{@mediadir} directory")
    r = resp.match("...#{@mediadir}")
    if r == nil or r.length < 1
      log_warn("No ***#{@mediadir} directory found")
      return []
    end
    dir = r[0]
    #send_serial("rm C:\\DCIM\\#{dir}\\*")
    send_serial("cd a:")
    send_serial("cd c:\DCIM\#{dir}")
    send_serial("rm *")
    sleep 3
    all_files = get_medialist()
    if all_files.length > 0
      ret = false
      msg = "Delete all media may have failed (medialist non-empty)"
    else
      ret = true
      msg = "Delete all successful"
    end
    send_serial("cd a:")
    log_debug(msg)
    return ret, msg
  end

  def already_set?(cmd="fake", args="fake")
    log_warn("already_set? method not supported on serial. Returning false")
    return false
  end

  def start_stop_capture(capture_time)
    log_info("Starting capture...")
    result,msg = start_video_capture()
    msg = "start_stop_capture() START-CAPTURE ERROR, " + msg if not result
    log_warn(msg) if not result

    log_info("Sleeping #{capture_time}s...")
    sleep capture_time if not @pause_serial_cmds

    log_info("Stopping capture...")
    result,msg = stop_capture()
    msg = "start_stop_capture() STOP-CAPTURE ERROR, " + msg if not result
    log_warn(msg) if not result

    return result, msg
  end

  # Enable/disable pausing between serial commands
  def enable_pause(onoff)
    @pause_serial_cmds = onoff # on==true, off=false
    puts "SERIAL PAUSING ENABLED" if (onoff)
  end

end # end SerialCamera

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  serial_port = "/dev/ttyUSB0"
  $camera = get_serial_camera(serial_port)
end
