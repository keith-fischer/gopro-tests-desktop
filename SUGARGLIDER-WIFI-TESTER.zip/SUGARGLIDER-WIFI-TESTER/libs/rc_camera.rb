
require 'socket'
require 'json'
require_relative 'wifi_camera'
# log utils?

# This class is the driving force in pretending to be a GoPro remote.
# It requires that you have an attached AP set up to detect & pair cameras.
# Additionally, you will have to modify your setup so that your VM can curl the camera's ips.

# Needs to know if it's in 1-1 mode or 1-many.
# Does it need to ever really be in one to many mode? I mean...
# Surely the AP can send signals to individual cams and trick them all into thinking they are in 1-1 mode.
# We can add 1-many mode later.

# In 1-1 mode:
# - Query status three times a second. (Excessive? Cut back to once a second?)
# - 
# - Send button presses as needed.
# - - PW (or PA)
# - - SH (or SA)
# - - XX

class CameraState

  attr_accessor :mode, :submode

  def initialize()
    @mode = nil
    @submode = nil
  end

end


# No, don't do that...
class RCCamera #< WifiCamera # Is that OK? Needed? Might want to downgrade base class to Camera...

  attr_accessor :use_cam

#  WifiCamera.instance_methods.each do |name|
#    define_method(name) do
#      @cameras_list[@use_cam].send(name)
#    end
#  end

  # This is not ideal, but 
  def method_missing(m, *args, &block)
    #puts( "method_missing(): #{m}" )
    @cameras_list[@use_cam].send(m, *args, &block)
  end  

  def initialize(rc_info_filename, source_ip=nil, camera_ips=nil)
    @interfaces = ["rc"] # For compatability reasons.
    if(rc_info_filename) then
      file = File.read(rc_info_filename)
      @rc_hash = JSON.parse(file)
      @cam_ips = []
      @rc_hash["CAMERAS"].each do |camera|
        # puts "Adding camera #{camera["NICKNAME"]}" # => #{camera["IP"]}"
        @cam_ips << camera["IP"]
      end
    elsif source_ip and camera_ips then
      @cam_ips = camera_ips
      @cam_ips = [@cam_ips] unless @cam_ips.instance_of? Array
      @src_ip = source_ip
    end
    # At this point, all we have is the list of camera ips.
    # But each camera needs additional information associated with it too.
    # For a start, we need the actual Wifi camera objects for each camera.
    @cameras_list = []
    @cam_ips.each { |ip| @cameras_list << get_wifi_camera(ip, nil, nil) } # No pairing code or serial ports.
    (puts("No cameras found. Exiting."); exit 1) unless @cameras_list.length > 0
    # We need to track the sequence numbers for each camera too.
    @sequence_numbers = []
    @cam_ips.length.times { @sequence_numbers << 0 }
    # We also need to track the state of each camera.    
    @camera_states = []
    @cam_ips.each { |ip| @camera_states << CameraState.new }
    # Define one camera as an active camera.
    @use_cam = 0
    # A generic socket to use for sending things.
    @udp_socket = UDPSocket.new

    # Need to make these happen for all cameras.
    rc_initial_packets
    sp("CM00")

    # Not sure why this next bit was causing an issue.
    #begin
    #  @udp_socket.bind(@rem_ip, 8383)
    #rescue
    #  puts "Could not bind to #{@rem_ip}:8383. Is this host machine connected to the fake RC?"
    #  exit 1
    #end

    # There is no need to connect to a specific port.
    # We can actually send to different ports just find.
    #@udp_socket.connect( some_ip, 8484 )


#    start_listener_one()
  end

  def start_listener_one()
    @threads = []
    @threads << Thread.new {
      while true do
        local_ip, local_port = @udp_socket.local_address.ip_unpack
        puts "Listener #1 listening on #{local_ip}:#{local_port}"
        content = @udp_socket.recv(1024)
        puts "Got content from listener #1: #{content}"
        puts #"From addr: '%s', msg: '%s'" % [addr[0], data]
        sleep(1.0)
      end
    }
    @threads.each { |thr| thr.abort_on_exception = true }
  end

=begin
  def start_listener_two()
    @threads << Thread.new {
      listener_socket = UDPSocket.new
      p @udp_socket.local_address
      local_ip, local_port = @udp_socket.local_address.ip_unpack
      p local_ip
      p local_port
      listener_socket.bind(local_ip, local_port) #@rem_ip, 8484)
      #listener_socket.connect(@rem_ip, 8484)
      while @threads_run do
        #addr = ['0.0.0.0', 8484]
#BasicSocket.do_not_reverse_lookup = true
# Create socket and bind to address
        #listener_socket = UDPSocket.new
        #listener_socket.bind(addr[0], addr[1])
        puts "#2 Listening..."
        content = listener_socket.recv(1024)
        #data, addr = @udp_socket.recvfrom(1024)
        puts "#{content}"#"From addr: '%s', msg: '%s'" % [addr[0], data]
        #msg = listener_socket.recvfrom(1024)
#        msg = @udp_socket.recvfrom(1024)
#        puts "LISTENER: #{msg}"
        sleep(1.0)
      end
    }
#    @threads << Thread.new {
#      pc_listen = UDPSocket.new
#      pc_listen.bind("192.168.1.144", 8383)

    # Bail if any thread whines.
    @threads.each { |thr| thr.abort_on_exception = true }
  end # start_listener
=end

  def is_special_command(cmd, cam_x)
    false
  end

  # Sends a specified command packet to the camera.
  def send_packet(which_cmd, cam_number=@use_cam)
    return nil if is_special_command(which_cmd, cam_number)

    # A special command to switch to a different camera number? Bleh!
#    (@use_cam = cam_number; return) if which_cmd == "##" 
    # The idea here is that we can cause a sleep simply by having sa plain number in the command list. Bleh!
#    (sleep(which_cmd); return) if which_cmd.is_a? Number

    cmd = cmd_leading_zeros + \
          cmd_destination_component(which_cmd) + \
          cmd_sequence_number(cam_number) + \
          cmd_actual_command(which_cmd)
    puts("Sending to #{@cameras_list[cam_number].ip}:8484 the command #{which_cmd}")
    @udp_socket.send( cmd, 0, @cameras_list[cam_number].ip, 8484)
    sleep(1.0)
  end # send_packet
  alias_method :sp, :send_packet

  

#### Methods for doing remote interactions via button presses.

# I don't know if I like these.

  def press_power
    send_packet("PW02")
  end # press_power

  def press_shutter
    send_packet("SH02")
  end # press_shutter

  def press_options
    send_packet("XX0210")
  end # press_options

# I really don't know if I like these.
# What use is a long press of shutter?
# Long press of power would turn off the camera, which would break the RC connection anyway.
# Long press of options would go to the wireless menu. And I don't know if we want to do that!

#  def long_press_power
#    puts "No. (Long-press power button.)"
#  end # long_press_power

#  def long_press_shutter
#    puts "No. (Long-press shutter button.)"
#  end # long_press_shutter

#  def long_press_options
#    puts "No. [Long-press options button.)"
#  end # long_press_options

### Methods to create commands.

  def cmd_leading_zeros
    # All gopro commands have this string of zeros in them for padding.
    "\x00\x00\x00\x00\x00\x00\x00\x00"
  end

  def cmd_destination_component(which_cmd)
    # Different commands are sent to the camera or bacpac.
    if ["pw", "wt", "OO00", "OO01"].include?(which_cmd) # Bacpac commands.
      #puts "---- Command #{which} is being sent to device 01, the backpac."
      return "\x01"
    end 
    return "\x00" # All others are camera commands.
  end

  def cmd_sequence_number(cam_number)
    retval = [@sequence_numbers[cam_number].to_s(16).rjust(4,"0")].pack("H4")
    #puts "---- Cam #{cam_number} : Sequence number : #{@sequence_numbers[cam_number]}"
    @sequence_numbers[cam_number]+=1
    @sequence_numbers[cam_number]%=65536
    return retval
  end

  def cmd_actual_command(which)
    # This is kind of dumb. Make this better.
    return "SH\x00" if which == "SH00" # Shutter stop.
    return "SH\x01" if which == "SH01" # Shutter start.
    return "SH\x02" if which == "SH02" # Shutter quick press.
    return "CM\x00" if which == "CM00" # Go directly to different modes.
    return "CM\x01" if which == "CM01"
    return "CM\x02" if which == "CM02"
    return "CM\x03" if which == "CM03"
    return "CM\x04" if which == "CM04"
    return "CM\x05" if which == "CM05"
    return "CM\x06" if which == "CM06"
    return "CM\x07" if which == "CM07"
    return "pw"     if which == "pw"   # Get power status
    return "PW\x00" if which == "PW00" # Power off.
    return "PW\x01" if which == "PW01" # Power on.
    return "PW\x02" if which == "PW02" # Power button press.
    return "XX\x02\x10" if which == "XX0210" # Wrench Press & duration.
    return "OO\x00" if which == "OO00" # 1-1 Off.
    return "OO\x01" if which == "OO01" # 1-1 On.
    return "lc\x05" if which == "lc05" # Whole LCD display - No responses yet. :-\
    return "cv"     if which == "cv" # Camera version command.
    return "wt"     if which == "wt" # Who's there?
    puts "Warning: cmd_actual_command(): Command #{which} is unknown to me."
    return which
  end

  # Methods for sending various different command packets.
  # Do I really want these?

  def send_shutter_start
    send_packet("SH01")
  end # send_shutter_start

  def send_shutter_stop
    send_packet("SH00")
  end # send_shutter_stop

  def send_whos_there
    send_packet("wt")
  end # send_whos_there

  def send_power_toggle
    send_packet("PW02")
  end # send_power_toggle

  def send_camera_version
    send_packet("cv")
  end # send_camera_version

  def send_one_to_one_mode
    send_packet("OO01")
  end # send_one_to_one_mode

  def send_one_to_many_mode
    send_packet("OO00")
  end # send_one_to_many_mode

  def send_change_mode(mode_code="00")
    send_packet("CM#{mode_code}")
  end # send_change_mode

  # === Camera functions ===
  # Keep the following things in mind:
  # This is the remote camera class.
  # Even if you can do something with one packet, that doesn't mean you get to.
  # The idea here is that we're simulating button presses.
  # For things that require multiple button presses to achieve

  def name_me(x="")
    puts("#{caller[0][/`([^']*)'/, 1]}() : #{x}")
  end  

  def set_steps_info
    @steps =
      { 
      "pipe" =>
        { 
        "main_modes" =>
          [
            "VIDEO",
            "PHOTO",
            "MULTI",
            "SETUP"
          ], 
        "sub_modes" =>
        {
          "VIDEO" => [ "VIDEO" ],
        }
      }
    }
  end

  def msv( mode, setting, value )
    set_capture_mode( mode )
    press_options unless mode == "SETUP" or mode == "PREVIEW"
    cycle_to_setting( setting )
    cycle_to_value( setting, value )
    press_options unless mode == "SETUP" or mode == "PREVIEW"
  end

  def cycle_to_setting( which_setting )
    # Basically, press power X times.
    name_me; not_working
    press_power
  end

  def cycle_to_value( which_setting, desired_value )
    # Basically, press shutter X times.
    name_me; not_working
    press_shutter
  end

  def main_mode_for_sub_mode(sub_mode)
    return sub_mode if ["SETUP","PLAYBACK"].include?(sub_mode)
    return "VIDEO" if sub_mode.start_with?("VIDEO")
    return "PHOTO" if sub_mode.start_with?("PHOTO")
    return "MULTI" if ["BURST","NIGHTLAPSE","TIMELAPSE"].include?(sub_mode)
    puts "UNKNOWN SUB MODE: #{sub_mode}. Returning nil."
    return nil
  end

  # This is only used inside of set_capture_mode.
  def set_capture_main_mode(main_mode)
#    name_me
    cur_mode = @camera_states[@use_cam].mode
    return if cur_mode and cur_mode = main_mode
    # Not already set to that main mode? Ok. Go back to Video...
    #send_packet("CM00") # 
    send_change_mode("00") # Go to video.
    (@camera_states[@use_cam].mode = "VIDEO"; return) if main_mode == "VIDEO"
    press_power
    (@camera_states[@use_cam].mode = "PHOTO"; return) if main_mode == "PHOTO"
    press_power
    (@camera_states[@use_cam].mode = "MULTI"; return) if main_mode == "MULTI"
    press_power
    # TODO: Find a better way to deal with playback mode.
    # Might need to ignore it totally, and just use RC commands to go directly to setup.
    # Can we even pick playback mode using RC?
    if( @camera_list[@use_cam].defaults[:setup_lcd_display] ) then
      (@camera_states[@use_cam].mode = "PLAYBACK"; return) if main_mode == "PLAYBACK"
      press_power
    end
    # Anyway, if we want setup mode, great.
    (@camera_states[@use_cam].mode = "SETUP"; press_shutter; return) if main_mode == "SETUP"
    # TODO: Figure out what to do about any other modes.
  end

  # This is the main function that cameras need to support.
  def set_capture_mode(sub_mode)
    name_me(sub_mode)
    cur_mode = @camera_states[@use_cam].submode
    return if cur_mode and cur_mode == sub_mode
    main_mode = main_mode_for_sub_mode(sub_mode)
    set_capture_main_mode(main_mode) if main_mode
    # TODO: Set the submode here!
    # Might be able to do this with the setting cycle.
  end

  def set_video_def_sub_mode(submode)
    name_me; not_working
  end

  def set_video_resolution(res)
    name_me; not_working
  end

  def set_video_fps(fps)
    name_me; not_working
  end

  def set_video_fov(fov)
    name_me; not_working
  end

  def set_video_timelapse(duration) # ?
    name_me; not_working
  end

  def set_video_piv(duration) # ?
    name_me; not_working
  end

  def set_video_looping(duration) # ?
    name_me; not_working
  end

  def set_video_low_light(ll)
    name_me; not_working
  end

  def set_video_spot_metering(spot)
    name_me; not_working
  end

  def set_video_protune(pt)
    name_me; not_working
  end

  def set_video_protune_white_balance(pt_wb)
    name_me; not_working
  end

  def set_video_protune_color(pt_color)
    name_me; not_working
  end

  def set_video_protune_iso(pt_iso)
    name_me; not_working
  end

  def set_video_protune_sharpness(pt_sharp)
    name_me; not_working
  end

  def set_video_protune_exposure(pt_exp)
    name_me; not_working
  end

  def set_video_format(vm) #, res, fps, fov)
    name_me; not_working
  end

  def start_capture(retries=0)
    press_shutter
  end

  def stop_capture(retries=0)
    name_me; not_working
  end

  def capture_video(res, fps, fov, duration, retries=0)
    name_me; not_working
  end

  def set_photo_def_sub_mode(mode)
    name_me; not_working
  end

  def set_photo_resolution(res)
    name_me; not_working
  end

  def set_photo_continuous(duration) # ?
    name_me; not_working
  end

  def set_photo_shutter_exposure(exp) # ?
    name_me; not_working
  end

  def set_photo_spot_metering(spot)
    name_me; not_working
  end

  def set_photo_protune(pt)
    name_me; not_working
  end

  def set_photo_protune_white_balance(pt_wb)
    name_me; not_working
  end

  def set_photo_protune_color(pt_color)
    name_me; not_working
  end

  def set_photo_protune_iso(pt_iso)
    name_me; not_working
  end

  def set_photo_protune_sharpness(pt_sharp)
    name_me; not_working
  end

  def set_photo_protune_exposure(pt_exp)
    name_me; not_working
  end

  def capture_photo_single(res, orient=nil, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    set_orientation(orient) if orient
    set_capture_mode("PHOTO")
    set_photo_resolution(res)
    set_photo_spot_metering(spot) if spot
    set_photo_protune(pt) if pt
    set_photo_protune_white_balance(wb) if wb
    set_photo_protune_color(col) if col
    set_photo_protune_sharpness(sh) if sh
    set_photo_protune_exposure(ex) if ex
    start_capture
  end

  def capture_photo_continuous(res, rate, duration, retries=0)
  end

  def capture_photo_night(res, retries=0)
  end

  def set_multi_def_sub_mode(mode)
  end

  def set_multi_photo_resolution(res)
  end

  def set_multi_photo_burst(burst)
  end

  def set_multi_photo_timelapse(duration) # ?
  end

  def set_multi_photo_nightlapse(duration) # ?
  end

  def set_multi_spot_metering(spot)
  end

  def set_multi_shutter_exposure(exp) # ?
  end

  def set_multi_protune(pt)
  end

  def set_multi_protune_white_balance(pt_wb)
  end

  def set_multi_protune_color(pt_color)
  end

  def set_multi_protune_iso(pt_iso)
  end

  def set_multi_protune_sharpness(pt_sharp)
  end

  def set_multi_protune_exposure(pt_exp)
  end

  def set_multi_capture(x) # ?
  end

  def capture_multi_photo_burst(res, mode, retries=0)
  end

  def set_default_capture_mode(mode)
  end

  def set_osd(osd)
  end

  def set_led(led)
  end

  def set_beep_sound(beep)
  end

# End of support???

##### Start of covered by method_missing. Leaving in for rc_support warning?

  def rc_support_warning()
#log_warn(
    puts("No native RC support for function #{caller[0][/`([^']*)'/, 1]}(). Relying on wifi mode commands!")
  end

  def get_medialist(suffix=nil)
    rc_support_warning
    retval = @cameras_list[@use_cam].get_medialist(suffix)
    #puts "get_medialist() returned: #{retval}"
    return retval
  end

  def get_last_video()
    rc_support_warning
    return @cameras_list[@use_cam].get_last_video()
  end

  def download_media(file_name, to_dir)
    rc_support_warning
    return @cameras_list[@use_cam].download_media(file_name, to_dir)
  end

  def download_all_media(to_dir, stop_after=nil)
    rc_support_warning
    return @cameras_list[@use_cam].download_all_media(to_dir, stop_after)
  end

  def is_alive?()
    rc_support_warning
    return @cameras_list[@use_cam].is_alive?
  end

  def reset_board()
    rc_support_warning
    return @cameras_list[@use_cam].reset_board
  end

  def do_reset()
    rc_support_warning
    return @cameras_list[@use_cam].do_reset
  end

  def get_mins_avail()
    rc_support_warning
    return @cameras_list[@use_cam].get_mins_avail
  end

  def get_photos_avail()
    rc_support_warning
    return @cameras_list[@use_cam].get_photos_avail
  end

  def get_n_videos()
    rc_support_warning
    return @cameras_list[@use_cam].get_n_videos
  end

  def get_n_photos()
    rc_support_warning
    return @cameras_list[@use_cam].get_n_photos
  end

  def delete_single_file(file_name)
    rc_support_warning
    return @cameras_list[@use_cam].delete_single_file(file_name)
  end

##### End of covered by missing_method

  def delete_all_media() # Assumed done via the setup menu.
    
  end

  def get_wifi_ssid()
    rc_support_warning
    #return @cameras_list[@use_cam].get_wifi_ssid
    return nil
  end

  # Start of unique RC-only supported functions

  def rc_setup_menu() # Since set_capture_mode() would be a misnomer.
    set_capture_mode("SETUP") # But whatever.
  end

#  def rc_playback_mode() # Maybe? Needed/possible in RC mode?

  def rc_reset_protune(mode) # Because this is possible via menu options.
  end

  def rc_exit_current_menu() # Via the EXIT option at the bottom...
    # TODO: Make this work for menu systems that don't use wrench to exit.
    wrench_press # TODO: Also make this work by going down to the EXIT choice and exiting.
  end

  def set_orientation(upd) # Set via setup menu.
    msv( "SETUP", :orientation, upd )
  end

  def rc_delete_last_file() # Is an option in the setup menu.
    name_me; not_working
  end

  def rc_set_date(day, month, year)
    name_me; not_working
  end

  def rc_set_time(hour, minute, second)
    name_me; not_working
  end

  # Would add reset to defaults, but that power's the camera off, breaking RC mode connection.

  def rc_set_language(langauge, cancel=false)
    # Goes to the set language choice.
    # Selects langauge, or BACK if language is nil/invalid.
    # Picks the checkmark to change if cancel is false.
    # Picks the X to cancel if cancel is true, then the BACK hoice to exit menu.
    name_me; not_working
  end

  def rc_square_one()
    # Go back to a known start point, before doing... something.
    # The "something" that we do is what determines if we need this step.
    send_packet("CM00")
  end

  def rc_initial_packets()
    @sequence_numbers[@use_cam]=0
    ["pw","cv","OO01","wt"].each do |cmd|
      sp(cmd)
      sleep(1.0)
    end
  end

  # Can't do this via RC mode. So not doing it.
  def test_preview_stream
    false
  end

  # 
  def not_working
    puts "- - - - - - - - THIS DOESN'T WORK YET..."
  end

end

# Driver code.
demo = false
multi = false

if(demo) then
  r = RCCamera.new( nil, "192.168.1.144", ["192.168.1.188"] ) # ,"192.168.1.74"] ) 
  # Enable and prep both cameras
  r.rc_initial_packets()
  # Go to burst mode.
  r.sp("CM02",0)
  # Capture
  r.sp("SH01",0)
  sleep(2.0)
  r.sp("SH00",0)
  # Change settings on 0
  r.sp("XX0210",0)
  r.sp("PW02",0)
  5.times { r.sp("SH01",0) }
  r.sp("XX0210",0)
  # Capture again
  r.sp("SH01",0)
  sleep(2.0)
  r.sp("SH00",0) 

#  r.send_shutter_start
#  sleep(5.0)
#  r.send_shutter_stop
end

if(multi) then
  r = RCCamera.new( nil, "192.168.1.74", "192.168.1.188" )
  puts "Top-level sending initial command packets."
  r.rc_initial_packets
  puts "Top-level sending CM00."
  r.sp("CM00")
  #r.send_shutter_start()
  #sleep(10.0)
  #r.send_shutter_stop()
  #8.times do |n|
  #  r.send_packet("CM0#{n}")
  #  sleep(10.0)
  #end
  #r.send_packet("CM00")
#  r.send_packet("cv")

#  8.times do |n|
#    cmds = ["pw", "cv", "OO01", "wt", "lc05", "st", "CM00", "XX0210", "SH01", "SH01", "SH01", "SH01", "PW02", "SH01", "XX0210", "SH01", "SH00"]
    #cmds = ["CM00","st","lc05","CM01","cv","XX0210"]
#    cmds.each do |cmd| 
#      r.send_packet(cmd)
#      sleep(1.0)
#    end
end
