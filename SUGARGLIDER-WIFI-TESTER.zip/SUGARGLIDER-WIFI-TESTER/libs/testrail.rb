##############################################################
# Copyright 2013 Woodman Labs Inc. d.b.a. GoPro Inc.
# Author: Chris Dana (cdana@)
# Description: RUBY interface for the TestRail API described at
# http://docs.gurock.com/testrail-api2/start

require 'json'
require 'net/https'
require 'uri'
require_relative 'log_utils'

class TestRail
  include LogUtils

  attr_accessor :proj_id, :proj_name, :dryrun
  attr_reader :default_section_name, :result_str,
    :passed, :blocked, :untested, :retest, :failed
  def initialize(name="(FWQA) Automation")
    # @url_base = "https://gopro.testrail.com/index.php?/api/v2"
    @url_base = "https://testrail.gopro.lcl/index.php?/api/v2"
    @username = "qaauto_gopro@gopro.com"
    @password = "Beahero123"
    # Array of [arg, val] headers to add to all http requests
    @headers = [["Content-Type", "application/json"]]
    @proj_name = name
    @proj_id = get_proj_id(@proj_name) if name != nil
    if @proj_id == false
      log_error("Unable to find project ID for name='#{@proj_name}'")
    end
    # Test case types from get_case_types()
    @type_automated = 1
    @default_section_name = "All Test Cases"
    # Results status IDs from get_statuses()
    @passed, @blocked, @untested, @retest, @failed = 1, 2, 3, 4, 5
    @result_str = { 1=>"PASS", 2=>"BLOCKED", 3=>"UNTESTED",
      4=>"RETEST", 5=>"FAIL" }
    @max_results = 250 # get_results_for_run()
  end

  # Handles requests to the TestRail API and returns the response
  # method - API method to use (e.g. "get_case")
  # arg - The argument to the API method (e.g. 182150) if any
  # post_fields - A dictionary of POST form data if any
  # returns - JSON formatted results or false on failure
  def get_resp(method, arg=nil, post_fields=nil)
    url = "#{@url_base}/#{method}"
    url += "/#{arg}" if arg != nil
    uri = URI.parse(url)
    log_debug(uri)
    #p url

    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE
    #log_info(http)

    if post_fields == nil
      req = Net::HTTP::Get.new(uri.request_uri)
    else
      req = Net::HTTP::Post.new(uri.request_uri)
      # log_debug("Post Fields: #{post_fields}")
      req.body = post_fields.to_json
      # log_debug("Request body: #{req.body}")
    end
    req.basic_auth(@username, @password)
    @headers.each { |h| req.add_field(h[0], h[1]) }
    log_debug(req)

    n = 0
    n_tries = 5
    wait = 5
    begin
      n += 1
      resp = http.request(req)

      log_debug("Response: #{resp.code}")
      log_debug("Response: #{resp.body}")
      resp_code = resp.code.to_i
      err_msg = resp.body.to_s
      if resp_code == 200
        return JSON.parse(resp.body) if resp.body.length > 1
        return resp
      elsif resp_code == 400
        raise
      elsif resp_code == 403
        err_msg = "No permission to perform requested action"
        # Don't skip to retry... No point.
      elsif resp_code >= 500
        err_msg = "Server error"
        raise
      else
        err_msg = "Unknown error"
        # No retry for now
      end
    rescue StandardError
      log_error("Received non-success HTTP code (#{resp_code} - #{err_msg})")
      log_info("Retry #{n} of #{n_tries}: Sleeping #{wait} seconds and retrying")
      sleep wait
      retry if n < n_tries
    end

    log_error("Retries timed out.  Giving up.")
    return false
  end

  ##################
  # Configurations API
  ##################
  # Example output:
  # ["get_configs", "54"]
  # [{"id"=>44,
  #   "name"=>"Default Mode",
  #   "project_id"=>54,
  #   "configs"=>
  #     [{"id"=>225, "name"=>"Photo", "group_id"=>44},
  #      {"id"=>224, "name"=>"Video", "group_id"=>44}]},
  #  {"id"=>45,
  #   "name"=>"Enable Capture Setting",
  #   "project_id"=>54,
  #   "configs"=>
  #      [{"id"=>227, "name"=>"Defaults", "group_id"=>45},
  #       {"id"=>226, "name"=>"UpD", "group_id"=>45}]}]

  def get_configs(proj_id); get_resp("get_configs", proj_id); end
  def get_config_id(proj_id, name)
    get_configs(proj_id).each { |c|
      c["configs"].each { |conf|
        return conf["id"] if conf["name"] == name
      }
    }
  end

  ##################
  # Test Case API
  ##################
  def get_case(test_id); get_resp("get_case", test_id); end
  def get_cases(proj_id, suite_id, section_id=nil)
    args = "#{proj_id}&suite_id=#{suite_id}"
    args += "&section_id=#{section_id}" if section_id != nil
    get_resp("get_cases", args)
  end
  def add_case(section_id, title, type_id=1, prio_id=4, est=nil,
    mstone_id=nil, refs=nil, custom=nil)
    post_data = {
      "title"   => title,
      "type_id" => type_id,
      "priority_id" => prio_id,
      "custom_steps" => "No custom steps",
      "custom_description" => "Automated test case: #{title}",
      "custom_automation_status" => 3, #Automation Complete
    }
    post_data["estimate"] = est if est != nil
    post_data["milestone_id"] = mstone_id if mstone_id != nil
    post_data["refs"] = refs if refs != nil
    get_resp("add_case", section_id, post_data)
  end
  # Post data supports same fields as add_case
  def update_case(case_id, post_data)
    get_resp("update_case", case_id, post_data)
  end
  # Delete uses a POST method (but no info) so we need {}
  def delete_case(case_id); get_resp("delete_case", case_id, {}); end
  def get_case_id(title, suite_id)
    log_info("Searching for test case named #{title}")
    get_cases(@proj_id, suite_id).each { |c|
      return c["id"] if c["title"] == title
    }
    log_warn("No test case matching name #{title} found.")
    return false
  end

  ##################
  # Misc Details API
  ##################
  def get_case_fields(); get_resp("get_case_fields"); end
  def get_case_types(); get_resp("get_case_types"); end
  def get_priorities(); get_resp("get_priorities"); end
  def get_result_fields(); get_resp("get_result_fields"); end
  def get_statuses(); get_resp("get_statuses"); end

  ##################
  # Milestone API
  ##################
  def get_milestone(mile_id); get_resp("get_milestone", mile_id); end
  def get_milestones(proj_id); get_resp("get_milestones", proj_id); end
  # due_on is a UNIX timestamp
  def add_milestone(proj_id, name, desc=nil, due_on=nil)
    post_data = {"name" => name}
    post_data["description"] = desc if desc != nil
    post_data["due_on"] = due_on if due_on != nil
    get_resp("add_milestone", proj_id, post_data)
  end
  def update_milestone(mile_id, name=nil, desc=nil, due_on=nil, complete=nil)
    post_data = {}
    post_data["name"] = name if name != nil
    post_data["description"] = desc if desc != nil
    post_data["due_on"] = due_on if due_on != nil
    post_data["is_completed"] = complete if complete != nil
    get_resp("update_milestone", mile_id, post_data)
  end
  # Delete uses a POST method (but no info) so we need {}
  def delete_milestone(mile_id); get_resp("delete_milestone", mile_id, {}); end

  ##################
  # Test Plans API
  ##################
  def get_plan(plan_id); get_resp("get_plan", plan_id); end
  def get_plans(proj_id=@proj_id); get_resp("get_plans", proj_id); end
  # "entries" is an array of test-run descriptions
  # Test plan entries can be added later with add_plan_entry() below
  def add_plan(proj_id, name, entries=nil, desc=nil, mstone_id=nil)
    post_data = {"name" => name}
    post_data["entries"] = entries if entries != nil
    post_data["description"] = desc if desc != nil
    post_data["milestone_id"] = mstone_id if mstone_id != nil
    get_resp("add_plan", proj_id, post_data)
  end
  # All cases are included by default unless specific cases are specified
  def add_plan_entry(plan_id, suite_id, name=nil, assign_id=nil, incl_all=true,
    case_ids=[], config_ids=[], runs=[])
    all_cases = get_cases(@proj_id, suite_id).map { |c| c["id"] }
    post_data = {"suite_id" =>  suite_id}
    post_data["name"] = name if name != nil
    post_data["assignedto_id"] = assign_id if assign_id != nil
    post_data["include_all"] = incl_all
    post_data["case_ids"] = all_cases
    post_data["config_ids"] = config_ids
    if runs == []
      runs[0] = {}
      runs[0]["include_all"] = false if case_ids != []
      runs[0]["case_ids"] = case_ids if case_ids != []
      runs[0]["config_ids"] = config_ids
    end
    post_data["runs"] = runs
    pp post_data
    get_resp("add_plan_entry", plan_id, post_data)
  end
  # Supports the same fields as add_plan
  def update_plan(plan_id, post_data)
    get_resp("update_plan", plan_id, post_data)
  end
  # Supports the same fields as add_plan_entry
  def update_plan_entry(plan_id, entry_id, post_data)
    args = "#{plan_id}/#{entry_id}"
    get_resp("update_plan_entry", args, post_data)
  end
  # Close/Delete uses a POST method (but no info) so we need {}
  def close_plan(plan_id); get_resp("close_plan", plan_id, {}); end
  def delete_plan(plan_id); get_resp("delete_plan", plan_id, {}); end
  def delete_plan_entry(plan_id, entry_id)
    args = "#{plan_id}/#{entry_id}"
    get_resp("delete_plan_entry", args, {})
  end
  def add_plan_if_not_exist(name, proj_id, desc=nil,
    mstone_id=nil, assign_id=nil, incl_all=true, case_ids=[])
    log_info("Searching for test plan named #{name}")
    plan_id = nil
    get_plans(proj_id).each { |p| plan_id = p["id"] if p["name"] == name }
    return plan_id if plan_id != nil
    log_info("Test plan not found.  Adding it...")
    plan_info = add_plan(proj_id, name)
    return plan_info["id"]
  end
  def add_plan_entry_if_not_exist(plan_id, suite_id, name=nil, assign_id=nil,
    incl_all=true, case_ids=[], config_ids=[], runs=[])
    log_info("Searching for test plan entry with config_ids #{config_ids}")
    entry_id = nil
    get_plan(plan_id)["entries"].each { |p|
      p["runs"].each { |r|
        entry_id = r["id"] if r["config_ids"].sort == config_ids.sort
      }
    }
    return entry_id if entry_id != nil
    log_info("Test plan entry not found.  Adding it...")
    entry_info = add_plan_entry(plan_id, suite_id, name, assign_id, incl_all,
      case_ids, config_ids, runs)
    return entry_info["id"]
  end

  ##################
  # Projects API
  ##################
  def get_project(proj_id); get_resp("get_project", proj_id); end
  def get_projects(); get_resp("get_projects"); end
  def add_project(name, ann=nil, show_ann=false)
    post_data = {"name" => name}
    post_data["announcement"] = ann if ann != nil
    post_data["show_announcement"] = show_ann
    get_resp("add_project", nil, post_data)
  end
  # Supports the same fields as add_project as well as
  # "is_completed" which is type BOOL
  def update_project(proj_id, post_data)
    get_resp("update_project", proj_id, post_data)
  end
  # Delete uses a POST method (but no info) so we need {}
  def delete_project(proj_id); get_resp("delete_project", proj_id, {}); end
  # Helper methods
  def get_proj_id(proj_name)
    get_projects().each { |proj|
      return proj["id"] if proj["name"] == proj_name
    }
    return false
  end

  ##################
  # Result Fields API
  ##################
  def get_result_fields(); get_resp("get_result_fields"); end

  ##################
  # Results API
  ##################
  # Results are returned latest first (LIFO)
  def get_results(test_id, limit=nil)
    args = "#{test_id}"
    args += "&limit=#{limit}" if limit != nil
    get_resp("get_results", args)
  end
  def get_results_for_case(run_id, case_id, limit=nil)
    args = "#{run_id}/#{case_id}"
    args += "&limit=#{limit}" if limit != nil
    get_resp("get_results_for_case", args)
  end
  # Has an UNDOCUMENTED limit of 250 results
  def get_results_for_run(run_id, offset=nil, limit=nil)
    args = "#{run_id}"
    if limit != nil and limit <= @max_results
      args += "&offset=#{offset}" if offset != nil
      args += "&limit=#{limit}" if limit != nil
      return get_resp("get_results_for_run", args)
    else
      # Figure out how many results there actually are in the run
      run = get_run(run_id)
      n_results = 0
      run.keys.each { |k|
        n_results += run[k] if k.match("_count") != nil
      }
      if limit == nil
      else
        if limit > n_results
          puts "Warning: # results (#{n_results}) < limit requested (#{limit})"
        else
          n_results = limit
        end
      end
      # and get them @max_results at a time.
      results_arr = []
      offset = 0
      while n_results > 0 do
        limit = [@max_results, n_results].min
        args += "&offset=#{offset}"
        args += "&limit=#{limit}"
        # puts "remaining results=#{n_results}, offset=#{offset}, limit=#{limit}"
        results_arr += get_resp("get_results_for_run", args)
        n_results -= @max_results
        offset += @max_results
      end
      return results_arr
    end
  end
  # Helper method of add_result() and add_result_for_case()
  def make_result_post_data(status_id, comment, version,
    elapsed, defects, assignedto_id, custom=nil)
    post_data = {"status_id" => status_id}
    post_data["comment"] = comment if comment != nil
    post_data["version"] = version if version != nil
    post_data["elapsed"] = elapsed if elapsed != nil
    post_data["defects"] = defects if defects != nil
    post_data["assignedto_id"] = assignedto_id if assignedto_id != nil
    post_data[custom[0]] = custom[1] if custom != nil
    return post_data
  end
  # Not supporting custom fields
  # Also not supporting structured steps custom field
  def add_result(test_id, status_id, comment=nil, version=nil,
    elapsed=nil, defects=nil, assignedto_id=nil, custom=nil)
    post_data = make_result_post_data(status_id, comment, version,
      elapsed, defects, assignedto_id, custom)
    get_resp("add_result", test_id, post_data)
  end
  # result_arr is an array of results hashes as in make_result_post_data()
  # with the addition of a "test_id" field in each one
  def add_results(run_id, results_arr)
    get_resp("add_results", run_id, results_arr)
  end
  def add_result_for_case(run_id, case_id, status_id, comment=nil,
    version=nil, elapsed=nil, defects=nil, assignedto_id=nil)
    args = "#{run_id}/#{case_id}"
    post_data = make_result_post_data(status_id, comment, version,
      elapsed, defects, assignedto_id)
    get_resp("add_result_for_case", args, post_data)
  end
  # result_arr is an array of results hashes as in make_result_post_data()
  # with the addition of a "case_id" field in each one
  def add_results_for_cases(run_id, results_arr)
    get_resp("add_results_for_cases", run_id, results_arr)
  end

  ##################
  # Runs API
  ##################
  def get_run(run_id); get_resp("get_run", run_id); end
  def get_runs(proj_id=@proj_id); get_resp("get_runs", proj_id); end
  def add_run(proj_id, suite_id, name=nil, desc=nil, mstone_id=nil,
    assign_id=nil, incl_all=true, case_ids=[])
    post_data = {"suite_id" =>  suite_id}
    post_data["name"] = name if name != nil
    post_data["desc"] = desc if desc != nil
    post_data["milestone_id"] = mstone_id if mstone_id != nil
    post_data["assignedto_id"] = assign_id if assign_id != nil
    post_data["include_all"] = incl_all
    post_data["case_ids"] = case_ids if incl_all == false
    get_resp("add_run", proj_id, post_data)
  end

  def get_run_id(name)
    get_runs(@proj_id).each { |r|
      return r["id"] if r["name"] == name
    }
    return false
  end

  # Supports the same fields as add_run() except for suite_id
  # and assignedto_id
  def update_run(run_id, post_data)
    get_resp("update_run", run_id, post_data)
  end

  # Close/Delete uses a POST method (but no info) so we need {}
  def close_run(run_id); get_resp("close_run", run_id, {}); end
  def delete_run(run_id); get_resp("delete_run", run_id, {}); end

  # Checks if a test run exists by name and adds it if not
  # Returns the test run ID in either case
  def add_run_if_not_exist(name, proj_id, suite_id, desc=nil,
    mstone_id=nil, assign_id=nil, incl_all=true, case_ids=[])
    log_info("Searching for test run named #{name}")
    run_id = nil
    get_runs(proj_id).each { |r| run_id = r["id"] if r["name"] == name }
    return run_id if run_id != nil
    log_info("Test run not found.  Adding it...")
    run_info = add_run(proj_id, suite_id, name, desc, mstone_id,
      assign_id, incl_all, case_ids)
    return run_info["id"]
  end

  ##################
  # Sections API
  ##################
  def get_section(sec_id); get_resp("get_section", sec_id); end
  def get_sections(proj_id, suite_id)
    args = "#{proj_id}&suite_id=#{suite_id}"
    get_resp("get_sections", args)
  end
  def add_section(proj_id, suite_id, name, parent_id=nil)
    post_data = {"suite_id" => suite_id, "name" => name}
    post_data["parent_id"] = parent_id if parent_id != nil
    get_resp("add_section", proj_id, post_data)
  end
  def update_section(sec_id, name)
    get_resp("update_section", sec_id, {"name" => name})
  end
  def delete_section(sec_id); get_resp("delete_section", sec_id); end
  def get_section_id(suite_id, name)
    get_sections(@proj_id, suite_id).each { |sec|
      return sec["id"] if sec["name"] == name
    }
    return false
  end
  def add_section_if_not_exist(suite_id, name, parent_id=nil)
    log_info("Searching for section named #{name}")
    ret_sec = nil
    get_sections(@proj_id, suite_id).each { |s| return s if s["name"] == name }
    log_info("Section not found.  Adding it...")
    return add_section(proj_id, suite_id, name, parent_id)
  end

  ##################
  # Suites API
  ##################
  def get_suite(suite_id); get_resp("get_suite", suite_id); end
  def get_suites(proj_id); get_resp("get_suites", proj_id); end
  def add_suite(proj_id, name, desc=nil)
    post_data = {"name" => name}
    post_data["description"] = desc if desc != nil
    get_resp("add_suite", proj_id, post_data)
  end
  def update_suite(suite_id, name=nil, desc=nil)
    post_data = {}
    post_data["name"] = name if name != nil
    post_data["description"] = desc if desc != nil
    get_resp("update_suite", suite_id, post_data)
  end
  # Warning! delete_suite cannot be undone and also deletes all
  # active test runs & results (i.e. those that were not yet closed)
  # Delete uses a POST method (but no info) so we need {}
  def delete_suite(suite_id); get_resp("delete_suite", suite_id, {}); end
  # Helper function
  def get_suite_id(name)
    get_suites(@proj_id).each { |s|
      return s["id"] if s["name"] == name
    }
    log_warn("Suite name #{name} not found")
    return false
  end

  ##################
  # Tests API
  ##################
  def get_test(test_id); get_resp("get_test", test_id); end
  def get_tests(test_run); get_resp("get_tests", test_run); end

  ##################
  # Users API
  ##################
  def get_user(user_id); get_resp("get_user", user_id); end
  def get_user_by_email(email)
    get_resp("get_user_by_email&email=#{email}")
  end
  def get_users(); get_resp("get_users"); end

  ##################
  # Helper tools
  ##################
  def pass_all_untested(run_id, build)
    get_tests(run_id).each { |t|
      if t["status_id"] == @untested
        title = t["title"]
        log_info("Setting #{title} to PASS")
        add_result(t["id"], @passed, nil, nil, nil, nil, nil, ["custom_build", build])
      end
    }
    return "All done!"
  end
end # end TestRail class

def help()
  puts "TestRail instance methods:"
  rail = TestRail.new
  TestRail.instance_methods(false).each { |m|
    print "#{m}("
    print rail.method(m.to_sym).parameters.map { |p| p[1] }.join(", ")
    puts ")\n"
  }
end

if __FILE__ == $0
  # Command line interface to the API
  require 'pp'
  p ARGV
  (puts "Use 'help' to see available commands"; exit 1) if ARGV.length == 0
  (help; exit 1) if ARGV[0] == "help"
  meth = ARGV[0]
  if not TestRail.instance_methods(false).include?(meth.to_sym)
    puts "Method not found: #{meth}"
    exit 1
  end
  rail = TestRail.new
  m = rail.method(meth)
  if ARGV.length > 1
    pp m.call(*ARGV[1..-1])
  else
    pp m.call()
  end
end

