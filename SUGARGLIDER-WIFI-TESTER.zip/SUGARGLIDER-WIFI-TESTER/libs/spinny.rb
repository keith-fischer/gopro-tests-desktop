#######################################################################################
### Sugarglider interface for SPINNY - An automated camera orientation changer
### based on the work of Juanita DeSouza, GoPro Automation QAE intern, Summer 2015
###
#######################################################################################
### Description: The functions provided will allow interfacing with the Arduino
###              Redboard via Serial interface and controlling a stepper motor.  Only
###              one function exists, spin(), which will spin the camera 180 degree.
###
#######################################################################################
### Linux Software requirements: None
### Ruby gems required: serialport
###
#######################################################################################
### Setup instructions:
### - Wire up redboard, easy-driver, and motor according to
###      https://learn.sparkfun.com/tutorials/easy-driver-hook-up-guide
###      ***DISCONNECT ANY POWER SUPPLY BEFORE CONNECTING/DISCONNECTING MOTOR***
### - Connect power supply and set to 12V
### - Connect Redboard to the host computer via USB
### - Orient camera UP or DOWN manually as required for test prerequisites
### - Test with 'ruby spinny.rb [SERIAL_DEV]'
###     - Example:  ruby spinny.rb /dev/ttyUSB0
###
#######################################################################################
### Programming examples:  See unit tests
#######################################################################################
require 'serialport'
require 'timeout'
require_relative 'log_utils'

class Spinny
  include LogUtils

  FWD = 1 # Clockwise
  REV = 2 # Counter-clockwise
  DISABLE = 3 # Disable motor control (saving power)
  DIR_STR = [nil, "FWD", "REV"]

  attr_accessor :current_orientation

  # Filter by serial_number if multiple boards are connected
  # Use server_id and password to connect across a network
  # opts = {:serial_number => 99999, :server_id => ‘myserver’, :password => nil}
  def initialize(serial_dev, curr_orient="UP")
    log_info("Initializing SPINNY on #{serial_dev}")
    begin
      timeout(5) {
        @ser = SerialPort.open(serial_dev, 9600)
        # resp = @ser.gets
        # log_verb(resp)
        # if resp.match(/SPINNY OK/)
        #   log_info("SPINNY initialized successfully")
        # else
        #   raise "Failed to receive SPINNY OK message"
        # end
      }
    rescue Timeout::Error
      raise "Timed out initializing SPINNY"
    rescue StandardError => e
      log_error("Unable to open serial port at #{serial_dev}")
      raise e
    end

    @next_direction = FWD
    @current_orientation = curr_orient
  end

  # Spin 180 degrees in the given direction
  # If no direction given it will spin the opposite direction of the previous spin
  # just in case there are wires connecting the camera that we do not want to get tangled
  def spin(dir=nil)
    dir = @next_direction if dir == nil
    log_info("SPINNY spinning #{DIR_STR[dir]}")
    begin
      timeout(5) {
        log_verb("SPINNY >>> " + dir.to_s)
        @ser.puts(dir)
        resp = @ser.gets
        log_verb("SPINNY <<< " + resp)
        if resp.match(/SPINNY OK/) == nil
          raise "Failed to receive SPINNY OK message"
        end
      }
    rescue Timeout::Error
      raise "Spinny timed out"
    end
    if dir == FWD
      @next_direction = REV
    else
      @next_direction = FWD
    end
    # 180 degree spin takes approx. 2 seconds
    sleep(2.0)
    @current_orientation = (@current_orientation == "UP") ? "DOWN" : "UP"
    log_verb("Current orientation: #{@current_orientation}")
  end

  def close()
    spin() if @current_orientation == "DOWN"
    @ser.puts(DISABLE)
    @ser.close()
  end # end close()

end # end Pushy

def quick_test(dev)
  # Basic connection and unit test here
  $LOGLEVEL = $LL_DEBUG
  log_info("Testing spinny")
  log_info("Current orientation assumes SPINNY was started in UP")
  s = Spinny.new(dev)
  log_info("Spinning auto-direction (should be forward)")
  s.spin()
  log_info("Spinning auto-direction (should be reverse)")
  s.spin()
  log_info("Forcing two forward spins")
  s.spin(Spinny::FWD)
  s.spin(Spinny::FWD)
  log_info("Forcing two reverse spins")
  s.spin(Spinny::REV)
  s.spin(Spinny::REV)
  s.close()
  log_info("DONE!")
end

if __FILE__ == $0
  include LogUtils
  if ARGV[0] == nil
    puts "Serial device is required argument!"
    puts "ruby spinny.rb /dev/ttyUSB0"
    exit 1
  end
  dev = ARGV[0]
  quick_test(dev)
end

###############################################################################
### Arduino Redboard Code reproduced here
### Load via Arduino Sketch v1.6.3
###############################################################################

# /******************************************************************************
# SparkFun Easy Driver Basic Demo
# Toni Klopfenstein @ SparkFun Electronics
# March 2015
# https://github.com/sparkfun/Easy_Driver

# Simple demo sketch to demonstrate how 5 digital pins can drive a bipolar stepper motor,
# using the Easy Driver (https://www.sparkfun.com/products/12779). Also shows the ability to change
# microstep size, and direction of motor movement.

# Development environment specifics:
# Written in Arduino 1.6.0

# This code is beerware; if you see me (or any other SparkFun employee) at the local, and you've found our code helpful, please buy us a round!
# Distributed as-is; no warranty is given.

# Example based off of demos by Brian Schmalz (designer of the Easy Driver).
# http://www.schmalzhaus.com/EasyDriver/Examples/EasyDriverExamples.html
# ******************************************************************************/
# //Declare pin functions on Redboard
# #define stp 2
# #define dir 3
# #define MS1 4
# #define MS2 5
# #define EN  6
# #define STEPANGLE 1.8
# #define MICROSTEPS_PER_STEP 8

# //Declare variables for functions
# char user_input;
# int x;
# int y;
# int state;
# int angle;

# void setup() {
#   pinMode(stp, OUTPUT);
#   pinMode(dir, OUTPUT);
#   pinMode(MS1, OUTPUT);
#   pinMode(MS2, OUTPUT);
#   pinMode(EN, OUTPUT);
#   // Set the pins appropriately
#   resetEDPins();
#   // Open the serial port (9600, 8N1, HW flow OFF (I think))
#   Serial.begin(9600); //Open Serial connection for debugging
#   //Serial.println("Begin motor control");
#   //Serial.println();
#   //Print function list for user selection
#   //Serial.println("Enter number for control option:");
#   //Serial.println("1. Turn 180 deg. forward at 1/8th microstep mode.");
#   //Serial.println("2. Turn 180 deg. reverse at 1/8th microstep mode.");
#   //Serial.println("3. Disable motor control and reset pins");
#   Serial.println("SPINNY OK");
# }

# //Main loop
# void loop() {
#   while (Serial.available()) {
#     user_input = Serial.read();
#     if (user_input == '1') { MicroStep(0, 180); } // FWD 180 // REV 180
#     else if (user_input == '2') { MicroStep(1, 180); }
#     else if (user_input == '3') { resetEDPins(); }
#     else {
#       //Ignore invalid input
#       //Serial.print("Invalid option entered: "); Serial.println(user_input);
#     }
#   }
# }

# //Reset Easy Driver pins to default states
# void resetEDPins()
# {
#   digitalWrite(stp, LOW);
#   digitalWrite(dir, LOW);
#   digitalWrite(MS1, HIGH); // Pull MS1, and MS2 high to set logic to 1/8th
#   digitalWrite(MS2, HIGH); // microstep resolution (we need the higher torque)
#   digitalWrite(EN, HIGH); // Disable motor control, saving power
# }

# void MicroStep(int fwd_rev, int angle)
# {
#   // Enables motor control.
#   // Persists until pin reset (option 3) to hold camera in place.
#   digitalWrite(EN, LOW);

#   // Set motor direction
#   if (fwd_rev == 0) {
#     digitalWrite(dir, LOW); // Forward/Clockwise
#   }
#   else {
#     digitalWrite(dir, HIGH); // Reverse/Counter-clockwise
#   }

#   int n_steps = (angle * MICROSTEPS_PER_STEP) / STEPANGLE;
#   for (x = 1; x < n_steps; x++)
#   {
#     //Trigger one step
#     digitalWrite(stp, HIGH);
#     delay(1);
#     digitalWrite(stp, LOW);
#     delay(1);
#   }

#   // Log action.  Spinny class looks for 'SPINNY OK' string
#   if (fwd_rev == 0) {
#     Serial.print("SPINNY OK -- FWD ");
#   } else {
#     Serial.print("SPINNY OK -- REV ");
#   }
#   Serial.print(angle);
#   Serial.print(" degrees (");
#   Serial.print(n_steps);
#   Serial.println(" steps) -- SPINNY OK");
# }
