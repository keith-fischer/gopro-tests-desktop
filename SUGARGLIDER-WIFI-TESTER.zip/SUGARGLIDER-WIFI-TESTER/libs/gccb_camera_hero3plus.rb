#!/usr/bin/env ruby

#######################################################
# gccb_camera_hero3plus.rb - GCCB camera class for Hero3+ Silver & Black
#   Class for connecting and communicating with a
#   camera/board connected by a standard gccb/serial interface
#
# Instructions:
# 1) Disconnect GCCB board from camera
# 2) Connect 3-wire connecter (black wire at top) to GCCB board and computer USB port
# 3) Connect mini-USB to GCCB sender board and computer USB port
# 4) Power-off camera and connect GCCB board
# 5) Locate the serial devices on your computer
#    On Raspberry PI: /dev/ttyACM0 (command port) and /dev/ttyUSB0 (response port)
# 6) Make it user-readable (sudo chmod 666 /dev/ttyACM0) - see verify_serial_port()
# 7) Run this test-file (OR tests/test_gccb_commands.rb)
#

# References/Documents/Specifications:
#
#  Hero3+-GCCB-JS060415.docx
#  "GCCB Request / Responses - Hero3+ Silver" -> https://wiki.gopro.com/pages/viewpage.action?pageId=44500292
#  "GCCB Request / Responses - Hero3+ Black"  -> https://wiki.gopro.com/pages/viewpage.action?pageId=43782897
#  "How to connect GCCB with Camera"          -> https://wiki.gopro.com/display/BD/How+to+connect+GCCB+with+Camera
#  "Camera Kit For HeroBus" -> https://wiki.gopro.com/pages/viewpage.action?spaceKey=BD&title=Camera+Kit+for+HeroBus
#
# Note: the GCCB Hero3+ api is not in any way similar to the Hero4 GCCB api
# Note: a lot of the framework (functions) for the serial and GCCB Hero4 api are left in for in case these functions are
#   implemented for the Hero3+ api and backward-compatibility with Sugarglider tests (if ever to be used with GCCB)
# 

=begin
# Example of GCCB serial command & response:
# Set camera mode to PHOTO:

COMMAND: (serial output)
CM 1

RESPONSE: (serial input)
>(C1)+(03)+(43)+(4D)+(01)-<
>(C0)+(02)+(00)+(01)+<

*What does this response mean?

Line#1:
>(C1)+(03)+(43)+(4D)+(01)-<
0xC1 == 
0x03 == 3 (length of following response bytes)
0x43 == 'C'
0x4D == 'M'
0x01 == 1  # mode 1

Line#2:
>(C0)+(02)+(00)+(01)+<
0xC0 == 
0x02 == 2 (length of following response bytes)
0x00 == 0 (no error?)
0x01 == 1


#Set mode to multi-shot burst mode
CM 2

................... RESPONSE PKT ...................
>(C1)+(03)+(43)+(4D)+(02)-<
>(C0)+(02)+(00)+(02)+<

*What does this response mean?
>(C1)+(03)+(43)+(4D)+(02)-<     # Is the echo of the command
0x03 == 3 (length of following response bytes)
0x43 == 'C'
0x4D == 'M'
0x02 == 2  # mode 2 (burst mode)

>(C0)+(02)+(00)+(02)+<          # Is the result of the command
0xC0 == 
0x02 == 2 (length of following response bytes)
0x00 == 0 (no error?)
0x02 == 2  # mode 2 (burst mode) was set


#Get the current mode (by sending a lone lower-case two-letter command)
cm
................... RESPONSE PKT ...................
>(C1)+(02)+(63)+(6D)-<
0xC1 =
0x03 == 3 (length of following response bytes)
0x63 == 'c'
0x6D == 'm'

>(C0)+(02)+(00)+(03)+<
0xC0 =
0x02 == 2 (length of following response bytes)
0x00 == 0 (no error)
0x03 == 3  # CURRENT mode 3 (timelapse mode)


GET Battery Level
INFO : GCCB command: bl

................... RESPONSE PKT ...................
>(C1)+(02)+(62)+(6C)-<
>(C0)+(02)+(00)+(64)+<
...........................
0xC1 =
0x02 == 2 (length of following response bytes)
0x62 == 'b'
0x6C == 'l'

>(C0)+(02)+(00)+(03)+<
0xC0 =
0x02 == 2 (length of following response bytes)
0x00 == 0 (no error)
0x64 == 100  #  percent-full == 0x64==100% full

=end

# WRONG MODE requests - Design for setting commands requested in the wrong mode
# 1. Read the mode, submode, settings  upon startup and SAVE in camera class variables
# 2. Change class variables when ever a setting is successfully changed and verified
#    Hint: do this in the api layer above "def set()", name-specific to call
# 3. Print WARNING if about to run setting command in WRONG mode
# 4. For test purposes, allow illegal commands to go through (sent)
#
# Design for VIDEO setting commands with MORE THAN ONE ARGUMENT
# 1. Resolution, FPS, and FOV are all combined in one command, however we should be able set one setting
# 2. DO THIS BY: 
#    a. READ & STORE all settings in class variables for each mode/submode - are these the DEFAULTS???
#    a. allowing the command to be sent, but upon verification read all 3 settings back and STORE in class variables
#    b. next time through use CLASS variables
#
# INVALID SETTINGS
# 1. Send illegal combinations (ie 60 fps in PAL mode) and record response
# 2. Send illegal values (ie out of range index)
# 3. Do this for ALL modes and ALL settings
#

require 'fileutils'
require 'serialport'
require 'set'
require 'scanf'

require_relative 'camera'
require_relative 'host_utils'
require_relative 'log_utils'
require_relative 'gccb_commands_hero3plus'

class GCCBCamera_Hero3plus < Camera
  include GCCBCommands_Hero3plus
  include LogUtils

  attr_accessor :last_video_attempted,
  :last_video_successful, :autoconnect,
  :debug, :extra_debug

  attr_reader :screens, :release, :type, :addr, :dev, :read_dev,

  # Use the following for determining invalid setting attempts
  :current_camera_mode,     # read during class initialization, update with any mode get command
  :current_camera_submode,  # read during class initialization, update with any submode get command

  # VIDEO current states
  :curr_video_submode,
  :curr_video_def_submode,
  :curr_video_format,       # NTSC vs PAL
  :curr_video_fps,
  :curr_video_fov,
  :curr_video_res,
  :curr_video_protune,
  :curr_video_protune_exposure,
  :curr_video_looping,
  :curr_video_lowlight,
  :curr_video_timelapse_interval, # MISSING FROM SPEC
  :curr_video_piv,          # photo in video 

  # PHOTO current states
  :curr_photo_submode,
  :curr_photo_def_submode,
  :curr_photo_res,
  :curr_photo_protune,
  :curr_photo_protune_exposure,
  :curr_photo_continuous_rate,

  # MULTI current states
  :curr_multi_submode,
  :curr_multi_def_submode,
  :curr_multi_res,
  :curr_multi_protune,
  :curr_multi_protune_exposure,
  :curr_multi_timelapse_interval,
  :curr_multi_burst_rate,

  # SETTINGS current states
  :current_fw_version,
  :curr_default_mode,
  :curr_default_submode,
  :curr_pb_osd_onoff,
  :curr_battery_percent,
  :curr_battery_bars,
  :curr_battery_state,
  :curr_quick_capture_mode,
  :curr_auto_off,
  :curr_camera_time,
  :curr_locate_camera,

  # NEW: added 9.22.15 for entire camera status response
  :current_camera_busy,
  :current_pt_enabled,
  :current_sdcard_err,
  :current_lowlight_en,
  :curr_power_state,

  :current_orientation,
  :current_obm_en,
  :current_osd_en,
  
  :curr_exp_mode,
  :curr_ti_intvl,
  :curr_pwroff_delay,
  :curr_beep_volume,
  :curr_num_leds,
  :curr_photos_rem,
  :curr_photos_taken,
  :curr_videos_rem,
  :curr_videos_taken,
  :curr_shutter_status,
  :current_white_balance,
  :current_iso,
  :current_sharpness,
  :curr_audio_input,


  :audio_channels,
  :audio_codec,
  :audio_sample_rate,
  :avc_profile_level,
  :burst_modes,
  :chg_prev_br_support,
  :chg_prev_res_support,
  :colorspace,
  :data_log_model,
  :defaults,
  :looping_chapter_len,
  :multi_photo_spot_metering_support,
  :multi_photo_nightlapse_support,
  :multi_photo_protune_support,
  :multi_shutter_exposure,
  :pes_modes,
  :photo_modes,
  :photo_spot_metering_support,
  :photo_continuous_support,
  :photo_night_support,
  :photo_protune_support,
  :photo_protune_iso_values,
  :photo_shutter_exposure,
  :preview,
  :protune_white_balance_values,
  :protune_color_values,
  :protune_sharpness_values,
  :protune_exposure_values,
  :setup,
  :test_preview_stream,
  :video_codec,
  :video_capture_modes,
  :video_looping_support,
  :video_low_light_support,
  :video_lrv_bitrate,
  :video_piv_support,
  :video_piv_intervals,
  :video_protune_support,
  :video_protune_iso_values,
  :video_timelapse_lrv_bitrate,
  :video_timelapse_support,
  :wifi_mac, :blue_mac, :serialno, :cam_model, :board_type, :cam_product, :product,
  :wait_time,
  :dont_verify,
  :retries,
  :verify
  
  alias_method :gccb_iface, :dev

  def get_all_camera_params()
    get_mode()
    get_video_format()
    get_video_sub_mode()
    get_video_settings()
=begin
    get_submode("VIDEO")
    get_submode("MULTI_SHOT")
    get_video_low_light() 
    get_video_looping()
    get_video_protune()
    get_video_protune_exposure()
    get_photo_res()
    get_photo_protune()
    get_photo_protune_exposure()
    get_photo_def_sub_mode()
    get_multi_timelapse_interval()
    get_multi_protune()
    get_multi_protune_exposure()
    get_multi_protune()
    get_sps()
    get_burst()
    get_pb_osd_onoff()
    get_battery_level()
    get_quickcapture()
    get_auto_off()
    get_camera_time()
    get_locate_camera()
=end
  end

  def initialize(dev)
    super()
    @read_dev = @dev        = dev                   # e.g. /dev/ttyACM0
    #@read_dev   = "/dev/ttyUSB0" if ["SILVER_PLUS", "BLACK_PLUS"].include?(@name)
    puts "@name=#{@name}"
    @read_dev   = "/dev/ttyUSB0"
    @addr       = @dev.split("/")[-1]   # e.g. ttyACM0
    @baud       = 115200  
    @serialport = verify_serial_port(@dev)
    @serialport_read = verify_serial_port(@read_dev)
    @interfaces << :gccb_hero3plus
    #@interfaces << :gccb 

    # The following are used as default ares to the "def set()" function call
    @wait_time  = 1.0
    @dont_verify= false
    @retries    = 1.0
    @verify     = true   # We want to automatically verify each setting
    @debug      = true  # turn on debug messages
    @debug      = false  # turn on debug messages
    @extra_debug= false  # turn on detailed debug messages

    #TODO - verify how to get camera info via GCCB or just do via wifi if enabled
    #TODO: FIXED CAMERA info for testing purposes

    ## Hero3+
    ## @release = "HD3"
    ## @type    = 10 # Hero3+ Silver
    ## #@type    = 11 # Hero3+ Black
    ## #HD3.10.03.00 as reported back from 'BF8F'
    ## @build   = "03.00.00"

    # GCCB initialization
    gccb_power_on()
    # see reinitialize_gccb()
    #TODO: get_all_camera_params()

    # get_cam_info() Sets the following:
    #  @release   = fw[0]
    #  @type      = fw[1].to_i
    #  @type      = fw[1].hex
    #  @build     = fw[2] + '.' + fw[3]
    #  @name      = fw[5].upcase
    #  @cam_model = fw[4]
    #@release, @type, @build, @serialno = get_cam_info() # DONT DO THIS WAY

    get_cam_info() # calls get_version()

    @cam_release = @release
    @cam_type    = @type
    @cam_build   = @build
    @cam_model   = "SILVER_PLUS" if  @type==10 
    @cam_model   = "BLACK_PLUS"  if  @type==11 
    @cam_product = @product

    # READ THE CAMERA FOR CURRENT MODES and SETTINGS
    # NOTE: This information will be used to determine if any attempts
    #  to set the a submode or setting is a VALID(NTSC & 30fps or INVALID (NTSC & 25fps) combination
    #
    # 1. get the mode (& save globally)
    # 2. get the submode (& save globally)
    # 3. get the format (NTSC/PAL) (& save globally)

    if @release == "HD4" and @type == 1
      require_relative 'camera_backdoor'
      extend Backdoor
      init()
    elsif @release == "HD4" and @type == 2
      log_info("HD4 camera_pipe")
      require_relative 'camera_pipe'
      extend Pipe
      init()
    elsif @release == "HX1" # Only DATA ANALYTICS commands supported!
      require_relative 'camera_rockypoint'
      extend Rockypoint
      init()
    elsif @release == "HD3" and @type == 21 # Only DATA ANALYTICS commands supported!
      require_relative 'camera_haleiwa'
      extend Haleiwa
      init()
    elsif @release == "HD3" and @type == 22 # Only DATA ANALYTICS commands supported!
      require_relative 'camera_himalayas'
      extend Himalayas
      init()
    elsif @release == "HD3" and @type == 10 # Hero3 Silver Plus
      require_relative 'camera_silver_plus'
      extend SilverPlus
      init()
    elsif @release == "HD3" and @type == 11 # Hero3 Silver Black
      require_relative 'camera_black_plus'
      extend BlackPlus
      init()
    else
      log_warn("Error: Unsupported serial camera (rel=#{@release}, type=#{@type})")
      log_info("Must be rel == HD4, type == [1|2]")
      raise "Make sure camera is connected, powered on, and contains an SD card."
    end
    @host       = Host.new()
    @last_video_attempted = nil   # The last video attempt via capture_video()
    @last_video_successful = nil  # The last video success via capture_video()
    #if ["BACKDOOR", "PIPE"].include?(@name)
    if ["SILVER_PLUS", "BLACK_PLUS"].include?(@name)
      #TODO: see if exists for GCCB
      #puts("GCCB manufacture data")
      #@wifi_mac, @blue_mac, @serialno, @cam_model, @board_type = get_manufacture_data()
    end

  end

  def reinitialize_gccb()
    gccb_power_on()
  end

  # Verifies that the serial port exists and is readable/writable
  def verify_serial_port(dev)
    doexit = false
    if not File.exist?(dev)
      log_warn("Serial device #{dev} not found. Is device plugged in?")
      doexit = true
    elsif not File.readable?(dev)
      log_warn("Serial device #{dev} not readable. 'sudo chmod 666 #{dev}' ?")
      doexit = true
    elsif not File.writable?(dev)
      log_warn("Serial device #{dev} not writable. 'sudo chmod 666 #{dev}' ?")
      doexit = true
    else
      begin
        serialport = SerialPort.new(dev, @baud)
      rescue StandardError => e
        log_warn("Unable to open serial port at #{dev}")
        log_warn(e.to_s + e.backtrace.join("\n"))
        doexit = true
      end
      log_info("OPENED serial port #{dev} SUCCESSFULLY")
      return serialport
    end
    exit 1 if doexit == true
  end

  # ENTIRE CAMERA STATUS RESPONSE FORMAT:
  # Format of 'se' command response
  # 0:: "03",  capture_mode
  # 1:: "00",   (reserved)
  # 2:: "03",  default_mode
  # 3:: "00",  exp_mode
  # 4:: "00", TI_INTVL
  # 5:: "00", powroff_delay
  # 6:: "00", fov
  # 7:: "08", photo_res
  # 8:: "06", (reserved)
  # 9:: "00", (reserved)
  # 10:: "FF", (reserved)
  # 11:: "00", (reserved)
  # 12:: "00", (reserved)
  # 13:: "00", (reserved)
  # 14:: "00", (reserved)
  # 15:: "02", beep_volume
  # 16:: "02", num_leds
  # 17:: "90", bits 2:ORIENT 3:OBM_EN 4:OSD_EN 5:VIDEO+MODE 6:LOCATION_EN
  # 18:: "32", battery_bar_level
  # 19:: "00", (reserved)
  # 20:: "16", photo file capacity remaining (upper byte)
  # 21:: "C4", photo file capacity remaining (lower byte)
  # 22:: "00", photos take (upper byte)
  # 23:: "00", photos take (lower byte)
  # 24:: "00", video file capacity remaining (minutes) (upper byte)
  # 25:: "84", video file capacity remaining (minutes) (lower byte)
  # 26:: "00", videos taken (upper byte)
  # 27:: "00", videos taken (lower byte)
  # 28:: "00", shutter status
  # 29:: "04"  FLAGS2 0:camera_busy(1=yes) 1:ProTunesEnabled 3:SDCARD_error (1=err) 6:low-light('lw' cmd)
  #
  # Tested 9.22.15
  def process_entire_cam_status(se)
    @current_camera_mode = capture_mode = se[0] ; puts "capture_mode=#{capture_mode}"
    @curr_default_mode = default_mode = se[2] ; puts "default_mode=#{default_mode}"
    @curr_exp_mode = exp_mode     = se[3] ; puts "exp_mode=#{exp_mode}"
    @curr_ti_intvl = ti_intvl     = se[4] ; puts "ti_intvl=#{ti_intvl}"
    @curr_pwroff_delay = powroff_delay= se[5] ; puts "powroff_delay=#{powroff_delay}"
    @curr_video_fov = fov          = se[6] ; puts "fov=#{fov}"
    @curr_photo_res = photo_res    = se[7] ; puts "photo_res=#{photo_res}"
    @curr_beep_volume = beep_volume  = se[15] ; puts "beep_volume=#{beep_volume}"
    @curr_num_leds = num_leds     = se[16] ; puts "num_leds=#{num_leds}"
    @curr_batter_bars = battery_bars = se[18] & 0xf ; puts "battery_bars=#{battery_bars} (0x#{battery_bars.to_s(16)})"

    @curr_photos_rem = photos_remaining = ((se[20] << 8) & 0xff00 ) | (se[21] & 0xff);puts "photos_remaining=#{photos_remaining}"
    @curr_photos_taken = photos_taken = ((se[22] << 8) & 0xff00 ) | (se[23] & 0xff);puts "photos_taken=#{photos_taken}"

    @curr_videos_rem = videos_remaining = ((se[20] << 8) & 0xff00 ) | (se[21] & 0xff);puts "videos_remaining=#{videos_remaining}"
    @curr_videos_taken = videos_taken = ((se[22] << 8) & 0xff00 ) | (se[23] & 0xff);puts "videos_taken=#{videos_taken}"

    @curr_shutter_status = shutter_status = se[28] ; puts "shutter_status=#{shutter_status}"

    @current_camera_busy = camera_busy =  se[29] & 0x1      ;  puts "camera_busy=#{camera_busy}"
    @current_pt_enabled  = pt_enabled  = (se[29] >> 1) & 0x1;  puts "pt_enabled=#{pt_enabled}"
    @current_sdcard_err  = sdcard_err  = (se[29] >> 3) & 0x1 ; puts "sdcard_err=#{sdcard_err}"   # bit 3 == 0x08
    @current_lowlight_en = lowlight_en = (se[29] >> 6) & 0x1 ; puts "lowlight_en=#{lowlight_en}" # bit 6 == 0x40

    @current_orientation = orientation = (se[17] >> 2) & 0x1 ; puts "orientation=#{orientation}" # bit 2 == 0x04
    @current_obm_en      = obm_en      = (se[17] >> 3) & 0x1 ; puts "obm_en=#{obm_en}"           # bit 3 == 0x08
    @current_osd_en      = osd_en      = (se[17] >> 4) & 0x1 ; puts "osd_en=#{osd_en}"           # bit 4 == 0x10
    @current_video_submode  = video_mode  = (se[17] >> 5) & 0x1 ; puts "video_mode=#{video_mode}"   # bit 5 == 0x20
    @curr_locate_camera  = locn_en     = (se[17] >> 6) & 0x1 ; puts "locn_en   =#{locn_en   }"   # bit 6 == 0x40
  end

  # Get entire camera status in one command
  # See function process_entire_cam_status() above
  # Tested 9.22.15
  def get_entire_cam_status
    puts "get entire camera status()" if @debug
    result, msg, statuses = get(entire_camera_status_cmds)
    if result
      #log_info("get_entire_cam_status: statuses=#{statuses}") 
      #statuses.each do |s|
        #puts s.to_s(16)
      #end
      process_entire_cam_status(statuses)
      return statuses
    else
      puts msg
      return nil
    end
  end

  # Sets the following:
  # @release   = fw[0]
  # @type      = fw[1].to_i
  # @type      = fw[1].hex
  # @build     = fw[2] + '.' + fw[3]
  # @name      = fw[5].upcase
  # @cam_model = fw[4]
  #
  # @release=HD3
  # @type=10
  # @build=03.00
  # @name=SILVER
  # @cam_model=HERO
  #
  def get_cam_info(tries=5)

    @debug = true
    get_version()
    @debug = false
    cam_release = @release
    cam_type    = @type
    cam_build   = @build
    serialno    = "XXXXXXXXXXXXXX"

    # IMPORTANT: Note, this information is needed for TestRail via ResultsHandler
    log_info("Camera Info:")
    log_conf("name, #{@name}")
    log_warn("serialno, ssid, and mac are HARDCODED")
    log_conf("serialno, C3131124519650")
    log_conf("ssid, aduong_bf8f")
    log_conf("mac, d4:d9:19:2d:18:5f")
    log_conf("release, #{cam_release}")
    log_conf("type, #{cam_type}")
    log_conf("build, #{cam_build}")

    return cam_release, cam_type, cam_build, serialno

  end # end get_cam_info()

  def update_cam_info()
    @release, @type, @build = get_cam_info()
  end

  def get_manufacture_data()
    wifi_mac = "???????"
    blue_mac = "???????"
    serialno = "???????"
    cam_model = @cam_type==10 ? "SILVER_PLUS" : "BLACK_PLUS"
    board_type = "board_type"
    return wifi_mac, blue_mac, serialno, cam_model, board_type
  end

  # Reads from the serial port for 'limit' seconds.
  # ALL output of interest must be received by this deadline
  def read_serial_resp(limit=1.0) # TODO: is 1 second long enough?
    resp = ""
    thr = Thread.new {
      while true do
        c = @serialport_read.getc  # NEW: Changed for Hero3+ which has seperate read and write ports
        resp << c if c != nil
      end
    }
    result = thr.join(limit)
    thr.terminate
    if @debug
      puts "\n................... RESPONSE PKT ...................\n"
      puts "#{resp}"
      puts "....................................................\n"

      # EXTRA DEBUGGING DETAIL...
      # The following line will print out the hex representation of each input byte
      # Use this to print out the values of unprintable characters suchas linefeeds(0xa) or 
      # carriage returns (0xd) 
      puts resp.each_byte.map { |b| b.to_s(16) }.join if @extra_debug
    end
    return resp
  end

  # Sends a string to the serial device
  def send_serial(s)
    puts("send_serial: \"#{s}\"") if @debug
    #log_info("GCCB command: #{s}")

    #SAVE: @serialport.write(s.chomp)
    #SAVE: @serialport.write("\r\n")

    @serialport.write(s) #NEW
    @serialport.write("\n\r")  # Linefeed "\n" and CR, "\r" are REQUIRED!!!
  end

  # Returns the response if the 're' match is found.  False if otherwise.
  # The response will be all the output through time 'timeout'.
  # Time per serial port read can be controlled by setting 'limit'
  #
  def expect(resp_in, re)
    # Convert all Fixnums to Strings and everything else to Regexp
    re = re.to_s if re.is_a?(Fixnum)
    re = Regexp.escape(re) if not re.is_a?(Regexp)
    return resp_in if resp_in.match(re) != nil
    return nil
  end

  # Function: get()
  # Note: works up to but limited to 3 response string args
  #
  def get(hash)
    puts "GET: hash[:name] = #{hash[:name]}" if @debug
    get_command  = hash[:get]
    send_serial(get_command)
    result,c1,c0,msg = read_serial_resp_in()
    arg1 =  c0
    return result, msg, c0
  end

  # Function: set()
  # NOTE: See gccb_commands_hero3plus.rb
  # 1. Format the GCCB "set" command, transmit it
  # 2. Format the GCCB "set response", if verify is true, read from camera, and compare
  # 3. Format the GCCB "get" command, transmit it, if verify is true
  # 4. Format the GCCB "get response" command, transmit it, if verify is true, and compare results
  #
  # FUNCTION: set()
  #   Set command that can be used for the well-formed API commands
  #
  # ARGS:
  #  hash      - command hash from gccb_commands_hero3plus.rb
  #  key       - value/arg to extract from hash[:settings] and put into gccb command
  #  wait_time - delay between sending command and checking for its response - default is 1.0s
  #  verify    - if 'true' it will send the :get command and get the :get_resp response from the camera
  # 
  # RETURNS:
  #     result - true|false
  #        msg - error message or ""
  #   verified - true|false
  #
  #
  def set(hash, key, wait_time=1.0, verify=true, retries=1)

    puts "set(): hash=#{hash} key=#{key} verify=#{verify}" if @extra_debug
    puts "set(): hash[:name]=#{hash[:name]}" if hash.has_key?(:name) if @debug

    not_verified = false  # returned if we never get to verify

    return false, "ERROR: hash #{hash} is MISSING the :set key", not_verified if hash[:set] == nil
    new_value = nil
    if key !=  nil
      if hash[:settings] != nil
        if hash[:settings][key] == nil
          msg = "ERROR: hash #{hash} is MISSING :settings[:key=#{key}]"
          log_error(msg)
          return false, msg, not_verified
        end
        # Get the NEW VALUE to set
        new_value = hash[:settings][key]
      else
        new_value = key
      end
      # Format the command with values
      set_command = hash[:set] % [ new_value ]
    else
      set_command = hash[:set]
    end

    msg  = ""
    msg2 = ""
    result = true
    ok = true
    verified     = false  # to be set below in GET verification if verify==true

    cmd_time = nil
    cmd_time = Time.now()
    send_serial(set_command)
    result,c1,c0,msg = read_serial_resp_in()  # This *already* checks the command response, lengths, and error fields

    #### VERIFICATION: check SET-CMD RESPONSE
    verify_set_response = true
    if verify_set_response
      puts "set():SET response result=#{result} msg=#{msg} c1=#{c1} c0=#{c0}" if @debug
      return result, msg, not_verified if !result
    end


    # Sleep any remaining time prescribed by wait_time arg.
    delay = wait_time - (Time.now() - cmd_time)
    sleep delay if delay > 0

    if verify == false
      msg = msg.to_s + "\nSkipping GET response VERIFICATION (verify==false)"
      return result, msg , not_verified
    end

    if verify == true and hash[:get] == nil
      msg = msg.to_s + "\nCANNOT VERIFY this command because hash is missing :get command"
      return result, msg , not_verified
    end

    ### VERIFICATION via CAMERA GET commands
    if verify == true and hash[:get] != nil

      puts "set():GET verification..." if @debug
      #sleep_gettime=1.0; puts "SLEEPING #{sleep_gettime}"; sleep sleep_gettime

      return false, msg + "\nHash MISSING :get key" if hash[:get] == nil

      get_command  = hash[:get]
      send_serial(get_command)

      result,c1,c0,msg = read_serial_resp_in()  # This *already* checks the command response, lengths, and error fields

      puts "set() GET verification: result=#{result} new_value=#{new_value} c0=#{c0} msg=#{msg}" if @debug
      puts "result=#{result}" if @debug
      if (c0.to_s == new_value.to_s)
        puts "VERIFIED c0 == new_value" if @debug
      else
        puts "FAILED verification! c0 != new_value"
      end
      verified = true if (result and (c0.to_s == new_value.to_s))
      puts "verified == #{verified}" if @debug

      msg = msg.to_s + "\n" + msg2.to_s

    end # verify GET command

    return result, msg, verified

  end # set() -------------------------------------------------

  # GET current camera mode
  #
  def get_current_capture_mode()
    get_mode()
  end # get_current_capture_mode

  # Override set_capture_mode()
  # mode_sub_mode will take precedence, otherwise it will use just 'mode'
  # "def mode_sub_mode() is defined in gccb_commands_hero3plus.rb
  #
  def set_capture_mode(new_mode)

    puts "set_capture_mode(#{new_mode})" if @debug

    if ["VIDEO", "VIDEO_TIMELAPSE", "VIDEO_PIV", "VIDEO_LOOPING",
        "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT",
        "BURST", "TIMELAPSE", "NIGHTLAPSE", "BROADCAST_RECORD"].include?(new_mode)

      puts("set_capture_mode(#{new_mode})")
      ret, msg = set(mode_sub_mode_cmds, new_mode) #TODO: NEEDS WORK -- will this work in GCCB SCHEME???
      return ret, msg

    end

    if new_mode == "VIDEO"
      mode_name = "VIDEO"
      sub_mode = video_sub_mode  # point to appropriate submodes hash
      sub_name = "VIDEO"

    elsif new_mode == "PHOTO" # For backward compatibility
      mode_name = "PHOTO"
      sub_mode = photo_sub_mode  # point to appropriate submodes hash
      sub_name = "SINGLE"

    elsif ["TIME_LAPSE", "TIMELAPSE"].include?(new_mode)
      mode_name = "TIMELAPSE"
      sub_mode = multi_sub_mode  # point to appropriate submodes hash
      sub_name = new_mode

    elsif ["BURST"].include?(new_mode)
      mode_name = "BURST"
      sub_mode = multi_sub_mode  # point to appropriate submodes hash
      sub_name = new_mode

    elsif ["PLAYBACK", "SETTINGS", "FW_UPDATE", "MTP", "SOS"].include?(new_mode)
      # NOTE: there are NO submodes for PLAYBACK, SETTINGS, etc.
      mode_name = new_mode
      sub_mode = nil  # point to

    else
      log_warn("Mode #{new_mode} NOT valid")
      return false, "Mode #{new_mode} NOT valid"
    end

    # Set the CAMERA MODE
    ret, msg = set(mode_cmds, mode_name)  
    return false, msg if ret == false

    # Set the CAMERA SUB-MODE
    if sub_mode != nil
      log_error("FIX THIS in set_capture_mode set(submode_hash...)")
      submode_hash = mode_cmds[:submodes][mode_name]
      ret, msg = set(submode_hash, sub_name)  
      return false, msg if ret == false
    end

    return true, "Set mode #{new_mode} SUCCESSFUL"
  end

  ###########################################################################
  # VIDEO METHODS
  ###########################################################################

  def set_video_sub_mode(x)
    verify = false
    verify = true
    result,msg,verified = set(video_sub_mode_cmds, x, @wait_time, verify, @retries)
    log_warn(msg) if !result
    @curr_video_submode = x if result and verified
    return verified
  end

  def get_video_sub_mode()
    result, msg, val = get(video_sub_mode_cmds)
    if result
      i_cmds = video_sub_mode_cmds[:settings].invert
      puts "video_sub_mode =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_video_submode = i_cmds[val.to_i]
      return @curr_video_submode
    else
      puts msg
      return nil
    end
  end

  def set_sub_mode(submode_hash, x)
    verify = true
    result,msg,verified = set(submode_hash, x, @wait_time, verify, @retries)
    log_warn(msg) if !result
    return verified
  end

  def set_video_def_sub_mode(x)
    @verify = true
    result,msg,verified = set(video_def_sub_mode_cmds, x, @wait_time, @verify, @retries)
    @curr_video_def_submode = x if result and verified
    log_warn(msg) if !result
    return verified
  end

  def set_video_resolution(x)
    #result, msg = set_video(@curr_video_format, x, @curr_video_fps, @curr_video_fov)
    result, msg = set_video_res(x)  # see function definition below
    return result
  end

  def set_video_res(x)
    log_info("set_video_res(\"#{x}\")")

    result, msg, verified = set(vid_res_cmds, x)

    if (result == true) and verified
      @curr_video_res = x
    else 
      puts "WARN: msg=#{msg}"
      puts "set_video_res() ***FAILED*** to set video resolution to #{x}"
    end
    return verified 
  end

  def get_video_res()
    puts "get_video_res()" if @debug
    result, msg, video_res = get(vid_res_cmds)
    if result
      ihash = vid_res_cmds[:settings].invert
      puts "video_res=#{video_res} #{ihash[video_res.to_i]}" if @debug
      @curr_video_res = video_res.to_i
      return @curr_video_res
    else
      puts msg
      return nil
    end
  end

  def set_video_fps(x)
    log_info("set_video_fps(\"#{x}\")")

    result, msg, verified = set(vid_fps_cmds, x)

    if (result == true) and verified
      @curr_video_fps = x
    else 
      puts "WARN: msg=#{msg}"
      puts "set_video_fps() ***FAILED*** to set video fps to #{x}"
    end
    return verified 
  end

  def get_video_fps()
    puts "get_video_fps()" if @debug
    result, msg, video_fps = get(vid_fps_cmds)
    if result
      ihash = vid_fps_cmds[:settings].invert
      puts "video_fps=#{video_fps} #{ihash[video_fps.to_i]}" if @debug
      @curr_video_fps = video_fps.to_i
      return @curr_video_fps
    else
      puts msg
      return nil
    end
  end

  def set_video_fov(x)
    log_info("set_video_fov(\"#{x}\")")

    result, msg, verified = set(vid_fov_cmds, x)

    if (result == true) and verified
      @curr_video_fov = x
    else 
      puts "WARN: msg=#{msg}"
      puts "set_video_fov() ***FAILED*** to set video fov to #{x}"
    end
    return verified 
  end

  def get_video_fov_name()
    puts "get_video_fov()" if @debug
    result, msg, video_fov = get(vid_fov_cmds)
    if result
      ihash = vid_fov_cmds[:settings].invert
      return ihash[video_fov.to_i]
    else
      puts msg
      return nil
    end
  end

  def get_video_fov()
    puts "get_video_fov()" if @debug
    result, msg, video_fov = get(vid_fov_cmds)
    if result
      ihash = vid_fov_cmds[:settings].invert
      puts "video_fov=#{video_fov} #{ihash[video_fov.to_i]}" if @debug
      @curr_video_fov = video_fov
      return @curr_video_fov
    else
      puts msg
      return nil
    end
  end

  # This is a COMBO function - sets 4 things at once
  # NOTE: these args in are in "key" string format, not actual GCCB command values
  #
  def set_video(vid_fmt, vid_res, vid_fps, vid_fov)

    puts "\nset_video(#{vid_fmt},#{vid_res},#{vid_fps},#{vid_fov})" if @debug
    verified_fov = set_video_fov(vid_fov)
    verified_fmt = set_video_mode(vid_fmt)
    verified_res = set_video_res(vid_res)
    verified_fps = set_video_fps(vid_fps)
=begin
    fov_check = get_video_fov_name()
    puts "fov_check: get_video_fov()=#{fov_check} set_video_fov==#{vid_fov}"
    if fov_check != vid_fov
      verified_fov = set_video_fov(vid_fov)
    else
      puts "FOV already #{vid_fov} (no need to set fov"
      verified_fov = true
    end
=end
    @debug = false

    return verified_fmt && verified_res && verified_fps && verified_fov
  end

  def get_video_settings()
    puts "get_video_settings2()"
    result, msg, xres, xfps, xfov = get(vid_fps_cmds)
    if result
      ifps = vid_fps_cmds[:settings].invert
      ires = vid_res_cmds[:settings].invert
      ifov = vid_fov_cmds[:settings].invert
      # len=hex[0][0].to_i(16)  # Note: the length of the "in:" response string is in ascii HEX
      res_name = ires[xres.to_i]
      fps_name = ifps[xfps.to_i(16)]
      fov_name = ifov[xfov.to_i]
      puts "result=#{result}" if @debug
      puts "res=#{xres} #{res_name}"
      puts "fps=#{xfps} #{fps_name}"
      puts "fov=#{xfov} #{fov_name}"
      @curr_video_res = res_name
      @curr_video_fps = fps_name
      @curr_video_fov = fov_name
    else
      puts msg
    end
    #return result, msg, xres, xfps, xfov
    return result, msg, res_name, fps_name, fov_name
  end

  def set_piv(x);                  return set_video_piv(); end
  def get_piv();                   return get_video_piv(); end
  def set_video_piv(x)
    puts "set_video_piv(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_piv_cmds, x, @wait_time, @verify)
    @curr_video_piv = x if verified
    return verified
  end

  def get_video_piv()
    result, msg, val = get(video_piv_cmds)
    if result
      i_cmds = video_piv_cmds[:settings].invert
      puts "video piv interval =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_video_piv = i_cmds[val.to_i]
      return @curr_video_piv
    else
      puts msg
      return nil
    end
  end


  ### WARNING: does NOT exist in GCCB spec 1.0 yet
  def set_video_timelapse_rate(x)
    return set_video_timelapse_interval(x)
  end
  def set_video_timelapse_interval(x)
    puts "set_video_timelapse_interval(\"#{x}\"\)" if @debug
    result,msg,verified =  set_timelapse_interval(x)
    @curr_video_timelapse_interval = x if verified
    return verified
  end

  def get_video_timelapse_interval()
    result, msg, timelapse_int_val = get(video_timelapse_interval_cmds)
    if result
      i_timelapse_int_cmds = video_timelapse_interval_cmds[:settings].invert
      puts "get__video_timelapse_interval=#{timelapse_int_val} #{i_timelapse_int_cmds[timelapse_int_val.to_i]}" # if @debug
      @curr_video_timelapse_interval = i_timelapse_int_cmds[timelapse_int_val.to_i]
      return timelapse_int_name
    else
      puts msg
      return nil
    end
  end

  def set_multi_timelapse_rate(x)
    return set_multi_timelapse_interval(x)
  end
  def set_multi_timelapse_interval(x)
    puts "set_multi_timelapse_interval(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_timelapse_interval_cmds, x, @wait_time, @verify)
    @curr_multi_timelapse_interval = x if verified
    return verified
  end

  def get_multi_timelapse_interval()
    result, msg, timelapse_int_val = get(multi_timelapse_interval_cmds)
    puts "timelapse_int_val=#{timelapse_int_val}"
    if result
      i_timelapse_int_cmds = multi_timelapse_interval_cmds[:settings].invert
      puts "get_multi_timelapse_interval=#{timelapse_int_val} \"#{i_timelapse_int_cmds[timelapse_int_val]}\"" # if @debug
      @curr_multi_timelapse_interval = i_timelapse_int_cmds[timelapse_int_val]
      return @curr_multi_timelapse_interval
    else
      puts msg
      return nil
    end
  end

  # Set the various VIDEO LOOPING times
  def set_video_looping(x); return set_looping(x); end

  def set_looping(x)  # Named for backward compatibility
    puts "set_video_looping(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_looping_cmds, x, @wait_time, @verify)
    @curr_video_looping = x if verified
    return verified
  end

  def get_video_looping(); return get_looping(); end
  def get_looping()  # Named for backward compatibility
    result, msg, vidlooping = get(video_looping_cmds)
    if result
      ividlooping = video_looping_cmds[:settings].invert
      puts "video looping=#{vidlooping} #{ividlooping[vidlooping.to_i]}" # if @debug
      @curr_video_looping = ividlooping[vidlooping.to_i]
      return @curr_video_looping
    else
      puts msg
      return nil
    end
  end

  def set_video_low_light(x)  # BLACK_PLUS only (does not work for SILVER_PLUS)
    puts "set_video_lowlight(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_lowlight_cmds, x, @wait_time, @verify)
    @curr_video_lowlight = x if verified
    return verified
  end

  def get_video_low_light()  # BLACK_PLUS only (does not work for SILVER_PLUS)
    result, msg, vid_lowlight = get(video_lowlight_cmds)
    if result
      ivid_lowlight = video_lowlight_cmds[:settings].invert
      puts "video lowlight=#{vid_lowlight} #{ivid_lowlight[vid_lowlight.to_i]}" # if @debug
      @curr_video_lowlight = ivid_lowlight[vid_lowlight.to_i]
      return @curr_video_lowlight
    else
      puts msg
      return nil
    end
  end


  def set_video_spot_metering(x);   return set(spot_metering_cmds, x); end

  def set_video_protune(x)
    puts "set_video_protune(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_cmds, x, @wait_time, @verify)
    @curr_video_protune = x if verified
    return verified
  end

  def get_video_protune()
    result, msg, vidprotunes = get(video_protune_cmds)
    if result
      ividprotunes = video_protune_cmds[:settings].invert
      puts "video protunes=#{vidprotunes} #{ividprotunes[vidprotunes.to_i]}" # if @debug
      @curr_video_protune = ividprotunes[vidprotunes.to_i]
      return @curr_video_protune
    else
      puts msg
      return nil
    end
  end

  # For compatibility with WifiCamera
  def set_protune(x);               return set_video_protune(x); end

  def set_video_white_balance(x);   return set_white_balance(x); end
  def get_video_white_balance();    return get_white_balance(); end

  def set_white_balance(x)
    cmd_hash = white_balance_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @current_white_balance = x if verified
    return verified
  end

  def get_white_balance()
    cmd_hash = white_balance_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "white balance=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @current_white_balance = i_cmds[val]
      return @current_white_balance
    else
      puts msg
      return nil
    end
  end

  def set_video_color(x);           return set(video_color_cmds, x); end

  def set_video_iso(x);             return set_iso(x); end
  def get_video_iso();             return get_iso(); end

  def set_iso(x)
    cmd_hash = iso_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @current_iso = x if verified
    return verified
  end

  def get_iso()
    cmd_hash = iso_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "iso=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @current_iso = i_cmds[val]
      return @current_iso
    else
      puts msg
      return nil
    end
  end


  def set_video_sharpness(x);       return set_sharpness(x); end
  def set_sharpness(x)
    cmd_hash = sharpness_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @current_sharpness = x if verified
    return verified
  end

  def get_sharpness()
    cmd_hash = sharpness_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "sharpness=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @current_sharpness = i_cmds[val]
      return @current_sharpness
    else
      puts msg
      return nil
    end
  end

  def set_video_protune_exposure(x)
    puts "set_video_protune_exposure(\"#{x}\"\)" if @debug
    result,msg,verified = set(video_protune_exposure_cmds, x, @wait_time, @verify)
    @curr_video_protune_exposure = x if verified
    return verified
  end

  def get_video_protune_exposure()
    puts "get_video_protune_exposure()" if @debug
    result, msg, vid_exp = get(video_protune_exposure_cmds)
    if result
      ividprotunes_exp = video_protune_exposure_cmds[:settings].invert
      puts "video protunes_exposure=#{vid_exp} #{ividprotunes_exp[vid_exp.to_i]}" # if @debug
      @curr_video_protune_exposure = ividprotunes_exp[vid_exp.to_i]
      return @curr_video_protune_exposure
    else
      puts msg
      return nil
    end
  end

  def set_trigger_shutter(x)
    puts "set_trigger_shutter(\"#{x}\"\)" if @debug
    result,msg,verified = set(trigger_shutter_cmds, x, @wait_time, @verify)
    @curr_shutter_status = x if verified
    return verified
  end

  # Tested 9.21
  def get_trigger_shutter()
    puts "get trigger_shutter()" if @debug
    result, msg, shutter_mode = get(trigger_shutter_cmds)
    if result
      @curr_shutter_status = shutter_mode
      puts "get_trigger_shutter(): result=#{result} msg=#{msg} @curr_shutter_status=#{@curr_shutter_status}" if @debug
      return @curr_shutter_status
    else
      puts msg
      return nil
    end
  end

  # Override start_capture()
  def start_capture(retries=2)
    # Try to poll the camera for the current capture mode.
    m = get_current_capture_mode()
    unless m
      log_warn("start_capture(): Defaulting to starting video capture.")
      m = "video"
    end
    return start_video_capture(retries) if m == "video"
    return start_photo_capture(retries) if m == "photo"
    return start_multi_capture(retries) if m == "multi_shot"
    return false, "Unknown capture mode."
  end # start_capture

  # Override stop_capture()
  def stop_capture(retries=2)
    # Try to poll the camera for the current capture mode.
    m = get_current_capture_mode()
    unless m
      log_warn("stop_capture(): Defaulting to stopping video capture.")
      m = "video"
    end
    # We should poll the camera for the current mode and do the right one.
    return stop_video_capture(retries) if m == "video"
    return stop_photo_capture(retries) if m == "photo"
    return stop_multi_capture(retries) if m == "multi_shot"
    return false, "Unknown capture mode."
  end # stop_capture

  # Tested 9.21
  # Start capturing video.
  def start_video_capture(r=2)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(start_video_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Start video capture failed."
      end
    end
    return result
  end # start_video_capture

  # Tested 9.21
  # Stop capturing video.
  def stop_video_capture(r=2)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(stop_video_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Stop video capture failed."
      end
    end
    return result
  end # stop_video_capture

  # Tested 9.21
  # Start capturing photo. Relocate this?
  # I'm not sure that we should be expecting a response here.
  def start_photo_capture(r=1)
    cmd_hash = trigger_shutter_cmds
    x = "START"
    puts "PHOTO #{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    return verified
  end # start_photo_capture

  # Tested 9.21
  # Stop capturing photo. Relocate this?
  def stop_photo_capture()
    cmd_hash = trigger_shutter_cmds
    x = "STOP"
    puts "PHOTO #{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    return verified
  end # stop_photo_capture

  # Captures video at a given RES/FPS/FOV for a given duration (in seconds)
  # Return status, msg.
  # status is true on success, false on fail.
  # msg holds information on pass/fail reason.
  def capture_video(vm, res, fps, fov, duration=5, ll=nil, spot=nil, 
    pt=nil, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
    @last_media = nil
    retries = 2

    (1..retries).each { |n|
      @last_video_attempted = nil
      log_debug("Capture video try #{n} of #{retries}")
      if set_capture_mode("VIDEO") == false
        next if n < retries
        return false, "Unable to set camera mode to VIDEO capture"
      end

      log_debug("Setting ProTune #{pt}")
      ret, msg = set_video_protune(pt)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_debug("Setting capture mode")
      ret, msg = set_video(vm, res, fps, fov)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_debug("Starting capture")
      start_time = Time.now()
      ret, msg = start_capture()
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      elapsed = Time.now() - start_time
      if duration > 5
        sleep (duration - elapsed) if (duration - elapsed) > 0
      else
        sleep duration
      end

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end # end capture_video

  def capture_piv(vm, res, fps, fov, p, duration, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      log_debug("Capture PIV try #{n} of #{retries}")
      ret, msg = set(mode, "VIDEO")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      ret, msg = set(video_sub_mode, "PIV")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      log_info("Setting PIV to #{p}s")
      ret, msg = set_piv(p)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      if ll != nil
        log_info("Setting low-light #{ll}")
        ret, msg = set_video_low_light(ll)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      if spot != nil
        log_info("Setting spot-metering #{spot}")
        ret, msg = set_video_spot_metering(spot)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      @last_video_attempted = nil
      log_debug("Setting capture mode")
      #ntsc_or_pal = (is_ntsc?(res, fps)) ? "NTSC" : "PAL"
      #ret, msg = set_video(ntsc_or_pal, res, fps, fov)
      ret, msg = set_video(vm, res, fps, fov)
      log_info(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end

      log_info("Starting capture for #{duration}s")
      start_time = Time.now()
      ret, msg = start_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      dur = duration - (Time.now() - start_time)
      sleep(dur) if dur > 0

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end

  def capture_looping(vm, res, fps, fov, loo, duration, setonly=false, orient=nil, ll=nil, spot=nil)
    retries = 3
    (1..retries).each { |n|
      log_debug("Capture PIV try #{n} of #{retries}")
      ret, msg = set(mode, "VIDEO")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      ret, msg = set(video_sub_mode, "LOOPING")
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      log_debug("Setting capture mode to #{vm}")
      ret, msg = set_video(vm, res, fps, fov)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end
      log_info(msg)

      vid_remain = get_rem_videos()
      if vid_remain == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, "Unable to query # remaining videos"
      end
      log_verb("Duration=#{duration}s, Space avail=#{vid_remain}s")
      if duration > vid_remain
        return false, "Insufficient space on SD card"
      end

      log_info("Setting looping to #{loo} min.")
      ret, msg = set_looping(loo)
      if ret == false
        reset_board() if not is_alive? == true
        next if n < retries
        return false, msg
      end

      if ll != nil
        log_info("Setting low-light #{ll}")
        ret, msg = set_video_low_light(ll)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      if spot != nil
        log_info("Setting spot-metering #{spot}")
        ret, msg = set_video_spot_metering(spot)
        if ret == false
          reset_board() if not is_alive? == true
          next if n < retries
          return false, msg
        end
      end

      return true, "Looping mode successfully set" if setonly == true

      @last_video_attempted = nil
      log_info("Starting capture for #{duration}s")
      start_time = Time.now()
      ret, msg = start_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false; next if n < retries; return false, status_msg; end
      if ret == false; next if n < retries; return false, msg; end
      f1 = msg
      log_debug("Capturing to #{f1}")
      @last_video_attempted = f1.split("\\")[-1]

      sleep(10.0)

      failed_arr = []
      lrvfile = @last_video_attempted[0..-4] + "LRV"
      exp = has_lrv?(res, fps, fov)
      act = media_exists?(lrvfile)
      if exp != act
        failed_arr << "LRV file (#{lrvfile}) presence (exp=#{exp}, act=#{act})"
      end
      log_warn("Skipping thumbnail verification on HD4 looping for now")

      dur = duration - (Time.now() - start_time)
      sleep(dur) if dur > 0

      log_info("Stopping capture")
      ret, msg = stop_capture()
      log_debug(msg)
      cam_alive, status_msg = detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false
        next if n < retries
        return false, status_msg
      end
      if ret == false
        next if n < retries
        return false, msg
      end
      if not failed_arr.empty?
        return false, failed_arr.join(",")
      end
      @last_video_successful = f1.split("\\")[-1]
      sleep 2
      return true, f1
    }
  end

  ###########################################################################
  # PHOTO METHODS
  ###########################################################################
  # These method names should override abstract methods in camera.rb when
  # possible to ensure test-case compatibility

  def set_photo_def_sub_mode(x)
    result,msg,verified = set(photo_def_sub_mode_cmds, x, @wait_time, @verify)
    log_warn(msg) if !result
    @curr_photo_def_submode = x if result and verified
    return verified
  end

  def get_photo_def_sub_mode()
    result, msg, submode = get(photo_def_sub_mode_cmds)
    if result
      i_cmds = photo_def_sub_mode_cmds[:settings].invert
      puts "photo default submode=#{submode} #{i_cmds[submode.to_i]}" # if @debug
      @curr_photo_def_submode = i_cmds[submode.to_i]
      return @curr_photo_def_submode
    else
      puts msg
      return nil
    end
  end

  def set_photo_sub_mode(x)
    result,msg,verified = set(photo_sub_mode_cmds, x, @wait_time, verify)
    log_warn(msg) if !result
    @curr_photo_submode = x if result and verified
    return verified
  end

  def set_photo_res(x)
    puts "set_photo_res(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_res_cmds, x, @wait_time, @verify)
    @curr_photo_res = x if verified
    return verified
  end

  def get_photo_res()
    result, msg, photo_res = get(photo_res_cmds)
    if result
      i_cmds = photo_res_cmds[:settings].invert
      puts "photo resolution=#{photo_res} #{i_cmds[photo_res.to_i]}" # if @debug
      @curr_photo_res = i_cmds[photo_res.to_i]
      return @curr_photo_res
    else
      puts msg
      return nil
    end
  end


  # Photo Continuous Shutter Speed/Rate (ie - 3|5|10 photos/s
  def set_sps(x)
    puts "set photo continuous shutter rate(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_sps_cmds, x, @wait_time, @verify)
    @curr_photo_continuous_rate = x if verified
    return verified
  end

  def get_sps()
    result, msg, val = get(photo_sps_cmds)
    if result
      i_cmds = photo_sps_cmds[:settings].invert
      puts "photo continuous rate=#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_photo_continuous = i_cmds[val.to_i]
      return @curr_photo_continuous_rate
    else
      puts msg
      return nil
    end
  end


  def set_photo_spot_metering(x);   return set(photo_spot, x); end

  def set_photo_protune(x)
    puts "set_photo_protune(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_protune_cmds, x, @wait_time, @verify)
    @curr_photo_protune = x if verified
    return verified
  end

  def get_photo_protune()
    result, msg, vidprotunes = get(photo_protune_cmds)
    if result
      i_cmds = photo_protune_cmds[:settings].invert
      puts "photo protunes=#{vidprotunes} #{i_cmds[vidprotunes.to_i]}" # if @debug
      @curr_photo_protune = i_cmds[vidprotunes.to_i]
      return @curr_photo_protune
    else
      puts msg
      return nil
    end
  end

  def set_photo_white_balance(x);   return set_white_balance(x); end
  def get_photo_white_balance();    return get_white_balance(); end

  def set_photo_color(x);           return set(photo_color, x); end

  def set_photo_iso(x);             return set(photo_iso, x); end

  def set_photo_sharpness(x);       return set(photo_sharpness, x); end

  def set_photo_exp(x);             return set_protune_photo_exposure(x); end
  def set_photo_protune_exposure(x)
    set(photo_protune_exposure_cmds, x)
    puts "set_photo_protune_exposure(\"#{x}\"\)" if @debug
    result,msg,verified = set(photo_protune_exposure_cmds, x, @wait_time, @verify)
    @curr_photo_protune_exposure = x if verified
    return verified
  end

  def get_photo_protune_exposure()
    puts "get_photo_protune_exposure()" if @debug
    result, msg, photo_exp = get(photo_protune_exposure_cmds)
    if result
      i_cmds = photo_protune_exposure_cmds[:settings].invert
      puts "photo protunes_exposure=#{photo_exp} #{i_cmds[photo_exp.to_i]}" # if @debug
      @curr_photo_protune_exposure = i_cmds[photo_exp.to_i]
      return @curr_photo_protune_exposure
    else
      puts msg
      return nil
    end
  end

  def capture_photo_single(res, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
  end

  def capture_photo_continuous(res, sps, duration=5.0, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil, quickpress=false)
  end

  ###########################################################################
  # MULTI-SHOT METHODS
  ###########################################################################

  def set_multi_sub_mode(x)
    result,msg,verified = set(multi_sub_mode_cmds, x, @wait_time, verify)
    log_warn(msg) if !result
    @curr_multi_submode = x if result and verified
    return verified
  end

  def set_multi_def_sub_mode(x);    return set(multi_def_sub_mode_cmds, x); end

  def set_multi_res(x);             return set(multi_res_cmds, x); end

  def set_burst(x)
    puts "set_burst(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_burst_cmds, x, @wait_time, @verify)
    @curr_multi_burst_rate = x if verified
    return verified
  end

  def get_burst()
    result, msg, val = get(multi_burst_cmds)
    if result
      i_cmds = multi_burst_cmds[:settings].invert
      puts "multi burst rate =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_multi_burst_rate = i_cmds[val.to_i]
      return @curr_multi_burst_rate
    else
      puts msg
      return nil
    end
  end

  def set_time_lapse(x);            return set(time_lapse_cmds, x); end

  def set_night_lapse(x);           return set(night_lapse_cmds, x); end

  def set_multi_spot_metering(x);   return set(multi_spot_cmds, x); end

  def set_multi_protune(x);         return set(multi_protune_cmds, x); end

  def set_multi_protune(x)
    puts "set_multi_protune(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_protune_cmds, x, @wait_time, @verify)
    @curr_multi_protune = x if verified
    return verified
  end

  def get_multi_protune()
    result, msg, pt_onoff = get(multi_protune_cmds)
    if result
      i_cmds = multi_protune_cmds[:settings].invert
      puts "multi protunes=#{pt_onoff} #{i_cmds[pt_onoff.to_i]}" # if @debug
      @curr_multi_protune = i_cmds[pt_onoff.to_i]
      return @curr_multi_protune
    else
      puts msg
      return nil
    end
  end

  def set_multi_protune_shutter_exposure(x); return set(multi_exp_cmds, x); end

  def set_multi_white_balance(x);   return set_white_balance(x); end
  def get_multi_white_balance();    return get_white_balance(); end

  def set_multi_color(x);           return set(multi_color_cmds, x); end

  def set_multi_iso(x);             return set(multi_iso_cmds, x); end

  def set_multi_sharpness(x);       return set(_cmdsmulti_sharpness, x); end

  def set_multi_protune_exposure(x)
    puts "set_multi_protune_exposure(\"#{x}\"\)" if @debug
    result,msg,verified = set(multi_protune_exposure_cmds, x, @wait_time, @verify)
    @curr_multi_protune_exposure = x if verified
    return verified
  end

  def get_multi_protune_exposure()
    puts "get_multi_protune_exposure()" if @debug
    result, msg, multi_exp = get(multi_protune_exposure_cmds)
    if result
      i_cmds = multi_protune_exposure_cmds[:settings].invert
      puts "multi protunes_exposure=#{multi_exp} #{i_cmds[multi_exp.to_i]}" # if @debug
      @curr_multi_protune_exposure = i_cmds[multi_exp.to_i]
      return @curr_multi_protune_exposure
    else
      puts msg
      return nil
    end
  end

  def set_multi_capture(x);         return set(multi_capture_cmds, x); end

  # This one wasn't abstracted properly. Calls the correct method above.
  def set_multi_photo_burst(x);     return set_burst(x); end

  def capture_multi_photo_burst(res, bu, spot=nil, pt=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
    tries = 2
    (1..tries).each { |n|
      log_info("Capturing #{res} #{bu} burst (try #{n} of #{tries})")
      ret = false
      msg = "Failed to set multi_shot burst mode"
      (1..3).each {
        ret, msg = set(mode_sub_mode_cmds, "MULTI_BURST")
        next if ret == false
        break
      }
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_multi_res(res)
      if ret == false
        next if n < tries
        return false, msg
      end
      ret, msg = set_burst(bu)
      if ret == false
        next if n < tries
        return false, msg
      end

      ret, msg = set_multi_spot_metering(spot) if spot != nil
      if ret == false
        next if n < tries
        return false, msg
      end

      if pt !=nil
        ret, msg = set_multi_protune(pt)
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_white_balance(wb) if wb != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_color(col) if col != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_iso(iso) if iso != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_sharpness(sh) if sh != nil
        if ret == false
          next if n < tries
          return false, msg
        end

        ret, msg = set_multi_protune_exposure(ex) if ex != nil
        if ret == false
          next if n < tries
          return false, msg
        end
      end # end pt
      sleep(3.0)

      set(multi_capture_cmds, "START", wait_time=0, verify=false)
      resp = expect(/C:.*JPG/, timeout=5, limit=1.0)
      if resp == nil
        next if n < tries
        return false, "Burst capture failed"
      end
      matchgroup = resp.match(/C:.*JPG/)
      wait_until_not_busy(interval=1.0, timeout=30)
      return true, "Capture successful. First file=#{matchgroup[0]}"
    }
  end

  def start_multi_capture(r=3, interval=3.0)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(start_multi_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "Start multi capture failed."
      end
    end
    return result
  end

  def stop_multi_capture(r=3, interval=3.0)
    retries = r
    for n in (1..retries) do
      result,msg,verified = set(stop_multi_trigger_cmds, nil, @wait_time, verify=false)
      log_warn(msg) if !result
      if result == nil
        next if n < retries
        return false, "stop multi capture failed."
      end
    end
    return result
  end

  def capture_multi_photo_nightlapse(res, pes, duration, orient=nil, spot=nil, pt=nil, se=nil, wb=nil, col=nil, sh=nil, iso=nil, ex=nil)
#    iso = nil
#    min_photos = 2
#    min_length = 10
    capture_multi_photo_timelapse(res, pes, duration, orient, spot, pt, wb, col,
    sh, iso, ex, multi_mode="NIGHT_LAPSE", se)
  end

  ###########################################################################
  # SETUP/SETTINGS
  ###########################################################################
  def set_lcd_brightness(x); return set(lcd_brightness_cmds, x); end

  def set_lcd_auto_off(x); return set(lcd_auto_off_cmds, x); end

  def set_exposure_mode(x)
    puts "exposure_mode(\"#{x}\"\)" if @debug
    result,msg,verified = set(exposure_mode_cmds, x, @wait_time, @verify)
    @curr_exposure_mode = x if verified
    return verified
  end

  def get_exposure_mode()
    cmd_hash = exposure_mode_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "exposure_mode=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @curr_exposure_mode = i_cmds[val]
      return @curr_exposure_mode
    else
      puts msg
      return nil
    end
  end

  def set_orientation(x)
    puts "set_orientation(\"#{x}\"\)" if @debug
    result,msg,verified = set(orientation_cmds, x, @wait_time, @verify)
    @current_orientation = x if verified
    return verified
  end

  def get_orientation()
    cmd_hash = orientation_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "orient_val=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @current_orientation = i_cmds[val]
      return @current_orientation
    else
      puts msg
      return nil
    end
  end

  def set_default_capture_mode(x)
    cmd_hash = default_mode_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    if (result == true) and verified
      @curr_default_mode = x
    else 
      puts "WARN: msg=#{msg}"
      puts "set_default_capture_mode() ***FAILED*** to set default mode to #{x}"
    end
    return verified 
  end

  def get_default_capture_mode()
    cmd_hash = default_mode_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "default captuture mode=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @curr_default_mode = i_cmds[val]
      return @curr_default_mode
    else
      puts msg
      return nil
    end
  end

  # Quick capture mode set on/off (true/false)
  def set_obm(x)
    puts "set_obm(\"#{x}\"\)" if @debug
    result,msg,verified = set(obm_cmds, x, @wait_time, @verify)
    @curr_quick_capture_mode = x if verified
    return verified
  end

  def set_quickcapture(x); return set_obm(x); end
  def get_quickcapture()
    result, msg, val = get(obm_cmds)
    if result
      i_cmds = obm_cmds[:settings].invert
      puts "quick capture mode =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_quick_capture_mode = i_cmds[val.to_i]
      return @curr_quick_capture_mode
    else
      puts msg
      return nil
    end
  end

  def set_led(x); return set_leds(x); end
  def get_led();  return get_leds(); end

  def set_leds(x)
    cmd_hash = led_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @curr_num_leds = x if verified
    return verified
  end

  def get_leds()
    cmd_hash = led_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "num_leds=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @curr_num_leds = i_cmds[val]
      return @curr_num_leds
    else
      puts msg
      return nil
    end
  end

  def set_beep_sound(x)
    cmd_hash = beep_sound_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @curr_beep_volume = x if verified
    return verified
  end

  def get_beep_sound()
    cmd_hash = beep_sound_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "curr_beep_volume=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @curr_beep_volume = i_cmds[val]
      return @curr_beep_volume
    else
      puts msg
      return nil
    end
  end


  # Backward compatible command
  def set_osd(x); return set_pb_osd_onoff(x); end
  def get_osd(); return get_pb_osd_onoff(); end
  def set_pb_osd_onoff(x)
    puts "set playback osd(\"#{x}\"\)" if @debug
    result,msg,verified = set(playback_osd_cmds, x, @wait_time, @verify)
    @curr_pb_osd_onoff = x if verified
    return verified
  end

  def get_pb_osd_onoff()
    result, msg, val = get(playback_osd_cmds)
    if result
      i_cmds = playback_osd_cmds[:settings].invert
      puts "playback osd =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_pb_osd_onoff = i_cmds[val.to_i]
      return @curr_pb_osd_onoff
    else
      puts msg
      return nil
    end
  end

  def set_locate_camera(x)
    puts "set locate camera(\"#{x}\"\)" if @debug
    result,msg,verified = set(locate_camera_cmds, x, @wait_time, @verify)
    @curr_locate_camera = x if verified
    return verified
  end

  def get_locate_camera()
    result, msg, val = get(locate_camera_cmds)
    if result
      i_cmds = locate_camera_cmds[:settings].invert
      puts "get locate_camera =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_locate_camera = i_cmds[val.to_i]
      return @curr_locate_camera
    else
      puts msg
      return nil
    end
  end

  # TIME FORMAT : Y1 Y2 MON DAY HOUR MIN SEC DOW(day of week)
  # ACTUAL TIME PORTION: 7 DF 9 9 13 12 A 3
  # Y1+Y2=7DF
  # converted to int =2015
  # 2015 9 9 19 18 10, 3
  # @curr_camera_time = 2015 9 9 19 18 10 dow:3
  def set_camera_time(year,mon,day,hour,min,sec)
    puts "set_camera_time()" if @debug
    puts "#{year} #{mon} #{day} #{hour} #{min} #{sec}" if @debug
    # Split up the year into two bytes
    year = year - 2000
    time_cmd = "%s %s %s %s %s %s" % [ year.to_s(16), mon.to_s(16), day.to_s(16), hour.to_s(16), min.to_s(16), sec.to_s(16)]
    # time_cmd.upcase!
    # x is the date/time string in the following format:
    puts "set camera time_cmd== (\"#{time_cmd}\"\)" if @debug
    result,msg,verified = set(camera_time_cmds, time_cmd, @wait_time, @dont_verify)
    return result
  end

  # EXAMPLE:
  # RESPONSE: 12 0 0 0 10 13 7 1A 0 0 8 7 DF 9 9 13 12 A 3
  # TIME FORMAT : Y1 Y2 MON DAY HOUR MIN SEC DOW(day of week)
  # ACTUAL TIME PORTION: 7 DF 9 9 13 12 A 3
  # Y1+Y2=7DF
  # converted to int =2015
  # 2015 9 9 19 18 10, 3
  # @curr_camera_time = 2015 9 9 19 18 10 dow:3
  def get_camera_time()
    puts "get_camera_time()" if @debug
    result, msg, val = get(camera_time_cmds)
    puts "val=#{val}"
    if result
      year = val[0].to_i + 2000
      cal_mon = camera_time_cmds[:month][val[1]]
      mon = val[1]
      day = val[2]
      hr  = val[3]
      min = val[4]
      sec = val[5]
      @curr_camera_time = "%s %s %s, %s:%s:%s" % [year, cal_mon, day, hr, min, sec] # Can use this to re-set time
      puts "curr_camera_time = #{@curr_camera_time}"
      return year, mon, day, hr, min, sec   # same format as Hero4 GCCB get_camera_time() so that test_gccb_commands.rb works
    else
      puts msg
      return nil
    end
  end

  def set_auto_off(x)
    cmd_hash = auto_off_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @curr_auto_off = x if verified
    return verified
  end

  def get_auto_off()
    result, msg, val = get(auto_off_cmds)
    if result
      i_cmds = auto_off_cmds[:settings].invert
      puts "power auto off =#{val} #{i_cmds[val.to_i]}" # if @debug
      @curr_auto_off = i_cmds[val.to_i]
      return @curr_auto_off
    else
      puts msg
      return nil
    end
  end

  # Tested 9.21

  # initialize() -> get_cam_info() -> get_version()
  def get_version()

    puts "get_version()" if @debug
    
    result, msg, fw_version = get(version_cmds)

    if result

      log_info("get_version: fw_version=#{fw_version}") 

      ### EXAMPLE:
      # "HD3.10.03.00 HERO3+ Silver Edition"
      #
      # @release = "HD3"
      # @type    = 10 # Hero3+ Silver
      # #@type    = 11 # Hero3+ Black
      # @build   = "03.00.00"


      # Parse the fields
      fw = fw_version.scan(/\w+/)
      # fw==["HD3", "10", "03", "00", "HERO3", "Silver", "Edition"]
      puts "fw=#{fw}" if @debug

      @release    = fw[0]
      @type       = fw[1].to_i
      #@type      = fw[1].hex
      @build      = fw[2] + '.' + fw[3][0] + fw[3][1]
      if fw[4] == nil
        if @type == 11 or @type == 10
          @product = "HERO3"
        end
      else
        @product    = fw[4]
      end
      if fw[5] == nil 
        @name = "BLACK_PLUS"  if @type == 11 
        @name = "SILVER_PLUS" if @type == 10
      else
        @name = fw[5].upcase + "_PLUS"
      end


      puts "\nCAMERA INFO (get_version)"
      puts "@release=#{@release}"
      puts "@type=#{@type}"
      puts "@build=#{@build}"
      puts "@name=#{@name}"
      puts "@product=#{@product}\n"

      @current_fw_version = fw_version

      return fw_version

    else
      puts msg
      return nil
    end
  end

  # Tested 9.21
  def set_power_off()
    puts "set power off()" if @debug
    x = "OFF"
    cmd_hash = power_off_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    wait_time = 3.0
    result,msg,verified = set(cmd_hash, x, wait_time, @dont_verify)
    @curr_power_state = x if result
    return result
  end

  def do_apply_settings(); return set(apply_settings_cmds, nil, 1.0, false); end

  # Tested 9.21
  def get_battery_level()
    puts "get battery level()" if @debug
    result, msg, percent = get(battery_level_cmds)
    if result
      puts "get_battery_level(): result=#{result} msg=#{msg} percent=#{percent}" if @debug
      log_warn("Battery level is OUT OF RANGE == #{percent}") if (percent.to_i<0 or percent.to_i>100)
      @curr_battery_percent = percent
      return percent
    else
      puts msg
      return nil
    end
  end

  def do_shutdown(); return set(shutdown_cmds, nil, 1.0, false); end

  def do_reset(force=true, timeout=30)
  end

  def do_beep_blink(x); return set(beep_blink_cmds, x); end

  def do_factory_reset(x)
  end

  def parse_yes_no(cmd, tries=2)
    (1..tries).each { |n|
      send_serial(cmd)
      re = /(^yes|^no)/
      resp = expect(re)
      if resp == nil
        next if n <= tries
        log_warn("Unable to parse yes/no from '#{resp}'")
        return false, "Unable to match yes/no"
      else
        return true if resp.match(re)[0] == "yes"
        return false if resp.match(re)[0] == "no"
      end
      return nil
    }
  end

  def parse_on_off(cmd, tries=2)
    (1..tries).each { |n|
      send_serial(cmd)
      re = /(^on|^off)/
      resp = expect(re)
      if resp == nil
        next if n <= tries
        log_warn("Unable to parse on/off from '#{resp}'")
        return false, "Unable to match on/off"
      else
        return true if resp.match(re)[0] == "on"
        return false if resp.match(re)[0] == "off"
      end
      return nil
    }
  end

  def recording?(); return parse_yes_no(recording_status[:get]); end

  def busy?(); return parse_yes_no(busy_status[:get]); end

  def save_settings()
    2.times {
      send_serial("t appc settings save")
      sleep 1
    }
  end

  # deprecated
  # def busy?(tries=3)
  #   busy_re = /record_active           [01]/
  #   (1..tries).each { |n|
  #     log_verb("Gerring status try #{n} of #{tries}")
  #     send_serial("t appc status show")
  #     resp = expect(busy_re, timeout=5.0, limit=1.0)
  #     break if resp != nil
  #   end
  #   if resp == nil
  #     log_warn("Unable to get status")
  #     return nil
  #   end
  #   stat = resp.match(busy_re)[0]
  #   p stat
  #   exit 1
  # end

  def quick_capturing?(); return parse_yes_no(quick_capture_status[:get]); end

  def wait_until_not_busy(interval=1.0, timeout=10)
    start = Time.now()
    loop {
      (recording?) ? sleep(interval) : (return true)
      log_verb("Waiting for camera not busy...")
      break if (Time.now() - start) > timeout
    }
    log_warn("Timeout waiting for camera not busy")
    return false
  end

  # Returns false if not supported, and a list of languages if supported.
  def language_support?()
    # Deem it supported if "t api setup" contains a "language" option.
    cmd = "t api setup" # Might vary on other cameras.
    send_serial(cmd)
    resp = read_serial_resp()
    return false unless resp and resp.match(/language/)
    ret = resp.match(/language.*/).to_s.match(/\[.*\]/).to_s.gsub("[","").gsub("]","").split("|")
    return ret
  end

  def get_language()
    langs = language_support?()
    return false unless langs
    cmd = language[:get] # Might vary on other cameras?
    send_serial(cmd)
    resp = read_serial_resp()
    langs.each { |lang| return lang if resp and resp.match(lang) }
    return false
  end

  # What does this do if we pass in nil?
  def set_language(x); return set(language, x); end

  ###########################################################################
  # Playback
  ###########################################################################

  def pb_start(); return set(playback_start, nil, 1.0, false); end

  def pb_stop(); return set(playback_stop, nil, 1.0, false); end

  def pb_pause(); return set(playback_pause, nil, 1.0, false); end

  def pb_resume(); return set(playback_resume, nil, 1.0, false); end

  def pb_step(); return set(playback_step, nil, 1.0, false); end

  def pb_forward(x); return set(playback_forward, x); end

  def pb_backward(x); return set(playback_forward, x); end

  def pb_start_slideshow; return set(playback_slideshow_start, nil, 1.0, false); end

  def pb_stop_slideshow; return set(playback_slideshow_stop, nil, 1.0, false); end

  def pb_multi_slideshow(); return set(playback_multi_slideshow, nil, 1.0, false); end

  def pb_next(); return set(playback_next, nil, 1.0, false); end

  def pb_prev(); return set(playback_prev, nil, 1.0, false); end

  def pb_tsearch(x); return set(playback_tsearch, x); end

  ###########################################################################
  # Storage
  ###########################################################################

  def set_tag(); return set(storage_tag, nil, 1.0, false); end

  def storage_count(cmd, tries=2)
    (1..tries).each {
      send_serial(cmd)
      re = /^[0-9]{1,6}/
      resp = expect(re)
      next if resp == nil
      return resp.match(re)[0].to_i
    }
    return false
  end

  #  def get_total_files(); return storage_count(total_files[:get]); end

  def get_photo_count(); return storage_count(photo_count[:get]); end

  def get_video_count(); return storage_count(video_count[:get]); end

  def get_rem_photos(); return storage_count(photos_rem[:get]); end

  def get_rem_videos(); return storage_count(vid_time_rem[:get]); end

  # For compatibility with WifiCamera
  def get_mins_avail()
    ret = get_rem_videos()
    if ret.to_i > 0
      return ret/60
    end
    log_warn("Unable to get remaining videos")
    return nil
  end

  def get_photos_avail()
    return get_rem_photos()
  end

  def get_photo_group_count(); return storage_count(group_photo_count[:get]); end

  def get_video_group_count(); return storage_count(group_video_count[:get]); end

  def get_last_file(tries=2)
    (1..tries).each {
      send_serial(last_file[:get])
      resp = read_serial_resp()
      m = resp.match(/.{8}\.MP4/)
      return m if m != nil
      m = resp.match(/.{8}\.JPG/)
      return m if m != nil
      sleep 0.5
    }
    return false, "Unable to get last file"
  end

  # Tested 9.21
  # Note: somewhat similar to a delete all media command
  def format_sd_card()
    puts "format_sd_card()" if @debug
    result,msg,verified = set(format_sdcard_cmds, nil, @wait_time, @dont_verify)
    return result
  end


  # NOTE:  camera reports NO errors if there are not any files on the SD card beforehand
  #
  # Tested 9.21
  def storage_delete_all()
    puts "storage_delete_all()" if @debug
    #TODO: put wifi verification here to save # photos and videos on card
    nilkey=nil # this tells set() that we don't have an arg to put in the command
    result,msg,verified = set(delete_all_cmds, nilkey, @wait_time, @verify)
    #TODO: put wifi verification that photos and videos on card both == 0
    return result
  end

  # TODO:  Why does deleting last file in photo mode, increase avail photo count by 6?
  # NOTE: camera reports ERROR if there are not any files on the SD card
  # 
  # Tested 9.21
  def storage_delete_last()
    puts "storage_delete_last()" if @debug
    #TODO: put wifi verification here to save # photos and videos on card
    nilkey=nil # this tells set() that we don't have an arg to put in the command
    result,msg,verified = set(delete_last_cmds, nilkey, @wait_time, @dont_verify)
    #TODO: put wifi verification that either photos and videos on card decremented by 1
    return result
  end

  # TODO: Figure out if this requires an arg?
  def storage_delete_one(x); return set(delete_one, x, 1.0, false); end


  # TODO: Figure out if this requires an arg?
  def storage_delete_group(x); return set(delete_group, x, 1.0, false); end

  def storage_status_event(x); return set(storage_status_event, x, 1.0, false); end

  ###########################################################################
  # WIRELESS
  ###########################################################################
  def set_wireless_mode(x)
    log_info("Setting wireless mode to #{x}")
    return set(wireless_mode, x)
  end

  def do_wifi_scan()
  end

  def do_pairing(x); return set(pairing, x, 1.0, false); end

  def do_pairing_stop(); return set(pairing_stop, nil, 1.0, false); end

  def do_wireless_ble(); return set(wireless_ble, nil, 1.0, false); end

  def do_push_multek(); return set(push_multek, nil, 1.0, false); end

  # Enable APP mode and return the ssid, pairing code of the camera
  # Returns false, false upon failure
  def enable_app_mode(ssid=nil, pc=nil)
    ssid = get_wifi_ssid() if ssid == nil
    pc = get_wifi_passphrase() if pc == nil
    if ssid != nil or pc != nil
      resp = nil
      log_info("Setting camera AP to ssid=#{ssid}, pc=#{pc}")
      3.times {
        send_serial("t api wireless ap_set #{ssid} #{pc}")
        resp = expect("SUCCESS")
        break if resp != nil
        sleep 1
      }
    else
      log_info("Using current camera wifi settings (ssid=#{ssid}, pc=#{pc})")
    end
    ret, msg = set_wireless_mode("APP")
    return ssid, pc if ret == true
    return false, false if ret == false
  end

  def get_csi(type, arg)
    ret = nil
    cmd = "t api wireless csi_get #{arg}"
    send_serial(cmd)
    resp = expect(/SUCCESS/)
    if resp == nil
      log_warn("No SUCCESS seen for arg=#{arg}")
      return ret
    end
    # TODO: Other types?
    if type == "STRING"
      re = /str - [a-zA-Z0-9_\-]+/
      resp_str = resp.match(re)
      if resp_str == nil
        log_warn("No valid string found in #{resp}")
      else
        ret = resp_str[0][6..-1].strip()
      end
    elsif type == "INT"  # Don't think any of them are floats...
      re = /value - \d+/
      resp_str = resp.match(re)
      if resp_str == nil
        log_warn("No valid number found in #{resp}")
      else
        ret = resp_str[0][8..-1].strip().to_i
      end
    end
    log_verb("Got #{arg} (#{type}) = #{ret}")
    return ret
  end

  def get_wifi_passphrase(); get_csi("STRING", "CSI_APP_PASSPHRASE"); end

  def get_wifi_ssid(); get_csi("STRING", "CSI_APP_SSID"); end

  def get_wireless_pin()
    cmd = "t appc wireless pin"
    send_serial(cmd)
    re = /^[0-9]{6}/
    resp = expect(re)
    if resp != nil
      return resp.match(re)[0].strip()
    end
    return nil
  end



  ###########################################################################
  # FW UPDATE
  ###########################################################################
  def do_fw_update_start(); return set(fw_update_start, nil, 1.0, false); end

  def do_fw_update_reset(); return set(fw_update_reset, nil, 1.0, false); end

  def do_boot_fw(); return set(boot_fw_cmds, nil, 1.0, false); end

  ###########################################################################
  # VID_FEATURE_AVAIL
  ###########################################################################
  # Takes capability-string, mode, res, fps, fov and returns whether it is supported
  # Capability strings are "piv", "low_light", "protune", "timelapse", "jello_slayer"
  def video_capability_filter_check(cap_str, m, r, fs, fv)
    cmd = method(cap_str+"_avail").call[:get]
    cmd_str = "#{cmd} #{m} #{vid_res[r]} #{fps[fs]} #{fov[fv]}"
    send_serial(cmd_str)
    re = /supported/
    resp = expect(re)
    return false, "Unable to get #{cap_str} availability" if resp == nil
    return true, true if resp.match("#{cap_str} supported") != nil
    return true, false if resp.match("#{cap_str} not supported") != nil
    return false, "Unable to read #{cap_str} support value from #{resp}"
  end

  ###########################################################################
  # OTHER USEFUL METHODS
  ###########################################################################
  def enable_power_save()
    3.times {
      send_serial("t appc status power_save")
      return true if expect("av_graph_power_save_enter", 2.0) != nil
    }
    return false
  end

  def disable_power_save()
    3.times {
      send_serial("t appc status power_save_disable")
      return true if expect("Disabling Power save", 3.0) != nil
    }
    return false
  end

  def simulate_low_batt()
    2.times {
      send_serial("t appc status lowbatt")
      break if expect("LOWBATT") != nil
    }
    return true
  end

  def simulate_over_temp()
    2.times {
      send_serial("t appc status overtemp")
      break if expect("OVERTEMP") != nil
    }
    return true
  end

  def short_press_button(b)
    ret, msg = set(short_press_cmds, b, wait_time=0.5, verify=false)
    return true
  end

  # Returns the mount point if a camera is mounted in mass-storage mode
  # Otherwise returns false
  def is_mounted?(pattern=nil)
  end

  # Turns on USB mass-storage mode and returns first camera found
  # If pattern is specified, returns first camera that matches
  def enter_mass_storage_mode(pattern=nil, retries=3, timeout=15)
    return nil
  end

  def exit_mass_storage_mode()
    send_serial(cmd)
    sleep 1
  end

  def get_first_gopro_dir(tries=3)
  end

  # Returns the full-path of all the media in the first GOPRO directory
  def get_medialist(suffix=nil, tries=3)
    dir = get_first_gopro_dir(tries)
    return [] if dir == nil
    send_serial("ls C:\\DCIM\\#{dir}\\*")
    # For very large numbers of files, the limit may be too short.
    data = ""
    (1..10).each {
      resp = read_serial_resp(limit=2.0)
      data += resp
      break if resp.match(/a:.>/) != nil
    }
    lines = data.split("\r\n")
    retval = []
    lines.each { |f|
      f.delete!("\u0000")
      fields = f.split()
      next if fields.length == 0
      next if fields[0][0] != "f" # Files only, skip directories
      (log_verb("Skipping #{f}"); next) if fields.length < 7
      fname = fields[6]
      # Skip non-matching suffix (if specified)
      next if suffix != nil and suffix != fname[-suffix.length..-1]
      retval << ["C:", "DCIM", dir, fname].join("\\")
    }
    return retval
  end

  # DEPRECATED
  def get_medialist2(suffix=nil)
    cam_root = enter_mass_storage_mode()
    if cam_root == nil
      log_warn("Camera did not appear as mass-storage-volume")
      return
    end
    if suffix == nil
      file_pattern = "*.*"
    else
      file_pattern = "*.#{suffix}"
    end
    # Matches files (file_pattern) in all subdirs (**) of DCIM
    medialist = Dir.glob(File.join(cam_root, "DCIM", "**", file_pattern))
    exit_mass_storage_mode()
    return medialist
  end

  # Override Camera.get_last_video()
  def get_last_video(); return @last_video_successful; end

  # Compatibility with Wi-fi camera
  def media_exists?(m)
    return find_file(m)
  end

  # fname is the 'basename' (i.e. GOPRxxxx.JPG) not the full path
  def find_file(fname, tries=3)
    dir = get_first_gopro_dir(tries)
    return false if dir == nil
    (1..tries).each { |n|
      send_serial("ls C:\\DCIM\\#{dir}\\*")
      resp = expect(fname, timeout=2, limit=1.0)
      return true if resp != nil
    }
    puts "returning false"
    return false
  end

  # fname is the 'basename' (i.e. GOPRxxxx.JPG) not the full path
  def find_file3(fname, tries=3)
    dir = get_first_gopro_dir(tries)
    return false if dir == nil
    (1..tries).each { |n|
      send_serial("ls C:\\DCIM\\#{dir}\\#{fname}")
      lines = read_serial_resp(limit=2.0).split("\r\n")
      lines.each { |f|
        f.delete!("\u0000")
        fields = f.split()
        next if fields.length != 7
        return true if fields[6] == fname
      }
    }
    puts "returning false"
    return false
  end

  # DEPRECATED
  def find_file2(fname)
    get_medialist().each { |f|
      return true if f.split("\\")[-1] == File.basename(fname)
    }
    return false
  end

  # Downloads a given file_name (e.g. GOPRO1234.MP4) to directory 'to_dir'
  def download_media(file_name, to_dir, retries=2)
    (1..retries).each { |n|
      log_debug("Looking for #{file_name} on camera")
      next if find_file(file_name) == false

      # File was found on the camera SD card, so let's mount it and copy it
      cam_root = enter_mass_storage_mode()
      if cam_root == nil
        log_warn("Can't find camera root in filesystem")
        return false, "Camera did not appear as mass-storage volume"
      end
      all_files = Dir.glob(File.join(cam_root, "DCIM", "**", "*.*"))
      log_verb(all_files)
      all_files.each { |f|
        if File.basename(f) == File.basename(file_name)
          if not File.directory?(to_dir)
            log_debug("Making #{to_dir}")
            FileUtils.mkdir_p(to_dir)
          end
          log_verb("Copying #{f} to #{to_dir}")
          mp4file = @host.copy_file(f, to_dir)
          lrvfile = f[0...-3] + "LRV"
          ret = @host.copy_file(lrvfile, to_dir)
          log_verb("Copied LRV file") if ret != nil
          thmfile = f[0...-3] + "THM"
          ret = @host.copy_file(thmfile, to_dir)
          log_verb("Copied THM file") if ret != nil
          sleep 3  # Very important to sleep here!
          exit_mass_storage_mode()
          return true, mp4file
        end
      }
      sleep 5
      log_debug("File not found.  Retrying...")
      exit_mass_storage_mode()
      sleep 5
    }
    return false, "File #{file_name} not found on camera"
  end

  # Downloads all media to directory 'to_dir'
  # (optionally stop after N files by setting stop_after=N)
  def download_all_media(to_dir, stop_after=nil)
    cam_root = enter_mass_storage_mode()
    if cam_root == nil
      log_warn("Camera did not appear as mass-storage-volume")
      return
    end
    all_files = Dir.glob(File.join(cam_root, "DCIM", "**", "*.*"))
    n_copied = 0
    all_files.each { |f|
      log_verb("Copying #{f} to #{to_dir}")
      mp4file = @host.copy_file(f, to_dir)
      n_copied += 1 if mp4file != nil
      break if stop_after != nil and n_copied == stop_after
    }
    exit_mass_storage_mode()
    if n_copied > 0
      return true, "#{n_copied} files copied"
    else
      return false, "File #{file_name} not found on camera"
    end
  end

  # Deletes a file on the SD card
  def delete_single_file(f)
    delfile = nil
    if File.dirname(f).length > 0
      delfile = f
    else
      all_files = get_medialist()
      all_files.each { |g|
        if File.basename(f) == File.basename(g)
          delfile = g
          break
        end
      }
    end
    if delfile == nil
      return false, "File #{f} not found on SD card"
    else
      log_debug("Deleting single file #{f}")
      send_serial("rm #{delfile}")
      return true, "File #{f} deleted"
    end
  end

  # Delete all using CCL command
  def delete_all_media()
    send_serial(delete_all[:set])
    sleep 5
  end

  def delete_all_media2()
    # Can take a LONG time if there are lots of files
    2.times {
      send_serial("rm c:\\dcim\\100gopro\\*")
      expect(/a:.>/, timeout=30, limit=1)
    }
    do_reset()
  end

  # DEPRECATED: Delete all the media on the SD card via 'rm' command
  # Use this only until an API command is given to do the same
  def delete_all_media3()
    log_debug("Deleting all files via 'rm' commands")
    send_serial("ls C:\\DCIM\\*")
    resp = read_serial_resp()
    log_verb("Looking up ***GOPRO directory")
    r = resp.match("...GOPRO")
    if r == nil or r.length < 1
      log_warn("No ***GOPRO directory found")
      return []
    end
    dir = r[0]
    send_serial("rm C:\\DCIM\\#{dir}\\*")
    sleep 3
    all_files = get_medialist()
    if all_files.length > 0
      ret = false
      msg = "Delete all media may have failed (medialist non-empty)"
    else
      ret = true
      msg = "Delete all successful"
    end
    log_debug(msg)
    return ret, msg
  end

  def already_set?(cmd="fake", args="fake")
    log_warn("already_set? method not supported on serial. Returning false")
    return false
  end


  # Boot the Hawaii camera
  def startGoPro4()
    send_serial('!\n')
    puts "please wait 20s"
    sleep 20.0
  end

  def send_zz_rdy()
    log_info("send_zz_rdy()") if @debug
    #buf = 'ZZ 0 0 2 1'
    byte1 = zz_cmds[:payload_byte1]["Ready"] 
    byte2 = zz_cmds[:payload_byte2]["Ready"]
    cmd   = zz_cmds[:set] % [ byte1, byte2 ]
    send_serial(cmd)

    resp_in = read_serial_resp_in()
    # Should get back:
    # in: 6 0 0 0 10 2 1  
    ack, ready1, ready2 = resp_in.scanf(zz_cmds[:set_resp])

    return false, "ZZ Ready ACK failed" if ack=='1'
    return false, "ZZ Ready1 failed" if ready1!='2'
    return false, "ZZ Ready2 failed" if ready2!='1'
    return true, "OK"
  end

  def sendZZcommand(cmdHex)
    zzcmd = 'ZZ 0 0 ' + cmdHex + '\n\r'
    send_serial(zzcmd)
  end

  def gccb_power_on(sleep_time=5.0)
    log_info("gccb_power_on()")
    send_serial(power_on_cmds[:set])
    puts "sleeping #{sleep_time}s..."
    sleep sleep_time
    #@debug = true
    resp = read_serial_resp(2.0)  # Allow more time because it READS the eprom listing #TODO: see if we need to check this
    #@debug = false
    @curr_power_state = 1
  end

  # GCCB Hero3+ ONLY
  # resp is the response pair set regex-scanned from the GCCB
  def check_resp_len(resp)

    return false, "resp=nil" if resp==nil
    puts "response len=#{resp.length}" if @extra_debug

    return false, "resp[1]==nil" if resp[1]==nil

    msg = ""
    #if (resp[1].hex < 0x21) or ((resp[1].hex > 0x7d) and (resp[1].hex < 0xa1))  # check for non-printable chars
      #msg = "check_resp_len(): resp[1]==#{resp[1]} is not a UTF8 hex value"
      #log_warn(msg)
      #puts "resp[1] is Fixnum" if resp[1].is_a?(Fixnum)
      #return false, msg
    #end

    param_len=resp[1].to_i(16) 
    puts "param_len=#{param_len}" if @extra_debug

    #MATH: actual resp length = param_len + length of 2 header bytes
    # which includes either C0 or C1 and the parameter (<length>) byte
    resp_hdr_len = 2 
    puts "resp_hdr_len=#{resp_hdr_len}" if @extra_debug

    expected_len = param_len + resp_hdr_len

    msg = ""
    if resp.length == expected_len
      msg += "lengths MATCH resp_len=#{resp.length} expected=#{expected_len}" if @debug
      return true, msg
    else
      msg += "lengths DONT MATCH! resp_len=#{resp.length} expected=#{expected_len}" if @debug
      return false, msg
    end
  end # check_resp_len

  # GCCB Hero3+ ONLY
  #  resp=["63", "6D"]
  #  e.inspect="63"
  #  e.hex=99
  #  packed('U')="c"
  #  e.inspect="6D"
  #  e.hex=109
  #  packed('U')="m"
  #  cm
  #  resp=["00", "03"]
  #  e.inspect="00"
  #  e.hex=0
  #  packed('U')="\u0000"
  #  e.inspect="03"
  #  e.hex=3
  #  packed('U')="\u0003"
  #
  # Arg: 'cmd' - pass this in so we can do "SPECIAL" processing on the response byte
  #              This is a KLUDGE because the responses are NOT consistent and need per-cmd attention!!
  #
  def convert_resp_to_utf8(resp, cmd=nil)
    # drop the header information from c1/c0
    puts "\nconvert_resp_to_utf8() cmd to process == #{cmd}" if @extra_debug
    #puts "resp=#{resp}" # (before deletes)"
    len = resp[1]


    is_c0 = (resp[0]=="C0")
    is_c1 = (resp[0]=="C1")
    #May need other "is_a0" tests here????

    puts "is_c0=#{is_c0}" if @extra_debug
    puts "is_c1=#{is_c1}" if @extra_debug

    # Delete the header information from the response line
    # C1 - leaving the command string that was sent
    # C0 - leaving the parameter that was actually set on the camera or the return string (ie - firmware version)
    #      Note: deletes the 3rd byte containing the command status (usually 00)
    resp.delete_at(0)
    resp.delete_at(0)
    # delete the status byte too -- it should not be part of the return value
    #  We'll check that in another place
    resp.delete_at(0) if is_c0  

    puts "resp=#{resp} (after deletes)" if @extra_debug
    

    if (cmd == 'se')  # get entire camera status will build an array instead of a string
      resp_utf8 = Array.new(30) # create an array that will hold 30 hex values
      resp.each_with_index do |e, i|
        resp_utf8[i] = e.hex
      end
      return resp_utf8
    end

    resp_utf8 = ""
    if (cmd == 'cs')  or (cmd == 'ti') # just return the ascii value
      puts "convert_resp_to_utf8(): cmd==ti or cs" if @extra_debug
      resp.each_with_index do |e, i|
        puts "cmd==ti e=#{e}"  if (cmd == 'ti') if @extra_debug
        resp_utf8 += e.to_i(16).to_s(16).upcase
      end
      return resp_utf8
    end
    if (cmd == 'tm')
      resp_utf8 = Array.new(6) # create an array that will hold 30 hex values
      resp.each_with_index do |e, i|
        resp_utf8[i] = e.to_i(16).to_s
      end
      return resp_utf8
    end

    resp.each do |e|

      # e.hex converts hex to decimal
      # U is the pack directive to convert from UTF-8
      packed = [e.hex].pack('U')

      # Note: skip the status byte altogether
      if (e.hex < 0x21) or ((e.hex > 0x7d) and (e.hex < 0xa1))  # check for non-printable chars
        # Append unprintable characters (ie - CR, LF, space)
        if (cmd == 'cv')
          case e.hex
          when 2
            puts "skipping value #{e}" if @extra_debug
          when 10
            puts "skipping value #{e}" if @extra_debug
            #puts "inserting NL"
            #resp_utf8 += "\n"
          when 12
            puts "ignoring formfeed #{e}" if @extra_debug
          when 21
            puts "inserting space for FACK #{e}" if @extra_debug
            resp_utf8 += " "
          when 32
            puts "inserting space for #{e}" if @extra_debug
            resp_utf8 += " "
          end # case 
        #elsif (cmd == 'cs')  or (cmd == 'ti') # just return the ascii value
          #puts "cmd==ti e=#{e}" 
          #resp_utf8 += e.to_i(16).to_s(16).upcase
        else
          resp_utf8 += ' ' if is_c1  # put a space between the 2-letter command and the parameter(s)
          resp_utf8 += e.hex.to_s
        end
      else # Printable characters or more special commands handled here
        if (cmd == "bl")
          resp_utf8 +=  e.hex.to_s
          # puts e.to_i(16)
        else
          resp_utf8 += [e.hex].pack('U')
        end
      end
    end # convert_resp_to_utf8

    resp_utf8.chomp!(' ') # remove trailing spaces
    puts resp_utf8.inspect if @extra_debug
    return resp_utf8

  end # convert_resp_to_utf8

  # Hero3+ ONLY
  #
  # Scans the Hero3+ GCCB response 
  #
  # response input:
  #   >(C1)+(03)+(43)+(4D)+(02)-<
  #   >(C0)+(02)+(00)+(02)+<
  #
  # Note: there is a NL "\n" between response C1 and C2
  # Returns:
  #   1. RESULT true(OK), false(ERROR) in the status
  #   2. Return the C1 command echo as the user sent it (convert all after the lenghth byte to ASCII)
  #   3. Return the C0 command status/reply as an array of chars (convert all after the length byte)
  #
  def get_resp_in(resp)

    #  EXAMPLE:
    #    >(C1)+(03)+(43)+(4D)+(02)-<
    # double WORD chars
    dual_lines = resp.split("\n")
    puts "dual_lines=#{dual_lines}" if @extra_debug
    c1_resp = dual_lines[0]
    c0_resp = dual_lines[1]
    if (c1_resp == nil) or (c0_resp == nil)
      msg = "NULL RESPONSES - Make sure camera is powered off first or reset the GCCB bacpac"
      log_error(msg)
      return false,"","", msg
    end
    c1_pairs = c1_resp.scan(/\w\w/)  # TODO: check this for empty or bad responses
    c0_pairs = c0_resp.scan(/\w\w/)  # TODO: check this for empty or bad responses

    c1_result, c1_msg = check_resp_len(c1_pairs)
    c0_result, c0_msg = check_resp_len(c0_pairs)

    msg = ""
    msg += c1_msg + "C1 lengths mismatch" if not c1_result
    msg += c0_msg + "C0 lengths mismatch" if not c0_result

    puts "c1_pairs=#{c1_pairs}" if @extra_debug
    puts "c0_pairs=#{c0_pairs}" if @extra_debug

    # Prevent ERROR "wrong number of arguments (1 for 0)" if c0_pairs or c0_pairs[2] is not in the correct format
    # It usually means that we did NOT get any serial response back from the GCCB
    return false, "", "", "c0_pairs is nil" if c0_pairs == nil
    return false, "", "", "c0_pairs[2] is nil" if c0_pairs[2] == nil
    #return false, "", "", "c0_pairs[2] is Fixnum" if c0_pairs[2].is_a? (Fixnum) # Not sure if this test is 

    cmd_status = c0_pairs[2].to_i(16) # This can get "wrong number of arguments (1 for 0)" ERROR if not in correct format
    #puts "STATUS=#{cmd_status}" if @extra_debug
    msg += "STATUS ERROR=#{cmd_status}" if cmd_status!=0

    # PARSE and CONVERT the C1 and C0 packet values to a simple usuable string of values
    # Why? Because GCCB is returning binary values for STATUS and COMMAND ARG value (dumb!)
    c1 = convert_resp_to_utf8(c1_pairs)
    c0 = convert_resp_to_utf8(c0_pairs,c1)  # not translating the CR/LF correctly in the firmware version 'cv' cmd response

    # A non-empty return message means we had an error somewhere
    result = msg.empty? ? true:false

    #puts "response RESULT=#{result}" if @debug
    puts "response ERROR MSG=#{msg}" if not result if @debug

    return result,c1, c0, msg

  end # get_resp_in

  # Get the response lines
  # Parse C1 and C0 lines for
  #  1. C1 command echo
  #  2. C1 and C0 lenth check
  #  3. C0 error code
  #  4. C0 parameter value returned
  #
  def read_serial_resp_in()

    # Gets raw input from serial line (whatever that may be)
    resp_pkt = read_serial_resp() 

    result,c1_resp,c0_resp,msg  = get_resp_in(resp_pkt)  
    #
    # get_resp_in() performs:
    #   1. command echo check in c1
    #   2. length check for c1 and c0 responses
    #   3. c0 error code check
    #
    # get_resp_in() returns:
    #   1. "result" - RESULT true(OK), false(ERROR) in the status
    #   2. "c1"     - C1 command echo as the user sent it (convert all after the lenghth byte to ASCII)
    #   3. "c0"     - C0 command status/reply as an array of chars (convert all after the length byte)

    return result, c1_resp, c0_resp, msg
  end

  # return the length byte of the "in:" response
  def resp_inlen(resp)
    if resp == nil
      log_warn("resp_inlen() resp == nil")
      return
    end
    #look for "in: <len>"
    hex = resp.scan(/^in: (\w+)/)
    #DEBUG: puts "resp_inlen() hex=#{hex}"
    len=hex[0][0].to_i(16)  # Note: the length of the "in:" response string is in ascii HEX
    #DEBUG: puts "resp_inlen() len=#{len}"
    return len
  end

  def get_nth_byte(resp, n)
    inline = resp.scan(/^in: (\w.+)/)
    inline = inline[0][0].chomp
    len = inline[0].to_i(16)
    if n > len
      log_warn("get_nth_byte(resp,#{n}):  n > len==#{len}")
      return nil
    end
    il = inline.split(" ")
    return il[n]
  end

  def get_last_byte(resp)
    inline = resp.scan(/^in: (\w.+)/)
    inline = inline[0][0].chomp
    len = inline[0].to_i(16)
    il = inline.split(" ")
    return il[len]
  end

  # Tested 9.21
  def set_mode(new_mode)
    log_info("set_mode(\"#{new_mode}\")")

    result, msg, verified = set(mode_cmds, new_mode)

    if (result == true) and verified
      @current_camera_mode = new_mode
    else 
      puts "WARN: msg=#{msg}"
      puts "set_mode() ***FAILED*** to set mode to #{new_mode}"
    end
    return verified 
  end

  def mode_to_name(mode)
    gettings = mode_cmds[:settings].invert
    #puts "gettings=#{gettings}"
    mode_str = gettings[mode.to_i]
  end

  # Tested 9.21
  def get_mode()
    puts "get_mode()" if @debug
    result, msg, mode = get(mode_cmds)
    if result
      imode = mode_cmds[:settings].invert
      puts "mode=#{mode} #{imode[mode.to_i]}" if @debug
      @current_camera_mode = mode.to_i
      return @current_camera_mode
    else
      puts msg
      return nil
    end
  end

  def set_video_output(port)
    log_info("set_video_output(\"#{port}\")")

    # TODO: Use @dont_verify because the :get 'vo' command is not working
    # When using @dont_verify, return the 'result' instead of 'verified'
    result,msg,verified = set(video_output_cmds, port, @wait_time, @dont_verify)


    if result == true
      @current_video_output_port = port # DISABLE verification check #if verified
      log_info("set_video_output port set to \"#{port}\")")
    else 
      puts "WARN: msg=#{msg}"
      puts "set_video_output() ***FAILED*** to set port #{port}"
    end
    #return verified  # When not verifying using the :get command
    return result
  end
  
  def get_video_output()
    puts "get_video_output()" if @debug
    result, msg, mode = get(video_output_cmds)
    if result
      imode = video_output_cmds[:settings].invert
      puts "mode=#{mode} #{imode[mode.to_i]}" if @debug
      @current_video_output_port = mode.to_i
      return @current_video_output_port
    else
      puts msg
      return nil
    end
  end

  def set_audio_input(x)
    cmd_hash = audio_input_cmds
    puts "#{cmd_hash[:name]} (\"#{x}\"\)" if @debug
    result,msg,verified = set(cmd_hash, x, @wait_time, @verify)
    @curr_audio_input = x if verified
    return verified
  end

  def get_audio_input()
    cmd_hash = audio_input_cmds
    result, msg, val = get(cmd_hash)
    if result
      i_cmds = cmd_hash[:settings].invert
      puts i_cmds
      puts "curr_audio_input=#{val} \"#{i_cmds[val.to_i]}\"" # if @debug
      @curr_audio_input = i_cmds[val]
      return @curr_audio_input
    else
      puts msg
      return nil
    end
  end

  # mode can either be the index value or string name as defined in mode_cmds
  def get_submode(mode)

    mode_cmds[:settings].each do |mode_name, mode_val|
      mode=mode_name if mode==mode_name or mode==mode_val
    end
    puts "get_submode(#{mode})"

    submode_hash = mode_cmds[:submodes][mode]

    # First put the camera into the correct "main" mode
    result, msg, submode = get(submode_hash)
    if result
      isubmode = submode_hash[:settings].invert
      puts "submode=#{submode} #{isubmode[submode.to_i]}"
      @current_camera_submode = submode.to_i
      return @current_camera_submode
    else
      puts msg
      return nil
    end
  end

  # VIDEO FORMAT "NTSC" vs "PAL"

  ## WARNING: this is the same as set_video_format()
  def set_video_mode(x)
    puts "set_video_mode(\"#{x}\"\)" if @debug
    result,msg,verified = set(vid_mode_cmds, x, @wait_time, @verify)
    @curr_video_format = x if verified
    return verified
  end

  def get_video_mode()
    puts "get_video_mode()" if @debug
    result, msg, video_format = get(vid_mode_cmds)
    if result
      i_cmds = vid_mode_cmds[:settings].invert
      vid_fmt_name = i_cmds[video_format.to_i]
      @curr_video_format = vid_fmt_name
      puts "video_format=#{video_format} #{i_cmds[video_format.to_i]}" if @debug
      return @curr_video_format
    else
      puts msg
      return nil
    end
  end

  def set_video_format(new_fmt) # "NTSC" or "PAL"
    puts "set_video_format(\"#{new_fmt}\"\)" if @debug
    set_video_mode(new_fmt)
  end

  def get_video_format()
    return get_video_mode()
  end

end # end GCCBCamera

####### M A I N #######

=begin
{
=end

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  
  serial_port = "/dev/ttyACM0"
  camera = get_gccb_camera_hero3plus(serial_port)
  camera.debug=true

  #puts "### POWER-ON..."
  #camera.gccb_power_on()  
    # line above replaces 3 lines below
    #camera.send_serial("!")
    #sleep(5.0)
    #resp = camera.read_serial_resp()

=begin
  ### TEST PURPOSES: put the command here :) ###

  ### STANDARD RESPONSE PARSER for Hero3+
  res,c1,c0,msg = camera.read_serial_resp_in()
  puts "C1=#{c1}"
  puts "C0=#{c0}"
  puts
=end

=begin
  puts "### SET Camera mode"; sleep(3.0)
  camera.send_serial("CM 2")

  puts "### GET Camera mode"; sleep(3.0)
  camera.send_serial("cm")

  # NOTE: battery level is returned in DECIMAL (STUPID!!! INCONSISTENT!!!)
  puts "### GET Battery Level"; sleep(3.0)
  camera.send_serial("bl")
  res,c1,c0,msg = camera.read_serial_resp_in()
  #c0 value should be decimal value/string between 0-100

  puts "### GET Version"; sleep(3.0)
  #camera.send_serial("vs")  ### THIS COMMAND DOES NOT WORK

  puts "### GET Camera Model and Firware Version"; sleep(3.0)
  camera.send_serial("cv")

  ##puts "### POWER-OFF"
  ##camera.send_serial("PW 0")
  ##resp = camera.read_serial_resp()
=end

=begin
  # WORKS (unit level testing)
  camera.set_power_off()
  camera.get_version() # called in get_cam_info()
  camera.get_battery_level()
  camera.get_mode()
  camera.set_mode("BURST")
  camera.set_mode("VIDEO")
  camera.start_video_capture()
  camera.stop_video_capture()
  camera.start_photo_capture()
  camera.start_photo_capture()
  camera.stop_photo_capture()
  camera.set_mode("BURST")
  camera.start_multi_capture()
  camera.stop_multi_capture()
  camera.set_mode("VIDEO")
  camera.start_video_capture()
  camera.get_trigger_shutter()
  camera.stop_video_capture()
  camera.get_trigger_shutter()
  #FAILED: camera.get_video_output()
  camera.set_video_output("USB_AV")
  camera.set_video_output("HERO_BUS")
  #TODO:  Why does deleting last file in photo mode, increase avail photo count by 6?
  camera.storage_delete_last()  # ERROR if there are not any files on the SD card
  camera.storage_delete_all()    # NO errors if there are not any files on the SD card beforehand
  camera.get_entire_cam_status() # Note: do this with shutter ON and OFF (either using Video or Multi)
  #camera.start_multi_capture()
  #camera.set_video_res("480") # PASSED
  camera.set_video_res("720") # FAILED
  #camera.set_video_res("4K-16:9") # FAILED
  camera.get_video_res()
  camera.get_video_fps()
  camera.get_video_fov()
  #camera.set_video_fps("12") # FAILEd (not supported in SilverPlus
  #camera.set_video_fps("24") # FAILED (not supported in SilverPlus
  # camera.set_video_fps("60") # PASSEd 
  #camera.get_video_fps()
  camera.get_video_fov()
  camera.set_video_fov("MEDIUM")
  camera.set_video_fov("WIDE")
  camera.set_video_fov("NARROW")
  camera.set_video_mode("PAL")
  camera.set_video_mode("NTSC")
  camera.get_video_format()
  #camera.set_mode("VIDEO")
  camera.set_video("PAL", "960", "25", "WIDE")
  camera.get_video_format()
  camera.get_video_res()
  camera.get_video_fps()
  camera.get_video_fov()
  camera.set_photo_res("5MP") # Check for ERROR handling in def set() - PASS (fixed gccb_camera.rb as well)
  camera.set_mode("PHOTO")
  puts "\nSLEEPING..."; sleep 5.0
  camera.get_photo_res()
  puts "\nSLEEPING..."; sleep 5.0
  camera.set_photo_res("7WIDE") # FAILED
  camera.set_photo_res("5MED") # FAILED
  puts "\nSLEEPING..."; sleep 5.0
  camera.get_photo_res()
  #camera.get_entire_cam_status()
  #camera.get_photo_res()
  camera.set_sps("10")   # WARNING: had to fix convert_utf8() to handle 'cs' cmd GET verification!!!
  camera.get_sps()
  camera.set_mode("BURST")
  camera.get_burst()
  camera.set_burst("30_2")  # FAILED
  camera.set_video("NTSC", "1080", "60", "WIDE")
  camera.set_video_res("1080") # PASSED
  camera.set_video_fps("60") # PASSED
  camera.set_video_fov("WIDE")
  #camera.set_video_fov("WIDE")
  #camera.set_video_fov("NARROW")
  #camera.set_video_fov("MEDIUM")
  puts "\nSLEEPING..."; sleep 5.0
  camera.get_video_format()
  camera.get_video_res()
  camera.get_video_fps()
  camera.get_video_fov()
  #camera.set_video_fps("12") # FAILEd (not supported in SilverPlus
  #camera.set_video_fps("24") # FAILED (not supported in SilverPlus
  # camera.set_video_fps("60") # PASSEd 
  #camera.get_video_fps()
  camera.get_video_fov()
  camera.set_video_fov("MEDIUM")
  camera.set_video_fov("WIDE")
  camera.set_video_fov("NARROW")
  camera.set_video_mode("PAL")
  camera.set_video_mode("NTSC")
  camera.get_video_format()
  #camera.set_mode("VIDEO")
  camera.set_video("PAL", "960", "25", "WIDE")
  camera.get_video_format()
  camera.get_video_res()
  camera.get_video_fps()
  camera.get_video_fov()
  camera.set_photo_res("5MP") # Check for ERROR handling in def set() - PASS (fixed gccb_camera.rb as well)
  camera.set_mode("PHOTO")
  puts "\nSLEEPING..."; sleep 5.0
  camera.get_photo_res()
  puts "\nSLEEPING..."; sleep 5.0
  camera.set_photo_res("7WIDE") # FAILED
  camera.set_photo_res("5MED") # FAILED
  puts "\nSLEEPING..."; sleep 5.0
  camera.get_photo_res()
  #camera.get_entire_cam_status()
  #camera.get_photo_res()
  camera.set_sps("10")   # WARNING: had to fix convert_utf8() to handle 'cs' cmd GET verification!!!
  camera.get_sps()
  camera.set_mode("BURST")
  camera.get_burst()
  camera.set_burst("30_2")  # FAILED
  camera.set_photo_res("7WIDE") # FAILED
  camera.set_burst("30_2")  # FAILED
  camera.set_burst("10_2")  # PASS - sort of - was already at that setting
  #camera.set_video_piv("OFF")
  #camera.set_video_piv("5") # FAILED
  #camera.set_video_piv("60") # FAILED
  #camera.set_video_piv("10") # FAILED
  camera.get_video_piv()
  #camera.set_multi_timelapse_interval("0.5")  # PASS
  #camera.set_multi_timelapse_interval("30")  #  PASS
  camera.set_multi_timelapse_interval("60")  #  PASS (had to fix convert_resp_to_utf8() )
  #camera.set_multi_timelapse_interval("10")  #  PASS
  camera.get_multi_timelapse_interval()
  camera.set_orientation("DOWN")
  camera.get_orientation()
  # TODO: TEST ME ON BLACK_PLUS #camera.set_video_low_light("ON") # BLACK_PLUS only (does not work for SILVER_PLUS)
  # TODO: TEST ME ON BLACK_PLUS # camera.get_video_low_light()  # BLACK_PLUS only (does not work for SILVER_PLUS)
  #camera.set_exposure_mode("CENTER-WEIGHTED")
  camera.set_exposure_mode("SPOT-METERING")
  camera.get_exposure_mode()
  camera.set_video_looping("120")
  camera.get_video_looping()
  camera.set_video_protune("ON")  # NOT supported in SILVER_PLUS #TODO: TESTME on BLACK_PLUS
  camera.get_video_protune()  # NOT supported in SILVER_PLUS #TODO: TESTME on BLACK_PLUS
  #camera.set_white_balance("RAW") # FAILED
  #camera.set_white_balance("6500K") # FAILED
  camera.get_white_balance() # WORKS
  camera.set_iso("400") # FAILED on silver_plus
  camera.get_iso() # FAILED on silver_plus
  camera.set_sharpness("MED") # failed on silver_plus
  camera.get_sharpness() # failed on silver_plus
  #camera.set_video_protune_exposure(x) # need pt on first
  camera.get_video_protune_exposure() # need pt on first
  #camera.set_leds("OFF") #PASS
  camera.set_leds("2") #PASS
  camera.get_leds() #PASS
  #camera.set_beep_sound("70") # PASS
  camera.set_beep_sound("0")
  camera.get_beep_sound()
  camera.set_default_capture_mode("BURST") 
  camera.get_default_capture_mode()
  camera.set_quickcapture("ON")
  camera.get_quickcapture()
  camera.set_audio_input("INTERNAL")   # FAILED and NOT supported for silver_plus # TODO: TESTME on black_plus
  #camera.set_audio_input("HERO_BUS")  # FAILED and NOT supported for silver_plus # TODO: TESTME on black_plus
  camera.get_audio_input()  # works, but setting it FAILS for silver 
  camera.set_locate_camera("ON")
  camera.get_locate_camera()
  camera.set_auto_off("5")
  camera.get_auto_off()
  camera.set_pb_osd_onoff("OFF")
  camera.get_pb_osd_onoff()
  year=2016; mon=1; day=2; h=3; m=4; s=5
  #val=["22", "1", "2", "3", "4", "10"]
  #curr_camera_time = 2022 Jan 2, 3:4:10
  camera.set_camera_time(year,mon,day,h,m,s)
  #camera.get_camera_time()
=end

  ## SET TO ONE OF THESE MODES
  #camera.set_mode("BURST")
  #camera.set_mode("VIDEO")
  #camera.set_mode("PHOTO")
  #camera.set_default_capture_mode("PHOTO") 
  #camera.set_mode("TIMELAPSE")

  # NEW function TEST HERE:
  puts "\n****************************************************"

  #camera.set_mode("VIDEO")

  camera.debug=true
  camera.extra_debug=false

  # camera.get_version() # called in get_cam_info()
  #camera.set_mode("BURST")  # PASSED
  #camera.set_default_capture_mode("BURST")   # PASSED

  # camera.set_mode("PHOTO")  # FAILS BADLY!!! 9.25.15
  # camera.set_default_capture_mode("PHOTO")   # WORKS by itself (if not setting mode to PHOTO

  # camera.set_mode("VIDEO")  # PASSED
  # camera.get_mode()
  # camera.get_default_capture_mode()   

  # camera.set_default_capture_mode("VIDEO")   # PASSED

  # camera.set_mode("TIMELAPSE")  # PASSED
  # camera.set_default_capture_mode("TIMELAPSE")   # PASSED

  # ONE CALL # camera.set_video("NTSC", "1080", "60", "WIDE")
  #camera.set_video("NTSC", "1080", "60", "WIDE")  # Tested 9.25
  #camera.set_video("NTSC", "1080", "30", "WIDE")  # Tested 9.25
  #camera.set_video("NTSC", "1080", "30", "MEDIUM")  # 
  #camera.set_video("NTSC", "1080", "60", "WIDE")  # 
  #camera.get_video_mode()
  #camera.get_video_res()
  #camera.get_video_fps()
  #camera.get_video_fov()
  #puts "\nSLEEPING..."; sleep 5.0

  #camera.set_video_mode("NTSC")
  #camera.set_video_res("1080") # PASSED
  #camera.set_video_fps("30") # PASSED
  #camera.set_video_res("960") # PASSED
  #camera.set_video_res("720") # PASSED
  #camera.set_video_fps("120") # PASSED
  #camera.set_video_fps("30") # PASSED
  #camera.set_power_off()
  #sleep 3
  #camera.gccb_power_on()
  #sleep 3
  #camera.set_video_fov("WIDE") # FAILED, PASSED with 3.0s read_serial_resp() delay
  #camera.set_video_fov("NARROW") # FAILED, PASSED with 3.0s read_serial_resp() delay
  #camera.set_video_fov("MEDIUM") # FAILED, PASSED with 3.0s read_serial_resp() delay
  #puts "\nSLEEPING..."; sleep 5.0

  #camera.get_video_mode()
  #camera.get_video_res()
  #camera.get_video_fps()
  #camera.get_video_fov()
  #puts "\nSLEEPING..."; sleep 5.0

  #camera.set_mode("BURST")
  #camera.set_burst("10_2")  # FAILED! sort of passed once - was already at that setting
  #camera.storage_delete_last()  # ERROR if there are not any files on the SD card

  #camera.get_video_output() # FAILS
  #camera.set_video_output("USB_AV")
  #camera.set_video_output("HERO_BUS")
  # camera.get_mode()

  # camera.set_beep_sound("70") # PASS
  #camera.get_entire_cam_status()

  #camera.set_orientation("UP")
  camera.set_default_capture_mode("VIDEO")   # PASSED
  #camera.get_orientation()
  puts "\n****************************************************"
  camera.debug=false
  verified = camera.set_power_off()
  # puts "camera.set_power_off verified=#{verified}"

end  # main()

# gccb_camera_hero3plus.rb
