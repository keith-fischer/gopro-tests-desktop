module MargaretRiver
  def init
    @name = "MARGARETRIVER"
    log_verb("Instantiating #{name} camera")
    @remote_api = 2  #remote smarty api version 2 (ie http://10.5.5.9/gp/gpControl/setting/1/0)
    @data_log_model = 16  # Camera model number for analytics purposes
    @analytics_version = "0.1.0"

    @audio_channels       = 2
    @audio_codec          = "aac"
    @audio_sample_rate    = 48000
    @audio_bitrate        = 64    #in kbps per channel.
    @avc_profile_level    = "MAIN"  # Same as Uluwatu
    # Support for changing preview bitrate via BV command
    @chg_prev_br_support  = nil #TBD
    # Support for changing preview resolution via BV command
    @chg_prev_res_support = true
    @colorspace           = "yuvj420p"
    @video_codec          = "h264"
    @total_lrv_bitrate    = 0.8
    @hilight_tag_limit    = 80

    #video
    @video_low_light_support    = true
    @video_protune_support      = true
    @video_timelapse_support    = true
    @video_piv_support          = true
    @video_looping_support      = true
    @video_spot_metering_support = false
    #photo
    @photo_spot_metering_support      = true
    @photo_continuous_support         = true
    @photo_night_support              = true
    @photo_protune_support            = true
    #multi_photo
    @multi_photo_spot_metering_support = true
    @multi_photo_nightlapse_support    = true
    @multi_photo_protune_support       = true

    # Share video/photo/multi_photo protune value. Split where necessary
    @video_protune_modes          = ["VIDEO"]
    @protune_white_balance_values = [nil]
    @protune_color_values         = [nil]
    @protune_sharpness_values     = ["OFF", "ON"]
    @protune_exposure_values      = [nil]
    # @photo_protune_iso_values     = [100, 200, 400, 800]
    @video_protune_iso_values     = ["1600", "400"]

    # @video_piv_intervals     = [5, 10, 30, 60]
    # @photo_shutter_exposure  = ["AUTO", "2", "5", "10", "15", "20", "30"]
    # @multi_shutter_exposure  = ['AUTO', "2", "5", "10", "15", "20", "30"]

    # preview stream testing flag
    @test_preview_stream     = false

    #photo's preview stream
    @photo_ts = {
      :lrv_aspect_ratio => "4:3",
      :lrv_width        => 320,
      :lrv_height       => 240
    }

    @capabilities = { #cc
      :has_camera_roll      => true,
      :has_ota              => true,  #over the air firmware update
      :has_ltp              => true,
      :has_3D               => false,
      :has_ccl              => true,   #camera control library
    }

    @defaults = {
      :setup_video_format     => "NTSC",
      :video_submode          => "VIDEO",
      :video_timelapse        => "0.5",
      :video_looping          => "5",
      :video_resolution       => "2.7K",
      :video_fps              => "30",
      :video_fov              => "W",
      :video_low_light        => "ON",
      :video_spot_metering    => "OFF",
      :video_pt_wb            => nil,
      :video_pt_color         => nil,
      :video_pt_sharp         => "ON",
      :video_pt_iso           => "1600",
      :video_pt_ev            => nil,
      :photo_submode          => "PHOTO",
      :photo_resolution       => "8WIDE",
      :photo_spot_metering    => "OFF",
      :multi_photo_submode    => "TIMELAPSE",
      :multi_photo_resolution => "8WIDE",
      :multi_photo_burst      => "5_1",
      :multi_photo_timelapse  => "0.5",
      :multi_photo_spot_meter => "OFF",
      :setup_default_mode     => "VIDEO",
      :setup_orientation      => "UP",
      :setup_led              => "4",
      :setup_beep             => "100",
    }

    #Initial camera setup before executing any tests
    @setup = {
      :setup_led              => "4",
      :setup_beep             => "100",
    }

    # Commands that don't have prerequisites
    # Wifi commands to test
    @cmds = [
      :setup_beep,
      :setup_default_mode,
      :setup_led,
      :video_spot_metering,
      :photo_spot_metering,
      :multi_photo_spot_meter,
      :setup_orientation,
      :setup_video_format,
    ]

    # Data structure for preview specifications
    # Basically come in 2 flavors.  Fullscreen and Widescreen
    # Fullscreen is 4:3 and widescreen is anything >4:3
    @preview = {
      # QVGA, WQVGA.  bitrate in bps
      "LOW" => {
      :bitrate => {
      :LOW  => 311040,
      :MED  => 500000,
      :HIGH => 750000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 240,
      :width_fs         => 320, # QVGA
      :width_ws         => 432, # WQVGA
      },
      # VGA, QVGA.  bitrate in bps
      "HIGH" => {
      :bitrate => {
      :LOW  => 1221120,
      :MED  => 2000000,
      :HIGH => 3000000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 480,
      :width_fs         => 640, # QVGA
      :width_ws         => 848, # WQVGA
      },
    }

    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 5,
      "120"   => 5,
      "MAX"   => 5,
    }

    # File size limit for videos after which it is split
    @chapter_size = 2<<30 # 2 GB

    @video_protune_vars = {
      :video_pt_color   => false,
      :video_pt_iso     => true,
      :video_pt_sharp   => true,
      :video_pt_ev      => false,
      :video_pt_wb      => false
    }

    @photo_protune_vars = {
      :photo_pt_color   => true,
      :photo_pt_iso     => true,
      :photo_pt_sharp   => true,
      :photo_pt_ev      => true,
      :photo_pt_wb      => true
    }

    @multi_photo_protune_vars = {
      :multi_photo_pt_color   => true,
      :multi_photo_pt_iso     => true,
      :multi_photo_pt_sharp   => true,
      :multi_photo_pt_ev      => true,
      :multi_photo_pt_wb      => true
    }

    # Additional supported options.
    @has_raw_support = true # RAW image. --raw OFF|ON
    @has_wdr_support = true # Wide Dynamic Range. --wdr OFF|ON
    @has_awf_support = true # Audio Wind Filtering. --awf OFF|WIND|STEREO
    @has_eis_support = true # Image Stabilization. --eis OFF|ON

    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    @video_capture_modes = {
      "4K"  =>  {
      :width  => 3840,
      :height => 2160,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 854,
      :lrv_height => 480,
      :lrv_aspect_ratio => "16:9",
      :fps    => {
      "25"  => {
      :fov        => ["W","L"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => false,
      }, # End 25
      "30"  => {
      :fov        => ["W","L"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => false,
      }, # End 30
      }, # End fps
      }, # End 4K
      "2.7K"  =>  {
      :width  => 2704,
      :height => 1520,
      :aspect_ratio => "169:95",
      :protune => true,
      :lrv_width  => 854,
      :lrv_height => 480,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov        => ["W", "M", "S", "L"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "25"  => {
      :fov        => ["W", "M", "S", "L"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "30"  => {
      :fov        => ["W", "M", "S", "L"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      }
      } # end fps
      }, # end 2.7K
      "2.7K_FS" => {
      :width  => 2704,
      :height => 1520,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 640,
      :lrv_height => 480,
      :lrv_aspect_ratio => "4:3",
      :fps  => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      }
      }, # end 2.7K_FS
      "1440"  =>  {
      :width  => 1920,
      :height => 1440,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 640,
      :lrv_height => 480,
      :lrv_aspect_ratio => "4:3",
      :time_lapse => false,
      :fps    => {
      "24"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 14.99,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "48"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 47.95,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :piv        => false,
      :eis        => true,
      },
      } # end fps
      }, # end 1440
      "1080"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 854,
      :lrv_height => 480,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => false,
      :fps    => {
      "24"  => {
      :fov        => ["W", "M", "N", "S", "L"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "25"  => {
      :fov        => ["W", "M", "N", "S", "L"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "30"  => {
      :fov        => ["W", "M", "N", "S", "L"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "50"  => {
      :fov        => ["W", "S", "L"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :piv        => false,
      :looping    => true,
      :eis        => true,
      },
      "60"  => {
      :fov        => ["W", "S", "L"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :piv        => false,
      :looping    => true,
      :eis        => true,
      },
      "90"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 30,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 90,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      } # end fps
      }, # end 1080
      "960"  =>  {
      :width  => 1280,
      :height => 960,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 640,
      :lrv_height => 480,
      :lrv_aspect_ratio => "4:3",
      :time_lapse => false,
      :fps    => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => true,
      },
      "100"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 100,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => false,
      },
      } # end fps
      }, # end 960
      "720"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 854,
      :lrv_height => 480,
      :lrv_aspect_ratio => "9:5",
      :time_lapse => true,
      :fps    => {
      "25"  => {
      :fov        => ["W", "M", "S"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "30"  => {
      :fov        => ["W", "M", "S"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "50"  => {
      :fov        => ["W", "M", "S"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "60"  => {
      :fov        => ["W", "M", "S"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping    => true,
      :piv        => true,
      :eis        => true,
      },
      "100"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 100,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => false,
      },
      "120"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 119.88,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      :eis        => false,
      },
      } # end fps
      }, # end 720
    } # end @video_capture_modes

    # FOV has been added to VTL.
    @video_timelapse_capture_modes = {
      "4K"  =>  {
      :width  => 3840,
      :height => 2160,
      :aspect_ratio => "16:9",
      :ntsc_fps => 29.97,
      :pal_fps => 25,
      :bitrate => 60,   #Mbps
      :timecode => true,
      :thm => true,
      :lrv_width  => 854,
      :lrv_height => 480,
      :lrv_aspect_ratio => "16:9",
      :lrv_ntsc_fps => 29.97,
      :lrv_pal_fps => 25,
      :lrv_timecode => true,
      :fov => ["W"],
      },
      "2.7K_FS" => {
      :width  => 2704,
      :height => 2028,
      :aspect_ratio => "4:3",
      :ntsc_fps => 29.97,
      :pal_fps => 25,
      :bitrate => 45,
      :timecode => true,
      :thm => true,
      :lrv_width  => 640,
      :lrv_height => 480,
      :lrv_aspect_ratio => "16:9",
      :lrv_ntsc_fps => 29.97,
      :lrv_pal_fps => 25,
      :lrv_timecode => true,
      :fov => ["W"],
      },
      "1080" => {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :ntsc_fps => 29.97,
      :pal_fps => 25,
      :bitrate => 30,
      :timecode => true,
      :thm => true,
      :lrv_width  => 854,
      :lrv_height => 480,
      :lrv_aspect_ratio => "16:9",
      :lrv_ntsc_fps => 29.97,
      :lrv_pal_fps => 25,
      :lrv_timecode => true,
      :fov => ["W", "M", "L", "N", "S"],
      }
    }

    # Photo Modes
    @photo_modes = {
      "10WIDE" => {
      :width        => 3648,
      :height       => 2736,
      :min_size     => 1500, # KB
      :min_psnr     => 31.0, # May raise if camera noise is reduced.
      :min_quality  => 98.0,
      :sps => {
      "3"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      # "10_3"  => { :min_quality  => 98.0 },
      "30_1"  => { :min_quality  => 98.0 },
      "30_2"  => { :min_quality  => 98.0 },
      "30_3"  => { :min_quality  => 98.0 },
      "30_6"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      :night_lapse => {
      "4"     => { :min_quality  => 98.0 },
      "5"     => { :min_quality  => 98.0 },
      "10"    => { :min_quality  => 98.0 },
      "15"    => { :min_quality  => 98.0 },
      "20"    => { :min_quality  => 98.0 },
      "30"    => { :min_quality  => 98.0 },
      "60"    => { :min_quality  => 98.0 },
      "120"   => { :min_quality  => 98.0 },
      "300"   => { :min_quality  => 98.0 },
      "1800"  => { :min_quality  => 98.0 },
      "3600"  => { :min_quality  => 98.0 },
      "CONTINUOUS"  => { :min_quality  => 98.0 }
      }, # end night_lapse modes
      }, # end 10WIDE
    } # end PHOTO mode
  end # end init
end # end module MargaretRiver
