# camera.rb
require 'net/http/persistent'
require 'json'
require 'uri'
require 'fileutils'
require 'socket'

require_relative 'camera'
require_relative 'exitcodes'
require_relative 'log_utils'
require_relative 'metadata'
require_relative 'wifi_commands'
require_relative 'mtp_utils'

class MTPCamera < Camera
  attr_reader :remote_api_version, :ip, :port, :os, :release, :type, :build
  include MTPUtils
  include WifiCommands
  include LogUtils
  def initialize(ip, port, os)
    @ip = ip  #ip of the system that camera is connecting to
    @port = port  #port which webserver is listening on
    @os = os  #MAC or WIN OS which camera is connecting to
    @http = Net::HTTP::Persistent.new("Camera@#{ip}")
    @release, @type, @build = get_cam_info()

    if @release == "HD3" and @type == 10
      require_relative 'camera_silver_plus'
      extend SilverPlus
    elsif @release == "HD3" and @type == 11
      require_relative 'camera_black_plus'
      extend BlackPlus
    elsif @release == "HD4" and @type == 1
      require_relative 'camera_backdoor'
      extend Backdoor
    elsif @release == "HD4" and @type == 2
      require_relative 'camera_pipe'
      extend Pipe
    elsif @release == "HX1" and @type == 1
      require_relative 'camera_rockypoint'
      extend Rockypoint
    else
      log_error("Unsupported MTP camera (release=#{@release}, type=#{@type})")
      exit 1
    end

    init()
    @remote_api_version = get_remote_api_version
  end

  def get_remote_api_version
    (log_error("Unknown remote api version");exit ExitCode::UNKNOWN_REMOTE_API_VERSION) if defined?(@remote_api) == nil
    @remote_api_version = @remote_api
  end

  def http_get(url, do_retry=true)
    retries = 3
    retry_interval = 5
    socket_was_reset = false
    log_info("#{Time.now} \t #{url}")

    try = 1
    begin
      @http.request(URI(url))
    rescue Timeout::Error,
    Errno::ECONNRESET,
    Errno::EHOSTUNREACH,
    Errno::EHOSTDOWN,
    Errno::ECONNREFUSED,
    Errno::ENETUNREACH,
    Net::HTTP::Persistent::Error => e
      return nil if do_retry != true
      if try <= retries
        sleep retry_interval
        log_warn("#{Time.now} \t Retrying #{try} \t #{e.message} #{url}")
        try += 1
        retry
      elsif not socket_was_reset
        log_warn("Still can't communicate.  Resetting socket and waiting 60 seconds")
        @http.shutdown
        socket_was_reset = true
        try = 1
        sleep 60
        retry
      else
        log_error("Unable to communicate from host to camera (#{@ip})")
        exit ExitCode::NO_CONNECTION
      end
    rescue StandardError => e
      log_error("OTHER HTTP ERROR => " << e.to_s)
      exit ExitCode::ERROR
    end
  end

  def get_cam_info
    resp = get_device_info
    return parse_device_build(resp)
  end

  def get_device_info
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getdeviceinfo"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def get_object_handles
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getobjecthandles"
    when "WIN"

    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def get_object_info
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getobjectinfo"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def get_storage_info
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getstorageinfo"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def get_storage_id
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getstorageIDs"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def get_num_objects
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getnumobjects"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def lock_card
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/lockcard"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def unlock_card
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/unlockcard"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def sendccl(cmd, value)
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/sendccl?#{cmd.upcase}=#{value}"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

  def getccl(cmd)
    case @os
    when "MAC"
      url = "http://#{@ip}:#{@port}/ETATestDriver/getccl?#{cmd.downcase}"
    when "WIN"
    else
      log_error("Unrecognized OS #{@os}")
      exit ExitCode::MTP_UNRECOGNIZED_OS
    end
    http_get(url)
  end

end
