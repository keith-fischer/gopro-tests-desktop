# sentinel.rb
require 'net/http/persistent'
require 'uri'
#require 'fileutils'
require 'socket'
#require 'timeout'
require 'serialport'
require_relative 'log_utils'

# Functions to be used by Sentinel and SentinelCamera classes
module HostComm
  #######################################################################################
  ### Interface functions (UDP/HTTP/Serial)
  #######################################################################################

  # Sends a packet 'pkt' over UDP to ip:port
  def send_udp(ip, port, pkt)
    sock = UDPSocket.new
    sock.setsockopt(Socket::SOL_SOCKET, Socket::SO_REUSEADDR, true)
    log_verb("%s - Sending packet to %s:%d" \
      %[Time.now.strftime("%H:%M:%S"), @ip, port])
    bytes = sock.send(pkt, 0, ip, port)
    return bytes if bytes > 0
    log_warn("send_udp bytes sent <= 0")
    return false
  end

  # Retrieves a URL via http. Returns resp on success, false on failure
  def http_get(url)
    log_verb("#{Time.now} \t #{url}")
    begin
      @http.open_timeout = 10
      resp = @http.request(URI(url))
    rescue  Timeout::Error,
            Errno::ECONNRESET,
            Errno::EHOSTUNREACH,
            Errno::EHOSTDOWN,
            Errno::ECONNREFUSED,
            Errno::ENETUNREACH,
            Net::HTTP::Persistent::Error => e
      log_warn("HTTP error => #{e.to_s}")
      return false
    rescue StandardError => e
      log_warn("OTHER ERROR => #{e.to_s}")
      return false
    end
    # Now check the response code
    begin
      r = resp.code.to_i
    rescue StandardError => e
      log_warn("Error reading HTTP resp: resp.code=#{resp.code}, error=#{e.to_s}")
      return false
    end
    if r != 200
      log_warn("HTTP status (#{r}) not OK (200)")
      log_warn("Check command validity / pairing code?") if r == 410
      return false
    end
    log_verb("HTTP status OK (200)")
    return resp
  end

  # Sends cmd to the serial port and returns the response
  def send_serial(cmd, limit=1.0)
    resp = ""
    begin
      SerialPort.open(@dev, 115200) { |ser|
        ser.read_timeout = (limit*1000).to_i
        output = []
        log_verb("SERIAL >>> #{cmd}")
        thr = Thread.new {
            ser.write(cmd.chomp + "\r\n")
            output = ser.readlines()
        }
        thr.join(limit*3)
        thr.terminate()
        output.each { |line|
          # Remove the junk/nulls and translate CR to LF
          line.gsub!(/\x1B\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K]/, "")
          line.gsub!(/[\u0000|\n]/, "")
          line.tr!("\r", "\n")
          log_verb("SERIAL <<< #{line}")
          resp << line
        }
      }
    rescue StandardError => e
      log_error("Error trying to send_serial()")
      log_verb(e.to_s)
    end
    return resp
  end
end # end HostComm

# Defines a class to represent Sentinel including both serial and Wi-Fi interfaces
# Specifically, we are interfacing with the TI DM365 encoder which is running
# the Sentinal Daemon.
class Sentinel
  include LogUtils
  include HostComm

  def initialize(ip="192.168.42.1", dev="/dev/ttyUSB0")
    @ip = ip    # Sentinel IP
    @port = 8080
    @dev = dev  # Serial device connected to DM365 console (e.g. /dev/ttyUSB0)
    @t_path = "/opt/gpcli/"   # Path to 't' command
    @http = Net::HTTP::Persistent.new
  end

  #######################################################################################
  ### Serial commands
  #######################################################################################
  # Append the absolute path to the t command location
  def send_t_cmd(cmd); return send_serial("#{@t_path}" + cmd); end
  
  # 't api' commands deal with high-level system modes
  def t_api_video_res(res); send_t_cmd("t api video res #{res}"); end
  def t_api_video_bitrate(br); send_t_cmd("t api video bitrate #{br}"); end
  def t_api_video_start(); send_t_cmd("t api video start"); end
  def t_api_video_stop(); send_t_cmd("t api video stop"); end
  def t_api_setup_set_rtc(time); send_t_cmd("t api setup set_rtc #{time}"); end
  def t_api_setup_get_rtc(); send_t_cmd("t api setup get_rtc"); end
  def t_api_system_shutdown(); send_t_cmd("t api system shutdown"); end
  def t_api_system_batt_level(); send_t_cmd("t api system batt_level"); end
  def t_api_system_fw_update(f); send_t_cmd("t api system fw_update #{f}"); end
  def t_api_metadata_gps_loc(); send_t_cmd("t api metadata gps_loc"); end
  def t_api_buckhorn(msg)l send_t_cmd("t api buckhorn #{msg}"); end

  # 't drv' command test interfaces to platform drivers
  def t_drv_hdmi_get_cable_status(); send_t_cmd("t drv hdmi get_cable_status"); end
  def t_drv_usb_get_cable_status(); send_t_cmd("t drv usb get_cable_status"); end
  def t_drv_rtc_time(y, mo, d, h, mi, s)
    send_t_cmd("t drv rtc time #{y} #{mo} #{d} #{h} #{mi} #{s}"
  end
  def t_drv_battery_get_charge_state(); send_t_cmd("t drv battery get_charge_state"); end
  def t_drv_battery_get_level(); send_t_cmd("t drv battery get_level"); end
  def t_drv_gpio_set(addr, lvl); send_t_cmd("t drv gpio set #{addr} #{lvl}"); end
  def t_drv_i2c_set(addr, lvl); send_t_cmd("t drv i2c set #{addr} #{lvl}"); end
  def t_drv_i2c_get(addr); send_t_cmd("t drv i2c get #{addr}"; end
  def t_drv_wifi_dhcp_reset(); send_t_cmd("t drv wifi dhcp_reset"); end

  # 't sky1x' commands send commands to Sky1X from the DM365
  def t_sky1x_fwupd(f); send_t_cmd("t sky1x fwupd #{f}"); end

  # 't device' provides a CLI to send commands to gpDevice (camera) from the DM365
  def t_device_fwupd(f); send_t_cmd("t device fwupd #{f}"); end
  def t_device_mode_photo; send_t_cmd("t device mode photo"); end
  def t_device_capture_start; send_t_cmd("t device capture start"); end
  def t_devifce_capture_stop; send_t_cmd("t device capture stop"); end

  # 't coyote' provides a CLI to talk to Coyote through Sky1X from DM365
  def t_coyote_fwupd(f); send_t_cmd("t coyote fwupd #{f}"); end

  #######################################################################################
  ### Joystick commands
  #######################################################################################
  # Joystick commands are all unsigned 16-bit integers
  def send_joy_cmd(pitch, roll, thrust, yaw, gimbal_pitch, state)
    pkt = [pitch, roll, thrust, yaw, gimbal_pitch, state].pack('SSSSSS') # uint16_t
    resp = send_udp_pkt(@ip, @joy_port, pkt)
  end

  #######################################################################################
  ### Camera commands
  ### All camera commands are contained within the SentinelCamera object which is 
  ### instantiated by get_sentinel_cam() below.  Error will be thrown for cameras that
  ### fail to be detected, or are not controllable by Sentinel (HD3/HX1)
  #######################################################################################
  def get_sentinel_cam(); return SentinelCamera.new(@ip); end

  

end # end Sentinel

class SentinelCamera
  include HostComm

  # Append http://@ip:@port/gpControl/ to the camera command and http_get it
  def send_cam_cmd(cmd); http_get("http://#{@ip}:#{@port}/gp/gpControl/#{cmd}"); end

  def get_cam_info()
    cam_release, cam_type, cam_build = nil, nil, nil
    resp = http_get("http://#{ip}:#{port}/camera/cv")
    raise StandardError "Unable to get camera info" if resp == false
    cam_release = resp.body[4..6].to_s
    cam_type    = resp.body[8..9].to_i
    if cam_release == "HD4"
      #HD4.02.01.02.00 - cam_build as '01.02.00'
      cam_build = cam_info_resp.body[11..18].to_s
    else
      #HX1.01.00.24 - cam_build as '00.24'
      cam_build   = cam_info_resp.body[11..15].to_s
    end
    log_info("Camera detected -- rel=%s, type=%s, build=%s" \
      %[cam_release, cam_type, cam_build])
    if @release == "HD3" and @type == 1 #US version
      require_relative 'camera_white'
      extend White
    elsif   @release == "HD3" and @type == 9  #europe version
      require_relative 'camera_white'
      extend White
    elsif @release == "HD3" and @type == 2
      require_relative 'camera_silver'
      extend Silver
    elsif @release == "HD3" and @type == 3
      require_relative 'camera_black'
      extend Black
    elsif @release == "HD3" and @type == 10
      require_relative 'camera_silver_plus'
      extend SilverPlus
    elsif @release == "HD3" and @type == 11
      require_relative 'camera_black_plus'
      extend BlackPlus
    elsif @release == "HD4" and @type == 1
      require_relative 'camera_backdoor'
      extend Backdoor
    elsif @release == "HD4" and @type == 2
      require_relative 'camera_pipe'
      extend Pipe
    elsif @release == "HX1" and @type == 1
      require_relative 'camera_rockypoint'
      extend Rockypoint
      extend WifiCommands_RP_api2
    elsif @release == "HD3" and @type == 21
      require_relative 'camera_haleiwa'
      extend Haleiwa
      extend WifiCommands_HLWA_api2
    elsif @release == "HD3" and @type == 22
      require_relative 'camera_himalayas'
      extend Himalayas
      extend WifiCommands_HIMA_api2
    else
      log_error("Unsupported wifi camera (release=#{@release}, type=#{@type})")
      exit 1
    end
  end
end # end SentinelCamera

# Tests start here
if __FILE__ = $0
  $LOGLEVEL = $LL_VERB
end
