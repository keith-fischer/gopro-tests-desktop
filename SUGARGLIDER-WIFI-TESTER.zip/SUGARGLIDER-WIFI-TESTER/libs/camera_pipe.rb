module Pipe
  def init
    @name = "PIPE"
    log_verb("Instantiating #{name} camera")
    @remote_api = 2  #remote smarty api version 2 (ie http://10.5.5.9/gp/gpControl/setting/1/0)
    @data_log_model = 13  # Camera model number for analytics purposes
    @analytics_version = "0.2.1"

    @audio_channels       = 2
    @audio_codec          = "aac"
    @audio_bitrate        = 64    #in kbps per channel.
    @audio_sample_rate    = 48000
    @avc_profile_level    = "HIGH"
    @video_codec          = "h264"
    @colorspace           = "yuvj420p"
    @hilight_tag_limit    = 80

    # Support for changing preview bitrate via BV command
    @chg_prev_br_support  = true
    # Support for changing preview resolution via BV command
    @chg_prev_res_support = true

    @total_video_timelapse_lrv_bitrate = 1.5 #Mbps, (includes video + audio + data)
    @total_lrv_bitrate    = 0.8        #Mbps, (includes video + audio + data)

    #video
    @video_low_light_support    = true
    @video_protune_support      = true
    @video_timelapse_support    = true
    @video_piv_support          = true
    @video_looping_support      = true
    #photo
    @photo_spot_metering_support = true
    @photo_night_support         = true
    @photo_continuous_support    = true
    @photo_protune_support       = true
    #multi_photo
    @multi_photo_spot_metering_support = true
    @multi_photo_nightlapse_support    = true
    @multi_photo_protune_support       = true

    #share video/photo/multi_photo protune value. Split where necessary
    @video_protune_modes          = ["VIDEO"]
    @photo_protune_modes          = ["PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"]
    @multi_protune_modes          = ["BURST", "TIMELAPSE", "NIGHTLAPSE"]

    @protune_white_balance_values = ["AUTO", "3000K", "5500K", "6500K", "RAW",
                                     "4000K", "4800K", "6000K"]
    @protune_color_values         = ["STANDARD", "NEUTRAL"]
    @protune_sharpness_values     = ["LOW", "MED", "HIGH"]
    @protune_exposure_values      = ["-2.0", "-1.5", "-1.0", "-0.5",
                                     "0", "0.5", "1.0", "1.5", "2.0"]
    @protune_shutter_speeds       = ["AUTO", "1/12.5", "1/15", "1/24", "1/25", "1/30",
                                     "1/48", "1/50", "1/60", "1/80", "1/90", "1/96",
                                     "1/100", "1/120", "1/160", "1/180", "1/192", "1/200",
                                     "1/240", "1/320", "1/360", "1/400", "1/480", "1/960"]
    @photo_protune_iso_values     = ["100", "200", "400", "800"]
    @photo_protune_iso_min_values = ["100", "200", "400", "800"]
    @video_protune_iso_values     = ["6400", "1600", "400", "3200", "800"]
    @video_protune_iso_modes          = ["MAX", "LOCK"]

    @photo_shutter_exposure  = ["AUTO", "2", "5", "10", "15", "20", "30"]
    @multi_shutter_exposure  = ["AUTO", "2", "5", "10", "15", "20", "30"]
    @video_piv_intervals     = ["5", "10", "30", "60"]

    # preview stream testing flag
    @test_preview_stream     = true

    #photo's preview stream
    @photo_ts = {
      :lrv_aspect_ratio => "4:3",
      :lrv_width        => 320,
      :lrv_height       => 240
    }

    @capabilities = {
      :has_camera_roll      => true,
      :has_ota              => true,  #over the air firmware update
      :has_ltp              => true,
      :has_3D               => true,
      :has_ccl              => true,   #camera control library
    }

    @defaults = {
      :setup_video_format     => "NTSC",
      :video_submode          => "VIDEO",
      :video_timelapse        => "0.5",
      :video_looping          => "5",
      :video_piv              => "5",
      :video_resolution       => "1080_SUPER",
      :video_fps              => "30",
      :video_fov              => "W",
      :video_low_light        => "ON",
      :video_spot_metering    => "OFF",
      :video_pt               => "OFF",
      :video_pt_wb            => "AUTO",
      :video_pt_color         => "STANDARD",
      :video_pt_ev            => "0",
      :video_pt_sharp         => "HIGH",
      :video_pt_iso           => "1600",
      :photo_submode          => "PHOTO",
      :photo_resolution       => "12WIDE",
      :photo_continuous       => "3",
      :photo_shutter_ev       => "AUTO",
      :photo_pt               => "OFF",
      :photo_pt_wb            => "AUTO",
      :photo_pt_color         => "STANDARD",
      :photo_pt_ev            => "0",
      :photo_pt_sharp         => "HIGH",
      :photo_pt_iso           => "800",
      :photo_spot_metering    => "OFF",
      :multi_photo_submode    => "BURST",
      :multi_photo_resolution => "12WIDE",
      :multi_photo_burst      => "30_1",
      :multi_photo_timelapse  => "0.5",
      :multi_photo_shutter_ev => "AUTO",
      :multi_photo_nightlapse => "CONTINUOUS",
      :multi_photo_pt         => "OFF",
      :multi_photo_pt_wb      => "AUTO",
      :multi_photo_pt_color   => "STANDARD",
      :multi_photo_pt_ev      => "0",
      :multi_photo_pt_sharp   => "HIGH",
      :multi_photo_pt_iso     => "800",
      :multi_photo_spot_meter => "OFF",
      :setup_default_mode     => "VIDEO",
      :setup_orientation      => "UP",
      :setup_led              => "4",
      :setup_beep             => "100",
      :setup_osd              => "ON",
      :setup_quick_capture    => "OFF",
      :setup_auto_off         => "0",     #NEVER
      :setup_lcd_brightness   => "HIGH",
      :setup_lcd_lock         => "ON",
      :setup_lcd_auto_off     => "60",
      #      :setup_lcd_display      => "ON"
      #      :setup_stream_gop_size
      #      :setup_stream_idr_interval
      #      :setup_stream_bit_rate
      #      :setup_stream_window_size
    }

    #Initial camera setup before executing any tests
    @setup = {
      :setup_led              => "4",
      :setup_beep             => "100",
    }

    # Commands that don't have prerequisites
    # Wifi commands to test
    @cmds = [
      :video_dft_submode,
      :photo_dft_submode,
      :multi_photo_dft_submode,
      :photo_shutter_ev,
      #      :multi_photo_shutter_exposure,   #requires special needs
      :setup_beep,
      :setup_default_mode,
      :setup_led,
      :video_spot_metering,
      :photo_spot_metering,
      :multi_photo_spot_meter,
      :setup_orientation,
      :setup_video_format,
      :setup_osd,
      :setup_quick_capture,
      :setup_auto_off,      #NEVER
      :setup_lcd_brightness,
      :setup_lcd_lock,
      #      :setup_lcd_auto_off,
      :setup_lcd_display,
      #      :setup_stream_gop_size,
      #      :setup_stream_idr_interval,
      #      :setup_stream_bit_rate,
      #      :setup_stream_window_size,
    ]

    @looping_chapter_len = {
      "5"     => 1,
      "20"    => 5,
      "60"    => 5,
      "120"   => 5,
      "MAX"   => 5,
    }

    # File size limit for videos after which it is split
    @chapter_size = 4<<30 # 4 GB

    @video_protune_vars = {
      :video_pt_color => true,
      :video_pt_iso   => true,
      :video_pt_sharp => true,
      :video_pt_ev    => true,
      :video_pt_wb    => true
    }

    @photo_protune_vars = {
      :photo_pt_color  => true,
      :photo_pt_iso    => true,
      :photo_pt_sharp  => true,
      :photo_pt_ev     => true,
      :photo_pt_wb     => true
    }

    @multi_photo_protune_vars = {
      :multi_photo_pt_color   => true,
      :multi_photo_pt_iso     => true,
      :multi_photo_pt_sharp   => true,
      :multi_photo_pt_ev      => true,
      :multi_photo_pt_wb      => true
    }

    # Data structure for preview specifications
    # Basically come in 2 flavors.  Fullscreen and Widescreen
    # Fullscreen is 4:3 and widescreen is anything >4:3
    @preview = {
      # QVGA, WQVGA.  bitrate in bps
      "LOW" => {
      :bitrate => {
      :LOW  => 311040,
      :MED  => 500000,
      :HIGH => 750000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 240,
      :width_fs         => 320, # QVGA
      :width_ws         => 432, # WQVGA
      },
      # VGA, QVGA.  bitrate in bps
      "HIGH" => {
      :bitrate => {
      :LOW  => 1221120,
      :MED  => 2000000,
      :HIGH => 3000000,
      },
      :frame_rate_ntsc  => 29.97,
      :frame_rate_pal   => 25,
      :height           => 480,
      :width_fs         => 640, # QVGA
      :width_ws         => 848, # WQVGA
      },
    }

    # Resolution names must match wifi 'res' keys
    # FPS/FOV values must match wifi keys as well.
    # certain resolution is available for certain mode (ie video single, video time lapse)
    # :video = single video
    # :piv => photo-in-video
    # :looping = video looping
    @video_capture_modes = {
      "4K"  =>  {
      :width  => 3840,
      :height => 2160,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 4K
      "4K_SUPER"  =>  {
      :width  => 3840, # TODO: Double check
      :height => 2160,
      :aspect_ratio => "16:9", # TODO: Double check
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 4K_SUPER
      "2.7K"  =>  {
      :width  => 2704,
      :height => 1520,
      :aspect_ratio => "169:95",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "25"  => {
      :fov        => ["W", "M"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "48"  => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 47.95,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "50"  => {
      :fov        => ["W", "M"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W", "M"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :piv        => false
      },
      } # end fps
      }, # end 2.7K
      "2.7K_SUPER" => {
      :width  => 2704,
      :height => 1520,
      :aspect_ratio => "169:95",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps  => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      }
      }, # end 2.7K_SUPER
      "2.7K_FS" => {
      :width  => 2704,
      :height => 2028,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :fps  => {
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :lrv_timecode => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      }
      }, # end 2.7K_FS
      "1440"  =>  {
      :width  => 1920,
      :height => 1440,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :fps    => {
      "24"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :looping    => true,
      :piv        => true
      },
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "48"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 47.95,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 45,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "80"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 80,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 1440
      "1080_SUPER"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "25"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "30"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      },
      "48"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 47.95,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "80"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 80,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 1080_SUPER
      "1080"  =>  {
      :width  => 1920,
      :height => 1080,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "24"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 23.98,
      :low_light  => false,
      :looping    => true,
      :jello_slayer => true,
      :piv        => true
      },
      "25"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => true
      },
      "30"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => true
      },
      "48"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 23.98,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 47.95,
      :low_light  => true,
      :jello_slayer => true,
      :piv        => false,
      :looping    => true,
      },
      "50"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :lrv_timecode => true,
      :pt_lrv     => true,
      :pt_thm     => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "90"  => {
      :fov        => ["W", "N"],
      :fov_lrv    => ["N"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => 30,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => false,
      :frame_rate => 90,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      "120"  => {
      :fov        => ["W", "N"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 119.88,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 1080
      "960"  =>  {
      :width  => 1280,
      :height => 960,
      :aspect_ratio => "4:3",
      :protune => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :fps    => {
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "120"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 119.88,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 960
      "720_SUPER"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "50"  => {
      :fov        => ["W"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "60"  => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :jello_slayer => true,
      :looping    => true,
      :piv        => false,
      },
      "120" => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 119.88,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      },
      } # end fps
      }, # end 720_SUPER
      "720"  =>  {
      :width  => 1280,
      :height => 720,
      :aspect_ratio => "16:9",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "25"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 20,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 25,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => true
      },
      "30"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 20,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 29.97,
      :low_light  => false,
      :jello_slayer => true,
      :looping    => true,
      :piv        => true
      },
      "50"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => false,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 25,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 50,
      :low_light  => true,
      :jello_slayer => true,
      :jello_slayer_fov => ["N"],
      :looping    => true,
      :piv        => true
      },
      "60"  => {
      :fov        => ["W", "M", "N"],
      :ntsc       => true,
      :pal        => false,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => 29.97,
      :pt_lrv     => true,
      :pt_thm     => true,
      :lrv_timecode => true,
      :timecode   => true,
      :frame_rate => 59.94,
      :low_light  => true,
      :jello_slayer => true,
      :jello_slayer_fov => ["N"],
      :piv_fov    => ["M", "N"],
      :looping    => true,
      :piv        => true
      },
      "120" => {
      :fov        => ["W", "M", "N"],
      #      :fov_lrv    => ["M"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 45,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 119.88,
      :low_light  => true,
      :piv        => false,
      :looping    => true,
      },
      "240" => {
      :fov        => ["N"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 60,
      :pt_bitrate => 60,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 239.76,
      :low_light  => true,
      :looping    => true,
      :piv        => false,
      }
      } # end fps
      }, # end 720
      "WVGA"  =>  {
      :width  => 848,
      :height => 480,
      :aspect_ratio => "53:30",
      :protune => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :fps    => {
      "240" => {
      :fov        => ["W"],
      :ntsc       => true,
      :pal        => true,
      :bitrate    => 30,
      :pt_bitrate => 30,
      :thm        => true,
      :lrv_fps    => false,
      :pt_lrv     => false,
      :pt_thm     => true,
      :timecode   => false,
      :frame_rate => 239.76,
      :low_light  => false,
      :looping    => true,
      :piv        => false,
      }
      } # end fps
      } # end WVGA
    } # end @video_capture_modes

    @video_timelapse_capture_modes = {
      "4K"  =>  {
      :width  => 3840,
      :height => 2160,
      :aspect_ratio => "16:9",
      :ntsc_fps => 29.97,
      :pal_fps => 25,
      :bitrate => 60,   #Mbps
      :timecode   => true,
      :thm => true,
      :lrv_width  => 432,
      :lrv_height => 240,
      :lrv_aspect_ratio => "9:5",
      :lrv_ntsc_fps => 29.97,
      :lrv_pal_fps => 25,
      :lrv_timecode => true,
      },
      "2.7K_FS" => {
      :width  => 2704,
      :height => 2028,
      :aspect_ratio => "4:3",
      :ntsc_fps => 29.97,
      :pal_fps => 25,
      :bitrate => 45,
      :timecode   => true,
      :thm => true,
      :lrv_width  => 320,
      :lrv_height => 240,
      :lrv_aspect_ratio => "4:3",
      :lrv_ntsc_fps => 29.97,
      :lrv_pal_fps => 25,
      :lrv_timecode => true,
      }
    }

    # Photo Modes
    @photo_modes = {
      "5MED" => {
      :width        => 2560,
      :height       => 1920,
      :min_size     => 1500, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :sps => {
      "3"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      "10_3"  => { :min_quality  => 98.0 },
      "30_1"  => { :min_quality  => 98.0 },
      "30_2"  => { :min_quality  => 98.0 },
      "30_3"  => { :min_quality  => 98.0 },
      "30_6"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      :night_lapse => {
      "4"     => { :min_quality  => 98.0 },
      "5"     => { :min_quality  => 98.0 },
      "10"    => { :min_quality  => 98.0 },
      "15"    => { :min_quality  => 98.0 },
      "20"    => { :min_quality  => 98.0 },
      "30"    => { :min_quality  => 98.0 },
      "60"    => { :min_quality  => 98.0 },
      "120"   => { :min_quality  => 98.0 },
      "300"   => { :min_quality  => 98.0 },
      "1800"  => { :min_quality  => 98.0 },
      "3600"  => { :min_quality  => 98.0 },
      "CONTINUOUS"  => { :min_quality  => 98.0 }
      }, # end night_lapse modes
      }, # end 5MED
      "7MED" => {
      :width        => 3000,
      :height       => 2250,
      :min_size     => 2100, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :sps => {
      "3"   => { :min_quality  => 95.0 },
      "5"   => { :min_quality  => 95.0 },
      "10"  => { :min_quality  => 95.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      "10_3"  => { :min_quality  => 98.0 },
      "30_1"  => { :min_quality  => 98.0 },
      "30_2"  => { :min_quality  => 98.0 },
      "30_3"  => { :min_quality  => 98.0 },
      "30_6"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      :night_lapse => {
      "4"     => { :min_quality  => 98.0 },
      "5"     => { :min_quality  => 98.0 },
      "10"    => { :min_quality  => 98.0 },
      "15"    => { :min_quality  => 98.0 },
      "20"    => { :min_quality  => 98.0 },
      "30"    => { :min_quality  => 98.0 },
      "60"    => { :min_quality  => 98.0 },
      "120"   => { :min_quality  => 98.0 },
      "300"   => { :min_quality  => 98.0 },
      "1800"  => { :min_quality  => 98.0 },
      "3600"  => { :min_quality  => 98.0 },
      "CONTINUOUS"  => { :min_quality  => 98.0 }
      }, # end night_lapse modes
      }, # end 7MED
      "7WIDE" => {
      :width        => 3000,
      :height       => 2250,
      :min_size     => 2100, # KB
      :min_psnr     => 35.0,
      :min_quality  => 98.0,
      :sps => {
      "3"   => { :min_quality  => 95.0 },
      "5"   => { :min_quality  => 95.0 },
      "10"  => { :min_quality  => 95.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 98.0 },
      "5_1"   => { :min_quality  => 98.0 },
      "10_1"  => { :min_quality  => 98.0 },
      "10_2"  => { :min_quality  => 98.0 },
      "10_3"  => { :min_quality  => 98.0 },
      "30_1"  => { :min_quality  => 98.0 },
      "30_2"  => { :min_quality  => 98.0 },
      "30_3"  => { :min_quality  => 98.0 },
      "30_6"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 93.0 },
      "1"   => { :min_quality  => 93.0 },
      "2"   => { :min_quality  => 98.0 },
      "5"   => { :min_quality  => 98.0 },
      "10"  => { :min_quality  => 98.0 },
      "30"  => { :min_quality  => 98.0 },
      "60"  => { :min_quality  => 98.0 },
      }, # end time_lapse modes
      :night_lapse => {
      "4"     => { :min_quality  => 98.0 },
      "5"     => { :min_quality  => 98.0 },
      "10"    => { :min_quality  => 98.0 },
      "15"    => { :min_quality  => 98.0 },
      "20"    => { :min_quality  => 98.0 },
      "30"    => { :min_quality  => 98.0 },
      "60"    => { :min_quality  => 98.0 },
      "120"   => { :min_quality  => 98.0 },
      "300"   => { :min_quality  => 98.0 },
      "1800"  => { :min_quality  => 98.0 },
      "3600"  => { :min_quality  => 98.0 },
      "CONTINUOUS"  => { :min_quality  => 98.0 }
      }, # end night_lapse modes
      }, # end 7WIDE
      "12WIDE" => {
      :width        => 4000,
      :height       => 3000,
      :min_size     => 3600, # KB
      :min_psnr     => 35,
      :min_quality  => 98.0,
      :sps => {
      "3"   => { :min_quality  => 94.0 },
      "5"   => { :min_quality  => 94.0 },
      "10"  => { :min_quality  => 94.0 },
      }, # end sps
      :burst => {
      "3_1"   => { :min_quality  => 95.0 },
      "5_1"   => { :min_quality  => 95.0 },
      "10_1"  => { :min_quality  => 95.0 },
      "10_2"  => { :min_quality  => 95.0 },
      "10_3"  => { :min_quality  => 95.0 },
      "30_1"  => { :min_quality  => 95.0 },
      "30_2"  => { :min_quality  => 95.0 },
      "30_3"  => { :min_quality  => 95.0 },
      "30_6"  => { :min_quality  => 98.0 },
      }, # end burst
      :time_lapse => {
      "0.5" => { :min_quality  => 95.0 },
      "1"   => { :min_quality  => 95.0 },
      "2"   => { :min_quality  => 95.0 },
      "5"   => { :min_quality  => 95.0 },
      "10"  => { :min_quality  => 95.0 },
      "30"  => { :min_quality  => 95.0 },
      "60"  => { :min_quality  => 95.0 },
      }, # end time_lapse mode
      :night_lapse => {
      "4"     => { :min_quality  => 98.0 },
      "5"     => { :min_quality  => 98.0 },
      "10"    => { :min_quality  => 98.0 },
      "15"    => { :min_quality  => 98.0 },
      "20"    => { :min_quality  => 98.0 },
      "30"    => { :min_quality  => 98.0 },
      "60"    => { :min_quality  => 98.0 },
      "120"   => { :min_quality  => 98.0 },
      "300"   => { :min_quality  => 98.0 },
      "1800"  => { :min_quality  => 98.0 },
      "3600"  => { :min_quality  => 98.0 },
      "CONTINUOUS"  => { :min_quality  => 98.0 }
      }, # end night_lapse modes
      }, # end 12WIDE
    } # end PHOTO mode

    @screens = {
      :wireless_settings => [ \
      "0000000000000000000f000000000000000f1fffffffffffff8f3fffffffffffffcf3" + \
      "fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3fffff" + \
      "ffffffffcf3fffffffffffffcf3fffffffffffffcf3fffffffffffffcf3ffffffffff" + \
      "fffcf3f1c6eeeec618fcf3eebaeeedbaf77cf"]
    }

  end # end init
end # end Pipe
