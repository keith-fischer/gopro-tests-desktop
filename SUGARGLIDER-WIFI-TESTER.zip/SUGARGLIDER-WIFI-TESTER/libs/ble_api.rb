#!/usr/bin/env ruby

#######################################################
# ble_api.rb
#
#
#
require 'net/http/persistent'
require 'json'
require 'uri'
require 'fileutils'
require 'socket'
require 'timeout'

require_relative 'camera'
require_relative 'host_utils'
require_relative 'exitcodes'
require_relative 'log_utils'
require_relative 'metadata'
require_relative 'wifi_commands'
require_relative 'wifi_camera'

# class ble_api < wifi_camera
class BLEdevice < Camera
  attr_accessor :ip, :port, :http_port, :pairing_code, :autoconnect, :serialno, :usboutlet, :battoutlet, :pushy,  # All needed by hostagent.rb or testHandler.rb
  :wait_after_cmd, :serial_iface, :system_address, :save_ts_file, :save_ts_filename, :squelch_status, :debug, :wifi_cam, :wf

  attr_reader :screens, :release, :type, :addr, :build, :name, :num_sensors, :sensor_list,
  :ssid, :mac, :wifi_version

  include WifiCommands
  include LogUtils

  def initialize(ip, pc, ble=nil, cam_serial_log=nil, log_path=nil)
    puts "ble_api::initialize" if @debug
    super()
    @ip                   = ip  # Keeping 'ip' because it is used all over the code. Camera's access point

    @wf = @wifi = @wifi_cam = get_wifi_camera("10.5.5.9", "goprohero1")
    @ssid, @mac, @wifi_version  = @wf.get_bacpac_info()
    @release, @type, @build     = @wf.get_cam_info()
    @debug = false
    @sensor_list = Array.new(10)
    # @dev        = dev                   # e.g. /dev/ttyACM0
    # @addr       = @dev.split("/")[-1]   # e.g. ttyACM0
    @addr         = ip  # Needed for log path directory naming
    @autoconnect  = false  # Needed by testHandler.rb:TestRunner
    @usboutlet    = nil  # Needed by testHandler.rb:TestRunner
    @battoutlet   = nil  # Needed by testHandler.rb:TestRunner
    @pushy        = nil  # Needed by testHandler.rb:TestRunner
    @serial_iface    = cam_serial_log # e.g. /dev/ttyUSB0 Non-null if also has a serial interface (for camera&linux logs)

    @autoconnect_enabled=0
    @interfaces << :ble   # IMPORTANT: don't remove this. hostagent.rb depends on this

    start_serial_logs()

    # Capture console logs to /tmp
    if @serial_iface != nil
      if @linux_iface == nil # Just assume it is serial_iface + 1
        n1 = @serial_iface[-5..-1].scan(/\d/)[0]
        n2 = n1.to_i + 1
        @linux_iface = @serial_iface[0...@serial_iface.index(n1)] + n2.to_s
        log_info("Linux serial port not specified.  Trying #{@linux_iface}")
      end

      # Fatally exit if these fail
      if init_amba_serial_log("/tmp", @addr) == false
        exit ExitCode.to_s(ExitCode::ERROR)
      elsif spawn_amba_logging_thread(@serial_iface) == false
        exit ExitCode.to_s(ExitCode::ERROR)
      end

      # Just warn if these fail
      if init_linux_serial_log("/tmp", @addr) == false
        log_warn("Error initializing Linux log")
      elsif spawn_linux_logging_thread(@linux_iface) == false
        log_warn("Error spawning Linux logging thread")
      end
    end

    if @release == "HD4" and @type == 1
      require_relative 'camera_backdoor'
      extend Backdoor
    elsif @release == "HD4" and @type == 2
      require_relative 'camera_pipe'
      extend Pipe
    elsif @release == "HD5" and @type == 1
      require_relative 'camera_squirrels'
      extend Squirrels
    elsif @release == "HD5" and @type == 2
      require_relative 'camera_streaky'
      extend Streaky
    elsif @release == "SUPERBANK" and @type == 1 # This probably isn't right.
      require_relative 'camera_superbank'
      extend Superbank
    else
      log_error("Unsupported wifi camera (release=#{@release}, type=#{@type})")
      exit 1
    end

    init()
    @host       = Host.new()
=begin
    log_conf("name, #{@name}")
    log_info("Camera Info (some may be missing)")
    log_conf("serialno, #{@serialno}")
    log_conf("ssid, #{@ssid}")
    log_conf("mac, #{@mac}")
    log_conf("wifi_ver, #{@wifi_version}")
    log_conf("release, #{@release}")
    log_conf("type, #{@type}")
    log_conf("build, #{@build}")
=end
  end

  def start_serial_logs()
    # Capture console logs to log_path
    if @serial_iface != nil
      log_path = "/tmp/test.log" if log_path == nil
      # @linux_iface: Just assume it is serial_iface + 1
      n1 = @serial_iface[-5..-1].scan(/\d/)[0]
      n2 = n1.to_i + 1
      @linux_iface = @serial_iface[0...@serial_iface.index(n1)] + n2.to_s
      log_info("Linux serial port not specified.  Trying #{@linux_iface}")

      # Fatally exit if these fail
      if init_amba_serial_log(File.dirname(log_path), File.basename(log_path)) == false
        exit ExitCode.to_s(ExitCode::ERROR)
      elsif spawn_amba_logging_thread(@serial_iface) == false
        exit ExitCode.to_s(ExitCode::ERROR)
      end

      # Just warn if these fail
      if init_linux_serial_log(File.dirname(log_path), File.basename(log_path)) == false
        log_warn("Error initializing Linux log")
      elsif spawn_linux_logging_thread(@linux_iface) == false
        log_warn("Error spawning Linux logging thread")
      end
    end
  end


  # Filters out control-characters that JSON parser can't handle (ie - SOH (0x01) Control-A)
  # Returns a parsed (indexable) JSON scan list
  #
  # Input: Array
  def filter_n_hash(list)
    len = list.length
    sohs = 0
    clean_list = Array.new(len)
    if len <= 0
      puts "filter_n_hash ERROR len=#{len}" if @debug
      errorHash = {}
      return errorHash
    end
    (0..len-1).each { |n|
      if list!=nil and !list.empty? and !list[n].empty? and list[n] != nil
        v =  list[n].ord
        if (( v < 32) || ( v > 126))
          sohs += 1
          puts "SOH #{sohs} FOUND @n=#{n}!" if @debug
          n = n+1
        else
          clean_list.push(list[n])
        end
      else
        log_error("filter_n_hash unexpected list ERROR")
      end
    }
    clean_str = clean_list.join
    if @debug
      puts ""
      puts "clean_str:"
      puts clean_str
      puts ""
    end
    json_scanlist = JSON.parse(clean_str)
    return json_scanlist
  end

  # Returns a list of GPMF sensors
  #
  def get_sensor_list()
    
    puts "get_sensor_list()" if @debug

    sensor_list = Array.new
    num_sensors = 0
    puts "@wf.ble_scan_list_" if @debug
    sl = @wf.ble_scan_list()
    puts "sl=#{sl}" if @debug
    parsed = filter_n_hash(sl)
    puts "parsed=#{parsed}" if @debug

    if parsed.has_key?("device_array")
      parsed["device_array"].each do |d|
        puts d["address"]  if @debug
        if d["name"].empty?
          puts "\tNIL name" if @debug
        else
          puts "\tname=#{d["name"]}" if @debug
        end
        # {"address":"78a5041977d0","address_type":0,"rssi":-89,"name":"Sensor-D0","profile_uuid16":["0304","0506"]}
        if d.has_key?("profile_uuid16")
          puts "\tuuid16 profile: #{d["profile_uuid16"]}" if @debug
          uuid16 =  d["profile_uuid16"]
          puts "uuid16[0]=#{uuid16[0]}" if @debug
          # If and only if uuid16[1] exists, check for uuid "0506" and mark this as a GoPro UUID sensor
          if uuid16[1] and uuid16[0]=="0304"
            puts "uuid16[1]=#{uuid16[1]}"  if @debug
            if uuid16[1]=="0506"
              puts "GPMF sensor found" if @debug
              num_sensors += 1
              sensor_list.push(d)
            end
          end
        end
      end
    end
    if num_sensors > 0 and @debug
      puts ""
      puts "SENSORS FOUND: #{num_sensors}"
      puts sensor_list
      puts ""
    end

    @sensor_list = sensor_list
    @num_sensors = num_sensors
    return @num_sensors, @sensor_list

  end # get_sensor_list

  def ble_get_address_n_type(name)
    address=""
    type=""
    @sensor_list.each { |s|
      if s["name"].to_s == name.to_s
        puts "FOUND name:#{s["name"]} address:#{s["address"]} type:#{s["address_type"]}" if @debug
        address = s["address"]
        type = s["address_type"]
      end
    }
    return address, type
  end

  def scan_start()
    err = 0
    msg = ""
    reply = @wf.ble_scan(1)
    parsed = filter_n_hash(reply)
    return parsed,err,msg
  end

  def scan_stop()
    err = 0
    msg = ""
    reply = @wf.ble_scan(0)
    parsed = filter_n_hash(reply)
    return parsed,err,msg
  end


  # BLE state:
  # his indicates whether BLE pairing phase state can be entered. It should be called before attempting to perform any BLE operations.
  # A HTTP-200 response indicates that pairing_phase command can be executed. Any other error indicates pairing_phase command should 
  # not be used and pairing is currently unavailable. See the comments for pairing_phase command for additional info on checking that pairing_phase 
  # was successfully entered.
  #
  # Possible responses:
  #  {} - OK
  #
  # {
  # "version": "3.00",
  # "path_info": "/command/ble/pairing_available",
  # "query_string": "",
  # "error_code":-1,
  # "error_msg": "/command/ble/pairing_available",
  # "function": "main",
  # "line": 149
  # }
  #
  def get_pairing_state()
    state_ok = true
    err = 0
    msg = ""
    state = @wf.ble_state()
    puts "state=#{state}" if @debug
    if !state.empty?
      state_ok = false
      if parsed.has_key?("error_code")
        puts "error_code: #{state["error_code"]}" if @debug
        err = state["error_code"].to_i
        msg = state["error_msg"].to_s
      end
    end
    return state_ok, err, msg
  end

  def enter_pairing_phase()
    err = 0
    msg = ""
    reply = @wf.ble_pairing_phase("enter")
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end

  def exit_pairing_phase()
    err = 0
    msg = ""
    reply = @wf.ble_pairing_phase("exit")
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end


  # {"auto_connect":1}
  #
  # {
  # "version": "3.00",
  # "path_info": "/command/ble/configure",
  # "query_string": "auto_connect=1",
  # "error_code":-1,
  # "error_msg": "/command/ble/configure",
  # "function": "main",
  # "line": 149
  # }
  def configure_get()
    puts "configure_get()" if @debug
    err = 0
    msg = ""
    reply=@wf.ble_get_autoconnect()
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed["auto_connect"] != nil
        @autoconnect_enabled = parsed["auto_connect"].to_i
      elsif parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return @autoconnect_enabled, err, msg
  end

  def autoconnect_all(enable_disable)
    puts "autoconnect_all(#{enable_disable})" if @debug
    err = 0
    msg = ""
    reply=@wf.ble_set_autoconnect(enable_disable)
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        puts "error_code: #{parsed["error_code"]}"  if @debug
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    else
      @autoconnect_enabled = enable_disable
    end
    return @autoconnect_enabled, err, msg
  end

  # Overall pairing status (not device-specific)
  def get_pairing_status()
    err = 0
    msg = ""
    reply = @wf.ble_pair_status()
    parsed = filter_n_hash(reply)
    pairing_name="N/A"
    puts "get_pairing_status(): parsed=#{parsed}" if @debug
    if  not parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end

      if (err==0) 
        if parsed.has_key?("pairing_status")
          pairing_sts = parsed["pairing_status"].to_i
          case pairing_sts
          when 0
            pairing_name = "IDLE"
          when 1
            pairing_name = "CONNECTING"
          when 2
            pairing_name = "CONNECTED"
          when 3
            pairing_name = "PAIRED"
          else
            pairing_name = "ERROR UNKNOWN #{pairing_sts}"
          end
        else
          err=-1
        end # if err==0
      end
    end
    return pairing_name, err, msg
  end

  def pair_start(address, address_type)
    err = 0
    msg = ""
    reply = @wf.ble_pair_start(address, type)
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end

  def pair_cancel(address, address_type)
    err = 0
    msg = ""
    reply = @wf.ble_pair_cancel(address, type)
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end

  def whitelist_get(index=-1)
    err = 0
    msg = ""
    reply = @wf.ble_whitelist_list(index)
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end

  def whitelist_config_remove(device)
    err = 0
    msg = ""
    reply = @wf.ble_whitelist_remove(address)
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end

  def whitelist_config_autoconnect(address, enable_disable)
    err = 0
    msg = ""
    reply = @wf.ble_whitelist_autoconnect(address, enable_disable)
    parsed = filter_n_hash(reply)
    if !parsed.empty?
      if parsed.has_key?("error_code")
        err = parsed["error_code"].to_i
        msg = parsed["error_msg"].to_s
      end
    end
    return parsed, err, msg
  end

  def get_whitelist_connections()
    wl,e,m = whitelist_get()
    num_sensors_connected=0
    if e==0
      if not wl.has_key?("device_array")
        log_debug("ERROR Whitelist does not contain KEY device_array")
        log_debug("wl=#{wl}")
      else
        wl["device_array"].each_with_index { |sens,i|
          sn=i+1
          log_debug("sensor#{sn}")
          sens.each { |k,v|
            log_debug("\t##{j} #{v}")
          }
          if sens.has_key?("connected") and sens["connected"].to_i == 1
            log_verb("sensor#{sn} is CONNECTED")
            num_sensors_connected += 1
          else
            log_verb("sensor#{sn} is NOT CONNECTED")
          end
        }
      end
    else
      log_error("Whitelist GET failed")
      return 0
    end
    return num_sensors_connected
  end


  # Whitelist example
  # {
  #    "index" : 0,
  #    "index_count" : 2,
  #    "device_array" : [
  #       {
  #          "mitm_paired" : 0,
  #          "connected" : 1,
  #          "name" : "Sensor-CC",
  #          "address" : "78a504196dcc",
  #          "auto_connect" : 1
  #       },
  #       {
  #          "mitm_paired" : 0,
  #          "connected" : 1,
  #          "name" : "Sensor-D0",
  #          "address" : "78a5041977d0",
  #          "auto_connect" : 1
  #       },
  #    ],
  #    "list_id" : 2,
  #    "total" : 2
  # }
  #
  def is_connected(address)
    puts "IS_CONNECTED(#{address})?" if @debug
    wl,e,m = whitelist_get()
    found=false
    if e==0
        if not wl.has_key?("device_array")
          e=-1
          m="ERROR Whitelist does not contain KEY device_array"
        else
          wl["device_array"].each_with_index { |sens,i|
            sn=i+1
            sens_addr = sens["address"]  
            puts "sens[address]=#{sens_addr} address=#{address}" if @debug
            if sens.has_key?("address") and sens["address"] == address
              if sens.has_key?("connected") and sens["connected"].to_i == 1
                found=true
              else
                break
              end
            end
          }
        end
    else
      log_warn("Whitelist GET failed")
    end
    return found
  end

  def get_connected_devices()
    wl,e,m = whitelist_get()
    num_connected=0
    wl_connected={}
    if e==0
        if not wl.has_key?("device_array")
          e=-1
          m="ERROR Whitelist does not contain KEY device_array"
        else
          wl["device_array"].each_with_index { |sens,i|
            sn=i+1
            if sens.has_key?("connected") and sens["connected"].to_i == 1
              num_connected += 1
              wl_connected[num_connected] = sens
            end
          }
        end
    else
      log_warn("Whitelist GET failed")
    end
    return num_connected, wl_connected
  end

  #### camera OVERRIDES ####
  # Override Camera.delete_all_media()
  def delete_all_media(force=false)
    @wf.delete_all_media(force)
  end

  def set_video_protune(p, force=false)
    @wf.set_video_protune(p, force)
  end

  def set_video(vm, r, fs, fv)
    @wf.set_video(vm, r, fs, fv)
  end

  def start_capture()
    @wf.start_capture()
  end

  def stop_capture()
    @wf.stop_capture()
  end

  def download_last_media(to_dir)
    @wf.download_last_media(to_dir)
  end

end # class ble_api

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  # c = get_wifi_camera("10.5.5.9", "goprohero1")
  c = get_ble_device("10.5.5.9", "goprohero1")
  # c.ble_scan_start()
  #c.ble_state()
  # url = "#{c.make_gpcontrol_url}/command/ble/pair/status"
  # puts "url=#{url}"
  # c.http_get(url)
  # json_wl = c.ble_whitelist_list()

  #num_sensors, sensor_list = c.get_sensor_list()
  #puts "num_sensors=#{num_sensors}"
  #puts "sensor_list=#{sensor_list}"

  # state, err, msg = c.get_pairing_state()
  # puts "state=#{state}"
  # puts "err=#{err}"
  # puts "msg=#{msg}"
  # num_sensors, sensor_list = c.get_sensor_list()
  # addr, type = c.ble_get_address_n_type("Sensor-CC")
  # puts "addr=#{addr} type=#{type}"

  c.debug=true
  c.debug=false
=begin
  s,e,m = c.scan_start()
  puts "scan_start=#{s} e=#{e} m=#{m}"

  puts "Let scan for 5s..."
  sleep(5)
  num_sensors, sensor_list = c.get_sensor_list()
  puts "num_sensors=#{num_sensors}"
  puts "sensor_list=#{sensor_list}"
  s,e,m = c.scan_stop()
  puts "scan_stop=#{s} e=#{e} m=#{m}"
  sleep(2)

  puts ""
  s,e,m = c.autoconnect_all(0)
  puts "noautoconn=#{s} e=#{e} m=#{m}"
  s,e,m = c.configure_get()
  puts "autoconn=#{s} e=#{e} m=#{m}"

  puts ""
  s,e,m = c.autoconnect_all(1)
  puts "autoconn=#{s} e=#{e} m=#{m}"
  s,e,m = c.configure_get()
  puts "autoconn=#{s} e=#{e} m=#{m}"
=end
=begin
  wl,e,m = c.whitelist_get()
  puts "wl=#{wl} e=#{e} m=#{m}"
  if e==0
      if not wl.has_key?("device_array")
        puts "ERROR Whitelist does not contain KEY device_array"
      else
        wl["device_array"].each_with_index { |sens,i|
          sn=i+1
          puts("sensor#{sn}")
          sens.each { |k,v|
            puts("\t##{j} #{v}")
          }
          if sens.has_key?("connected") and sens["connected"].to_i == 1
            puts("sensor#{sn} is CONNECTED")
          else
            puts("sensor#{sn} is NOT CONNECTED")
          end
        }
      end
  else
    log_fail("Whitelist GET failed")
  end
  name, e, m = c.get_pairing_status()
  puts "get_pairing_status: name=#{name} e=#{e} m=#{m}"

  num_photos = c.wf.get_status_api2(:photos_on_card)
  puts "num_photos=#{num_photos}"
  puts "num_photos.is_a?Integer=#{num_photos.is_a?Integer}"
  puts "num_photos.is_a?String=#{num_photos.is_a?String}"
  puts "num_photos.to_i.is_a?Integer=#{num_photos.to_i.is_a?Integer}"
  num_videos = c.wf.get_status_api2(:videos_on_card)
  num_videos=""
  num_videos=nil
  num_videos=false
  puts "num_videos=#{num_videos}"
  puts "num_videos.to_i=#{num_videos.to_i}"
  puts "num_videos.is_a?Integer=#{num_videos.is_a?Integer}"
  puts "num_videos.is_a?String=#{num_videos.is_a?String}"
  puts "num_videos.to_i.is_a?Integer=#{num_videos.to_i.is_a?Integer}"
=end
  c.autoconnect_all(1)


end
