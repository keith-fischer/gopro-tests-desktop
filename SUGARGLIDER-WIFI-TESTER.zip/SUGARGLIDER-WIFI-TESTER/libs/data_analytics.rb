require_relative "log_utils"

class DataAnalytics
  include Data_analytics_decode
  include Data_analytics_events
  include LogUtils

  attr_reader :event_codes, :unused

  def initialize(ver, model)
    log_info("Instantiating analytics ver=#{ver}, model=#{model}")
    if ver >= "0.0.0" and ["ROCKYPOINT", "HALEIWA","HIMALAYAS"].include?(model)
      log_info("Including v0.0.0 RP/HAL/HIM extensions")
      extend Data_analytics_events_v000000_rp_hal
      if model == "HALEIWA"
        extend Data_analytics_events_v000000_hal
        log_info("Including v0.0.0 HAL-specific extensions")
      end
      if model == "HIMALAYAS"
        extend Data_analytics_events_v000000_hal
        log_info("Including v0.0.0 HIM-specific extensions")
      end
    end
    if ver >= "0.1.0"
      log_info("Including v0.1.0 extensions")
      extend Data_analytics_events_v000100
      if ["ROCKYPOINT", "HALEIWA","HIMALAYAS"].include?(model)
        log_info("Including v0.1.0 RP/HAL/HIM extensions")
        extend Data_analytics_events_v000100_rp
      end
    end
    if ver >= "0.2.0"
      log_info("Including v0.2.1 extensions")
      extend Data_analytics_events_v000201
    end
    @event_codes = init_event_code_hash()
    @unused = "NOT_USED"
  end

  # Create a quick_lookup table to go from NAME to code
  def init_event_code_hash
    ev_codes = {}
    range = (1..256)
    range.each { |n|
      begin
        code = "x%02x" %n
        event_hash = method(code).call
      rescue
        next
      else
        if event_hash.has_key?(:name) == false
          puts "WARNING: Event code #{code} missing :name key"
        end
        if ev_codes[event_hash[:name]] != nil
          puts "WARNING: overwriting hash for #{:name}(#{code})"
        end
        ev_codes[event_hash[:name]] = code if event_hash != nil
      end
    }
    return ev_codes
  end

  def translate_time(year, month, day, hour, min, sec)
    c_year = 2014 + year.to_i(2)
    c_month = '%02d' % month.to_i(2)
    c_day = '%02d' % day.to_i(2)
    c_hour = '%02d' % hour.to_i(2)
    c_min = '%02d' % min.to_i(2)
    c_sec = '%02d' % sec.to_i(2)
    return c_year, c_month, c_day, c_hour, c_min, c_sec
  end

  def translate_event(event, p1, p2, p3)

    begin
      event_hash = method("x#{event}").call
    rescue
      event_name = "UNKNOWN-EVENT"
    else
      event_name = event_hash[:name] if event_hash != nil
    end

    begin
      param1 = event_hash["p1"].call(p1)
    rescue
      param1 = nil
    end

    begin
      param2 = event_hash["p2"].call(p2)
    rescue
      param2 = nil
    end

    begin
      param3 = event_hash["p3"].call(p3)
    rescue
      param3 = nil
    end

    param1 = "UNKNOWN-P1" if param1 == nil
    param2 = "UNKNOWN-P2" if param2 == nil
    param3 = "UNKNOWN-P3" if param3 == nil
    return event_name, param1, param2, param3
  end

  def translate_entry(year, month, day, hour, min, sec, event, p1, p2, p3)
    return translate_time(year, month, day, hour, min, sec) + translate_event(event, p1, p2, p3)
  end

  def translate_to_file(file, save_dir, orig_date_time, orig_event, orig_p1, orig_p2, orig_p3, c_date_time, translated_data_array)

    now = Time.now

    parsed_file = File.join(save_dir, "#{File.basename(file, ".*")}_#{now.strftime("%m%d%Y_%H%M%S")}.txt")

    f = File.new(parsed_file, "a")

    orig_line = "#{orig_date_time},0x#{orig_event},0x#{orig_p1},0x#{orig_p2},0x#{orig_p3}"

    date_time_string = get_date_time(c_date_time[0], c_date_time[1], c_date_time[2], c_date_time[3], c_date_time[4], c_date_time[5])

    parsed_line = "#{date_time_string},#{translated_data_array[0]},#{translated_data_array[1]},#{translated_data_array[2]},#{translated_data_array[3]}"

    f.write(orig_line)
    f.puts
    f.write(parsed_line)
    f.puts
    f.puts

    f.close
    parsed_file
  end

  def validate_timestamp(y, mon, d, h, min, s)
    ts_str = "(YYYY-MM-DD HH:MM:SS) %s-%s-%s %s:%s:%s" %[y, mon, d, h, min, s]
    return false, "Year failed in #{ts_str}" if y.to_i < 2014 or y.to_i > 2077
    return false, "Month failed in #{ts_str}" if mon.to_i < 1 or mon.to_i > 12
    return false, "Day failed in #{ts_str}"   if d.to_i < 1 or d.to_i > 31
    return false, "Hour failed in #{ts_str}"  if h.to_i < 0 or h.to_i > 23
    return false, "Minute failed in #{ts_str}" if min.to_i < 0 or min.to_i > 59
    return false, "Second failed in #{ts_str}" if s.to_i < 0 or s.to_i > 59
    return true, "Timestamp passed"
  end

  def validate_data(file, save_dir, orig_date_time, orig_event, orig_p1, orig_p2, orig_p3, c_date_time, translated_data_array)

    orig_line = "#{orig_date_time},0x#{orig_event},0x#{orig_p1},0x#{orig_p2},0x#{orig_p3}"

    date_time_string = get_date_time(c_date_time[0], c_date_time[1], c_date_time[2], c_date_time[3], c_date_time[4], c_date_time[5])

    parsed_line = "#{date_time_string},#{translated_data_array[0]},#{translated_data_array[1]},#{translated_data_array[2]},#{translated_data_array[3]}"

    result_month = validate_month(c_date_time[0])
    result_day = validate_day(c_date_time[1])
    result_year = validate_year(c_date_time[2])

    result_hour = validate_hour(c_date_time[3])
    result_min = validate_min(c_date_time[4])
    result_sec = validate_sec(c_date_time[5])

    result_event = validate_event(orig_event)

    result_params = []

    result_params = validate_params(orig_event, [orig_p1, orig_p2, orig_p3]) if result_event[0]

    date_time_fail_result = ""
    failed_line = ""

    date_time_fail_result += "#{result_month[1]} / " if !result_month[0]
    date_time_fail_result += "#{result_day[1]} / " if !result_day[0]
    date_time_fail_result += "#{result_year[1]} / " if !result_year[0]
    date_time_fail_result += "#{result_hour[1]} / " if !result_hour[0]
    date_time_fail_result += "#{result_min[1]} / " if !result_min[0]
    date_time_fail_result += "#{result_sec[1]} / " if !result_sec[0]

    date_time_fail_result.empty? ? failed_line += "," : failed_line += "#{date_time_fail_result},"

    result_event[0] ? failed_line += "," : failed_line += "#{result_event},"

    result_params.each(){ |value|

      #      (failed_line += "SKIPPED VALIDATION," ;next) if value == nil
      (failed_line += "," ; next) if value == nil
      value[0] ? failed_line += "," : failed_line += "#{value[1]},"

    }

    if !failed_line.match(/,{4}/)

      failed_file = File.join(save_dir, "#{File.basename(file, ".*")}_failed_cases.txt")

      f = File.new(failed_file, "a")

      f.write(orig_line)
      f.puts
      f.write(parsed_line)
      f.puts
      f.write(failed_line)
      f.puts
      f.close
    end

    failed_file
  end

  #validate it is in range of 1 - 12
  def validate_month(month)

    (1..12).include?(month.to_i) ? (return true, "VALID_MONTH") : (return false, "#{fail_analytics_case["00"]}")
  end

  #validate it is in range of 1 - 31
  def validate_day(day)

    (1..31).include?(day.to_i) ? (return true, "VALID_DAY") : (return false, "#{fail_analytics_case["01"]}")

  end

  #validate it contains 4 digits only. Camera's date and time can be set to any (by choice or whatever).
  def validate_year(year)

    year.to_s.match(/\d{4}/) ? (return true, "VALID_YEAR") : (return false, "#{fail_analytics_case["02"]}")

  end

  #validate it is in range of 00 - 23
  def validate_hour(hour)

    (00..23).include?(hour.to_i) ? (return true, "VALID_HOUR") : (return false, "#{fail_analytics_case["03"]}")

  end

  #validate it is in range of 00 - 59
  def validate_min(min)

    (00..59).include?(min.to_i) ? (return true, "VALID_MIN") : (return false, "#{fail_analytics_case["04"]}")

  end

  #validate it is in range of 00 - 59
  def validate_sec(sec)

    (00..59).include?(sec.to_i) ? (return true, "VALID_SEC") : (return false, "#{fail_analytics_case["05"]}")

  end

  def validate_event(event)

    name = "x#{event}"

    begin

      method(name).inspect

    rescue NoMethodError, NameError

      return false, "#{fail_analytics_case()["06"]} #{name}"

    end

    return true, "RECOGNIZED EVENT #{name}"

  end

  #param value is supposed to be 0xff (aka not_used) but has 0x01 or something other than that. Also within range of available settings
  def validate_params(event, params)

    ret = []
    name = "x#{event}"

    hash =  method(name).call

    params.each_with_index do |value, index|

      p_value = "p#{index + 1}"

      p_name = hash[p_value].name()
      p_name_string = hash[p_value].name().to_s

      if p_name_string.include?("hash")

        res = method(p_name).call(value)

        if res == nil
          ret << [false, "#{fail_analytics_case["07"]} #{value}"]
        else
          ret << [true, "VALID PARAM VALUE"]
        end

      else
        ret << nil
      end

    end

    ret
  end

  #Data Analytics support methods
  def get_date_time(year, month, day, hour, min, sec)
    "#{year}/#{month}/#{day} #{hour}:#{min}:#{sec}"
  end

  def fail_analytics_case
    {
      "00" => "INVALID_MONTH", #validate it is in range of 1 - 12
      "01" => "INVALID_DAY",  #validate it is in range of 1 - 31
      "02" => "INVALID_YEAR", #validate it contains 4 digits only. Camera's date and time can be set to any (by choice or whatever).
      "03" => "INVALID_HOUR", #validate it is in range of 00 - 23
      "04" => "INVALID_MIN",  #validate it is in range of 00 - 59
      "05" => "INVALID_SEC",  #validate it is in range of 00 - 59
      "06" => "UNRECOGNIZED_EVENT",
      "07" => "UNEXPECTED_PARAM_VALUE"  #param value is supposed to be 0xff (aka not_used) but has 0x01 or something other than that. Also within range of available settings
    }
  end

end
