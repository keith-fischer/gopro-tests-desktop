require 'shellwords'
require 'date'
require 'time'
require 'open3'
require 'json'
require "base64"
require_relative '../libs/emailResults'
require 'rbconfig'

module Utils

  module_function
  def Email_Sender; @Email_Sender end
  def Email_Sender= v; @Email_Sender = v end
  #module_function :Email_Sender
  module_function
  def Email_pw; @Email_pw end
  def Email_pw= v; @Email_pw = v end
  #module_function :Email_pw

  def bash(command)
    # escaped_command = Shellwords.escape(command)
    puts "bash: #{command}"
    stdin, stdout, stderr = Open3.popen3(command)
    err=stderr.readlines()
    out = stdout.readlines()
    #err=stderr.gets
    #out = stdout.gets
    #puts "bash-stdout: #{out.to_s}"
    rc = nil
    fail = nil
    if err != nil

      if err.length>0
        rc= err.join("\n")
        puts "bash-stderr: #{rc}"
        fail=true
      end
    end
    if out != nil
      puts "bash-stdout: #{out.to_s.length}"
      if out.length>0
        puts "bash-stdout: #{out.to_s.length}"
        rc='' if rc==nil
        rc += out.join("\n")
      end
    end
    return rc, fail
  end
  module_function :bash

  #
  def os
    @os ||= (
    host_os = RbConfig::CONFIG['host_os']
    rc = ''
    case host_os
      when /mswin|msys|mingw|cygwin|bccwin|wince|emc/
        rc = 'win' # :windows
      when /darwin|mac os/
        rc = 'osx' #:macosx
      when /linux/
        rc = 'linux' #:linux
      when /solaris|bsd/
        rc = 'unix' #:unix
      else
        rc = host_os.inspect
        puts("host_os=#{rc}")
        raise Error, "unknown os: #{rc}"
    end
    )
    puts("host_os=#{rc}")
    return rc
  end
  module_function :os
  def setwifi(network, ssid,password)
    platform =os if platform==nil
    if platform=='osx'
      #networksetup -setairportnetwork en0 autobackdoor4851 password1
      out,err = self.bash("networksetup -setairportnetwork #{network} #{ssid} #{password}")
      return self.waitwifi(network,ssid, 30)
      #add validation
    elsif platform=='win'
      out,err = self.bash("networksetup -setairportnetwork #{network} #{ssid} #{password}")
    elsif platform=='linux'
      out,err = self.bash("networksetup -setairportnetwork #{network} #{ssid} #{password}")
    elsif platform=='unix'
      out,err = self.bash("networksetup -setairportnetwork #{network} #{ssid} #{password}")
    else
      puts "Unsupported platform utils.os=#{os}"
    end

  end
  module_function :setwifi

  def setgoprowifi()
    out,err = self.bash("networksetup -setairportnetwork en0 GoProWireless pro2450go!")
    return self.waitwifi('en0','GoProWireless', 30)
    #add validation
  end
  module_function :setgoprowifi

  def waitdownload(path)
    for i in 1..10 do
      if File.exists?(path)
        return true
      else
        puts "download wait #{i} second"
        sleep(1)
      end
    end
    return false
  end
  module_function :waitdownload
  def savemediainfo(path)
    puts "savemediainfo-path: #{path}"
    fdir = File.dirname(path)
    ffile = File.basename(path, ".*")
    newname = ffile + '.txt'
    newpath = fdir+'/'+newname
    sh="mediainfo -f #{path}"# &> #{newpath}"
    puts "savemediainfo-BASH_TXT=#{sh}"
    sleep(1)
    stdout, rc = self.bash(sh)

    # newname = ffile + '.html'
    # newpath = fdir+'/'+newname
    # sh="mediainfo -f --output=HTML #{path} &> #{newpath}"
    # puts "savemediainfo-BASH_HTML=#{sh}"
    # s,rc = self.bash(sh)
    puts "savemediainfo-stdout.length=#{stdout.length}" if stdout != nil
    return stdout
  end
  module_function :savemediainfo

  def waitwifi(network, expectedssid, timeout)
    dt1 =DateTime.now
    begin
      dt2 =DateTime.now
      stdout, err = self.bash("networksetup -getairportnetwork #{network}")
      if stdout != nil and stdout.length > 0
        if stdout.include? expectedssid
          return true
        end
      end
      dt2 =DateTime.now
    end while datediff_sec(dt1,dt2)<timeout

    return false
  end
  module_function :waitwifi

  def datediff_sec(start_time,end_time)
    return ((end_time - start_time) * 24 * 60 * 60).to_i
  end
  module_function :datediff_sec

  def getprojroot()
    rootp = File.dirname(__FILE__)
    return rootp.sub('/libs','')
  end
  module_function :getprojroot

  def loadJSON(path)
    begin
      jobj = JSON.load(File.read(path)) if File.exist?path
      return [false,jobj] if jobj==nil
      return [true,jobj]
    rescue StandardError => e
      return [false,e]
    end
  end
  module_function :loadJSON

  def openText(path)
    begin
      if not File.exists?(path)
        puts "ERROR: openText invalid path=#{path}"
        return false
      end

      rc = File.readlines(path)
      return rc

    rescue StandardError => e
      puts "ERROR openText #{path}\n"
      puts e.to_s
    end
    return false
  end
  module_function :openText

  def saveText(path, text)
    begin
      if not File.exists?(path)
        if not Dir.exists?(File.dirname(path))
          puts "ERROR: saveText invalid path=#{path}"
          return false
        end
      end
      rc = File.write(path,text)
      return true if rc != nil
      return false
    rescue StandardError => e
      puts "ERROR saveText #{path}"
      puts e.to_s
    end
    return false
  end
  module_function :saveText

  def saveJSON(path, jsonobj)
    begin
      jsontext = JSON.generate(jsonobj)  #JSON.pretty_generate(jsonobj)
      rc=saveText(path, jsontext)
      #rc = File.write(path,jsontext)
      return true if rc != nil
      return false

    rescue StandardError => e
      puts "ERROR saveJSON #{path}\n#{jsonobj.to_s}"
      puts e.to_s
    end
    return false
  end
  module_function :saveJSON

  def findObjPropinList(list,prop,value)

    return true, obj
  end
  module_function :findObjPropinList




  def getpathparts(path)
    dir = File.dirname(path)
    file = File.basename(path, ".*")
    ext = File.extname(path)
    return dir, file, ext
  end
  module_function :getpathparts

  def getiterativefilename(path)
    rc=path
    for i in 1..99 do
      if File.exists?(rc)
        dir, file, ext = getpathparts(path)
        rc = "#{dir}/#{file}_#{i}#{ext}"
      else
        break
      end
    end

    return rc
  end
  module_function :getiterativefilename

  def getmediafileparts(media_file)
    file = File.basename(media_file, ".*")
    ext = File.extname(media_file)
    prefix=file[1..(file.length-4)]
    index =file[(file.length-4)..-1]
    int = Integer(index, 10)
    return prefix, index, ext, int
  end
  module_function :getmediafileparts

  def getunusedmediaindex(media_dir,media_file,start_idx,end_idx)

    prefix, index, ext, int=getmediafileparts(media_file)
    rc = nil
    for idx in start_idx..end_idx do
      numstr = idx.to_s.rjust(4, '0')
      newpath = "#{media_dir}/#{prefix}#{numstr}#{ext}"
      if not File.exist?(newpath)
        rc = "#{prefix}#{numstr}#{ext}"
        break
      end
    end
    return rc
  end
  module_function :getunusedmediaindex

  def converttobase64(text)
    enc   = Base64.strict_encode64(text) #encode64(text)
    return enc
  end
  module_function :converttobase64

  def EmailDebug(email_to, email_subj, email_body)
    elist = [email_to]
    if email_body == nil
      email_body = ''
    end
    if email_subj == nil
      email_subj = 'Test Email from sugarglider media_capture_tool.rb'
    end

    EmailInfo(elist,email_subj,email_body)
  end
  module_function :EmailDebug

  # send email to all config recipients
  # all get same sub/body
  #
  def EmailInfo(emaillist, emailsub, emailbody)
    begin
      e = MailServer.new(@Email_Sender, @Email_pw)
      e.from_addr = @Email_Sender
    rescue StandardError => e
      puts "FAILED MailServer"
      puts e.to_s
    end

    emaillist.each { |email|
      begin
        e.to_addr = email
        e.build_message(emailsub, emailbody)
        e.send
        puts 'sent:' + e.content
      rescue StandardError => e
        puts "FAILED MailServer send: #{email}"
        puts e.to_s
      end
    }
  end
  module_function :EmailInfo
end

