module Data_analytics_events
  def x00
    {
      :name => "DATA_LOG_VERSION",
      "p1" => method("decode_data_log_version_major"),
      "p2" => method("decode_data_log_version_minor"),
      "p3" => method("decode_data_log_version_revision"),
    }
  end

  def x01
    {
      :name => "CAMERA_MODEL",
      "p1" => method("decode_camera_model"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x02
    {
      :name => "FIRMWARE_VERSION",
      "p1" => method("decode_camera_fw_major"),
      "p2" => method("decode_camera_fw_minor"),
      "p3" => method("decode_camera_fw_revision")
    }
  end

  def x03
    {
      :name => "POWER_CHARGING_STATUS",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_hash_charging_status"),
      "p3" => method("decode_hash_param_not_used")
    }
  end

  def x04
    {
      :name => "WIFI_CONNECTION_STATUS",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_hash_wifi_connection_status"),
      "p3" => method("decode_hash_wifi_mode")
    }
  end

  def x05
    {
      :name => "BUTTON_PRESSED",
      "p1" => method("decode_hash_p_button_pressed"),
      "p2" => method("decode_hash_s_button_pressed"),
      "p3" => method("decode_hash_w_button_pressed"),
    }
  end

  def x07
    {
      :name => "RTC_DATE_SET",
      "p1" => method("decode_rtc_val"),
      "p2" => method("decode_rtc_val"),
      "p3" => method("decode_rtc_val"),
    }
  end

  def x08
    {
      :name => "RTC_TIME_SET",
      "p1" => method("decode_rtc_val"),
      "p2" => method("decode_rtc_val"),
      "p3" => method("decode_rtc_val"),
    }
  end

  def x09
    {
      :name => "MFG_DATE",
      "p1" => method("decode_mfg_year"),
      "p2" => method("decode_mfg_week"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x0a
    {
      :name => "CAMERA_RESET",
      "p1" => method("decode_reset"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x11
    {
      :name => "CAMERA_MODE",
      "p1" => method("decode_hash_camera_mode"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x13
    {
      :name => "DEFAULT_MODE",
      "p1" => method("decode_hash_default_mode"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x14
    {
      :name => "SPOT_METERING",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_capture_parameter_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x15
    {
      :name => "TIME_LAPSE_INTERVAL",
      "p1" => method("decode_hash_time_lapse_interval"),
      "p2" => method("decode_capture_parameter_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x16
    {
      :name => "AUTO_POWER_OFF",
      "p1" => method("decode_hash_auto_power_off"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x17
    {
      :name => "FIELD_OF_VIEW",
      "p1" => method("decode_hash_field_of_view"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x18
    {
      :name => "PHOTO_RESOLUTION",
      "p1" => method("decode_hash_photo_resolution"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x19 #VR
    {
      :name => "VIDEO_RESOLUTION_FPS",
      "p1" => method("decode_hash_video_resolution_fps"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1a
    {
      :name => "AUDIO_INPUT",
      "p1" => method("decode_hash_audio_input"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1d
    {
      :name => "BEEP_SOUND",
      "p1" => method("decode_hash_beep_sound"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1e
    {
      :name => "LED_BLINK",
      "p1" => method("decode_hash_led_blink"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1f
    {
      :name => "FLAG_1",
      "p1" => method("decode_flag_1"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x20
    {
      :name => "BATTERY_LEVEL",
      "p1" => method("decode_hash_battery_level"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used")
    }
  end

  def x21
    {
      :name => "USB_MODE",
      "p1" => method("decode_hash_usb_mode"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x22
    {
      :name => "PHOTOS_AVAILABLE",
      "p1" => method("decode_photos_available_msb"),
      "p2" => method("decode_photos_available_lsb"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x23
    {
      :name => "PHOTOS_ON_CARD",
      "p1" => method("decode_photos_on_card_msb"),
      "p2" => method("decode_photos_on_card_lsb"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x24
    {
      :name => "VIDEO_MINS_AVAILABLE",
      "p1" => method("decode_video_mins_available_msb"),
      "p2" => method("decode_video_mins_available_lsb"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x25
    {
      :name => "VIDEOS_ON_CARD",
      "p1" => method("decode_videos_on_card_msb"),
      "p2" => method("decode_videos_on_card_lsb"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x26
    {
      :name => "SHUTTER_STATUS",
      "p1" => method("decode_hash_shutter_status"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x27
    {
      :name => "FLAG_2",
      "p1" => method("decode_flag_2"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x28
    {
      :name => "HLS_SEGMENT_SIZE",
      "p1" => method("decode_hash_hls_segment_size"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x29
    {
      :name => "BURST_VALUE",
      "p1" => method("decode_hash_burst_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2a
    {
      :name => "CONTINUOUS_SHOT_VALUE",
      "p1" => method("decode_hash_continuous_shots_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2b
    {
      :name => "WHITE_BALANCE_VALUE",
      "p1" => method("decode_hash_white_balance_value"),
      "p2" => method("decode_capture_parameter_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2c
    {
      :name => "PHOTO_BRACKETING",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2d
    {
      :name => "PHOTO_IN_VIDEO_VALUE",
      "p1" => method("decode_hash_photo_in_video_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2e
    {
      :name => "LOOPING_VALUE",
      "p1" => method("decode_hash_looping_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2f
    {
      :name => "HDMI_SLIDESHOW",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

=begin
  #TODO
  def x30
    {

    }
  end
=end

  def x31
    {
      :name => "TIME_LAPSE_STYLE",
      "p1" => method("decode_hash_time_lapse_style"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x32
    {
      :name => "VIDEO_LOOP_TIME_COUNTER",
      "p1" => method("decode_video_looping_counter_hour"),
      "p2" => method("decode_video_looping_counter_min"),
      "p3" => method("decode_video_looping_counter_sec")
    }
  end

  def x33
    {
      :name => "EXTERNAL_BATTERY_LEVEL",
      "p1" => method("decode_external_battery_level"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x34
    {
      :name => "FLAG_3",
      "p1" => method("decode_flag_3"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x35
   {
      :name => "LCD_VOLUME",
      "p1" => method("decode_lcd_volume"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x36
    {
      :name => "LCD_BRIGHTNESS",
      "p1" => method("decode_lcd_brightness"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x37
    {
      :name => "LCD_SLEEP",
      "p1" => method("decode_lcd_sleep"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x38
    {
      :name => "VIDEO_RESOLUTION",
      "p1" => method("decode_hash_video_resolution"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x39
    {
      :name => "FRAMES_PER_SECOND",
      "p1" => method("decode_hash_frame_per_second"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3a
    {
      :name => "FLAG_4",
      "p1" => method("decode_flag_4"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3b
    {
      :name => "EXPOSURE_COMPENSATION",
      "p1" => method("decode_hash_exposure_compensation"),
      "p2" => method("decode_capture_parameter_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3c
    {
      :name => "NIGHT_PHOTO_SHUTTER_EXPOSURE",
      "p1" => method("decode_hash_night_photo_shutter_exposure"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3d
    {
      :name => "NIGHT_LAPSE_SHUTTER_EXPOSURE",
      "p1" => method("decode_hash_night_lapse_shutter_exposure"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3e
    {
      :name => "VIDEO_PROTUNE_ISO",
      "p1" => method("decode_hash_video_protune_iso_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3f
    {
      :name => "PHOTO_PROTUNE_ISO",
      "p1" => method("decode_hash_photo_protune_iso_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x40
    {
      :name => "MULTI_SHOT_PROTUNE_ISO",
      "p1" => method("decode_hash_photo_protune_iso_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x41
    {
      :name => "HIGHLIGHT_TAG",
      "p1" => method("decode_highlight_tag"),
      "p2" => method("decode_highlight_tag_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x42
    {
      :name => "NIGHT_LAPSE_INTERVAL",
      "p1" => method("decode_hash_night_lapse_interval"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x43
    {
      :name => "DELETE_FILE",
      "p1" => method("decode_delete_file"),
      "p2" => method("decode_delete_cancel"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x44
    {
      :name => "FLAG_5",
      "p1" => method("decode_flag_5"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x45
    {
      :name => "FLAG_6",
      # P1 uses flag 5 because they are exactly the same
      "p1" => method("decode_flag_5"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x50
    {
      :name => "TEMPERATURE_WARNING",
      "p1" => method("decode_temperature_read"),
      "p2" => method("decode_hash_temperature_warning"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x51
    {
      :name => "SD_CARD_WARNING",
      "p1" => method("decode_hash_sd_card_warning"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x52
    {
      :name => "BATTERY_LOW_SHUTDOWN_WARNING",
      "p1" => method("decode_hash_battery_low_shutdown_warning"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def xEE
    {
      :name => "FAKE_TEST_EVENT",
      "p1" => method("decode_fake_test_event"),
      "p2" => method("decode_fake_test_event"),
      "p3" => method("decode_fake_test_event"),
    }
  end

  def xxy
    {
      :name => "VIDEO_TIME_LAPSE_INTERVAL",
      "p1" => method("decode_hash_video_time_lapse_interval"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end
=begin
  def xff
    {
      :name => "EVENT xff",
      "p1" => method("decode_hash_param_not_used"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end
=end
end

###############################################################################
# Differences with v000000 (Hawaii phase 2)
# - P2 not used for FLAG events for anything
# - P2 not used to identify 'mode' for certain parameters
###############################################################################
module Data_analytics_events_v000000_rp_hal
  def x14
    {
      :name => "SPOT_METERING",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x15
    {
      :name => "TIME_LAPSE_INTERVAL",
      "p1" => method("decode_hash_time_lapse_interval"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1e
    {
      :name => "LED_BLINK",
      "p1" => method("decode_hash_led_blink_rp"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1f
    {
      :name => "FLAG_1",
      "p1" => method("decode_flag_1"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x27
    {
      :name => "FLAG_2",
      "p1" => method("decode_flag_2"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x2b
    {
      :name => "WHITE_BALANCE_VALUE",
      "p1" => method("decode_hash_white_balance_value"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x34
    {
      :name => "FLAG_3",
      "p1" => method("decode_flag_3"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3a
    {
      :name => "FLAG_4",
      "p1" => method("decode_flag_4_rpv00"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3b
    {
      :name => "EXPOSURE_COMPENSATION",
      "p1" => method("decode_hash_exposure_compensation"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end
end

module Data_analytics_events_v000000_hal
  def x1d
    {
      :name => "BEEP_SOUND",
      "p1" => method("decode_hash_beep_sound_hal"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1e
    {
      :name => "LED_BLINK",
      "p1" => method("decode_hash_led_blink_hal"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  # LCD is either ON or OFF
  def x36
    {
      :name => "LCD_BRIGHTNESS",
      "p1" => method("decode_lcd_brightness_haleiwa_v000"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end
end # Data_analytics_events_v000000_rp_hal

###############################################################################
### Hawaii Data Analytics v0.1.0
###############################################################################
module Data_analytics_events_v000100
  def x05
    {
      :name => "BUTTON_PRESSED",
      "p1" => method("decode_button_id"),
      "p2" => method("decode_button_action"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x06
    {
      :name => "CAMERA_ACCESSORY",
      "p1" => method("decode_camera_accessory"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x0b
    {
      :name => "WIFI_RESET",
      "p1" => method("decode_reset"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x0c
    {
      :name => "CAMERA_STATUS",
      "p1" => method("decode_camera_status"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x1b
    {
      :name => "AUDIO_OUTPUT",
      "p1" => method("decode_hash_audio_output"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1c
    {
      :name => "PLAYBACK_SETTINGS",
      "p1" => method("decode_playback_action"),
      "p2" => method("decode_file_type"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1f
    {
      :name => "PROTUNE_SETTINGS",
      "p1" => method("decode_protune_settings"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x27
    {
      :name => "USER_SETTINGS",
      "p1" => method("decode_user_settings"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x2f
    {
      :name => "BROADCAST_SETTINGS",
      "p1" => method("decode_hash_video_resolution"),
      "p2" => method("decode_hash_frame_per_second"),
      "p3" => method("decode_hash_field_of_view")
    }
  end

  def x30
    {
      :name => "BROADCAST_SUB_MODE",
      "p1" => method("decode_broadcast_mode"),
      "p2" => method("decode_broadcast_privacy_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x34
    {
      :name => "FW_UPDATE_STATUS",
      "p1" => method("decode_fw_update_status"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3a
    {
      :name => "VIDEO_PROTUNE_SETTINGS",
      "p1" => method("decode_video_protune_settings"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x3c
    {
      :name => "NIGHT_PHOTO_SHUTTER_EXPOSURE",
      "p1" => method("decode_hash_night_photo_shutter_exposure"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  # def x43
  #   {
  #     :name => "DELETE_FILE",
  #     "p1" => method("decode_delete_file"),
  #     "p2" => method("decode_delete_mode"),
  #     "p3" => method("decode_hash_modified_by")
  #   }
  # end

  def x44
    {
      :name => "FLAG_5",
      "p1" => method("decode_photo_protune_settings"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x45
    {
      :name => "FLAG_6",
      "p1" => method("decode_multi_shot_protune_settings"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x46
    {
      :name => "BROADCAST_RECORD_RESOLUTION",
      "p1" => method("decode_hash_video_resolution"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x47
    {
      :name => "BROADCAST_RECORD_FPS",
      "p1" => method("decode_hash_frame_per_second"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x48
    {
      :name => "BROADCAST_RECORD_FOV",
      "p1" => method("decode_hash_field_of_view"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end
end # Data_analytics_events_v000100

############################################################
module Data_analytics_events_v000100_rp
  def x14
    {
      :name => "SPOT_METERING",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_capture_parameter_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x15
    {
      :name => "TIME_LAPSE_INTERVAL",
      "p1" => method("decode_hash_time_lapse_interval"),
      "p2" => method("decode_capture_parameter_mode"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3a
    {
      :name => "VIDEO_PROTUNE_SETTINGS",
      "p1" => method("decode_video_protune_settings_rpv01"),
      "p2" => method("decode_field_changed"),
      "p3" => method("decode_hash_modified_by")
    }
  end
end # Data_analytics_events_v000100_rp

###############################################################################
### Hawaii Phase 4 Analytics Updates
###############################################################################
module Data_analytics_events_v000201

  def x03
    {
      :name => "POWER_CHARGING_STATUS",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_hash_charging_status"),
      "p3" => method("decode_hash_battery_type")
    }
  end

  def x05
    {
      :name => "BUTTON_PRESSED",
      "p1" => method("decode_button_id"),
      "p2" => method("decode_button_action"),
      "p3" => method("decode_hash_modified_by"),
    }
  end

  def x0d
    {
      :name => "LANGUAGE",
      "p1" => method("decode_language"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x0e
    {
      :name => "LIGHT_VALUE",
      "p1" => method("decode_light_value"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x14
    {
      :name => "SPOT_METERING",
      "p1" => method("decode_hash_on_off"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x17
    {
      :name => "FIELD_OF_VIEW",
      "p1" => method("decode_hash_field_of_view"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x18
    {
      :name => "PHOTO_RESOLUTION",
      "p1" => method("decode_hash_photo_resolution"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x1a
    {
      :name => "AUDIO_INPUT",
      "p1" => method("decode_hash_audio_input"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used")
    }
  end

  def x1b
    {
      :name => "AUDIO_OUTPUT",
      "p1" => method("decode_hash_audio_output"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used")
    }
  end

  def x2b
    {
      :name => "WHITE_BALANCE_VALUE",
      "p1" => method("decode_hash_white_balance_value_hawaiip4"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end


  def x38
    {
      :name => "VIDEO_RESOLUTION",
      "p1" => method("decode_hash_video_resolution"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x39
    {
      :name => "FRAMES_PER_SECOND",
      "p1" => method("decode_hash_frame_per_second"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3e
    {
      :name => "VIDEO_PROTUNE_ISO",
      "p1" => method("decode_hash_video_protune_iso_value_hawaiip4"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x3f
    {
      :name => "PHOTO_PROTUNE_ISO_MAX",
      "p1" => method("decode_hash_photo_protune_iso_value"),
      "p2" => method("decode_capture_parameter_photo_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x40
    {
      :name => "MULTI_SHOT_PROTUNE_ISO_MAX",
      "p1" => method("decode_hash_photo_protune_iso_value"),
      "p2" => method("decode_capture_parameter_multishot_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x41
    {
      :name => "HIGHLIGHT_TAG",
      "p1" => method("decode_highlight_tag_hawaiip4"),
      "p2" => method("decode_highlight_tag_mode_media_type"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x46
    {
      :name => "VIDEO_PROTUNE_SHUTTER_SPEED",
      "p1" => method("decode_video_protune_shutter_speed"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x47
    {
      :name => "PHOTO_PROTUNE_ISO_MIN",
      "p1" => method("decode_hash_photo_protune_iso_value"),
      "p2" => method("decode_capture_parameter_photo_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x48
    {
      :name => "MULTI_SHOT_PROTUNE_ISO_MIN",
      "p1" => method("decode_hash_photo_protune_iso_value"),
      "p2" => method("decode_capture_parameter_multishot_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x49
    {
      :name => "VIDEO_PROTUNE_ISO_MODE",
      "p1" => method("decode_hash_video_protune_iso_mode"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x4a
    {
      :name => "PROTUNE_RESET",
      "p1" => method("decode_hash_protune_reset"),
      "p2" => method("decode_capture_parameter_all_modes"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x4b
    {
      :name => "PLAYBACK_MEDIA_FILTER_TYPE",
      "p1" => method("decode_playback_media_filter_type"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_modified_by")
    }
  end

  def x53
    {
      :name => "FIRMWARE_UPDATE_ERROR",
      "p1" => method("decode_firmware_update_error"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x54
    {
      :name => "POWER_SAVE_MODE",
      "p1" => method("decode_power_save_mode"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end

  def x55
    {
      :name => "DATA_ANALYTICS_FULL",
      "p1" => method("decode_data_analytics_full"),
      "p2" => method("decode_hash_param_not_used"),
      "p3" => method("decode_hash_param_not_used"),
    }
  end
end # Data_analytics_events_v000200
