# wifi.rb
require_relative 'wifi_commands_decode'

module WifiCommands
  include WifiCommandsDecode
  def setup_beep
    {
      :set  => "BS",
      :get  => "bs",
      :ret  => method("decode_1byte_option"),
      "0"     => "%00",
      "70"    => "%01",
      "100"   => "%02",
    }
  end

  #capture mode for remote_api_1
  def mode_cm
    {
      :set  => "CM",
      :get  => "cm",
      :ret  => method("decode_1byte_option"),
      "VIDEO"       => "%00",
      "PHOTO"       => "%01",
      "BURST"       => "%02",
      "TIMELAPSE"   => "%03",
      #    "SELF_TIMER"  => "%04",
      #    "PLAYBACK"    => "%05",
      #    "RC_MULTI"    => "%06",
      "SETTINGS"    => "%07",
    }
  end

  def setup_default_mode
    {
      :set  => "DM",
      :get  => "dm",
      :ret  => method("decode_1byte_option"),
      "VIDEO"       => "%00",
      "PHOTO"       => "%01",
      "BURST"       => "%02",
      "TIME_LAPSE"  => "%03",
      #      "LAST"        => "%04",
    }
  end

  def video_spot_metering
    {
      :set    => "EX",
      :get    => "ex",
      :ret    => method("decode_1byte_option"),
      "OFF"   => "%00",
      "ON"    => "%01",
    }
  end

  def setup_led
    {
      :set    => "LB",
      :get    => "lb",
      :ret    => method("decode_1byte_option"),
      "0"     => "%00",
      "2"     => "%01",
      "4"     => "%02",
    }
  end

  def locate_ll
    {
      :set    => "LL",
      :get    => "ll",
      :ret    => method("decode_1byte_option"),
      "OFF"   => "%00",
      "ON"    => "%01",
    }
  end

  def preview_pv
    {
      :set  => "PV",
      :get  => "pv",
      :ret  => method("decode_wifi_pass_fail"),
      "OFF" => "%00",
      "ON"  => "%02"
    }
  end

  def power_pw
    {
      :set      => "PW",
      :get      => "pw",
      :ret      => method("decode_1byte_option"),
      "OFF"     => "%00",
      "ON"      => "%01",
      "TOGGLE"  => "%02",
    }
  end

  def shutter_sh
    {
      :set      => "SH",
      :get      => "sh",
      :ret      => method("decode_1byte_option"),
      "OFF"     => "%00",
      "ON"      => "%01",
      "TOGGLE"  => "%02",
      "LONG"    => "%03",
    }
  end

  # Upside-down mode
  def setup_orientation
    {
      :set    => "UP",
      :get    => "up",
      :ret    => method("decode_1byte_option"),
      "UP"    => "%00",
      "DOWN"  => "%01",
    }
  end

  def setup_video_format
    {
      :set    => "VM",
      :get    => "vm",
      :ret    => method("decode_1byte_option"),
      "NTSC"  => "%00",
      "PAL"   => "%01",
    }
  end

  def photo_resolution
    {
      :set      => "PR",
      :get      => "pr",
      :ret      => method("decode_1byte_option"),
      "11WIDE"  => "%00",
      "8MED"    => "%01",
      "5WIDE"   => "%02",
      "5MED"    => "%03",
      "7WIDE"   => "%04",
      "12WIDE"  => "%05",
      "7MED"    => "%06",
      "8WIDE"   => "%07",
      "10WIDE"  => "%08"
    }
  end

  def multi_photo_resolution
    {
      :set      => "PR",
      :get      => "pr",
      :ret      => method("decode_1byte_option"),
      "11WIDE"  => "%00",
      "8MED"    => "%01",
      "5WIDE"   => "%02",
      "5MED"    => "%03",
      "7WIDE"   => "%04",
      "12WIDE"  => "%05",
      "7MED"    => "%06",
      "8WIDE"   => "%07",
      "10WIDE"  => "%08"
    }
  end

  def multi_photo_burst
    {
      :set    => "BU",
      :get    => "bu",
      :ret    => method("decode_1byte_option"),
      "3_1"   => "%00",
      "5_1"   => "%01",
      "10_1"  => "%02",
      "10_2"  => "%03",
      "30_1"  => "%04",
      "30_2"  => "%05",
      "30_3"  => "%06"
    }
  end

  def multi_photo_timelapse
    {
      :set  => "TI",
      :get  => "ti",
      :ret  => method("decode_1byte_option"),
      "0.5" => "%00",
      "1"   => "%01",
      "2"   => "%02",
      "5"   => "%05",
      "10"  => "%0A",
      "30"  => "%1E",
      "60"  => "%3C"
    }
  end

  def photo_continuous
    {
      :set  => "CS",
      :get  => "cs",
      :ret  => method("decode_1byte_option"),
      "1"   => "%00",
      "3"   => "%03",
      "5"   => "%05",
      "10"  => "%0A",
    }
  end

  # Photo in video
  def video_piv
    {
      :set  => "PN",
      :get  => "pn",
      :ret  => method("decode_1byte_option"),
      "OFF" => "%00",
      "5"   => "%01",
      "10"  => "%02",
      "30"  => "%03",
      "60"  => "%04",
    }
  end

  def video_looping
    {
      :set  => "LO",
      :get  => "lo",
      :ret  => method("decode_1byte_option"),
      "OFF" => "%00",
      "5"   => "%01",
      "20"  => "%02",
      "60"  => "%03",
      "120" => "%04",
      "MAX" => "%05",
    }
  end

  def preview_bitrate
    {
      :set    => "BV",
      :get    => "bv",
      :ret    => method("decode_1byte_option"),
      "HIGH"  => "%00",
      "MED"   => "%01",
      "LOW"   => "%02",
    }
  end

  def preview_resolution
    {
      :set    => "RV",
      :get    => "rv",
      :ret    => method("decode_1byte_option"),
      "LOW"   => "%00",
      "HIGH"  => "%01",
    }
  end

  #def video_protune
  def video_pt
    {
      :set  => "PT",
      :get  => "pt",
      :ret  => method("decode_1byte_option"),
      "OFF" => "%00",
      "ON"  => "%01",
    }
  end

  def video_pt_color
    {
      :set    => "CO",
      :get    => "co",
      :ret    => method("decode_1byte_option"),
      "STANDARD"  => "%00",
      "NEUTRAL"   => "%01",
    }
  end

  def video_pt_ev
    {
      :set    => "EV",
      :get    => "ev",
      :ret    => method("decode_1byte_option"),
      #      -5.0    => "%00",
      #      -4.5    => "%01",
      #      -4.0    => "%02",
      #      -3.5    => "%03",
      #      -3.0    => "%04",
      #      -2.5    => "%05",
      "-2.0"    => "%06",
      "-1.5"    => "%07",
      "-1.0"    => "%08",
      "-0.5"    => "%09",
      "0"       => "%0a",
      "0.5"     => "%0b",
      "1.0"     => "%0c",
      "1.5"     => "%0d",
      "2.0"     => "%0e",
      #      2.5     => "%0f",
      #      3.0     => "%10",
      #      3.5     => "%11",
      #      4.0     => "%12",
      #      4.5     => "%13",
      #      5.0     => "%14",
    }
  end

  #gain
  def video_pt_iso
    {
      :set    => "GA",
      :get    => "ga",
      :ret    => method("decode_1byte_option"),
      "6400"  => "%00",
      "1600"  => "%01",
      "400"   => "%02",
    }
  end

  def video_pt_sharp
    {
      :set    => "SP",
      :get    => "sp",
      :ret    => method("decode_1byte_option"),
      "HIGH"  => "%00",
      "MED"   => "%01",
      "LOW"   => "%02",
    }
  end

  def video_pt_wb
    {
      :set    => "WB",
      :get    => "wb",
      :ret    => method("decode_1byte_option"),
      "AUTO"  => "%00",
      "3000K" => "%01",
      "5500K" => "%02",
      "6500K" => "%03",
      "RAW"   => "%04"
    }
  end

  def video_resolution
    {
      :set          => "VV",
      :get          => "vv",
      :ret          => method("decode_1byte_option"),
      "WVGA"        => "%00",
      "720"         => "%01",
      "960"         => "%02",
      "1080"        => "%03",
      "1440"        => "%04",
      "2.7K"        => "%05",
      "4K"          => "%06",
      "2.7K_CIN"    => "%07",
      "4K_CIN"      => "%08",
      "1080_SUPER"  => "%09",
      "720_SUPER"   => "%0a"
    }
  end

  def video_fps
    {
      :set  => "FS",
      :get  => "fs",
      :ret  => method("decode_1byte_option"),
      "12"    => "%00",
      "15"    => "%01",
      "24"    => "%02",
      "25"    => "%03",
      "30"    => "%04",
      "48"    => "%05",
      "50"    => "%06",
      "60"    => "%07",
      "100"   => "%08",
      "120"   => "%09",
      "240"   => "%0a",
      "12.5"  => "%0b"
    }
  end

  def video_fov
    {
      :set  => "FV",
      :get  => "fv",
      :ret  => method("decode_1byte_option"),
      "W"   => "%00",
      "M"   => "%01",
      "N"   => "%02",
      "L"   => "%04"
    }
  end

  def video_low_light
    {
      :set    => "LW",
      :get    => "lw",
      :ret    => method("decode_1byte_option"),
      "OFF"   => "%00",
      "ON"    => "%01",
    }
  end

  def delete_all; {
      :set    => "DA",
      :ret    => method("decode_wifi_pass_fail"),
    }
  end

  def delete_file; {
      :set    => "DF",
      :ret    => method("decode_wifi_pass_fail"),
    }
  end

  def delete_group; {
      :set    => "DG",
      :ret    => method("decode_wifi_pass_fail"),
    }
  end

  def delete_last; {
      :set    => "DL",
      :ret    => method("decode_wifi_pass_fail"),
    }
  end

  def start_ota_update
    {
      :set    => "OF",
      :ret    => method("decode_wifi_pass_fail"),
      "ON"    => "%01",
    }
  end

  def ota_mode
    {
      :set    => "OM",
      :get    => "om",
      :ret    => method("decode_1byte_option"),
      "OFF"   => "%00",
      "ON"    => "%01",
    }
  end

  def camera_capabilities
    [
      :has_camera_roll,
      :has_ota,
      :has_ltp,
      :has_3D,
      :has_ccl
    ]
  end

  # For camera status
  def status_sx; {:get => "sx"}; end

  # For camera capabilities
  def status_cc; {:get => "cc"}; end

  # For bacpac status
  def status_se
    {
      :get => "se",
      :ret => method("decode_bacpac_se"),
    }
  end

  # For basic camera info
  def cam_info; { :get => "cv"}; end

  def status_secondary
    {
      :get    => "xs",
      :ret    => method("decode_status_secondary"),
    }
  end

  #not checking
  def audio_input
    {
      :set    => "AI",
      :get    => "ai",
      :ret    => method("decode_1byte_option"),
      "CAM"   => "%00",
      "BUS"   => "%01",
      "MIX"   => "%02",
      "JACK"  => "%03",
    }
  end

  #auto power off (not valid when wireless active)
  def setup_auto_off
    {
      :set    => "AO",
      :get    => "ao",
      :ret    => method("decode_1byte_option"),
      "0"     => "%00",
      "60"    => "%01",
      "120"   => "%02",
      "300"   => "%03",
    }
  end

  def battery_level
    {
      :get    => "bl",
      :ret    => method("decode_battery_level"),
    }
  end

  # On-screen display
  def setup_osd
    {
      :set    => "DS",
      :get    => "ds",
      :ret    => method("decode_1byte_option"),
      "OFF"   => "%00",
      "ON"    => "%01",
    }
  end

  def lcd_display
    {
      :get  => "lc",
      :ret  => method("decode_lcd"),
      "0"   => "%00",
      "1"   => "%01",
      "2"   => "%02",
      "3"   => "%03",
      "4"   => "%04",
    }
  end

  # One-button mode (not valid when wireless active)
  def obm
    {
      :set    => "OB",
      :get    => "ob",
      :ret    => method("decode_1byte_option"),
      "OFF"   => "%00",
      "ON"    => "%01",
    }
  end

  def playback_mode
    {
      :set    => "PM",
      :get    => "pm",
      :ret    => method("decode_1byte_option"),
      "PAUSE" => "%00",
      "PLAY"  => "%01",
      "FF2X"  => "%02",
      "FF4X"  => "%04",
      "FF8X"  => "%08",
      "FF16X" => "%10",
      "FF32X" => "%20",
      "RW1X"  => "%81",
      "RW2X"  => "%82",
      "RW4X"  => "%84",
      "RW8X"  => "%88",
      "RW16X" => "%90",
      "RW32X" => "%a0",
    }
  end

  def bacpac_cv
    {
      :get  => "cv",
      :ret  => method("decode_bacpac_cv")
    }
  end

  def bacpac_ap_key
    {
      :get  => "sd",
      :ret  => method("decode_ap_key")
    }
  end

  def status_api2_mapping
    {
      :internal_battery_present => '1',
      :internal_battery_bar => '2',
      :external_battery_present => '3',
      :external_battery_bar => '4',
      :current_temperature => '5',
      :system_hot => '6',
      :busy => '8',
      :quick_capture_active => '9',
      :shutter => '10',
      :lcd_lock_active => '11',
      :xmode => '12',
      :video_progress_counter => '13',
      :broadcast_progress_counter => '14',
      :broadcast_viewers_count => '15',
      :broadcast_bstatus => '16',
      :wireless_enabled => '17',
      :wireless_current_time => '18',
      :wireless_pairing_state => '19',
      :wireless_requested_pair_type => '20',
      :wireless_pairing_complete_time => '21',
      :wireless_network_scanning_state => '22',
      :wireless_scan_complete_time => '23',
      :wireless_provision_state => '24',
      :wireless_smart_device_rssi => '25',
      :wireless_rc_associated => '26',
      :wireless_rc_connected => '27',
      :wireless_previously_paired => '28',
      :wireless_wlan_associated => '29',
      :wireless_camera_ap_ssid => '30',
      :wireless_app_count => '31',
      :stream_enabled => '32',
      :sd_status => '33',
      :photos_available => '34',
      :video_minutes_available => '35',
      :num_group_photos => '36',
      :num_group_videos => '37',
      :photos_on_card => '38',
      :videos_on_card => '39',
      :date_time => '40',
      :fwupdate_download_active => '41',
      :fwupdate_download_cancel_request_pending => '42',
      :mode => '43',
      :submode => '44',
      :locate => '45',
      :video_protune_default => '46',
      :photo_protune_default => '47',
      :multi_photo_protune_default => '48',
      :multi_photo_count_down => '49',
      :remaining_space => '54',
      :stream_supported => '55',
      :wifi_bars => '56',
      :current_time_msec => '57',
      :num_hilights => '58',
      :last_hilight_time_msec => '59',
      :next_poll_msec => '60',
      :analytics_ready => '61',
      :analytics_size => '62',
      :in_contextual_menu => '63',
      :remaining_timelapse_time => '64',
    }
  end

  def setting
    {
      :video_submode => {'l1' => 'video', 'l2' => 'current_sub_mode', 'method' => :video_current_submode_api2},
      :video_resolution => {'l1' => 'video', 'l2' => 'resolution', 'method' => :video_resolution_api2},
      :video_fps => {'l1' => 'video', 'l2' => 'fps', 'method' => :video_fps_api2},
      :video_fov => {'l1' => 'video', 'l2' => 'fov', 'method' => :video_fov_api2},
      :video_timelapse => {'l1' => 'video', 'l2' => 'timelapse_rate', 'method' => :video_timelapse_api2},
      :video_looping => {'l1' => 'video', 'l2' => 'looping', 'method' => :video_looping_api2},
      :video_piv => {'l1' => 'video', 'l2' => 'piv', 'method' => :video_piv_api2},
      :video_low_light => {'l1' => 'video', 'l2' => 'low_light', 'method' => :video_low_light_api2},
      :video_spot_metering => {'l1' => 'video', 'l2' => 'spot_meter', 'method' => :video_spot_metering_api2},
      :video_dft_submode => {'l1' => 'video', 'l2' => 'default_sub_mode', 'method' => :video_default_submode_api2},
      :video_pt => {'l1' => 'video', 'l2' => 'protune', 'method' => :video_protune_api2},
      :video_pt_wb => {'l1' => 'video', 'l2' => 'protune_white_balance', 'method' => :video_protune_white_balance_api2},
      :video_pt_color => {'l1' => 'video', 'l2' => 'protune_color', 'method' => :video_protune_color_api2},
      :video_pt_iso => {'l1' => 'video', 'l2' => 'protune_iso', 'method' => :video_protune_iso_api2},
      :video_pt_iso_mode => {'l1' => 'video', 'l2' => 'protune_iso_mode', 'method' => :video_protune_iso_mode_api2},
      :video_pt_shutter_speed => {'l1' => 'video', 'l2' => 'exposure_time', 'method' => :video_protune_shutter_speed_api2},
      :video_pt_sharp => {'l1' => 'video', 'l2' => 'protune_sharpness', 'method' => :video_protune_sharpness_api2},
      :video_pt_ev => {'l1' => 'video', 'l2' => 'protune_ev', 'method' => :video_protune_exposure_api2},

      :video_eis => { 'l1' => 'video', 'l2' => 'eis', 'method' => :video_eis_api2},
      :video_awf => { 'l1' => 'audio', 'l2' => 'option', 'method' => :video_awf_api2},

      :photo_submode => {'l1' => 'photo', 'l2' => 'current_sub_mode', 'method' => :photo_current_submode_api2},
      :photo_resolution => {'l1' => 'photo', 'l2' => 'resolution', 'method' => :photo_resolution_api2},
      :photo_continuous => {'l1' => 'photo', 'l2' => 'continuous_rate', 'method' => :photo_continuous_api2},
      :photo_shutter_ev => {'l1' => 'photo', 'l2' => 'exposure_time', 'method' => :photo_shutter_exposure_api2},
      :photo_spot_metering => {'l1' => 'photo', 'l2' => 'spot_meter', 'method' => :photo_spot_metering_api2},
      :photo_dft_submode => {'l1' => 'photo', 'l2' => 'default_sub_mode', 'method' => :photo_default_submode_api2},
      :photo_pt => {'l1' => 'photo', 'l2' => 'protune', 'method' => :photo_protune_api2},
      :photo_pt_wb => {'l1' => 'photo', 'l2' => 'protune_white_balance', 'method' => :photo_protune_white_balance_api2},
      :photo_pt_color => {'l1' => 'photo', 'l2' => 'protune_color', 'method' => :photo_protune_color_api2},
      :photo_pt_iso => {'l1' => 'photo', 'l2' => 'protune_iso', 'method' => :photo_protune_iso_api2},
      :photo_pt_iso_min => {'l1' => 'photo', 'l2' => 'protune_iso_min', 'method' => :photo_protune_iso_min_api2},
      :photo_pt_sharp => {'l1' => 'photo', 'l2' => 'protune_sharpness', 'method' => :photo_protune_sharpness_api2},
      :photo_pt_ev => {'l1' => 'photo', 'l2' => 'protune_ev', 'method' => :photo_protune_exposure_api2},

      :photo_raw => { 'l1' => 'photo', 'l2' => 'single_raw', 'method' => :photo_raw_api2},
      :photo_wdr => { 'l1' => 'photo', 'l2' => 'single_wdr', 'method' => :photo_wdr_api2},

      :multi_photo_submode => {'l1' => 'multi_shot', 'l2' => 'current_sub_mode', 'method' => :multi_photo_current_submode_api2},
      :multi_photo_resolution => {'l1' => 'multi_shot', 'l2' => 'resolution', 'method' => :multi_photo_resolution_api2},
      :multi_photo_burst => {'l1' => 'multi_shot', 'l2' => 'burst_rate', 'method' => :multi_photo_burst_api2},
      :multi_photo_timelapse => {'l1' => 'multi_shot', 'l2' => 'timelapse_rate', 'method' => :multi_photo_timelapse_api2},
      :multi_photo_shutter_ev => {'l1' => 'multi_shot', 'l2' => 'exposure_time', 'method' => :multi_photo_shutter_exposure_api2},
      :multi_photo_nightlapse => {'l1' => 'multi_shot', 'l2' => 'nightlapse_rate', 'method' => :multi_photo_nightlapse_api2},
      :multi_photo_spot_meter => {'l1' => 'multi_shot', 'l2' => 'spot_meter', 'method' => :multi_photo_spot_metering_api2},
      :multi_photo_dft_submode => {'l1' => 'multi_shot', 'l2' => 'default_sub_mode', 'method' => :multi_photo_default_submode_api2},
      :multi_photo_pt => {'l1' => 'multi_shot', 'l2' => 'protune', 'method' => :multi_photo_protune_api2},
      :multi_photo_pt_wb => {'l1' => 'multi_shot', 'l2' => 'protune_white_balance', 'method' => :multi_photo_protune_white_balance_api2},
      :multi_photo_pt_color => {'l1' => 'multi_shot', 'l2' => 'protune_color', 'method' => :multi_photo_protune_color_api2},
      :multi_photo_pt_iso => {'l1' => 'multi_shot', 'l2' => 'protune_iso', 'method' => :multi_photo_protune_iso_api2},
      :multi_photo_pt_iso_min => {'l1' => 'multi_shot', 'l2' => 'protune_iso_min', 'method' => :multi_photo_protune_iso_min_api2},
      :multi_photo_pt_sharp => {'l1' => 'multi_shot', 'l2' => 'protune_sharpness', 'method' => :multi_photo_protune_sharpness_api2},
      :multi_photo_pt_ev => {'l1' => 'multi_shot', 'l2' => 'protune_ev', 'method' => :multi_photo_protune_exposure_api2},

      :broadcast_default_sub_mode => {'l1' => 'broadcast', 'l2' => 'default_sub_mode'},
      :broadcast_resolution => {'l1' => 'broadcast', 'l2' => 'resolution'},
      :broadcast_fps => {'l1' => 'broadcast', 'l2' => 'fps'},
      :broadcast_fov => {'l1' => 'broadcast', 'l2' => 'fov'},
      :broadcast_record_resolution => {'l1' => 'broadcast', 'l2' => 'record_resolution'},
      :broadcast_record_fps => {'l1' => 'broadcast', 'l2' => 'record_fps'},
      :broadcast_record_fov => {'l1' => 'broadcast', 'l2' => 'record_fov'},
      :broadcast_window_size => {'l1' => 'broadcast', 'l2' => 'window_size'},
      :broadcast_privacy => {'l1' => 'broadcast', 'l2' => 'privacy'},
      :broadcast_gop_size => {'l1' => 'broadcast', 'l2' => 'gop_size'},
      :broadcast_idr_interval =>{'l1' => 'broadcast', 'l2' => 'idr_interval'},
      :broadcast_bit_rate =>{'l1' => 'broadcast', 'l2' => 'bit_rate'},

      :setup_lcd_brightness => {'l1' => 'setup', 'l2' => 'lcd_brightness', 'method' => :setup_lcd_brightness_api2},
      :setup_lcd_lock => {'l1' => 'setup', 'l2' => 'lcd_lock', 'method' => :setup_lcd_lock_api2},
      :setup_lcd_auto_off => {'l1' => 'setup', 'l2' => 'lcd_sleep', 'method' => :setup_lcd_auto_off_api2},
      :setup_lcd_display => {'l1' => 'setup', 'l2' => 'lcd', 'method' => :setup_lcd_display_api2},
      :setup_orientation => {'l1' => 'setup', 'l2' => 'orientation', 'method' => :setup_orientation_api2},
      :setup_default_mode => {'l1' => 'setup', 'l2' => 'default_app_mode', 'method' => :setup_default_mode_api2},
      :setup_quick_capture => {'l1' => 'setup', 'l2' => 'quick_capture', 'method' => :setup_quick_capture_api2},
      :setup_led => {'l1' => 'setup', 'l2' => 'led', 'method' => :setup_led_api2},
      :setup_beep => {'l1' => 'setup', 'l2' => 'beep_volume', 'method' => :setup_beep_api2},
      :setup_video_format => {'l1' => 'setup', 'l2' => 'video_format', 'method' => :setup_video_format_api2},
      :setup_osd => {'l1' => 'setup', 'l2' => 'osd', 'method' => :setup_osd_api2},
      :setup_auto_off => {'l1' => 'setup', 'l2' => 'auto_power_down', 'method' => :setup_auto_off_api2},
      :setup_stream_gop_size => {'l1' => 'setup', 'l2' => 'stream_gop_size', 'method' => :setup_stream_gop_size_api2},
      :setup_stream_idr_interval => {'l1' => 'setup', 'l2' => 'stream_idr_interval', 'method' => :setup_stream_idr_interval_api2},
      :setup_stream_bit_rate => {'l1' => 'setup', 'l2' => 'stream_bit_rate', 'method' => :setup_stream_bit_rate_api2},
      :setup_stream_window_size => {'l1' => 'setup', 'l2' => 'stream_window_size', 'method' => :setup_stream_window_size_api2},
      :setup_wireless_mode => {'l1' => 'setup', 'l2' => 'wireless_mode', 'method' => :setup_wireless_mode_api2},
    }
  end

  def capture_mode_mapping_api2
    {
      "VIDEO" => "video",
      "VIDEO_TIMELAPSE" => 'video',
      "VIDEO_PIV" => 'video',
      "VIDEO_LOOPING" => 'video',
      "PHOTO" => 'photo',
      "PHOTO_CONTINUOUS" => 'photo',
      "PHOTO_NIGHT" => 'photo',
      "BURST" => 'multi_shot',
      "TIMELAPSE" => 'multi_shot',
      "NIGHTLAPSE" => 'multi_shot'
    }
  end

  def video_default_submode_api2
    {
      "VIDEO"           => "Video",
      "VIDEO_TIMELAPSE" => "Time Lapse Video",
      "VIDEO_PIV"       => "Video + Photo",
      "VIDEO_LOOPING"   => "Looping"
    }
  end

  def video_current_submode_api2
    {
      "VIDEO"           => "Video",
      "VIDEO_TIMELAPSE" => "Time Lapse Video",
      "VIDEO_PIV"       => "Video + Photo",
      "VIDEO_LOOPING"   => "Looping"
    }
  end

  def video_resolution_api2
    {
      "WVGA"        => "WVGA",
      "720"         => "720",
      "960"         => "960",
      "1080"        => "1080",
      "1440"        => "1440",
      "2.7K"        => "2.7K",
      "2.7K_FS"     => "2.7K 4:3",
      "2.7K_CIN"    => "2.7K 17:9",
      "2.7K_SUPER"  => "2.7K SuperView",
      "4K"          => "4K",
      "4K_CIN"      => "4K 4:3",
      "4K_SUPER"    => "4K SuperView",
      "1080_SUPER"  => "1080 SuperView",
      "720_SUPER"   => "720 SuperView"
    }
  end

  def video_fps_api2
    {
      "12"    => "12",
      "15"    => "15",
      "24"    => "24",
      "25"    => "25",
      "30"    => "30",
      "48"    => "48",
      "50"    => "50",
      "60"    => "60",
      "80"    => "80",
      "90"    => "90",
      "100"   => "100",
      "120"   => "120",
      "160"   => "160",
      "240"   => "240",
      "12.5"  => "12.5"
    }
  end

  def video_fov_api2
    {
      "W" => "Wide",
      "M" => "Medium",
      "N" => "Narrow",
      # New FOVs for STREAKY.
      "L" => "Linear",
      "S" => "Superview"
    }
  end

  def video_timelapse_api2
    {
      "0.5" => "0.5 Seconds",
      "1"   => "1 Second",
      "2"   => "2 Seconds",
      "5"   => "5 Seconds",
      "10"  => "10 Seconds",
      "30"  => "30 Seconds",
      "60"  => "60 Seconds"
    }
  end

  def video_looping_api2
    {
      "5"     => "5 Minutes",
      "20"    => "20 Minutes",
      "60"    => "60 Minutes",
      "120"   => "120 Minutes",
      "MAX"   => "Max"
    }
  end

  def video_piv_api2
    {
      "5"   => "1 Photo / 5 Seconds",
      "10"  => "1 Photo / 10 Seconds",
      "30"  => "1 Photo / 30 Seconds",
      "60"  => "1 Photo / 60 Seconds"
    }
  end

  def video_low_light_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def video_spot_metering_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def video_protune_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def video_protune_white_balance_api2
    {
      "AUTO"  => "Auto",
      "3000K" => "3000K",
      "5500K" => "5500K",
      "6500K" => "6500K",
      "RAW"   => "Native",
      "4000K" => "4000K",
      "4800K" => "4800K",
      "6000K" => "6000K",
    }
  end

  def video_protune_color_api2
    {
      "STANDARD"  => "GoPro Color",
      "NEUTRAL"   => "Flat",
    }
  end

  # 400, 1600, 6400
  def video_protune_iso_api2
    {
      "6400"  => "6400",
      "1600"  => "1600",
      "400"   => "400",
      "3200"  => "3200",
      "800"   => "800",
    }
  end

  def video_protune_iso_mode_api2
    {
      "MAX"   => "Max",
      "LOCK"  => "Lock",
    }
  end

  def video_protune_sharpness_api2
    {
      "HIGH"  => "High",
      "MED"   => "Medium",
      "LOW"   => "Low",
    }
  end

  def video_protune_shutter_speed_api2
    {
      "AUTO"    => "Auto",
      "1/12.5"  => "1/12.5",
      "1/15"    => "1/15",
      "1/24"    => "1/24",
      "1/25"    => "1/25",
      "1/30"    => "1/30",
      "1/48"    => "1/48",
      "1/50"    => "1/50",
      "1/60"    => "1/60",
      "1/80"    => "1/80",
      "1/90"    => "1/90",
      "1/96"    => "1/96",
      "1/100"   => "1/100",
      "1/120"   => "1/120",
      "1/160"   => "1/160",
      "1/180"   => "1/180",
      "1/192"   => "1/192",
      "1/200"   => "1/200",
      "1/240"   => "1/240",
      "1/320"   => "1/320",
      "1/360"   => "1/360",
      "1/400"   => "1/400",
      "1/480"   => "1/480",
      "1/960"   => "1/960",
    }
  end

  # -2, -1.5, ..., 1.5, 2
  def video_protune_exposure_api2
    {
      "-2.0"    => "-2.0",
      "-1.5"    => "-1.5",
      "-1.0"    => "-1.0",
      "-0.5"    => "-0.5",
      "0"       => "0.0",
      "0.5"     => "0.5",
      "1.0"     => "1.0",
      "1.5"     => "1.5",
      "2.0"     => "2.0",
    }
  end

  def video_eis_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF",
    }
  end

  def video_awf_api2
    {
      "STEREO" => "Stereo Only",
      "WIND"   => "Wind Only",
      "OFF"    => "Auto",
    }
  end

  def photo_default_submode_api2
    {
      "PHOTO"             => "Single",
      "PHOTO_CONTINUOUS"  => "Continuous",
      "PHOTO_NIGHT"       => "Night"
    }
  end

  def photo_current_submode_api2
    {
      "PHOTO"             => "Single",
      "PHOTO_CONTINUOUS"  => "Continuous",
      "PHOTO_NIGHT"       => "Night"
    }
  end

  def photo_resolution_api2
    {
      "11WIDE"  => "11MP Wide",
      "10WIDE"  => "10MP Wide",
      "8MED"    => "8MP Med",
      "5WIDE"   => "5MP Wide",
      "5MED"    => "5MP Med",
      "7WIDE"   => "7MP Wide",
      "12WIDE"  => "12MP Wide",
      "7MED"    => "7MP Med",
      "8WIDE"   => "8MP Wide",
      # These next three are for STREAKY.
      "12MED"   => "12MP Medium",
      "12NAR"   => "12MP Narrow",
      "12LIN"   => "12MP Linear",
    }
  end

  def photo_continuous_api2
    {
      "3"     => "3 Frames / Second",
      "5"     => "5 Frames / Second",
      "10"    => "10 Frames / Second",
    }
  end

  def photo_shutter_exposure_api2
    {
      "AUTO"    => "Auto",
      "2"       => "2 Seconds",
      "5"       => "5 Seconds",
      "10"      => "10 Seconds",
      "15"      => "15 Seconds",
      "20"      => "20 Seconds",
      "30"      => "30 Seconds"
    }
  end

  def photo_spot_metering_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def photo_protune_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def photo_protune_white_balance_api2
    {
      "AUTO"  => "Auto",
      "3000K" => "3000K",
      "5500K" => "5500K",
      "6500K" => "6500K",
      "RAW"   => "Native",
      "4000K" => "4000K",
      "4800K" => "4800K",
      "6000K" => "6000K",
    }
  end

  def photo_protune_color_api2
    {
      "STANDARD"  => "GoPro Color",
      "NEUTRAL"   => "Flat",
    }
  end

  # 100, 200, 400, 800
  def photo_protune_iso_api2
    {
      "800" => "800",
      "400" => "400",
      "200" => "200",
      "100" => "100"
    }
  end

  def photo_protune_iso_min_api2
    {
      "800" => "800",
      "400" => "400",
      "200" => "200",
      "100" => "100"
    }
  end

  def photo_protune_sharpness_api2
    {
      "HIGH"  => "High",
      "MED"   => "Medium",
      "LOW"   => "Low",
    }
  end

  # -2, -1.5, ..., 1.5, 2
  def photo_protune_exposure_api2
    {
      "-2.0"    => "-2.0",
      "-1.5"    => "-1.5",
      "-1.0"    => "-1.0",
      "-0.5"    => "-0.5",
      "0"       => "0.0",
      "0.5"     => "0.5",
      "1.0"     => "1.0",
      "1.5"     => "1.5",
      "2.0"     => "2.0",
    }
  end

  def photo_raw_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF",
    }
  end

  def photo_wdr_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF",
    }
  end

  def multi_photo_default_submode_api2
    {
      "BURST"       => "Burst",
      "TIMELAPSE"   => "Time Lapse",
      "NIGHTLAPSE"  => "Night Lapse"
    }
  end

  def multi_photo_current_submode_api2
    {
      "BURST"       => "Burst",
      "TIMELAPSE"   => "Time Lapse",
      "NIGHTLAPSE"  => "Night Lapse"
    }
  end

  def multi_photo_resolution_api2
    {
      "11WIDE"  => "11MP Wide",
      "10WIDE"  => "10MP Wide",
      "8MED"    => "8MP Med",
      "5WIDE"   => "5MP Wide",
      "5MED"    => "5MP Med",
      "7WIDE"   => "7MP Wide",
      "12WIDE"  => "12MP Wide",
      "7MED"    => "7MP Med",
      "8WIDE"   => "8MP Wide",
      "12MED"   => "12MP Medium",
      "12NAR"   => "12MP Narrow",
      "12LIN"   => "12MP Linear",
    }
  end

  def multi_photo_burst_api2
    {
      "3_1"   => "3 Photos / 1 Second",
      "5_1"   => "5 Photos / 1 Second",
      "10_1"  => "10 Photos / 1 Second",
      "10_2"  => "10 Photos / 2 Seconds",
      "10_3"  => "10 Photos / 3 Seconds",
      "30_1"  => "30 Photos / 1 Second",
      "30_2"  => "30 Photos / 2 Seconds",
      "30_3"  => "30 Photos / 3 Seconds",
      "30_6"  => "30 Photos / 6 Seconds",
    }
  end

  def multi_photo_timelapse_api2
    {
      "0.5" => "1 Photo / 0.5 Sec",
      "1"   => "1 Photo / 1 Sec",
      "2"   => "1 Photo / 2 Sec",
      "5"   => "1 Photo / 5 Sec",
      "10"  => "1 Photo / 10 Sec",
      "30"  => "1 Photo / 30 Sec",
      "60"  => "1 Photo / 60 Sec"
    }
  end

  # In seconds
  def multi_photo_nightlapse_api2
    {
      "4"             => "4 Seconds",
      "5"             => "5 Seconds",
      "10"            => "10 Seconds",
      "15"            => "15 Seconds",
      "20"            => "20 Seconds",
      "30"            => "30 Seconds",
      "60"            => "1 Minute",
      "120"           => "2 Minutes",
      "300"           => "5 Minutes",
      "1800"          => "30 Minutes",
      "3600"          => "60 Minutes",
      "CONTINUOUS"    => "Continuous"
    }
  end

  def multi_photo_spot_metering_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF",
    }
  end

  def multi_photo_protune_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def multi_photo_shutter_exposure_api2
    {
      "AUTO"  => "Auto",
      "2"       => "2 Seconds",
      "5"       => "5 Seconds",
      "10"      => "10 Seconds",
      "15"      => "15 Seconds",
      "20"      => "20 Seconds",
      "30"      => "30 Seconds"
    }
  end

  def multi_photo_protune_white_balance_api2
    {
      "AUTO"  => "Auto",
      "3000K" => "3000K",
      "5500K" => "5500K",
      "6500K" => "6500K",
      "RAW"   => "Native",
      "4000K" => "4000K",
      "4800K" => "4800K",
      "6000K" => "6000K",
    }
  end

  def multi_photo_protune_color_api2
    {
      "STANDARD"  => "GoPro Color",
      "NEUTRAL"   => "Flat",
    }
  end

  def multi_photo_protune_iso_api2
    {
      "800" => "800",
      "400" => "400",
      "200" => "200",
      "100" => "100"
    }
  end

  def multi_photo_protune_iso_min_api2
    {
      "800" => "800",
      "400" => "400",
      "200" => "200",
      "100" => "100"
    }
  end

  def multi_photo_protune_sharpness_api2
    {
      "HIGH"  => "High",
      "MED"   => "Medium",
      "LOW"   => "Low",
    }
  end

  # -2, -1.5, ..., 1.5, 2
  def multi_photo_protune_exposure_api2
    {
      "-2.0"    => "-2.0",
      "-1.5"    => "-1.5",
      "-1.0"    => "-1.0",
      "-0.5"    => "-0.5",
      "0"       => "0.0",
      "0.5"     => "0.5",
      "1.0"     => "1.0",
      "1.5"     => "1.5",
      "2.0"     => "2.0",
    }
  end

  #TODO - broadcast

  def setup_lcd_brightness_api2
    {
      "HIGH"  => "High",
      "MED"   => "Medium",
      "LOW"   => "Low"
    }
  end

  def setup_lcd_lock_api2
    {
      "ON" => "ON",
      "OFF" => "OFF"
    }
  end

  def setup_lcd_auto_off_api2
    {
      "0"   => "Never",
      "60"  => "1 MIN",
      "120" => "2 MIN",
      "180" => "3 MIN",
    }
  end

  def setup_lcd_display_api2
    {
      "ON" => "ON",
      "OFF" => "OFF"
    }
  end

  # In seconds
  def setup_auto_off_api2
    {
      "0"   => "NEVER",
      "60"  => "1 MIN",
      "120" => "2 MIN",
      "180" => "3 MIN",
      "300" => "5 MIN"
    }
  end

  def setup_orientation_api2
    {
      "UP"    => "Up",
      "DOWN"  => "Down",
      "AUTO"  => "Auto"
    }
  end

  def setup_default_mode_api2
    {
      "VIDEO"       => "Video",
      "PHOTO"       => "Photo",
      "MULTI_SHOT"  => "Multi-shot"
    }
  end

  def setup_led_api2
    {
      "0" => "OFF",
      "2" => "2",
      "4" => "4",
    }
  end

  def setup_beep_api2
    {
      "0"   => "OFF",
      "70"  => "70%",
      "100" => "100%",
    }
  end

  def setup_video_format_api2
    {
      "NTSC"  => "NTSC",
      "PAL"   => "PAL",
    }
  end

  def setup_osd_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def setup_quick_capture_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def setup_wireless_mode_api2
    {
      "OFF"     => "OFF",
      "APP"     => "App",
      "RC"      => "RC",
      "NETWORK" => "Network",
      "SMART"   => "Smart"
    }
  end

  def setup_stream_gop_size_api2
    {
      "DEFAULT"   => "Default",
      "3"         => "3",
      "4"         => "4",
      "8"         => "8",
      "15"        => "15",
      "30"        => "30"
    }
  end

  def setup_stream_idr_interval_api2
    {
      "DEFAULT"   => "Default",
      "1"         => "1",
      "2"         => "2",
      "4"         => "4"
    }
  end

  def setup_stream_bit_rate_api2
    {
      "250000" => "250 Kbps",
      "400000" => "400 Kbps",
      "600000" => "600 Kbps",
      "800000" => "800 Kbps",
     "1000000" => "1 Mbps",
     "1200000" => "1.2 Mbps",
     "1600000" => "1.6 Mbps",
     "2000000" => "2 Mbps",
     "2400000" => "2.4 Mbps"
    }
  end

  def setup_stream_window_size_api2
    {
      "DEFAULT" => "Default",
      "240" => "240",
      "240 3:4" => "240 3:4 Subsample",
      "240 1:2" => "240 1:2 Subsample",
      "480" => "480",
      "480 3:4" => "480 3:4 Subsample",
      "480 1:2" => "480 1:2 Subsample",
    }
  end
end # end module WifiCommands

### ROCKYPOINT UPDATES TO API2 ################################################
# We simply overwrite the hashes that are different.
# They will be pulled in the WifiCamera::initialize()
module WifiCommands_RP_api2
  def setup_default_mode_api2
    {
      "VIDEO"         => "Video",
      "VIDEO_LOOPING" => "Looping Video",
      "PHOTO"         => "Photo",
      "BURST"         => "Burst",
      "TIMELAPSE"     => "Time Lapse",
    }
  end

  def setup_led_api2
    {
      "ON"    => "ON",
      "OFF"   => "OFF",
    }
  end

  def setup_orientation_api2
    {
      "AUTO"  => "Auto",
      "UP"    => "Up",
      "DOWN"  => "Down",
    }
  end

  def setup_beep_api2
    {
      "0"   => "OFF",
      # "40"  => "40%", # Removed for phase 2
      "70"  => "70%",
      "100" => "100%",
    }
  end

  def video_low_light_api2
    {
      "ON"  => "AUTO",
      "OFF" => "OFF"
    }
  end

  def video_protune_iso_api2
    {
      "1600"  => "1600",
      "400"   => "400",
    }
  end

  def video_protune_sharpness_api2
    {
      "OFF"  => "OFF",
      "ON"   => "ON",
    }
  end


  def capture_mode_mapping_api2
    {
      "VIDEO" => "video",
      "VIDEO_LOOPING" => 'video',
      "PHOTO" => 'photo',
      "BURST" => 'multi_shot',
      "TIMELAPSE" => 'multi_shot',
    }
  end
end # module WifiCommands_RP_api2

### HALEIWA UPDATES TO API2 ################################################
# We simply overwrite the hashes that are different.
# They will be pulled in the WifiCamera::initialize()
module WifiCommands_HLWA_api2
  def setup_default_mode_api2
    {
      "VIDEO"       => "Video",
      "VIDEO_LOOPING"     => "Looping",
      "PHOTO"       => "Photo",
      "BURST"       => "Burst",
      "TIMELAPSE"   => "Time Lapse",
    }
  end

  def setup_led_api2
    {
      "BOTH"  => "Both",
      "FRONT" => "Front",
      "BACK"  => "Back",
      "OFF"   => "OFF",
    }
  end

  def setup_orientation_api2
    {
      "UP"    => "Up",
      "DOWN"  => "Down",
    }
  end

  def setup_beep_api2
    {
      "ON"    => "ON",
      "OFF"   => "OFF",
    }
  end

  def setup_lcd_sleep_api2
    {
      "0"   => "NEVER",
      "60"  => "1 MIN",
      "120" => "2 MIN",
      "180" => "3 MIN",
    }
  end

  def setup_lcd_brightness_api2
    {
      "ON"  => "ON",
      "OFF" => "OFF"
    }
  end

  def capture_mode_mapping_api2
    {
      "VIDEO" => "video",
      "VIDEO_LOOPING" => 'video',
      "PHOTO" => 'photo',
      "BURST" => 'multi_shot',
      "TIMELAPSE" => 'multi_shot',
    }
  end
end # module WifiCommands_HLWA_api2

### HIMALAYAS UPDATES TO API2 ################################################
# We simply overwrite the hashes that are different.
# They will be pulled in the WifiCamera::initialize()
module WifiCommands_HIMA_api2
  def setup_default_mode_api2
    {
      "VIDEO"       => "Video",
      "VIDEO_LOOPING"     => "Looping",
      "PHOTO"       => "Photo",
      "BURST"       => "Burst",
      "TIMELAPSE"   => "Time Lapse",
    }
  end

  def setup_led_api2
    {
      "BOTH"  => "Both",
      "FRONT" => "Front",
      "BACK"  => "Back",
      "OFF"   => "OFF",
    }
  end

  def setup_orientation_api2
    {
      "UP"    => "Up",
      "DOWN"  => "Down",
    }
  end

  def setup_beep_api2
    {
      "ON"    => "ON",
      "OFF"   => "OFF",
    }
  end

  def capture_mode_mapping_api2
    {
      "VIDEO" => "video",
      "VIDEO_LOOPING" => 'video',
      "PHOTO" => 'photo',
      "BURST" => 'multi_shot',
      "TIMELAPSE" => 'multi_shot',
    }
  end

  def video_default_submode_api2
    {
      "VIDEO"           => "Video",
      "VIDEO_LOOPING"   => "Looping"
    }
  end

  def video_current_submode_api2
    {
      "VIDEO"           => "Video",
      "VIDEO_LOOPING"   => "Looping"
    }
  end

end # module WifiCommands_HIMA_api2


