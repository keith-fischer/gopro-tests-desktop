# Important utilities for logging in the correct format
# Note: The variable "$DEBUG" is used by RUBY!  Do not use/set it!
$DBG  = ["DEBUG",   0]
$VERB = ["VERBOSE", 1]
$INFO = ["INFO",    2]
$WARN = ["WARN",    3]
$ERR  = ["ERROR",   4]
$PASS = ["PASS",    4]
$FAIL = ["FAIL",    4]
$SKIP = ["SKIP",    4]
$CONF = ["CONF",    4]

$LL_DEBUG, $LL_VERB, $LL_INFO, $LL_WARN, $LL_ERROR = 0, 1, 2, 3, 4
# Default log-level
$LOGLEVEL = $LL_INFO
# Do not use ":" in the two below str because LTP splits on ":"
$FILE_TIME_STR = "%Y-%m-%d_%H-%M-%S"
$LOG_TIME_STR = "%Y-%m-%d %H;%M;%S.%L"
# Sugarglider log file (depends on loglevel)
$LOG_FILE = nil
# Log file for all serial output
$CAMERA_LOG_FILE = nil
$LINUX_LOG_FILE = nil

# When displaying the results to the screen, color them.
# These colors are not added to the log files!
$COLOR_RESULTS = true

module LogUtils
  # Log to stdout and file (if it exists)
  # Almost everything should use ltp_log() (which calls this) instead
  def log(s)
    File.open($LOG_FILE, "a") { |f| f.puts(s) } if $LOG_FILE != nil
    if $COLOR_RESULTS
      if s.start_with?("PASS") # Light Green
        puts("\033[92m#{s}\033[0m")
      elsif s.start_with?("FAIL") # Light Red
        puts("\033[91m#{s}\033[0m")
      elsif s.start_with?("WARN") # Light Yellow
        puts("\033[40m\033[93m#{s}\033[0m")
      elsif s.start_with?("ERROR") # Light Cyan
        puts("\033[96m#{s}\033[0m")
      else
        puts(s)
      end
    else
      puts(s)
    end
    STDOUT.flush
  end

  # Generates Ambashell console log file of the form
  # /path/to/dir/YYYY-mm-dd_HH-MM-SS-ttyUSBX-amba-log.txt
  def init_amba_serial_log(dir, tc_name)
    if not (File.directory?(dir) and File.writable?(dir))
      ltp_log($ERR, "Can't access dir=#{dir}.  Make sure it exists and is writable.")
      return false
    end
    fname = "camera_log_#{tc_name}"
    $CAMERA_LOG_FILE = File.join(dir, fname)
    ltp_log($INFO, "Initialized camera serial log at #{$CAMERA_LOG_FILE}")
    return true
  end

  # Generates Linux console log file of the form
  # /path/to/dir/YYYY-mm-dd_HH-MM-SS-ttyUSBX-linux-log.txt
  def init_linux_serial_log(dir, tc_name)
    if not (File.directory?(dir) and File.writable?(dir))
      ltp_log($ERR, "Can't access dir=#{dir}.  Make sure it exists and is writable.")
      return false
    end
    fname = "linux_log_#{tc_name}"
    $LINUX_LOG_FILE = File.join(dir, fname)
    ltp_log($INFO, "Initialized Linux serial log at #{$LINUX_LOG_FILE}")
    return true
  end

  def log_amba(s)
    File.open($CAMERA_LOG_FILE, "a") { |f| f.puts(s) } if $CAMERA_LOG_FILE != nil
  end

  def log_linux(s)
    File.open($LINUX_LOG_FILE, "a") { |f| f.puts(s) } if $LINUX_LOG_FILE != nil
  end

  # To be used within the framework (Camera, models, wifi)\
  # Level is from above
  def ltp_log(level, msg)
    if [$PASS, $FAIL, $SKIP, $ERR].include?(level)
      if @tc_name != nil
        tc_str = ": #{@tc_name} "
      elsif defined? @camera and @camera.tc_name != nil
        tc_str = ": #{@camera.tc_name} "
      else
        tc_str = ""
      end
    else
      tc_str = ""
    end

    if level[1] >= $LOGLEVEL
      log("#{level[0]} #{tc_str}: #{msg}")
      #log("#{Time.now.strftime($LOG_TIME_STR)} #{level[0]} : #{msg}")
    end
  end

  def log_info(msg)
    ltp_log($INFO, msg)
  end

  def log_pass(msg="")
    ltp_log($PASS, msg)
  end

  def log_fail(msg="")
    ltp_log($FAIL, msg)
  end

  def log_skip(msg="")
    ltp_log($SKIP, msg)
  end

  def log_warn(msg)
    ltp_log($WARN, msg)
  end

  def log_error(msg)
    ltp_log($ERR,  msg)
  end

  def log_debug(msg)
    ltp_log($DBG,  msg)
  end

  def log_verb(msg)
    ltp_log($VERB, msg)
  end

  def log_conf(msg)
    ltp_log($CONF, msg)
  end

  # Regular expression string match for log lines produced above
  def ltp_re_str(level); return ("#{level[0]} : .*"); end

  def set_log_file(logfile)
    $LOG_FILE = logfile
    ltp_log($INFO, "Setting logfile to #{logfile}")
    ltp_log($INFO, "File exists!  Appending...") if File.exists?(logfile)
  end

  # Log parsing helpers
  # Should match up with ltp_log above and testcase.rb to return
  # relevant informations
  def parse_log_result(line)
    result = tc = msg = ""
    n = line.split(":")
    if n.length > 0
      result = n[0].strip()
    end
    if n.length == 2
      msg    = n[1].strip()
    elsif n.length == 3
      tc     = n[1].strip()
      msg    = n[2].strip()
    else
      #ltp_log($WARN, "Unexpected number (>2) of ':' in #{line}")
      tc     = n[1].strip()
      msg    = n[2..-1].join(":").strip()
    end
    return result, tc, msg
  end

  # Spawn a logging thread for the serial logs take by Wi-Fi cameras
  # Do not use for tests over serial camera since they need to read the
  # response and this would prevent such ability.
  # TBD: Test with debug cable and camera reset.
  def spawn_amba_logging_thread(dev)
    begin
      @serialport = SerialPort.new(dev, 115200)
    rescue StandardError => e
      ltp_log($ERR, "Unable to open serial port at #{dev}")
      ltp_log($ERR, e.to_s + e.backtrace.join("\n"))
      return false
    end
    @serial_log_thread = Thread.new {
      # Copied from serial_camera.rb
      limit = 1.0
      while true do
        resp = ""
        thr = Thread.new {
          while true do
            c = @serialport.getc
            resp << c
          end
        }
        result = thr.join(limit)
        thr.terminate
        # Remove invalid characters (happens a lot when board is reset)
        resp.encode!('UTF-16', 'UTF-8', :invalid => :replace, :replace => '')
        resp.encode!('UTF-8', 'UTF-16')
        log_amba(resp)
      end
    }
  end

  def spawn_linux_logging_thread(dev)
    begin
      @linuxport = SerialPort.new(dev, 115200)
    rescue StandardError => e
      ltp_log($ERR, "Unable to open serial port at #{dev}")
      ltp_log($ERR, e.to_s + e.backtrace.join("\n"))
      return false
    end
    @linux_log_thread = Thread.new {
      # Copied from serial_camera.rb
      limit = 1.0
      while true do
        resp = ""
        thr = Thread.new {
          while true do
            c = @linuxport.getc
            resp << c
          end
        }
        result = thr.join(limit)
        thr.terminate
        # Remove invalid characters (happens a lot when board is reset)
        resp.encode!('UTF-16', 'UTF-8', :invalid => :replace, :replace => '')
        resp.encode!('UTF-8', 'UTF-16')
        log_linux(resp)
      end
    }
  end # end def

end # end module
