# HostUtils
require 'json'
require 'open3'
require 'fileutils'
require 'net/http'
require 'serialport'
require 'socket'

require_relative 'log_utils'
require_relative 'metadata'

class Host
  include LogUtils

  attr_accessor :WIFI_LOCK
  def initialize
    @WIFI_LOCK = "/run/lock/sg_wifi"
    @status_pid = nil
  end

  def sys_exec(cmd, opts=nil)
    log_debug("Running system command: #{cmd} #{opts}")
    if opts == nil
      o, e, s = Open3.capture3(cmd)
    else
      o, e, s = Open3.capture3(cmd, opts)
    end
    log_debug("Output = #{o}")
    log_debug("Error = #{e}")
    log_debug("Status = #{s}")
    log_verb("Command (#{cmd}) returned unsucessful") if not s.success?
    return o, e, s
  end

  def valid_ipv4_addr?(ip)
    octets = ip.split(".")
    return false if octets.length != 4
    octets.each { |oct|
      return false if oct.to_i < 0 or oct.to_i > 255
    }
    return true
  end

  # Returns mask length if dest_ip is covered by dest_ip_route and mask
  # I.e. route_match("10.5.5.9", "10.0.0.0", "255.0.0.0") returns 8
  # Returns false otherwise
  def route_match(dest_ip, dest_ip_route, mask)
    # First convert to arrays of ints
    ip1 = dest_ip.split(".").map { |m| m.to_i }
    ip2 = dest_ip_route.split(".").map { |m| m.to_i }
    m = mask.split(".").map { |m| m.to_i }
    (0..3).each { |i|
      return false if (ip1[i] & m[i]) != (ip2[i] & m[i])
    }
    # Route match.  Now get the length by counting the "1"s in binary
    len = 0
    m.each { |oct|
      (0..7).each { |i|
        len += (oct >> i) & 0x01
      }
    }
    return len
  end

  # Looks up the IP of the outgoing interface for the destination IP
  # Returns true, IP on success
  # Returns false, msg on failure
  def get_system_camera_ip(dest_ip)
    cmd = "route -n"
    o, e, s = sys_exec(cmd)
    return false, e if !s.success?

    match_iface = nil
    match_len = -1
    o.each_line { |line|
      fields = line.split()
      next if !valid_ipv4_addr?(fields[0])
      dest = fields[0]
      mask = fields[2]
      iface = fields[7]
      # Look for the routing entry with the longest mask
      m = route_match(dest_ip, dest, mask)
      if (m != false and m > match_len)
        match_iface = iface
        match_len = m
      end
    }
    if match_iface != nil
      ret = get_network_ip_address(match_iface)
      log_info(
      "Using addr/mask #{ret}/#{match_len} (#{match_iface}) to reach #{dest_ip}")
      return true, ret
    else
      return false, "Unable to find interface with route to #{dest_ip}"
    end
  end

  # Returns IPv4 address of given interface name
  # Retuns false on failure
  def get_network_ip_address(interface)
    cmd = "ifconfig #{interface} | grep 'inet addr'"
    o,e,s = sys_exec(cmd)
    return false, e if !s.success?
    # Output looks like: inet addr:10.0.2.15  Bcast:10.0.2.255  Mask:255.255.255.0

    ip = o.split()[1].split(':')[1]
    if !valid_ipv4_addr?(ip)
      log_warn("IP found (#{ip}) not a valid IPv4 address")
      return false
    else
      return ip
    end
  end

  # def get_network_interfaces
  #   cmd = "ifconfig -s | awk '{print $1}'"
  #   o,e,s = Open3.capture3(cmd)

  #   if !s.success?
  #     return false, e
  #   end

  #   interfaces = o.split(' ')
  #   interfaces.delete("Iface")
  #   interfaces.delete("lo")

  #   return true, interfaces
  # end

  # def get_system_camera_ip(camera_ap)
  #   found, ret = get_network_interfaces

  #   if found
  #     ret.each {|i|
  #       found_ip, ret_ip = get_network_ip_address(i)

  #       if found_ip
  #         next if ret_ip == nil || ret_ip.empty?

  #         splitted = camera_ap.split('.')
  #         splitted.pop
  #         str = splitted.join(".")

  #         return true, ret_ip if ret_ip.include?(str)

  #       end
  #     }
  #   else
  #     return false, "Unable to find network interface"
  #   end
  #   return false, "Unable to get system address in the same subnet" unless defined?(str)
  #   return false, "Unable to get system address in the same subnet as #{str}"
  # end

  # Downloads a file listed at 'url'
  # 'local' can be one of the following:
  #   - A directory (e.g. /tmp)
  #   - A filename (e.g. downloaded.bin)
  #   - A full path (e.g. /tmp/downloaded.bin)
  #   - Empty (default download location is /tmp/[URL_FILENAME])
  # Note: If only a filename is specified it will download to /tmp by default
  # Returns the local file location if successful.  False if unsuccessful.
  def wget(url, local=nil, overwrite=false)
    log_verb("Host::wget (url=#{url}, local=#{local})")
    outfile = nil
    # Guard against undesired directory?/dirname behavior
    # By checking for nil or empty 'local' arg
    if local != nil and local != ""
      # Just got a directory name
      if File.directory?(local)
        outfile = File.join(local, File.basename(url))
        # Just got a file name (dump to /tmp)
      elsif File.dirname(local) == "."
        outfile = File.join("/tmp", local)
        # Got both directory and file
      elsif File.directory?(File.dirname(local))
        outfile = local
      end
    end
    # Last resort is to dump into /tmp
    outfile = File.join("/tmp", File.basename(url)) if outfile == nil
    # Get the file, only if necessary
    if File.file?(outfile) and overwrite == false
      log_verb("Found file locally at #{outfile}")
      return outfile
    end

    # Perform download
    cmd = "wget -q -O #{outfile} #{url}"
    start_time = Time.now
    o, e, s = sys_exec(cmd)
    elapsed = Time.now - start_time
    size = File.size(outfile)
    mbps = size*8.0/1000000/elapsed
    log_info("Downloaded #{size} bytes in %0.2fs (%0.2f mbps)" %[elapsed, mbps])

    if File.size(outfile) == 0
      log_warn("File at #{outfile} is 0 bytes. ")
      return false
    elsif s.success?
      return outfile
    else
      return false
    end
  end

  # Alternative to WGET.  Has the advantage of being able to download up to a specified
  # number of bytes.  Otherwise behaves the same.
  def curl(url, local=nil, overwrite=false, range=nil)
    log_verb(
    "Host::curl (url=#{url}, local=#{local}, overwrite=#{overwrite}, range=#{range})")
    outfile = nil
    # Guard against undesired directory?/dirname behavior
    # By checking for nil or empty 'local' arg
    if local != nil and local != ""
      # Just got a directory name
      if File.directory?(local)
        outfile = File.join(local, File.basename(url))
        # Just got a file name (dump to /tmp)
      elsif File.dirname(local) == "."
        outfile = File.join("/tmp", local)
        # Got both directory and file
      elsif File.directory?(File.dirname(local))
        outfile = local
      end
    end
    # Last resort is to dump into /tmp
    outfile = File.join("/tmp", File.basename(url)) if outfile == nil

    # Get the file, only if necessary
    if File.file?(outfile) and overwrite == false
      log_verb("Found file locally at #{outfile}")
      return outfile
    end

    # Set download range
    range_str = ""
    if range != nil
      log_verb("Only downloading bytes in range: #{range}")
      range_str = "-r #{range}"
    end

    # Perform download
    cmd = "curl #{range_str} -o #{outfile} #{url}"
    start_time = Time.now
    o, e, s = sys_exec(cmd)
    elapsed = Time.now - start_time
    size = File.size(outfile)
    mbps = size*8.0/1000000/elapsed
    log_info("Downloaded #{size} bytes in %0.2fs (%0.2f mbps)" %[elapsed, mbps])

    if File.size(outfile) == 0
      log_warn("File at #{outfile} is 0 bytes. ")
      return false
    elsif s.success?
      return outfile
    else
      return false
    end
  end

  def ssid_visible?(ssid)
    3.times {
      cmd = "sudo nmcli dev wifi list"
      o, e, s = sys_exec(cmd)
      results = o.lines.map(&:chomp)
      results.each { |line|
        if line.match(ssid) != nil
          log_verb("Matched ssid '#{ssid}' with output line #{o}")
          return true
        end
      }
      restart_wireless() if results.length <= 5 # Host Wi-Fi might be hosed
      sleep 5
    }
    return false
  end

  def restart_wireless()
    sys_exec("sudo nmcli nm wifi off")
    sleep 5
    sys_exec("sudo nmcli nm wifi on")
    sleep 5
  end

  # Returns currently connected SSID or empty string if not connected
  def get_current_ssid()
    cmd = "iwgetid -r"
    o, e, s = sys_exec(cmd)
    return o.strip()
  end

  # Returns MAC of currently connected AP or empty string if not connected
  def get_AP_mac()
    cmd = "iwgetid --ap -r"
    o, e, s = sys_exec(cmd)
    return o.strip()
  end

  # Returns IP of currently connected AP or empty string if not connected
  # Requires the mac address
  def get_ip_from_mac(mac)
    cmd = "arp -n | grep -i #{mac} | awk '{print $1}'"
    o, e, s = sys_exec(cmd)
    return o.strip
  end

  def pingable?(ip)
    cmd = "ping -c 3 -w 1 -i .3 #{ip}"
    o, e, s = sys_exec(cmd)
    #return true if s.success?
    # If even one packet makes it, we will return true
    o.split("\n").each { |line|
      result = line.match("[0-9] received")
      if result != nil
        n_rec = result[0][0].to_i
        return true if n_rec > 0
      end
    }
    return false
  end

  def curlable?(ip, ct=1, rt=1, mt=2)
    url = "http://#{ip}"
    cmd = "curl -s --connect-time #{ct} --retry #{rt} --max-time #{mt} #{url}"
    o, e, s = sys_exec(cmd)
    return s.success?
  end

  # Send the magic WOL packet in a UDP packet
  # Returns number of bytes sent should be >0 on success
  def wol(ip, mac)
    sock = UDPSocket.new
    sock.setsockopt(Socket::SOL_SOCKET, Socket::SO_BROADCAST, true)
    # Format is 0xFF 6 times followed by the MAC ADDR 16 times
    wol_pkt = "\xFF"*6 + ("\\x" + mac.split(":").join("\\x"))*16
    # log_verb("WOL packet:  #{wol_pkt}")

    # Send to the class D IPv4 broadcast address (usually 10.5.5.255)
    dest_ip = ip.split(".")[0..2].join(".") + ".255"
    dest_port = 1234 # Don't think this ever changes
    log_verb("%s - Sending WOL packet to %s:%d" \
    %[Time.now.strftime("%H:%M:%S"), dest_ip, dest_port])
    return sock.send(wol_pkt, 0, dest_ip, dest_port)
  end

  # Connects to an AP with the given ssid/password
  # returns true on success, false, otherwise
  def connect_ap(ssid, pc)
    if File.exists?("/etc/NetworkManager/system-connections/#{ssid}")
      cmd = "sudo nmcli con up id #{ssid}"
    else
      cmd = "sudo nmcli dev wifi connect #{ssid} password #{pc} --private"
    end
    o, e, s = sys_exec(cmd)
    return s.success?
  end

  def connect_camera(ssid, ip, pc)
    if ssid_visible?(ssid)
      if connect_ap(ssid, pc) == true
        sleep 8.0
        if get_current_ssid() == ssid
          if curlable?(ip, ct=1, rt=2, mt=3)
            return true
            # If all but curlable, maybe the camera needs to be awakened?
          else
            mac = get_AP_mac()
            return false if mac.length == 0
            wol(ip, mac)
            sleep 10
            return true if curlable?(ip, ct=1, rt=2, mt=3)
          end # curlable?
        end # get_current_ssid
      end # connect_ap
    end # ssid_visible?
    return false
  end # connect_camera

  def wait_for_beacons(ssid, timeout=60, interval=5)
    return true if is_raspberry_pi?() # No support on Raspberry Pi
    start_time = Time.now()
    while Time.now - start_time < timeout do
      return true if ssid_visible?(ssid)
      log_info("Looking for SSID #{ssid}... %ds/%ss" \
      %[Time.now - start_time, timeout])
      sleep interval
    end
    return false
  end

  def wait_for_wifi_camera(ip, timeout=60, interval=5, mac=nil)
    start_time = Time.now()
    while Time.now - start_time < timeout do
      wol(ip, mac) if mac != nil
      return true if pingable?(ip) # HD3/+ will respond to this
      return true if curlable?(ip) # HD4 will respond to this
      log_verb("Waiting for camera... %ds/%ss" \
      %[Time.now - start_time, timeout])
      sleep interval
    end
    return false
  end

  # Returns the 'Revision' from the build page in Jenkins
  # url = URL to the build page
  # e.g. (http://goprofwbuild1.gopro.lcl:8080/job/Banzai-Continuous/604/)
  def get_build_revision(url)
    3.times {
      r = Net::HTTP.get_response(URI.parse(url).host, URI.parse(url).path,
      URI.parse(url).port)
      return nil if r.code.to_i != 200
      # Matches "Revision</b>: ee5501e8b3ff1d378cbea1aca631d02b536778cb"
      m = r.body.match(/Revision.{46}/)
      return m[0].split()[1] if m != nil
      sleep 2.0
    }
    return nil
  end

  # Return the metadata from movie file contained in file 'f'
  # 'f' can be either a local file (e.g. /tmp/GOPR1835.MP4) or a URL
  # (e.g. http://10.5.5.9:8080/DCIM/100GOPRO/GOPR1835.MP4)!!
  def get_video_metadata(f)
    meta = VideoMetadata.new()

    # Use ffprobe for some more detailed metadata
    o, e, s = sys_exec("ffprobe -v quiet -print_format json -show_streams #{f}")
    return nil if !s.success?

    data = JSON.parse(o)
    meta.has_timecode = false
    data["streams"].each { |s|
      if s["codec_type"] == "video"
        # We have to calculate the fps ourselves
        num, den = s["avg_frame_rate"].split("/").map { |n| n.to_f }
        fps = "%0.2f" %(num/den)
        # Fill in all the instance variables
        meta.aspect_ratio       = s["display_aspect_ratio"]
        meta.video_bitrate      = (s["bit_rate"].to_f / 1000000).round(2)
        meta.colorspace         = s["pix_fmt"]
        meta.creation_time      = s["tags"]["creation_time"]
        meta.frame_rate         = fps.to_f
        meta.height             = s["height"]
        meta.width              = s["width"]
        meta.video_codec        = s["codec_name"]
        meta.profile_level      = s["level"].to_i
      elsif s["codec_type"] == "audio"
        meta.audio_channels     = s["channels"]
        meta.audio_codec        = s["codec_name"]
        meta.audio_sample_rate  = s["sample_rate"].to_i
        meta.audio_bitrate      = s["bit_rate"].to_i / 1000
      elsif s["codec_type"] == "data"
        meta.has_timecode = true if s["codec_tag_string"] == "tmcd"
        meta.timecode = s["tags"]["timecode"] if s["tags"].has_key?("timecode")
      end
    }
    return meta
  end

  # Some things are missing from the ffprobe MPEG-TS json report so
  # we have to get them other ways
  def get_mpeg_ts_metadata(f)
    meta = VideoMetadata.new()

    # Use ffprobe for some more detailed metadata
    o, e, s = sys_exec("ffprobe -print_format json -show_streams #{f}")
    return nil if not s.success?
    data = JSON.parse(o)
    meta.has_timecode = false
    data["streams"].each { |s|
      if s["codec_type"] == "video"
        # We have to calculate the fps ourselves
        num, den = s["avg_frame_rate"].split("/").map { |n| n.to_f }
        fps = "%0.2f" %(num/den)
        # Fill in all the instance variables
        meta.aspect_ratio       = s["display_aspect_ratio"]
        #meta.video_bitrate            = s["bit_rate"].to_i / 1000000
        meta.colorspace         = s["pix_fmt"]
        #meta.creation_time      = s["tags"]["creation_time"]
        meta.frame_rate         = fps.to_f
        meta.height             = s["height"]
        meta.width              = s["width"]
        meta.video_codec        = s["codec_name"]
      elsif s["codec_type"] == "audio"
        meta.audio_channels     = s["channels"]
        meta.audio_codec        = s["codec_name"]
        meta.audio_sample_rate  = s["sample_rate"].to_i
      elsif s["codec_type"] == "data"
        meta.has_timecode = true if s["codec_tag_string"] == "tmcd"
      end
    }

    #Comment out because sometimes it isn't exposed individually
    # Fill in the bitrate from the ffprobe report error stream
    # Example: Duration: 00:00:00.27, start: 7.207211, bitrate: 1001 kb/s
    #bitrate = nil
    #e.split("\n").each { |line|
    #  if line.match("bitrate")
    #    bitrate = line.split(",")[2].split(":")[1].split()[0]
    #    break
    #  end
    #}
    #meta.video_bitrate = bitrate.to_i * 1000 # In bps
    return meta
  end

  def find_next_run_dir(base_dir)
    re_run_pattern = "RUN_"
    # If the user specifies a RUN_X as the base_dir, just use that one
    return base_dir if File.basename(base_dir).match(re_run_pattern)
    # Otherwise find the next RUN_X directory in base_dir
    max_run = 0
    Dir.entries(base_dir).each() { |d|
      if File.directory?(File.join(base_dir,d)) and d.match(re_run_pattern)
        run_number = d.split("_")[1].to_i
        max_run = run_number if run_number > max_run
      end
    }
    next_run_dir = "RUN_%s" %(max_run + 1)
    return File.join(base_dir, next_run_dir)
  end

  def get_psnr(img, ref)
    log_verb("Comparing #{ref} and #{img}")
    cmd = "compare -metric PSNR #{ref} #{img} /dev/null 2>&1"
    o, e, s = sys_exec(cmd)
    return false, "Unable to get PSNR." if not s.success?
    return true, o.to_f
  end

  def get_quality(img)
    cmd = "identify -debug coder -log %e #{img} 2>&1 | awk '/Qual/ {print $2}'"
    o, e, s = sys_exec(cmd)
    return o.to_f
  end

  # Returns a hash of the image metadata
  # Uses the ImgMagick 'identify -format X' command
  # Metadata can be easily added
  # (see http://www.imagemagick.org/script/escape.php)
  def get_img_metadata(img)
    # ImgMagick format options
    filename  = "%f"
    format    = "%m"
    width     = "%w"
    height    = "%h"
    quality   = "%Q"

    format_str = [
      filename,
      format,
      width,
      height,
      quality,
    ].join(",")

    cmd = "identify -format #{format_str} #{img}"
    o, e, s = sys_exec(cmd)
    # Values are comma-separated (per format str)
    # and we remove any whitespace with chomp
    result = o.split(",").map { |a| a.chomp }
    meta = {
      :filename   => result[0],
      :format     => result[1],
      :width      => result[2].to_i,
      :height     => result[3].to_i,
      :quality    => result[4].to_i,
    }
  end

  # Copies file at src to dst
  # dst can be a file or a directory
  # returns path to the the destination file on success
  def copy_file(src, dst)
    begin
      FileUtils.cp(src, dst)
    rescue StandardError => e
      puts e.to_s
      return nil
    end
    return dst if not File.directory?(dst) # dst was a file
    return File.join(dst, File.basename(src)) # dst was a dir
  end

  def get_cksum(f)
    o, e, s = sys_exec("sum #{f}")
    return nil if not s.success?
    return o.split()[0].to_i
  end

  def cksum_equal?(a, b)
    ck1 = get_cksum(a)
    ck2 = get_cksum(b)
    if ck1 == nil or ck2 == nil
      log_warn("Unable to retrieve one of the checksums")
      return false
    end
    return ck1 == ck2
  end

  # img - image file (usually jpeg)
  # bbox - Bounding box [x, y, width, height]
  # llimit - Lower-limit of the result
  # ulimit - upper limit of the result
  def read_lcd_img(img, bbox, llimit=0.0, ulimit=5.0, thresh=98)

    # SSOCR options
    thresh = "-t #{thresh}"
    xform = "invert make_mono"
    box = "crop %s %s %s %s" %[bbox[0], bbox[1], bbox[2], bbox[3]]
    debug = "-o /tmp/ssocr.jpg"
    # Get result
    cmd = "ssocr -d -1 #{debug} #{thresh} #{xform} #{box} #{img}"
    p cmd
    o, e, s = sys_exec(cmd)
    return nil if not s.success?

    # Check the bounds of the result
    n = o.to_f
    if n == 0.0
      log_warn("Unable to cast result to float (#{o})")
      return nil
    elsif n < 0
      log_warn("Got negative value.  I can't with this (#{o})")
      return nil
    end
    # Figure out if we need to shift the digits to get within the bounds
    while n > ulimit
      n /= 10.0
    end
    while n < llimit
      n *= 10.0
    end
    if n < llimit or n > ulimit
      log_warn("Unable to fit (#{o}) in (#{llimit}, #{ulimit}).  Result = #{n}")
      return nil
    end
    return n
  end

  def expand_search(img, bbox, llimit, ulimit)
    pixels_per_step = 5
    steps = 3
    x = bbox[0]
    w = bbox[2]
    h = bbox[3]
    [98, 99].each { |thresh|
      (0..steps).each { |s|
        # Positive step
        y = bbox[1] + (s * pixels_per_step)
        new_bbox = [x, y, w, h]
        ret = read_lcd_img(img, new_bbox, llimit, ulimit, thresh)
        return new_bbox, ret if ret != nil
        # Negative step
        y = bbox[1] - (s * pixels_per_step)
        new_bbox = [x, y, w, h]
        ret = read_lcd_img(img, new_bbox, llimit, ulimit, thresh)
        return new_bbox, ret if ret != nil
      }
    }
    return nil, nil
  end

  def read_current(img)
    bbox = @current_bbox != nil ? @current_bbox : [1111, 370, 275, 160]
    llimit = 0.2
    ulimit = 1.5
    @current_bbox, current = expand_search(img, bbox, llimit, ulimit)
    return current
  end

  def read_voltage(img)
    bbox = @voltage_bbox != nil ? @voltage_bbox : [1111, 825, 275, 160]
    llimit = 3.0
    ulimit = 5.0
    @voltage_bbox, voltage = expand_search(img, bbox, llimit, ulimit)
    return voltage
  end

  def get_cam_power(cam)
    cam.delete_all_media()
    cam.set_capture_mode("PHOTO")
    cam.set_photo_resolution("5MED")
    cam.start_capture()
    sleep(3)
    img = cam.download_last_media("/tmp")
    v = read_voltage(img)
    i = read_current(img)
    log_info("Read V=#{v}, I=#{i}")
    if v == nil or i == nil
      return nil
    else
      return (i*v).round(2)
    end
  end

  def acquire_lock(lock, check_valid=true, interval=30, timeout=300)
    start_time = Time.now()
    mypid = Process.pid
    while File.exist?(lock)
      pid = File.read(lock).to_i
      return true, "Lock already owned" if pid == mypid
      if check_valid == true
        log_info("Checking if lock is still held by pid=#{pid}")
        begin
          Process.getpgid(pid)
        rescue StandardError
          log_info("PID #{pid} not found.  Acquiring the lock.")
          break
        end
      end # end check_valid
      elapsed = Time.now() - start_time
      if elapsed > timeout
        return false, "Unable to acquire lock within #{timeout}s"
      end
      log_info("Waiting #{interval}s before checking lock again.")
      sleep interval
    end # end while

    log_info("Acquiring the lock using PID=#{mypid}.")
    File.open(lock, 'w') { |f|
      f.write(mypid)
    }
    return true, "Successfully got lock"
  end

  def release_lock(lock, check_valid=true)
    if File.exist?(lock)
      if check_valid == true
        pid = File.read(lock).to_i
        mypid = Process.pid
        if pid != mypid
          log_warn("release_lock mypid=#{mypid} but lock pid=#{pid}.  Skipping")
          return false, "Lock not released"
        end
      end # end check_valid
      File.delete(lock)
      return true, "Lock released"
    end # end File.exist?
    return true, "No lock file found"
  end

  # Verifies that the serial port exists and is readable/writable
  def verify_serial_port(dev)
    doexit = false
    if not File.exist?(dev)
      log_error("Serial device #{dev} not found. Is device plugged in?")
      return false
    elsif not File.readable?(dev)
      log_error("Serial device #{dev} not readable. 'sudo chmod 666 #{dev}' ?")
      return false
    elsif not File.writable?(dev)
      log_error("Serial device #{dev} not writable. 'sudo chmod 666 #{dev}' ?")
      return false
    end
    return true
  end

  # Write a command 'cmd' to the serial device 'dev'
  def send_serial(cmd, dev, timeout=30, interval=2.0)
    start_time = Time.now()
    while (Time.now() - start_time) < timeout do
      log_verb("Sending #{cmd} command to #{dev}")
      begin
        SerialPort.open(dev, 115200) { |serialport|
          serialport.write("\r\n")
          serialport.write(cmd.chomp)
          serialport.write("\r\n")
        }
        return true
      rescue StandardError => e
        log_warn("Failed to open serial port.  Retrying in #{interval} seconds.")
        log_verb(e.to_s)
      end
      sleep interval
    end
    return false
  end

  def read_serial_resp(dev, limit=1.0)
    resp = ""
    thr = Thread.new {
      SerialPort.open(dev, 115200) { |serialport|
        while true do
          c = serialport.getc
          resp << c
        end
      }
    }
    result = thr.join(limit)
    thr.terminate
    # Remove invalid characters (happens a lot when board is reset)
    resp.encode!('UTF-16', 'UTF-8', :invalid => :replace, :replace => '')
    resp.encode!('UTF-8', 'UTF-16')
    log_amba(resp)
    return resp
  end

  def find_camera_tty(sn, dev=nil, timeout=60, interval=5.0)
    tries = 2 # tries per camera
    version_cmds = [
      "cat c:\\MISC\\version.txt", # Hawaii
      "cat d:\\MISC\\version.txt", # RP/Hal
    ]

    start_time = Time.now()
    while (Time.now() - start_time) < timeout do
      found = false
      log_verb("Searching for camera #{sn}")
      all_devs = (dev != nil) ? [dev] : Dir.glob("/dev/**/ttyUSB*")
      all_devs.each { |d|
        m = nil # will hold the match
        log_verb("Querying #{d}")
        cmd = "cat "
        (1..tries).each { |n|
          version_cmds.each { |v|
            send_serial(v, d)
            resp = read_serial_resp(d)
            m = resp.match((/serial number":"[0-9A-Z]{14}"/))
            break if m != nil
            sleep 0.5
          }
          break if m != nil
          sleep 2.0
        } # end tries
        if m != nil
          serialno = m[0].split(":")[1][1...-1]
          log_verb("#{d}: #{serialno}")
          found = (serialno == sn)
        end
        return d if found
        sleep interval
      } # end devices
    end # end while
    return false, "Timed out without matching #{sn} to a TTY"
  end

  # Spawn a process that requests the 'status' of the camera every 0.25s
  def spawn_status_process(url)
    cmd = "while /bin/true; do curl -s #{url} > /dev/null; sleep 0.25; done"
    @status_pid = fork {
      exec(cmd)
    }
    log_info("Process #{@status_pid} spawned to constantly query status")
  end

  def kill_status_process()
    if @status_pid != nil
      Process.kill("KILL", @status_pid)
      log_info("Status process #{@status_pid} killed.")
    else
      log_info("Not killing status process due to null pid")
    end
  end

  def is_raspberry_pi?()
    log_info("#{Time.now} Checking for Raspberry PI...")
    cmd = "cat /etc/issue"
    o,e,s = sys_exec(cmd)
    if (o.include?("Raspbian"))
      log_verb("ON a Raspberry PI host")
      return true
    else
      return false
    end
  end

  def bounce_wifi()
    if is_raspberry_pi?
      log_info("#{Time.now} BOUNCING wlan0 on raspberry pi!")
      sys_exec("sudo /sbin/ifdown wlan0")
      sys_exec("sudo /sbin/ifup wlan0")
    else
      log_info("Skipping bouncing the Wi-Fi on non-Raspbian system")
    end
  end

  # Extracts a single frame from an MP4 file using FFMpeg
  # Can optionally seek to a position in the video (in seconds)
  # extract_frame("infile.MP4", "outfile.MP4", seek=0.5, overwrite=true)
  # Returns true on success and false on failure
  def extract_frame(infile, outfile, seek=nil, overwrite=false)
    if File.exists?(outfile)
      if overwrite == true
        log_info("Overwriting #{outfile}")
        File.delete(outfile)
      else
        log_warn("#{outfile} already exists and overwrite == false")
        return false
      end
    end
    seek_str = (seek == nil) ? "" : "-ss #{seek}"
    cmd = "ffmpeg -nostats %s -i %s -vframes 1 -f image2 %s" \
    %[seek_str, infile, outfile]
    o, e, s = sys_exec(cmd)
    return s.success?
  end

  # Flips an image vertically via the "convert" command
  # If no outfile is given, the infile will be flipped in-place
  # If the outfile is given and already exists it will be overwritten (with a warning)
  def flip_image(infile, outfile=nil, quiet=false)
    if outfile != nil
      if File.exists?(outfile) and quiet == false
        log_warn("#{outfile} will be overwritten")
      end
    else
      outfile = infile
    end
    cmd = "convert #{infile} -flip #{outfile}"
    o, e, s = sys_exec(cmd)
    return s.success?
  end

  def rmdir(d)
    log_info("Removing directory #{d} before creating again")
    begin
      FileUtils::rm_rf(d)
    rescue StandardError => e
      log_warn("Unable to remove directory #{d}. #{e.to_s}")
      return false
    end
    return true
  end

  def mkdir(d, clear=true)
    if File.exists?(d)
      if clear == true
        ret = rmdir(d)
        return false if ret == false
      else
        log_warn("File/Dir #{d} already exists and clear=false. Not creating")
        return false
      end
    end
    log_info("Creating directory #{d}")
    begin
      FileUtils::mkdir_p(d)
    rescue StandardError => e
      log_warn("Unable to create directory #{d}. #{e.to_s}")
      return false
    end
    return true
  end

  def play_audio(file)
    cmd = is_raspberry_pi? ? "omxplayer #{file}" : "aplay #{file}"
    o, e, s = sys_exec(cmd)
    return s.success?
  end

end # end Host class

if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  #test_public_ip = "8.8.8.8"
  #test_file_url = "http://goprofwbuild1.gopro.lcl/builds/Uluwatu/HD3.10.00.03.zip"
  #cam_ip = "10.5.5.9"
  #h = Host.new
  #h.pingable?("8.8.8.8")
  #p h.wget(test_file_url, "/tmp")
  #p h.wget(test_file_url, "tmpfile2")
  #p h.wget(test_file_url, "/tmp/tmpfile")
  #p h.wget(test_file_url)
  #p h.wait_for_camera(cam_ip)
  #require 'pp'; pp h.get_video_metadata("/media/sf_vbox-shared/G0261629.MP4")
  h = Host.new
  p h.get_routing_interface("10.5.5.9")
  # p h.cksum_equal?("/tmp/camera_firmware-0e0c8952.bin", "/tmp/camera_firmware-0e0c8952.bin")
  # p h.cksum_equal?("/tmp/camera_firmware-0e0c8952.bin", "/tmp/camera_firmware-dca2be59.bin")
  #p h.get_build_revision("http://goprofwbuild1.gopro.lcl:8080/job/Banzai-Continuous/lastSuccessfulBuild/")
end
