# multimeter.rb
# A wrapper class for getting basically anything you need to know about a BK390A multimeter.
# Quick Start Guide: require_relative '../tools/multimeter'; Multimeter.new(<device_name>).display
# Please make sure that the multimeter is on and set to the right mode.
# Please push the button "RS232" until "RS232" appears on the display.

class Multimeter # BK390A
require 'serialport'

  attr_accessor :battery_warning_enabled, :rs232_warning_enabled
  # These return strings.
  attr_reader :range, :function, :digit3, :digit2, :digit1, :digit0, :units
  #These return booleans.
  attr_reader :sign, :battery, :overload, :pmax, :pmin, :vahz, :ac, :dc, :auto, :apo

  def put_rs232_msg()
    if @rs232_warning_enabled
      puts "Device was found, but no data was read. Try pressing the RS232 button until RS232 appears on the display."
    end
  end

  def initialize(device="/dev/ttyUSB1",
                 baud_rate=2400,
                 data_bits=7,
                 stop_bits=1,
                 parity=SerialPort::ODD)
    @device = device
    @baud_rate = baud_rate
    # We could save the settings and create a new serial port each read.
    @sp = SerialPort.new(@device, @baud_rate, data_bits, stop_bits, parity)
    @sp.read_timeout=(1000) # Give users access to this setting?
    #sleep(2.0) # If you have issues with it, maybe allow time for serial port to initialize?
    no_reading()
    @battery_warning_enabled = true # Disable?
    @rs232_warning_enabled   = true # Disable?
  end # initialize

  # Called whenever a reading fails. Resets status values to nil.
  def no_reading()
    @range=nil
    @function=nil
    @sign=nil
    @digit3=nil
    @digit2=nil
    @digit1=nil
    @digit0=nil
    @battery=nil
    @overload=nil
    @pmax=nil
    @pmin=nil
    @vahz=nil
    @ac=nil
    @dc=nil
    @auto=nil
    @apo=nil
    @format=nil
    @units=nil
  end

  # Read everything out of the buffer so that the next get_reading()
  # displays current information.
  def clear_read_buffer(limit=1.0)
    # resp = ""
    thr = Thread.new {
      while true do
        c = @sp.getc
        # resp << c
      end
    }
    result = thr.join(limit)
    thr.terminate
    return true
  end

  # Does a new reading.
  # Returns a string of the four digits on the display if it can.
  # Returns false if overload.
  # Returns nil on failed read.
  def digits()
    ret = update()
    put_rs232_msg if ret == nil
    return ret unless ret
    return "#{@digit3}#{@digit2}#{@digit1}#{@digit0}"
  end

  # Does a new reading.
  # Returns a string of the actual value displayed, always including sign, digits, decimal point, and units
  # Returns false on overload.
  # Returns nil on failed read.
  def display()
    ret = update()
    put_rs232_msg if ret == nil
    return ret unless ret
    ret = ""
    ret += "+" unless @sign
    ret += "-" if @sign
    ret += @format.gsub(/[Q]/, @digit3).gsub(/[L]/, @digit2).gsub(/[S]/, @digit1).gsub(/[T]/, @digit0)
    return ret
  end

  # Does the same thing as display(), but returns the value as a number, without units.
  def value()
    dis = display()
    return dis unless dis
    return dis.gsub(/[\+a-zA-Z]/, "").to_f
  end

  # This is the same as value()
  def get_reading()
    value()
  end

  # Tries to read the multimeter, and sets values accordingly.
  # Will also print a warning if @battery_warning_enabled && @battery (true indicates low battery).
  # Returns true if read succeeds, false if succeeds but overloaded, otherwise nil.
  def update()
    # Records are 11 bytes long, so we read twice that to ensure we get at least one full record.
    # This is because we could start reading in the middle of a byte.
    values = @sp.read(22)
    (no_reading; return nil) unless values
    byte_str = values.unpack("B*")[0]
#    puts "byte_str: #{byte_str}"
    offset = byte_str.rindex("0000110100001010") # "\r\n"
#    puts "offset: #{offset}"
    (no_reading; return nil) unless offset
    record = byte_str.slice((offset-72)...(offset))
    # Bail if the record found isn't long enough?
#    puts "    10: 000000000011111111112222222222333333333344444444445555555555666666666677"
#    puts "     1: " + "0123456789"*7 + "01"
#    puts "  Info:    range  digit3  digit2  digit1  digit0   funct  status option1 option2"
#    puts "  Mask: " + "0011DDDD"*9
#    puts "Record: #{record}" # Yeah!
    # This isn't elegant. Oh well.
    @digit3 = record.slice(12...16).to_i(2).to_s
    @digit2 = record.slice(20...24).to_i(2).to_s
    @digit1 = record.slice(28...32).to_i(2).to_s
    @digit0 = record.slice(36...40).to_i(2).to_s
    judge     = record[52] == "1" # Used to determine function only.
    @sign     = record[53] == "1"
    @battery  = record[54] == "1" # Low Battery
    @overload = record[55] == "1"
    @pmax     = record[60] == "1"
    @pmin     = record[61] == "1"
    @vahz     = record[63] == "1"
    @dc       = record[68] == "1"
    @ac       = record[69] == "1" 
    @auto     = record[70] == "1" # Automatic Mode
    @apo      = record[71] == "1" # Auto Power Off
    function_key = record.slice(44...48)
    # Could move this to a place where it's not redefined each time.
    function_hash = {
      "1011" => "Voltage",
      "1101" => "uA Current",
      "1001" => "mA Current",
      "1111" => "A Current",
      "0011" => "Ohms", # Better that an Omega symbol in the specs, I guess?
      "0101" => "Continuity",
      "0001" => "Diode",
      "0110" => "Capacitance",
      "1110" => "ADP0",
      "1100" => "ADP1",
      "1000" => "ADP2",
      "1010" => "ADP3"
    }
    if function_key == "0010"
      if judge
        @function = "RPM"
      else
        @function = "Frequency"
      end
    elsif function_key == "0100"
      if judge
        @function = "Temperature (C)"
      else
        @function = "Temperature (F)"
      end
    else
      @function = function_hash[function_key]
    end
    range_index = record.slice(4...8).to_i(2)
#    puts "range_index: #{range_index}"
    # Could move this somewhere so it's not redefined each time too.
    # Like a static class variable. Do that, would you?
    # If you want to add some units that use the characters 'Q', 'L', 'S', or 'T', I'm sorry. So, so sorry.
    format_hash = {
      "Voltage" => ["QLS.TmV","Q.LSTV","QL.STV","QLS.TV","QLSTV"],
      "uA Current" => ["QLS.TuA","QLSTuA"],
      "mA Current" => ["QL.STmA","QLS.TmA"],
      "A Current" => ["QL.STA"],
      "Ohms" => ["QLS.TOhms","Q.LSTKOhms","QL.STKOhms","QLS.TKOhms","Q.LSTMOhms","QL.STMOhms"],
      "Continuity" => [],
      "Diode" => [],
      "Capacitance" => ["Q.LSTnF","QL.STnF","QLS.TnF","Q.LSTuF","QL.STuF","QLS.TuF","Q.LSTmF","QL.STmF"],
      "ADP0" => [],
      "ADP1" => [],
      "ADP2" => [],
      "ADP3" => [],
      "RPM" => ["QL.STKRPM","QLS.TKRPM","Q.LSTMRPM","QL.STMRPM","QLS.TMRPM","QLSTMRPM"],
      "Frequency" => ["Q.LSTKHz","QL.STKHz","QLS.TKHz","Q.LSTMHz","QL.STMHz","QLS.TMHz"],
      "Temperature (C)" => ["QLSTC"],
      "Temperature (F)" => ["QLSTF"]
    }
    format_array = format_hash[@function]
    if range_index < format_array.length
      @format = format_array[range_index]
    else
      @format = "QLST" # This is sort of a hack. No decimal? No units? Specs weren't forthcoming...
    end
    @range = @format.gsub(/[Q]/, "4").gsub(/[LST]/, "0")
    @units = @format.gsub(/[QLST\.]/, "")
    if @battery_warning_enabled and @battery
      puts "WARNING: The 9V battery inside the multimeter is running low."
    end
    return !@overload
  end

  def cleanup
    @sp.close
  end # cleanup

  def ltp_log(to_stream, message)
    puts message
  end # ltp_log

end # Multimeter

if __FILE__ == $0
  (puts "Please specify the device name:\n\truby multimeter.rb <device_name>"; exit 1) unless ARGV[0]
  begin
    @meter = Multimeter.new(ARGV[0])
    # Only these three actions cause the multimeter to be read and values updated.
    puts "    display: #{@meter.display}"
    puts "     digits: #{@meter.digits}"
    puts "get_reading: #{@meter.get_reading}"
    # All other actions reference data from the last valid read.
    puts "   Function: #{@meter.function}"
    puts "      Units: #{@meter.units}"
    puts "      Range: #{@meter.range}"
    puts "Low Battery: #{@meter.battery}"
    puts "   Overload: #{@meter.overload}"
    # Other options are possible, but these are the most interesting. :D
  rescue StandardError => e
    puts "ERROR: #{e.to_s}"
    puts e.backtrace.join("\n")
  ensure
    @meter.cleanup() if @meter != nil
  end
end

