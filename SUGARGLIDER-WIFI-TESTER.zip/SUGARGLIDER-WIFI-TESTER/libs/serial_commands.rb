# Module to hold hashes for well-formed serial commands
# These are well-formed in the following sense
#  - Have :set and :get commands
#  - val in cmd[key] => val is matched in cmd[:get] response
# Some exceptions are in here (video_record).  Might remove later.
module SerialCommands

  ##################################################################
  # VIDEO MODE
  ##################################################################
  def vid_res
    {
      :set          => 't api video res',
      :get          => 't api video res',
      'WVGA'        => 'wvga',
      '720'         => '720',
      '960'         => '960',
      '1080'        => '1080',
      '1440'        => '1440',
      '2.7K'        => '2.7k',
      '4K'          => '4k',
      '2.7K_FS'     => '2.7k_4:3',  # FS=Fullscreen (4:3)
      '2.7K_CIN'    => '2.7k_17:9',
      '4K_CIN'      => '4k_17:9',
      '1080_SUPER'  => '1080s',
      '720_SUPER'   => '720s',
      '2.7K_SUPER'  => '2.7ks',
      '4K_SUPER'    => '4ks',
    }
  end

  def fps
    {
      :set  => 't api video fps',
      :get  => 't api video fps',
      12    => 12,
      12.5  => 12.5,
      15    => 15,
      24    => 24,
      25    => 25,
      30    => 30,
      48    => 48,
      50    => 50,
      60    => 60,
      80    => 80,  # Note: Not in current two-letter command set!
      90    => 90,  # Note: Not in current two-letter command set!
      100   => 100,
      120   => 120,
      240   => 240
    }
  end

  def decode_fps
  end

  def fov
    {
      :set  => 't api video fov',
      :get  => 't api video fov',
      'W'   => 'wide',
      'M'   => 'medium',
      'N'   => 'narrow',
      'S'   => 'superview'
    }
  end
  def decode_fov
  end

  def mode
    {
      :set        => 't api app mode',
      :get        => 't api app mode',
      'VIDEO'             => 'video',
      'PHOTO'             => 'photo',
      'MULTI_SHOT'        => 'multi_shot',
      'BROADCAST'         => 'broadcast',
      'PLAYBACK'          => 'playback',
      'SETTINGS'          => 'setup',
      'FW_UPDATE'         => 'fwupdate',
      'MTP'               => 'usb_mtp',
      'SOS'               => 'sos',
    }
  end

  # Modes are flattened from mode/sub-mode
  def mode_sub_mode
    {
      :set        => 't api app mode_sub_mode',
      :get        => 't api app mode_sub_mode',
      'VIDEO'             => 'video video',
      'VIDEO_TIMELAPSE'   => 'video timelapse',
      'VIDEO_PIV'         => 'video video_photo',
      'VIDEO_LOOPING'     => 'video looping',
      'PHOTO'             => 'photo single',
      'PHOTO_CONTINUOUS'  => 'photo continuous',
      'PHOTO_NIGHT'       => 'photo night_photo',
      'BURST'             => 'multi_shot burst',
      'TIMELAPSE'         => 'multi_shot timelapse',
      'NIGHTLAPSE'        => 'multi_shot nightlapse',
      'BROADCAST_RECORD'  => 'broadcast record',
    }
  end

  def video_sub_mode
    {
      #:set          => 't api video sub_mode',
      #:get          => 't api video sub_mode',
      :set          => 't api app sub_mode',
      :get          => 't api app sub_mode',
      'VIDEO'       => 'video',
      'TIME_LAPSE'  => 'timelapse',
      'PIV'         => 'video_photo',
      'LOOPING'     => 'looping',
    }
  end

  def video_def_sub_mode
    {
      :set          => 't api video default_sub_mode',
      :get          => 't api video default_sub_mode',
      'VIDEO'       => 'video',
      'TIME_LAPSE'  => 'timelapse',
      'PIV'         => 'video_photo',
      'LOOPING'     => 'looping',
    }
  end

  def video_record
    {
      :set          => 't api video',
      'START'       => 'record_start',
      'STOP'        => 'record_stop',
    }
  end

  # Photo in video
  def piv
    {
      :set  => 't api video piv',
      :get  => 't api video piv',
      'OFF' => 'off',
      5     => '5sec',
      10    => '10sec',
      30    => '30sec',
      60    => '60sec',
    }
  end

  def video_looping
    {
      :set  => 't api video looping',
      :get  => 't api video looping',
      #    'OFF' => 'off',
      5     => '5min',
      20    => '20min',
      60    => '60min',
      120   => '120min',
      'MAX' => 'max',
    }
  end

  def video_timelapse_rate
    {
      :set  => 't api video timelapse_rate',
      :get  => 't api video timelapse_rate',
      0.5   => '0.5sec',
      1     => '1sec',
      2     => '2sec',
      5     => '5sec',
      10    => '10sec',
      30    => '30sec',
      60    => '60sec',
    }
  end

  def low_light
    {
      :set    => 't api video low_light',
      :get    => 't api video low_light',
      'OFF'   => 'off',
      'ON'    => 'on',
    }
  end

  def spot_metering
    {
      :set    => 't api video spot_meter',
      :get    => 't api video spot_meter',
      'OFF'   => 'off',
      'ON'    => 'on',
    }
  end

  def video_protune
    {
      :set  => 't api video protune',
      :get  => 't api video protune',
      'OFF' => 'off',
      'ON'  => 'on',
    }
  end

  # For compatibility
  def protune
    video_protune
  end

  def white_balance
    {
      :set    => 't api video protune_white_balance',
      :get    => 't api video protune_white_balance',
      'auto'  => 'auto',
      '3000k' => '3000k',
      '5500k' => '5500k',
      '6500k' => '6500k',
      'native'   => 'native'
    }
  end

  def color
    {
      :set    => 't api video protune_color',
      :get    => 't api video protune_color',
      'STANDARD'  => 'gopro_color',
      'NEUTRAL'   => 'flat',
    }
  end

  def iso
    {
      :set    => 't api video protune_iso',
      :get    => 't api video protune_iso',
      6400    => 6400,
      3200    => 3200,
      1600    => 1600,
      800     => 800,
      400     => 400
    }
  end

  def sharpness
    {
      :set    => 't api video protune_sharpness',
      :get    => 't api video protune_sharpness',
      'HIGH'  => 'high',
      'MED'   => 'medium',
      'LOW'   => 'low',
    }
  end

  # <-2, >2 not supported by t api commands
  def exposure
    {
      :set    => 't api video protune_ev',
      :get    => 't api video protune_ev',
      -2.0    => '-2',
      -1.5    => '-1.5',
      -1.0    => '-1',
      -0.5    => '-0.5',
      0       => '0',
      0.5     => '+0.5',
      1.0     => '+1',
      1.5     => '+1.5',
      2.0     => '+2'
    }
  end

  def video_eis
    {
      :set  => 't api video eis',
      :get  => 't api video eis',
      :has  => 't api video eis_available', # output: "yes"
      'ON'  => 'on',
      'OFF' => 'off',
    }
  end

  def video_awf
    {
      :set     => 't api audio audio_option',
      :get     => 't api audio audio_option',
      'OFF'    => 'auto',
      'WIND'   => 'wind_noise_reduction',
      'STEREO' => 'stereo',
    }
  end

  ##################################################################
  # PHOTO MODE
  ##################################################################
  def photo_sub_mode
    {
      #:set          => 't api photo sub_mode',
      #:get          => 't api photo sub_mode',
      :set          => 't api app mode_sub_mode',
      :get          => 't api app mode_sub_mode',
      'SINGLE'      => 'photo single',
      'CONTINUOUS'  => 'photo continuous',
      'NIGHT'       => 'photo night_photo',
    }
  end

  def photo_def_sub_mode
    {
      :set          => 't api photo default_sub_mode',
      :get          => 't api photo default_sub_mode',
      'SINGLE'      => 'single',
      'CONTINUOUS'  => 'continuous',
      'NIGHT'       => 'night_photo',
    }
  end

  def photo_res
    {
      :set      => 't api photo res',
      :get      => 't api photo res',
      '5MED'    => '5mp_medium',
      '7MED'    => '7mp_medium',
      '7WIDE'   => '7mp_wide',
      '12WIDE'  => '12mp_wide',
    }
  end

  def sps
    {
      :set  => 't api photo continuous_rate',
      :get  => 't api photo continuous_rate',
      3     => '3/1sec',
      5     => '5/1sec',
      10    => '10/1sec',
    }
  end

  def photo_exp
    {
      :set  => 't api photo protune_shutter_exposure',
      :get  => 't api photo protune_shutter_exposure',
      'AUTO' => 'auto',
      10    => '10sec',
      15    => '15sec',
      20    => '20sec',
      30    => '30sec',
    }
  end

  def photo_spot
    {
      :set  => 't api photo spot_meter',
      :get  => 't api photo spot_meter',
      'ON'  => 'on',
      'OFF' => 'off',
    }
  end

  def photo_protune
    {
      :set  => 't api photo protune',
      :get  => 't api photo protune',
      'OFF' => 'off',
      'ON'  => 'on',
    }
  end

  def photo_white_balance
    {
      :set    => 't api photo protune_white_balance',
      :get    => 't api photo protune_white_balance',
      'AUTO'  => 'auto',
      '3000K' => '3000k',
      '5500K' => '5500k',
      '6500K' => '6500k',
      'RAW'   => 'native',
    }
  end

  def photo_color
    {
      :set    => 't api photo protune_color',
      :get    => 't api photo protune_color',
      'STANDARD'  => 'gopro_color',
      'NEUTRAL'   => 'flat',
    }
  end

  def photo_iso
    {
      :set    => 't api photo protune_iso',
      :get    => 't api photo protune_iso',
      100     => 100,
      200     => 200,
      400     => 400,
      800     => 800,
    }
  end

  def photo_sharpness
    {
      :set    => 't api photo protune_sharpness',
      :get    => 't api photo protune_sharpness',
      'HIGH'  => 'high',
      'MED'   => 'medium',
      'LOW'   => 'low',
    }
  end

  # <-2, >2 not supported by t api commands
  def photo_protune_exposure
    {
      :set    => 't api photo protune_ev',
      :get    => 't api photo protune_ev',
      -2.0    => '-2',
      -1.5    => '-1.5',
      -1.0    => '-1',
      -0.5    => '-0.5',
      0       => '0',
      0.5     => '+0.5',
      1.0     => '+1',
      1.5     => '+1.5',
      2.0     => '+2',
    }
  end

  def photo_capture
    {
      :set          => 't api photo',
      'START'       => 'capture_start',
      'STOP'        => 'capture_stop',
    }
  end

  def photo_raw
    {
      :set  => 't api photo raw',
      'ON'  => 'on',
      'OFF' => 'off'
    }
  end

  def photo_wdr
    {
      :set  => 't api photo wdr',
      'ON'  => 'on',
      'OFF' => 'off'
    }
  end

  ##################################################################
  # MULTI-SHOT
  ##################################################################
  def multi_sub_mode
    {
      #:set          => 't api multi_shot sub_mode',
      #:get          => 't api multi_shot sub_mode',
      :set          => 't api app sub_mode',
      :get          => 't api app sub_mode',
      'BURST'       => 'burst',
      'TIME_LAPSE'  => 'timelapse',
      'NIGHT_LAPSE' => 'nightlapse',
    }
  end

  def multi_def_sub_mode
    {
      :set          => 't api multi_shot default_sub_mode',
      :get          => 't api multi_shot default_sub_mode',
      'BURST'       => 'burst',
      'TIME_LAPSE'  => 'timelapse',
      'NIGHT_LAPSE' => 'nightlapse',
    }
  end

  def multi_res
    {
      :set      => 't api multi_shot res',
      :get      => 't api multi_shot res',
      '5MED'    => '5mp_medium',
      '7MED'    => '7mp_medium',
      '7WIDE'   => '7mp_wide',
      '12WIDE'  => '12mp_wide',
    }
  end

  def burst
    {
      :set    => 't api multi_shot burst_rate',
      :get    => 't api multi_shot burst_rate',
      '3_1'   => '3/1sec',
      '5_1'   => '5/1sec',
      '10_1'  => '10/1sec',
      '10_2'  => '10/2sec',
      '10_3'  => '10/3sec',
      '30_1'  => '30/1sec',
      '30_2'  => '30/2sec',
      '30_3'  => '30/3sec',
    }
  end

  def time_lapse
    {
      :set  => 't api multi_shot timelapse_rate',
      :get  => 't api multi_shot timelapse_rate',
      0.5   => '0.5sec',
      1     => '1sec',
      2     => '2sec',
      5     => '5sec',
      10    => '10sec',
      30    => '30sec',
      60    => '60sec',
    }
  end

  def night_lapse
    {
      :set  => 't api multi_shot nightlapse_rate',
      :get  => 't api multi_shot nightlapse_rate',
      # 2     => '2sec',
      # 5     => '5sec',
      10    => '10sec',
      15    => '15sec',
      20    => '20sec',
      30    => '30sec',
      60    => '60sec',
      120   => '2min',
      300   => '5min',
      1800  => '30min',
      3600  => '60min',
    }
  end

  def multi_spot
    {
      :set  => 't api multi_shot spot_meter',
      :get  => 't api multi_shot spot_meter',
      'ON'  => 'on',
      'OFF' => 'off',
    }
  end

  def multi_protune
    {
      :set  => 't api multi_shot protune',
      :get  => 't api multi_shot protune',
      'OFF' => 'off',
      'ON'  => 'on',
    }
  end

  def multi_exp
    {
      :set  => 't api photo protune_shutter_exposure',
      :get  => 't api photo protune_shutter_exposure',
      'AUTO' => 'auto',
      10    => '10sec',
      15    => '15sec',
      20    => '20sec',
      30    => '30sec',
    }
  end

  def multi_white_balance
    {
      :set    => 't api multi_shot protune_white_balance',
      :get    => 't api multi_shot protune_white_balance',
      'AUTO'  => 'auto',
      '3000K' => '3000k',
      '5500K' => '5500k',
      '6500K' => '6500k',
      'RAW'   => 'native',
    }
  end

  def multi_color
    {
      :set    => 't api multi_shot protune_color',
      :get    => 't api multi_shot protune_color',
      'STANDARD'  => 'gopro_color',
      'NEUTRAL'   => 'flat',
    }
  end

  def multi_iso
    {
      :set    => 't api multi_shot protune_iso',
      :get    => 't api multi_shot protune_iso',
      100     => 100,
      200     => 200,
      400     => 400,
      800     => 800,
    }
  end

  def multi_sharpness
    {
      :set    => 't api multi_shot protune_sharpness',
      :get    => 't api multi_shot protune_sharpness',
      'HIGH'  => 'high',
      'MED'   => 'medium',
      'LOW'   => 'low',
    }
  end

  # <-2, >2 not supported by t api commands
  def multi_protune_exposure
    {
      :set    => 't api multi_shot protune_ev',
      :get    => 't api multi_shot protune_ev',
      -2.0    => '-2',
      -1.5    => '-1.5',
      -1.0    => '-1',
      -0.5    => '-0.5',
      0       => '0',
      0.5     => '+0.5',
      1.0     => '+1',
      1.5     => '+1.5',
      2.0     => '+2',
    }
  end

  def multi_capture
    {
      :set          => 't api multi_shot',
      'START'       => 'capture_start',
      'STOP'        => 'capture_stop',
    }
  end

  ##################################################################
  # SETUP/SETTINGS
  ##################################################################
  def lcd_brightness
    {
      :set    => 't api setup lcd_brightness',
      :get    => 't api setup lcd_brightness',
      'HIGH'  => 'high',
      'MED'   => 'medium',
      'LOW'   => 'low',
    }
  end

  def lcd_auto_off
    {
      :set    => 't api setup lcd_auto_off',
      :get    => 't api setup lcd_auto_off',
      'OFF'   => 'never',
      60      => '1min',
      120     => '2min',
      180     => '3min',
    }
  end

  def lcd_lock
    {
      :set    => 't api setup lcd_lock',
      :get    => 't api setup lcd_lock',
      'OFF'   => 'off',
      'ON'    => 'on',
    }
  end

  def orientation
    {
      :set    => 't api setup orientation',
      :get    => 't api setup orientation',
      'AUTO'  => 'auto',
      'UP'    => 'up',
      'DOWN'  => 'down',
    }
  end

  def default_mode
    {
      :set  => 't api setup default_app_mode',
      :get  => 't api setup default_app_mode',
      'VIDEO'       => 'video',
      'PHOTO'       => 'photo',
      'MULTI_SHOT'  => 'multi_shot',
      'BROADCAST'   => 'broadcast',
      'PLAYBACK'    => 'playback',
      'SETTINGS'    => 'setup',
    }
  end

  def quick_capture
    {
      :set  => 't api setup quick_capture',
      :get  => 't api setup quick_capture',
      'OFF' => 'off',
      'ON'  => 'on',
    }
  end

  def obm
    {
      :set  => 't api setup quick_capture',
      :get  => 't api setup quick_capture',
      'ON'  => 'on',
      'OFF' => 'off',
    }
  end

  def led
    {
      :set => 't api setup led',
      :get => 't api setup led',
      0    => 'off',
      2    => 2,
      4    => 4,
    }
  end

  def beep_sound
    {
      :set  => 't api setup beep_volume',
      :get  => 't api setup beep_volume',
      '0'     => 'off',
      '70'    => '70%',
      '100'   => '100%',
    }
  end

  def video_mode
    {
      :set    => 't api setup video_format',
      :get    => 't api setup video_format',
      'NTSC'  => 'ntsc',
      'PAL'   => 'pal',
    }
  end

  def osd
    {
      :set  => 't api setup osd',
      :get  => 't api setup osd',
      'ON'  => 'on',
      'OFF' => 'off',
    }
  end

  def auto_off
    {
      :set    => 't api setup auto_power_down',
      :get    => 't api setup auto_power_down',
      'OFF'   => 'never',
      60      => '1min',
      120     => '2min',
      180     => '3min',
    }
  end

  def apply_settings
    { :set => 't api app apply' }
  end

  def battery_level
    { :get => 't api system batt_level' }
  end

  def temperature
    {
      get: 't api system temperature'
    }
  end

  def debug_cmds
    {
      :set        => 'dbg',
      'ON'        => 'on',
      'OFF'       => 'off',
    }
  end

  def internal_battery_info
    { :get => 't api system internal_battery_info' }
  end

  def external_battery_info
    { :get => 't api system external_battery_info' }
  end

  def firmware_version
    { :get => 't api system firmware_version' }
  end

  def shutdown
    { :set => 't api system shutdown' }
  end

  def reset
    { :set => 't api system reset force' }
  end

  def reset_no_force
    { :set => 't api system reset not_force' }
  end

  def beep_blink
    {
      :set        => 't api system beep_blink',
      'STARTUP'   => 'startup',
      'WARN'      => 'warning',
      'NOTIFY'    => 'notify',
      'SHUTDOWN'  => 'shutdown',
      'ONCE'      => 'once',
      'BEEP'      => 'beep_once',
      'BLINK'     => 'blink_once',
    }
  end

  def temperature_warn_status
    {
      get: 't api system temperature_warn_status'
    }
  end

  def recording_status
    { :get => 't api system recording_status' }
  end

  def busy_status
    { :get => 't api system busy_status' }
  end

  def ready_status
    { :get => 't api system ready_status'}
  end

  def quick_capture_status
    { :get => 't api system quick_capture_status' }
  end

  def factory_reset
    {
      :set        => 't api system factory_reset',
      'USER'      => 'user',
      'WIRELESS'  => 'wireless',
      'ALL'       => 'all',
    }
  end

  def language
    {
      :set       => 't api setup language',
      :get       => 't api setup language',
      'english'  => 'english',
      'chinese'  => 'chinese',
      'german'   => 'german',
    }
  end

  ##################################################################
  # PLAYBACK
  ##################################################################
  def playback_start
    { :set => 't api playback start' }
  end

  def playback_stop
    { :set => 't api playback stop' }
  end

  def playback_pause
    { :set => 't api playback pause' }
  end

  def playback_resume
    { :set => 't api playback resume' }
  end

  def playback_step
    { :set => 't api playback step' }
  end

  def playback_forward
    {
      :set => 't api playback forward',
      '1/8X'  => '1/8x',
      '1/4X'  => '1/4x',
      '1/2X'  => '1/2x',
      '1X'    => '1x',
      '2X'    => '2x',
      '4X'    => '4x',
      '8X'    => '8x',
    }
  end

  def playback_backward
    {
      :set => 't api playback backward',
      '1/8X'  => '1/8x',
      '1/4X'  => '1/4x',
      '1/2X'  => '1/2x',
      '1X'    => '1x',
      '2X'    => '2x',
      '4X'    => '4x',
      '8X'    => '8x',
    }
  end

  def playback_slideshow_start
    { :set    => 't api playback slideshow start' }
  end

  def playback_slideshow_stop
    { :set    => 't api playback slideshow stop' }
  end

  def playback_slideshow_multi
    { :set    => 't api playback multishot_slideshow' }
  end

  def playback_next
    { :set => 't api playback next_file' }
  end

  def playback_prev
    { :set => 't api playback previous_file' }
  end

  # TODO: Does this have args?
  def playback_tsearch
    { :set => 't api playback tsearch' }
  end

  ##################################################################
  # STORAGE
  ##################################################################
  def storage_tag
    { :set => 't api storage tag_moment' }
  end

  def photos_rem
    { :get => 't api storage remaining_photos' }
  end

  def vid_time_rem
    { :get => 't api storage remaining_video_time' }
  end

  def group_photo_count
    { :get => 't api storage num_group_photos' }
  end

  def group_video_count
    { :get => 't api storage num_group_videos' }
  end

  def photo_count
    { :get => 't api storage num_total_photos' }
  end

  def video_count
    { :get => 't api storage num_total_videos' }
  end

  # Removed in v8.00
  #def total_files  { :get => 't api storage num_files' } end

  def last_file
    { :get => 't api storage last_file' }
  end

  def delete_one
    { :set => 't api storage file_delete' }
  end

  def delete_last
    { :set => 't api storage latest_file_delete' }
  end

  def delete_group
    { :set => 't api storage group_file_delete' }
  end

  def delete_all
    { :set => 't api storage all_delete' }
  end


  def storage_status_event
    {
      :set        => 't api storage delete_all',
      'OK'        => 'ok',
      'FULL'      => 'full',
      'REMOVED'   => 'removed',
      'SD_ERROR'  => 'sd_err',
      'BUSY'      => 'busy',
    }
  end

  ##################################################################
  # WIRELESS
  ##################################################################
  def wireless_mode
    {
      :set      => 't api wireless mode',
      :get      => 't api wireless mode',
      'OFF'     => 'off',
      'APP'     => 'app',
      'RC'      => 'rc',
      'NETWORK' => 'network',
      'SMART'   => 'smart',
    }
  end

  def pairing
    {
      :set => 't api wireless pairing',
      'APP'      => 'app',
      'RC'       => 'rc',
      'NETWORK'  => 'nw',
      'BT_AUDIO' => 'bt_audio',
      'SMART'    => 'app_ble',
    }
  end

  def pairing_stop
    { :set => 't api wireless pairing_stop' }
  end

  def wireless_ble
    { :set => 't api wireless ble' }
  end

  def wireless_status
    { :set => 't api wireless status' }
  end

  def push_multek
    { :set => 't api wireless push_multek' }
  end

  def wifi_scan
    { :set => 't api wireless scan' }
  end

  def wifi_scan_stop
    { :set => 't api wireless scan_stop' }
  end

  def wifi_ssid
    { :get => 't api wireless ssid' }
  end

  def wifi_ssid_connect
    { :get => 't api wireless ssid_connect' }
  end

  def wifi_ssid_delete
    { :get => 't api wireless ssid_delete' }
  end

  ##################################################################
  # FWUPDATE
  ##################################################################
  def fw_update_start
    { :set => 't api fwupdate start' }
  end

  def fw_update_reset
    { :set => 't api fwupdate reset' }
  end

  def boot_fw
    { :set => 't api fwupdate boot_fw' }
  end

  ###########################################################################
  # VID_FEATURE_AVAIL
  ###########################################################################
  def piv_avail
    { :get => 't api video capability_filter_check piv' }
  end

  def low_light_avail
    { :get => 't api video capability_filter_check low_light' }
  end

  def protune_avail
    { :get => 't api video capability_filter_check protune' }
  end

  def timelapse_avail
    { :get => 't api video capability_filter_check timelapse' }
  end

  def jello_slayer_avail
    { :get => 't api video capability_filter_check jello_slayer' }
  end

  ###########################################################################
  # BROADCAST MODE
  ###########################################################################
  def broadcast_sub_mode
    {
      :set          => 't api app sub_mode',
      :get          => 't api app sub_mode',
      'RECORD'      => 'broadcast_record',
      'BROADCAST'   => 'broadcast',
    }
  end

  def broadcast_def_sub_mode
    {
      :set          => 't api broadcast default_sub_mode',
      :get          => 't api broadcast default_sub_mode',
      'RECORD'      => 'broadcast_record',
      'BROADCAST'   => 'broadcast',
    }
  end

  def broadcast
  end

  #############################################################################
  #  Non-API utility commands
  #############################################################################
  def short_press
    {
      :set            => 't button press',
      'P_BUTTON'      => '0 250',
      'S_BUTTON'      => '1 250',
      'MENU_BUTTON'   => '2 250',
      'LCD_BUTTON'    => '3 250',
    }
  end
end

if __FILE__ == $0

end
