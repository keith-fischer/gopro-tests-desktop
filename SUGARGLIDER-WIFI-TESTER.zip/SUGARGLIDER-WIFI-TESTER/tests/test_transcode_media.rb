#!/usr/bin/env ruby
# test_transcode_media.rb
# usage: ruby tests/test_transcode_media.rb --serial /dev/ttyUSB0 --logfile logs/test_res_fps_fov.log

require 'fileutils'
require 'English'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/serial_commands'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    @host = Host.new
    log_info('Initialising the serial camera ')
    @camera = tu_get_camera
    @camera.set_io_delay(2)
    @camera.set_media_dirname('...GOPRO')
    @camera.disable_power_save
  end

  def runtest
    test_transcode_videos
    test_invalid_params_for_transcode_video
    test_invalid_params_for_transcode_photo
    test_transcode_photos
  end

  def test_record_videos
    @camera.video_capture_modes.each do |res, settings|
      next if @options[:video_resolution] && @options[:video_resolution] != res
      settings[:fps].each do |fps, fps_settings|
        next if @options[:video_fps] && @options[:video_fps] != fps
        modes = []
        modes << 'NTSC' if fps_settings[:ntsc]
        modes << 'PAL' if fps_settings[:pal]
        modes.each do |mode|
          fps_settings[:fov].each do |fov|
            next if @options[:video_fov] && @options[:video_fov] != fov
            next if fov == 'L'
            test_record_video(mode, settings[:protune], res, fps, fov)
          end
        end
      end
    end
  end

  def test_transcode_videos
    mp4_on_sd.each do |media_file|
      next if media_file.include?('_')
      test_transcode_video(media_file)
    end
  end

  def test_transcode_video(media_file)
    set_tc_name("Transcoding #{media_file}")
    log_info("Battery: #{@camera.get_internal_battery_info}")
    error = @camera.transcode_video(media_file)
    if ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]
      log_fail("Failed due to #{ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]}")
      abort if error == -13
    else
      cur_media = @camera.get_medialist
      if cur_media.empty?
        log_warn('Aborting further tests, Please check the camera')
        abort
      end
      trv = cur_media.grep(media_file.gsub(/\.MP4/, '.TRV')).first
      if trv
        log_pass("Success, Transcoded video at #{trv}")
        if @options[:delete_trv]
          success, msg = @camera.delete_single_file(trv)
          success ? log_info(msg) : log_warn(msg)
        end
      end
    end
  end

  def test_invalid_params_for_transcode_video
    media_files = mp4_on_sd
    [-1, 99999999999999].each do |bitrate|
      transcode_video_with_invalid_params(media_files.shuffle.first, 'output bitrate', '<depends on input mp4>', :output_bitrate, bitrate)
    end

    [-1, 7].each do |output_res|
      transcode_video_with_invalid_params(media_files.shuffle.first, 'output res', '<0, 6>', :output_res, output_res)
    end

    [-1, 5].each do |fps_divisor|
      transcode_video_with_invalid_params(media_files.shuffle.first, 'fps divisor', '<0, 4>', :fps_divisor, fps_divisor)
    end

    [-1, 999999999999999].each do |start_msec|
      transcode_video_with_invalid_params(media_files.shuffle.first, 'start msec', '<0, video length>', :start_msec, start_msec)
    end

    #[-1, 999999999999999].each do |end_msec|
    #  transcode_video_with_invalid_params(media_files.shuffle.first, "end msec", "<0, video length>", :end_msec, end_msec)
    #end
    transcode_video_with_invalid_filename(media_files.shuffle.first.gsub(/GOPR0.*\.MP4/, 'foo.MP4'))
  end

  def test_invalid_params_for_transcode_photo
    media_files = jpg_on_sd
    transcode_photo_with_invalid_filename('foo.JPG')
    [-1, 8].each do |output_res|
      transcode_photo_with_invalid_params(media_files.shuffle.first, 'output res', '<0, 7>', :output_res, output_res)
    end
    [-1, 40001, 999999999999].each do |count|
      transcode_photo_with_invalid_params(media_files.shuffle.first, 'sequence count', '<0, 40000>', :sequence_count, count)
    end
  end

  def test_transcode_photos
    media_files = jpg_on_sd
    media_files.each do |media_file|
      test_transcode_photo(media_file)
    end
  end

  def test_transcode_photo(media_file)
    set_tc_name("Transcoding #{media_file}")
    log_info("Battery: #{@camera.get_internal_battery_info}")
    error = @camera.transcode_photo(media_file)
    if ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]
      log_fail("Failed due to #{ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]}")
      abort if error == -13
    else
      cur_media = @camera.get_medialist
      if cur_media.empty?
        log_warn('Aborting further tests, Please check the camera')
        abort
      end

      match = media_file.match(/\d\d\d\d\./)
      trv = cur_media.grep(Regexp.new("GOPR#{match.to_s}TRV")).first
      if trv
        log_pass("Success, Transcoded video at #{trv}")
        if @options[:delete_trv]
          success, msg = @camera.delete_single_file(trv)
          success ? log_info(msg) : log_warn(msg)
        end
      end
    end
  end

  def test_record_video(mode, pt, res, fps, fov)
    set_tc_name("Record a video with Protune=#{pt}, Mode=#{mode}, Resolution=#{res}, FPS=#{fps}, FOV=#{fov}")
    num_videos = total_videos_on_sd
    log_warn('Unable to get video count') unless warn
    result, msg = @camera.set_video_def_sub_mode('VIDEO')
    log_warn(msg) unless result
    if pt
      @camera.set_video_protune('ON')
    else
      @camera.set_video_protune('OFF')
    end

    @camera.set_video(mode, res, fps.to_i, fov)
    record_video(20)
    if validate_num_videos_on_sd?(num_videos + 1)
      log_pass('Successful')
    else
      log_fail('Failed')
    end
  end

  def cleanup
    @host.kill_status_process if @host
  end

  private

  def transcode_video_with_invalid_params(file_name, param_str, range_str, param_name, param_val)
    set_tc_name("Transcode Video to Video should return GP_ERROR_INVALID_PARAM if #{param_str} is not in #{range_str}, specified #{param_str}: #{param_val}")
    error = @camera.transcode_video(file_name, {param_name => param_val})
    msg = "Expected: GP_ERROR_INVALID_PARAM, Got: #{ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]}"
    error == -2 ? log_pass(msg) : log_fail(msg)
  end

  def transcode_video_with_invalid_filename(filename)
    set_tc_name("Transcode Video to Video should return GP_ERROR_FILE_NOT_FOUND if input file name is invalid")
    error = @camera.transcode_video(filename)
    msg = "Expected: GP_ERROR_FILE_NOT_FOUND, Got: #{ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]}"
    error == -12 ? log_pass(msg) : log_fail(msg)
  end

  def transcode_photo_with_invalid_filename(filename)
    set_tc_name("Transcode Photo to Video should return GP_ERROR_FILE_NOT_FOUND if input file name is invalid")
    error = @camera.transcode_photo(filename)
    msg = "Expected: GP_ERROR_FILE_NOT_FOUND, Got: #{ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]}"
    error == -12 ? log_pass(msg) : log_fail(msg)
  end

  def transcode_photo_with_invalid_params(file_name, param_str, range_str, param_name, param_val)
    set_tc_name("Transcode Photo to Video should return GP_ERROR_INVALID_PARAM if #{param_str} is not in #{range_str}, specified #{param_str}: #{param_val}")
    error = @camera.transcode_photo(file_name, {param_name => param_val})
    msg = "Expected: GP_ERROR_INVALID_PARAM, Got: #{ExitCode::TRANSCODING_ERROR_STRING_BY_ERROR_CODE[error]}"
    error == -2 ? log_pass(msg) : log_fail(msg)
  end

  def mp4_on_sd
    media_files = @camera.get_medialist
    media_files.grep(/\.MP4/)
  end

  def jpg_on_sd
    media_files = @camera.get_medialist
    media_files.grep(/\.JPG/)
  end

  def delete_media_on_sd
    log_info('Deleting the contents of the SD card')
    result, msg = @camera.storage_delete_all
    log_warn(msg) unless result
  end

  def record_video(duration)
    log_info("Starting video capture for #{duration}s")
    result, msg = @camera.start_video_capture
    log_warn(msg) unless result

    sleep(duration)
    if @camera.recording?
      log_info('System is recording video')
      log_info('Stopping video capture')
      result, msg = @camera.stop_video_capture
      log_warn(msg) unless result
    else
      log_error('System is not recording a video')
    end
  end

  def total_videos_on_sd
    log_info('Getting the count of video files on Master Camera SD Card')
    media_files = @camera.get_medialist
    count = 0
    log_info('Listing media files')
    puts media_files
    media_files.each do |media_file|
      count += 1 if media_file.include?('.MP4')
    end
    count
  end

  def validate_num_videos_on_sd?(n)
    (total_videos_on_sd == n) ? true : false
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $PROGRAM_NAME
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:set_defaults, :serialdev,
                   :logfile, :verb, :pal_only, :ntsc_only,
                   :video_resolution, :video_fps, :video_fov,
                   :delete_trv]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    unless t.nil?
      t.cleanup
      t.final_actions
    end
  end
end
