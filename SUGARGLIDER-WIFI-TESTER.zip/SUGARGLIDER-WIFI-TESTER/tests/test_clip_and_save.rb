# test_clip_and_save.rb
# Uses serial commands to test camera clipping ability.
# This is not an end to end test!
# Makes video clips of various lengths and validates their existence and metadata.
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    (log_warn("Serial interface required."); exit 1) unless @camera.serial_iface
    tu_keep_or_delete_all_media()
    tu_verify_sd_status()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest()

    # The existance of this array is the test for clip and save being supported.
    clip_durations = @camera.get_clip_and_save_durations
    unless clip_durations
      log_warn("Camera type #{@camera.name} does not appear to support Clip & Save. Exiting.")
      exit 1
    end

    failed_arr = []

    # Enumerate all the test combinations
    test_params = tu_get_video_res_with_protune()

    if test_params[0].empty? && test_params[1].empty?
      log_warn("No tests to run! Check res/fps and camera @video_capture_modes.")
      return
    end

    total_tc = ( test_params[0].length + test_params[1].length ) * clip_durations.length
    counter = 0

    duration = clip_durations.max + 6 # Max clip length plus six seconds.

    test_params.each() { |r|
      next if r.empty?
      r.each {|vm, res, fps, fov, orient, ll, spot, p, wb, co, sh, iso, ex|
        
        from_media = nil
        try_to_make_media = true
        media_creation_failure = false

        clip_durations.each { |clip_duration|

        counter += 1
        next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
        log_info("Running test #{counter} of #{total_tc}")

        # Add all relevant info to the test case name
        tc_name = "#{vm}_#{res}_#{fps}_#{fov}_#{orient}_clip_#{clip_duration}"
        tc_name += "_spot_#{spot}" if spot != nil
        tc_name += "_ll_#{ll}" if ll != nil
        tc_name += "_protune_#{p}"
        tc_name += "_#{wb}" if wb != nil
        tc_name += "_#{co}" if co != nil
        tc_name += "_#{sh}" if sh != nil
        tc_name += "_#{iso}" if iso != nil
        tc_name += "_#{ex}" if ex != nil

        set_tc_name(tc_name)

        # A duration of 0 really means to clip a still photo.
        # I am not sure this is posible yet with the given t api trim command.
        # So while these test cases exist, they are being skipped.
        if clip_duration == 0
          log_skip("Skipping clip durations of 0 for now.")
          next
        end

        begin # Want to rescue from Errors within the test loop.

          cur_video = nil

          # If we don't have media to clip from, make it.
          if from_media == nil && try_to_make_media
            try_to_make_media = false
            log_info("Generating media to clip from.")
            prev_video = @camera.get_last_media("MP4", hash=false)
            #fail("Unable to get mediaList.") if prev_video == false

            ret, msg = @camera.capture_video(vm, res, fps, fov, duration, orient, ll, spot, p, wb, co, sh, iso, ex)
            (ret == false) ? (fail(msg); next) : log_info(msg)

            cur_video = @camera.get_last_media("MP4", hash=false)
            media_creation_failure = true if prev_video == cur_video
            log_info("Current video is: #{cur_video}")
            from_media = "DCIM\\" + cur_video
            from_media = from_media.gsub(/\//, "\\") # Format slashes.
          end

          # If we didn't manage to create media to clip from,
          # all the tests that would have clipped from this media should fail.
          if media_creation_failure
           fail("Did not generate media to clip from.")
           next
          end

          log_info("Clipping from #{from_media}.")
          start_time_ms = 3000
          end_time_ms = 3000 + ( clip_duration * 1000 )
          full_path = from_media
          cmd = "t api trim start #{full_path} #{start_time_ms} #{end_time_ms}"
          sanity_check_before = @camera.get_last_media("MP4", hash=false)
          ret, msg = @camera.send_serial( cmd, true )
          sleep(20.0)
          ( log_fail( msg ); next ) unless ret
          sanity_check_after = @camera.get_last_media("MP4", hash=false)
          if sanity_check_before == sanity_check_after # No clip happened?
            log_fail( "Serial command failed to create a clip." )
            next
          end

          cur_video = sanity_check_after
          log_info( "Checking this file: #{cur_video}" )

          # Not sure about this. This test could be used to generate clips.
          # I wasn't planning on keeping the clips. I guess we could if --keep_media.
          # You know what, let's leave this in.
          # Actually the call to save the mapped media in this test is going to have to be
          # a bit more complicated than this call. Commenting out for now.
#          tu_map_media_list( __FILE__, tc_name, [cur_video] )

          ### Metadata and other checks
          failed_arr << tu_wifi_analyze_video_metadata(cur_video, p, res, fps, fov)

          #File name convention
          failed_arr << tu_analyze_file_name("VIDEO", File.basename(cur_video))

          #gpMediaList or camera roll verification
          failed_arr << tu_wifi_analyze_gpmedialist_params("VIDEO", vm, p, res, fps, fov)

          #Analyze if mp4/lrv/thm exists over http (since there is no way to check
          #if thm exists on SD card, and doesn't hurt to check mp4/lrv as well)
          failed_arr << tu_wifi_check_media_existence("VIDEO", cur_video, vm, p, res, fps, fov, true)

          failed_arr << tu_wifi_verfiy_low_light(res, fps)

          log_pass( "Clip exists and has correct metadata.") if !has_failure?(failed_arr) # Will log a fail if it sees one
          failed_arr.clear

        rescue WifiCameraError
          fail("Lost communication with camera")
          tu_reset_camera()
        rescue StandardError => e
          fail("General error: #{e.to_s}")
          puts e.backtrace.join("\n")
          tu_reset_camera()
        end

      } # End clip_durations.each

      } # End r.each

    } # End test_params.each

  end # End runtest()

  def cleanup()
    #tu_map_media_done()
    #tu_save_media()
    @host.kill_status_process() if @host
  end # End cleanup()

end # End Test

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      # :duration, # Not currently used. Use as limit on clip durations to test?
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only,
      :video_pt, :video_pt_wb, :video_pt_color, :video_pt_iso, :video_pt_sharp, :video_pt_ev,
      :video_low_light, :full, :range, :keep_media, :download_media,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering,
      :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, :quick, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
