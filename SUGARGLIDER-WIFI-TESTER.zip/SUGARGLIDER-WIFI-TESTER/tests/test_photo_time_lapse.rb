# test_burst.rb

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

#    if @options[:ip] != nil and @options[:pc] != nil
#      @camera = get_wifi_camera(@options[:ip], @options[:pc], @options[:serialdev])
#    elsif @options[:serialdev] != nil
#      @camera = get_serial_camera(@options[:serialdev])
#    else
#      log_error("Must specify either serial or ip/pc/serial")
#      exit 1
#    end

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    @camera.do_factory_reset("USER") if @camera.interfaces.include?(:serial)
    set_options()

    # Start preview stream on cameras that we want to test it
    if @camera.test_preview_stream == true
      ret, msg = @host.get_system_camera_ip(@camera.ip)
      ret == true ? @camera.system_address = msg : (log_info(msg); exit 1)
      @camera.send_live_stream_start
      @camera.start_streaming_protocol()
    end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    # Get the parameters for all test cases.  Shuffle if necessary
    test_params = tu_get_multi_photo_timelapse_test_params
    failed_arr = []


    if test_params.empty?
      log_warn("No tests to run!  Check RES/TIME-LAPSE chosen")
    else
      log_info("Running #{test_params.length} test cases")
    end
    test_params.shuffle! if @options[:shuffle]

    min_photos = @options[:min_pes_pho].to_i

    tu_keep_or_delete_all_media()
    tu_verify_sd_status()

    # Put camera in right mode for testing the first preview stream.
    @camera.set_capture_mode("TIMELAPSE") if @camera.test_preview_stream == true

    counter = 0
    test_params.each { |res, pes, orient, spot, pt, wb, col, sh, iso, ex|
      counter += 1
      next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
      log_info("Running test #{counter} of #{test_params.length}")

      tc_name = "#{res}_pes_#{pes}_#{orient}"
      tc_name += "_spot_#{spot}" if spot != nil
      tc_name += "_protune_#{pt}" if pt != nil
      tc_name += "_#{wb}"  if wb != nil
      tc_name += "_#{col}" if col != nil
      tc_name += "_#{iso}" if iso != nil
      tc_name += "_#{sh}"  if sh != nil
      tc_name += "_#{ex}"  if ex != nil
      set_tc_name(tc_name)

      ntsc_ts_before = "#{@options[:save_dir]}/#{tc_name}_ntsc_before.ts"
      ntsc_ts_after = "#{@options[:save_dir]}/#{tc_name}_ntsc_after.ts"
      pal_ts_before = "#{@options[:save_dir]}/#{tc_name}_pal_before.ts"
      pal_ts_after = "#{@options[:save_dir]}/#{tc_name}_pal_after.ts"

      duration = (pes.to_f * min_photos.to_i) + 1

      # Deal with user-specified duratiuons.
      #min_duration = duration
      if @options[:duration]
        if @options[:duration_range_low] and @options[:duration_range_high]
          duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
          log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
        else
          duration = @options[:duration].to_f
          log_info("Attempting to use user-specified duration of #{duration}.")
        end
        # This check has been removed; the user specified value is absolute.
        #if duration < min_duration
        #  duration = min_duration
        #  log_warn("User-specified duration is too small, so using test's default of #{duration}.")
        #end
      end

      begin
        list_before = @camera.get_medialist("JPG")
        log_verb("List before time-lapse capture: #{list_before}")

        if @camera.test_preview_stream == true
          #ts file contains different frame rate depending on video format
          ret, msg = @camera.set_video_format("NTSC")
          log_info("Saving preview streaming (ts) file in NTSC mode before capture")
          failed_arr << msg if ret == false
          isTimeout_ntsc_before = tu_save_idle_stream(ntsc_ts_before)
          if isTimeout_ntsc_before == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_before, "NTSC")
          else
            failed_arr << "Unable to get idle stream #{ntsc_ts_before}"
          end

          ret, msg = @camera.set_video_format("PAL")
          log_info("Saving preview streaming (ts) file in PAL mode before capture")
          failed_arr << msg if ret == false
          isTimeout_pal_before = tu_save_idle_stream(pal_ts_before)
          if isTimeout_pal_before == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_before, "PAL")
          else
            failed_arr << "Unable to get idle stream #{pal_ts_before}"
          end
        end

        ret, msg = @camera.capture_multi_photo_timelapse(res, pes, duration, orient, spot, pt, wb,
        col, sh, iso, ex)
        # Check that capture was successful
        if ret == false
          if @camera.interfaces.include?(:serial)
            if @camera.is_alive?
              @camera.do_reset()
            else
              @camera.detect_crash_and_reboot()
            end
          end
          fail(msg)
          next
        end
        log_info(msg)

        if @camera.test_preview_stream == true
          ret, msg = @camera.set_video_format("NTSC")
          log_info("Saving preview streaming (ts) file in NTSC mode after capture")
          failed_arr << msg if ret == false
          isTimeout_ntsc_after = tu_save_idle_stream(ntsc_ts_after)
          if isTimeout_ntsc_after == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_after, "NTSC")
          else
            failed_arr << "Unable to get idle stream #{ntsc_ts_after}"
          end

          ret, msg = @camera.set_video_format("PAL")
          log_info("Saving preview streaming (ts) file in PAL mode after capture")
          failed_arr << msg if ret == false
          isTimeout_pal_after = tu_save_idle_stream(pal_ts_after)
          if isTimeout_pal_after == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_after, "PAL")
          else
            failed_arr << "Unable to get idle stream #{pal_ts_after}"
          end
        end

        list_after = @camera.get_medialist("JPG")
        log_verb("List after time-lapse capture: #{list_after}")
        jpg_array = list_after - list_before
        tu_map_media_list( __FILE__, tc_name, jpg_array )

        # Check that at least 1 photo was taken
        (fail("No new photos taken");next) if jpg_array.empty?

        jpg_array.each { |jpgfile|

          sleep 1
          f = tu_basename(jpgfile) # Just get GYYYXXXX.JPG
          # File name convention checks
          failed_arr << tu_analyze_file_name("TIMELAPSE", f)
          if @camera.interfaces.include?(:wifi)
            # Metadata checks over HTTP (faster)
            full_path =  @camera.get_media_url(jpgfile)
            failed_arr << tu_analyze_photo_metadata(full_path, :time_lapse, res, pes)

            # GPMediaList or camera roll verification
            failed_arr << tu_wifi_analyze_gpmedialist_params("TIMELAPSE", nil)
          end

          # Group and object number verification
          log_info("Checking group numbering")
          grp_num = f[1..3].to_i
          exp_grp_num = grp_num if exp_grp_num == nil
          failed_arr << assert_equal(exp_grp_num, grp_num,
          "(#{f}) Group # exp=#{exp_grp_num}, act=#{grp_num}")

          log_info("Checking file index numbering")
          obj_num = f[4..8].to_i
          exp_obj_num = obj_num if exp_obj_num == nil
          failed_arr << assert_equal(exp_obj_num, obj_num,
          "(#{f}) Object # exp=#{exp_obj_num}, act=#{obj_num}")
          if exp_obj_num == 999
            exp_grp_num += 1
            exp_obj_num = 1
          else
            exp_obj_num += 1
          end
        }

        if @camera.test_preview_stream == true
          failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_before, "NTSC")
          failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_after, "NTSC")
          failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_before, "PAL")
          failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_after, "PAL")
        end

        # Log any failures in quality/metadata and move on to the next
        log_pass if !has_failure?(failed_arr)
        failed_arr.clear()
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    } # end test_params.each

    # Stop preview streaming if it was started
    if @camera.test_preview_stream == true
      @camera.send_live_stream_stop
      @camera.stop_streaming_protocol
    end

  end # end runtest

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @host.kill_status_process() if @host
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :multi_photo_resolution, :multi_photo_timelapse, :keep_media, :download_media,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :multi_photo_spot_meter, :multi_photo_pt, :multi_photo_pt_wb, :multi_photo_pt_sharp,
      :multi_photo_pt_iso, :multi_photo_pt_color, :multi_photo_pt_ev, :range,
      :shuffle, :set_defaults, :quick, :full, :dryrun, :verb, :duration]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
