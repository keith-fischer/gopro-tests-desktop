# test_folder_size_limit.rb
# DESCRIPTION: Tests that folders are limited to 999 DCF objects.
# Does this by:
# - Deleting all media.
# - Taking 1 photo.
# - Recording the current folder and determining the next folder.
# - Making sure the file counter is low enough.
# - if not, do bursts until it is.
# - Doing about 33 burts.
# - Doing about 8 more photos.
# - Doing 1 more photo.
# - Validating that the next folder was used for that last photo.

# This test should work for all cameras.
# It starts capturing a little differently and lists media differently for serial cameras.
# It has has only been tested on Pipe and Backdoor.
# With some improvements, it could run significantly faster for serial cameras.

require_relative '../libs/camera'
#require_relative '../libs/dlipower'
#require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include Test_utils
  def initialize()
    super
  end # initialize

  def setup(options)
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @options = options
    #@host = Host.new
    @camera = tu_get_camera()
    #@camera.powerstrip = PowerStrip.new(@options[:power_ip],
    #  @options[:power_usr], @options[:power_pwd])
    #@camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    #@camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    set_options()
  end # setup

  def runtest()
    set_tc_name("#{@test_file}_runtest")
    # Blow away existing files.
    # There might be stray full folders that would ruin this test.
    ret, msg = @camera.delete_all_media()
    (log_fail(msg); exit! 1) unless ret
    log_info("Deleted all media.")

    # Take one picture to get the file counter.
    # We need to make sure we won't hit the file counter limit during the test.
    ret, msg = @camera.set_capture_mode("PHOTO")
    (log_fail(msg); exit! 2) unless ret
    @camera.start_capture()
    sleep(1)
    @camera.stop_capture()
    sleep(1)
    counter, msg = get_last_file_counter()
    (log_fail(msg); exit! 3) unless counter
    log_info("Took first image. File counter: #{counter}")

    # If we're going to hit the file counter limit, push the file counter past the limit.
    # We have to do this because the file counter rolling over creates a new folder too.
    # For serial cameras, we can just do a factory reset to reset the file counter.
    if counter > 9000
      if @options[:serialdev]
        # Reset the file counter with a factory reset.
        log_info("Factory resetting serial camera to reset file counter.")
        ret, msg = delete_all_media()
        (log_fail(msg); exit! 4) unless ret
        ret, msg = do_factory_reset("ALL")
        (log_fail(msg); exit! 5) unless ret
        ret = disable_power_save()
        (log_fail("Could not disable serial camera power save."); exit! 6) unless ret
      else
        # Roll the file counter over by adding files.
        log_info("Adding more files to rollover file counter.")
        ret, msg = @camera.set_capture_mode("BURST")
        (log_fail(msg); exit! 6) unless ret
        ret, msg = @camera.set_multi_photo_burst("30_1")
        (log_fail(msg); exit! 7) unless ret
        # Take bursts until the file counter rolls over.
        while counter > 9000
          @camera.start_capture()
          sleep(4)
          @camera.stop_capture()
          sleep(1)
          counter, msg = get_last_file_counter()
          (log_fail(msg); exit! 8) unless counter
        end # while
      end # if
    end # if

    # We need the folder names.
    ml = @camera.get_medialist() # This one is actually correct!
    msg = "Could not get medialist for initial folder name."
    (log_fail(msg); exit! 9) unless ml and ml.length > 0
    this_folder = ml.last[-21..-14]
    next_folder, msg = get_next_folder(this_folder)
    (log_fail(msg); exit! 10) unless next_folder
    log_info("Current folder: #{this_folder}")
    log_info("Next folder: #{next_folder}")

    # Count the DCF objects in this folder.
    dcf_count, msg = get_dcf_count(this_folder)
    (log_fail(msg); exit! 11) unless dcf_count
    log_info("Number of DCF objects found in folder #{this_folder}: #{dcf_count}")

    if false ##### @options[:serialdev] and defined?(@camera.file_make)
      # Serial cameras could do this much faster.
=begin # Removed for now.
      while dcf_count < 999
        spoof = counter.to_s.rjust(4,"0") # Pads with 0's.
        @camera.file_make( this_folder, "GOPR#{spoof}.JPG")
        counter += 1
        dcf_count += 1
      end # while
=end
    else
      # It's not an advanced enough serial camera.
      # Fill the folders with images the "slow" way.

      # Now swap to burst mode to get near 999 DCF objects "quickly".
      # Also setup to do 30 pictures per burst.
      ret, msg = @camera.set_capture_mode("BURST")
      (log_fail(msg); exit! 12) unless ret
      ret, msg = @camera.set_multi_photo_burst("30_1")
      (log_fail(msg); exit! 13) unless ret
      log_info("Switched to BURST mode.")

      # Take images via burst mode.
      attempts = 0
      while dcf_count < 969
        log_info("Doing burst capture to add 30 more DCF objects.")# (#{dcf_count})")
        @camera.start_capture()   unless @options[:serialdev]
        @camera.start_multi_capture() if @options[:serialdev]
        sleep(4)
        @camera.stop_capture()
        sleep(1)
        dcf_count += 30
        attempts += 1
        (log_fail("Too many failed attempts to make DCF objects."); exit! 90) if attempts > 40
      end # while
      log_info("Done with burst captures.") #(#{dcf_count})")

      # Swap to photo mode to get to 999 DCF objects exactly.
      ret, msg = @camera.set_capture_mode("PHOTO")
      (log_fail(msg); exit! 14) unless ret
      log_info("Switched to PHOTO mode.")

      # Take pictures via photo mode.
      attempts = 0
      while dcf_count < 999
        log_info("Doing photo capture to add one more DCF object.")# (#{dcf_count})")
        @camera.start_capture()   unless @options[:serialdev]
        @camera.start_photo_capture() if @options[:serialdev]
        sleep(1)
        @camera.stop_capture()
        sleep(1)
        dcf_count += 1
        attempts += 1
        (log_fail("Too many failed attempts to make DCF objects."); exit! 91) if attempts > 40
      end # while
      log_info("Done with photo captures.")# (#{dcf_count})")

    end # if, Doing it the "slow" way.

    # Verify we have the right number of DCF objects in the first folder.
    dcf_count, msg = get_dcf_count(this_folder)
    (log_fail(msg); exit! 15) unless dcf_count
    (log_fail("DCF count was not 999. Act: #{dcf_count}"); exit! 16) unless dcf_count == 999
    log_pass("Folder #{this_folder} has only 999 images, which is correct.")

    # Verify the last DCF object was in this_folder.
    # This check is kind of redundant for serial cameras...
    ml = camera_get_medialist(this_folder)
    msg = "Could not get medialist for 999th DCF object folder."
    (log_fail(msg); exit! 17) unless ml and ml.length > 0
    the_folder = ml.last[-21..-14] # Assumes they are sorted properly...?
    if the_folder.chomp != this_folder.chomp
      log_fail("999th DCF object was in the wrong folder. (act:#{the_folder} exp:#{this_folder})")
    else
      log_pass("999th DCF object found in correct folder. (#{the_folder})")
    end # if
    
    # Take one more image.
    @camera.start_capture()   unless @options[:serialdev]
    @camera.start_photo_capture() if @options[:serialdev]  
    sleep(4)
    @camera.stop_capture()
    sleep(1)

    # Verify the next_folder now has some DCF objects in it too!
    ml = camera_get_medialist(next_folder)
    msg = "Could not get medialist for 1000th DCF object folder."
    (log_fail(msg); exit! 18) unless ml and ml.length > 0
    the_folder = ml.last[-21..-14]
    if the_folder.chomp != next_folder.chomp
      log_fail("DCF objects past 999 were in the wrong folder. (act: #{the_folder} exp: #{next_folder})")
    else
      log_pass("DCF object past 999 were found in correct folder. (#{the_folder})")
    end # if

  end # runtest

  def cleanup()
    #set_tc_name("#{@test_file}_cleanup")
  end # cleanup

  # This is uesful.
  def get_last_file_counter(folder=nil)
  ml = camera_get_medialist(folder)
  return false, "get_last_file_counter: Could not get medialist." unless ml and ml.length > 0
    counter = ml.last[-8..-5].to_i
    return counter, "get_last_file_counter: Returned #{counter}"
  end # get_last_file_counter

  # This is also useful. Counts how many DCF objects appear in a given folder.
  def get_dcf_count(folder)
    ml = camera_get_medialist(folder)
    return false, "get_dcf_count: Could not get medialist." unless ml
    # Count how many JPGs and MP4s are in this folder.
    count = ml.count { |x| x[-21..-14] == folder and (x.end_with?("MP4") or x.end_with?("JPG")) }
log_info("get_dcf_count: last file in list: #{ml.last}")
    return count, "get_dcf_count: Returned #{count}"
  end # get_dcf_count

  # This gives the folder name that follows numerically next.
  # It does not look for what the next folder should be based on the files and folders found on the camera.
  # This is ok though, because we use it after deleting all media.
  def get_next_folder(folder)
    return false, "next_folder(): Invalid foldername." unless folder.match(/\d\d\dGOPRO/)
    ret = "#{folder[0..3].to_i + 1}GOPRO"
    ret = "100GOPRO" if folder == "999GOPRO"
    return ret, "next_folder(): Returned #{ret}"
  end # next_folder

  # Sometimes we need to behave differently for wifi and serial cameras.
  def camera_get_medialist(folder)
    # Call the normal function for non-serial cameras.
    return @camera.get_medialist() unless @options[:serialdev]
    # Call the guessing version (defined below) for serial cameras.
    return @camera.guess_medialist(folder) if folder
    # Or don't if not calling this without a folder.
    return @camera.get_medialist()
  end #camera_get_medialist

end # Test

# Serial cameras take too long to return all the files, so it gets limited at about 350.
# This is no good. So instead we look for the single captures on the ends and assume the middle.
# Could pipe the full ls to a file, download that file to host, and wc -l on the host instead.
class SerialCamera < Camera
  # Add a guess_medialist method.
  def guess_medialist(folder)
    dir = folder
    drive = "C"
    return [] if dir == nil
    # Only list single capture files. This cuts the number way down.
    send_serial("ls #{drive}:\\DCIM\\#{dir}\\GOPR*")
    data = ""
    (1..10).each {
      resp = read_serial_resp(limit=2.0)
      data += resp
      break if resp.match(/a:.>/) != nil
    }
    lines = data.split("\r\n")
    retval = []
    nlow = 10000
    nhigh = -1
    lines.each { |f|
      f.delete!("\u0000")
      fields = f.split()
      next if fields.length == 0
      next if fields[0][0] != "f" # Files only, skip directories
      (ltp_log($VERB, "Skipping #{f}"); next) if fields.length < 7
      fname = fields[6]
      nlow =  fname[4..7].to_i if fname[4..7].to_i < nlow
      nhigh = fname[4..7].to_i if fname[4..7].to_i > nhigh
      # Skip non-matching suffix (if specified)
#      next if suffix != nil and suffix != fname[-suffix.length..-1]     
#      retval << [dir, fname].join("\\")
    }
    # Fake a list of files based on the lowest and highest numbers found.
    findex = nlow
    while findex <= nhigh
      retval << [dir, "GOPR#{findex.to_s.rjust(4,"0")}.JPG"].join("\\")
      findex += 1
    end # while
    return retval
  end # get_medialist
end # SerialCamera

if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :save_dir, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOG_LEVEL = $LL_VERB if options[:verb] == true
        options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end

