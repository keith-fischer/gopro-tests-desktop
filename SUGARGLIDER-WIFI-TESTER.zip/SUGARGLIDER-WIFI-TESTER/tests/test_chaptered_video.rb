# test_chaptered_video.rb
# Description: Iterates over all RES/FPS/FOV with both ProTunes
#              off and on (if supported) and checks that video is chaptered
#              correctly (filename/metadata is correct).
#              Capture length is calculated from video bitrate and maximum
#              file size on the SD card, or can be specified on cmd line.
#              Also performs a max_chaptering test on the highest bitrate mode.
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  # Returns just the mode with the highest bitrate.
  # For ties, returns the first mode encountered, or random if shuffle == true
  def get_max_bitrate_mode(modes_arr, shuffle=true)
    max_br = 0
    max_br_mode = nil
    max_br_modes = []
    modes_arr.each { |m|
      vm, res, fps, fov, orient, ll, spot, p = m[0..7]
      br = @camera.get_bitrate(res, fps, p)
      if br > max_br
        max_br = br
        max_br_modes = [m]
      elsif br == max_br
        max_br_modes << m
      end
    }
    if shuffle == false
      max_br_mode = max_br_modes[0]
    else
      max_br_mode = max_br_modes.shuffle[0]
    end
    log_info("Max bitrate mode found (%s/%s/%s -- %s)" \
      %[max_br_mode[1], max_br_mode[2], max_br_mode[3], max_br])
    return max_br_mode
  end

  def verify_chap_mp4_files(mp4list, vm, p, res, fps, fov)
    failed_arr = []
    first_file_processed = false
    mp4list.each {|mp4file|

      # Expecting mp4file to be the following form
      # 128GOPRO/GOPR8207.MP4
      # 128GOPRO/GP018207.MP4
      if !first_file_processed
        #File name convention
        failed_arr << tu_analyze_file_name("VIDEO", File.basename(mp4file))

        #Analyze if mp4/lrv/thm exists over http
        failed_arr << tu_wifi_check_media_existence("VIDEO", mp4file, vm, p, res, fps, fov, true)
        #TODO - File size?

        first_file_processed = true
      else
        #File name convention
        failed_arr << tu_analyze_file_name("CHAPTERED_VIDEO", File.basename(mp4file))

        #Analyze if mp4/lrv/thm exists over http (no thumbnail)
        failed_arr << tu_wifi_check_media_existence("VIDEO", mp4file, vm, p, res, fps, fov, false)
      end

      failed_arr << tu_wifi_analyze_video_metadata(mp4file, p, res, fps, fov)
    }
    return failed_arr
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest

    # 2-chapter test performed on all RES/FPS/FOV/ProTune combinations (default settings)
    test_params = tu_get_video_res_with_protune()

    if test_params[0].empty? && test_params[1].empty?
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end

    total_tc = test_params[0].length + test_params[1].length
    counter = 0
    test_params.each() { |r|
      next if r.empty?
      r.each {|vm, res, fps, fov, orient, ll, spot, p, wb, co, sh, iso, ex|
        counter += 1
        next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
        log_info("Running test #{counter} of #{total_tc}")

        # Add all relevant info to the test case name
        tc_name = "#{vm}_#{res}_#{fps}_#{fov}_#{orient}"
        tc_name += "_spot_#{spot}" if spot != nil
        tc_name += "_ll_#{ll}" if ll != nil
        tc_name += "_protune_#{p}"
        tc_name += "_#{wb}" if wb != nil
        tc_name += "_#{co}" if co != nil
        tc_name += "_#{sh}" if sh != nil
        tc_name += "_#{iso}" if iso != nil
        tc_name += "_#{ex}" if ex != nil
        set_tc_name(tc_name)

        begin
          tu_keep_or_delete_all_media()
          tu_verify_sd_status()

          sleep(5.0)

          tu_map_media_before()

          if @camera.chapter_size != nil
            chap_len = (@camera.chapter_size * 8) / (1000000 * @camera.get_bitrate(res, fps, p))
            duration = (chap_len + 60).to_i
          else
            duration = 22 * 60
          end

          # Deal with user-specified durations.
          #min_duration = duration
          if @options[:duration]
            if @options[:duration_range_low] and @options[:duration_range_high]
              duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
              log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
            else
              duration = @options[:duration].to_f
              log_info("Attempting to use user-specified duration of #{duration}.")
            end
            # This check has been removed; the user specified value is absolute.
            #if duration < min_duration
            #  duration = min_duration
            #  log_warn("User-specified duration is too small, so using test's default of #{duration}.")
            #end
          end

          log_info("Capturing %02d:%02d length video" %[(duration/60), (duration%60)])
          capture_params = [vm, res, fps, fov, duration, orient, ll, spot, p, wb, co, sh, iso, ex]
          ret, msg = @camera.capture_video(*capture_params)
          (ret == false) ? (fail(msg); next) : log_info(msg)

          mp4list = @camera.get_medialist("MP4")
          tu_map_media_after( __FILE__, tc_name )
          if mp4list == false or mp4list.empty?
            fail("No new video was found after encoding")
            next
          end

          failed_arr = verify_chap_mp4_files(mp4list, vm, p, res, fps, fov)

          log_pass if !has_failure?(failed_arr)  # Will log a fail if it sees one
        rescue WifiCameraError
          fail("Lost communication with camera")
          tu_reset_camera()
        rescue StandardError => e
          fail("General error: #{e.to_s}")
          puts e.backtrace.join("\n")
          tu_reset_camera()
        end
      } # r.each
    } # test_params.each

    # Max chapter test performed on highest bitrate mode
    max_br_mode = get_max_bitrate_mode(test_params[0])
    vm, res, fps, fov, orient, ll, spot, p, wb, co, sh, iso, ex = max_br_mode

    tc_name = "#{vm}_protune_#{p}_#{res}_#{fps}_#{fov}_#{orient}_max_chaptering"
    set_tc_name(tc_name)

    begin
      # Must format card and set mode first for get_mins_avail() to be accurate
      tu_keep_or_delete_all_media()
      tu_verify_sd_status()

      sleep(5.0)
      tu_map_media_before()

      @camera.set_single_video_settings(*max_br_mode)

      duration = @camera.get_mins_avail() * 60 + 300 # 5 extra minutes
      log_info("Capturing %02d:%02d:%02d length video" \
        %[(duration/3600), ((duration%3600)/60), ((duration%3600)%60)])
      @camera.start_capture()
      sleep(duration)
      @camera.stop_capture()

      mp4list = @camera.get_medialist("MP4")
      tu_map_media_after( __FILE__, tc_name )
      if mp4list == false or mp4list.empty?
        fail("No new video was found after encoding")
      end

      failed_arr = verify_chap_mp4_files(mp4list, vm, p, res, fps, fov)
      log_pass if !has_failure?(failed_arr)  # Will log a fail if it sees one
    rescue WifiCameraError
      fail("Lost communication with camera")
      tu_reset_camera()
    rescue StandardError => e
      fail("General error: #{e.to_s}")
      puts e.backtrace.join("\n")
      tu_reset_camera()
    end
  end

  def cleanup
    tu_map_media_done()
    @host.kill_status_process() if @host
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only, :keep_media,
      :video_pt, :video_pt_wb, :video_pt_color, :video_pt_iso, :video_pt_sharp, :video_pt_ev,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :range,
      :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, :verb, :duration]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
