# test_serial_commands.rb
# Tests the serial API by attempting to apply a setting and 
# then testing if it was correctly set.  This is only for 
# HERO4 cameras.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/serial_commands'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
  end

  def runtest
    @camera.do_factory_reset("USER")
    sleep 5.0
    # There must be media on the card to enter 'playback' mode
    # @camera.capture_photo_single(@camera.get_photo_resolutions[0])

    test_cmd(@camera.mode, "app_mode")
    test_video_commands()
    test_photo_commands()
    test_multi_shot()
    test_storage()
    test_wireless()
    test_setup()
    test_system()
    test_vid_feature_avail("piv")
    test_vid_feature_avail("low_light")
    test_vid_feature_avail("protune")
    test_vid_feature_avail("timelapse")
    test_vid_feature_avail("jello_slayer")
  end
  
  def test_video_commands()
    # @camera.set(@camera.mode, "VIDEO")
    # @camera.set(@camera.video_sub_mode, "VIDEO")
    # # Test all res/fps/fov non-protune
    # test_res_fps_fov()
    # # Test all res/fps/fov protune
    # test_res_fps_fov(pt="ON")

    # TODO Missing: 
    # protune_reset, settings, progress_counter, piv_capture_start/stop
    @camera.set(@camera.mode, "VIDEO")
    @camera.disable_power_save()
    test_cmd(@camera.video_sub_mode,      "video_sub_mode")
    test_cmd(@camera.video_def_sub_mode,  "video_default_sub_mode")
    test_cmd(@camera.piv,                 "video_piv")
    test_cmd(@camera.video_looping,       "video_looping")
    test_cmd(@camera.low_light,           "video_low_light")
    test_cmd(@camera.spot_metering,       "video_spot_metering")
    test_cmd(@camera.video_timelapse_rate, "video_timelapse_rate")
    @camera.disable_power_save()
    test_cmd(@camera.video_protune,       "video_protune")
    @camera.set(@camera.video_protune, "ON")
    test_cmd(@camera.white_balance,       "video_protune_white_balance")
    test_cmd(@camera.color,               "video_protune_color")
    test_cmd(@camera.iso,                 "video_protune_iso")
    test_cmd(@camera.sharpness,           "video_protune_sharpness")
    test_cmd(@camera.exposure,            "video_protune_exposure")
    @camera.set(@camera.video_protune, "OFF")
    @camera.detect_crash_and_reboot()
  end
  
  # TODO Missing: 
    # protune_reset, settings
  def test_photo_commands()
    @camera.set(@camera.mode, "PHOTO")
    @camera.disable_power_save()
    test_cmd(@camera.photo_sub_mode,         "photo_sub_mode")
    test_cmd(@camera.photo_def_sub_mode,     "photo_default_sub_mode")
    test_cmd(@camera.photo_res,              "photo_res")
    @camera.set(@camera.photo_sub_mode, "CONTINUOUS")
    test_cmd(@camera.sps,                    "photo_sps")
    test_cmd(@camera.photo_spot,             "photo_spot_meter")
    @camera.set(@camera.photo_sub_mode, "NIGHT")
    @camera.disable_power_save()
    test_cmd(@camera.photo_protune,          "photo_protune")
    @camera.set(@camera.photo_protune, "ON")
    test_cmd(@camera.photo_exp,              "photo_exposure")
    test_cmd(@camera.photo_white_balance,    "photo_white_balance")
    test_cmd(@camera.photo_color,            "photo_color")
    test_cmd(@camera.photo_iso,              "photo_iso")
    test_cmd(@camera.photo_sharpness,        "photo_sharpness")
    test_cmd(@camera.photo_protune_exposure, "photo_protune_exposure")
    @camera.set(@camera.photo_protune, "OFF")
    @camera.detect_crash_and_reboot()
  end

  # TODO Missing: 
    # protune_reset, settings
  def test_multi_shot()
    @camera.set(@camera.mode, "MULTI_SHOT")
    @camera.disable_power_save()
    test_cmd(@camera.multi_sub_mode,         "multi_shot_sub_mode")
    test_cmd(@camera.multi_def_sub_mode,     "multi_shot_default_sub_mode")
    test_cmd(@camera.multi_res,              "multi_shot_res")
    test_cmd(@camera.burst,                  "multi_shot_burst")
    test_cmd(@camera.time_lapse,             "multi_shot_time_lapse")
    test_cmd(@camera.night_lapse,            "multi_shot_night_lapse")
    test_cmd(@camera.multi_spot,             "multi_shot_spot_meter")
    @camera.disable_power_save()
    test_cmd(@camera.multi_protune,          "multi_shot_protune")
    @camera.set(@camera.multi_protune, "ON")
    test_cmd(@camera.multi_exp,              "multi_exposure")
    test_cmd(@camera.multi_white_balance,    "multi_shot_white_balance")
    test_cmd(@camera.multi_color,            "multi_shot_color")
    test_cmd(@camera.multi_iso,              "multi_shot_iso")
    test_cmd(@camera.multi_sharpness,        "multi_shot_sharpness")
    test_cmd(@camera.multi_protune_exposure, "multi_shot_protune_exposure")
    @camera.set(@camera.multi_protune, "OFF")
    @camera.detect_crash_and_reboot()
  end

  def test_storage()
    #set_tc_name("storage_total_files")
    #log_skip("Not currently implemented")
    # ret, msg = @camera.get_total_files
    # fail(msg) if ret == false
    # pass("Total files = #{ret}") if ret != false

    set_tc_name("storage_remaining_photos")
    ret, msg = @camera.get_rem_photos()
    fail(msg) if ret == false
    pass("Remaining photos = #{ret}") if ret != false

    set_tc_name("storage_remaining_videos")
    ret, msg = @camera.get_rem_videos()
    fail(msg) if ret == false
    pass("Remaining videos = #{ret}") if ret != false

    set_tc_name("storage_photo_group_count")
    ret, msg = @camera.get_photo_group_count()
    fail(msg) if ret == false
    pass("Photo group count = #{ret}") if ret != false

    set_tc_name("storage_video_group_count")
    ret, msg = @camera.get_video_group_count()
    fail(msg) if ret == false
    pass("Video group count = #{ret}") if ret != false

    set_tc_name("storage_photo_count")
    ret, msg = @camera.get_photo_count()
    fail(msg) if ret == false
    pass("Photo count = #{ret}") if ret != false

    set_tc_name("storage_video_count")
    ret, msg = @camera.get_video_count()
    fail(msg) if ret == false
    pass("Video count = #{ret}") if ret != false

    set_tc_name("storage_get_last_file")
    ret, msg = @camera.get_last_file()
    fail(msg) if ret == false
    pass("Last file = #{ret}") if ret != false

    # TODO: Missing
    # tag_moment
    # delete_all
    # delete_one
    # delete_last
    # delete group
    # sd_status
    @camera.detect_crash_and_reboot()
  end

  def test_wireless()
    test_cmd(@camera.wireless_mode, "wireless_mode")
    
    set_tc_name("wireless_scan")
    @camera.send_serial(@camera.wifi_scan[:set])
    resp = @camera.expect("SSID scan completed", 5, 1)
    fail("Completion message not seen") if resp == nil
    pass("SSID scan completed") if resp != nil

    set_tc_name("wireless_ssid")
    @camera.send_serial(@camera.wifi_ssid[:get])
    resp = @camera.expect("GoPro", 5, 1)
    fail("No SSID containing 'GoPro' seen") if resp == nil
    pass("'GoPro' SSID seen") if resp != nil

    # TODO: Missing
    # log
    # pairing
    # pairing_stop
    # ble
    # status
    # push_multek
    # scan_stop
    # ssid_connect
    # ssid_delete
    @camera.detect_crash_and_reboot()
  end

  def test_setup()
    test_cmd(@camera.lcd_brightness,      "setup_lcd_brightness")
    test_cmd(@camera.lcd_auto_off,        "setup_lcd_auto_off")
    @camera.set(@camera.lcd_auto_off, "OFF")
    test_cmd(@camera.lcd_lock,            "setup_lcd_lock")
    test_cmd(@camera.orientation,         "setup_orientation")
    test_cmd(@camera.default_mode,        "setup_default_mode")
    test_cmd(@camera.quick_capture,       "setup_quick_capture")
    test_cmd(@camera.beep_sound,          "setup_beep_volume")
    test_cmd(@camera.video_mode,          "setup_video_format")
    test_cmd(@camera.osd,                 "setup_osd")
    #test_cmd(@camera.language,            "setup_language")
    test_cmd(@camera.auto_off,            "setup_auto_power_down")
    @camera.set(@camera.auto_off, "OFF")
    @camera.detect_crash_and_reboot()
  end

  def test_system()
    set_tc_name("system_battery_level")
    log_skip("Battery info API TBD")
    # ret, msg = @camera.get_battery_level()
    # fail(msg) if ret == false
    # pass("Battery level = #{ret}") if ret != false

    # set_tc_name("system_shutdown"
    # @camera.do_shutdown()
    # resp = @camera.expect("AmbaShell ;)", 20, 1)
    # fail("Ambashell message not seen on boot") if resp == nil
    # pass("Boot completed") if resp != nil
    # sleep 3.0

    set_tc_name("system_reset")
    ret, msg = @camera.do_reset()
    fail("Ambashell message not seen on boot") if ret == false
    pass("Boot completed") if ret == true
    sleep 3.0

    # test_cmd(@camera.beep_blink,      "system_beep_blink")  # no real way to verify
    # test_cmd(@camera.lcd_set,      "system_lcd_set") # crashes camera

    set_tc_name("system_factory_reset")
    ret, msg = @camera.do_factory_reset("USER")
    ret == true ? pass(msg) : fail(msg)
    sleep 3.0
    @camera.detect_crash_and_reboot()
  end

# feature_str are "piv", "low_light", "protune", "timelapse", "jello_slayer"
  def test_vid_feature_avail(feature_str)
    @camera.disable_power_save()
    get_capture_modes().each do |mode, res, fps, fov|
      set_tc_name("vid_feature_avail_#{feature_str}_#{mode}_#{res}_#{fps}_#{fov}")
      exp = @camera.method("video_#{feature_str}_support?").call(res, fps, fov)
      ret, msg = @camera.video_capability_filter_check(feature_str, mode, res, fps, fov)
      if ret == false
        fail(msg) if ret == false
      else
        act = msg
        ret_str = "expected = #{exp} -- actual=#{act}"
        pass(ret_str) if exp == act
        fail(ret_str) if exp != act
      end
    end
    @camera.detect_crash_and_reboot()
  end

  # Test NTSC/PAL + all video RES/FPS/FOV combinations
  def test_res_fps_fov(pt="OFF")
    test_params = []
    @camera.get_video_resolution().each do |res|
      next if @options[:vid_res] != nil and @options[:vid_res] != res
      @camera.get_video_fps(res).each do |fps|
        next if @options[:fps] != nil and @options[:fps] != fps
        @camera.get_video_fov(res, fps).each do |fov|
          next if @options[:fov] != nil and @options[:fov] != fov
          log_verb("Adding test [#{res}, #{fps}, #{fov}]")
          test_params << [res, fps, fov]
        end # fov
      end # fps
    end # res
    test_params.shuffle! if @options[:shuffle] == true
    test_params.each do |res, fps, fov|
      if pt == "ON"
        next if @camera.video_protune_support?(res, fps) == false
        set_tc_name("test_serial_commands_#{res}_#{fps}_#{fov}_protune")
        ret, msg = @camera.set_video_protune(pt)
        (fail(msg); next) if ret == false
      else
        set_tc_name("test_serial_commands_#{res}_#{fps}_#{fov}")
      end
      mode = @camera.is_ntsc?(res, fps) ? "NTSC" : "PAL"
      log_debug("Setting capture mode")
      ret, msg = @camera.set_video(mode, res, fps, fov)
      cam_alive, status_msg = @camera.detect_crash_and_reboot()
      log_debug(status_msg)
      if cam_alive == false or ret == false
        fail(msg)
      else
        pass(msg)
      end
    end
  end
  
  def test_cmd(cmd_hash, cmd_name)
    keys = cmd_hash.keys.map { |m| m if not m.instance_of? Symbol }
    keys.compact!
    keys.shuffle! if @options[:shuffle] == true
    keys.each { |k|
      set_tc_name("#{cmd_name}_#{cmd_hash[k]}")
      ret, msg = @camera.set(cmd_hash, k)
      ret == true ? pass(msg) : fail(msg)
    }
  end

  def get_capture_modes()
    test_params = []
    @camera.get_video_resolution().each do |res|
      next if @options[:video_resolution] != nil and @options[:video_resolution] != res
      @camera.get_video_fps(res).each do |fps|
        @camera.get_video_fov(res, fps).each do |fov|
          if @camera.is_ntsc?(res, fps)
            test_params << ["ntsc", res, fps, fov]
          else
            test_params << ["pal", res, fps, fov]
          end
        end # fov
      end # fps
    end # res
    return test_params
  end

  def cleanup()
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end # end runtest

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :shuffle, :set_defaults,
      :video_resolution, :video_fps, :video_fov, :usboutlet, :battoutlet,
      :verb
    ]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
