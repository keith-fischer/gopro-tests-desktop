# test_file_rollover.rb
# Tests what happens when file numbers, folder numbers, and group numbers rollover.
# Also runs the DCF limit test, which makes sure folders are limited to 999 DCF objects.
# Only runs the complete test on cameras that are connected via both serial and wifi.
# If a camera is not connected by wifi, the test bails out.
# For cameras that are connected only by wifi, only runs the DCF limit test.
# For Hawaii or Hawiewa cameras that are connected by both wifi and serial, runs the full test.

# I have commented out testcase test_no_capture for now.
# This testcase takes a long time and doesn't work very well.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize()
    super
  end # initialize

  # Helper functions  
  def file_make(folder, file, verify=true)
    if verify == true
      t = Time.now()
      while (Time.now() - t) < 30 do
        case @camera.name
        when "BACKDOOR", "PIPE", "STREAKY", "SQUIRRELS"
          @sercam.send_serial("dmesg rtos -1 > #{@sd_drv}\\DCIM\\#{folder}\\#{file}")
        when "ROCKYPOINT", "HALEIWA", "HIMALAYAS"
          @sercam.send_serial("touch #{@sd_drv}\\DCIM\\#{folder}\\#{file}")
        end
        @sercam.send_serial("ls #{@sd_drv}\\DCIM\\#{folder}\\*")
        resp = @sercam.read_serial_resp()
        # p resp
        return true if resp.match(file)
        sleep 0.5
      end
    else
      case @camera.name
      when "BACKDOOR", "PIPE", "STREAKY", "SQUIRRELS"
        @sercam.send_serial("dmesg rtos -1 > #{@sd_drv}\\DCIM\\#{folder}\\#{file}")
      when "ROCKYPOINT", "HALEIWA", "HIMALAYAS"
        @sercam.send_serial("touch #{@sd_drv}\\DCIM\\#{folder}\\#{file}")
      end
    end
    return false
  end # file_make

  def file_exists?(folder, file)
    @camera.get_medialist.include?("#{folder}/#{file}")
  end # file_exists?

  def dir_exists?(folder)
    @camera.get_medialist.each { |f|
      return true if File.dirname(f) == folder
    }
    return false
  end # dir_exists?
  alias_method :folder_exists?, :dir_exists?

  def file_delete(folder, file)
    @sercam.send_serial("rm #{@sd_drv}\\DCIM\\#{folder}\\#{file}")
  end # file_delete

  def folder_make(folder, verify=true)
    if verify
      resp = @sercam.read_serial_resp(limit=3.0) # Clear the serial buffer
      t = Time.now()
      while (Time.now() - t) < 30 do
        @sercam.send_serial("mkdir #{@sd_drv}\\DCIM\\#{folder}")
        # Can't use wi-fi get_medialist to verify dir.  Have to use serial.
        @sercam.send_serial("ls #{@sd_drv}\\DCIM\\*")
        resp = @sercam.read_serial_resp()
        # p resp
        return true if resp.match(folder)
        sleep 0.5
      end
    else
      @sercam.send_serial("mkdir #{@sd_drv}\\DCIM\\#{folder}")
      sleep(0.1)
    end
    return false
  end # folder_make

  def factory_reset()
    if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
      5.times {
        @sercam.send_serial("t app test factory_reset")
        resp = @sercam.expect(/Factory Reset Complete/, 2.0)
        return true if resp != nil
        log_warn("Didn't see factory reset message.  Retrying.")
        sleep 10
      }
      return false
    else
      return @camera.factory_reset("user")
    end
  end

  def folder_list_contents(folder)
    @sercam.send_serial("ls #{@sd_drv}\\DCIM\\#{folder}\\*")
    resp = @sercam.read_serial_resp() # May need more time!
    return nil unless resp
    ret = []
    lines = resp.split("\r\n")
    # Pull out ls contents.
    lines.each do |f|
      f.delete!("\u0000")
      fields = f.split()
      next if fields.length == 0 or fields.length < 7
      next if ["[.]","[..]"].include?(fields[6])
      ret << fields.join(" ")
    end
    return ret
  end # list_folder_contents

  def set_and_enable_app_mode()
    5.times {
      log_info("Setting AP to #{@camera.ssid} #{@camera.pairing_code}")
      @sercam.send_serial("t wireless ap_set #{@camera.ssid} #{@camera.pairing_code}")
      sleep 1.0
      log_info("Enabling AP")
      @sercam.send_serial("t wireless mode_set ap")
      sleep 1.0
      @sercam.send_serial("t wireless enable on")
      return true if @host.wait_for_wifi_camera(@camera.addr, 45) == true
      log_warn("Failed to connect to camera.  Retrying.")
      sleep 10
    }
    return false
  end

  def get_curr_dir()
    @camera.delete_all_media(force=true)
    @camera.capture_photo_single(@camera.get_photo_resolutions[0])
    sleep(5.0)
    img = @camera.get_medialist[0]
    return File.dirname(img)
  end

  def get_dir_and_file_num()
    @camera.delete_all_media(force=true)
    @camera.capture_photo_single(@camera.get_photo_resolutions[0]) #multi_photo_burst(@camera.get_photo_resolutions[0], "3_1")
    sleep(10)
    img = @camera.get_medialist[-1]
    if img != nil
      dirnum = File.dirname(img)[0..2].to_i
      filenum = File.basename(img)[4..7].to_i
      return dirnum, filenum
    else
      return nil
    end
  end

  def fast_capture(minimum_captures_to_do)
    timelimit = 3 * minimum_captures_to_do
    medialist = []
    t = Time.now()
    while (Time.now - t) < timelimit do
      ret, msg = @camera.capture_multi_photo_timelapse(@camera.get_photo_resolutions[0], "0.5", 60)
      log_warn(msg) if ret == false
      sleep(10)
      medialist = @camera.get_medialist()
      n = medialist.length
      break if n > minimum_captures_to_do
    end
  end # fast_capture

  # End of Helper Functions

  def setup(options)
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @options = options
    @host = Host.new
    @camera = tu_get_camera()
    unless @camera.is_a?(WifiCamera)
      log_error("Camera must inititally be connected via wifi for this test.")
      exit 1
    end
    unless @camera.serial_iface
      log_error("Camera must have a serial interface (--serial) to run this test.")
      exit 1
    end
    @sercam = get_serial_camera(@camera.serial_iface)
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
      @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()

    case @camera.name
    when "BACKDOOR", "PIPE", "STREAKY", "SQUIRRELS"
      @sd_drv = "C:"
    when "ROCKYPOINT", "HALEIWA", "HIMALAYAS"
      @sd_drv = "D:"
    else
      log_error("Camera type #{@camera.name} not supported for this test!")
      exit 1
    end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end # setup

  def runtest()
    test_999_DCF_obj_limit()
    test_photo_file_rollover()
    test_burst_file_rollover()
    test_timelapse_file_rollover()
    test_group_number_rollover()
    test_folder_rollover()
    test_folder_skipping() if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name) == false
    #test_no_capture()
  end

  def test_999_DCF_obj_limit()
    set_tc_name("test_999_DCF_obj_limit")
    dir_num = get_curr_dir[0..2].to_i
    grp_num = 111
    d1 = "#{dir_num}GOPRO"
    d2 = "#{dir_num+1}GOPRO"
    d2 = "100GOPRO" if dir_num == 999

    @camera.delete_all_media(force=true)
    if folder_make(d1) == false
      fail("Unable to make folder #{d1}")
      return false
    end
    f = "G#{grp_num}0001.JPG"
    if file_make(d1, f, verify=true) == false
      fail("Unable to make file #{d1}/#{f}")
      return false
    end
    tu_reset_camera(pmic=true)

    timelimit = 800
    medialist = []
    t = Time.now()
    while (Time.now - t) < timelimit do
      ret, msg = @camera.capture_multi_photo_timelapse(@camera.get_photo_resolutions[0], "0.5", 60)
      log_warn(msg) if ret == false
      sleep(10)
      medialist = @camera.get_medialist()
      n = medialist.length
      log_info("#{n} photos captured")
      break if n > 999
    end

    if medialist.length <= 999
      fail("Somehow did not get >999 objects.")
      return false
    end

    failures = []
    d1files = medialist.reject { |f| f.match(d1) == nil }
    d2files = medialist.reject { |f| f.match(d2) == nil }
    unkfiles = medialist - d1files - d2files
    failures << assert(d1files.length == 999, "# of objects in #{d1} (#{d1files.length}) != 999")
    failures << assert(d2files.length > 0, "No files were written to #{d2}")
    failures << assert(unkfiles.length == 0, "Unknown files present #{unkfiles}")
    pass if not has_failure?(failures)
  end

  def test_photo_file_rollover()
    set_tc_name("test_photo_file_rollover")
    dir_num = get_curr_dir[0..2].to_i
    d1 = "#{dir_num}GOPRO"
    @camera.delete_all_media(force=true)
    folder_make(d1)
    f = "GOPR9998.JPG"
    file_make(d1, f, verify=true)
    tu_reset_camera(pmic=true)
    3.times {
      @camera.capture_photo_single(@camera.get_photo_resolutions[0])
      sleep(5)
    }
    d2 = "#{dir_num+1}GOPRO"
    d2 = "100GOPRO" if dir_num == 999
    failures = []
    failures << assert(file_exists?(d1, "GOPR9999.JPG"), "Missing #{d1}/GOPR9999.JPG")
    failures << assert(dir_exists?(d2), "Missing #{d2}")
    failures << assert(file_exists?(d2, "GOPR0001.JPG"), "Missing #{d2}/GOPR0001.JPG")
    failures << assert(file_exists?(d2, "GOPR0002.JPG"), "Missing #{d2}/GOPR0002.JPG")
    pass if not has_failure?(failures)
  end

  def test_burst_file_rollover()
    set_tc_name("test_burst_file_rollover")
    dir_num = get_curr_dir[0..2].to_i
    grp_num = 111
    d1 = "#{dir_num}GOPRO"
    d2 = "#{dir_num+1}GOPRO"
    d2 = "100GOPRO" if dir_num == 999

    @camera.delete_all_media(force=true)
    folder_make(d1)
    f = "G#{grp_num}9989.JPG"
    file_make(d1, f, verify=true)
    tu_reset_camera(pmic=true)
    3.times {
      @camera.capture_multi_photo_burst(@camera.get_photo_resolutions[0], "10_1")
      sleep(15)
    }

    failures = []
    # First burst should be d1/G1129990-9999
    all_media = @camera.get_medialist
    (9990..9999).each { |n|
      fname = "%s/G%03d%04d.JPG" %[d1, grp_num+1, n]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    # Second burst should be d2/G1120001-0010
    (1..10).each{ |n|
      fname = "%s/G%03d%04d.JPG" %[d2, grp_num+2, n]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    # Third burst should be d2/g1130011-0020
    (11..20).each{ |n|
      fname = "%s/G%03d%04d.JPG" %[d2, grp_num+3, n]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    pass if not has_failure?(failures)
  end

  def test_timelapse_file_rollover()
    set_tc_name("test_timelapse_file_rollover")
    dir_num = get_curr_dir[0..2].to_i
    grp_num = 111
    d1 = "#{dir_num}GOPRO"
    d2 = "#{dir_num+1}GOPRO"
    d2 = "100GOPRO" if dir_num == 999

    @camera.delete_all_media(force=true)
    if folder_make(d1) == false
      fail("Unable to make folder #{d1}")
      return false
    end
    f = "G#{grp_num}9989.JPG"
    if file_make(d1, f, verify=true) == false
      fail("Unable to make file #{d1}/#{f}")
      return false
    end
    tu_reset_camera(pmic=true)

    # Perform actual capture
    @camera.capture_multi_photo_timelapse(@camera.get_photo_resolutions[0], "0.5", 20)
    sleep(7)

    failures = []
    # First files should continue in d1.  i.e. d1/G1129990-9999
    all_media = @camera.get_medialist
    (9990..9999).each { |n|
      fname = "%s/G%03d%04d.JPG" %[d1, grp_num+1, n]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    # Rest should be in next folder using the next group number
    # We will just ensure first 10 files made it
    (1..10).each{ |n|
      fname = "%s/G%03d%04d.JPG" %[d2, grp_num+2, n]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    pass if not has_failure?(failures)
  end

  def test_group_number_rollover()
    set_tc_name("test_group_number_rollover")
    dir_num, file_num = get_dir_and_file_num()
    file_num += 1
    grp_num = 998
    d1 = "#{dir_num}GOPRO"
    d2 = "#{dir_num+1}GOPRO"
    d2 = "100GOPRO" if dir_num == 999

    @camera.delete_all_media(force=true)
    if folder_make(d1) == false
      fail("Unable to make folder #{d1}")
      return false
    end
    f = "G%03d%04d.JPG" %[grp_num, file_num]
    if file_make(d1, f, verify=true) == false
      fail("Unable to make file #{d1}/#{f}")
      return false
    end
    tu_reset_camera(pmic=true)
 
    # Perform actual capture
    3.times {
      @camera.capture_multi_photo_burst(@camera.get_photo_resolutions[0], "3_1")
      sleep(10)
    }

    failures = []
    # All groups should be encoded in dir 'd2'
    # Group number should rollover
    all_media = @camera.get_medialist
    (file_num+1..file_num+3).each { |n|
      fname = "%s/G%03d%04d.JPG" %[d1, (grp_num+1), n%10000]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    (file_num+4..file_num+6).each { |n|
      fname = "%s/G%03d%04d.JPG" %[d2, 1, n%10000]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    (file_num+7..file_num+9).each { |n|
      fname = "%s/G%03d%04d.JPG" %[d2, 2, n%10000]
      failures << assert(all_media.include?(fname), "Missing #{fname}")
    }
    pass if not has_failure?(failures)
  end

  def test_folder_rollover()
    set_tc_name("test_folder_rollover")
    d1 = "999GOPRO"
    d2 = "100GOPRO"

    @camera.delete_all_media(force=true)
    if folder_make(d1) == false
      fail("Unable to make folder #{d1}")
      return false
    end
    f = "GOPR9999.JPG"
    if file_make(d1, f, verify=true) == false
      fail("Unable to make file #{d1}/#{f}")
      return false
    end
    tu_reset_camera(pmic=true)
 
    # Perform actual capture
    2.times {
      @camera.capture_photo_single(@camera.get_photo_resolutions[0])
      sleep(5)
    }

    # Folder should rollover and have two files in it
    failures = []
    failures << assert(dir_exists?(d2), "Missing #{d2}")
    failures << assert(file_exists?(d2, "GOPR0001.JPG"), "Missing #{d2}/GOPR0001.JPG")
    failures << assert(file_exists?(d2, "GOPR0002.JPG"), "Missing #{d2}/GOPR0002.JPG")
    pass if not has_failure?(failures)
  end

  # Is this a fair test? That is, can a folder even exist after the current folder?
  # If not, what about the case of "fill 999 -> skip 100 -> use 102"?
  def test_folder_skipping()
    set_tc_name("test_folder_skipping")
    d1 = "200GOPRO"
    s1 = "201GOPRO" # This folder will exist, so it is skipped over.
    d2 = "202GOPRO"

    #log_info("Removing existing media.")
    @camera.delete_all_media(force=true)

    #log_info("Setting up first folder with one file.")
    if folder_make(d1) == false
      fail("Unable to make folder #{d1}")
      return false
    end
    f = "GOPR9998.JPG"
    if file_make(d1, f, verify=true) == false
      fail("Unable to make file #{d1}/#{f}")
      return false
    end

    #log_info("Resetting camera.")
    tu_reset_camera(pmic=true)

    #log_info("Creating the folder that should be skipped, with two files in it.")
    if folder_make(s1) == false
      fail("Unable to make folder #{s1}")
      return false
    end
    f = "GOPR0002.JPG"
    if file_make(s1, f, verify=true) == false
      fail("Unable to make file #{s1}/#{f}")
      return false
    end
    f = "GOPR4444.JPG"
    if file_make(s1, f, verify=true) == false
      fail("Unable to make file #{s1}/#{f}")
      return false
    end

    #log_info("Doing some captures.")
    3.times {
      @camera.capture_photo_single(@camera.get_photo_resolutions[0])
      sleep(5)
    }

    # First capture should happen in d1.
    # Folder should rollover, skipping s1, creating d2
    # The next two captures appear in d2.
    #log_info("Verifying results.")
    failures = []
    failures << assert(dir_exists?(d2), "Missing #{d2}")
    failures << assert(file_exists?(d1, "GOPR9999.JPG"), "Missing #{d1}/GOPR9999.JPG")
    failures << assert(file_exists?(d2, "GOPR0001.JPG"), "Missing #{d2}/GOPR0001.JPG")
    failures << assert(file_exists?(d2, "GOPR0002.JPG"), "Missing #{d2}/GOPR0002.JPG")
    pass("Existing folder was skipped, which is correct.") if not has_failure?(failures)
  end # test_folder_skipping

def test_no_capture()
    set_tc_name("test_no_capture")
    d1 = "999GOPRO"

    #log_info("Removing existing media.")
    @camera.delete_all_media(force=true)

    #log_info("Setting up the last folder.")
    unless folder_make(d1)
      fail("Unable to make folder #{d1}")
      return false
    end
    f = "GOPR9999.JPG"
    unless file_make(d1, f, verify=true)
      fail("Unable to make file #{d1}/#{f}")
      return false
    end

    #log_info("Resetting camera.")
    tu_reset_camera(pmic=true)

    #log_info("Create all the other folders, with a file in them.")
    log_info("Creating all folders. Please wait...")
    for n in 101..999 do
      folder_make("#{n}GOPRO", false)
      unless file_make("#{n}GOPRO", "GOPR9999.JPG", verify=true)
        fail("Unable to make file #{n}GOPRO/GOPR9999.JPG")
        return false
      end
      log_info("#{n}/999") if n % 10 == 0
      sleep(0.1)
    end

    #log_info("Validating the files exist based on medialist length.")
    ml = @camera.get_medialist()
    unless ml.length == 900 # 1 each in all 899 folders, except the last which has one more.
      fail("Didn't create enough files for no capture test.") # Try verifying them above instead.
      return false
    end

    #log_info("Getting pre-capture folder information.")
    d2 = "100GOPRO"
    old_100 = folder_list_contents(d2)
    old_999 = folder_list_contents(d1)

    #log_info("Attempting to capture. No captures should actually happen.")
    3.times {
      @camera.capture_photo_single(@camera.get_photo_resolutions[0])
      sleep(5)
    }

    #log_info("Getting post-capture folder information.")
    new_100 = folder_list_contents(d2)
    new_999 = folder_list_contents(d1)

    #log_info("Verifying results.")
    failures = []
    failures << assert(old_999 == new_999, "Folder contents have changed in 999GOPRO")
    failures << assert(old_100 == new_100, "Folder contents have changed in 100GOPRO")
    pass("No capture appears to have occurred, which is correct.") if not has_failure?(failures)
  end # test_no_capture

  def cleanup()
    @host.kill_status_process() if @host
  end

end # Test

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :shuffle, :set_defaults, 
       :battoutlet, :usboutlet, :reset_on_failure,
       :setup_default_mode, :setup_led, :setup_beep, :setup_orientation,
       :save_dir, :quick, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
