# test_orientation.rb
# Description:  Tests that media is correctly flipped in UP/DOWN/AUTO
#               orientation.  AUTO is only testable if SPINNY is
#               connected and functioning

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require_relative '../libs/spinny'

class Test < TestCase
  include TestUtils
  def intialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera
    @spinny = Spinny.new(@options[:spinny])
    tu_keep_or_delete_all_media()
    tu_verify_sd_status()
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    test_orient_video_single()
    test_orient_photo_single()
  end

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @spinny.spin if @spinny.current_orientation == "DOWN"
    @spinny.close()
    @host.kill_status_process() if @host
  end

  # Compare two images and figure out if the orientation is same/opposite
  # Returns 0 if images are same orientation
  # Returns 1 if images are opposite orientation
  def cmp_ori(img1, img2)
    # Get a vertically flipped version
    img_flipped = "/tmp/orient_temp.jpg"
    @host.flip_image(img1, img_flipped, quiet=true)

    ret, psnr = @host.get_psnr(img1, img2)
    ret, psnr_flip = @host.get_psnr(img_flipped, img2)
    log_verb("psnr=#{psnr}, psnr_flip=#{psnr_flip}")
    if psnr >= psnr_flip
      return 0
    else
      return 1
    end
  end

  # dest is local directory
  def curl_all_media(dest)
    ret = []
    begin
      @camera.get_medialist().each { |f|
        ret << @host.curl(@camera.get_media_url(f), dest)
      }
    rescue StandardError => e
      log_warn("Problem downloading media. #{e.to_s}")
      return false
    end
    return ret
  end

  # f is the MP4 file on the camera as returned from get_medialist()
  # dest is the local directory
  def extract_first_frame(f, dest)
    url = @camera.get_media_url(f)
    # byte_range = "0-500000" # Byte range does not work for HAWAII MP4 files... ugh
    fname = @host.curl(url, local=dest, overwrite=true)
    if fname == false
      return false
    end
    frame_file = File.join(dest, File.basename(f, ".MP4") + "-frame.jpg")
    return frame_file if @host.extract_frame(fname, frame_file, seek=nil, overwrite=true)
    return false
  end

  def get_video_images(img_dir, ori, vm, res, fps, fov, dur)
    mp4frame = thmframe = lrvframe = nil
    # media_before = @camera.get_medialist("MP4")
    media_before = @camera.get_mp4_files_from_webserver()
    @camera.set_orientation(ori)
    @camera.capture_video(vm, res, fps, fov, dur)
    # media_after = @camera.get_medialist("MP4")
    media_after = @camera.get_mp4_files_from_webserver()
    if media_before == nil or media_after == nil
      raise WifiCameraError("Failed to get list of media from webserver")
    end
    mp4 = (media_after - media_before)[0]
    thm = mp4[0..-5] + ".THM"
    mp4frame = extract_first_frame(mp4, img_dir)
    thmframe = @host.curl(@camera.get_media_url(thm), img_dir)
    if @camera.has_lrv?(res, fps, fov)
      lrv = mp4[0..-5] + ".LRV"
      lrvframe = extract_first_frame(lrv, img_dir)
    end
    return mp4frame, thmframe, lrvframe
  end

  def get_photo_images(img_dir, ori, res)
    media_before = @camera.get_medialist()
    @camera.set_orientation(ori)
    @camera.capture_photo_single(res)
    media_after = @camera.get_medialist()
    jpg = @camera.get_media_url((media_after - media_before)[0])
    return @host.curl(jpg, img_dir)
  end

  # Test VIDEO mode
  def test_orient_video_single()
    duration = 5
    ["NTSC", "PAL"].each { |vm|
      @camera.get_video_resolution().each { |res|
        all_fps = @camera.get_fps_ntsc(res) if vm == "NTSC"
        all_fps = @camera.get_fps_pal(res) if vm == "PAL"
        all_fps.each { |fps|
          @camera.get_video_fov(res, fps).each { |fov|
            ["OFF", "ON"].each { |pt|
              next if pt == "ON" and @camera.video_protune_support?(res, fps) == false
              begin
                tc_name = "test_orientation_video_#{vm}_#{res}_#{fps}_#{fov}_pt_#{pt}"
                set_tc_name( tc_name )
                @spinny.spin if @spinny.current_orientation == "DOWN"
                tu_keep_or_delete_all_media()
                tu_verify_sd_status()
                tu_map_media_before()
                img_dir = File.join(@options[:save_dir], @tc_name)
                ret = @host.mkdir(img_dir)
                next if ret == false

                log_info("Capture UP video with camera UP")
                up, up_thm, up_lrv = get_video_images(img_dir, "UP",
                                                      vm, res, fps, fov, duration)
                log_info("Capture DOWN video with camera UP")
                down, down_thm, down_lrv = get_video_images(img_dir, "DOWN",
                                                      vm, res, fps, fov, duration)
                log_info("Capture AUTO video with camera UP")
                auto, auto_thm, auto_lrv = get_video_images(img_dir, "AUTO",
                                                      vm, res, fps, fov, duration)

                failed_arr = []
                msg1 = "UP and DOWN should never match"
                msg2 = "AUTO should be same as UP"
                msg3 = "AUTO should be same as DOWN"
                # UP/AUTO should match.  UP/DOWN shouldn't (ever)
                failed_arr << assert_equal(cmp_ori(up, down), 1, msg1)
                failed_arr << assert_equal(cmp_ori(up, auto), 0, msg2)
                failed_arr << assert_equal(cmp_ori(up_thm, down_thm), 1, msg1)
                failed_arr << assert_equal(cmp_ori(up_thm, auto_thm), 0, msg2)
                if up_lrv != nil and down_lrv != nil and auto_lrv != nil
                  failed_arr << assert_equal(cmp_ori(up_lrv, down_lrv), 1, msg1)
                  failed_arr << assert_equal(cmp_ori(up_lrv, auto_lrv), 0, msg2)
                end

                # Spin SPINNY and do the same
                @spinny.spin()
                log_info("Capture UP video with camera DOWN")
                up, up_thm, up_lrv = get_video_images(img_dir, "UP",
                                                      vm, res, fps, fov, duration)
                log_info("Capture DOWN video with camera DOWN")
                down, down_thm, down_lrv = get_video_images(img_dir, "DOWN",
                                                      vm, res, fps, fov, duration)
                log_info("Capture AUTO video with camera DOWN")
                auto, auto_thm, auto_lrv = get_video_images(img_dir, "AUTO",
                                                      vm, res, fps, fov, duration)
                # Now DOWN/AUTO should match.  UP/DOWN shouldn't (ever)
                failed_arr << assert_equal(cmp_ori(up, down), 1, msg1)
                failed_arr << assert_equal(cmp_ori(down, auto), 0, msg3)
                failed_arr << assert_equal(cmp_ori(up_thm, down_thm), 1, msg1)
                failed_arr << assert_equal(cmp_ori(down_thm, auto_thm), 0, msg3)
                if up_lrv != nil and down_lrv != nil and auto_lrv != nil
                  failed_arr << assert_equal(cmp_ori(up_lrv, down_lrv), 1, msg1)
                  failed_arr << assert_equal(cmp_ori(down_lrv, auto_lrv), 0, msg3)
                end

                tu_map_media_after( __FILE__, tc_name )

                next if has_failure?(failed_arr)
                pass("UP/DOWN/AUTO orientation passed.")
                # Delete the directory if everything passed
                @host.rmdir(img_dir)

              rescue WifiCameraError => e
                fail("Camera communication failed.  #{e.to_s}")
              rescue StandardError => e
                fail("Some other error. #{e.to_s}")
                puts e.backtrace.join("\n")
              end # begin...rescue block
            } # pt
          } # fps
        } # fov
      } # get_video_resolutions
    } # [NTSC, PAL].each
  end # test_orient_photo_single

  # Test PHOTO_SINGLE mode
  def test_orient_photo_single()
    @camera.get_photo_resolutions().each { |res|
      begin
        tc_name = "test_orientation_photo_single_#{res}"
        set_tc_name( tc_name )
        @spinny.spin if @spinny.current_orientation == "DOWN"
        tu_keep_or_delete_all_media()
        tu_verify_sd_status()
        tu_map_media_before()
        img_dir = File.join(@options[:save_dir], @tc_name, res)
        ret = @host.mkdir(img_dir)
        next if ret == false

        log_info("Capture UP image with camera UP")
        up = get_photo_images(img_dir, "UP", res)
        log_info("Capture DOWN image with camera UP")
        down = get_photo_images(img_dir, "DOWN", res)
        log_info("Capture AUTO image with camera UP")
        auto = get_photo_images(img_dir, "AUTO", res)

        failed_arr = []
        msg1 = "UP and DOWN should never match"
        msg2 = "AUTO should be same as UP"
        msg3 = "AUTO should be same as DOWN"
        # UP/AUTO should match.  UP/DOWN shouldn't (ever)
        failed_arr << assert_equal(cmp_ori(up, down), 1, msg1)
        failed_arr << assert_equal(cmp_ori(up, auto), 0, msg2)

        @spinny.spin()
        log_info("Capture UP image with camera DOWN")
        up = get_photo_images(img_dir, "UP", res)
        log_info("Capture DOWN image with camera DOWN")
        down = get_photo_images(img_dir, "DOWN", res)
        log_info("Capture AUTO image with camera DOWN")
        auto = get_photo_images(img_dir, "AUTO", res)

        # Now DOWN/AUTO should match.  UP/DOWN shouldn't (ever)
        failed_arr << assert_equal(cmp_ori(up, down), 1, msg1)
        failed_arr << assert_equal(cmp_ori(down, auto), 0, msg3)

        tu_map_media_after( __FILE__, tc_name )

        next if has_failure?(failed_arr)
        pass("UP/DOWN/AUTO orientation passed.")
        # Delete the directory if everything passed
        @host.rmdir(img_dir)

      rescue WifiCameraError => e
        fail("Camera communication failed.  #{e.to_s}")
      rescue StandardError => e
        fail("Some other error. #{e.to_s}")
        puts e.backtrace.join("\n")
      end # begin...rescue block
    }
  end # test_orient_photo_single

  # TODO test multi-shot modes... and rest of video/photo modes

end # Test

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_VERB
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :photo_resolution, :photo_shutter_ev, :photo_pt, :photo_spot_metering,
      :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :save_dir, :shuffle, :quick, :full, :verb, :rc_info, :range, :keep_media,
      :download_media, :spinny]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil

    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
