# test_wifi_stress_media_list.rb
# Description: Stress tests the wifi by doing a single photo capture, then getting the medialist.

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def intialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    
#    if @options[:ip] != nil and @options[:pc] != nil
#      @camera = get_wifi_camera(@options[:ip], @options[:pc], @options[:serialdev])
#    elsif @options[:serialdev] != nil
#      @camera = get_serial_camera(@options[:serialdev])
#    else
#      log_error("Must specify either serial or ip/pc/serial")
#      exit 1
#    end
    
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.do_factory_reset("USER") if @camera.interfaces.include?(:serial)
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()

    @camera.delete_all_media()
    # Start preview stream on cameras that we want to test it
=begin
    if @camera.test_preview_stream == true
      ret, msg = @host.get_system_camera_ip(@camera.ip)
      ret == true ? @camera.system_address = msg : (log_info(msg); exit 1)
      @camera.send_live_stream_start
      @camera.start_streaming_protocol()
    end
=end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest

    log_info("Deleting all media...")
    @camera.delete_all_media()

    log_info("Going to photo mode...")
    @camera.set_capture_mode("PHOTO") 


    n = 1
    continue_ok = true
    limit = @options[:n_iter] == nil ? 10000 : @options[:n_iter].to_i
    
    while n <= limit and continue_ok
      
      log_info("Performing iteration #{n} of #{limit}")
      set_tc_name("test_wifi_stress_media_list_#{n}")

      n+=1

      before_list = @camera.get_medialist()
      (fail("Could not get before list!"); continue_ok = false; next) unless before_list
      log_verb("Before list: #{before_list}")
      log_verb("Before list count: #{before_list.length}")

      log_info("Doing a capture...")
      @camera.capture_photo_single(@camera.get_photo_resolutions[0])
      
      after_list = @camera.get_medialist()
      (fail("Could not get after list!"); continue_ok = false; next) unless after_list
      log_verb("After list: #{after_list}")
      log_verb("After list count: #{after_list.length}")

      list_diff = after_list - before_list
      log_info("Difference list: #{list_diff}")
      log_info("Difference list count: #{list_diff.length}")
      (fail("Wrong number of resulting files. (Exp=1, Act=#{list_diff.length})"); continue_ok = false; next) unless list_diff.length == 1

      log_pass("No problems this iteration.")

    end
  end

  def cleanup
    @host.kill_status_process() if @host
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure, :n_iter,
      :photo_resolution, :photo_shutter_ev, :photo_pt, :photo_spot_metering,
      :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :save_dir, :shuffle, :quick, :full, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil

    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
