# test_video_looping.rb
# Description: Iterates over all RES/FPS/FOV  (no ProTunes)
#              and tests PIV settings on each.  It encodes
#              video and checks for JPGs.  Also checks for
#              the absence of JPGs on unsupported RES/FPS
#
# Note: Running with the --quick flag will skip all the
# negative tests and all FOV other than wide.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    (log_info("#{@camera.name} doesn't support video looping feature"); exit 1) if !@camera.video_looping_support?

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    @captured = false
    failed_arr = []

    test_params = tu_get_looping_res()

    if test_params == []
      log_warn("No tests to run!  Check RES/FPS/LOOPING values")
    else
      log_info("Running #{test_params.length} test cases")
    end
    test_params.shuffle! if @options[:shuffle]

    counter = 0
    test_params.each() { |vm, res, fps, fov, loo, orient, ll, spot|
      counter += 1
      next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
      log_info("Running test #{counter} of #{test_params.length}")

      ll_str = (ll == "ON") ? "ll_ON" : "ll_OFF" # Meaningful even if ll is nil.
      spot_str = (spot == "ON") ? "spot_ON_" : "spot_OFF_" # Same for spot.

      begin
        tu_keep_or_delete_all_media()
        tu_verify_sd_status()

        before_list = @camera.get_medialist()

        # Set the length of the capture and expected number of chapters
        chap_len = @camera.looping_chapter_len[loo]  # in minutes
        if loo == "MAX"
          n_chap = (@camera.get_mins_avail() / chap_len).to_i - 1
        else
          n_chap = loo.to_i / chap_len
        end

        #TODO - use 'duration = ((n_chap + 1) * chap_len * 60) + 45' when bkdr-1936 is fixed
        # We want to encode for N+1 chapters in seconds + 45 seconds
        # duration = ((n_chap + 1) * chap_len * 60) + 45
        duration = ((n_chap * chap_len * 60) + 15)

        setonly = true
        # For a quick test, just encode the first 5min looping case we see
        # The rest will be setonly
        if @options[:quick] == true
          if @captured == false
            setonly = false if loo.to_s == "5"
            @captured = true
            next
          end
          # On a full test, capture everything
        elsif (@options[:full] == true)
          setonly = false
        else # By default encode all 5 minute looping cases
          setonly = false if loo.to_s == "5"
        end
        cap_str = (setonly == false) ? "capture" : "setonly"
        tc_name = "#{vm}_#{res}_#{fps}_#{fov}_loop_#{loo}min_#{orient}_#{ll_str}_#{spot_str}#{cap_str}"
        set_tc_name( tc_name )

        # Deal with a specified duration. This normally shouldn't be used.
        # It has been added in for Darren, who needs short loopings for data analytics reasons.
        if @options[:duration] != nil
          if @options[:duration_range_low] and @options[:duration_range_high]
            duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
          else
            duration = @options[:duration]
          end
          unless setonly
            log_warn("A duration (of #{duration}) has been specified.")
            log_warn("This is unusual, and may cause looping tests that do capturing to fail.")
            log_warn("The duration is usually based only on the looping interval.")
            log_warn("This might be okay if you are doing looping for data analytics reasons.")
          end
        end

        # Set the settings, and perform the capture if not setonly
        ret, msg = @camera.capture_looping(vm, res, fps, fov, loo, duration, setonly, orient, ll, spot)
        if ret == false
          if msg.match("Insufficient") != nil
            log_skip(msg)
          else
            fail(msg)
          end
          next
        elsif setonly == true
          pass(msg)
          next
        else
          log_info(msg)
        end

        after_list = @camera.get_medialist()
        all_files = after_list - before_list
        tu_map_media_list( __FILE__, tc_name, all_files )
        mp4_files = all_files.reject{ |f| f.split(".")[1] != "MP4" }

        exp_n_chap = n_chap + 1
        act_n_chap = mp4_files.length
        log_info("Checking that we have #{exp_n_chap} chapters")
        failed_arr << assert_equal(exp_n_chap, act_n_chap,
        "Expected #{exp_n_chap} chapters but found #{act_n_chap}")
        mp4_files.each { |f| log_verb("#{f}") }
        fail("Capture unsuccessful") if mp4_files.empty?

        if mp4_files.length < 1
          log_skip("Skipping metadata checks because no MP4 file found")
          next
        end

        #Analyze file naming convention
        exp_obj_num = nil
        exp_grp_num = nil
        index = 0

        mp4_files.sort!.each { |file|
          f = tu_basename(file)
          failed_arr << tu_analyze_file_name("LOOPING_VIDEO", f)
          begin
            grp_num = f[2..3].to_i
            exp_grp_num = grp_num if exp_grp_num == nil
            failed_arr << assert_equal(exp_grp_num, grp_num,
            "(#{f}) Group # exp=#{exp_grp_num}, act=#{grp_num}")
            obj_num = f[4...8].to_i
            exp_obj_num = obj_num if exp_obj_num == nil
            failed_arr << assert_equal(exp_obj_num, obj_num,
            "(#{f}) Object # exp=#{exp_obj_num}, act=#{obj_num}")
            exp_obj_num += 1
          rescue StandardError => e
            failed_arr << "Caught exception #{e}"
            break
          end
          if @camera.interfaces.include?(:wifi)
            failed_arr << tu_wifi_analyze_video_metadata(file, "OFF", res, fps, fov)
            failed_arr << tu_wifi_analyze_gpmedialist_params("VIDEO", vm, "OFF", res, fps, fov)
            failed_arr << tu_wifi_check_media_existence("VIDEO", file, vm, "OFF", res, fps, fov, true) if index == 0
            failed_arr << tu_wifi_check_media_existence("VIDEO", file, vm, "OFF", res, fps, fov, false) if index > 0
          end
          index += 1
        }

        pass "Metadata_checks passed" if not has_failure?(failed_arr)
        failed_arr.clear
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    } # end test_params.each
  end

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @host.kill_status_process() if @host
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  begin
    $LOGLEVEL = $LL_INFO
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only, :video_looping,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :setup_orientation,
      :video_low_light, :quick, :full, :ntsc_only, :pal_only, :range, :duration,
      :set_defaults, :shuffle, :dryrun, :verb, :keep_media, :download_media]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
