# test_gccb_commands

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/gccb_commands'
require_relative '../libs/log_utils'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def my_cam()
    @camera
  end

  def setup(options)

    @run_unit_test = false

    # --quick: run one or a select group of tests 
    #

    @options = options
    @run_unit_test = true if @options[:quick]
    @test_file = __FILE__
    @host = Host.new
    @camera = tu_get_camera()
    @camera.debug_enable(true) if @options[:verb]

    @valid_resolutions  = Hash.new
    @valid_fps          = Hash.new
    @valid_fov          = Hash.new
    @valid_capabilities = Hash.new
    @all_photo_settings = Array.new
    @all_video_settings = Array.new

    @camera.pause_enable(true) if @options[:pause]
    @camera.set_io_delay(@options[:io_delay]) if @options[:io_delay]
    log_info "IO delay=#{@options[:io_delay]}" if @options[:io_delay]
    log_info "Running 'quick' unit-level GCCB test(s)" if @run_unit_test


    #@camera.powerstrip = PowerStrip.new(@options[:power_ip],
    #@options[:power_usr], @options[:power_pwd])
    #@camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    #@camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    #@host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"

    @valid_resolutions=
    {
      "ALL"=>["4K", "2.7K", "1440", "1080_SUPER", "1080", "960", "720_SUPER", "720", "WVGA"],
      "PIV"=>["1440", "1080", "720"],
      "LOWLIGHT"=>["1440", "1080_SUPER", "1080", "960", "720_SUPER", "720"],
      "PROTUNE"=>["4K", "2.7K", "1440", "1080_SUPER", "1080", "960", "720_SUPER", "720", "WVGA"],
      "TIMELAPSE"=>["4K", "2.7K_FS"]
    }
    @valid_fps=
    {

      "ALL"=>{
        "NTSC"=>{"4K"=>["14"], "2.7K"=>["30", "24"], "1440"=>["48", "30", "24"], "1080_SUPER"=>["60", "48", "30", "24"], "1080"=>["60", "48", "30", "24"], "960"=>nil, "720_SUPER"=>nil, "720"=>nil, "WVGA"=>nil},
        "PAL"=>{"4K"=>["12.5"], "2.7K"=>["25", "24"], "1440"=>["48", "25", "24"], "1080_SUPER"=>["50", "48", "25", "24"], "1080"=>["50", "48", "25", "24"], "960"=>nil, "720_SUPER"=>nil, "720"=>nil, "WVGA"=>nil}},

      "PIV"=>{
        "NTSC"=>{"1440"=>["24"], "1080"=>["30", "24"], "720"=>nil},
        "PAL"=>{"1440"=>["24"], "1080"=>["25", "24"], "720"=>nil}},

      "LOWLIGHT"=>{
        "NTSC"=>{"1440"=>["48"], "1080_SUPER"=>["60", "48"], "1080"=>["60", "48"], "960"=>nil, "720_SUPER"=>nil, "720"=>nil},
        "PAL"=>{"1440"=>["48"], "1080_SUPER"=>["50", "48"], "1080"=>["50", "48"], "960"=>nil, "720_SUPER"=>nil, "720"=>nil}},

      "PROTUNE"=>{
        "NTSC"=>{"4K"=>["14"], "2.7K"=>["30", "24"], "1440"=>["48", "30", "24"], "1080_SUPER"=>["60", "48", "30", "24"], "1080"=>["60", "48", "30", "24"], "960"=>nil, "720_SUPER"=>nil, "720"=>nil, "WVGA"=>nil},
        "PAL"=>{"4K"=>["12.5"], "2.7K"=>["25", "24"], "1440"=>["48", "25", "24"], "1080_SUPER"=>["50", "48", "25", "24"], "1080"=>["50", "48", "25", "24"], "960"=>nil, "720_SUPER"=>nil, "720"=>nil, "WVGA"=>nil}},

      "TIMELAPSE"=>{
        "NTSC"=>{"4K"=>["14"], "2.7K_FS"=>["14"]},
        "PAL"=>{"4K"=>["12.5"], "2.7K_FS"=>["12.5"]}}
    }

    @valid_fov=
    {
      "ALL"=>{
        "NTSC"=>{"4K"=>{"14"=>nil}, "2.7K"=>{"30"=>["WIDE", "MEDIUM"], "24"=>nil}, "1440"=>{"48"=>["WIDE"], "30"=>["WIDE"], "24"=>nil}, "1080_SUPER"=>{"60"=>["WIDE"], "48"=>["WIDE"], "30"=>["WIDE"], "24"=>nil}, "1080"=>{"60"=>["WIDE", "MEDIUM", "NARROW"], "48"=>["WIDE", "MEDIUM", "NARROW"], "30"=>["WIDE", "MEDIUM", "NARROW"], "24"=>nil}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}},
        "PAL"=>{"4K"=>{"12.5"=>nil}, "2.7K"=>{"25"=>["WIDE", "MEDIUM"], "24"=>nil}, "1440"=>{"48"=>["WIDE"], "25"=>["WIDE"], "24"=>nil}, "1080_SUPER"=>{"50"=>["WIDE"], "48"=>["WIDE"], "25"=>["WIDE"], "24"=>nil}, "1080"=>{"50"=>["WIDE", "MEDIUM", "NARROW"], "48"=>["WIDE", "MEDIUM", "NARROW"], "25"=>["WIDE", "MEDIUM", "NARROW"], "24"=>nil}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}}},

      "PIV"=>{
        "NTSC"=>{"1440"=>{"24"=>nil}, "1080"=>{"30"=>["WIDE", "MEDIUM", "NARROW"], "24"=>nil}, "720"=>{}},
        "PAL"=>{"1440"=>{"24"=>nil}, "1080"=>{"25"=>["WIDE", "MEDIUM", "NARROW"], "24"=>nil}, "720"=>{}}},

      "LOWLIGHT"=>{
        "NTSC"=>{"1440"=>{"48"=>["WIDE"]}, "1080_SUPER"=>{"60"=>["WIDE"], "48"=>["WIDE"]}, "1080"=>{"60"=>["WIDE", "MEDIUM", "NARROW"], "48"=>["WIDE", "MEDIUM", "NARROW"]}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}},
        "PAL"=>{"1440"=>{"48"=>["WIDE"]}, "1080_SUPER"=>{"50"=>["WIDE"], "48"=>["WIDE"]}, "1080"=>{"50"=>["WIDE", "MEDIUM", "NARROW"], "48"=>["WIDE", "MEDIUM", "NARROW"]}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}}},

      "PROTUNE"=>{
        "NTSC"=>{"4K"=>{"14"=>nil}, "2.7K"=>{"30"=>["WIDE", "MEDIUM"], "24"=>nil}, "1440"=>{"48"=>["WIDE"], "30"=>["WIDE"], "24"=>nil}, "1080_SUPER"=>{"60"=>["WIDE"], "48"=>["WIDE"], "30"=>["WIDE"], "24"=>nil}, "1080"=>{"60"=>["WIDE", "MEDIUM", "NARROW"], "48"=>["WIDE", "MEDIUM", "NARROW"], "30"=>["WIDE", "MEDIUM", "NARROW"], "24"=>nil}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}},
        "PAL"=>{"4K"=>{"12.5"=>nil}, "2.7K"=>{"25"=>["WIDE", "MEDIUM"], "24"=>nil}, "1440"=>{"48"=>["WIDE"], "25"=>["WIDE"], "24"=>nil}, "1080_SUPER"=>{"50"=>["WIDE"], "48"=>["WIDE"], "25"=>["WIDE"], "24"=>nil}, "1080"=>{"50"=>["WIDE", "MEDIUM", "NARROW"], "48"=>["WIDE", "MEDIUM", "NARROW"], "25"=>["WIDE", "MEDIUM", "NARROW"], "24"=>nil}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}}},

      "TIMELAPSE"=>{
        "NTSC"=>{"4K"=>{"14"=>nil}, "2.7K_FS"=>{"14"=>nil}},
        "PAL"=>{"4K"=>{"12.5"=>nil}, "2.7K_FS"=>{"12.5"=>nil}}}
    }

    @valid_capabilities= 
    {
      "ALL"=>
      {"NTSC"=>{"4K"=>{"14"=>{}}, "2.7K"=>{"30"=>{"WIDE"=>true, "MEDIUM"=>true}, "24"=>{}}, "1440"=>{"48"=>{"WIDE"=>true}, "30"=>{"WIDE"=>true}, "24"=>{}}, "1080_SUPER"=>{"60"=>{"WIDE"=>true}, "48"=>{"WIDE"=>true}, "30"=>{"WIDE"=>true}, "24"=>{}}, "1080"=>{"60"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "48"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "30"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "24"=>{}}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}}, 
      "PAL"=>{"4K"=>{"12.5"=>{}}, "2.7K"=>{"25"=>{"WIDE"=>true, "MEDIUM"=>true}, "24"=>{}}, "1440"=>{"48"=>{"WIDE"=>true}, "25"=>{"WIDE"=>true}, "24"=>{}}, "1080_SUPER"=>{"50"=>{"WIDE"=>true}, "48"=>{"WIDE"=>true}, "25"=>{"WIDE"=>true}, "24"=>{}}, "1080"=>{"50"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "48"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "25"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "24"=>{}}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}}}, 

      "PIV"=>
      {"NTSC"=>{"1440"=>{"24"=>{}}, "1080"=>{"30"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "24"=>{}}, "720"=>{}}, 
      "PAL"=>{"1440"=>{"24"=>{}}, "1080"=>{"25"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "24"=>{}}, "720"=>{}}}, 
      
      "LOWLIGHT"=>
      {"NTSC"=>{"1440"=>{"48"=>{"WIDE"=>true}}, "1080_SUPER"=>{"60"=>{"WIDE"=>true}, "48"=>{"WIDE"=>true}}, "1080"=>{"60"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "48"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}}, 
      "PAL"=>{"1440"=>{"48"=>{"WIDE"=>true}}, "1080_SUPER"=>{"50"=>{"WIDE"=>true}, "48"=>{"WIDE"=>true}}, "1080"=>{"50"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "48"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}}}, 

      "PROTUNE"=>
      {"NTSC"=>{"4K"=>{"14"=>{}}, "2.7K"=>{"30"=>{"WIDE"=>true, "MEDIUM"=>true}, "24"=>{}}, "1440"=>{"48"=>{"WIDE"=>true}, "30"=>{"WIDE"=>true}, "24"=>{}}, "1080_SUPER"=>{"60"=>{"WIDE"=>true}, "48"=>{"WIDE"=>true}, "30"=>{"WIDE"=>true}, "24"=>{}}, "1080"=>{"60"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "48"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "30"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "24"=>{}}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}}, 
      "PAL"=>{"4K"=>{"12.5"=>{}}, "2.7K"=>{"25"=>{"WIDE"=>true, "MEDIUM"=>true}, "24"=>{}}, "1440"=>{"48"=>{"WIDE"=>true}, "25"=>{"WIDE"=>true}, "24"=>{}}, "1080_SUPER"=>{"50"=>{"WIDE"=>true}, "48"=>{"WIDE"=>true}, "25"=>{"WIDE"=>true}, "24"=>{}}, "1080"=>{"50"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "48"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "25"=>{"WIDE"=>true, "MEDIUM"=>true, "NARROW"=>true}, "24"=>{}}, "960"=>{}, "720_SUPER"=>{}, "720"=>{}, "WVGA"=>{}}}, 

      "TIMELAPSE"=>
      {"NTSC"=>{"4K"=>{"14"=>{}}, "2.7K_FS"=>{"14"=>{}}}, 
      "PAL"=>{"4K"=>{"12.5"=>{}}, "2.7K_FS"=>{"12.5"=>{}}}}
    }

  end # setup()

  def runtest

    log_info("Deleting all media...")
    @camera.delete_all_media() # Can't perform ota with full disk
    if @run_unit_test

      ####  UNIT LEVEL TESTING of individual tests

      # test_video_settings("NTSC")

      # test_multi_trigger_shutter()  # FAILS START/STOP # PIPE-3031
      #TODO (PIPE-2998): # #test_video_timelapse()  ## HIDDEN IN GCCB

      # test_video_protune_whitebalance() # PASS 1dec15
      # test_video_protune_color() # PASS 1dec15

      test_set_camera_time() # PASS 1dec15
      test_beeps() # PASS 1dec15
      test_leds()  # PASS 1dec15

      # test_video_spotmeter() # PASS 1dec15
      # test_video_timelapse_interval() # PASS 1dec15
      # test_video_protune_sharpness() # pass 1dec15
      # test_video_protune_iso() # pass 1dec15
      # test_video_piv_interval() # pass 1dec15
      # test_video_piv_trigger_shutter()  # fail 2dec15
      # test_video_progress_counter()  # pass 2dec15
      # test_video_get_all_settings() # pass 2dec15, 14dec15
      # test_video_get_all_resolutions() # pass 3dec15
      # test_video_get_all_fps() # pass 3dec15, 14dec15
      # test_video_get_all_fov() # pass 3dec15, 14dec15
      # test_video_get_all_capabilities() # pass 4dec15, 14dec15
      # test_photo_spotmeter() # pass 4dec15
      # test_photo_exp() # pass 4dec15
      # test_photo_whitebalance() # 7dec15
      # test_photo_color() # pass 4dec15
      # test_photo_sharpness() # pass 4dec15
      # test_photo_iso() # pass 4dec15
      # test_photo_ev() # pass 4dec15
      # test_photo_protune_reset() # pass 4dec15
      # test_photo_get_all_settings() # pass 4dec15

      # TODO: TRY THIS???? 
      # test_protune_defaults() # Rod TODO try this

      # test_multi_res() # pass 7dec15
      # test_multi_nightlapse_interval() # 7dec15
      # test_multi_spotmeter() # 7dec15
      # test_multi_exp() # 7dec15

      # test_multi_whitebalance() # 7dec15

      # test_multi_color() # 7dec15
      # test_multi_sharpness() # 7dec15
      # test_multi_iso() # 7dec15
      # test_multi_ev() # 7dec15
      # test_multi_protune_reset() # pass 7dec15
      # test_multi_get_all_settings() # pass 7dec15
      # test_multi_get_shot_countdown() #FAIL 8dec15
      # test_get_firmware_version() # FAIL 9dec15
      # test_get_camera_info() # PASS 9dec15
      # test_get_camera_temps() # pass 10dec15
      # test_get_recording_status() # pass 10dec15
      # test_get_busy_status() # pass 10dec15
      # test_storage_status()  # pass 10dec15
      # test_remaining_photos() # pass 11dec15
      # test_remaining_video() # pass 11dec15
      # test_total_photos() # pass 11dec15
      # test_total_video()  # pass 11dec15
      # test_storage_remaining_space()
      # test_hilight_tags() # FAILING 11dec15 -> TODO: file a bug

   
    else # run full regression test below

      ####  FULL FUNCTIONAL TESTING 
      # ZZ commands
      test_zz_commands()

      # Modes
      test_all_modes()
      test_all_submodes()

      # TODO: TRY THIS???? 
      # test_protune_defaults() # Rod TODO try this

      # Video
      test_video_settings("NTSC")
      test_video_settings("PAL")
      test_video_protune()
      test_video_protune_exposure()
      test_video_protune_whitebalance()
      test_video_protune_color()
      test_video_protune_sharpness()
      test_video_protune_iso()
      test_video_looping()
      test_video_lowlight()
      test_video_protune_onoff()
      test_video_def_submodes()
      test_video_spotmeter()
      test_video_timelapse_interval()
      test_video_piv_interval() 
      test_video_get_all_settings()
      test_video_get_all_resolutions()
      test_video_get_all_fps()
      test_video_get_all_fov()
      test_video_get_all_capabilities()

      # Photo
      test_photo_res()
      test_photo_protune_onoff()
      test_photo_continuous_rates()
      test_photo_def_submodes()
      test_photo_spotmeter()
      test_photo_exp()
      test_photo_whitebalance()
      test_photo_color()
      test_photo_sharpness()
      test_photo_iso()
      test_photo_ev()
      test_photo_protune_reset()
      test_photo_get_all_settings()

      # Multi-Shot
      test_multi_def_submodes()
      test_multi_res()
      test_multi_timelapse_interval()
      test_multi_protune_onoff()
      test_multi_protune_exposure()
      test_multi_burst_rates()
      test_multi_nightlapse_interval()
      test_multi_spotmeter()
      test_multi_exp()
      test_multi_whitebalance()
      test_multi_color()
      test_multi_sharpness()
      test_multi_iso()
      test_multi_ev()
      test_multi_protune_reset()
      test_multi_get_all_settings()
      test_multi_get_shot_countdown()

      # Settings
      test_default_capture_modes()
      test_playback_osd_onoff()
      test_get_battery_level()
      test_beeps()
      test_leds()

      test_delete_last_file()

      test_delete_all_files()
      test_quick_capture_mode()
      test_auto_power_off_delay()
      test_set_camera_time()
      test_locate_camera()

      test_poweroff_cmds()  
      test_video_trigger_shutter()  # FAILS both
      test_multi_trigger_shutter()  # FAILS START/STOP
      test_photo_trigger_shutter()  # FAILS STOP
      test_video_piv_trigger_shutter()  # 
      test_get_firmware_version()
      test_get_camera_info()
      test_get_camera_temps()
      test_get_recording_status()
      test_get_busy_status()


      #### STORAGE
      test_storage_status()
      test_remaining_photos()
      test_remaining_video()
      test_total_photos()
      test_total_video()
      test_storage_remaining_space()
      test_hilight_tags()

      # POWER-OFF the camera at the end of every test
      # Alternatively we can have auto-power-off enabled, but that requires some time of inactivity
      result = @camera.set_power_off("FORCE")  # alternative is "NORMAL". Use FORCE to make sure it's off

    end  # if run_unit_test; else run regression tests

  end # runtest()

  def test_zz_commands()
    puts "test_zz_commands()"

    #camera.zz_get_capabilities()   # WORKS
    #camera.zz_get_firmware_ver()   # WORKS
    #camera.zz_get_protocol_ver()   # FAILS, ack==1
    #camera.zz_get_i2c_speed()   # WORKS

    set_tc_name("ZZ I2C Speed")
    result = @camera.zz_get_i2c_speed()
    puts "I2C Speed=#{result}" if result != nil
    result==nil ? fail() : pass()

    set_tc_name("ZZ capabilities")
    result = @camera.zz_get_capabilities()
    puts "capabilties=#{result}" if result != nil
    result==nil ? fail() : pass()

    set_tc_name("ZZ Firmware Version")
    result = @camera.zz_get_firmware_ver()
    puts "Firmware Version=#{result}" if result != nil
    result==nil ? fail() : pass()

    set_tc_name("ZZ Protocol Version")
    result = @camera.zz_get_protocol_ver()
    puts "Protocol Version=#{result}" if result != nil
    result==nil ? fail() : pass()

  end # test_zz_commands

  # 12.11.15
  def test_hilight_tags()

    # Test-Case:
    #  1. Start video capture
    #  2. Set tag(s)
    #  3. Get tag(s)
    #  4. stop capture
    #  5. check for number of tags increased and timestamps have increased in time
    #
    set_tc_name("Set/Get Hilight Tags")

    result = @camera.set_mode("VIDEO")
    log_fail("Could not set camera mode to VIDEO") if result == nil
    result = @camera.set_video_sub_mode("VIDEO")
    log_fail("Could not set camera mode to VIDEO submode to VIDEO") if result == nil

    log_info "START VIDEO CAPTURE"
    @camera.start_video_capture()
    delay = 5.0
    puts "SLEEP #{delay}"
    sleep delay

    result,msg = @camera.set_hilight_tag()  # First TAG
    log_fail(msg) if result == false
    result,msg,num_tags1,tag_timestamp1 = @camera.get_hilight_tags()  # Get First TAG timestamp
    log_fail(msg) if result == false

    delay = 3.0
    log_info "SLEEP #{delay}"

    result,msg = @camera.set_hilight_tag()  # Second TAG
    log_fail(msg) if result == false
    result,msg,num_tags2,tag_timestamp2 = @camera.get_hilight_tags()  # Get Second TAG timestamp
    log_fail(msg) if result == false

    delay = 2.0
    log_info "SLEEP #{delay}"

    log_info "STOP VIDEO CAPTURE"
    @camera.stop_video_capture()

    # CHECKS
    nt1 = num_tags1.to_i
    nt2 = num_tags2.to_i
    ts1 = tag_timestamp1.to_i
    ts2 = tag_timestamp2.to_i
    log_fail("2nd num_tags(#{nt2}) should be greater than 1st num_tags(#{nt1})") if nt2 <= nt1
    log_fail("2nd tag timestamp(#{ts2}) should be greater than 1st tag timestamp(#{ts2})") if ts2 <= ts1

    log_pass("num_tags=#{nt2} tag1_timestamp=#{ts1} tag2_timestamp=#{ts2}")

  end # test_hilight_tags

  # 12.11.15
  def test_total_video()

    set_tc_name("Total Videos")

    # Test case steps:
    #
    # 1. set camera to VIDEO mode
    # 2. get the total video avail
    # 3. encode video
    # 2. get the total video avail
    # 4. Check that total video INCREMENTED
    # (Also check for any errors along the way)

    result = @camera.set_mode("VIDEO")
    log_fail("Could not set camera mode to VIDEO") if result == nil
    result = @camera.set_video_sub_mode("VIDEO")
    log_fail("Could not set camera mode to VIDEO submode to VIDEO") if result == nil

    total_video = @camera.get_video_count()
    if total_video == nil
      log_fail(msg)
    else
      total_video_before=total_video
      log_info("Remaining video BEFORE=#{total_video}")
    end

    log_info("Trigger Video Shutter")
    result,msg,verified = @camera.start_video_capture()
    # TODO: log_fail(msg) if result == nil   # VIDEO start capture is broken

    delay = 3.0
    log_info("sleep #{delay}...")
    sleep delay

    log_info("STOP Video Shutter")
    result,msg,verified = @camera.stop_video_capture()
    # TODO: log_fail(msg) if result == nil  # VIDEO stop capture is broken

    delay = 5.0
    log_info("sleep #{delay}...")
    sleep delay


    total_video = @camera.get_video_count()
    if total_video == nil
      log_fail(msg)
    else
      total_video_after=total_video
      log_info("Remaining video AFTER=#{total_video}")
    end

    # Check to see that the total video INCREMENTED. If so, PASS, else FAIL
    (total_video_after.to_i > total_video_before) ? pass() : fail()

  end # test_total_video()

  # 12.11.15
  def test_remaining_video()

    set_tc_name("Remaining video")

    # Test case steps:
    #
    # 1. set camera to PHOTO-SINGLE mode
    # 2. get the remaining video avail
    # 3. take a picture
    # 2. get the remaining video avail
    # 4. Check that remaining video DECREMENTED
    # (Also check for any errors along the way)

    result = @camera.set_mode("VIDEO")
    log_fail("Could not set camera mode to VIDEO") if result == nil
    result = @camera.set_video_sub_mode("VIDEO")
    log_fail("Could not set camera mode to VIDEO submode to VIDEO") if result == nil

    rem_video = @camera.get_rem_videos()
    if rem_video == nil
      log_fail(msg)
    else
      rem_video_before=rem_video
      log_info("Remaining video BEFORE=#{rem_video}")
    end

    log_info("Trigger Video Shutter")
    result,msg,verified = @camera.start_video_capture()
    # TODO: log_fail(msg) if result == nil

    delay = 3.0
    log_info("sleep #{delay}...")
    sleep delay

    log_info("STOP Video Shutter")
    result,msg,verified = @camera.stop_video_capture()
    # TODO: log_fail(msg) if result == nil

    delay = 5.0
    log_info("sleep #{delay}...")
    sleep delay


    rem_video = @camera.get_rem_videos()
    if rem_video == nil
      log_fail(msg)
    else
      rem_video_after=rem_video
      log_info("Remaining video AFTER=#{rem_video}")
    end

    # Check to see that the remaining video DECREMENTED. If so, PASS, else FAIL
    (rem_video_after.to_i < rem_video_before) ? pass() : fail()

  end # test_remaining_video()

  # 12.11.15
  def test_total_photos()

    set_tc_name("Total Photos")

    # Test case steps:
    #
    # 1. set camera to PHOTO-SINGLE mode
    # 2. get the total photos avail
    # 3. take a picture
    # 2. get the total photos avail
    # 4. Check that total photos INCREMENTED
    # (Also check for any errors along the way)

    result = @camera.set_mode("PHOTO")
    log_fail("Could not set camera mode to PHOTO") if result == nil
    result = @camera.set_photo_sub_mode("SINGLE")
    log_fail("Could not set camera mode to PHOTO submode to SINGLE") if result == nil

    total_photos = @camera.get_photo_count()
    if total_photos == nil
      log_fail(msg)
    else
      total_photos_before=total_photos
      log_info("Total Photos BEFORE=#{total_photos}")
    end

    log_info("Trigger Photo-Single Shutter")
    result,msg,verified = @camera.start_photo_capture()
    log_fail(msg) if result == nil

    delay = 3.0
    log_info("sleep #{delay}...")
    sleep delay

    total_photos = @camera.get_photo_count()
    if total_photos == nil
      log_fail(msg)
    else
      total_photos_after=total_photos
      log_info("Total Photos AFTER=#{total_photos}")
    end

    # Check to see that the total photos INCREMENTED. If so, PASS, else FAIL
    (total_photos_after.to_i > total_photos_before) ? pass() : fail()

  end # test_remaining_photos()


  # 12.11.15
  def test_remaining_photos()

    set_tc_name("Remaining Photos")

    # Test case steps:
    #
    # 1. set camera to PHOTO-SINGLE mode
    # 2. get the remaining photos avail
    # 3. take a picture
    # 2. get the remaining photos avail
    # 4. Check that remaining photos DECREMENTED
    # (Also check for any errors along the way)

    result = @camera.set_mode("PHOTO")
    log_fail("Could not set camera mode to PHOTO") if result == nil
    result = @camera.set_photo_sub_mode("SINGLE")
    log_fail("Could not set camera mode to PHOTO submode to SINGLE") if result == nil

    rem_photos = @camera.get_rem_photos()
    if rem_photos == nil
      log_fail(msg)
    else
      rem_photos_before=rem_photos
      log_info("Remaining Photos BEFORE=#{rem_photos}")
    end

    log_info("Trigger Photo-Single Shutter")
    result,msg,verified = @camera.start_photo_capture()
    log_fail(msg) if result == nil

    delay = 3.0
    log_info("sleep #{delay}...")
    sleep delay

    rem_photos = @camera.get_rem_photos()
    if rem_photos == nil
      log_fail(msg)
    else
      rem_photos_after=rem_photos
      log_info("Remaining Photos AFTER=#{rem_photos}")
    end

    # Check to see that the remaining photos DECREMENTED. If so, PASS, else FAIL
    (rem_photos_after.to_i < rem_photos_before) ? pass() : fail()

  end # test_remaining_photos()

  # 12.14.15
  def test_storage_remaining_space()
    set_tc_name("Storage Remaining Space")
    # TODO cases:
    # 0. Get storage space
    # 3. record video
    # 0. Get storage space
    # 4. Check that storage space decreased

    result = @camera.set_mode("PHOTO")
    log_fail("Could not set camera mode to PHOTO") if result == nil
    result = @camera.set_photo_sub_mode("SINGLE")
    log_fail("Could not set camera mode to PHOTO submode to SINGLE") if result == nil

    result,msg,rem_space_before = @camera.get_storage_remspace()
    if result==false
      log_fail(msg)
    else
      log_info("Remaining Space BEFORE=#{rem_space_before}")
    end

    log_info("Trigger Photo-Single Shutter")
    result,msg,verified = @camera.start_photo_capture()
    log_fail(msg) if result == nil

    delay = 3.0
    log_info("sleep #{delay}...")
    sleep delay

    result,msg,rem_space_after = @camera.get_storage_remspace()
    if result==false
      log_fail(msg)
    else
      log_info("Remaining Space AFTER=#{rem_space_after}")
    end

    # Check to see that the remaining space DECREMENTED. If so, PASS, else FAIL

    if (rem_space_before.to_i > rem_space_after.to_i) 
      tmsg = "before: #{rem_space_before} > after:#{rem_space_after}"
      log_pass(tmsg) 
    else
      tmsg = "before: #{rem_space_before} <= after:#{rem_space_after}"
      log_fail(tmsg)
    end

  end # test_storage_remaining_space

  # 12.10.15
  def test_storage_status()

    set_tc_name("Storage Status")
    # TODO cases:
    # 0. nothing with sd card in, not full
    # 1. put in full sdcard
    # 2. remove sdcard
    # 3. record video
    # 4. unformatted sdcard

    # case 0:
    storage_sts = @camera.storage_status_event()
    if storage_sts == nil
      fail()
    else
      log_info("storage status=#{storage_sts}")
      pass()
    end
  end

  # 12.10.15
  def test_get_busy_status()

    set_tc_name("Get Camera Busy Status")
    busy_sts = @camera.get_busy_status()
    if busy_sts == nil
      fail()
    else
      log_info("busy status=#{busy_sts}")
      pass()
    end
  end

  # 12.10.15
  def test_get_recording_status()

    set_tc_name("Get Camera Recording Status")
    recording_sts = @camera.get_recording_status()
    if recording_sts == nil
      fail()
    else
      log_info("recording status=#{recording_sts}")
      pass()
    end
  end

  # 12.10.15
  def test_get_camera_temps()

    set_tc_name("Get Camera Temperature Warning")
    temp_warning = @camera.get_cam_temp_warning()
    if temp_warning == nil
      fail()
    else
      log_info("temperature warning=#{temp_warning}")
      pass()
    end

    set_tc_name("Get Camera Temperatures")
    x,y,z = @camera.get_cam_temperatures(); puts "temps: cpu=#{x} battery=#{y} sensor=#{z}"
    if x == nil
      fail() 
      # log_fail("get camera temperatures failed")
    else
      log_info("temperatures: cpu=#{x} battery=#{y} image_sensor=#{z}")
      pass()
    end

  end

  # 12.9.15
  def test_get_camera_info()
    set_tc_name("Get Camera Info")
    result,msg,id,name,ver = @camera.get_camera_info()
    log_info("get_camera_info: result=#{result},camera_id=#{id},camera_name=\"#{name}\",ver=#{ver}") if result
    log_info("get_camera_info: ERROR result=#{result} msg=#{msg}") if not result
    result ? pass() : fail()
  end

  # 12.8.15
  def test_get_firmware_version()
    set_tc_name("Get Firmware Version")
    result,msg,fwver = @camera.get_firmware_ver()
    puts "Firmware Version=#{fwver}" if result != nil
    puts "ERROR: #{msg}" if result == nil
    result==nil ? fail() : pass()
  end

  def test_all_modes()
    puts "test_all_modes()"
    @camera.mode_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("set mode #{mode_name}")
      result = @camera.set_mode(mode_name)
      result ? pass() : fail()
    end
  end

  def test_all_submodes()
    puts "test_all_submodes()"
    @camera.mode_cmds[:settings].each do |mode_name,mode_val|
      submode_hash = @camera.mode_cmds[:submodes][mode_name]
      puts "MODE=#{mode_name}"
      next if submode_hash==nil
      set_tc_name("set mode #{mode_name}")
      result = @camera.set_mode(mode_name)
      fail if !result
      pass if result
      submode_hash[:settings].each do |submode_name, submode_val|
        puts "SUBMODE=#{submode_name}"
        set_tc_name("set #{mode_name} submode to #{submode_name}")
        result = @camera.set_sub_mode(submode_hash, submode_name)
        result ? pass() : fail()
      end
    end
  end

  # 3dec15
  # WARNING: *MUST* execute the following tests first:
  #  1. test_video_get_all_resolutions()
  #  2. test_video_get_all_fps()
  #  3. test_video_get_all_fov()
  #
  def test_video_get_all_capabilities()

    @camera.video_get_all_capabilities_cmd[:filters].each do |filter,v1|
      @valid_capabilities[filter]         = Hash.new

      @camera.vid_mode_cmds[:settings].each do |vfmt, v2| 

        @valid_capabilities[filter][vfmt] = Hash.new

        @camera.set_video_format(vfmt)

        @valid_resolutions[filter].each do |res|
          # puts "***IGNORING res=#{res}" if res==nil
          # next if res==nil
          @valid_capabilities[filter][vfmt][res] = Hash.new

          log_info "NIL for @valid_fps[filter=#{filter} fmt=#{vfmt} res=#{res}]" if @valid_fps[filter][vfmt][res] == nil
          next if @valid_fps[filter][vfmt][res] == nil
          @valid_fps[filter][vfmt][res].each do |fps|
            # puts "***IGNORING FPS=#{fps}" if res==nil
            # next if fps==nil
            @valid_capabilities[filter][vfmt][res][fps] = Hash.new

            # puts "filter=#{filter} fmt=#{vfmt} res=#{res} fps=#{fps}"
            log_info "NIL for @valid_fov[filter=#{filter} fmt=#{vfmt} res=#{res} fps=#{fps}]" if @valid_fov[filter][vfmt][res][fps] == nil
            next if @valid_fov[filter][vfmt][res][fps] == nil
            @valid_fov[filter][vfmt][res][fps].each do |fov|

              capabilities_list = "#{filter}, #{vfmt}, #{res}, #{fps}, #{fov}"
              tmsg = "CAPABILITIES CHECK FOR #{capabilities_list}"
              set_tc_name(tmsg)

              # get_video_all_capabilities():
              #  returns: true or false , if camera is capable of all these settings specified
              is_capable, msg = @camera.get_video_all_capabilities(filter, vfmt, res, fps, fov)

              # log_info("CAPABILITIES RESULT for #{filter}, #{vfmt}, #{res}, #{fps}, #{fov}==#{is_capable}") if @debug
              @valid_capabilities[filter][vfmt][res][fps][fov] = is_capable  # true or false
              if is_capable
                rmsg = "VALID"
                log_pass(rmsg)
              else
                rmsg = "NOT SUPPORTED: ERROR msg=#{msg}"
                log_fail(rmsg)
              end
            end # fov

          end # fps

        end # res

      end # format

    end # filter (ALL,PIV,PROTUNE,TIMELAPSE)

    return @valid_capabilities

  end # test_video_get_all_capabilities

  # 3dec15
  # WARNING: *MUST* execute the following tests first:
  #  1. test_video_get_all_resolutions() first
  #  2. test_video_get_all_fps() first
  #
  def test_video_get_all_fov()

    @camera.video_get_all_fov_cmd[:filters].each do |filter,v1|
      @valid_fov[filter]         = Hash.new

      @camera.vid_mode_cmds[:settings].each do |vfmt, v2| 

        @valid_fov[filter][vfmt] = Hash.new

        @camera.set_video_format(vfmt)

        @valid_resolutions[filter].each do |res|
          puts "***IGNORING res=#{res}" if res==nil
          next if res==nil
          @valid_fov[filter][vfmt][res] = Hash.new

          puts "***IGNORING FPS is nil for #{filter} #{vfmt}" if @valid_fps[filter][vfmt][res] == nil
          next if @valid_fps[filter][vfmt][res] == nil
          @valid_fps[filter][vfmt][res].each do |fps|
            puts "***IGNORING FPS=#{fps}" if res==nil
            next if fps==nil

            set_tc_name("Video Get FOV settings for #{filter},#{vfmt},#{res},#{fps}")

            result, msg, all_video_fov  = @camera.get_video_all_fov(filter, vfmt, res, fps)

            @valid_fov[filter][vfmt][res][fps] = all_video_fov

            if result==true
              pmsg="#{all_video_fov}"
              log_pass(pmsg)
            else
              fmsg="#{msg}"
              log_fail(fmsg)
            end

          end # fps

        end # res

      end # format

    end # filter (ALL,PIV,PROTUNE,TIMELAPSE)

    puts ""
    log_info("VALID VIDEO FOVs=#{@valid_fov}")
    puts ""

    return @valid_fov

  end # test_video_get_all_fov

  # 3dec15
  # WARNING: *MUST* execute test_video_get_all_resolutions() first
  #
  def test_video_get_all_fps()

    @camera.video_get_all_fps_cmd[:filters].each do |filter,v1|

      @valid_fps[filter]         = Hash.new

      @camera.vid_mode_cmds[:settings].each do |vfmt, v2| 

        @valid_fps[filter][vfmt] = Hash.new
        @camera.set_video_format(vfmt)
        #@camera.vid_res_cmds[:settings].each do |res, v3|  # WARNING: don't do this because of illegal resolutions

        @valid_resolutions[filter].each do |res|

          set_tc_name("Video Get FPS settings for #{filter},#{vfmt},#{res}")

          result, msg, all_video_fps = @camera.get_video_all_fps(filter, vfmt, res)

          # result = (all_video_fps!=nil) && (all_video_fps.length > 0)

          @valid_fps[filter][vfmt][res] = all_video_fps

          if result==true
            pmsg="#{all_video_fps}"
            log_pass(pmsg)
          else
            fmsg="#{msg}"
            log_fail(fmsg)
          end

        end # resolution

      end # video format

    end # filter (ALL,PIV,PROTUNE,TIMELAPSE)

    puts ""
    log_info("VALID VIDEO FPS=#{@valid_fps}")
    puts ""

    return @valid_fps

  end # test_video_get_all_fps

  # 3dec15
  # test AND build the valid video resolutions for ALL,PIV,PROTUNE,TIMELAPSE
  #
  # NOTE: This *MUST* be executed before the following tests:
  #     test_video_get_all_fps
  #     test_video_get_all_fov
  #
  def test_video_get_all_resolutions()

    @camera.video_get_all_resolutions_cmd[:settings].each do |filter,mode_val|

      set_tc_name("Video Get #{filter} Resolutions")

      result, msg, all_video_resolutions = @camera.get_video_all_resolutions(filter)

      if result==true
        @valid_resolutions[filter] = all_video_resolutions
        pmsg="#{all_video_resolutions}"
        log_pass(pmsg)
      else
        fmsg="#{msg}"
        log_fail(fmsg)
      end

    end

    puts ""
    log_info("VALID VIDEO RESOLUTIONS=#{@valid_resolutions}")
    puts ""

    return @valid_resolutions

  end

  # 2dec15
  # Sample:
  #   INFO : GCCB command: YY 0 0 7 2 1D 0 0
  #   INFO : GET response: 22 0 0 0 10 13 2 1D 0 0 18 0 0 D 0 0 4 4 0 1 6 1 1 2 2 8 4 0 0 0 0 0 0 0 0  
  #   dm=0 res=D fps=0 fov=0 piv=4 loop=4 spot=0 lowlt=1 tl=6 pt=1 color=1 sharp=2 iso=2 ev=8 wb=4
  #   INFO : Pre-defined order:  [dm,res,fps,fov,piv,loop,spot,lowlt,tl,pt,color,sharp,iso,ev,wb]
  #   PASS : Video Get All Settings : ["0", "D", "0", "0", "4", "4", "0", "1", "6", "1", "1", "2", "2", "8", "4"]
  #
  def test_video_get_all_settings()
    set_tc_name("Video Get All Settings")

    puts "#TODO: "
    puts "# 1. get all video settings, and save"
    puts "# 2. Change each video setting"
    puts "# 3. get all video settings, and compare"
    puts ""

    result, msg, @all_video_settings = @camera.get_video_all_settings()

    # log_info("@all_video_settings==#{@all_video_settings}")
    log_info("Pre-defined order:  [dm,res,fps,fov,piv,loop,spot,lowlt,tl,pt,color,sharp,iso,ev,wb]")

    if result==true
      vs = @all_video_settings

      val = vs[0].to_i
      ic = @camera.video_def_sub_mode_cmds[:settings].invert
      dm = ic[val]

      val = vs[1].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      res = ic[val]

      val = vs[2].to_i
      ic = @camera.vid_fps_cmds[:settings].invert
      fps = ic[val]

      val = vs[3].to_i
      ic = @camera.vid_fov_cmds[:settings].invert
      fov = ic[val]

      val = vs[4].to_i
      ic = @camera.video_piv_interval_cmds[:settings].invert
      piv = ic[val]

      val = vs[5].to_i
      ic = @camera.video_looping_cmds[:settings].invert
      loop = ic[val]

      val = vs[6].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      spot = ic[val]

      val = vs[7].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      lowlt = ic[val]

      val = vs[8].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      tl = ic[val]

      val = vs[9].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      pt = ic[val]

      val = vs[10].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      color = ic[val]

      val = vs[11].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      sharp = ic[val]

      val = vs[12].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      iso = ic[val]

      val = vs[13].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      ev = ic[val]

      val = vs[14].to_i
      ic = @camera.vid_res_cmds[:settings].invert
      wb = ic[val]

      puts "dm=#{dm} #{ic[dm]}"

      pmsg="#{@all_video_settings}"
      log_pass(pmsg)
    else
      fmsg="#{msg}"
      log_fail(fmsg)
    end

    return @all_video_settings
  end

  # 2dec15
  def test_video_progress_counter()
    # puts "test_video_progress_counter()"
    set_tc_name("Video Progress Counter")

    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")

    @camera.start_video_capture()

    sec_delay = 10.0
    counter1 = @camera.get_video_progress_counter()
    log_info("video_progress_counter=#{counter1}")
    log_info("Sleeping #{sec_delay}s to see change in the video_progress counter...")
    sleep (10.0)
    counter2 = @camera.get_video_progress_counter()
    log_info("video_progress_counter=#{counter2}")
    result = (counter1 > 0) && (counter2 > 0) && (counter1 < counter2) 
    result ? pass() : fail()

    @camera.stop_video_capture()
  end

  # 2dec15
  def test_video_piv_trigger_shutter()
    puts "test_video_piv_trigger_shutter()"

    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("PIV")

    set_tc_name("set video PIV trigger shutter START")
    result = @camera.start_video_capture()
    result ? pass() : fail()

    sleep (10.0)

    set_tc_name("set video PIV trigger shutter STOP")
    result = @camera.stop_video_capture()
    result ? pass() : fail()
  end

  def test_video_trigger_shutter()
    puts "test_video_trigger_shutter()"

    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")

    set_tc_name("set video trigger shutter START")
    result = @camera.start_video_capture()
    result ? pass() : fail()

    sleep (10.0)

    set_tc_name("set video trigger shutter STOP")
    result = @camera.stop_video_capture()
    result ? pass() : fail()
  end

  def test_photo_trigger_shutter()
    puts "test_photo_trigger_shutter()"

    @camera.set_mode("PHOTO")
    @camera.set_photo_sub_mode("CONTINUOUS")

    set_tc_name("set photo trigger shutter START")
    result = @camera.start_photo_capture()
    result ? pass() : fail()

    # Don't delay as this should take 30 shots in 6 seconds
    # Turn off the shutter right away while it is still busy

    set_tc_name("set photo trigger shutter STOP")
    result = @camera.stop_photo_capture()
    result ? pass() : fail()
  end

  def test_multi_trigger_shutter()
    puts "test_multi_trigger_shutter()"

    @camera.set_mode("MULTI_SHOT")
    @camera.set_multi_sub_mode("TIME_LAPSE")

    set_tc_name("set multi trigger shutter START")
    result = @camera.start_multi_capture()
    result ? pass() : fail()

    sleep (5.0)

    set_tc_name("set multi trigger shutter STOP")
    result = @camera.stop_multi_capture()
    result ? pass() : fail()
  end

  def test_locate_camera()
    puts "test locate_camera()"
    @camera.set_mode("SETTINGS")
    @camera.locate_camera_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("set camera locate  #{mode_name}")
      result = @camera.set_locate_camera(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_set_camera_time()
    puts "test_set_camera_time()"
    @camera.set_mode("SETTINGS")
    set_tc_name("Set camera time")
    #year=2016
    #mon=1
    #day=2
    #hr=3
    #min=4
    #sec=5
    year=2015
    mon=11
    day=20
    hr=17
    min=30
    sec=0
    log_info  "SET: #{year} #{mon} #{day} #{hr} #{min} #{sec}"
    result = @camera.set_camera_time(year,mon,day,hr,min,sec)
    if not result
      fail()
      return
    end
    sec_delay = 5
    log_info("Sleeping #{sec_delay}s to see change in seconds...")
    sleep sec_delay
    y,mo,d,h,mi,s,dow = @camera.get_camera_time()
    log_info  "GET: #{y} #{mo} #{d} #{h} #{mi} #{s} dayOfWeek:#{dow}"
    #if (y==nil) or (y != year) or (mo != mon) or (d != day) or (h != hr) or (mi != min)
    if  y.to_i != year.to_i
      log_warn "Camera year does NOT match set values"
      fail()
      return
    end
    if  mo.to_i != mon
      log_warn "Camera month does NOT match set values"
      fail()
      return
    end
    if  d.to_i != day
      log_warn "Camera day does NOT match set values"
      fail()
      return
    end
    if  h.to_i != hr
      log_warn "Camera hour does NOT match set values"
      fail()
      return
    end
    if  mi.to_i != min
      log_warn "Camera minute does NOT match set values"
      fail()
      return
    end
    if  s.to_i != (sec + sec_delay)
      log_fail "Camera seconds does NOT match set values"
      return
    end
    pass()
  end

  # Tested 9.9.15
  def test_auto_power_off_delay()
    puts "test_auto_power_off_delay()"
    @camera.set_mode("SETTINGS")
    @camera.auto_off_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("settings auto power-off delay #{mode_name}")
      result = @camera.set_auto_off(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested 9.9.15
  def test_quick_capture_mode()
    puts "test_quick_capture_mode()"
    @camera.obm_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("settings quick capture mode #{mode_name}")
      result = @camera.set_quickcapture(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested 9.9.15
  def test_delete_last_file()
    # TODO Test procedure:
    # 1. capture a few video shots (set video mode first)
    # 2. capture a few photo shots (set photo mode first)
    # 3. delete last file
    # 4. wifi-verify that the last photo shot was deleted and count deleted, not video
    # 5. capture one video shot
    # 6. delete last file
    # 7. wifi-verify that the last video was deleted and count deleted, not photo
    puts "test_delete_last_file()"
    set_tc_name("delete last file")
    @camera.set_mode("SETTINGS")
    result = @camera.storage_delete_last()
    result ? pass() : fail()
  end

  # Tested 9.9.15
  def test_delete_all_files()
    # TODO Test procedure:
    # 1. capture a few video shots (set video mode first)
    # 2. capture a few photo shots (set photo mode first)
    # 3. delete all files
    # 4. wifi-verify that all photos and videos counts on card are at 0
    puts "test_delete_all_files()"
    set_tc_name("delete all files")
    @camera.set_mode("SETTINGS")
    result = @camera.storage_delete_all()
    result ? pass() : fail()
  end

  # Tested 9.3.15
  def test_get_battery_level()
    puts "test_get_battery_level()"
    @camera.set_mode("SETTINGS")
    set_tc_name("get battery level information")
    result,msg,percent,bars,state = @camera.get_battery_level()
    log_info("get_battery_level(): result=#{result} msg=#{msg} percent=#{percent} bars=#{bars} state=#{state}")
    result ? pass() : fail()
  end

  # Tested
  def test_poweroff_cmds(poweroff_type=nil)
    # Commented out single way of doing it
    #puts "test_poweroff_cmds()"
    #set_tc_name("power off cmd #{poweroff_type}")
    #result = @camera.set_power_off(poweroff_type)
    #result ? pass() : fail()

    # Loop through both NORMAL and FORCE power-off modes
    @camera.power_off_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("power off cmd #{mode_name}")
      result = @camera.set_power_off(mode_name)
      # NOTE: Get-verification is turned off for the gccb_camera set() call. But a good reply is checked
      result ? pass() : fail()
      ### IMPORTANT delay: MUST WAIT otherwise cannot communicate with camera via GCCB
      puts "sleeping 10s waiting for poweroff..."; sleep(10.0)
      # Recover from power-off (NOTE: MUST DO otherwise camera/gccb is unusable)
      @camera.reinitialize_gccb()
      sleep(5.0)
    end
  end

  # Tested
  def test_playback_osd_onoff()
    puts "test_playback_osd_onoff()"
    @camera.set_mode("SETTINGS")
    @camera.playback_osd_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("settings playback osd #{mode_name}")
      result = @camera.set_pb_osd_onoff(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_photo_continuous_rates()
    puts "test_photo_continuous_rates()"
    @camera.set_mode("PHOTO")
    @camera.set_video_sub_mode("CONTINUOUS")
    @camera.photo_sps_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo continuous rate #{mode_name}")
      result = @camera.set_sps(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_photo_def_submodes()
    puts "test_photo_def_submodes()"
    @camera.photo_def_sub_mode_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo default power-on submode #{mode_name}")
      result = @camera.set_photo_def_sub_mode(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_multi_def_submodes()
    puts "test_multi_def_submodes()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_video_sub_mode("TIME_LAPSE")
    @camera.multi_def_sub_mode_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi default power-on submode #{mode_name}")
      result = @camera.set_multi_def_sub_mode(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_video_def_submodes()
    puts "test_video_def_submodes()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_def_sub_mode_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("video default power-on submode #{mode_name}")
      result = @camera.set_video_def_sub_mode(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_photo_protune_onoff()
    puts "test_photo_protune_onoff()"
    @camera.set_mode("PHOTO")
    @camera.set_video_sub_mode("SINGLE")
    @camera.photo_protune_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo protune command #{mode_name}")
      result = @camera.set_photo_protune(mode_name)
      result ? pass() : fail()
    end
  end

  # Implemented: 1dec15
  # Tested: pass
  def test_leds()
    puts "test_leds()"
    @camera.led_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("Number of leds #{mode_name}")
      result = @camera.set_led(mode_name)
      result ? pass() : fail()
    end
  end

  # Implemented: 1dec15
  # Tested: pass
  def test_beeps()
    puts "test_beeps()"
    @camera.beep_sound_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("Number of beeps #{mode_name}")
      result = @camera.set_beeps(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_default_capture_modes()
    puts "test_default_capture_modes()"
    @camera.default_mode_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("default capture mode #{mode_name}")
      result = @camera.set_default_capture_mode(mode_name)
      result ? pass() : fail()
    end
  end


  # Tested
  def test_video_protune_onoff()
    puts "test_video_protune_onoff()"
    @camera.video_protune_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("video protune command #{mode_name}")
      result = @camera.set_video_protune(mode_name)
      result ? pass() : fail()
    end
  end

  ###########  PHOTO TESTS #############
  # 4dec15
  def test_photo_protune_reset()
    puts "test_photo_protune_reset()"
    set_tc_name("Photo Protune RESET")



    # Set to NON-defaults
    # @camera.set_photo_spot_metering("ON") # NOT affected by RESET
    # @camera.set_photo_protune("ON") # NOT affected by RESET
    @camera.set_photo_exp(30)  # NOT affected by RESET?
    @camera.set_photo_color("flat")
    @camera.set_photo_sharpness("MED")
    @camera.set_photo_iso(400)
    color     = @camera.get_photo_color()
    sharpness = @camera.get_photo_sharpness()
    iso       = @camera.get_photo_iso()
    log_info("test_photo_protune_reset(): PRE-RESET color=#{color} sharpness=#{sharpness} iso=#{iso}")


    ## RESET
    result = @camera.set_photo_protune_reset()
    fail() if not result  # fail if command itself failed

    # DEFAULTs (after RESET) are:
    #
    #  color            : gopro_color
    #  sharpness        : HIGH
    #  iso              : 800
    #
    # IGNORE  photo protune    : ON
    # IGNORE  photo spot-meter : ON
    # IGNORE  exp              : 10
    #
    # x = @camera.get_photo_spot_metering(); puts "photo spot-meter=#{spotval}" # NOT AFFECTED by RESET
    # x = @camera.get_photo_protune(); puts "protune=#{x}" # NOT AFFECTED by RESET
    # x = @camera.get_photo_exp(); puts "exp=#{x}"
    def_color     = @camera.get_photo_color()    ; puts "DEFAULT color=#{def_color}"
    def_sharpness = @camera.get_photo_sharpness(); puts "DEFAULT sharpness=#{def_sharpness}"
    def_iso       = @camera.get_photo_iso()      ; puts "DEFAULT iso=#{def_iso}"
    log_info("test_photo_protune_reset(): POST-RESET color=#{def_color} sharpness=#{def_sharpness} iso=#{def_iso} (DEFAULTS)")

    result = (def_color != color) && (def_sharpness != sharpness) && (def_iso != iso) 

    result ? pass() : fail()
  end

  # 4dec15
  def test_photo_sharpness()
    puts "test_photo_sharpness()"
    @camera.photo_sharpness_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo sharpness #{mode_name}")
      result = @camera.set_photo_sharpness(mode_name)
      result ? pass() : fail()
    end
  end

  # 4dec15
  def test_photo_iso()
    puts "test_photo_iso()"
    @camera.photo_iso_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo iso #{mode_name}")
      result = @camera.set_photo_iso(mode_name)
      result ? pass() : fail()
    end
  end

  # 4dec15
  def test_photo_ev()
    puts "test_photo_ev()"
    # @camera.set_mode("PHOTO")
    # @camera.set_video_sub_mode("SINGLE")
    @camera.photo_protune_exposure_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo protune exposure #{mode_name}")
      result = @camera.set_photo_protune_exposure(mode_name)
      result ? pass() : fail()
    end
  end

  #
  def test_photo_get_all_settings()
    puts "test_photo_get_all_settings()"
    # @camera.set_mode("PHOTO")
    # @camera.set_video_sub_mode("SINGLE")
    set_tc_name("photo get_all_settings")

    puts "#TODO: "
    puts "# 1. get all photo settings, and save"
    puts "# 2. Change each photo setting"
    puts "# 3. get all photo settings, and compare"
    @all_photo_settings = @camera.get_photo_all_settings()

    log_info("All Photo Settings==#{@all_photo_settings}")
    log_info("Pre-defined order:  [dm,cm,res,cont_rate,spot,exp_time,pt,color,sharp,iso,ev,wb,iso_min]")
    result = (@all_photo_settings!=nil)
    result ? pass() : fail()
  end

  # 4dec15
  def test_photo_color()
    puts "test_photo_color()"
    # @camera.set_mode("PHOTO")
    # @camera.set_video_sub_mode("SINGLE")
    @camera.photo_color_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo color #{mode_name}")
      result = @camera.set_photo_color(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_photo_whitebalance()
    puts "test_photo_whitebalance()"
    # @camera.set_mode("PHOTO")
    # @camera.set_video_sub_mode("SINGLE")
    @camera.photo_white_balance_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo whitebalance #{mode_name}")
      result = @camera.set_photo_white_balance(mode_name)
      result ? pass() : fail()
    end
  end

  # 4dec15
  def test_photo_exp()
    puts "test_photo_exp()"
    # @camera.set_mode("MULTI_SHOT")
    # @camera.set_video_sub_mode("SINGLE")
    @camera.photo_exp_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo exp #{mode_name}")
      result = @camera.set_photo_exp(mode_name)
      result ? pass() : fail()
    end
  end

  # 4dec15
  def test_photo_spotmeter()
    puts "test_photo_spotmeter()"
    # @camera.set_mode("MULTI_SHOT")
    # @camera.set_video_sub_mode("SINGLE")
    @camera.photo_spotmeter_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo spotmeter #{mode_name}")
      result = @camera.set_photo_spot_metering(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_photo_res()
    puts "test_photo_res()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_video_sub_mode("SINGLE")
    @camera.photo_res_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("photo resolution #{mode_name}")
      result = @camera.set_photo_res(mode_name)
      result ? pass() : fail()
    end
  end

  ###########  MULTI-SHOT TESTS #############
  # 7dec15
  def test_multi_protune_reset()
    puts "test_multi_protune_reset()"
    set_tc_name("Multi-Shot protune RESET")



    # Set to NON-defaults
    # @camera.set_multi_spot_metering("ON") # NOT affected by RESET
    # @camera.set_multi_protune("ON") # NOT affected by RESET
    @camera.set_multi_exp(30)  # NOT affected by RESET?
    @camera.set_multi_color("flat")
    @camera.set_multi_sharpness("MED")
    @camera.set_multi_iso(400)
    color     = @camera.get_multi_color()
    sharpness = @camera.get_multi_sharpness()
    iso       = @camera.get_multi_iso()
    log_info("test_multi_protune_reset(): PRE-RESET color=#{color} sharpness=#{sharpness} iso=#{iso}")


    ## RESET
    result = @camera.set_multi_protune_reset()
    fail() if not result  # fail if command itself failed


    # DEFAULTs (after RESET) are:
    #
    #  color            : gopro_color
    #  sharpness        : HIGH
    #  iso              : 800
    #
    # IGNORE  multi protune    : ON
    # IGNORE  multi spot-meter : ON
    # IGNORE  exp              : 10
    #
    # x = @camera.get_multi_spot_metering(); puts "multi spot-meter=#{spotval}" # NOT AFFECTED by RESET
    # x = @camera.get_multi_protune(); puts "protune=#{x}" # NOT AFFECTED by RESET
    # x = @camera.get_multi_exp(); puts "exp=#{x}"
    def_color     = @camera.get_multi_color()    ; puts "DEFAULT color=#{def_color}"
    def_sharpness = @camera.get_multi_sharpness(); puts "DEFAULT sharpness=#{def_sharpness}"
    def_iso       = @camera.get_multi_iso()      ; puts "DEFAULT iso=#{def_iso}"
    log_info("test_multi_protune_reset(): POST-RESET color=#{def_color} sharpness=#{def_sharpness} iso=#{def_iso} (DEFAULTS)")

    result = (def_color != color) && (def_sharpness != sharpness) && (def_iso != iso) 

    result ? pass() : fail()
  end

  # 7dec15
  def test_multi_sharpness()
    puts "test_multi_sharpness()"
    @camera.multi_sharpness_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi sharpness #{mode_name}")
      result = @camera.set_multi_sharpness(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_iso()
    puts "test_multi_iso()"
    @camera.multi_iso_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi iso #{mode_name}")
      result = @camera.set_multi_iso(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_ev()
    puts "test_multi_ev()"
    # @camera.set_mode("MULTI_SHOT")
    # @camera.set_multi_sub_mode("TIME_LAPSE")
    @camera.multi_protune_exposure_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi protune exposure #{mode_name}")
      result = @camera.set_multi_protune_exposure(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_get_shot_countdown()
    puts "test_multi_get_shot_countdown()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_multi_sub_mode("NIGHT_LAPSE")
    log_info("Setting NIGHT-LAPSE interval to 60 minutes")
    @camera.set_multi_nightlapse_interval("60min")
    set_tc_name("multi get_shot_countdown")


    log_info("STARTING NIGHT-LAPSE CAPTURE")
    result = @camera.start_multi_capture()
    countdown1 = @camera.get_multi_shot_countdown()
    log_info("All Multi-Shot Night/Time-Lapse Countdown#1==#{countdown1}")
    delay = 5.0
    log_info("sleeping #{delay} seconds...")
    sleep(delay)
    countdown2 = @camera.get_multi_shot_countdown()
    log_info("All Multi-Shot Night/Time-Lapse Countdown#2==#{countdown2}")

    log_info("STOPPING NIGHT-LAPSE CAPTURE")
    result = @camera.stop_multi_capture()

    log_info("Checking the count occurred proper over #{delay} second period...")
    # NOTE: this does handle wraparound conditions (count reached 0 and started at max again)
    # Assumption: we do this test fast enough before wrap occurs
    countdiff =  countdown1.to_i - countdown2.to_i
    if (countdiff >= delay)
      result = true
      log_info("countdown diff=#{countdiff}")
    else
      result = fail
      log_info("TEST FAILED because shot countdown diff=#{countdiff} was less preset delay=#{delay}. Should be greater than or equal")
    end
    result ? pass() : fail()
  end

  # 7dec15
  def test_multi_get_all_settings()
    puts "test_multi_get_all_settings()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_multi_sub_mode("TIME_LAPSE")
    set_tc_name("multi get_all_settings")

    puts "#TODO: "
    puts "# 1. get all multi settings, and save"
    puts "# 2. Change each multi setting"
    puts "# 3. get all multi settings, and compare"
    @all_multi_settings = @camera.get_multi_all_settings()

    log_info("All Multi-Shot Settings==#{@all_multi_settings}")
    log_info("Pre-defined order:  dm,cm,res,cont_rate,tlrate,nlrate,spot,exp_time,pt,color,sharp,iso,evcomp,wb,iso_min")
    result = (@all_multi_settings!=nil)
    result ? pass() : fail()
  end

  # 7dec15
  def test_multi_color()
    puts "test_multi_color()"
    # @camera.set_video_sub_mode("SINGLE")
    @camera.multi_color_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi color #{mode_name}")
      result = @camera.set_multi_color(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_whitebalance()
    puts "test_multi_whitebalance()"
    # @camera.set_mode("MULTI_SHOT")
    # @camera.set_video_sub_mode("BURST")
    @camera.multi_white_balance_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi whitebalance #{mode_name}")
      result = @camera.set_multi_white_balance(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_exp()  # Exposure Times
    puts "test_multi_exp()"
    @camera.multi_exp_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi exp #{mode_name}")
      result = @camera.set_multi_exp(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_spotmeter()
    puts "test_multi_spotmeter()"
    # @camera.set_mode("MULTI_SHOT")
    # @camera.set_video_sub_mode("SINGLE")
    @camera.multi_spotmeter_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi spotmeter #{mode_name}")
      result = @camera.set_multi_spot_metering(mode_name)
      result ? pass() : fail()
    end
  end


  # 7dec15
  def test_multi_res()
    puts "test_multi_res()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_multi_sub_mode("TIME_LAPSE")
    @camera.multi_res_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi resolution #{mode_name}")
      result = @camera.set_multi_res(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_multi_burst_rates()
    puts "test_multi_burst_rates()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_video_sub_mode("BURST")
    @camera.multi_burst_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi burst rate #{mode_name}")
      result = @camera.set_burst(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_multi_timelapse_interval()
    puts "test_multi_timelapse_interval()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_multi_sub_mode("TIME_LAPSE")
    #@camera.set_video_sub_mode("TIME_LAPSE")
    @camera.multi_timelapse_interval_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi-shot timelapse interval #{mode_name}")
      result = @camera.set_multi_timelapse_interval(mode_name)
      result ? pass() : fail()
    end
  end

  # 7dec15
  def test_multi_nightlapse_interval()
    puts "test_multi_nightlapse_interval()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_multi_sub_mode("NIGHT_LAPSE")
    @camera.set_multi_exp("AUTO")
    @camera.multi_nightlapse_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi-shot nightlapse interval #{mode_name}")
      result = @camera.set_multi_nightlapse_interval(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_multi_protune_exposure()
    puts "test_multi_protune_exposure()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_video_sub_mode("TIME_LAPSE")
    @camera.multi_protune_exposure_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi protune exposure #{mode_name}")
      result = @camera.set_multi_protune_exposure(mode_name)
      result ? pass() : fail()
    end
  end

  # Tested
  def test_multi_protune_onoff()
    puts "test_multi_protune_onoff()"
    @camera.set_mode("MULTI_SHOT")
    @camera.set_video_sub_mode("TIME_LAPSE")
    @camera.multi_protune_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("multi protune command #{mode_name}")
      result = @camera.set_multi_protune(mode_name)
      result ? pass() : fail()
    end
  end


  ###########  VIDEO TESTS #############
  def test_video_lowlight()
    puts "test_video_lowlight()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_lowlight_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("video low-light #{mode_name}")
      result = @camera.set_video_low_light(mode_name)
      result ? pass() : fail()
    end
  end

  # 1dec15
  def test_video_piv_interval()
    puts "test_video_piv_interval()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("PIV")
    @camera.video_piv_interval_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("set_video_piv_interval #{mode_name}")
      result = @camera.set_video_piv_interval(mode_name)
      result ? pass() : fail()
    end
  end

  # 1dec15
  def test_video_timelapse_interval()
    puts "test_video_timelapse_interval()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("TIME_LAPSE")
    @camera.video_timelapse_interval_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("set_video_timelapse_interval #{mode_name}")
      result = @camera.set_video_timelapse_interval(mode_name)
      result ? pass() : fail()
    end
  end

  def test_video_looping()
    puts "test_video_looping()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("LOOPING")
    @camera.video_looping_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("set_video_looping #{mode_name}")
      result = @camera.set_video_looping(mode_name)
      result ? pass() : fail()
    end
  end

  def test_video_protune()
    puts "test_video_protune()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_protune_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("set_video_protune #{mode_name}")
      result = @camera.set_video_protune(mode_name)
      result ? pass() : fail()
    end
  end

  # implemented 1dec15
  # tested: 
  def test_video_protune_iso()
    puts "test_video_iso()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_protune_iso_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("test_video_iso #{mode_name}")
      result = @camera.set_video_protune_iso(mode_name)
      result ? pass() : fail()
    end
  end

  # implemented 1dec15
  # tested: 
  def test_video_protune_sharpness()
    puts "test_video_sharpness()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_protune_sharpness_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("test_video_sharpness #{mode_name}")
      result = @camera.set_video_protune_sharpness(mode_name)
      result ? pass() : fail()
    end
  end

  # implemented 1dec15
  # tested: pass
  def test_video_spotmeter()
    puts "test_video_spotmeter()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_spotmeter_cmds[:settings].each do |mode_name,mode_val|
      set_tc_name("test_video_spotmeter #{mode_name}")
      result = @camera.set_video_spot_metering(mode_name)
      result ? pass() : fail()
    end
  end

  # implemented 1dec15
  # tested: PASS
  def test_video_protune_whitebalance()
    puts "test_video_protune_whitebalance()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_protune_whitebalance_cmds[:settings].each do |wb_name,wb_val|
      set_tc_name("set_video_protune_whitebalance #{wb_name}")
      result = @camera.set_video_protune_whitebalance(wb_name)
      result ? pass() : fail()
    end
  end

  # implemented 1dec15
  # tested: 
  def test_video_protune_color()
    puts "test_video_protune_color()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_protune_color_cmds[:settings].each do |color_name,color_val|
      set_tc_name("set_video_protune_color #{color_name}")
      result = @camera.set_video_protune_color(color_name)
      result ? pass() : fail()
    end
  end

  def test_video_protune_exposure()
    puts "test_video_protune_exposure()"
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")
    @camera.video_protune_exposure_cmds[:settings].each do |exposure_name,exposure_val|
      set_tc_name("set_video_protune_exposure #{exposure_name}")
      result = @camera.set_video_protune_exposure(exposure_name)
      result ? pass() : fail()
    end
  end

  def test_video_settings(video_format)

    # USER-OPTION 
    # testcase.rb video capture options:
    #   options[:video_resolution]    = nil
    #   options[:video_fps]           = nil
    #   options[:video_fov]           = nil
    #   options[:video_spot_metering] = nil

    # Respect user options
    return if video_format == "NTSC" and @options[:pal_only]
    return if video_format == "PAL"  and @options[:ntsc_only]

    verified, msg = @camera.set_video_format(video_format)
    # NOTE: just print the error message if the format is not set here
    # because we set video format for every res/fps/fov combination in set_video()
    puts msg if not verified  

    # Note: Setting the mode and submode is not necessary for the commands to work
    #       This is done to help facilitate a visual verification on the camera's multek screen
    @camera.set_mode("VIDEO")
    @camera.set_video_sub_mode("VIDEO")

    puts "\nTESTING THE FOLLOWING supported_video_settings for camera #{@camera.name}:"
    @camera.supported_video_settings.each do |res_hash|

      res_name=res_hash[0]
      res_sets=res_hash[1]

      # PRINT a list of settings that we're testing for this camera
      res_sets.each do |rset|
        next if not rset.include? @camera.name  # Test for only this camera ie="PIPE", "BACKDOOR"
        next if not rset.include? video_format  
        puts "\t#{rset}"
      end
    end

    @camera.supported_video_settings.each do |res_hash|
      test_res=res_hash[0]

      # Check the --video_resolution option. If set, we will test that and only that resolution
      next if @options[:video_resolution] != nil and @options[:video_resolution] != test_res

      res_sets=res_hash[1]
      #puts "test_res=#{test_res}"

      supported_fps = @camera.supported_fps_hawaii[video_format]
      # TEST EACH SETTING
      res_sets.each do |rset|
        next if not rset.include? @camera.name  # Test for only this camera ie="PIPE", "BACKDOOR"
        next if not rset.include? video_format  
        test_settings = video_format + ", " + test_res
        test_fps = supported_fps & rset
        puts "ERROR, fps=#{supported_fps} is NOT SUPPORTED in #{rset}" if test_fps == nil
        next if test_fps == nil
        test_fps = test_fps[0]

      # Check the --video_fps option. If set, we will test that and only that fps
        next if @options[:video_fps] != nil and @options[:video_fps] != test_fps

        test_settings +=  ", " + test_fps
        puts "\nSupported Test Setting: #{rset}"
        @camera.vid_fov_cmds[:settings].each do |fov|
          test_fov = fov & rset
          #next if test_fov == nil
          test_fov = test_fov[0]
          next if test_fov == nil
          #puts "ERROR, fov=#{fov} is NOT SUPPORTED in #{rset}" if test_fov == nil

          # Check the --video_fov option. If set, we will test that and only that fov
          # :video_fov is W|M|N,  test_fov is WIDE|MEDIUM|NARROW
          # So, just compare to the first character in test_fov[] string
          next if @options[:video_fov] != nil and @options[:video_fov] != test_fov[0]  

          final_test_settings =  test_settings + ", " + test_fov
          set_tc_name(final_test_settings)

          #Example: @camera.set_video("NTSC", "1080", "30", "WIDE")
          result, msg = @camera.set_video(video_format, test_res, test_fps, test_fov)

          if not result
            log_error(msg)
            fail()
          else
            pass()
          end
        end
      end
    end
    puts ""

  end # test_video_settings

  def test_setup_settings
    cmds = @camera.get_cmds()
    cmds.shuffle! if @options[:shuffle]
    cmds.each { |i|
      test_gccb_cmd_all_keys(i)
      sleep 1
    }
  end

  def test_mode_switching(m)

    set_tc_name("setup_mode_#{m}")
    ## NOTE: there is no busy bit for GCCB but shal we use WIFI? #@camera.wait_until_not_busy

    # path = @camera.capture_mode_mapping_api2[m]

    # Check that "mode" actual exists in our API
    #mode_value = @camera.get_level_1_index(path)
    #(log_fail("Failed to switch to capture mode #{m} because #{path} path isn't found in settings.json");return) if mode_value == nil


    # Get the values for mode and submode out of the API
    #when 'video'
      #submode_id, submode_value = @camera.get_id_value(:video_submode, m)
      #(log_fail("Failed to switch to capture mode #{m} because of unknown modes #{path}");return)

    #set mode
    #resp = @camera.send_mode_submode_api2(mode_value, submode_value)
    #sleep(3.0) # why SLEEEP?

    #get *actual* modes from camera
    #actual_submode = @camera.get_status_api2(:submode)
    #actual_mode = @camera.get_status_api2(:mode)


    #compare and log submode check results
    (log_fail("Failed to switch to capture mode #{m} because submode is incorrect. Expected: #{submode_value}. Actual: #{actual_submode}");return) if \
    actual_submode.to_s.upcase != submode_value.to_s.upcase

    #compare and log mode check results
    (log_fail("Failed to switch to capture mode #{m} because mode is incorrect. Expected: #{mode_value}. Actual: #{actual_submode}");return) if \
    actual_mode.to_s.upcase != mode_value.to_s.upcase

    #if we get this far we PASS
    log_pass("Change capture mode to #{m} successfully")

  end # test_mode_switching

  def test_multi_photo_shutter_exposure
    if not @camera.get_multi_shutter_exposure_intervals().empty?
      #NOTE - prev_sh in gpControl value (not camera's shutter interval)
      prev_sh = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)

      if @camera.multi_photo_protune_support? == true
        @camera.set_multi_photo_protune("ON")
        @camera.get_multi_photo_nightlapse_rates().each { |pes|
          @camera.get_multi_shutter_exposure_intervals().each { |sh|           
            if pes == "CONTINUOUS" or sh == "AUTO" or pes.to_i > sh.to_i
              set_tc_name("nightlapse_#{pes}_shutter_#{sh}")
              # First set shutter to AUTO to ensure we can reach nightlapse interval
              @camera.set_multi_photo_shutter_exposure("AUTO")
              # Then set the nightlapse interval
              ret, msg = @camera.set_multi_photo_nightlapse(pes)
              (ret == false) ? (fail(msg); next) : pass(msg)
              # Finally set the shutter to the actual value
              ret, msg = @camera.set_multi_photo_shutter_exposure(sh)
              (ret == false) ? (fail(msg); next) : pass(msg)
            else
              next
              act_value = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)
              assert_equal(prev_sh, act_value) == nil ? pass : fail
            end

            prev_sh = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)
          }
        }
      end # end camera.multi_photo_protune_support?
    end # end get_multi_shutter_exposure_intervals()
  end

  def test_locate
    #Turn ON
    set_tc_name("locate_ON")
    resp = @camera.send_locate_camera_api2(1)
    http_result = @camera.http_resp_ok(resp)
    ret = @camera.get_status_api2(:locate)
    result = assert_equal(1, ret.to_i, "Locate ON")
    if result != nil and http_result != true
      fail()
    else
      pass()
    end

    #Turn OFF
    set_tc_name("locate_OFF")
    resp = @camera.send_locate_camera_api2(0)
    http_result = @camera.http_resp_ok(resp)
    ret = @camera.get_status_api2(:locate)
    result = assert_equal(0, ret.to_i, "Locate OFF")
    if result != nil and http_result != true
      fail()
    else
      pass()
    end
  end

  def test_date_time
    set_tc_name("set_date_time")
    retries = 2
    resp = false
    failed_arr = []

    for i in 1..retries
      t = Time.now.strftime("%Y-%m-%d-%H-%M-%S")
      year, month, day, hour, min, sec = t.split('-')
      year = year.to_i - 2000

      exp_year =  @camera.gccb_itohs(year.to_i).upcase
      exp_month = @camera.gccb_itohs(month.to_i).upcase
      exp_day = @camera.gccb_itohs(day.to_i).upcase
      exp_hour = @camera.gccb_itohs(hour.to_i).upcase
      exp_min = @camera.gccb_itohs(min.to_i).upcase
      exp_sec = @camera.gccb_itohs(sec.to_i).upcase

      date_time_str = exp_year
      date_time_str += exp_month
      date_time_str += exp_day
      date_time_str += exp_hour
      date_time_str += exp_min
      date_time_str += exp_sec

      resp = @camera.send_date_time_api2(date_time_str)

      if resp != false
        act_date_time = @camera.get_status_api2(:date_time)
        act_year = act_date_time[0..2]
        act_month = act_date_time[3..5]
        act_day = act_date_time[6..8]
        act_hour = act_date_time[9..11]
        act_min = act_date_time[12..14]
        act_sec = act_date_time[15..17]

        failed_arr << assert_delta(exp_year, act_year, 1, "Year")
        failed_arr << assert_delta(exp_month, act_month, 1, "Month")
        failed_arr << assert_delta(exp_day, act_day, 1, "Day")
        failed_arr << assert_delta(exp_hour, act_hour, 1,  "Hour")
        failed_arr << assert_delta(exp_min, act_min, 1, "Min")
        failed_arr << assert_delta(exp_sec, act_sec, 5, "Sec")
        break
      end
    end
    resp == false ? fail("Set date and time command returns unsuccessful http code") : ( pass if !has_failure?(failed_arr))
  end

  def test_protune_defaults
    failed_arr = []

    # Video
    if @camera.video_protune_support? == true
      set_tc_name("video_protune_reset")
      @camera.send_video_protune_reset

      ret = @camera.get_status(:video_protune_default)
      failed_arr << assert_equal(1, ret, "Video protune default isn't 1 after reset in /status")

      @camera.get_video_protune_vars().each(){|k, v|
        # Only check ProTune settings valid for this camera
        # E.g. Rockypoint doesn't have WB, Color, or Exposure
        next if v == false
        id, exp = @camera.get_id_value(k, @camera.defaults()[k])
        act = @camera.get_setting_status_api2_by_name(k)
        failed_arr << assert_equal(exp, act, "#{k} value isn't as expected.")
      }
      pass if !has_failure?(failed_arr)
      failed_arr.clear
    end

    # Photo
    if @camera.photo_protune_support? == true
      @camera.get_photo_shutter_exposure_intervals.each(){ |sh|
        set_tc_name("photo_protune_reset_shutter_#{sh}")
        @camera.set_photo_shutter_exposure(sh)
        @camera.send_photo_protune_reset

        ret = @camera.get_status(:photo_protune_default)
        failed_arr << assert_equal(1, ret, "Photo protune default isn't 1 after reset in /status")

        @camera.get_photo_protune_vars().each(){|k, v|
          #TODO - remove IF statement (use else) when white balance has same default for all shutter intervals
          if k == :photo_pt_wb
            sh_cur_value = @camera.get_setting_status_api2_by_name(:photo_shutter_ev)
            wb_cur_value = @camera.get_setting_status_api2_by_name(:photo_pt_wb)

            sh_auto_id, sh_auto_value = @camera.get_id_value(:photo_shutter_ev, "AUTO")
            wb_auto_id, wb_auto_value = @camera.get_id_value(:photo_pt_wb, "AUTO")
            wb_5500K_id, wb_5500K_value = @camera.get_id_value(:photo_pt_wb, "5500K")

            if sh_cur_value == sh_auto_value and wb_cur_value != wb_auto_value
              failed_arr << "Photo protune white balance default isn't AUTO when shutter exposure is AUTO. Expected: #{wb_auto_value}. Actual: #{wb_cur_value}"
            end

            if sh_cur_value != sh_auto_value and wb_cur_value != wb_5500K_value
              failed_arr << "Photo protune white balance default isn't 5500K when shutter exposure isn't AUTO. Expected: #{wb_5500K_value}. Actual: #{wb_cur_value}"
            end

          else
            act = @camera.get_setting_status_api2_by_name(k)
            id, exp = @camera.get_id_value(k, @camera.defaults()[k])
            failed_arr << assert_equal(exp, act, "#{k} value isn't as expected.")
          end
        }
        pass if !has_failure?(failed_arr)
        failed_arr.clear
      }
    end

    # Multi_photo.
    if @camera.multi_photo_protune_support? == true
      @camera.get_multi_shutter_exposure_intervals().each{|sh|
        set_tc_name("multi_photo_protune_reset_shutter_#{sh}")
        @camera.set_multi_photo_shutter_exposure(sh)
        @camera.send_multi_photo_protune_reset

        ret = @camera.get_status(:multi_photo_protune_default)
        failed_arr << assert_equal(1, ret, "Multi-Photo protune default isn't 1 after reset in /status")

        #TODO - SAVE!!! uncomment IF statement (use else) when white balance has same default for all shutter intervals
        @camera.get_multi_photo_protune_vars().each(){|k, v|
          if k == :multi_photo_pt_wb
            sh_cur_value = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)
            wb_cur_value = @camera.get_setting_status_api2_by_name(:multi_photo_pt_wb)

            sh_auto_id, sh_auto_value = @camera.get_id_value(:multi_photo_shutter_ev, "AUTO")
            wb_auto_id, wb_auto_value = @camera.get_id_value(:multi_photo_pt_wb, "AUTO")
            wb_5500K_id, wb_5500K_value = @camera.get_id_value(:multi_photo_pt_wb, "5500K")

            if sh_cur_value == sh_auto_value and wb_cur_value != wb_auto_value
              failed_arr << "Multi-photo protune white balance default isn't AUTO when shutter exposure is AUTO. Expected: #{wb_auto_value}. Actual: #{wb_cur_value}"
            end

            if sh_cur_value != sh_auto_value and wb_cur_value != wb_5500K_value
              failed_arr << "Multi-photo protune white balance default isn't 5500K when shutter exposure isn't AUTO. Expected: #{wb_5500K_value}. Actual: #{wb_cur_value}"
            end

          else
            act = @camera.get_setting_status_api2_by_name(k)
            id, exp = @camera.get_id_value(k, @camera.defaults()[k])
            failed_arr << assert_equal(exp, act, "#{k} value isn't as expected.")
          end
        }

        pass if !has_failure?(failed_arr)
        failed_arr.clear
      }
    end
  end

  def test_all_photo_modes(protune)

    #test photo_protune
    if protune == "ON"
      set_tc_name("photo_protune_#{protune}")
      test_set_and_get(:photo_pt, nil, "ON", "ON", true)

      #photo protune variables
      pt_vars = @camera.get_photo_protune_vars

      pt_vars.keys.each { |v|
        if pt_vars[v]
          test_gccb_cmd_all_keys(v)
        end
      }
    end

    if protune == "OFF"
      if @camera.photo_protune_support?()
        set_tc_name("photo_protune_#{protune}")
        test_set_and_get(:photo_pt, nil, "OFF", "OFF", true)
      end

      #test photo resolution
      res = @camera.get_photo_resolutions
      res.each {|r|
        set_tc_name("photo_resolution_#{r}_protune_#{protune}")
        test_set_and_get(:photo_resolution, @camera.photo_resolution, r, r, true)
      }

      #test photo continuous rate
      test_gccb_cmd_all_keys(:photo_continuous) if @camera.photo_continuous_support?()
    end

  end

  def test_all_multi_photo_modes(protune)
    #test multi photo_protune
    if protune == "ON"
      set_tc_name("multi_photo_protune_#{protune}")
      test_set_and_get(:multi_photo_pt, nil, "ON", "ON", true)

      #multi photo protune variables
      pt_vars = @camera.get_multi_photo_protune_vars

      pt_vars.keys.each { |v|
        if pt_vars[v]
          test_gccb_cmd_all_keys(v)
        end
      }
    end

    if protune == "OFF"
      if @camera.photo_protune_support?()
        set_tc_name("multi_photo_protune_#{protune}")
        test_set_and_get(:multi_photo_pt, nil, "OFF", "OFF", true)
      end

      #test multi photo resolution
      res = @camera.get_photo_resolutions
      res.each {|r|
        set_tc_name("multi_photo_resolution_#{r}_protune_#{protune}")
        test_set_and_get(:multi_photo_resolution, @camera.multi_photo_resolution, r, r, true)
      }

      #multi-photo burst
      @camera.get_multi_photo_burst_rates().each { |bu|
        set_tc_name("multi_photo_burst_#{bu}_protune_#{protune}")
        test_set_and_get(:multi_photo_burst, @camera.multi_photo_burst, bu, bu, true)
      }
      # test_gccb_cmd_all_keys(:multi_photo_burst)

      #multi_photo timelapse
      @camera.get_multi_photo_timelapse_rates().each { |ti|
        set_tc_name("multi_photo_timelapse_#{ti}_protune_#{protune}")
        test_set_and_get(:multi_photo_timelapse, @camera.multi_photo_timelapse, ti, ti, true)
      }
      # test_gccb_cmd_all_keys(:multi_photo_timelapse)

      #multi_photo nightlapse - test in test_multi_photo_shutter_exposure
      #test_gccb_cmd_all_keys(:multi_photo_nightlapse) if @camera.multi_photo_nightlapse_support?()
    end

  end

  # NOT USED in GCCB testing
  def test_all_res_fps_fov(protune="OFF")

    res_set = []
    fps_set = []
    fov_set = []

    #tracker to run command only once
    protune_vars_tested = false
    preview_vars_tested = false
    looping_vars_tested = false
    piv_vars_tested = false
    low_light_vars_tested = false

    if @camera.video_protune_support? == true
      if protune == "ON"
        @camera.set_video_protune("ON")
      else
        @camera.set_video_protune("OFF")
      end
    end

    ["NTSC", "PAL"].each do |video_mode|
      next if video_mode == "NTSC" and @options[:pal_only]
      next if video_mode == "PAL"  and @options[:ntsc_only]

      @camera.set_video_format(video_mode)
      sleep(2.0)
      @camera.set_capture_mode("VIDEO")
      sleep(2.0)

      # RES
      r = @camera.get_video_resolution()
      r.shuffle! if @options[:shuffle] == true
      r.each do |res|
        next if @options[:video_resolution] != nil and @options[:video_resolution] != res
        next if protune == "ON" && @camera.video_protune_support?(res) == false

        if res_set.include?(res) == false
          set_tc_name("video_resolution_#{res}_protune_#{protune}")
          test_set_and_get(:video_resolution, @camera.video_resolution, res, res, true)
          res_set.push(res)
        end

        # FPS
        fs = @camera.get_video_fps(res)
        fs.shuffle! if @options[:shuffle] == true
        fs.each do |fps|
          next if @options[:video_fps] != nil and @options[:video_fps] != fps
          next if !@camera.mode_supported?(video_mode, res, fps)

          # Turns out there are some RES that support Protune, but FPS that do not
          next if protune == "ON" and !@camera.video_protune_support?(res, fps)

          if fps_set.include?(fps) == false
            ret, msg = @camera.set_video_resolution(res)
            sleep(2.0)
            log_info(msg)

            # set_tc_name("#{video_mode}_protune_#{protune}_#{res}_#{fps}")
            set_tc_name("video_fps_#{fps}_protune_#{protune}")
            test_set_and_get(:video_fps, @camera.video_fps, key=fps, expected=fps, true)
            fps_set.push(fps)
          end

          if protune == "ON"
            if  @camera.video_protune_support?(res) == true && protune_vars_tested == false
              pt_vars = @camera.get_video_protune_vars()
              pt_vars.keys.each { |v|
                if pt_vars[v]
                  test_gccb_cmd_all_keys(v)
                end
              }
              protune_vars_tested = true
            end
          else # ProTune == "OFF"
            #Looping
            if @camera.video_looping_support?(res, fps) && looping_vars_tested == false
              sleep 1
              full_cmd_hash = tu_get_cmd_hash(:video_looping)
              cmd_hash = @camera.get_set_params(full_cmd_hash)
              cmd_hash.shuffle! if @options[:shuffle] == true

              cmd_hash.each { |key, value|
                set_tc_name("looping_#{key}")
                ret, msg = @camera.set_video_looping(key)

                if ret == true
                  if @camera.get_mins_avail > tu_get_looping_min_reqd(@camera, key)
                    pass("Looping correctly set to #{key}")
                  else
                    fail("Looping incorrectly set to #{key}")
                  end
                else
                  if @camera.get_mins_avail < tu_get_looping_min_reqd(@camera, key)
                    pass("Looping correctly NOT set to #{key}")
                  else
                    fail("Looping incorrectly NOT set to #{key}")
                  end
                end
              }
              looping_vars_tested = true
            end
          end

          # Low-light settings
          if @camera.video_low_light_support?(res, fps) && low_light_vars_tested == false
            set_tc_name("low_light_protune_#{protune}")
            test_gccb_cmd_all_keys(:video_low_light)

            low_light_vars_tested = true
          end

          # FOV
          fv = @camera.get_video_fov(res, fps, protune)
          fv.shuffle! if @options[:shuffle] == true
          fv.each do |fov|
            if fov_set.include?(fov) == false
              set_tc_name("video_fov_#{fov}_protune_#{protune}")
              test_set_and_get(:video_fov, @camera.video_fov, key=fov, expected=fov, true)
              fov_set.push(fov)
            end

            if protune == "OFF"
              #PIV
              if @camera.video_piv_support?(res,fps,fov) && piv_vars_tested == false
                full_cmd_hash = tu_get_cmd_hash(:video_piv)
                cmd_hash = @camera.get_set_params(full_cmd_hash)
                cmd_hash.shuffle! if @options[:shuffle] == true

                cmd_hash.each {|key, value|
                  set_tc_name("video_piv_#{key}")
                  test_set_and_get(:video_piv, @camera.video_piv, key, key, true)
                }
                piv_vars_tested = true
              end
            end
          end # fov
        end # FPS
      end # res
    end # video_mode (ntsc/pal)
  end # test_all_res_fps_fov

  def test_cc_params
    @camera.camera_capabilities().each { |cc|
      set_tc_name("camera_capabilities_#{cc}")
      act = (@camera.get_cc_status(cc) == 1)  # Map to T/F. 0 - false, 1 - true
      exp = @camera.get_capabilities[cc]
      if exp != act
        fail("Camera (cc) expect #{cc}=#{exp}, but receive #{cc}=#{act} from camera")
      else
        pass("Camera (cc) correctly advertises #{cc} support=#{exp}")
      end
    }
  end

  def get_takes_params?(sym)
    # The following commands use parameters in their GET command.
    get_takes_params = {
      :lcd_display => true
    }
    get_takes_params.default = false
    return get_takes_params[sym]
  end

  # Most commands only use parameters with the SET command,
  # but a few (like lc) use them with the GET command.  In that case
  # call with getwithparams=true
  def test_gccb_cmd_all_keys(i)

    gccb_hash = @camera.setting[i]
    @camera.method(gccb_hash['method']).call().keys.each{ |k|
      log_info("Testing #{i} setting to #{k}")
      set_tc_name("#{i}_#{k}")
      test_set_and_get(i, nil, k, nil, nil)
      sleep 1
    }

    log_info("All command keys passed") if !has_failure?(failed_arr)

  end

  def test_set_and_get(gccb_name, gccb_hash, key, expected, ret)
    # if gccb_name == :setup_video_format and @camera.name == "SILVER_PLUS"
    #   log_skip("ULU-116 Workaround")
    #   return
    # end
    
    #resp = @camera.set_api2(gccb_name, key)
    fail_str = nil
    if resp == nil
      fail_str = "Nil response for cmd=#{gccb_name}, key=#{key}"
    elsif resp[:success] != true
      fail_str = "Unable to set %s to %s. Expected %s. Detected %s." \
      %[gccb_name, key, resp[:expected], resp[:detected]]
    end
    failed_arr << fail_str if fail_str != nil

    log_pass("#{gccb_name} #{key} passed") if !has_failure?(failed_arr)

  end

  def cleanup
    @host.kill_status_process() if @host
  end

end # end runtest

def init_serial_logging(dev, log_path, t)
  include LogUtils

  # Capture console logs to log_path
  if dev != nil
    log_path = "/tmp/test.log" if log_path == nil
    # @linux_iface: Just assume it is dev + 1
    n1 = dev[-5..-1].scan(/\d/)[0]
    n2 = n1.to_i + 1
    @linux_iface = dev[0...dev.index(n1)] + n2.to_s
    t.log_warn("Linux serial port not specified.  Trying #{@linux_iface}")

    # Fatally exit if these fail
    # if init_amba_serial_log(File.dirname(log_path), dev.split("/")[2].join(".log")) == false
    logname = dev.split("/")[2]
    logname += ".log"
    if init_amba_serial_log(File.dirname(log_path), logname) == false
      exit ExitCode.to_s(ExitCode::ERROR)
    elsif spawn_amba_logging_thread(dev) == false
      exit ExitCode.to_s(ExitCode::ERROR)
    end

    logname = @linux_iface.split("/")[2]
    logname += ".log"
    # Just warn if these fail
    if init_linux_serial_log(File.dirname(log_path), logname) == false
      t.log_error("Error initializing Linux log")
    elsif spawn_linux_logging_thread(@linux_iface) == false
      t.log_error("Error spawning Linux logging thread")
    end
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
#
# GCCB testing options:
#
#  Camera communication and I/O options:
#
#  "--serial DEVICE", "The serial device (e.g. /dev/ttyUSB0)"
#  "--gccb DEVICE", "The gccb device (e.g. /dev/ttyACM0")
#  "--logfile FILE", "Sets the log file location (default $HOME)"
#
#  Video capture options:
#
#  "--res RESOLUTION", "Only test a specific video resolution"
#  "--fps FPS", "Only test a specific video fps"
#  "--fov W|M|N", "Only test a specific video fov"
#
#  Test run options:
#
#  "--ntsc_only", "Only do NTSC frame-rates (default False)"  
#  "--pal_only", "Only do PAL frame-rates (default False)"  
#  "--quick", "Run a quick version of the test 
#  "--verb", "Verbose/debug logging"  
#  "--pause", # Pauses before the sending of each GCCB command
#  "--io_delay VALUE", "delay in seconds between IO operations"  # delays/waits n-seconds before the sending of each GCCB command
#
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :gccbdev, :battoutlet, :usboutlet, :reset_on_failure, 
      :shuffle, :set_defaults, :logfile, :verb, :pal_only, :ntsc_only, :video_resolution, :video_fps, :video_fov,
      :mode_cm, :mode, :timelapse, :video_timelapse, :quick,
      :test_delay, :io_delay, :pause]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    cam = t.my_cam()
    if options[:serialdev] != nil
      t.log_info("serial=#{options[:serialdev]}")
      t.log_info("t.camera.log_path=#{cam.log_path}")
      dev = options[:serialdev]
      init_serial_logging(dev, cam.log_path,t)
    else
      puts "NO SERIAL"
    end
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
