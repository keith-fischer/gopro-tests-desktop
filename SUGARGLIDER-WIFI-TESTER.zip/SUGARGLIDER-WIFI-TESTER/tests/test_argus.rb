#!/usr/bin/env ruby
# test_argus.rb

require 'fileutils'
require 'English'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/serial_commands'

PROTUNE_VIDEO_WHITE_BALANCE_VALUES = ['3000k', '5500k', '6500k', 'native']
PROTUNE_VIDEO_COLOR_VALUES = ['NEUTRAL']
PROTUNE_VIDEO_SHARPNESS_VALUES = ['LOW', 'MED', 'HIGH']
PROTUNE_VIDEO_ISO_VALUES = [6400, 3200, 1600, 800, 400]
PROTUNE_VIDEO_EXPOSURE_VALUES = [-2.0, -1.5, -1.0, -0.5, 0, 0.5, 1.0, 1.5, 2.0]
CHAPTERED_VIDEO_DURATION = 448


class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    @host = Host.new
    log_conf('name, ARGUS')
    log_info('Initialising Master Camera ')
    @master_camera = get_serial_camera(options[:masterdev])
    log_info('Initialising Slave Camera')
    @slave_camera = get_serial_camera(options[:slavedev])
    @master_camera.set_debug('OFF')
    @master_camera.name = 'ARGUS'
    @slave_camera.name = 'ARGUS'
    @slave_camera.set_debug('OFF')
    log_info("Master Camera.name: #{@master_camera.name}")
    log_info("Slave Camera name: #{@slave_camera.name}")
    log_info("Master Camera Firmware Version: #{@master_camera.get_firmware_version.first}")
    log_info("Slave Camera Firmware Version: #{@slave_camera.get_firmware_version.first}")
    if options[:pause]
      @master_camera.pause_enable(true)
      @slave_camera.pause_enable(true)
    end

    if options[:io_delay]
      @master_camera.set_io_delay(@options[:io_delay])
      @slave_camera.set_io_delay(@options[:io_delay])
      log_info("Master Camera IO delay=#{@options[:io_delay]}")
      log_info("Slave Camera IO delay=#{@options[:io_delay]}")
    end

    @master_camera.set_media_dirname('...AR...')
    @slave_camera.set_media_dirname('...AR...')

    check_system_health
  end

  def test_delete_media_on_sd
    set_tc_name('Delete media on SD card')
    delete_media_on_sd
    if validate_num_videos_on_sd?(0)
      log_info('Listing the files on SD')
      media_files = @master_camera.get_medialist
      puts media_files
      log_pass('Found no media on SD')
    else
      log_fail("Failed to delete media on SD card")
    end
  end

  def test_record_videos(n, duration)
    set_tc_name("Record #{n} video(s)," \
                "#{duration > CHAPTERED_VIDEO_DURATION ? ' with chapters,' : '' }" \
                " capture_mode=VIDEO," \
                " capture_length=#{duration}s")

    delete_media_on_sd
    abort unless validate_num_videos_on_sd?(0)

    n.times do
      record_video(duration)
      check_system_health
    end

    if duration > CHAPTERED_VIDEO_DURATION
      log_info("Video(s) will be chaptered since duration is #{duration}")
      n = (n * (duration / CHAPTERED_VIDEO_DURATION.to_f).ceil)
    end

    if validate_num_videos_on_sd?(n)
      log_info('Listing the files on Master Camera SD')
      media_files = @master_camera.get_medialist
      puts media_files
      log_info('Listing the files on Slave Camera SD')
      media_files = @slave_camera.get_medialist
      puts media_files
      log_pass("Found #{n} videos on both Master, Slave SD")
    else
      log_fail("SD does not contain #{n} videos on Master or Slave")
    end
  end

  def test_protune
    @master_camera.set_video_protune('ON')

    PROTUNE_VIDEO_WHITE_BALANCE_VALUES.each do |wbal|
      PROTUNE_VIDEO_SHARPNESS_VALUES.each do |shp|
        PROTUNE_VIDEO_EXPOSURE_VALUES.each do |exp|
          PROTUNE_VIDEO_ISO_VALUES.each do |iso|
            set_tc_name("Video Protune with WB=#{wbal}, Color=NEUTRAL," \
                        " Sharpness=#{shp}, Exposure=#{exp}, ISO=#{iso}")
            result, msg = @master_camera.set_video_protune_color('NEUTRAL')
            log_warn(msg) unless result
            result, msg = @master_camera.set_video_protune_white_balance(wbal)
            log_warn(msg) unless result
            result, msg = @master_camera.set_video_protune_sharpness(shp)
            log_warn(msg) unless result
            result, msg = @master_camera.set_video_protune_exposure(exp)
            log_warn(msg) unless result
            result, msg = @master_camera.set_video_protune_iso(iso)
            log_warn(msg) unless result
            expected_settings = {
              protune_mode: 'on',
              white_balance: @master_camera.white_balance[wbal],
              color: 'flat',
              iso: @master_camera.iso[iso],
              exposure: @master_camera.exposure[exp],
              sharpness: @master_camera.sharpness[shp]
            }
            verify_protune_settings(expected_settings)
          end
        end
      end
    end
  ensure
    @master_camera.set_video_protune('OFF')
  end

  def runtest
    if @options[:stress]
      test_record_videos(1, 1500)
    else
      test_delete_media_on_sd
      test_record_videos(1, 30)
      test_record_videos(1, 200)
      test_record_videos(1, 500)
      test_protune
    end
  end

  def cleanup
    @host.kill_status_process if @host
  end

  private

  def verify_protune_settings(expected_settings)
    protune_settings = {
      protune_mode: [@master_camera.get_video_protune_status,
                     @slave_camera.get_video_protune_status],
      white_balance: [@master_camera.get_video_protune_white_balance,
                      @slave_camera.get_video_protune_white_balance],
      color: [@master_camera.get_video_protune_color,
              @slave_camera.get_video_protune_color],
      iso: [@master_camera.get_video_protune_iso.to_i,
            @slave_camera.get_video_protune_iso.to_i],
      sharpness: [@master_camera.get_video_protune_sharpness,
                  @slave_camera.get_video_protune_sharpness],
      exposure: [@master_camera.get_video_protune_exposure,
                 @slave_camera.get_video_protune_exposure]
    }

    result = true
    settings_str = ''
    protune_settings.each do |key, arr|
      a = (arr.first == arr.last)
      b = (arr.first == expected_settings[key])
      c = (arr.last == expected_settings[key])
      result &= (a && b && c)
      settings_str << "#{key} Master: #{arr.first}, Slave: #{arr.last}, Expected: #{expected_settings[key]}\n"
    end

    if result
      log_pass("Master, Slave settings match.\nSettings #{settings_str}")
    else
      log_fail("Master, Slave settings dont match.\nSettings #{settings_str}")
    end
  end

  def delete_media_on_sd
    log_info('Deleting the contents of the SD card')
    result, msg = @master_camera.storage_delete_all
    log_warn(msg) unless result
  end

  def record_video(duration)
    result, msg = @master_camera.set_video_def_sub_mode('VIDEO')
    log_warn(msg) unless result

    log_info("Starting video capture for #{duration}s")
    result, msg = @master_camera.start_video_capture
    log_warn(msg) unless result

    sleep(duration)
    if @master_camera.recording? && @slave_camera.recording?
      log_info('System is recording video')
    else
      log_error('System is not recording a video')
    end

    log_info('Stopping video capture')
    result, msg = @master_camera.stop_video_capture
    log_warn(msg) unless result
  end

  def check_system_health
    log_info('Checking status of the cameras')
    if @master_camera.ready? && @slave_camera.ready?
      log_info('System is ready')
    else
      log_error('System is unresponsive, shutting down the camera array')
      @master_camera.do_shutdown
      abort
    end

    log_info("Master Camera Temperatures: #{@master_camera.temperatures}")
    log_info("Slave Camera Temperatures: #{@slave_camera.temperatures}")
    if @master_camera.hot? || @slave_camera.hot?
      log_warn('Argus is hot !!')
      log_error('Aborting tests, shutting down the camera array')
      @master_camera.do_shutdown
      abort
    end
  end

  def validate_num_videos_on_sd?(n)
    log_info('Getting the count of video files on Master Camera SD Card')
    result_master, msg = @master_camera.get_video_count
    log_warn(msg) if msg
    log_info('Getting the count of video files on Slave Camera SD Card')
    result_slave, msg = @slave_camera.get_video_count
    log_warn(msg) if msg
    (result_master == n) && (result_master == result_slave) ? true : false
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $PROGRAM_NAME
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :masterdev, :slavedev, :battoutlet,
                   :usboutlet, :reset_on_failure,
                   :shuffle, :set_defaults, :logfile, :verb, :timelapse,
                   :pal_only, :ntsc_only, :mode_cm, :video_timelapse, :mode,
                   :full, :quick, :video_pt, :test_delay,
                   :io_delay, :pause, :stress
                  ]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera
  ensure
    unless t.nil?
      t.cleanup
      t.final_actions
    end
  end
end
