# test_video_looping.rb
# Test all the looping settings

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("test_power_off_on_setup")
    @host = Host.new
    @camera = tu_get_camera()
    
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()
  end

  def toggle_power_off_on_via_wifi(timeout=30)
    return api2_toggle_power_off_on if @camera.remote_api_version() == 2

    # true = power ON, false = power OFF
    curr_state = @camera.get_bacpac_status(:camera_power)
    if curr_state == true
      @camera.set(:power_pw, "OFF", wait_time=5, decode=false,
      expected=nil, tries=2, interval=5, target="bacpac")
    end
    start_time = Time.now()
    @camera.set(:power_pw, "ON", wait_time=3, decode=false,
    expected=nil, tries=2, interval=5, target="bacpac")
    elapsed = 0
    # Wait first for bacpac to detect camera powered
    while true
      elapsed = Time.now() - start_time
      break if @camera.get_bacpac_status(:camera_power) == true
      return false if elapsed > timeout
      sleep 1.0
    end
    # Then wait for camera to report status OK
    while true
      elapsed = Time.now() - start_time
      break if @camera.get_status(:ok) == true
      return false if elapsed > timeout
      sleep 1.0
    end
    elapsed = Time.now() - start_time
    return elapsed
  end

  def api2_toggle_power_off_on()
    @camera.send_camera_sleep_api2
    sleep(5)
    # RP/Hal need an extra 5 seconds.  curl was coming back true
    sleep(5) if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
    return @camera.api2_camera_power_on_ok?
  end

  def toggle_power_off_on_via_serial(timeout=30)
    start_time = Time.now()
    ret, msg = @camera.do_reset(force=false)
    if ret == true
      result = Time.now() - start_time
    else
      log_warn(msg)
      result = false
    end
    return result
  end

  def runtest
    default_iter = 10
    iter = @options[:n_iter].to_i
    if iter == nil
      log_warn("# Iterations not set.  Running with default of #{default_iter}")
      iter = default_iter
    end
    
    set_tc_name("power_cycle_#{iter}_iterations")
    log_info("Running power OFF/ON test for #{iter} iterations")
    (1..iter).each { |n|
      log_info("Iteration #{n}. Powering off and on.")
      if @camera.interfaces.include?(:wifi)
        result = toggle_power_off_on_via_wifi()
      else
        result = toggle_power_off_on_via_serial()
      end
      if result == false
        log_fail("Camera did not toggle power successfully")
        @camera.detect_crash_and_reboot() if @camera.interfaces.include?(:serial)
        exit ExitCode::CAMERA_OFF
      end

      sleep(5.0) # Camera not quite ready even though says OK...
      sleep(10.0) if ["HIMALAYAS"].include?(@camera.name) # Helps Himalayas get thru 1000 iterations

      if @camera.interfaces.include?(:serial) or @camera.remote_api_version() == 1
        if @camera.is_alive?
          log_info("Camera powered on in %0.2f seconds" %result)
        else
          log_fail("Camera not responding after power-on")
          @camera.detect_crash_and_reboot() if @camera.interfaces.include?(:serial)
          exit ExitCode::CAMERA_FREEZE
        end
      end
      sleep(3.0)
    }
    log_pass("All #{iter} power off-on iterations passed")
  end

  def cleanup
    return unless @host and @camera # Bail if we're missing required objects for cleanup.
    log_info("Ensuring camera is ON before exiting test")
    begin
      if not @host.wait_for_wifi_camera(@camera.ip, timeout=5, interval=2)
        if @camera.remote_api_version() == 1
          @camera.set(:power_pw, "ON", wait_time=3, decode=false,
          expected=nil, tries=2, interval=5, target="bacpac")
        elsif @camera.remote_api_version() == 2
          @camera.api2_camera_power_on_ok?
        end
      end
    rescue StandardError => e
      log_warn("Caught exception in cleanup block trying to power on camera")
      log_info(e.to_s)
    end
  end
end # end Test class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  $exitcode = 0
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov,
      :logfile, :verb, :n_iter,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
