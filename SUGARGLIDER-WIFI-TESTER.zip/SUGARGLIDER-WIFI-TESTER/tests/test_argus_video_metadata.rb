#!/usr/bin/env ruby
# test_argus_video_metadata.rb

require 'fileutils'
require 'English'
require 'json'

require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @options[:media_dir] = Dir.getwd unless @options[:media_dir]
    @test_file = __FILE__
    @host = Host.new
    log_conf('name, ARGUS')
    log_info('Checking for the mp4_meta binary ...')

    unless File.exist?('tools/mp4_metadata/mp4_meta')
      log_error('Binary tools/mp4_metadata/mp4_meta does not exist. Please build the binary before running the tests')
      abort
    end
  end

  def runtest
    gusi_by_file = {}
    guri_by_file = {}
    Dir.glob("#{@options[:media_dir]}/*.MP4").each do |file|
      metadata = JSON.load(%x{#{ENV['PWD']}/tools/mp4_metadata/mp4_meta -j #{file}})
      print_camera_info(metadata['MOOV']['UDTA']['FIRM']['Raw'])
      gusi = metadata['MOOV']['UDTA']['GUSI']
      guri = metadata['MOOV']['UDTA']['GURI']
      gusi_by_file[metadata['File Name']] = gusi
      guri_by_file[metadata['File Name']] = guri
    end
    test_gusi_metadata(gusi_by_file)
    test_guri_metadata(guri_by_file)
  end

  def test_gusi_metadata(gusi_by_file)
    size_by_file = {}
    esn_by_file = {}
    snum_by_file = {}
    cnum_by_file = {}
    ts_by_file = {}
    gusi_by_file.each do |file, gusi|
      next unless gusi
      size_by_file[file] = gusi['Atom Size']
      esn_by_file[file] = gusi['Primary Camera ESN']
      snum_by_file[file] = gusi['Primary Camera Shot Number']
      cnum_by_file[file] = gusi['Chapter Number']
      ts_by_file[file] =  gusi['Backpack Timestamp at Capture Start']
    end
    verify_gusi_atom_size(size_by_file)
    verify_gusi_primary_camera_esn(esn_by_file)
    verify_gusi_shot_number(snum_by_file, ts_by_file)
    verify_gusi_chapter_number(cnum_by_file, ts_by_file)
    verify_gusi_backpack_timestamp(snum_by_file, ts_by_file)
  end

  def test_guri_metadata(guri_by_file)
    size_by_file = {}
    esn_by_file = {}
    rig_type_by_file = {}
    rig_size_by_file = {}
    node_id_by_file = {}
    guri_by_file.each do |file, guri|
      next unless guri
      size_by_file[file] = guri['Atom Size']
      esn_by_file[file] = guri['Primary Backpack ESN']
      rig_type_by_file[file] = guri['Rig Type']
      rig_size_by_file[file] = guri['Rig Size']
      node_id_by_file[file] = guri['Node ID']
    end

    verify_guri_atom_size(size_by_file)
    verify_guri_primary_backpack_esn(esn_by_file)
    verify_guri_rig_type(rig_type_by_file)
    verify_guri_rig_size(rig_size_by_file)
    verify_guri_node_id(node_id_by_file)
  end

  def cleanup
    @host.kill_status_process if @host
  end

  private

  def print_camera_info(raw_firm)
    if !@options[:build] && !@options[:release] && !@options[:type]
      raw_firm = raw_firm.split(' ')
      if raw_firm
        raw_firm = raw_firm[8..-1].join()
        firm = [raw_firm].pack('H*')
        @options[:type] = firm.match(/[A-Za-z0-9]{3,3}/)
        temp = firm.scan(/[0-9]{2,2}/)
        @options[:release] =  temp.first
        @options[:build] = temp[1..-1].join('.')
        log_conf("build, #{@options[:build]}")
        log_conf("release, #{@options[:release]}")
        log_conf("type, #{@options[:type]}")
      end
    end
  end

  def verify_gusi_atom_size(size_by_file)
    set_tc_name('GUSI Atom size should be 24 bytes')
    result = size_by_file.keys.all? { |file| size_by_file[file] == 24}
    msg = test_rail_json_format(size_by_file)
    if result
      log_pass("Atom Size is 24 bytes. #{msg}")
    else
      log_fail("Atom Size is not 24 bytes. #{msg}")
    end
  end

  def verify_gusi_primary_camera_esn(esn_by_file)
    set_tc_name('GUSI Primary Camera ESN should be same across all files.')
    result = esn_by_file.values.uniq.length
    msg = test_rail_json_format(esn_by_file)
    if result == 1
      log_pass("Primary Camera ESN is same. #{msg}")
    else
      log_fail("Primary Camera ESN is not same. #{msg}")
    end

    set_tc_name('GUSI Primary Camera ESN should be 8 bytes.')
    result = esn_by_file.keys.all? { |file| esn_by_file[file].split(' ').length == 8 }
    if result
      log_pass("Primary Camera ESN is 8 bytes. #{msg}")
    else
      log_fail("Primary Camera ESN is not 8 bytes. #{msg}")
    end
  end

  def verify_gusi_shot_number(snum_by_file, ts_by_file)
    set_tc_name('GUSI Primary Camera Shot Number should be 2 bytes')
    result = snum_by_file.keys.all? { |file| snum_by_file[file].split(' ').length == 2 }
    msg = test_rail_json_format(snum_by_file)
    if result
      log_pass("Primary Camera Shot Number is 2 bytes. #{msg}")
    else
      log_fail("Primary Camera Shot Number is not 2 bytes. #{msg}")
    end

    set_tc_name('GUSI Primary Camera Shot Number should be same for each encoding.')
    snum_by_ts = {}
    ts_by_file.each do |file, ts|
      if snum_by_ts[ts]
        snum_by_ts[ts] << snum_by_file[file]
      else
        snum_by_ts[ts] = [snum_by_file[file]]
      end
    end

    result = snum_by_ts.values.map(&:uniq).all? {|arr| arr.length == 1}
    if result
      log_pass("Primary Camera Shot Number is same. #{msg}")
    else
      log_fail("Primary Camera Shot Number is not same. #{msg}")
    end
  end

  def verify_gusi_chapter_number(cnum_by_file, ts_by_file)
    set_tc_name('GUSI Chapter Number should be 2 bytes')
    result = cnum_by_file.keys.all? { |file| cnum_by_file[file].split(' ').length == 2 }
    msg = test_rail_json_format(cnum_by_file)
    if result
      log_pass("Chapter Number is 2 bytes. #{msg}")
    else
      log_fail("Chapter Number is not 2 bytes. #{msg}")
    end

    set_tc_name('GUSI Chapter Number should be same for each encoding')
    cnums_by_ts = {}
    ts_by_file.each do |file, ts|
      if cnums_by_ts[ts]
        cnums_by_ts[ts] << cnum_by_file[file]
      else
        cnums_by_ts[ts] = [cnum_by_file[file]]
      end
    end

    result = cnums_by_ts.values.map(&:sort).uniq.length
    if result == 1
      log_pass("Chapter Number is same. #{msg}")
    else
      log_fail("Chapter Number is not same. #{msg}")
    end
  end

  def verify_gusi_backpack_timestamp(snum_by_file, ts_by_file)
    set_tc_name('GUSI Primary Backpack Number at Capture Start should be 4 bytes')
    result = ts_by_file.keys.all? { |file| ts_by_file[file].split(' ').length == 4 }
    msg = test_rail_json_format(ts_by_file)
    if result
      log_pass("Primary Backpack Number at Capture Start is 4 bytes. #{msg}")
    else
      log_fail("Primary Backpack Number at Capture Start  is not 4 bytes. #{msg}")
    end

    set_tc_name('GUSI Primary Backpack Number at Capture Start should be same for each encoding.')
    ts_by_snum = {}
    snum_by_file.each do |file, snum|
      if ts_by_snum[snum]
        ts_by_snum[snum] << ts_by_file[file]
      else
        ts_by_snum[snum] = [ts_by_file[file]]
      end
    end

    result = ts_by_snum.values.map(&:uniq).all? {|arr| arr.length == 1 }
    if result
      log_pass("Primary Backpack Number at Capture Start is same. #{msg}")
    else
      log_fail("Primary Backpack Number at Capture Start  is not same. #{msg}")
    end
  end

  def verify_guri_atom_size(size_by_file)
    set_tc_name('GURI Atom Size should be 24 bytes.')
    msg = test_rail_json_format(size_by_file)
    result = size_by_file.values.all? {|size| size == 24}
    if result
      log_pass("Atom Size is 24 bytes. #{msg}")
    else
      log_fail("Atom Size is not 24 bytes. #{msg}")
    end
  end

  def verify_guri_rig_type(rig_type_by_file)
    set_tc_name('GURI Rig Type should be 1 byte.')
    msg = test_rail_json_format(rig_type_by_file)
    result = rig_type_by_file.values.all? {|typ| typ.split(' ').length == 1}
    if result
      log_pass("Rig Type is 1 byte. #{msg}")
    else
      log_fail("Rig Type is not 1 byte. #{msg}")
    end

    set_tc_name('GURI Rig Type should be same for all encodings.')
    result = rig_type_by_file.values.uniq.length
    if result
      log_pass("Rig Type is same. #{msg}")
    else
      log_fail("Rig Type is not same. #{msg}")
    end
  end

  def verify_guri_rig_size(rig_size_by_file)
    set_tc_name('GURI Rig Size should be same for all encodings.')
    msg = test_rail_json_format(rig_size_by_file)
    result = rig_size_by_file.values.uniq.length
    if result == 1
      log_pass("Rig Size is same. #{msg}")
    else
      log_fail("Rig Size is not same. #{msg}")
    end

    set_tc_name('GURI Rig Size should be 2 bytes.')
    result = rig_size_by_file.values.all? {|size| size.split(' ').length == 2}
    if result
      log_pass("Rig Size is 2 bytes. #{msg}")
    else
      log_fail("Rig Size is not 2 bytes. #{msg}")
    end
  end

  def verify_guri_primary_backpack_esn(esn_by_file)
    set_tc_name('GURI Primary Backpack ESN should be 8 bytes.')
    result = esn_by_file.values.all? { |esn| esn.split(' ').length == 8}
    msg = test_rail_json_format(esn_by_file)
    if result
      log_pass("Primary Backpack ESN is 8 bytes. #{msg}")
    else
      log_fail("Primary Backpack ESN is not 8 bytes. #{msg}")
    end

    set_tc_name('GURI Primary Backpack ESN should be same for all encodings')
    result = esn_by_file.values.uniq.length
    if result
      log_pass("Primary Backpack ESN is same. #{msg}")
    else
      log_fail("Primary Backpack ESN is not same. #{msg}")
    end
  end

  def verify_guri_node_id(node_id_by_file)
    set_tc_name('GURI Node ID should be 2 bytes.')
    result = node_id_by_file.values.all? { |id| id.split(' ').length == 2}
    msg = test_rail_json_format(node_id_by_file)
    if result
      log_pass("Node ID is 2 bytes. #{msg}")
    else
      log_fail("Node ID is not 8 bytes. #{msg}")
    end
  end

  def test_rail_json_format(input)
    JSON.pretty_generate(input).gsub(/\n/, '  ')
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $PROGRAM_NAME
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:logfile, :verb, :media_dir]
    options = t.parse_options(ARGV, use_options)
    unless options[:media_dir]
      puts 'Missing required arguments --media_dir'
      abort
    end
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    unless t.nil?
      t.cleanup
    end
  end
end
