require_relative '../libs/camera'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'

class Test < TestCase
  def initialize
  end

  def setup(options)
    @options = options
    @host = Host.new()
    if @options[:mtp_ip] != nil and @options[:mtp_port] != nil and @options[:mtp_os] != nil
      @camera = get_mtp_camera(@options[:mtp_ip], @options[:mtp_port], @options[:mtp_os])
    else
      log_error("Must specify mtp ip, port, and OS")
      exit 1
    end

  end

  def runtest
    #test_standard_mtp_cmds
    #test_setup_ccl
  end

  def test_setup_ccl
    cmds = @camera.get_cmds

    cmds.each{|cmd| test_set_get_all_keys(cmd)}
  end

  def test_standard_mtp_cmds
    #test_get_storage_id
    #test_get_storage_info
    #test_num_objects
    #test_get_object_handles
    
=begin

    #TODO - 
    test_get_object_info
    test_get_object
    test_get_thumb
    test_format_store
=end
  end

  def test_set_get_all_keys(cmd_symbol)

    case @camera.remote_api_version
    when 1
      #set
      cmd_hash = @camera.method(cmd_symbol).call()
      cmd_name = @camera.method(cmd_symbol).name.to_s

      puts "cmd_hash #{cmd_hash} \t cmd_name #{cmd_name}"
      cmd_set = cmd_hash[:set]
      cmd_get = cmd_hash[:get]

      cmd_hash.delete(:set)
      cmd_hash.delete(:get)
      cmd_hash.delete(:ret)

      cmd_values = cmd_hash.values

      cmd_values.each{|v|
        send_resp = @camera.sendccl(cmd_set, v)
        (log_fail;next) if @camera.success_response?(send_resp)[0] == false
        #        puts "sendccl resp #{send_resp.body}"

        get_resp = @camera.getccl(cmd_get)
        ret = @camera.parse_getccl_resp(get_resp)
        assert_equal(@camera.toGetString(v), ret[:value]) == nil ? pass : fail
        #        puts "getccl resp #{get_resp.body}"
      }

      #get
    when 2

      #set

      #get

    else
      log_error("Unknown remote api version #{@camera.remote_api_version()}")
      exit ExitCode::UNKNOWN_REMOTE_API_VERSION
    end

  end

  def test_get_storage_id
    resp = @camera.get_storage_id
    @camera.success_response?(resp)[0] == true ? pass : fail
    #TODO - parse storage id and get expected
  end

  def test_get_storage_info
    resp = @camera.get_storage_info()

    res = @camera.analyze_storage_info(resp)
    log_pass if !has_failure?(res)
  end

  def test_num_objects
    resp = @camera.get_num_objects()

    res = @camera.analyze_num_objects(resp)
    log_pass if !has_failure?(res)
  end

  def test_get_object_handles
    resp = @camera.get_object_handles()
    
    res = @camera.analyze_object_handles(resp)
    log_pass if !has_failure?(res)
  end
  
  def test_get_object_info
    resp = @camera.get_object_info()

  end

  def cleanup

  end

end #class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:mtp_ip, :mtp_port, :mtp_os, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_info(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
  end
end
