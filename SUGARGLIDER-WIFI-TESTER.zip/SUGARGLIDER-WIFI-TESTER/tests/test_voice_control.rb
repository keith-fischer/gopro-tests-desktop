require 'fileutils'
require 'json'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase

  include TestUtils
  def intialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    @host = Host.new
    @camera = tu_get_camera
    @audio_dir = "/mnt/gopro-share/VoiceControl"
    @lang_dir = "#{@audio_dir}/#{@options[:vc_lang]}"
    @cmd_json = "/mnt/gopro-share/VoiceControl/VoiceControl.json"

    if !Dir.exist?(@audio_dir)
      log_error("Required audio directory #{@audio_dir} doesn't exist.")
      exit ExitCode::ERROR
    end

    begin
      file = File.read(@cmd_json)
      @data_hash = JSON.parse(file)
    rescue StandardError => e
      log_error(e.to_s)
      log_info(e.backtrace.join("\n"))
      exit ExitCode::ERROR_PARSING_VOICECONTROL_JSON
    end
    tu_keep_or_delete_all_media
    tu_verify_sd_status
  end

  def runtest

    #get all possible commands/tests to run
    test_params, json_cam_state = tu_get_voice_commands_test_params()

    if test_params.empty?
      log_info("Nothing to test. Exiting..")
      exit
    end

    if @options[:n_iter] && @options[:n_iter].to_s =~ /^\d*$/
      iter = @options[:n_iter].to_i
      log_info("To execute total #{iter} iteration(s)")
    else
      log_warn("Invalid iteration value. Default to  1")
      iter = 1
    end

    1.upto(iter) { |i|

      log_info("Iteration #{i}: Running #{test_params.length} tests")

      test_params.each { |lang, input, state, command, audio|

        #      next if command == 'gopro_turn_off'  #can't test this yet
        #      next if command == 'gopro_start_video'
        #      next if command == 'gopro_start_time_lapse'
        #      next if command == 'gopro_take_photo'
        #      next if command == 'gopro_shoot_burst'
        #      next if command == 'gopro_video_mode'
        #      next if command == 'gopro_photo_mode'
        #      next if command == 'gopro_time_lapse'
        #      next if command == 'gopro_burst_mode'
        #      next if command == 'gopro_stop_video'
        #      next if command == 'gopro_stop_time_lapse'
        #      next if command == 'gopro_highlight'
        #      next if command == 'oh_shit'
        #      next if command == 'gopro_turn_on'

        json_cam_state.each { |c_state|
          set_tc_name("iteration_#{i}_camera_state_#{c_state}_#{lang}_#{state}_#{command}")
          @lang_dir = "#{@audio_dir}/#{lang}"
          audio_file = "#{@lang_dir}/#{audio}"
          if !Dir.exist?(@lang_dir)
            log_skip("#{@lang_dir} directory doesn't exist. Skipping")
            next
          elsif !File.exist?(audio_file)
            log_skip("#{audio_file} file doesn't exist. Skipping")
            next
          end

          medialist_mp4_before = @camera.get_medialist("MP4")
          medialist_jpg_before = @camera.get_medialist("JPG")

          #put camera in json_cam_state
          sh = @camera.get_status(:shutter)
          case c_state

          when "idle"

            if command == 'gopro_video_mode'
              temp = ['PHOTO', 'TIMELAPSE', 'BURST']
              mode = temp[Random.rand(temp.length)]

              ret, msg = @camera.set_capture_mode(mode)
              log_info(msg)
              exit ExitCode::ERROR if !ret
            end

            if sh.to_s == "1"
              ret, msg = @camera.stop_capture
              exit ExitCode::CAMERA_BUSY if !ret
            end

          when "encoding"

            if command == 'gopro_stop_time_lapse'
              ret, msg = @camera.set_capture_mode("TIMELAPSE")
              log_info(msg)
              exit ExitCode::ERROR if !ret
            else
              ret, msg = @camera.set_capture_mode("VIDEO")
              log_info(msg)
              exit ExitCode::ERROR if !ret
            end

            if sh.to_s == "0"
              ret, msg = @camera.start_capture
              sleep (2)
              exit ExitCode::ERROR if !@camera.busy?
            end

          when "off"
            @camera.send_camera_sleep_api2

          else
            log_skip("Skipping since not recognizing camera state #{c_state}. Please add new state to test script.")
          end

          method(command).call(c_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
        } #end camera_state
      } #end test_params
    } #iteration

  end

  def gopro_turn_off(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    log_skip("Skipping due to STK-3024")
    ret, msg = @camera.stop_capture
    exit ExitCode::CAMERA_BUSY if !ret
    return

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(3)

    #positive case
    if (camera_state == "idle" && state == "idle")

      if @host.curlable?(@ip)
        failed_arr << ("Camera is still on after executing #{command}")
      else
        log_info("Camera is off")

        #turn camera back on using wol
        exit ExitCode::CAMERA_OFF if !@camera.api2_camera_power_on_ok?
      end

    #negative case
    else
      if !@host.curlable?(@ip)
        failed_arr << ("Camera is off after excuting #{command}")

        #turn camera back on using wol
        exit ExitCode::CAMERA_OFF if !@camera.api2_camera_power_on_ok?
      else
        log_info("Camera is still on")
      end

    end
    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_start_video(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")

      #checking mode status
      failed_arr << ("Not in video single mode") if @camera.is_current_capture_mode?("VIDEO") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera didn't start encoding after executing #{command}")
      else
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("No new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length == 0)

      medialist_jpg_after = @camera.get_medialist("JPG")
      failed_arr << ("Camera has new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length > 0)

    else #negative case

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding after executing #{command}")

        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end
    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_start_time_lapse(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")

      #checking mode status
      failed_arr << ("Not in timelapse mode") if @camera.is_current_capture_mode?("TIMELAPSE") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera didn't start encoding after executing #{command}")
      else
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      failed_arr << ("No new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length == 0)

      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)

    else #negative case

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command} ")

        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_take_photo(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")

      #checking mode status
      failed_arr << ("Not in photo single mode") if @camera.is_current_capture_mode?("PHOTO") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera is still encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      failed_arr << ("No new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length == 0)

      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)

    else #negative case
      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command} ")

        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_shoot_burst(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")
      sleep(20)

      #checking mode status
      failed_arr << ("Mode not in burst") if @camera.is_current_capture_mode?("BURST") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera is still encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      failed_arr << ("No new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length == 0)

      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)

    else #negative case
      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command} ")

        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end
    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_video_mode(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")

      #checking mode status
      failed_arr << ("Not in video single mode") if @camera.is_current_capture_mode?("VIDEO") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)

      if sh.to_s == "1"
        failed_arr << ("Camera started encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)
      failed_arr << ("Camera has new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length > 0)

    else #negative case

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_photo_mode(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")
      #checking mode status
      failed_arr << ("Not in photo mode") if @camera.is_current_capture_mode?("PHOTO") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera started encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{i} command") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)
      failed_arr << ("Camera has new JPG after #{i} command") if (medialist_jpg_after.length - medialist_jpg_before.length > 0)

    else #negative case
      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_time_lapse(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{method}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")
      #checking mode status
      failed_arr << ("Mode not in timelapse") if @camera.is_current_capture_mode?("TIMELAPSE") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)

      if sh.to_s == "1"
        failed_arr << ("Camera started encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)
      failed_arr << ("Camera has new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length > 0)

    else #negative case
      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_burst_mode(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "idle" && state == "idle")
      #checking mode status
      failed_arr << ("Not in burst mode") if @camera.is_current_capture_mode?("BURST") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)

      if sh.to_s == "1"
        failed_arr << ("Camera started encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

      #checking file existence on SD card
      medialist_jpg_after = @camera.get_medialist("JPG")
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)
      failed_arr << ("Camera has new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length > 0)
    else #negative case

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "0"
        failed_arr << ("Camera isn't in encoding mode after executing #{command}")
      else
        log_info("Camera is still in encoding mode after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_stop_video(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "encoding" && state == "encoding")

      failed_arr << ("Not in video single mode") if @camera.is_current_capture_mode?("VIDEO") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera is still encoding after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      else
        log_info("Camera is not in encoding mode after executing #{command}")
      end

      #checking file existence on SD card
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("No new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length == 0)

      medialist_jpg_after = @camera.get_medialist("JPG")
      failed_arr << ("Camera has new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length > 0)

    else #negative case

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera is still in encoding mode after executing #{command}")

        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      else
        log_info("Camera not in encoding mode after executing #{command}")
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_stop_time_lapse(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__}_#{camera_state} \t #{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")

    failed_arr = []

    log_info("Playing #{audio_file} for command #{command}")
    ret = @host.play_audio(audio_file)
    failed_arr << ("Unable to play file #{audio_file}") if !ret

    sleep(2)

    #positive case
    if (camera_state == "encoding" && state == "encoding")

      failed_arr << ("Not in time lapse mode") if @camera.is_current_capture_mode?("TIMELAPSE") != true

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera is still in encoding mode after executing #{command}")
        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      else
        log_info("Camera is not in encoding mode after executing #{command}")
      end

      #checking file existence on SD card
      medialist_mp4_after = @camera.get_medialist("MP4")
      failed_arr << ("Camera has new MP4 after #{command}") if (medialist_mp4_after.length - medialist_mp4_before.length > 0)

      medialist_jpg_after = @camera.get_medialist("JPG")
      failed_arr << ("No new JPG after #{command}") if (medialist_jpg_after.length - medialist_jpg_before.length == 0)

    else #negative case

      #checking shutter status
      sh = @camera.get_status(:shutter)
      if sh.to_s == "1"
        failed_arr << ("Camera is still in encoding mode after executing #{command}")

        ret, msg = @camera.stop_capture
        exit ExitCode::CAMERA_BUSY if !ret
      else
        log_info("Camera is not in encoding mode after executing #{command}")
      end

    end

    log_pass("Tests passed.") if !has_failure?(failed_arr)
  end

  def gopro_highlight(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__} \t #{cam_state} \t _#{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")
    log_skip("TO DO")
    ret, msg = @camera.stop_capture
    exit ExitCode::CAMERA_BUSY if !ret
  end

  def oh_shit(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__} \t #{cam_state} \t _#{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")
    log_skip("TO DO")
    ret, msg = @camera.stop_capture
    exit ExitCode::CAMERA_BUSY if !ret
  end

  def gopro_turn_on(camera_state, lang, input, state, command, audio_file, medialist_mp4_before, medialist_jpg_before)
    #log_info("#{__method__} \t #{cam_state} \t _#{lang} \t #{input} \t #{state} \t #{command} \t #{audio_file}")
    log_skip("TO DO")
    ret, msg = @camera.stop_capture
    exit ExitCode::CAMERA_BUSY if !ret
  end

  def cleanup
    @host.kill_status_process() if @host
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev,
                   :vc_lang, :vc_command, :vc_input,
                   :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
                   :save_dir, :shuffle, :verb, :range, :keep_media, :n_iter]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil

    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    if t
      t.cleanup
      t.final_actions
    end    
  end
end
