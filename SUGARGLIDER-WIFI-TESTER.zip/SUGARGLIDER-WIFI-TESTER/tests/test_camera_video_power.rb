    # test_video_simple_metadatarb
# Description: Iterates over all RES/FPS/FOV with both ProTunes
#              off and on (if supported).  Also checks LRV and THM.
# Tests the following items:
#   - The following video metadata is correct:
#     - aspect_ratio
#     - audio_channels
#     - audio_codec
#     - audio_sample_rate
#     - bitrate
#     - colorspace
#     - frame_rate
#     - has_timecode
#     - height
#     - width
#     - video_codec
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    $host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    else
      log_error("Must specify serial device (--serial)")
      exit 1
    end
    if @options[:ip] != nil
      @monitor_cam = get_wifi_camera(@options[:ip])
      # $host.get_cam_power(@monitor_cam)
      # exit 1
  	else
      log_error("Must specify monitor camera IP")
      exit 1
    end
    @camera.powerstrip = PowerStrip.new(@options[:power_ip], 
                         @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.exit_mass_storage_mode() if @camera.is_mounted?
    @camera.delete_all_media() if not @options[:quick]
    @camera.do_reset() if not @options[:quick]
    @camera.exit_mass_storage_mode() if @camera.is_mounted?
#    set_options()
  end

  def test_capture(res, pt, fps, fov, duration, tries=2)
    (1..tries).each { |n|
      log_info("TRY #{n} -- Capturing #{duration} seconds of #{res}/#{fps}/#{fov} video")
      if @camera.is_ntsc?(res, fps) and @camera.is_pal?(res, fps)
        Random.rand(2) == 0 ? vm = "NTSC" : vm = "PAL"
        log_info("#{res}/#{fps} is both PAL/NTSC. Coin flip chose #{vm} for this run.")
      elsif @camera.is_ntsc?(res, fps)
        vm = "NTSC"
      else
        vm = "PAL"
      end

      ret, msg = false, "Capture failed"
      p_cap, p_idle = 0.0, 0.0
      last_video_attempted = nil
      retries = 2

      (1..retries).each { |n|
        last_video_attempted = nil
	      log_debug("Capture video try #{n} of #{retries}")
	      if @camera.set_capture_mode("VIDEO") == false
	        next if n < retries
	        ret, msg =  false, "Unable to set camera mode to VIDEO capture"
	        break
	      end

	      log_debug("Setting ProTune #{pt}")
	      ret, msg = @camera.set_video_protune(pt)
	      log_info(msg)
	      cam_alive, status_msg = @camera.detect_crash_and_reboot()
	      log_debug(status_msg)
	      if cam_alive == false; next if n < retries; ret, msg = false, status_msg; break; end
	      if ret == false; next if n < retries; ret, msg = false, msg; break; end

	      log_debug("Setting capture mode")
	      ret, msg = @camera.set_video(vm, res, fps, fov)
	      log_info(msg)
	      cam_alive, status_msg = @camera.detect_crash_and_reboot()
	      log_debug(status_msg)
	      if cam_alive == false; next if n < retries; ret, msg = false, status_msg; break; end
	      if ret == false; next if n < retries; ret, msg = false, msg; break; end

	      log_debug("Starting capture")
	      start_time = Time.now()
	      ret, msg = @camera.start_capture()
	      log_info(msg)
	      cam_alive, status_msg = @camera.detect_crash_and_reboot()
	      log_debug(status_msg)
	      if cam_alive == false; next if n < retries; ret, msg = false, status_msg; break; end
	      if ret == false; next if n < retries; ret, msg = false, msg; break; end
	      f1 = msg
	      log_debug("Capturing to #{f1}")
	      last_video_attempted = f1.split("\\")[-1]

	      p_cap = $host.get_cam_power(@monitor_cam)
	      elapsed = Time.now() - start_time
	      sleep (duration - elapsed) if (duration - elapsed) > 0

	      log_info("Stopping capture")
	      ret, msg = @camera.stop_capture()
	      log_info(msg)
	      cam_alive, status_msg = @camera.detect_crash_and_reboot()
	      log_debug(status_msg)
	      if cam_alive == false; next if n < retries; ret, msg = false, status_msg; break; end
	      if ret == false; next if n < retries; ret, msg = false, msg; break; end
	      sleep 2
	      p_idle = $host.get_cam_power(@monitor_cam)
	      ret, msg = true, f1
        break
	    }

      if ret == false
        @camera.do_reset()
        sleep(3.0)
        next if n < tries
        fail(msg)
        return
      end
      
      mp4file = last_video_attempted
      if mp4file == nil
        @camera.do_reset()
          sleep(3.0)
          next if n < tries
          fail("No MP4 file name seen in logging output")
          return
      else
        log_info("Checking that #{mp4file} is on the SD card")
        if @camera.find_file(mp4file) == true
          $video_data << [res, fps, fov, pt, mp4file]
          s = "#{res}, #{fps}, #{fov}, #{pt}, #{mp4file}, #{p_idle}, #{p_cap}"
          File.open($data_log, "a") { |f| f.puts(s) } if $data_log != nil
          pass("Capture successful and video file #{mp4file} found on SD card")
          return
        else
          @camera.do_reset()
          sleep(3.0)
          next if n < tries
          fail("Unable to find #{mp4file} on SD card")
          return
        end
      end
    } # end tries
  end

  def runtest()
    # This global will hold mapping between RES/FPS/FOV/PT and video files
    $video_data = []
    $data_log = File.join("/tmp", "power_data.log")
    if File.exists?($data_log)
      log_warn("#{$data_log} exists!  Deleting to start fresh")
      File.delete($data_log)
    end
    
    if @options[:quick] == true
      test_metadata()
      return
    end
    
    # Enumerate all the test combinations
    test_params = []
    @camera.get_video_resolution().each do |res|
      next if @options[:video_resolution] != nil and @options[:video_resolution] != res
      @camera.get_video_fps(res).each do |fps|
        next if @options[:video_fps] != nil and @options[:video_fps] != fps
        @camera.get_video_fov(res, fps).each do |fov|
          next if @options[:video_fov] != nil and @options[:video_fov] != fov
          log_verb("Adding test [#{res}, #{fps}, #{fov}]")
          test_params << [res, fps, fov]
        end # fov
      end # fps
    end # res
    
    if test_params.length == 0
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end
    test_params.shuffle! if @options[:shuffle]
    
    # Now run each test
    duration = (@options[:duration] != nil) ?  @options[:duration] : 5 #seconds
    if @options[:duration_range_low] and @options[:duration_range_high]
      duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
      log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
    end
    
    if @options[:video_protune] == nil or @options[:video_protune] == "OFF"
      test_params.each do |res, fps, fov|
        set_tc_name("#{res}_#{fps}_#{fov}_capture")
        begin
          test_capture(res, "OFF", fps, fov, duration)
          break if @hard_fail and @assertion_failed
        rescue StandardError => e
          log_error(e.to_s + "\n" + e.backtrace.join("\n"))
        end
      end # end test_params
    end # end protune=nil/OFF
    if @options[:video_protune] == nil or @options[:video_protune] == "ON"
      test_params.each do |res, fps, fov|
        set_tc_name("#{res}_#{fps}_#{fov}_protune_capture")
        begin
          test_capture(res, "ON", fps, fov, duration)
          break if @hard_fail and @assertion_failed
        rescue StandardError => e
          log_error(e.to_s + "\n" + e.backtrace.join("\n"))
        end
      end # end test_params
    end # end protune=nil/ON 
  end # end runtest

  def cleanup
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, 
      :battoutlet, :usboutlet, 
      :video_resolution, :video_fps, :video_fov, :setup_beep,
      :video_protune, :video_protune_color, :video_protune_white_balance, 
      :video_protune_exposure, :video_protune_sharpness,
      :duration, :shuffle, :save_dir, :verb, :quick]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
