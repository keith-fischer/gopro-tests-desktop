# test_wifi

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/wifi_commands'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest

    test_setup_settings

    if @camera.remote_api_version() == 2
      test_mode_switching("VIDEO")
      test_mode_switching("VIDEO_TIMELAPSE") if @camera.video_timelapse_support?
      test_mode_switching("VIDEO_PIV") if @camera.video_piv_support?
      test_mode_switching("VIDEO_LOOPING") if @camera.video_looping_support?
      test_mode_switching("PHOTO")
      test_mode_switching("PHOTO_CONTINUOUS") if @camera.photo_continuous_support?
      test_mode_switching("PHOTO_NIGHT") if @camera.photo_night_support?
      test_mode_switching("BURST")
      test_mode_switching("TIMELAPSE")
      test_mode_switching("NIGHTLAPSE") if @camera.multi_photo_nightlapse_support?
      test_locate
      test_date_time
      # Will automatically skip for camera models that don't support ProTune
      test_protune_defaults
      test_multi_photo_shutter_exposure
    end

    # RES/FPS/FOV ProTune & Non-ProTune
    # Plus Low-light and Looping
    test_all_res_fps_fov("OFF")
    test_all_res_fps_fov("ON") if @camera.video_protune_support?

    #PHOTO MODES (SINGLE/NIGHT/CONTINUOUS)
    test_all_photo_modes("OFF")
    test_all_photo_modes("ON") if @camera.photo_protune_support?()

    #MULTI_PHOTO MODES (BURST/TIMELAPSE/NIGHTLAPSE)
    test_all_multi_photo_modes("OFF")
    test_all_multi_photo_modes("ON") if @camera.multi_photo_protune_support?()

    #camera capabilities
    #for remote api version 2, there is really no dedicated command.
    test_cc_params() if @camera.remote_api_version() == 1

  end

  def test_setup_settings
    cmds = @camera.get_cmds()
    cmds.shuffle! if @options[:shuffle]
    cmds.each { |i|
      begin
        test_wifi_cmd_all_keys(i)
        sleep 1
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    }
    @camera.set(:locate_ll, "OFF") if @camera.remote_api_version() == 1
  end

  def test_mode_switching(m)
    set_tc_name("setup_mode_#{m}")
    @camera.wait_until_not_busy
    path = @camera.capture_mode_mapping_api2[m]
    mode_index = @camera.get_level_1_index(path)
    @camera.get_settings_json_hash
    mode_value = @camera.settings_json_hash["modes"][mode_index]["value"]
    mode_value = mode_index if mode_value.nil?

    (log_fail("Failed to switch to capture mode #{m} because #{path} path isn't found in settings.json");return) if mode_value == nil

    case path
    when 'video'
      submode_id, submode_value = @camera.get_id_value(:video_submode, m)
    when 'photo'
      submode_id, submode_value = @camera.get_id_value(:photo_submode, m)
    when 'multi_shot'
      submode_id, submode_value = @camera.get_id_value(:multi_photo_submode, m)
    else
      (log_fail("Failed to switch to capture mode #{m} because of unknown modes #{path}");return)
    end

    #set mode
    resp = @camera.send_mode_submode_api2(mode_value, submode_value)
    sleep(3.0)

    actual_submode = @camera.get_status_api2(:submode)
    actual_mode = @camera.get_status_api2(:mode)

    (log_fail("Failed to switch to capture mode #{m} because submode is incorrect. Expected: #{submode_value}. Actual: #{actual_submode}");return) if \
    actual_submode.to_s.upcase != submode_value.to_s.upcase

    (log_fail("Failed to switch to capture mode #{m} because mode is incorrect. Expected: #{mode_value}. Actual: #{actual_submode}");return) if \
    actual_mode.to_s.upcase != mode_value.to_s.upcase

    log_pass("Change capture mode to #{m} successfully")

  end

  def test_multi_photo_shutter_exposure
    if not @camera.get_multi_shutter_exposure_intervals().empty?
      #NOTE - prev_sh in gpControl value (not camera's shutter interval)
      prev_sh = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)

      if @camera.multi_photo_protune_support? == true
        @camera.set_multi_photo_protune("ON")
        @camera.get_multi_photo_nightlapse_rates().each { |pes|
          @camera.get_multi_shutter_exposure_intervals().each { |sh|
            if pes == "CONTINUOUS" or sh == "AUTO" or pes.to_i > sh.to_i
              set_tc_name("nightlapse_#{pes}_shutter_#{sh}")
              # First set shutter to AUTO to ensure we can reach nightlapse interval
              @camera.set_multi_photo_shutter_exposure("AUTO")
              # Then set the nightlapse interval
              ret, msg = @camera.set_multi_photo_nightlapse(pes)
              (ret == false) ? (fail(msg); next) : pass(msg)
              # Finally set the shutter to the actual value
              ret, msg = @camera.set_multi_photo_shutter_exposure(sh)
              (ret == false) ? (fail(msg); next) : pass(msg)
            else
              next
              act_value = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)
              assert_equal(prev_sh, act_value) == nil ? pass : fail
            end

            prev_sh = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)
          }
        }
      end # end camera.multi_photo_protune_support?
    end # end get_multi_shutter_exposure_intervals()
  end

  def test_locate
    #Turn ON
    set_tc_name("locate_ON")
    resp = @camera.send_locate_camera_api2(1)
    http_result = @camera.http_resp_ok(resp)
    ret = @camera.get_status_api2(:locate)
    result = assert_equal(1, ret.to_i, "Locate ON")
    if result != nil and http_result != true
      fail()
    else
      pass()
    end

    #Turn OFF
    set_tc_name("locate_OFF")
    resp = @camera.send_locate_camera_api2(0)
    http_result = @camera.http_resp_ok(resp)
    ret = @camera.get_status_api2(:locate)
    result = assert_equal(0, ret.to_i, "Locate OFF")
    if result != nil and http_result != true
      fail()
    else
      pass()
    end
  end

  def test_date_time
    set_tc_name("set_date_time")
    retries = 2
    resp = false
    failed_arr = []

    for i in 1..retries
      t = Time.now.strftime("%Y-%m-%d-%H-%M-%S")
      year, month, day, hour, min, sec = t.split('-')
      year = year.to_i - 2000

      exp_year =  @camera.wifi_itohs(year.to_i).upcase
      exp_month = @camera.wifi_itohs(month.to_i).upcase
      exp_day = @camera.wifi_itohs(day.to_i).upcase
      exp_hour = @camera.wifi_itohs(hour.to_i).upcase
      exp_min = @camera.wifi_itohs(min.to_i).upcase
      exp_sec = @camera.wifi_itohs(sec.to_i).upcase

      date_time_str = exp_year
      date_time_str += exp_month
      date_time_str += exp_day
      date_time_str += exp_hour
      date_time_str += exp_min
      date_time_str += exp_sec

      resp = @camera.send_date_time_api2(date_time_str)

      if resp != false
        act_date_time = @camera.get_status_api2(:date_time)
        act_year = act_date_time[0..2]
        act_month = act_date_time[3..5]
        act_day = act_date_time[6..8]
        act_hour = act_date_time[9..11]
        act_min = act_date_time[12..14]
        act_sec = act_date_time[15..17]

        failed_arr << assert_delta(exp_year, act_year, 1, "Year")
        failed_arr << assert_delta(exp_month, act_month, 1, "Month")
        failed_arr << assert_delta(exp_day, act_day, 1, "Day")
        failed_arr << assert_delta(exp_hour, act_hour, 1,  "Hour")
        failed_arr << assert_delta(exp_min, act_min, 1, "Min")
        failed_arr << assert_delta(exp_sec, act_sec, 5, "Sec")
        break
      end
    end
    resp == false ? fail("Set date and time command returns unsuccessful http code") : ( pass if !has_failure?(failed_arr))
  end

  def test_protune_defaults
    failed_arr = []

    # Video
    if @camera.video_protune_support? == true
      set_tc_name("video_protune_reset")
      @camera.send_video_protune_reset

      ret = @camera.get_status(:video_protune_default)
      failed_arr << assert_equal(1, ret, "Video protune default isn't 1 after reset in /status")

      @camera.get_video_protune_vars().each(){|k, v|
        # Only check ProTune settings valid for this camera
        # E.g. Rockypoint doesn't have WB, Color, or Exposure
        next if v == false
        id, exp = @camera.get_id_value(k, @camera.defaults()[k])
        act = @camera.get_setting_status_api2_by_name(k)
        failed_arr << assert_equal(exp, act, "#{k} value isn't as expected.")
      }
      pass if !has_failure?(failed_arr)
      failed_arr.clear
    end

    # Photo
    if @camera.photo_protune_support? == true
      @camera.get_photo_shutter_exposure_intervals.each(){ |sh|
        set_tc_name("photo_protune_reset_shutter_#{sh}")
        @camera.set_photo_shutter_exposure(sh)
        @camera.send_photo_protune_reset

        ret = @camera.get_status(:photo_protune_default)
        failed_arr << assert_equal(1, ret, "Photo protune default isn't 1 after reset in /status")

        @camera.get_photo_protune_vars().each(){|k, v|
          #TODO - remove IF statement (use else) when white balance has same default for all shutter intervals
          if k == :photo_pt_wb
            sh_cur_value = @camera.get_setting_status_api2_by_name(:photo_shutter_ev)
            wb_cur_value = @camera.get_setting_status_api2_by_name(:photo_pt_wb)

            sh_auto_id, sh_auto_value = @camera.get_id_value(:photo_shutter_ev, "AUTO")
            wb_auto_id, wb_auto_value = @camera.get_id_value(:photo_pt_wb, "AUTO")
            wb_5500K_id, wb_5500K_value = @camera.get_id_value(:photo_pt_wb, "5500K")

            if sh_cur_value == sh_auto_value and wb_cur_value != wb_auto_value
              failed_arr << "Photo protune white balance default isn't AUTO when shutter exposure is AUTO. Expected: #{wb_auto_value}. Actual: #{wb_cur_value}"
            end

            if sh_cur_value != sh_auto_value and wb_cur_value != wb_5500K_value
              failed_arr << "Photo protune white balance default isn't 5500K when shutter exposure isn't AUTO. Expected: #{wb_5500K_value}. Actual: #{wb_cur_value}"
            end

          else
            act = @camera.get_setting_status_api2_by_name(k)
            id, exp = @camera.get_id_value(k, @camera.defaults()[k])
            failed_arr << assert_equal(exp, act, "#{k} value isn't as expected.")
          end
        }
        pass if !has_failure?(failed_arr)
        failed_arr.clear
      }
    end

    # Multi_photo.
    if @camera.multi_photo_protune_support? == true
      @camera.get_multi_shutter_exposure_intervals().each{|sh|
        set_tc_name("multi_photo_protune_reset_shutter_#{sh}")
        @camera.set_multi_photo_shutter_exposure(sh)
        @camera.send_multi_photo_protune_reset

        ret = @camera.get_status(:multi_photo_protune_default)
        failed_arr << assert_equal(1, ret, "Multi-Photo protune default isn't 1 after reset in /status")

        #TODO - SAVE!!! uncomment IF statement (use else) when white balance has same default for all shutter intervals
        @camera.get_multi_photo_protune_vars().each(){|k, v|
          if k == :multi_photo_pt_wb
            sh_cur_value = @camera.get_setting_status_api2_by_name(:multi_photo_shutter_ev)
            wb_cur_value = @camera.get_setting_status_api2_by_name(:multi_photo_pt_wb)

            sh_auto_id, sh_auto_value = @camera.get_id_value(:multi_photo_shutter_ev, "AUTO")
            wb_auto_id, wb_auto_value = @camera.get_id_value(:multi_photo_pt_wb, "AUTO")
            wb_5500K_id, wb_5500K_value = @camera.get_id_value(:multi_photo_pt_wb, "5500K")

            if sh_cur_value == sh_auto_value and wb_cur_value != wb_auto_value
              failed_arr << "Multi-photo protune white balance default isn't AUTO when shutter exposure is AUTO. Expected: #{wb_auto_value}. Actual: #{wb_cur_value}"
            end

            if sh_cur_value != sh_auto_value and wb_cur_value != wb_5500K_value
              failed_arr << "Multi-photo protune white balance default isn't 5500K when shutter exposure isn't AUTO. Expected: #{wb_5500K_value}. Actual: #{wb_cur_value}"
            end

          else
            act = @camera.get_setting_status_api2_by_name(k)
            id, exp = @camera.get_id_value(k, @camera.defaults()[k])
            failed_arr << assert_equal(exp, act, "#{k} value isn't as expected.")
          end
        }

        pass if !has_failure?(failed_arr)
        failed_arr.clear
      }
    end
  end

  def test_all_photo_modes(protune)

    #test photo_protune
    if protune == "ON"
      set_tc_name("photo_protune_#{protune}")
      test_set_and_get(:photo_pt, nil, "ON", "ON", true)

      #photo protune variables
      pt_vars = @camera.get_photo_protune_vars

      pt_vars.keys.each { |v|
        if pt_vars[v]
          test_wifi_cmd_all_keys(v)
        end
      }
    end

    if protune == "OFF"
      if @camera.photo_protune_support?()
        set_tc_name("photo_protune_#{protune}")
        test_set_and_get(:photo_pt, nil, "OFF", "OFF", true)
      end

      #test photo resolution
      res = @camera.get_photo_resolutions
      res.each {|r|
        set_tc_name("photo_resolution_#{r}_protune_#{protune}")
        test_set_and_get(:photo_resolution, @camera.photo_resolution, r, r, true)
      }

      #test photo continuous rate
      test_wifi_cmd_all_keys(:photo_continuous) if @camera.photo_continuous_support?()
    end

  end

  def test_all_multi_photo_modes(protune)
    #test multi photo_protune
    if protune == "ON"
      set_tc_name("multi_photo_protune_#{protune}")
      test_set_and_get(:multi_photo_pt, nil, "ON", "ON", true)

      #multi photo protune variables
      pt_vars = @camera.get_multi_photo_protune_vars

      pt_vars.keys.each { |v|
        if pt_vars[v]
          test_wifi_cmd_all_keys(v)
        end
      }
    end

    if protune == "OFF"
      if @camera.photo_protune_support?()
        set_tc_name("multi_photo_protune_#{protune}")
        test_set_and_get(:multi_photo_pt, nil, "OFF", "OFF", true)
      end

      #test multi photo resolution
      res = @camera.get_photo_resolutions
      res.each {|r|
        set_tc_name("multi_photo_resolution_#{r}_protune_#{protune}")
        test_set_and_get(:multi_photo_resolution, @camera.multi_photo_resolution, r, r, true)
      }

      #multi-photo burst
      @camera.get_multi_photo_burst_rates().each { |bu|
        set_tc_name("multi_photo_burst_#{bu}_protune_#{protune}")
        test_set_and_get(:multi_photo_burst, @camera.multi_photo_burst, bu, bu, true)
      }
      # test_wifi_cmd_all_keys(:multi_photo_burst)

      #multi_photo timelapse
      @camera.get_multi_photo_timelapse_rates().each { |ti|
        set_tc_name("multi_photo_timelapse_#{ti}_protune_#{protune}")
        test_set_and_get(:multi_photo_timelapse, @camera.multi_photo_timelapse, ti, ti, true)
      }
      # test_wifi_cmd_all_keys(:multi_photo_timelapse)

      #multi_photo nightlapse - test in test_multi_photo_shutter_exposure
      #test_wifi_cmd_all_keys(:multi_photo_nightlapse) if @camera.multi_photo_nightlapse_support?()
    end

  end

  def test_all_res_fps_fov(protune="OFF")

    res_set = []
    fps_set = []
    fov_set = []

    #tracker to run command only once
    protune_vars_tested = false
    preview_vars_tested = false
    looping_vars_tested = false
    piv_vars_tested = false
    low_light_vars_tested = false

    if @camera.video_protune_support? == true
      if protune == "ON"
        @camera.set_video_protune("ON")
      else
        @camera.set_video_protune("OFF")
      end
    end

    ["NTSC", "PAL"].each do |video_mode|
      next if video_mode == "NTSC" and @options[:pal_only]
      next if video_mode == "PAL"  and @options[:ntsc_only]

      @camera.set_video_format(video_mode)
      sleep(2.0)
      @camera.set_capture_mode("VIDEO")
      sleep(2.0)

      # RES
      r = @camera.get_video_resolution()
      r.shuffle! if @options[:shuffle] == true
      r.each do |res|
        next if @options[:video_resolution] != nil and @options[:video_resolution] != res
        next if protune == "ON" && @camera.video_protune_support?(res) == false

        if res_set.include?(res) == false
          set_tc_name("video_resolution_#{res}_protune_#{protune}")
          test_set_and_get(:video_resolution, @camera.video_resolution, res, res, true)
          res_set.push(res)
        end

        # FPS
        fs = @camera.get_video_fps(res)
        fs.shuffle! if @options[:shuffle] == true
        fs.each do |fps|
          next if @options[:video_fps] != nil and @options[:video_fps] != fps
          next if !@camera.mode_supported?(video_mode, res, fps)

          # Turns out there are some RES that support Protune, but FPS that do not
          next if protune == "ON" and !@camera.video_protune_support?(res, fps)

          if fps_set.include?(fps) == false
            ret, msg = @camera.set_video_resolution(res)
            sleep(2.0)
            log_info(msg)

            # set_tc_name("#{video_mode}_protune_#{protune}_#{res}_#{fps}")
            set_tc_name("video_fps_#{fps}_protune_#{protune}")
            test_set_and_get(:video_fps, @camera.video_fps, key=fps, expected=fps, true)
            fps_set.push(fps)
          end

          if protune == "ON"
            if  @camera.video_protune_support?(res) == true && protune_vars_tested == false
              pt_vars = @camera.get_video_protune_vars()
              pt_vars.keys.each { |v|
                if pt_vars[v]
                  test_wifi_cmd_all_keys(v)
                end
              }
              protune_vars_tested = true
            end
          else # ProTune == "OFF"
            #Looping
            if @camera.video_looping_support?(res, fps) && looping_vars_tested == false
              @camera.set_capture_mode("VIDEO_LOOPING")
              sleep 1
              full_cmd_hash = tu_get_cmd_hash(:video_looping)
              cmd_hash = @camera.get_set_params(full_cmd_hash)
              cmd_hash.shuffle! if @options[:shuffle] == true

              cmd_hash.each { |key, value|
                set_tc_name("looping_#{key}")
                ret, msg = @camera.set_video_looping(key)
                if ret == true
                  if @camera.get_mins_avail > tu_get_looping_min_reqd(@camera, key)
                    pass("Looping correctly set to #{key}")
                  else
                    fail("Looping incorrectly set to #{key}")
                  end
                else
                  if @camera.get_mins_avail < tu_get_looping_min_reqd(@camera, key)
                    pass("Looping correctly NOT set to #{key}")
                  else
                    fail("Looping incorrectly NOT set to #{key}")
                  end
                end
              }
              looping_vars_tested = true
              @camera.set_capture_mode("VIDEO")
            end
          end

          # Low-light settings
          if @camera.video_low_light_support?(res, fps) && low_light_vars_tested == false
            set_tc_name("low_light_protune_#{protune}")
            test_wifi_cmd_all_keys(:video_low_light)

            low_light_vars_tested = true
          end

          # FOV
          fv = @camera.get_video_fov(res, fps, protune)
          fv.shuffle! if @options[:shuffle] == true
          fv.each do |fov|
            if fov_set.include?(fov) == false
              set_tc_name("video_fov_#{fov}_protune_#{protune}")
              test_set_and_get(:video_fov, @camera.video_fov, key=fov, expected=fov, true)
              fov_set.push(fov)
            end

            if protune == "OFF"
              #PIV
              if @camera.video_piv_support?(res,fps,fov) && piv_vars_tested == false
                full_cmd_hash = tu_get_cmd_hash(:video_piv)
                cmd_hash = @camera.get_set_params(full_cmd_hash)
                cmd_hash.shuffle! if @options[:shuffle] == true

                cmd_hash.each {|key, value|
                  set_tc_name("video_piv_#{key}")
                  test_set_and_get(:video_piv, @camera.video_piv, key, key, true)
                }
                piv_vars_tested = true
              end
            end
          end # fov
        end # FPS
      end # res
    end # video_mode (ntsc/pal)
  end # test_all_res_fps_fov

  def test_cc_params
    @camera.camera_capabilities().each { |cc|
      set_tc_name("camera_capabilities_#{cc}")
      act = (@camera.get_cc_status(cc) == 1)  # Map to T/F. 0 - false, 1 - true
      exp = @camera.get_capabilities[cc]
      if exp != act
        fail("Camera (cc) expect #{cc}=#{exp}, but receive #{cc}=#{act} from camera")
      else
        pass("Camera (cc) correctly advertises #{cc} support=#{exp}")
      end
    }
  end

  def get_takes_params?(sym)
    # The following commands use parameters in their GET command.
    get_takes_params = {
      :lcd_display => true
    }
    get_takes_params.default = false
    return get_takes_params[sym]
  end

  # Most commands only use parameters with the SET command,
  # but a few (like lc) use them with the GET command.  In that case
  # call with getwithparams=true
  def test_wifi_cmd_all_keys(i)

    failed_arr = []

    if @camera.remote_api_version == 1
      # Camera 'set' method expects the whole wifi command hash
      cmd_hash = @camera.method(i).call()
      cmd_name = @camera.method(i).name.to_s

      # Pull out the set, get, ret parameters
      log_info("cmd_name #{cmd_name}")
      keys = cmd_hash.keys()
      keys.shuffle! if @options[:shuffle]
      has_set_cmd = keys.delete(:set) != nil
      has_get_cmd = keys.delete(:get) != nil
      has_ret_cmd = keys.delete(:ret) != nil

      # First, the case for commands with no parameters
      msg = nil
      if keys.length == 0
        if has_set_cmd == true
          resp = @camera.set(i,nil,wait_time=0.5,has_ret_cmd, nil)
          failed_arr << "Unable to set #{k} in #{i}" if resp[:success] == false
        end

        if has_get_cmd == true
          resp = @camera.get(i,nil,wait_time=0.5,has_ret_cmd, nil)
          failed_arr << "Unable to get #{k} in #{i}" if resp[:success] == false
        end

      else keys.each { |k|
          set_tc_name("#{cmd_name}_#{k}")

          if has_set_cmd == true && has_get_cmd == true
            test_set_and_get(i, cmd_hash, k, k, has_ret_cmd)

          elsif has_set_cmd == true && has_get_cmd == false
            # In both cases 'expected'=k
            cmd_str = "Wi-Fi %s command '%s' (%s), key=%s, expect=%s (%s)" \
            %["SET", i, cmd_hash[:set], k, k, cmd_hash[k]]
            log_info("Testing #{cmd_str}")
            resp = @camera.set(i,k,wait_time=0.5, has_ret_cmd, k)
            failed_arr << "Unable to set #{k} in #{i}" if resp[:success] == false

          elsif has_get_cmd == true && has_set_cmd == false
            get_key = nil
            get_key = k if get_takes_params?(i)
            # expected is equal to the key
            cmd_str = "Wi-Fi %s command '%s' (%s), key=%s, expect=%s (%s)" \
            %["GET", i, cmd_hash[:get], k, k, cmd_hash[k]]
            log_info("Testing #{cmd_str}")
            resp = @camera.get(i,get_key,wait_time=0.5, has_ret_cmd, k)
            failed_arr << "Unable to get #{k} in #{i}" if resp[:success] == false
            failed_arr << msg if resp[:success] == false
          end

        }
      end
    end

    if @camera.remote_api_version == 2
      wifi_hash = @camera.setting[i]
      @camera.method(wifi_hash['method']).call().keys.each{ |k|
        log_info("Testing #{i} setting to #{k}")
        set_tc_name("#{i}_#{k}")
        test_set_and_get(i, nil, k, nil, nil)
        sleep 1
      }
    end

    log_info("All command keys passed") if !has_failure?(failed_arr)

  end

  def test_set_and_get(wifi_name, wifi_hash, key, expected, ret)
    # if wifi_name == :setup_video_format and @camera.name == "SILVER_PLUS"
    #   log_skip("ULU-116 Workaround")
    #   return
    # end

    failed_arr = []
    if @camera.remote_api_version == 1
      get_key = nil
      get_key = key if get_takes_params?(wifi_name) == true

      cmd_str = "Wi-Fi %s command '%s' (%s), key=%s, expect=%s (%s)" \
      %["SET", wifi_name, wifi_hash[:set], key, expected, wifi_hash[expected]]
      log_info("Testing #{cmd_str}")
      # Prototype: set(wifi_name, key=nil, wait_time=@wait_after_cmd,
      # decode=true, expected=nil, tries=3, interval=5, target="camera", get=false)
      resp = @camera.set(wifi_name, key, 1.0, ret, expected, 3, 5, "camera", false)
      # resp = @camera.set(wifi_name, key, wait_time=1.0, ret, expected)
      if resp.is_a?(Hash) == false or resp[:success] == false
        failed_arr << "Wi-Fi %s command '%s' (%s=>%s)" %["SET", wifi_name, wifi_hash[:set], expected]
      else
        # Trigger a camera 'sx' request as SMARTY would
        @camera.get_status(:ok)

        cmd_str = "Wi-Fi %s command '%s' (%s), key=%s, expect=%s (%s)" \
        %["GET", wifi_name, wifi_hash[:get], key, expected, wifi_hash[expected]]
        log_info("Testing #{cmd_str}")
        resp = @camera.get(wifi_name, get_key, wait_time=1.0, ret, expected)
        if resp == nil or resp[:success] == false
          failed_arr << "Wi-Fi %s command '%s' (%s=>%s)"  %["GET", wifi_name, wifi_hash[:get], expected]
        end

        sx_resp = @camera.get_status(wifi_name)

        if wifi_name == :preview_pv && expected == "ON"
          if sx_resp != 1
            failed_arr << "SX contains different setting %s. Expected 1. Detected %s" \
            %[wifi_name, sx_resp.upcase]
          end
        else
          if wifi_hash[expected].to_s.upcase != @camera.wifi_itohs(sx_resp).to_s.upcase
            failed_arr << "SX contains different setting %s. Expected %s. Detected %s" \
            %[wifi_name, wifi_hash[expected].to_s.upcase, sx_resp.to_s.upcase]
          end
        end
      end # end set resp == nil
    end # end remote_api_version == 1

    if @camera.remote_api_version == 2
      resp = @camera.set_api2(wifi_name, key)
      fail_str = nil
      if resp == nil
        fail_str = "Nil response for cmd=#{wifi_name}, key=#{key}"
      elsif resp[:success] != true
        fail_str = "Unable to set %s to %s. Expected %s. Detected %s." \
        %[wifi_name, key, resp[:expected], resp[:detected]]
      end
      failed_arr << fail_str if fail_str != nil
    end

    log_pass("#{wifi_name} #{key} passed") if !has_failure?(failed_arr)

  end

  def cleanup
    @host.kill_status_process() if @host
  end

end # end runtest

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :shuffle, :set_defaults, :logfile, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
