# test_hilight_tag.rb
# Tests the hilight tag function by capturing '--duration' seconds of
# video and tagging every '--tag_interval' seconds.
# The video files are left on the SD card for manual verification of
# the hilight tags.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require 'timeout'
require 'fileutils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()
    FileUtils.mkdir_p(@options[:save_dir]) if not File.directory?(@options[:save_dir])
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest()
    test_all_video_capture_modes
    test_tag_limit unless @options[:quick]
  end

  def test_all_video_capture_modes
    # Enumerate all the test combinations
    # Default for this test will be protune OFF only (set nil -> OFF explicitly)
    @options[:video_pt] = "OFF" if @options[:video_pt] != "ON"

    test_params = tu_get_video_res_with_protune()

    if test_params[0].empty? && test_params[1].empty?
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end

    # Now run each test
    tag_interval = (@options[:tag_interval] != nil) ?  \
    @options[:tag_interval].to_i : 3 # Seconds

    tc_total = test_params[0].length + test_params[1].length
    tc_count = 0

    test_params.flatten(1).each() { |params|
      next if params.empty?

      # Set duration (potentially randomly) for this test case.
      duration = (@options[:duration] != nil) ?  @options[:duration].to_i : 20 # Seconds
      if @options[:duration_range_low] and @options[:duration_range_high]
        duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
        log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
      end

      vm, res, fps, fov, ori, ll, spot, p, wb, co, sh, iso, ex = params

      # Add all relevant info to the test case name
      tc_name = "tag_hilight_every_#{tag_interval}s"
      tc_name += "_#{vm}_protune_#{p}"
      tc_name += "_spot_#{spot}" if spot
      tc_name += "_#{res}_#{fps}_#{fov}"
      tc_name += "_ori_#{ori}" if ori
      tc_name += "_low_light_#{ll}" if ll
      tc_name += "_#{wb}" if wb
      tc_name += "_#{co}" if co
      tc_name += "_#{sh}" if sh
      tc_name += "_#{iso}" if iso
      tc_name += "_#{ex}" if ex
      set_tc_name(tc_name)
      tc_count = tc_count + 1
      log_info("Running test #{tc_count} of #{tc_total}")

      begin
        # Actual duration will be longer due to padding
        exp_n_tags = (duration / tag_interval)
        ret, msg = tag_n_times(exp_n_tags, tag_interval, params)
        if ret == false
          fail(msg)
          next
        else
          act_tags = ret[ret.keys[0]]
        end

        # Verify number of tags
        failed_arr = []
        log_info("Expecting #{exp_n_tags} tags")
        log_info("Found tags: #{act_tags}")
        failed_arr << assert_equal(exp_n_tags, act_tags.length, "Number of tags")

        # Verify tags have expected values (0 < tag < duration)
        act_tags.each { |t|
          t_in_s = t / 1000.0
          if t_in_s <= 0 or t_in_s > ((exp_n_tags+4)*tag_interval*1.15)
            failed_arr << "Out of bounds tag: #{t_in_s}s"
          end
        }

        # Verify tags are sorted in ascending order
        t_prev = 0
        act_tags.each { |t|
          if t < t_prev
            failed_arr << "Tags are not in ascending order (t_prev=#{t_prev}, t=#{t})"
            break
          end
          t_prev = t
        }

        # Verify tags are within 1s of tag_interval apart
        t_prev = nil
        act_tags.each { |t|
          (t_prev = t; next) if t_prev == nil
          exp = tag_interval
          act = (t - t_prev) / 1000.0
          delta = 1.0
          failed_arr << assert_delta(exp, act, delta, "Tag interval >#{delta}s from exp.")
          t_prev = t
        }

        log_pass if !has_failure?(failed_arr)  # Will log a fail if it sees one
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    } # end test_params.each
  end

  def test_tag_limit
    tag_limit = @camera.hilight_tag_limit
    set_tc_name("test_#{tag_limit}_tag_limit")
    # Random capture parameters
    test_params = tu_get_video_res_with_protune().flatten(1).shuffle()[0]
    # Try to tag 1 beyond the limit (3 second interval)
    begin
      ret, msg = tag_n_times(tag_limit+1, 3, test_params)
      if ret == false
        fail(msg)
        return
      else
        tags_arr = ret[ret.keys[0]]
      end

      if tags_arr.length > tag_limit
        fail("# tags (#{tags_arr.length}) > tag limit (#{tag_limit})")
      elsif tags_arr.length < tag_limit
        fail("# number of tags too low (#{tags_arr.length} < #{tag_limit})")
      else
        pass("# tags == limit")
      end
    rescue WifiCameraError
      fail("Lost communication with camera")
      tu_reset_camera()
    rescue StandardError => e
      fail("General error: #{e.to_s}")
      puts e.backtrace.join("\n")
      tu_reset_camera()
    end
  end

  # Returns { File1 => tag_arr1, File2 => tag_arr2, ... } on success
  # Returns nil, msg on failure
  def tag_n_times(n, interval, test_params)
    duration = ((n+2) * interval * 1.15).to_i
    test_params = test_params[0..3] + [duration] + test_params[4..-1]

    @camera.delete_all_media()
    sleep(5.0)
    t_start = Time.now()
    ret, msg = false, "Waiting for thread"
    thr = Thread.new {
      ret, msg = @camera.capture_video(*test_params)
    }

    log_verb("Waiting for camera to set shutter on")
    begin
      timeout(30) {
        while true do
          (@camera.shutter_on? == true) ? break : (sleep 1)
        end
      }
    rescue Timeout::Error
      return false, "Timed out waiting for camera to start capture"
    end
    t1 = interval
    log_verb("Sleeping #{t1} seconds before starting to tag")
    sleep t1

    n_tags = 0
    begin
      while thr.alive? == true
        sleep interval
        log_info("Tagging hilight (n=#{n_tags+1}) every #{interval} seconds")
        tag_ret, tag_msg = @camera.tag_hilight()
        n_tags += 1
        break if n_tags == n
      end
      log_info("Waiting for capture to finish (~%0.1ds)" \
        %(duration - (Time.now() - t_start)))
      thr.join
    rescue WifiCameraError => e
      ret = false
      msg = e.message
    end
    (ret == false) ? (return ret, msg) : log_info(msg)

    media = @camera.get_medialist("MP4")
    if media == nil or media.empty?
      return false, "No media found"
    end

    # Check each MP4 file
    save_dir = @options[:save_dir]

    ret_tags = {}
    ranges = ["0-500000", "-2000000"] # First 500 kB and last 2000 kB.
    media.each { |m|
      url = @camera.get_media_url(m)
      tags_arr = nil
      ranges.each { |byte_range|
        ret = @host.curl(url, local=save_dir, overwrite=true, range=byte_range)
        (ret == false) ? (fail("Unable to get #{url}"); next) : log_info(ret)
        tags_arr = tu_read_hilight_tags(ret)
        break if tags_arr != nil
      }
      log_warn("Overwriting tags!") if ret_tags.has_key?(m)
      ret_tags[File.basename(m)] = tags_arr
    }
    #Check if list of tags is nil or if we have an empty tag
    if ret_tags == nil or ret.empty?
      return false, "Failed to get tags from media.  Curl error?"
    else
      return ret_tags
    end
  end

  def cleanup
    @host.kill_status_process() if @host
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only,
      :video_pt, :duration, :video_low_light, :tag_interval,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering,
      :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, :quick, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp/hilight" if options[:save_dir] == nil
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
