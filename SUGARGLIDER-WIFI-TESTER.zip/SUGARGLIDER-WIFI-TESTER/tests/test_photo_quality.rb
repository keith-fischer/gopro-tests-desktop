# test_photo_quality
# Tests the JPG 'quality' of each photo and checks that it
# is above the threshold set in the camera module.
#
# Ultimately a bug is only filed if the subjective image quality
# actually suffers, which may or may not be the case.
#
# Hero 3+/4/RKPT/HAL

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include Test_utils
  def intialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    set_options()
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def verify_single_photo()
    test_params = tu_get_photo_test_params()
    log_warn("No tests to run!  Check resolution chosen") if test_params == []
    log_info("Running #{test_params.length} tests")

    n = 0
    test_params.each { |photo_opts|
      log_info("Test #{n += 1} of #{test_params.length}")
      res, orient, spot, pt, wb, col, sh, iso, ex = photo_opts
      tc_name = "jpg_quality_single_%s_%s_spot_%s" %[res, orient, spot]
      tc_name += "_pt_#{pt}"    if pt != nil
      tc_name += "_wb_#{wb}"    if wb != nil
      tc_name += "_col_#{col}"  if col != nil
      tc_name += "_sh_#{sh}"    if sh != nil
      tc_name += "_iso_#{iso}"  if iso != nil
      tc_name += "_ex_#{ex}"    if ex != nil
      set_tc_name(tc_name)

      @camera.delete_all_media()
      sleep(5.0)

      ret, msg = @camera.capture_photo_single(*photo_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], photo_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      ret, msg = @camera.download_all_media(save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      exp_q = @camera.photo_modes[res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    }
  end # verify_single_photo

  def verify_continuous_photo()
    test_params = tu_get_photo_continuous_test_params()
    log_warn("No tests to run!  Check resolution chosen") if test_params == []
    log_info("Running #{test_params.length} tests")

    n = 0
    test_params.each { |photo_opts|
      log_info("Test #{n += 1} of #{test_params.length}")
      res, sps, orient, spot, pt, wb, col, sh, iso, ex = photo_opts
      tc_name = "jpg_quality_%s_continuous_%s_%s_spot_%s" %[res, sps, orient, spot]
      tc_name += "_pt_#{pt}"    if pt != nil
      tc_name += "_wb_#{wb}"    if wb != nil
      tc_name += "_col_#{col}"  if col != nil
      tc_name += "_sh_#{sh}"    if sh != nil
      tc_name += "_iso_#{iso}"  if iso != nil
      tc_name += "_ex_#{ex}"    if ex != nil
      set_tc_name(tc_name)

      @camera.delete_all_media()
      sleep(5.0)

      duration = 3
      photo_opts = photo_opts[0..1] + [duration] + photo_opts[2..-1]
      ret, msg = @camera.capture_photo_continuous(*photo_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], photo_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      ret, msg = @camera.download_all_media(save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      exp_q = @camera.photo_modes[res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    }
  end # verify_continuous_photo

  def verify_piv_photo()
    already_tested = []
    video_params = tu_get_piv_res()

    n = 0
    video_params.each { |video_opts|
      vm, res, fps, fov, piv, orient, ll, spot = video_opts
      next if already_tested.include?(piv)
      already_tested << piv
      tc_name = "jpg_quality_piv_interval_%s" %[piv]
      set_tc_name(tc_name)

      @camera.delete_all_media()
      sleep(5.0)

      duration = piv.to_f * 1.1 + 5
      video_opts = video_opts[0..4] + [duration] + video_opts[5..-1]
      ret, msg = @camera.capture_piv(*video_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], video_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      media = @camera.get_medialist("JPG")

      # Save it
      media.each { |m|
        ret, msg = @camera.download_media(m, save_dir)
        (ret == false) ? (fail(msg); next) : log_info(msg)
      }

      # Not really a category for these photo resolutions so just get exp from first available
      photo_res = @camera.get_photo_resolutions()[0]
      exp_q = @camera.photo_modes[photo_res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    }
  end # verify_piv_photo

  def verify_night_photo()
    test_params = tu_get_photo_night_test_params()
    log_warn("No tests to run!  Check resolution chosen") if test_params == []
    log_info("Running #{test_params.length} tests")

    n = 0
    test_params.each { |photo_opts|
      log_info("Test #{n += 1} of #{test_params.length}")
      res, orient, spot, se, pt, wb, col, sh, iso, ex = photo_opts
      tc_name = "jpg_quality_night_photo_%s_%s_spot_%s" %[res, orient, spot]
      tc_name += "_se_#{se}"    if se != nil
      tc_name += "_pt_#{pt}"    if pt != nil
      tc_name += "_wb_#{wb}"    if wb != nil
      tc_name += "_col_#{col}"  if col != nil
      tc_name += "_sh_#{sh}"    if sh != nil
      tc_name += "_iso_#{iso}"  if iso != nil
      tc_name += "_ex_#{ex}"    if ex != nil
      set_tc_name(tc_name)

      @camera.delete_all_media()
      sleep(5.0)

      duration = se.to_i * 1.1 + 5 # Sleeping longer than the shutter exposure value
      # Need to insert 'duration' into argument array at index 1
      photo_opts = [photo_opts[0]] + [duration] + photo_opts[1..-1]
      ret, msg = @camera.capture_photo_night(*photo_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], photo_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      ret, msg = @camera.download_all_media(save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      exp_q = @camera.photo_modes[res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    }
  end # verify_single_photo

  def verify_burst()
    test_params = tu_get_multi_photo_burst_test_params()
    log_warn("No tests to run!  Check resolution chosen") if test_params == []
    log_info("Running #{test_params.length} tests")

    n = 0
    test_params.each { |photo_opts|
      log_info("Test #{n += 1} of #{test_params.length}")
      res, bu, orient, spot, pt, wb, col, sh, iso, ex = photo_opts
      tc_name = "jpg_quality_%s_burst_%s_%s_spot_%s" %[res, bu, orient, spot]
      tc_name += "_pt_#{pt}"    if pt != nil
      tc_name += "_wb_#{wb}"    if wb != nil
      tc_name += "_col_#{col}"  if col != nil
      tc_name += "_sh_#{sh}"    if sh != nil
      tc_name += "_iso_#{iso}"  if iso != nil
      tc_name += "_ex_#{ex}"    if ex != nil
      set_tc_name(tc_name)
      @camera.delete_all_media
      sleep 5.0

      ret, msg = @camera.capture_multi_photo_burst(*photo_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], photo_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      ret, msg = @camera.download_all_media(save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      exp_q = @camera.photo_modes[res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    } # test_params.each
  end # verify_burst

  def verify_timelapse()
    test_params = tu_get_multi_photo_timelapse_test_params()
    log_warn("No tests to run!  Check resolution chosen") if test_params == []
    log_info("Running #{test_params.length} tests")

    n = 0
    test_params.each { |photo_opts|
      log_info("Test #{n += 1} of #{test_params.length}")
      res, pes, orient, spot, pt, wb, col, sh, iso, ex = photo_opts
      tc_name = "jpg_quality_%s_timelapse_%s_%s_spot_%s" %[res, pes, orient, spot]
      tc_name += "_pt_#{pt}"    if pt != nil
      tc_name += "_wb_#{wb}"    if wb != nil
      tc_name += "_col_#{col}"  if col != nil
      tc_name += "_sh_#{sh}"    if sh != nil
      tc_name += "_iso_#{iso}"  if iso != nil
      tc_name += "_ex_#{ex}"    if ex != nil
      set_tc_name(tc_name)
      @camera.delete_all_media
      sleep 5.0

      duration = pes.to_f * 2.1
      # Need to insert 'duration' into argument array at index 2.
      photo_opts = photo_opts[0..1] + [duration] + photo_opts[2..-1]
      ret, msg = @camera.capture_multi_photo_timelapse(*photo_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], photo_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      ret, msg = @camera.download_all_media(save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      exp_q = @camera.photo_modes[res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    } # test_params.each
  end # timelapse

  def verify_nightlapse()
    test_params = tu_get_multi_photo_nightlapse_test_params()
    log_warn("No tests to run!  Check resolution chosen") if test_params == []
    log_info("Running #{test_params.length} tests")

    n = 0
    test_params.each { |photo_opts|
      log_info("Test #{n += 1} of #{test_params.length}")
      res, pes, orient, spot, se, pt, wb, col, sh, iso, ex = photo_opts
      tc_name = "jpg_quality_%s_nightlapse_%s_%s_spot_%s" %[res, pes, orient, spot]
      tc_name += "_se_#{se}"    if se != nil
      tc_name += "_pt_#{pt}"    if pt != nil      
      tc_name += "_wb_#{wb}"    if wb != nil
      tc_name += "_col_#{col}"  if col != nil
      tc_name += "_sh_#{sh}"    if sh != nil
      tc_name += "_iso_#{iso}"  if iso != nil
      tc_name += "_ex_#{ex}"    if ex != nil
      set_tc_name(tc_name)

      # Nightlapse has some LOOONG intervals.
      # Skip anything >= 30mins unless run with FULL flag
      if @options[:full] != true and pes.to_i >= 1800
        log_skip("Skipping intervals > 30 minutes.  Run with '--full' to enable.")
        next
      end

      @camera.delete_all_media
      sleep 5.0
      duration = pes.to_f * 2.1
      # Need to insert 'duration' into argument array at index 2.
      photo_opts = photo_opts[0..1] + [duration] + photo_opts[2..-1]
      ret, msg = @camera.capture_multi_photo_nightlapse(*photo_opts)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      save_dir = File.join(@options[:save_dir], photo_opts.join("-"))
      FileUtils::rm_rf(save_dir) if File.directory?(save_dir)
      ret, msg = @camera.download_all_media(save_dir)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      exp_q = @camera.photo_modes[res][:min_quality]
      all_files = Dir.glob(File.join(save_dir, "**", "*.JPG"))
      failed_arr = []
      all_files.each { |f|
        act_q = @host.get_quality(f)
        failed_arr << assert(act_q >= exp_q, "JPG quality (#{act_q} < #{exp_q})")
      }
      pass("All files JPG quality > #{exp_q}") if not has_failure?(failed_arr)
    } # test_params.each
  end # timelapse

  def runtest
    verify_single_photo()
    verify_continuous_photo() if @camera.photo_continuous_support? == true
    verify_piv_photo() if @camera.video_piv_support? == true
    verify_night_photo() if @camera.photo_night_support? == true
    verify_burst()
    verify_timelapse()
    verify_nightlapse() if @camera.multi_photo_nightlapse_support? == true
  end

  def cleanup
    @host.kill_status_process() if @host
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :save_dir,
      :photo_single, :photo_resolution,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :photo_spot_metering, :setup_orientation,
      :save_dir, :shuffle, :verb, :full]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
