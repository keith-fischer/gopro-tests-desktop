# test_media_list.rb

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file} setup")
    @host = Host.new
    @camera = tu_get_camera()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options() if @camera.interfaces.include?(:wifi)
    @seed = options[:seed]
    @seed = srand >> 100 if (@seed == nil or @seed == false)
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    log_info("Using seed: #{@seed}")
    tests = [
      :test_video,
      :test_video_piv,
      :test_video_timelapse,
      :test_video_looping,
      :test_single_photo,
      :test_photo_night,
      :test_sps,
      :test_burst,
      :test_time_lapse,
      :test_photo_nightlapse
    ]

    tests.shuffle!(random: Random.new(@seed))
    srand @seed

    tests.each() {|t|
      method(t).call()
    }

    test_empty_card
    test_delete_video_chapters()
    test_delete_video_looping_chapters()
  end

  def test_empty_card()
    return if @camera.remote_api_version() != 1

    @camera.delete_all_media()
    sleep 3
    set_tc_name("empty_sd_card_delete_last")
    ret, msg = del_last
    if ret == false
      pass("DL correctly failed on empty card")
    else
      fail("DL was successful on empty card")
    end

    set_tc_name("empty_sd_card_delete_file_fake_param")
    f = "100GOPRO/HOPR0001.JPG"
    ret, msg = del_file(f)
    if ret == false
      pass("(DF, p='#{f}') correctly failed on empty card")
    else
      fail("(DF, p='#{f}') was successful on empty card")
    end
    # No delete group because it is deprecated
  end

  def test_video()

    all_res = tu_get_video_res_with_protune[0]
    vm, res, fps, fov, orient, ll, spot, pt, wb, co, sh, iso, ex = all_res[Random.rand(all_res.length)]

    set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_delete_last")
    @camera.delete_all_media()
    3.times() {
      ret, msg = @camera.capture_video(vm, res, fps, fov, 5)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_delete_file")
    test_delete_file()
  end

  def test_video_piv()
    return if !@camera.video_piv_support?

    all_res = tu_get_piv_res()
    vm, res, fps, fov, piv, orient, ll, spot = all_res[Random.rand(all_res.length())]

    duration = (piv.to_i * 2) + 2

    set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_piv_#{piv}_delete_last")
    @camera.delete_all_media()
    2.times() {
      ret, msg = @camera.capture_piv(vm, res, fps, fov, piv, duration)
      (ret == false) ? fail(msg): log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_piv_#{piv}_delete_file")
    test_delete_file()
  end

  def test_video_timelapse()
    return if !@camera.video_timelapse_support?()

    all_res = tu_get_video_timelapse_res
    all_res.delete_if { |vm, res, pes| pes.to_i >= 10 }
    vm, res, fov, pes = all_res[Random.rand(all_res.length())]

    duration = ((30 * pes.to_f) * 2).to_i #get 2sec video

    set_tc_name("#{vm}_#{res}_video_timelapse_#{pes}_delete_last")
    @camera.delete_all_media()
    2.times() {
      ret, msg = @camera.capture_video_timelapse(vm, res, fov, pes, duration)
      (ret == false) ? fail(msg): log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{vm}_#{res}_video_timelapse_#{pes}_delete_file")
    test_delete_file()
  end

  def test_video_looping()
    return if !@camera.video_looping_support?()

    all_res = tu_get_looping_res
    # We need to limit the looping times to ones that any SD card can handle.
    all_res.delete_if { |vm, res, fps, fov, loo| loo == "MAX" or loo.to_i > 30 }
    vm, res, fps, fov, loo, orient, ll, spot = all_res[Random.rand(all_res.length)]

    set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_video_looping_#{loo}_delete_last")
    @camera.delete_all_media()
    3.times() {
      # The 5 is duration. The false is for setonly.
      ret, msg = @camera.capture_looping(vm, res, fps, fov, loo, 5, false, orient, ll, spot)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_video_looping_#{loo}_delete_file")
    test_delete_file()
  end # test_video_looping

  # Captures 4 minutes of a 5 minute looping video
  # Test that deleting the first, last, and third file does not cause the
  # rest of the chapters to also be deleted
  def test_delete_video_looping_chapters()
    return if !@camera.video_looping_support?()
    set_tc_name("delete_first_last_third_looping_chapter")
    @camera.delete_all_media()

    all_modes = tu_get_looping_res
    params = all_modes[Random.rand(all_modes.length)] # Pick a capture mode
    loo = "5"
    dur = 4 * 60 + 10
    params = params[0..3] + [loo, dur, false] + params[5..-1]
    ret, msg = @camera.capture_looping(*params)
    (ret == false) ? (fail(msg); return) : log_info(msg)

    act_files = @camera.get_medialist()
    status_n_videos = @camera.get_status(:videos_on_card)
    status_n_photos = @camera.get_status(:photos_on_card)
    f1, f2, f3, f4 = act_files

    [f1, f4, f3].each { |f|
      log_info("Files before delete: #{act_files}")
      log_info("Deleting #{f}")
      del_file(f)
      exp_files = act_files - [f]
      act_files = @camera.get_medialist()
      if  exp_files != act_files
        fail("Only #{f} should have been deleted. Contents: #{act_files}")
        return
      end
    }
    pass("Only specified file was deleted each time (first, last, third)")
  end

  # Captures 2 chapters of video
  # Test that deleting the first does not cause the second to be deleted
  def test_delete_video_chapters()
    return if !@camera.video_looping_support?()
    (fail("Camera is missing @chapter_size"); return) if @camera.chapter_size == nil
    set_tc_name("delete_first_video_chapter")
    @camera.delete_all_media()

    all_modes = tu_get_video_res_with_protune.flatten(1)
    params = all_modes[Random.rand(all_modes.length)] # Pick a capture mode
    res, fps, p = params[1], params[2], params[7]
    chap_len = (@camera.chapter_size * 8) / (1000000 * @camera.get_bitrate(res, fps, p))
    dur = (chap_len + 150).to_i # creates 2 chapters

    #DEBUG code for HML-54 ~RodT
=begin
    # chapter_size is in bytes, *8 is in bits
    # bit_rate is in MB, *1000000 is in bits, 27.5 * 1000000 = 27,500,000 bits/s
    # EXAMPLE chapter_size==2.2GB  2,147,483,648 
    # chap_len= (chap_sz* 8) == 17,179,869,184 bits / 27,500,000 bits/s = 624 seconds
    # chap_len is aggregates  of seconds
    # dur = ((chap_len*2) + 150).to_i # creates 3 chapters #HML-54 test code - Create 3 chapters instead of 2
    chap_sz = @camera.chapter_size
    bitrate =  @camera.get_bitrate(res, fps, p)
    all_mode_len = all_modes.length
    log_info("DEBUG: res=#{res} fps=#{fps} p={p}")
    log_info("DEBUG: chap_sz=#{chap_sz}")
    log_info("DEBUG: chap_len=#{chap_len}")
    log_info("DEBUG: bitrate=#{bitrate}")
    log_info("DEBUG: all_mode_len=#{all_mode_len}")
    log_info("DEBUG: dur=#{dur}")
=end
    #DEBUG (end of debug code ~RodT) (Please remove if/when no longer needed -TF)

    params = params[0..3] + [dur] + params[4..-1]
    log_info("Capturing %02d:%02d length video" %[(dur/60), (dur%60)])
    ret, msg = @camera.capture_video(*params)
    (ret == false) ? (fail(msg); return) : log_info(msg)

    act_files = @camera.get_medialist()
    f1 = act_files[0]
    log_info("Files before delete: #{act_files}")
    log_info("Deleting #{f1}")
    del_file(f1)
    exp_files = act_files - [f1]
    act_files = @camera.get_medialist()
    log_info("Files AFTER delete: #{act_files}")
    if  exp_files != act_files
      act_files = @camera.get_medialist()
      fail("Only #{f1} should have been deleted. Contents: #{act_files}")
      return
    end
    pass("Only the first file deleted (correct)")
  end

  def test_single_photo()

    res = @camera.get_photo_resolutions()[Random.rand(@camera.get_photo_resolutions().length)]

    set_tc_name("#{res}_photo_single_delete_last")
    @camera.delete_all_media()
    3.times(){
      ret, msg = @camera.capture_photo_single(res)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{res}_photo_single_delete_file")
    test_delete_file()

  end #  end test_single_photo

  def test_sps()
    return if !@camera.photo_continuous_support?

    res = @camera.get_photo_resolutions()[Random.rand(@camera.get_photo_resolutions().length)]
    sps = @camera.get_photo_continuous_rates(res)[Random.rand(@camera.get_photo_continuous_rates(res).length())]

    set_tc_name("#{res}_sps_#{sps}_delete_last")
    @camera.delete_all_media()
    3.times {
      ret, msg = @camera.capture_photo_continuous(res, sps, 3)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{res}_sps_#{sps}_delete_file")
    test_delete_file()

    set_tc_name("#{res}_sps_#{sps}_group_indexing")
    @camera.delete_all_media()
    ret, msg = @camera.capture_photo_continuous(res, sps, 3)
    (ret == false) ? fail(msg) : log_info(msg)
    test_group_indexing()

  end # end test_sps

  def test_burst()

    res = @camera.get_photo_resolutions()[Random.rand(@camera.get_photo_resolutions().length)]
    burst = @camera.get_multi_photo_burst_rates(res)[Random.rand(@camera.get_multi_photo_burst_rates(res).length)]

    set_tc_name("#{res}_burst_#{burst}_delete_last")
    @camera.delete_all_media()
    2.times {
      ret, msg = @camera.capture_multi_photo_burst(res, burst)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{res}_burst_#{burst}_delete_file")
    test_delete_file()

    set_tc_name("#{res}_burst_#{burst}_group_indexing")
    @camera.delete_all_media()
    ret, msg = @camera.capture_multi_photo_burst(res, burst)
    (ret == false) ? fail(msg) : log_info(msg)
    test_group_indexing()
  end

  def test_time_lapse()

    res = @camera.get_photo_resolutions()[Random.rand(@camera.get_photo_resolutions().length)]
    pes = @camera.get_multi_photo_timelapse_rates(res)[Random.rand(@camera.get_multi_photo_timelapse_rates(res).length)]

    min_photos = @options[:min_pes_pho].to_i
    duration = ((pes.to_f * min_photos) + 2).to_i

    set_tc_name("#{res}_time_lapse_#{pes}_delete_last")
    @camera.delete_all_media()
    2.times {
      ret, msg = @camera.capture_multi_photo_timelapse(res, pes, duration)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{res}_time_lapse_#{pes}_delete_file")
    test_delete_file()

    set_tc_name("#{res}_time_lapse_#{pes}_group_indexing")
    @camera.delete_all_media()
    ret, msg = @camera.capture_multi_photo_timelapse(res, pes, duration)
    (ret == false) ? fail(msg) : log_info(msg)
    test_group_indexing()

  end

  def test_photo_night
    return if !@camera.photo_night_support?()

    all_res = tu_get_photo_night_test_params
    res, orient, spot, se, pt, wb, col, sh, iso, ex = all_res[Random.rand(all_res.length())]

    if se == "AUTO"
      duration = 5
    else
      duration = se.to_i + 1
    end

    set_tc_name("#{res}_shutter_#{se}_photo_night_delete_last")
    @camera.delete_all_media()
    3.times() {
      ret, msg = @camera.capture_photo_night(res, duration, nil, nil, se)
      (ret == false) ? (fail(msg)) : log_info(msg)
    }
    test_delete_last()

    set_tc_name("#{res}_shutter_#{se}_photo_night_delete_file")
    test_delete_file()

  end

  def test_photo_nightlapse
    return if !@camera.multi_photo_nightlapse_support?()

    res = @camera.get_photo_resolutions[Random.rand(@camera.get_photo_resolutions().length)]

    rates = @camera.get_multi_photo_nightlapse_rates(res)

    # Skip the longest ones
    rates.delete("300") if rates.include?("300")
    rates.delete("1800") if rates.include?("1800")
    rates.delete("3600") if rates.include?("3600")

    pes = rates[Random.rand(@camera.get_multi_photo_nightlapse_rates(res).length() - 2)]

    # Need to take at least 3 photos.
    min_photos = [3, @options[:min_pes_pho].to_i].max

    if pes == "CONTINUOUS"
      duration = 5
    else
      duration = ((pes.to_f * min_photos) + 2).to_i
    end

    set_tc_name("#{res}_night_lapse_#{pes}_delete_last")
    @camera.delete_all_media()
    2.times() {
      ret, msg = @camera.capture_multi_photo_nightlapse(res, pes, duration)
      (ret == false) ? fail(msg) : log_info(msg)
    }
    test_delete_last()
    sleep(2.0)

    set_tc_name("#{res}_night_lapse_#{pes}_delete_file")
    test_delete_file()
    sleep(2.0)

    set_tc_name("#{res}_night_lapse_#{pes}_group_indexing")
    @camera.delete_all_media()
    ret, msg = @camera.capture_multi_photo_nightlapse(res, pes, duration)
    (ret == false) ? (fail(msg)) : log_info(msg)
    test_group_indexing()
  end

  # Delete last
  def test_delete_last()
    sleep 2
    all_files = @camera.get_medialist()
    status_n_videos = @camera.get_status(:videos_on_card)
    status_n_photos = @camera.get_status(:photos_on_card)
    failed_arr = []
    failed_arr << assert(all_files.length > 0, "No files found on card")
    failed_arr << assert_equal(all_files.length, status_n_photos + status_n_videos,
    "# files on card != # reported by camera status")

    if all_files.length > 0
      last_file = all_files[-1]
      prefix = File.basename(last_file)[0..3]
      if prefix == "GOPR"
        # Individual file
        exp_len = all_files.length - 1
      else
        # File is part of the following group, which will be deleted
        d_files = all_files.map { |f| f if File.basename(f)[0..3] == prefix }
        d_files.compact!
        exp_len = all_files.length - d_files.length
      end

      ret, msg = del_last()
      if ret == false
        failed_arr << msg
        return failed_arr
      end
      # Only add if necessary
      ## Trigger updates to camera status
      #@camera.set_capture_mode("PHOTO")
      #sleep 5
      #@camera.set_capture_mode("VIDEO")

      all_files = @camera.get_medialist()
      act_len = all_files.length
      status_n_videos = @camera.get_status(:videos_on_card)
      status_n_photos = @camera.get_status(:photos_on_card)
      failed_arr << assert( ! all_files.include?(last_file))
      failed_arr << assert_equal(exp_len, act_len, "Unexpected # files (#{act_len})")
      failed_arr << assert_equal(all_files.length, status_n_photos + status_n_videos,
      "# files on card != # reported by camera status")
      return if has_failure?(failed_arr)
      pass()
    else
      log_skip("No files on card! Skipping delete_last")
    end
  end

  # Delete file
  def test_delete_file()
    all_files = @camera.get_medialist()
    status_n_videos = @camera.get_status(:videos_on_card)
    status_n_photos = @camera.get_status(:photos_on_card)
    failed_arr = []
    failed_arr << assert(all_files.length > 0, "No files found on card")
    failed_arr << assert_equal(all_files.length, status_n_photos + status_n_videos,
    "# files on card != # reported by camera status")
    if all_files.length > 0
      random_file = all_files[Random.rand(all_files.length)]
      exp_len = all_files.length - 1
      ret, msg = del_file(random_file)
      sleep 2
      if ret == false
        failed_arr << msg
        return failed_arr
      end

      # Only add if necessary
      # Trigger updates to camera status
      #@camera.set_capture_mode("PHOTO")
      #sleep 5
      #@camera.set_capture_mode("VIDEO")

      all_files = @camera.get_medialist()
      act_len = all_files.length
      status_n_videos = @camera.get_status(:videos_on_card)
      status_n_photos = @camera.get_status(:photos_on_card)
      failed_arr << assert( ! all_files.include?(random_file))
      failed_arr << assert_equal(exp_len, act_len, "Unexpected # files (#{act_len})")
      failed_arr << assert_equal(all_files.length, status_n_photos + status_n_videos,
      "# files on card != # reported by camera status")
      pass("Deleted #{random_file} successfully") if !has_failure?(failed_arr)

    else
      log_skip("No files on card! Skipping delete_last")
    end
  end

  # Delete group
  def test_delete_group()
    all_files = @camera.get_medialist()
    status_n_photos = @camera.get_status(:photos_on_card)
    failed_arr = []
    failed_arr << assert(all_files.length > 0, "No files found on card")
    failed_arr << assert_equal(all_files.length, status_n_photos, "# card != # status")
    if all_files.length > 0
      random_file = all_files[Random.rand(all_files.length)]
      exp_len = 0
      ret, msg = del_group(random_file)
      if ret == false
        failed_arr << msg
        return failed_arr
      end
      # Trigger updates to camera status
      #@camera.set_capture_mode("PHOTO")
      #@camera.set_capture_mode("VIDEO")

      all_files = @camera.get_medialist()
      act_len = all_files.length
      status_n_photos = @camera.get_status(:photos_on_card)
      failed_arr << assert_equal(exp_len, act_len, "Unexpected # files (#{act_len})")
      failed_arr << assert_equal(act_len, status_n_photos, "# card != # status")
      return if has_failure?(failed_arr)
      pass("Deleted #{random_file} successfully")
    else
      log_skip("No files on card! Skipping delete_last")
    end
  end

  # Given some group of files, test that deleting doesn't ruin the indexes
  # Delete the first file --> group start += 1
  # Delete the last file --> group end -= 1
  # Delete middle files --> 'missing' array is populated
  def test_group_indexing()
    # dir, name, size, group, begin, last, type, missing
    d, n, s, g, b, l, t, m = parse_group_media()

    if d == nil
      log_skip("Problem in parse_group_media.  Empty card?")
      return
    end

    # Delete the beginning file (i.e. 'n')
    failed_arr = []
    f = File.join(d, n)
    del_file(f)
    sleep(1)
    # Expected results: n++, g == true, b++, l == l, m == []
    prefix, ext = n.split(".")
    file = prefix[0..-((b+1).to_s.length + 1)] + (b+1).to_s
    exp_n = "#{file}.#{ext}"
    exp_g = true
    exp_b = b + 1
    exp_l = l
    exp_m = []
    d, n, s, g, b, l, t, m = parse_group_media()

    log_info("Deleting begin of file")
    failed_arr << assert_equal(exp_n, n, "Filename #{n} != #{exp_n}")
    failed_arr << assert_equal(exp_g, g, "Group? #{g} != #{exp_g}")
    failed_arr << assert_equal(exp_b, b, "Begin file #{b} != #{exp_b}")
    failed_arr << assert_equal(exp_l, l, "Last file #{l} != #{exp_l}")
    failed_arr << assert_equal(exp_m, m, "Missing #{m} != #{exp_m}")
    has_failure?(failed_arr)

    # Delete the last file
    prefix, ext = n.split(".")
    file = prefix[0..-(l.to_s.length + 1)] + l.to_s
    f = File.join(d, "#{file}.#{ext}")
    del_file(f)
    sleep(1)
    # Expected results: n == n, g == true, b == b, l -= 1, m == []
    exp_n = n
    exp_g = true
    exp_b = b
    exp_l = l - 1
    exp_m = []
    d, n, s, g, b, l, t, m = parse_group_media()

    log_info("Deleting last file")
    failed_arr << assert_equal(exp_n, n, "Filename #{n} != #{exp_n}")
    failed_arr << assert_equal(exp_g, g, "Group? #{g} != #{exp_g}")
    failed_arr << assert_equal(exp_b, b, "Begin file #{b} != #{exp_b}")
    failed_arr << assert_equal(exp_l, l, "Last file #{l} != #{exp_l}")
    failed_arr << assert_equal(exp_m, m, "Missing #{m} != #{exp_m}")
    has_failure?(failed_arr)

    # Randomly delete body files
    del_order = ((b+1)..(l-1)).to_a.shuffle
    prefix, ext = n.split(".")
    del_order.each { |num|
      file = prefix[0..-(num.to_s.length + 1)] + num.to_s
      f = File.join(d, "#{file}.#{ext}")
      del_file(f)
      sleep(1)
      # Expected results: n == n, g == true, b == b, l -= 1, m << num
      exp_n = n
      exp_g = true
      exp_b = b
      exp_l = l
      exp_m = m << num.to_s
      d, n, s, g, b, l, t, m = parse_group_media()

      log_info("Deleting middle file")
      failed_arr << assert_equal(exp_n, n, "Filename #{n} != #{exp_n}")
      failed_arr << assert_equal(exp_g, g, "Group? #{g} != #{exp_g}")
      failed_arr << assert_equal(exp_b, b, "Begin file #{b} != #{exp_b}")
      failed_arr << assert_equal(exp_l, l, "Last file #{l} != #{exp_l}")
      failed_arr << assert_equal(exp_m.sort, m.sort, "Missing #{m} != #{exp_m}")
      has_failure?(failed_arr)
    }

    pass() if !has_failure?(failed_arr)
  end # end test_group_indexing

  def parse_group_media()
    parsed = @camera.get_parsed_gpmedialist()

    dir = name = size = nil
    group = first = last = miss = nil

    parsed["media"].each do |folder|
      d = folder["d"]
      folder["fs"].each do |f|
        n = f["n"]
        s = f["s"].to_i
        if f["g"] == nil
          log_warn("Unable to find file group in folder #{f}")
          return nil
        end
        g = (f["g"] == nil) ? false : true
        b = f["b"].to_i
        l = f["l"].to_i
        t = f["t"]
        m = f["m"]
        media_str = "dir=%s, name=%s, size=%s, group=%s, " %[d, n, s, g]
        media_str += "begin=%s, last=%s, type=%s, miss=%s" %[b, l, t, m]
        log_verb(media_str)
        return d, n, s, g, b, l, t, m
      end # f
    end
    return nil
  end

  def del_file(f)
    resp = @camera.delete_single_file(f)
    if not @camera.http_resp_ok(resp)
      return false, "Bad HTTP response"
    end
    return true, "Command successful"
  end

  # Any file from the group may be used and the whole group should be deleted
  def del_group(g)
    resp = @camera.delete_single_group(g)
    if not @camera.http_resp_ok(resp)
      return false, "Bad HTTP response"
    end
    return true, "Command successful"
  end

  def del_last()
    resp = @camera.delete_last_file()
    if not @camera.http_resp_ok(resp)
      return false, "Bad HTTP response"
    end
    return true, "Command successful"
  end

  def cleanup
    @host.kill_status_process() if @host
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov,
      :photo_resolution, :photo_continuous,
      :multi_photo_burst, :multi_photo_timelapse,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :setup_orientation,
      :shuffle, :set_defaults, :dryrun, :verb]

    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
