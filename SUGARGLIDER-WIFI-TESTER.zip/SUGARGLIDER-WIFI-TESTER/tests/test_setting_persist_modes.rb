# test_media_list.rb

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require 'set'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setups_tc_name
    @is_power_test = false
    "#{@test_file} setup"
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name(setups_tc_name)
    @host = Host.new
    @camera = tu_get_camera()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    # set_options()
    # @seed = options[:seed]
    # @seed = srand >> 100 if (@seed == nil or @seed == false)
    @seed = 90210 # Hard-coded seed for now.  We want repeatability on this one I think.
    srand @seed
    log_info("Using seed: #{@seed}")
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    # Get the array of Parameters objects for each camera mode
    # Modes not supported by a certain camera model will return []
    log_info("Selecting parameter sets for each mode")
    all_vid_params = get_param_set("VIDEO")
    log_verb("VIDEO MODES: #{all_vid_params.to_s}")
    all_loop_params = get_param_set("VIDEO_LOOPING")
    log_verb("VIDEO_LOOPING MODES: #{all_loop_params.to_s}")

    all_photo_single_params = get_param_set("PHOTO")
    log_verb("PHOTO_MODES: #{all_photo_single_params.to_s}")
    all_photo_cont_params = get_param_set("PHOTO_CONTINUOUS")
    log_verb("CONTINUOUS_MODES: #{all_photo_cont_params.to_s}")
    all_photo_night_params = get_param_set("PHOTO_NIGHT")
    log_verb("NIGHT_PHOTO_MODES: #{all_photo_night_params.to_s}")

    all_burst_params = get_param_set("BURST")
    log_verb("BURST_MODES: #{all_burst_params.to_s}")
    all_tlapse_params = get_param_set("TIMELAPSE")
    log_verb("TIMELAPSE_MODES: #{all_tlapse_params.to_s}")
    all_nlapse_params = get_param_set("NIGHTLAPSE")
    log_verb("NIGHTLAPSE_MODES: #{all_nlapse_params.to_s}")

    n_vid = all_vid_params.length
    n_loo = all_loop_params.length
    n_sin = all_photo_single_params.length
    n_con = all_photo_cont_params.length
    n_nht = all_photo_night_params.length
    n_bur = all_burst_params.length
    n_tla = all_tlapse_params.length
    n_nla = all_nlapse_params.length
    n = [n_vid, n_loo, n_sin, n_con, n_nht, n_bur, n_tla, n_nla].max

    ###
    # We are only testing NTSC
    ###
    @camera.set_video_format("NTSC")

    # Loop through the parameter sets for each mode -- set then check them
    # Since lengths are different, take the index (idx) % length
    # so shorter parameter sets will just loop.
    # Parameters sets will not be checked the second time around
    (0...n).each { |idx|
      if n_vid > 0
        vid_params = all_vid_params[(idx % n_vid)]
        set_params(vid_params)
      end
      if n_loo > 0
        loop_params = all_loop_params[(idx % n_loo)]
        set_params(loop_params)
      end
      if n_sin > 0
        photo_single_params = all_photo_single_params[(idx % n_sin)]
        set_params(photo_single_params)
      end
      if n_con > 0
        photo_cont_params = all_photo_cont_params[(idx % n_con)]
        set_params(photo_cont_params)
      end
      if n_nht > 0
        photo_night_params = all_photo_night_params[(idx % n_nht)]
        set_params(photo_night_params)
      end
      if n_bur > 0
        burst_params = all_burst_params[(idx % n_bur)]
        set_params(burst_params)
      end
      if n_tla > 0
        tlapse_params = all_tlapse_params[(idx % n_tla)]
        set_params(tlapse_params)
      end
      if n_nht > 0
        nlapse_params = all_nlapse_params[(idx % n_nht)]
        set_params(nlapse_params)
      end
      sleep 5.0
      toggle_power(idx) if @is_power_test
      # Only verify if this is the first time around for the current parameter set
      log_info("Verifying Params")
      verify_params(vid_params) if idx < n_vid
      verify_params(loop_params) if idx < n_loo
      verify_params(photo_single_params) if idx < n_sin
      verify_params(photo_cont_params) if idx < n_con
      verify_params(photo_night_params) if idx < n_nht
      verify_params(burst_params) if idx < n_bur
      verify_params(tlapse_params) if idx < n_tla
      verify_params(nlapse_params) if idx < n_nla
    }
  end

  # Enumerate all combinations and then filter out parameters as we see them
  # Modes where all parameters are already covered are removed completely
  # leading to a smaller spanning set (although not guaranteed to be minimal)
  #
  # Step 1) Each mode is to get the full parameter set (all_params).
  #         For cameras with fewer parameters, just set options[:full] = true
  #         Otherwise (for Hawaii cameras) we must linearize some of the options
  #         (usually the ProTune ones)
  #
  # Step 2) List the parameters we actually want to set and check uin use_params
  #         Note they are listed as symbols WITH @ because they are instance variables
  def get_param_set(mode)
    case @camera.name
    when "HALEIWA", "HIMALAYAS"
      @options[:full] = true
      @options[:ntsc_only] = true
      @options[:setup_orientation] = "UP"
      case mode
      when "VIDEO"
        all_params = tu_get_video_res_with_protune.flatten(1).shuffle
        use_params = [:@mode, :@video_resolution, :@video_fps, :@video_fov,
          :@video_low_light, :@video_spot_metering]
      when "VIDEO_LOOPING"
        # Skip RES/FPS/FOV because they are always the same as in VIDEO
        all_params = tu_get_looping_res.shuffle
        use_params = [:@mode, :@video_looping]
      when "PHOTO"
        all_params = tu_get_photo_test_params.shuffle
        use_params = [:@mode, :@photo_resolution, :@photo_spot_metering]
      when "BURST"
        all_params = tu_get_multi_photo_burst_test_params
        use_params = [:@mode, :@multi_photo_resolution, :@multi_photo_spot_meter,
          :@multi_photo_burst]
      when "TIMELAPSE"
        all_params = tu_get_multi_photo_timelapse_test_params
        use_params = [:@mode, :@multi_photo_resolution, :@multi_photo_timelapse]
      else
        return []
      end
    when "ROCKYPOINT"
      @options[:full] = true
      @options[:ntsc_only] = true
      @options[:setup_orientation] = "UP"
      case mode
      when "VIDEO"
        all_params = tu_get_video_res_with_protune.flatten(1).shuffle
        use_params = [:@mode, :@video_resolution, :@video_fps, :@video_fov,
          :@video_low_light, :@video_spot_metering,
          :@video_pt, :@video_pt_wb, :@video_pt_color, :@video_pt_iso,
          :@video_pt_sharp, :@video_pt_ev,]
      when "VIDEO_LOOPING"
        # Skip RES/FPS/FOV because they are always the same as in VIDEO
        all_params = tu_get_looping_res.shuffle
        use_params = [:@mode, :@video_looping]
      when "PHOTO"
        all_params = tu_get_photo_test_params.shuffle
        use_params = [:@mode, :@photo_resolution, :@photo_spot_metering]
      when "BURST"
        all_params = tu_get_multi_photo_burst_test_params
        use_params = [:@mode, :@multi_photo_spot_meter, :@multi_photo_burst]
      when "TIMELAPSE"
        all_params = tu_get_multi_photo_timelapse_test_params
        use_params = [:@mode, :@multi_photo_timelapse]
      else
        return []
      end
    when "BACKDOOR", "PIPE"
      @options[:full] = false
      @options[:ntsc_only] = true
      @options[:setup_orientation] = "UP"
      case mode
      when "VIDEO"
        # vars holds the options to be linearized (from options in TestCase class)
        vars = [:video_pt_wb, :video_pt_color, :video_pt_ev, :video_pt_sharp, :video_pt_iso]
        all_params = linearize_combinations("tu_get_video_res_with_protune", vars)
        all_params.flatten!(1).shuffle!
        use_params = [:@mode, :@video_resolution, :@video_fps, :@video_fov,
          :@video_low_light, :@video_spot_metering,
          :@video_pt, :@video_pt_wb, :@video_pt_color, :@video_pt_iso,
          :@video_pt_sharp, :@video_pt_ev,]
      when "VIDEO_LOOPING"
        # No ProTune here.  Can just use options:full
        @options[:full] = true
        all_params = tu_get_looping_res.shuffle
        use_params = [:@mode, :@video_resolution, :@video_fps, :@video_fov,
          :@video_looping, :@video_low_light, :@video_spot_metering,]
      when "PHOTO"
        vars = [:photo_pt_wb, :photo_pt_color, :photo_pt_ev, :photo_pt_sharp,
          :photo_pt_iso, :photo_shutter_ev]
        all_params = linearize_combinations("tu_get_photo_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@photo_resolution, :@photo_spot_metering,
          :@photo_pt, :@photo_pt_wb, :@photo_pt_color, :@photo_pt_ev, :@photo_pt_sharp,
          :@photo_pt_iso]
      when "PHOTO_CONTINUOUS"
        vars = [:photo_pt_wb, :photo_pt_color, :photo_pt_ev, :photo_pt_sharp,
          :photo_pt_iso, :photo_shutter_ev]
        all_params = linearize_combinations("tu_get_photo_continuous_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@photo_resolution, :@photo_continuous, :@photo_spot_metering,
          :@photo_pt, :@photo_pt_wb, :@photo_pt_color, :@photo_pt_ev, :@photo_pt_sharp,
          :@photo_pt_iso]
      when "PHOTO_NIGHT"
        vars = [:photo_pt_wb, :photo_pt_color, :photo_pt_ev, :photo_pt_sharp,
          :photo_pt_iso, :photo_shutter_ev]
        all_params = linearize_combinations("tu_get_photo_night_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@photo_resolution, :@photo_night, :@photo_spot_metering,
          :@photo_pt, :@photo_pt_wb, :@photo_pt_color, :@photo_pt_ev, :@photo_pt_sharp,
          :@photo_pt_iso]
      when "BURST"
        @options[:multi_photo_pt] = nil # Do both OFF and ON
        vars = [:multi_photo_pt_wb, :multi_photo_pt_color, :multi_photo_pt_ev,
          :multi_photo_pt_sharp, :multi_photo_pt_iso]
        all_params = linearize_combinations("tu_get_multi_photo_burst_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@multi_photo_resolution, :@multi_photo_spot_meter,
          :@multi_photo_pt, :@multi_photo_pt_wb, :@multi_photo_pt_color,
          :@multi_photo_pt_ev, :@multi_photo_pt_sharp, :@multi_photo_pt_iso,
          :@multi_photo_burst]
      when "TIMELAPSE"
        @options[:multi_photo_pt] = nil # Do both OFF and ON
        vars = [:multi_photo_pt_wb, :multi_photo_pt_color, :multi_photo_pt_ev,
          :multi_photo_pt_sharp, :multi_photo_pt_iso]
        all_params = linearize_combinations("tu_get_multi_photo_timelapse_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@multi_photo_resolution, :@multi_photo_spot_meter,
          :@multi_photo_pt, :@multi_photo_pt_wb, :@multi_photo_pt_color,
          :@multi_photo_pt_ev, :@multi_photo_pt_sharp, :@multi_photo_pt_iso,
          :@multi_photo_timelapse]
      when "NIGHTLAPSE"
        @options[:multi_photo_pt] = nil # Do both OFF and ON
        vars = [:multi_photo_pt_wb, :multi_photo_pt_color, :multi_photo_pt_ev,
          :multi_photo_pt_sharp, :multi_photo_pt_iso, :multi_photo_shutter_ev]
        all_params = linearize_combinations("tu_get_multi_photo_nightlapse_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@multi_photo_resolution, :@multi_photo_spot_meter,
          :@multi_photo_pt, :@multi_photo_pt_wb, :@multi_photo_pt_color,
          :@multi_photo_pt_ev, :@multi_photo_pt_sharp, :@multi_photo_pt_iso,
          :@multi_photo_shutter_ev, :@multi_photo_nightlapse]
      else
        return []
      end # mode
    when "STREAKY"
      @options[:full] = false
      @options[:ntsc_only] = true
      @options[:setup_orientation] = "UP"
      case mode
      when "VIDEO"
        # vars holds the options to be linearized (from options in TestCase class)
        vars = [:video_pt_wb, :video_pt_color, :video_pt_ev, :video_pt_sharp, :video_pt_iso]
        all_params = linearize_combinations("tu_get_video_res_with_protune", vars)
        all_params.flatten!(1).shuffle!
        use_params = [:@mode, :@video_resolution, :@video_fps, :@video_fov,
          :@video_low_light, #:@video_spot_metering,
          :@video_pt, :@video_pt_wb, :@video_pt_color, :@video_pt_iso,
          :@video_pt_sharp, :@video_pt_ev,]
      when "VIDEO_LOOPING"
        # No ProTune here.  Can just use options:full
        @options[:full] = true
        all_params = tu_get_looping_res.shuffle
        use_params = [:@mode, :@video_resolution, :@video_fps, :@video_fov,
          :@video_looping, :@video_low_light, ]#:@video_spot_metering,]
      when "PHOTO"
        vars = [:photo_pt_wb, :photo_pt_color, :photo_pt_ev, :photo_pt_sharp,
          :photo_pt_iso, :photo_shutter_ev]
        all_params = linearize_combinations("tu_get_photo_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@photo_resolution, #:@photo_spot_metering,
          :@photo_pt, :@photo_pt_wb, :@photo_pt_color, :@photo_pt_ev, :@photo_pt_sharp,
          :@photo_pt_iso]
#      when "PHOTO_CONTINUOUS"
#        vars = [:photo_pt_wb, :photo_pt_color, :photo_pt_ev, :photo_pt_sharp,
#          :photo_pt_iso, :photo_shutter_ev]
#        all_params = linearize_combinations("tu_get_photo_continuous_test_params", vars)
#        all_params.shuffle!
#        use_params = [:@mode, :@photo_resolution, :@photo_continuous, #:@photo_spot_metering,
#          :@photo_pt, :@photo_pt_wb, :@photo_pt_color, :@photo_pt_ev, :@photo_pt_sharp,
#          :@photo_pt_iso]
      when "PHOTO_NIGHT"
        vars = [:photo_pt_wb, :photo_pt_color, :photo_pt_ev, :photo_pt_sharp,
          :photo_pt_iso, :photo_shutter_ev]
        all_params = linearize_combinations("tu_get_photo_night_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@photo_resolution, :@photo_night, #:@photo_spot_metering,
          :@photo_pt, :@photo_pt_wb, :@photo_pt_color, :@photo_pt_ev, :@photo_pt_sharp,
          :@photo_pt_iso]
      when "BURST"
        @options[:multi_photo_pt] = nil # Do both OFF and ON
        vars = [:multi_photo_pt_wb, :multi_photo_pt_color, :multi_photo_pt_ev,
          :multi_photo_pt_sharp, :multi_photo_pt_iso]
        all_params = linearize_combinations("tu_get_multi_photo_burst_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@multi_photo_resolution, #:@multi_photo_spot_meter,
          :@multi_photo_pt, :@multi_photo_pt_wb, :@multi_photo_pt_color,
          :@multi_photo_pt_ev, :@multi_photo_pt_sharp, :@multi_photo_pt_iso,
          :@multi_photo_burst]
      when "TIMELAPSE"
        @options[:multi_photo_pt] = nil # Do both OFF and ON
        vars = [:multi_photo_pt_wb, :multi_photo_pt_color, :multi_photo_pt_ev,
          :multi_photo_pt_sharp, :multi_photo_pt_iso]
        all_params = linearize_combinations("tu_get_multi_photo_timelapse_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@multi_photo_resolution, :@multi_photo_spot_meter,
          :@multi_photo_pt, :@multi_photo_pt_wb, :@multi_photo_pt_color,
          :@multi_photo_pt_ev, :@multi_photo_pt_sharp, :@multi_photo_pt_iso,
          :@multi_photo_timelapse]
      when "NIGHTLAPSE"
        @options[:multi_photo_pt] = nil # Do both OFF and ON
        vars = [:multi_photo_pt_wb, :multi_photo_pt_color, :multi_photo_pt_ev,
          :multi_photo_pt_sharp, :multi_photo_pt_iso, :multi_photo_shutter_ev]
        all_params = linearize_combinations("tu_get_multi_photo_nightlapse_test_params", vars)
        all_params.shuffle!
        use_params = [:@mode, :@multi_photo_resolution, #:@multi_photo_spot_meter,
          :@multi_photo_pt, :@multi_photo_pt_wb, :@multi_photo_pt_color,
          :@multi_photo_pt_ev, :@multi_photo_pt_sharp, :@multi_photo_pt_iso,
          :@multi_photo_shutter_ev, :@multi_photo_nightlapse]
      else
        return []
      end # mode
    else
      log_warn("Unknown camera type: #{@camera.name}")
      exit 1
    end # Case camera type

    s = Sieve.new(@camera, use_params)
    p_obj_arr = []
    all_params.each { |par_arr|
      p = Parameters.new(mode, par_arr)
      if s.should_use?(p)
        # Remove anything that is not in use_params
        p.instance_variables.each { |v|
          p.instance_variable_set(v.to_s, nil) if use_params.include?(v) == false
        }
        p_obj_arr << p
      end
    }
    return p_obj_arr
  end

  # Call meth with only ONE of the vars set to 'ALL' at a time.  The rest are nil.
  # Meth is a string of the method name
  def linearize_combinations(meth, vars)
    combos = []
    vars.each { |set_all_var|
      vars.each { |v|
        if v == set_all_var
          @options[v] = "ALL"
        else
          @options[v] = nil
        end
      }
      combos += method(meth).call()
    }
    return combos
  end

  # Sieve class enumerates all the possibilities for a given capture parameter.
  # Sieve::should_use? can be called with a Parameters object to determine whether
  # it should be added to the spanning set.  If so, the corresponding options are
  # removed from the instance variables.
  class Sieve
    def initialize(cam, use_params)
      @cam = cam
      # List of symbols of variables to use [:@video_resolution, :@video_fps, ...]
      @use_params           = use_params.to_set
      # Rest of instance variables should match wifi_command names
      @video_resolution     = @cam.get_video_resolution().to_set
      @video_fps            = get_all_fps
      @video_fov            = get_all_fov
      @video_low_light      = ["ON", "OFF"].to_set
      @video_spot_metering  = ["ON", "OFF"].to_set
      @video_looping        = @cam.get_video_looping_intervals.to_set
      @setup_orientation    = ["UP", "DOWN"].to_set
      if @cam.video_protune_support?
        @video_pt           = ["ON", "OFF"].to_set
        @video_pt_wb        = @cam.protune_white_balance_values.compact.to_set
        @video_pt_color     = @cam.protune_color_values.compact.to_set
        @video_pt_iso       = @cam.video_protune_iso_values.compact.to_set
        @video_pt_sharp     = @cam.protune_sharpness_values.compact.to_set
        @video_pt_ev        = @cam.protune_exposure_values.compact.to_set
      end

      @photo_resolution     = @cam.get_photo_resolutions.to_set
      @photo_spot_metering  = ["ON", "OFF"].to_set
      @photo_continuous     = @cam.get_photo_continuous_rates.to_set
      @photo_shutter_ev     = @cam.get_photo_shutter_exposure_intervals.to_set
      if @cam.photo_protune_support?
        @photo_pt           = ["ON", "OFF"].to_set
        @photo_pt_wb        = @cam.protune_white_balance_values.compact.to_set
        @photo_pt_color     = @cam.protune_color_values.compact.to_set
        @photo_pt_iso       = @cam.photo_protune_iso_values.compact.to_set
        @photo_pt_sharp     = @cam.protune_sharpness_values.compact.to_set
        @photo_pt_ev        = @cam.protune_exposure_values.compact.to_set
      end

      @multi_photo_resolution     = @cam.get_photo_resolutions.to_set
      @multi_photo_spot_meter     = ["ON", "OFF"].to_set
      @multi_photo_burst          = @cam.get_multi_photo_burst_rates.to_set
      @multi_photo_timelapse      = @cam.get_multi_photo_timelapse_rates.to_set
      @multi_photo_nightlapse     = @cam.get_multi_photo_nightlapse_rates.to_set
      @multi_photo_shutter_ev     = @cam.get_multi_shutter_exposure_intervals.to_set
      if @cam.multi_photo_protune_support?
        @multi_photo_pt           = ["ON", "OFF"].to_set
        @multi_photo_pt_wb        = @cam.protune_white_balance_values.compact.to_set
        @multi_photo_pt_color     = @cam.protune_color_values.compact.to_set
        @multi_photo_pt_iso       = @cam.photo_protune_iso_values.compact.to_set
        @multi_photo_pt_sharp     = @cam.protune_sharpness_values.compact.to_set
        @multi_photo_pt_ev        = @cam.protune_exposure_values.compact.to_set
      end
    end #initialize

    # Return true if the parameter object should be part of the spanning set
    def should_use?(p)
      # Search through current instance variables to see if anything in the
      # Parameter object still needs to be covered
      ret = false
      p.instance_variables.each { |v|
        next if @use_params.include?(v) == false
        param_set = eval(v.to_s)
        next if param_set == nil
        param = eval("p." + v.to_s[1..-1])
        if param_set.include?(param)
          ret = true
          break
        end
      }
      return false if ret == false
      # We are going to use this parameter set.  Cycle through and delete the
      # parameters from the local instance variables
      p.instance_variables.each { |v|
        next if @use_params.include?(v) == false
        param_set = eval(v.to_s)
        next if param_set == nil
        param = eval("p." + v.to_s[1..-1])
        param_set.delete(param)
      }
      return true
    end

    def get_all_fps
      ret = Set.new
      @cam.get_video_resolution.each { |res|
        @cam.get_video_fps(res).each { |fps|
          ret << fps if @cam.is_ntsc?(res, fps)
        }
      }
      return ret
    end

    def get_all_fov
      ret = Set.new
      @cam.get_video_resolution.each { |res|
        @cam.get_video_fps(res).each { |fps|
          @cam.get_video_fov(res, fps).each { |fov|
            ret << fov
          }
        }
      }
      return ret
    end
  end # class Sieve

  # Applies all non-nil settings in a Parameters object to the camera
  def set_params(p)
    log_info("Setting #{p.to_s}")
    ret, msg = @camera.set_capture_mode(p.mode)
    if @camera.name == "ROCKYPOINT" # Set ProTune first
      camera_run(:set_video_protune, p.video_pt)
    end
    # camera_run(:set_video_format, p.setup_video_format) # Running NTSC only
    camera_run(:set_video_resolution, p.video_resolution)
    camera_run(:set_video_fps, p.video_fps)
    camera_run(:set_video_fov, p.video_fov)
    camera_run(:set_video_protune, p.video_pt) if @camera.video_protune_support?
    # camera_run(:set_orientation, p.orient)
    camera_run(:set_video_spot_metering, p.video_spot_metering)
    camera_run(:set_video_low_light, p.video_low_light)
    camera_run(:set_video_protune_white_balance, p.video_pt_wb)
    camera_run(:set_video_protune_color, p.video_pt_color)
    camera_run(:set_video_protune_iso, p.video_pt_iso)
    camera_run(:set_video_protune_sharpness, p.video_pt_sharp)
    camera_run(:set_video_protune_exposure, p.video_pt_ev)
    camera_run(:set_video_piv, p.video_piv)
    camera_run(:set_video_looping, p.video_looping)
    camera_run(:set_video_timelapse, p.video_timelapse)

    camera_run(:set_photo_resolution, p.photo_resolution)
    camera_run(:set_photo_spot_metering, p.photo_spot_metering)
    camera_run(:set_photo_continuous, p.photo_continuous)
    camera_run(:set_photo_shutter_exposure, p.photo_shutter_ev)
    camera_run(:set_photo_def_sub_mode, p.photo_dft_submode)
    camera_run(:set_photo_protune, p.photo_pt)
    camera_run(:set_photo_protune_white_balance, p.photo_pt_wb)
    camera_run(:set_photo_protune_color, p.photo_pt_color)
    camera_run(:set_photo_protune_iso, p.photo_pt_iso)
    camera_run(:set_photo_protune_sharpness, p.photo_pt_sharp)
    camera_run(:set_photo_protune_exposure, p.photo_pt_ev)

    camera_run(:set_multi_photo_resolution, p.multi_photo_resolution)
    camera_run(:set_multi_photo_spot_metering, p.multi_photo_spot_meter)
    camera_run(:set_multi_photo_burst, p.multi_photo_burst)
    camera_run(:set_multi_photo_timelapse, p.multi_photo_timelapse)
    camera_run(:set_multi_photo_shutter_exposure, p.multi_photo_shutter_ev)
    camera_run(:set_multi_photo_nightlapse, p.multi_photo_nightlapse)
    camera_run(:set_multi_photo_def_sub_mode, p.multi_photo_dft_submode)
    camera_run(:set_multi_photo_protune, p.multi_photo_pt)
    camera_run(:set_multi_photo_protune_white_balance, p.multi_photo_pt_wb)
    camera_run(:set_multi_photo_protune_color, p.multi_photo_pt_color)
    camera_run(:set_multi_photo_protune_iso, p.multi_photo_pt_iso)
    camera_run(:set_multi_photo_protune_sharpness, p.multi_photo_pt_sharp)
    camera_run(:set_multi_photo_protune_exposure, p.multi_photo_pt_ev)
  end

  # Set a value via the given method
  # Skip if value is nil
  def camera_run(meth, val)
    # log_verb("meth=#{meth.to_s}, val=#{val.inspect}")
    return if val == nil
    # log_verb("Calling #{meth.to_s}(#{val})")
    ret, msg = @camera.method(meth).call(val)
    log_warn(msg) if ret != true
  end

  # Verifies all the camera settings for non-nil variables in a Parameters object p
  def verify_params(p)
    set_tc_name(p.to_s)
    # Himalayas/Haleiwa must enter VIDEO_LOOPING mode through VIDEO mode
    if @camera.looping_is_video_setting? and p.mode == "VIDEO_LOOPING"
      @camera.set_capture_mode("VIDEO")
    end
    ret, msg = @camera.set_capture_mode(p.mode)
    sleep 1.0
    arr = []
    p.instance_variables.each { |v|
      sym_name = v.to_s[1..-1]
      next if sym_name == "mode"
      exp = eval("p." + sym_name)
      next if exp == nil
      act = @camera.get_setting_name_by_sym_api2(sym_name.to_sym, refresh=false)
      log_verb("Verify setting: exp=#{exp}, act=#{act}")
      arr << "#{sym_name} fail. exp=#{exp}, act=#{act}" if exp != act
    }
    return if has_failure?(arr)
    pass()
  end

  # Parameters class holds parameteds for all the below options
  # Initializers use the same ordering as tu_get... functions in test_utils
  # Also has a string representation for all non-nil instance variables
  class Parameters
    attr_accessor :mode, # Top-level mode (VIDEO, PHOTO, etc...)
    # Copied from wifi_commands
    :video_submode,
    :video_resolution,
    :video_fps,
    :video_fov,
    :video_timelapse,
    :video_looping,
    :video_piv,
    :video_low_light,
    :video_spot_metering,
    :video_dft_submode,
    :video_pt,
    :video_pt_wb,
    :video_pt_color,
    :video_pt_iso,
    :video_pt_sharp,
    :video_pt_ev,

    :photo_resolution,
    :photo_continuous,
    :photo_shutter_ev,
    :photo_spot_metering,
    :photo_dft_submode,
    :photo_pt,
    :photo_pt_wb,
    :photo_pt_color,
    :photo_pt_iso,
    :photo_pt_sharp,
    :photo_pt_ev,

    :multi_photo_submode,
    :multi_photo_resolution,
    :multi_photo_burst,
    :multi_photo_timelapse,
    :multi_photo_shutter_ev,
    :multi_photo_nightlapse,
    :multi_photo_spot_meter,
    :multi_photo_dft_submode,
    :multi_photo_pt,
    :multi_photo_pt_wb,
    :multi_photo_pt_color,
    :multi_photo_pt_iso,
    :multi_photo_pt_sharp,
    :multi_photo_pt_ev,

    :setup_orientation,
    :setup_default_mode,
    :setup_quick_capture,
    :setup_led,
    :setup_beep,
    :setup_video_format

    def initialize(mode=nil, params=nil)
      return if mode == nil
      @mode = mode
      # Unpacking of 'params' must match how they are packed in test_utils
      case mode
      when "VIDEO"
        @setup_video_format,
        @video_resolution,
        @video_fps,
        @video_fov,
        @setup_orientation,
        @video_low_light,
        @video_spot_metering,
        @video_pt,
        @video_pt_wb,
        @video_pt_color,
        @video_pt_sharp,
        @video_pt_iso,
        @video_pt_ev = params
      when "VIDEO_LOOPING"
        @setup_video_format,
        @video_resolution,
        @video_fps,
        @video_fov,
        @video_looping,
        @setup_orientation,
        @video_low_light,
        @video_spot_metering = params
      when "PHOTO"
        @photo_resolution,
        @setup_orientation,
        @photo_spot_metering,
        @photo_pt,
        @photo_pt_wb,
        @photo_pt_color,
        @photo_pt_sharp,
        @photo_pt_iso,
        @photo_pt_ev = params
      when "PHOTO_CONTINUOUS"
        # res, sps, orient, spot, pt, wb, col, sh, iso, ex
        @photo_resolution,
        @photo_continuous,
        @setup_orientation,
        @photo_spot_metering,
        @photo_pt,
        @photo_pt_wb,
        @photo_pt_color,
        @photo_pt_sharp,
        @photo_pt_iso,
        @photo_pt_ev = params
      when "PHOTO_NIGHT"
        # res, orient, spot, se, pt, wb, col, sh, iso, ex
        @photo_resolution,
        @setup_orientation,
        @photo_spot_metering,
        @photo_shutter_ev,
        @photo_pt,
        @photo_pt_wb,
        @photo_pt_color,
        @photo_pt_sharp,
        @photo_pt_iso,
        @photo_pt_ev = params
      when "BURST"
        # res, bu, orient, spot, pt, wb, col, sh, iso, ex
        @multi_photo_resolution,
        @multi_photo_burst,
        @setup_orientation,
        @multi_photo_spot_meter,
        @multi_photo_pt,
        @multi_photo_pt_wb,
        @multi_photo_pt_color,
        @multi_photo_pt_sharp,
        @multi_photo_pt_iso,
        @multi_photo_pt_ev = params
      when "TIMELAPSE"
        # res, pes, orient, spot, pt, wb, col, sh, iso, ex
        @multi_photo_resolution,
        @multi_photo_timelapse,
        @setup_orientation,
        @multi_photo_spot_meter,
        @multi_photo_pt,
        @multi_photo_pt_wb,
        @multi_photo_pt_color,
        @multi_photo_pt_sharp,
        @multi_photo_pt_iso,
        @multi_photo_pt_ev = params
      when "NIGHTLAPSE"
        # res, pes, orient, spot, se, pt, wb, col, sh, iso, ex
        @multi_photo_resolution,
        @multi_photo_nightlapse,
        @setup_orientation,
        @multi_photo_spot_meter,
        @multi_photo_shutter_ev,
        @multi_photo_pt,
        @multi_photo_pt_wb,
        @multi_photo_pt_color,
        @multi_photo_pt_sharp,
        @multi_photo_pt_iso,
        @multi_photo_pt_ev = params
      else
        log_error("Unrecognized mode (#{mode})for Parameter class")
        exit 1
      end
    end

    def to_str
      return self.to_s
    end

    def inspect
      return self.to_s
    end

    def to_s
      s = "#{@mode}"
      s += "_#{@setup_video_format}" if @setup_video_format
      s += "_#{@video_resolution}" if @video_resolution
      s += "_#{@video_fps}" if @video_fps
      s += "_#{@video_fov}" if @video_fov
      s += "_loop-#{@video_looping}" if @video_looping
      s += "_ll-#{@video_low_light}" if @video_low_light
      s += "_spot-#{@video_spot_metering}" if @video_spot_metering
      s += "_pt-#{@video_pt}" if @video_pt
      s += "_wb-#{@video_pt_wb}" if @video_pt_wb
      s += "_col-#{@video_pt_color}" if @video_pt_color
      s += "_sharp-#{@video_pt_sharp}" if @video_pt_sharp
      s += "_exp-#{@video_pt_ev}" if @video_pt_ev
      s += "_iso-#{@video_pt_iso}" if @video_pt_iso

      s += "_#{@photo_resolution}" if @photo_resolution
      s += "_cont-#{@photo_continuous}" if @photo_continuous
      s += "_night-#{@photo_shutter_ev}" if @photo_shutter_ev
      s += "_spot-#{@photo_spot_metering}" if @photo_spot_metering
      s += "_pt-#{@photo_pt}" if @photo_pt
      s += "_wb-#{@photo_pt_wb}" if @photo_pt_wb
      s += "_col-#{@photo_pt_color}" if @photo_pt_color
      s += "_sharp-#{@photo_pt_sharp}" if @photo_pt_sharp
      s += "_iso-#{@photo_pt_iso}" if @photo_pt_iso
      s += "_exp-#{@photo_pt_ev}" if @photo_pt_ev

      s += "_#{@multi_photo_resolution}" if @multi_photo_resolution
      s += "_burst-#{@multi_photo_burst}" if @multi_photo_burst
      s += "_tlapse-#{@multi_photo_timelapse}" if @multi_photo_timelapse
      s += "_nlapse-#{@multi_photo_nightlapse}" if @multi_photo_nightlapse
      s += "_shut-#{@multi_photo_shutter_ev}" if @multi_photo_shutter_ev
      s += "_spot-#{@multi_photo_spot_meter}" if @multi_photo_spot_meter
      s += "_pt-#{@multi_photo_pt}" if @multi_photo_pt
      s += "_wb-#{@multi_photo_pt_wb}" if @multi_photo_pt_wb
      s += "_col-#{@multi_photo_pt_color}" if @multi_photo_pt_color
      s += "_sharp-#{@multi_photo_pt_sharp}" if @multi_photo_pt_sharp
      s += "_iso-#{@multi_photo_pt_iso}" if @multi_photo_pt_iso
      s += "_exp-#{@multi_photo_pt_ev}" if @multi_photo_pt_ev

      s += "_ori-#{@setup_orientation}" if @setup_orientation
      return s
    end
  end

  def cleanup
    @host.kill_status_process() if @host
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov,
      :photo_resolution, :photo_continuous,
      :multi_photo_burst, :multi_photo_timelapse, :full,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :setup_orientation,
      :shuffle, :set_defaults, :dryrun, :verb]

    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
