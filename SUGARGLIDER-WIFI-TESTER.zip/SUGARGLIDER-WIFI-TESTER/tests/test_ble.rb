#!/usr/bin/env ruby

# test_ble

# Bluetooth Low-Energy 
#
#  Objectives:
#   - Test the wifi-api that configures and initiates connection with a GoPro BLE device
#   - Test the video and session metadata that is created when a BLE device is connected to a camera
#

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/ble_api'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @run_unit_test = false
    @run_unit_test = true

    @options = options
    @test_file = __FILE__
    #set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    puts "@camera.name = #{@camera.name}"

    @camera.pause_enable(true) if @options[:pause]
    @camera.set_io_delay(@options[:io_delay]) if @options[:io_delay]
    puts "IO delay=#{@options[:io_delay]}" if @options[:io_delay]

    # default duration is 15 seconds
    # @duration = @options[:duration] != nil ? @options[:duration].to_i : 15
    @duration = @options[:duration] != nil ? @options[:duration].to_i : 15

  end # setup()

  def runtest

    if @run_unit_test

      ####  UNIT LEVEL TESTING of individual tests
      # test_ble_connection() 
      test_gpmf_metadata()
      # test_metadata_sensors(@num_sensors) # use the --sensors <#> option
      # test_ble_cancel_pairing() 
      # test_ble_whitelist()       # add, remove
      # test_ble_autoconnect() 
   
    else # run full regression test below

      ####  FULL FUNCTIONAL TESTING 
      test_ble_connection() 
      test_gpmf_metadata()
      test_ble_cancel_pairing() 
      test_ble_whitelist()       # add, remove
      test_ble_autoconnect() 

    end  # if run_unit_test; else run functional tests

  end # runtest()

  def cleanup
    @host.kill_status_process() if @host
  end

  def do_sleep(sleep_time,msg=nil)
    if (msg==nil)
      log_info("sleeping for #{sleep_time}s")
    else
      log_info("#{msg} for #{sleep_time}s")
    end
    sleep(sleep_time)
  end

  def test_ble_connection()

    log_info("test_ble_connection()")

    # 1. (manual) turn on device broadcast
    # 2. tell camera to scan for ble devices
    # 3. check camera device list until specified device name is found
    # 4. turn off ble scan
    # 5. Enter pairing phase
    # 6. pair camera to device
    # 7. Exiting pairing phase
    # 8. Check ble status -> should be "paired" (connecting, connected on the way?)
    # 9. Make sure autoconnect is on. If not, configure it on
    # 10. Get camera whitelist 
    # 11. Check whitelist to see if device is paired and connected
    # 12. Turn autoconnect off. 
    # 13. Check whitelist to see if device is disconnected
    # 14. Turn autoconnect on
    # 15. Check whitelist to see if device is re-connected
    #
    result = @camera.ble_scan()
    list = @camera.ble_list()
    # list,msg = @camera.ble_list()  # First TAG
    # if  list is empty -> fail
    # check if list contains @sensor_name  (use --sensor_name <name>)

    dev_address, dev_address_type = @camera.ble_get_address(@sensor_name)
    log("device address=#{dev_address} type=#{dev_address_type}")

    result  = @camera.ble_pairphase_enter()
    result = @camera.ble_pairphase_enter(dev_address, dev_address_type)
    if result==false
      log_fail("ERROR pairing with device")
    end
    result = @camera.ble_pairphase_exit()

    do_sleep(5.0)

    result==nil ? fail() : pass()

  end # test_ble_connection

  def test_gpmf_metadata()

    # 0. autoconnect enable
    # 1. (manual step) turn on sensor advertising
    # 2. start ble-scan (gpControl)
    # 3. check scan list for pre-determined sensor name (option settable)
    #      OR check for GoPro UUIDs "profile_uuid16":["0304","0506"]
    # 4. if found, stop scan. Extract address and address type for sensor name
    # 5. enter pairing phase
    # 6. pair address, type
    #    - check status for pairing_status:1,2 (idle(0), connecting(1), connected(2))
    # 7. exit pairing phase
    # 8. check status for pairing_status:3 (paired)
    # 9. check whitelist for device name,address,type, connected state
    # 10. set mode to video
    # 11. shutter on
    # 12. (manual) press side TI button to send sensor metadata to camera (led should be bright green)
    # 13. sleep 20s (option settable)
    # 14. check medialist
    # 15. copy latest file to RaspberryPI (/tmp/?)
    # 16. call mdtool -f <mp4 path> -v 1 -test gpmf (runs all tests) -l $RUN_DIR (save along with test)
    # 17. parse mdtool results for
    # GPMF_RAMP_TEST      : FAIL
    # GPMF_TAGS_TEST      : FAIL
    # GPMF_TIMING_TEST    : FAIL
    # GPMF_NSENSOR_TEST   : FAIL, #expected=6 #detected=3 name(s):
        # sensor#1) dvid:2 name:"SENSOR"
        # sensor#2) dvid:1 name:"SENSOR"
        # sensor#3) dvid:3 name:"SENSORD0"

    set_tc_name("Autoconnect Enable")
    log_info("Enabling autoconnect...")
    s,e,m = @camera.autoconnect_all(1)
    if (e != 0)
      log_fail("Autoconnect-Enable Error #{e} #{m}")
    else
      pass()
    end

    set_tc_name("Scan Start")
    log_info("Scanning for BLE devices...")
    s,e,m = @camera.scan_start()
    if (e != 0)
      log_fail("Scan Error #{e} #{m}")
    else
      pass()
    end

    set_tc_name("Scan List Get")
    sensor_list = {}
    num_sensors = -1
    scan_delay=5
    scan_tries=1
    (1..scan_tries).each { |tryN|
      do_sleep(scan_delay,"Scanning")

      log_info("Getting list of GP BLE devices...#{tryN}")
      num_sensors, sensor_list = @camera.get_sensor_list()
      log_info ("num_sensors=#{num_sensors}")
      log_info ( "sensor_list=#{sensor_list}")
      if num_sensors.to_i > 0
        break
      else
        scan_delay = scan_delay/2
      end
    }
    # Scan List Get Test Result
    if (num_sensors < 0)
      fail()
    else
      pass()
    end

    set_tc_name("Scan Stop")
    log_info("Stopping scan... num_sensors=#{num_sensors}")
    do_sleep(2)
    s,e,m = @camera.scan_stop()
    if (e != 0)
      log_fail("Stop-Scan Error #{e} #{m}")
      exit(1)
    else
      pass()
    end

    set_tc_name("Whitelist Get")
    num_sensors_connected = @camera.get_whitelist_connections()
    if (num_sensors_connected < 0)
      fail()
    else
      pass()
    end

    if (num_sensors <= 0) and (num_sensors_connected <= 0)
      log_warn("Aborting test, NO SENSORS FOUND, NO SENSORS CONNECTED!") 
      exit(1)
    end

    # Test the following just once (because there can be multiple sensors
    phase_enter_tested_once=false
    pair_start_tested_once=false
    phase_exit_tested_once=false
    pairing_status_tested_once=false

      # Pairing and connect with each device in the list
    if (num_sensors > 0)
      sensor_status={}
      sensor_list.each { |sens|

        name      = sens["name"]
        address   = sens["address"]
        type      = sens["address_type"]

        if (@camera.is_connected(address) == true)
          log_info ("ALREADY CONNECTED: name:#{name} addr:#{address} type:#{type}")
          next
        end

        log_info("Device addr=#{address} is NOT connected, attempting to pair")
        set_tc_name("Pairing Phase Enter") if (phase_enter_tested_once==false)
        log_info("Enter Pairing Phase...")
        reply,e,m = @camera.enter_pairing_phase()
        if (e != 0)
          msg = "Enter Pairing Phase Error #{e} #{m}"
          log_fail(msg) if phase_enter_tested_once==false
          log_warn(msg) if phase_enter_tested_once==true
        else
          pass() if (phase_enter_tested_once==false)
        end
        phase_enter_tested_once = true

        set_tc_name("Pairing Start") if not pair_start_tested_once
        log_info("Pairing with name:#{name} addr:#{address} type:#{type}")
        reply,e,m = @camera.pair_start(address, type)
        if (e != 0)
          msg = "Pairing Error #{e} #{m}"
          log_fail(msg) if (pair_start_tested_once==false)
          log_warn(msg) if (pair_start_tested_once==true)
        else
          pass() if pair_start_tested_once==false
        end
        pair_start_tested_once = true
        do_sleep(3,"Pairing")

        set_tc_name("Pairing Phase Exit") if not phase_exit_tested_once
        log_info("Exit Pairing Phase...")
        reply,e,m = @camera.exit_pairing_phase()
        if (e != 0)
          msg="Pairing Phase Exit Error #{e} #{m}"
          log_fail(msg) if (phase_exit_tested_once==false)
          log_warn(msg) if (phase_exit_tested_once==true)
        else
          pass() if phase_exit_tested_once==false
        end
        phase_exit_tested_once = true


        pairing_status_tested_once = false
        sensor_status[address] = "none"
        # Check 1 times for PAIRED or CONNECTED status
        tries=1
        (1..tries).each { |nTry|
          do_sleep(2, "Pair status check, waiting")
          log_info("nTry=#{nTry}") if @debug
          set_tc_name("Pairing Phase Exit") if not pairing_status_tested_once
          pair_sts,e,m = @camera.get_pairing_status()
          sensor_status[address] = pair_sts
          if (e==0)
            case pair_sts.to_s
            when "IDLE" 

              log_info("Pairing state is IDLE") if nTry==1
              log_warn("Pairing state is IDLE") if nTry==2
              if (nTry>=tries)
                log_warn("Pairing failed, state is IDLE")
                sensor_status[address] = "FAILED"
              end
            when "CONNECTING" 
              log_info("Pairing in progress, state is CONNECTING")
            when "CONNECTED" 
              log_info("Pairing in paired and connected, state is CONNECTED")
              break
            when "PAIRED" 
              log_info("Pairing in complete, state is PAIRED")
              break
            else
              log_fail("ERROR UNKNOWN pairing status=#{pair_sts} e=#{e} m=#{m}")
              exit(1)
            end
          else
            msg = "Pairing Status Error #{e} #{m}"
            log_fail(msg) if pairing_status_tested_once==false
            log_warn(msg) if pairing_status_tested_once==true
            next
          end
          pairing_status_tested_once = true

        } # check pairing status 

      } # each sensor

      log_info( "sensor pairing statuses:")
      sensor_status.each { |k,v|
        log_info( "addr=#{k} state=#{v}")
      }
    end # if new sensors were found

    do_sleep(5)
    num_sensors_connected= @camera.get_whitelist_connections()
    log_info("# of CONNECTED Sensors = #{num_sensors_connected}")

    if num_sensors_connected <= 0
      log_warn("NO SENSORS ARE CONNECTED")
      exit(1)
    end

    set_tc_name("GPMF Metadata Check")
    do_sleep(5.0, "TURN ON the TI-SENSOR METADATA *NOW*, waiting")
    log_info("Deleting all media on camera")
    @camera.delete_all_media()
    do_sleep(5.0,"Deleting Media, waiting")

    numEncodes=3
    num_sensors, sensor_list = @camera.get_sensor_list()

    orig_connected, orig_connlist = @camera.get_connected_devices()
    log_info( "Starting connections=#{orig_connected} list=#{orig_connlist}")

    (1..numEncodes).each { |ne|

      log_info("ENCODE ##{ne}")
      curr_conns, curr_connlist = @camera.get_connected_devices()
      if curr_conns != orig_connected
        if curr_conns==0
          wl,e,m = @camera.whitelist_get()
          log_info("CURRENT WHITELIST = #{wl}")
          log_fail("CONNECTIONS DROPPED to ZERO during test")
          exit(1)
        else
          log_warn("Original CONNECTIONS from #{orig_connected} list=#{orig_connlist} to #{curr_conns} list=#{curr_connlist}")
        end
      end

=begin
      # Place-holder for testing all video settings
      if @test_all_video_settings
        # Get/Set VIDEO options
        if @options[:duration]  # seconds to wait while encoding
          @duration = @options[:duration].to_i
        else
          @duration = 30.0 # default
        options = @options
        options[:video_pt] = "OFF"
        video_params = tu_get_video_res_with_protune(@camera, options).flatten(1)
        video_params.each { |vp|
          vm, res, fps, fov, ll, spot, pt, wb, co, sh, iso, ex = vp
          # @camera.set_video_protune("OFF")
          # @camera.set_video(vm, res, fps, fov)
          set_tc_name("%s-%s-%s_ble_video_metadata_%s-%s-%s" \
            %[res, fps, fov, pt_res, pt_fps, pt_fov])
          @camera.capture_video(vp);
          video_opts = vp[0..4] + [@duration] + vp[5..-1]   # insert duration into the args to capture_video()
          ret, msg = @camera.capture_video(*video_opts)
        } # video_params
        # ret, msg = @camera.capture_video(*video_opts)
        # (ret == false) ? (fail(msg); next) : log_info(msg)
=end
      # Simplify: just one video setting for now (TODO: go back to video_params in future)
      @camera.set_video_protune("OFF")
      vm, res, fps, fov = "NTSC", "1080", "30", "W"
      @camera.set_video(vm, res, fps, fov)
      log_info "@duration=#{@duration}"
      @camera.start_capture()
      do_sleep(@duration,"Capturing video")
      @camera.stop_capture()

      log_info("Downloading last media to /tmp")
      mp4Path = @camera.download_last_media("/tmp")
      puts "mp4Path=#{mp4Path}"
      mdtoolPath = "/home/pi/SUGARGLIDER-WIFI-TESTER/tools/BLE/mdtool"
      mdOptions = "-test gpmf -sensors #{num_sensors_connected} -v 2 -showrampdata -pre 1 -preamble '______' -l -ld /home/pi/logs/BLE"

      @cmd = "#{mdtoolPath} -f #{mp4Path} #{mdOptions}"
      o,e,s = @host.sys_exec(@cmd)
      log_info("MDTOOL=\"#{@cmd}\:")
      log_info("#{o}") # stdout from mdtool - put in testlog
      log_debug("output=#{o} e=#{e} s=#{s}")

      # Test Results Hash:
      # Save line below for GPMF_TIMING_TEST
      # tests={"GPMF_RAMP_TEST"=>"na", "GPMF_TAGS_TEST"=>"na", "GPMF_TIMING_TEST"=>"na","GPMF_NSENSOR_TEST"=>"na"}
      tests={"GPMF_RAMP_TEST"=>"na", "GPMF_TAGS_TEST"=>"na", "GPMF_NSENSOR_TEST"=>"na"}
      tests.each do |t, test_res|
        result =  o.scan(/#{t}\s+:\s+(\w+)/)     # ramp_result="FAIL"
        puts "#{t} result=#{result[0][0]}"
        tests[t] = result[0][0]
      end
      puts "MDTOOL=\"#{@cmd}"
      puts "TEST RESULTS:"
      tests.each do |t, test_res|
        set_tc_name(t)
        # puts "#{t} result=#{test_res}"
        if test_res=="FAIL"
          fail() 
        elsif test_res=="PASS"
          pass() 
        else
          log_fail("ERROR: unknown mdtool result=#{test_res}")
        end
      end
    } # numEncodes

  end # test_gpmf_metadata

  def test_gpmf_sensors(num_sensors) # use the --sensors <#> option
    # log_info("test_gpmf_sensors()")
    # log_fail("Not implemented yet")
  end # test_gpmf_sensors

  def test_ble_cancel_pairing() 
    # 1. camera scan for ble devices
    # 2. get device list
    # 3. enter pairing phase
    # 4. start pairing
    # 5. cancel pairing (right away?)
    # 6. make sure there are no errors
    # 7. exit pairing phase
    log_info("test_ble_cancel_pairing")
    log_fail("Not implemented yet")
  end # test_ble_cancel_pairing

  def test_ble_whitelist()
    log_info("test_whitelist()")
    # 1. scan for ble devices
    # 2. get device list
    # 3. add to white list, check
    # 4. remove from white list, check
    #
  end # test_whitelist

  def test_ble_autoconnect() 
    log_info("test_ble_autoconnect()")
    log_fail("Not implemented yet")
  end # test_ble_autoconnect

end # class Test

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :reset_on_failure, :duration, :ble,
      :shuffle, :set_defaults, :logfile, :verb, :pal_only, :ntsc_only, :video_resolution,
      :video_fps, :video_fov, :mode_cm, :mode, :timelapse, :full, :quick,
      :test_delay, :io_delay, :pause, :model]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    # t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
