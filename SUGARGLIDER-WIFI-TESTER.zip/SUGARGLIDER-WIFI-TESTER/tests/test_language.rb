# test_language.rb
# Description: Tests putting the camera in different languages, if that option is present.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize()
    super
  end # initialize

  def setup(options)
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @options = options
    @host = Host.new
    @camera = tu_get_camera()
    @sercam = get_serial_camera(@camera.serial_iface) if @camera.serial_iface
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
      @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    # Make sure that this camera can test this feature.
    unless @sercam
      log_fail("As there are currently no gpCommands to set the language, this test can not run without a serial interface to the camera.")
      exit 1
    end
    # Make sure that this feature exists on this camera.
    @langs = @sercam.language_support? # False or list of languages.
    unless @langs
      log_fail("This camera doesn't support multiple languages.")
      exit 1
    end
  end # setup

  def runtest()
    # TODO: Add logic to determine if this camera should have this feature.
    test_language_support() # A side effect of this test is to set @langs.
    @langs.each { |lang| test_set_language(lang) } if @langs
    # TODO: Enable this test case once written.
    #@langs.each { |lang| test_validate_ui_text(lang) } if @langs
  end # runtest

  def test_language_support(expected=nil)
    if expected == nil
      log_warn("Could not determine if this canera should support this feature. Assuming it doesn't.")
    end
    @langs = @sercam.language_support? # False or list of languages.
    if @langs
      if expected
        pass("Languages are supported, which is what was expected. Doing remaining tests.")
      else
        fail("Surprisingly, languages are supported. Update the test logic? Doing remaining tests.")
      end
    else
      if expected
        fail("Expected languages to be supported, but they aren't.")
      else
        pass("As expected, this camera doesn't support languages.")
      end
    end
  end # test_language_support

  def test_set_language(lang)
    set_tc_name("test_set_language_#{lang}")
    @sercam.set_language(lang)
    sleep(1.0)
    result = @sercam.get_language()
    failures = []
    failures << assert(result == lang, "Failed to set language to #{lang}, result was #{result}")
    pass("Language set correctly.") if not has_failure?(failures)
  end # test_set_language

  # TODO: If possible, write this testcase.
  def test_validate_ui_text(lang)
    set_tc_name("test_validate_ui_text_#{lang}")
    @sercam.set_language(lang)
    # May need to restart camera at this point for UI changes to take hold.
    log_warn("test_validate_ui_text: No idea how to do this yet.")
    failures = []
    failures << assert(false, "This test is not implemented.")
    pass("UI text is in correct language.") if not has_failure?(failures)
  end # test_validate_ui_text

  def cleanup()
    # Try to set it back to English.
    log_info("Attempting to set the camera back into English...")
    @sercam.set_language("english") if @sercam
  end # cleanup

end # Test

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :shuffle, :set_defaults, 
       :battoutlet, :usboutlet, :reset_on_failure, :save_dir, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
