# test_ota_cancel.rb
# Description: Repeatedly starts and cancles an ota update.
#
# Tests the following items:
#   - Canceling an ota update.

require_relative '../libs/camera'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require_relative '../libs/dlipower'
require_relative '../libs/installHandler.rb'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    set_tc_name("test_ota_cancel_setup")
    @host = Host.new
    @camera = tu_get_camera()
    # Option to verify update happens by checking capture mode before and after update.
    @mode_check = false #true
    @camera.squelch_status = true if @camera.interfaces.include?(:wifi)
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
  end

  def runtest
    limit = @options[:n_iter] == nil ? 1 : @options[:n_iter].to_i
    set_tc_name("test_ota_cancel_#{limit}_iterations")
    if @options[:base_fw_file] != nil
      base_ih = InstallHandler.new(@camera, @options[:base_fw_file])
    end
    ih = InstallHandler.new(@camera, @options[:fw_file])
    log_info("Deleting all media...")
    @camera.delete_all_media() # Can't perform ota with full disk
    log_info("Camera release of FW file: #{ih.fw_rel()}")
    log_info("Camera model of FW file: #{ih.fw_cam()}")
    log_info("Firmware version of FW file: #{ih.fw_ver}")
    n = 1
    failed_arr = []
    while n <= limit
      log_info("Performing cancel update cycle #{n} of #{limit}.")
      log_info("Starting update to FW version #{ih.fw_ver}, but canceling it.")
      @camera.set_capture_mode("PHOTO") if @mode_check
      log_warn("Failed to switch to PHOTO MODE.") unless do_mode_check("PHOTO")
      start = Time.now()
      result = ih.do_ota_update(true, cancel_upload=true)
      time_taken = Time.now() - start
      if result == true
        if do_mode_check("PHOTO")
          log_info("Update canceled after %0.2f seconds" %(time_taken) )
          if time_taken >= 60
            log_warn("That seemed rather slow. Did it actually cancel?")
          end # time_taken
        else # bad mode check
          failed_arr << "No longer in PHOTO mode after iteration #{n}. An update must have happened!"
        end # do_mode_check
      else # bad result
        failed_arr << "Did not do ota cancel for iteration #{n}."
      end
      n += 1
      sleep(5.0)
    end
    pass "All #{limit} iterations of ota canceling passed." unless has_failure?(failed_arr)
  end

  def do_mode_check(want_mode)
    # Always pass this check if mode_check is false.
    return true unless @mode_check
    found_mode = @camera.get_current_capture_mode().upcase
    retval = (want_mode == found_mode)
    log_info("do_mode_check returning #{retval}. (found: #{found_mode} wanted: #{want_mode})")
    return retval
  end # do_mode_check

  def cleanup
  end

end # end Test class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :n_iter, :fw_file, :serialdev, #:base_fw_file,
      :battoutlet, :usboutlet, :reset_on_failure, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
    t.cleanup
  rescue StandardError => e
    require_relative '../libs/log_utils'; include LogUtils
    log_error(e.to_s + "\n" + e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
