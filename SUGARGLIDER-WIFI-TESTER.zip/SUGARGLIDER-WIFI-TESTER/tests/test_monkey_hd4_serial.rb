# Monkey test
#
# Description: Resets the camera to defaults and randomly triggers
#     the SHUTTER and POWER buttons to exercise the camera in 
#     random ways.  This test is SERIAL ONLY and Hero4 ONLY
# Options: 
#    [--iterations N]   Number of steps to perform
#    [--duration SECS]  Length of time to for which to run
#    [--quick]          Drive the test faster
#    [--shuffle SEED]   Set the random seed to SEED
#    [--beep 0]         Turn off the beep sound (TODO::: not implemented yet)

require 'pp'
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Monkey
  include LogUtils
  def initialize(seed, camera, options)
    @c            = camera
    @seed         = seed
    @iterations   = options[:n_iter].to_i
    @duration     = options[:duration]
    if options[:duration_range_low] and options[:duration_range_high]
      @duration = rand(options[:duration_range_low]..options[:duration_range_high])
      log_info("Using a duration of #{@duration}. Range is (#{options[:duration_range_low]}..#{options[:duration_range_high]}).")
    end
    @log_file     = options[:log_file]
    @quick        = options[:quick]
    @quiet        = options[:setup_beep] == "0"
    @count        = 0
    @last_status  = nil
  end

  def dump_current_settings()
    if @c.is_alive?
      @c.send_serial("t appc status show")
      @last_status = @c.read_serial_resp(limit=3.0)
    else
      log_warn("Last known camera settings")
    end
    log_info(@last_status)
  end

  def update_status()
    @c.send_serial("t appc status show")
    @last_status = @c.read_serial_resp(limit=3.0)
  end

  def press_button(id, dur=250, label="", tries=3)
    (1..tries).each { |n|
      log_info("Step #{@count} -- Try #{n} pressing button id=#{id} (#{label}) for #{dur}ms")
      @c.send_serial("t button press #{id} #{dur}")
      # if @c.expect("detect button #{id} press") == nil
      #   log_warn("Button press not seen (id=#{id}, dur=#{dur})")
      #   sleep(1.0)
      # else
      #   return true
      # end
      # return false
      return true
    }
  end

  def toggle_power(dur=250)
    return press_button(0, dur, "POWER")
  end

  def toggle_shutter(dur=250)
    return press_button(1, dur, "SHUTTER")
  end

  def toggle_settings(dur=250)
    return press_button(2, dur, "SETTINGS")
  end

  def toggle_lcd(dur=250)
    return press_button(3, dur, "LCD")
  end
  
  # Start the monkey
  def run()
    srand @seed
    start_time = Time.now()
    begin
      # Fill in camera initial status structure
      update_status()
      while true do
        @count += 1

        # Handle quiet_mode
        # if @quiet and @c.status(:beeping_sound) != 0
        #   @c.set(@c.beep_sound, 0, wait_time=1.0, decode=false)
        # end
        
        # Take a random step
        case rand(0..3)
          when 0; toggle_power
          when 1; toggle_shutter
          when 2; toggle_settings
          when 3; toggle_lcd     
        end

        if @quick == false
          sleep(0.5)
          @c.expect(/a:.>/, 0.55, 0.25)
        end

        # Take encoding duration from truncated exponential distribution
        if @c.recording?
          mean = 5.0
          sample = -mean * Math.log(rand)
          t = (sample > 30) ? 30 : sample.to_i
          log_info("Sleeping for #{t} seconds")
          sleep(t)
        end
        
        if @c.is_alive?
          update_status()
        else
          raise("Camera is not alive")
        end
        
        # Check if we should break
        break if @iterations != nil and @count >= @iterations
        break if @duration != nil and (Time.now() - start_time) >= @duration
      end
    rescue StandardError=>e
      t = Time.now
      log_warn("Current time: %s (lasted %s seconds)" %[t, (t - start_time).to_i])
      log_warn("Reason: %s" %e.to_s)
      log_warn(e.backtrace.join("\n"))
      dump_current_settings
      return false, "Monkey execution loop unexpectedly exited at step #{@count}"
    end
    return true, "Monkey execution loop finished #{@count} steps successfully"
  end # run
end # class Monkey
  
class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    else
      log_error("Must specify serial device")
      exit 1
    end
    @camera.delete_all_media()
    sleep(3.0)

    @camera.powerstrip = PowerStrip.new(@options[:power_ip], 
                         @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @seed = options[:seed]
    @seed = srand >> 100 if (@seed == nil or @seed == false)
    
    # Reset defaults
    log_info("Resetting defaults")
    @camera.do_factory_reset("USER")
  end
  
  def runtest
    set_tc_name("#{@test_file}-executing")
    log_info("Using seed #{@seed}")
    monkey = Monkey.new(@seed, @camera, @options)
    ret, msg = monkey.run()
    ret == true ? log_pass(msg) : log_fail(msg)
  end
  
  def cleanup
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:serialdev, :setup_beep,
      :battoutlet, :usboutlet, :n_iter, :duration, :quick, :shuffle, :verb
    ]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
