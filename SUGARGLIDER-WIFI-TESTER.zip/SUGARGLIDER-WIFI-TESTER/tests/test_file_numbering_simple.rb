# test_file_numbering_simple.rb
# DESCRIPTION: Tests that numbers in names of files created by the following modes are correct:
# - PHOTO (photo single)
# - VIDEO (video single)
# - BURST (mulitshot burst)
# - TIMELAPSE (photo timelapse)

# NOT COVERED
# Filenames of files created by other modes are more involved, and not covered by this test.
# Chaptered video file numbers are also not covered by this test.
# The file counter not being reset by a firmware update is not covered by this test.

#####
# Actually a lot of testcases aren't even here yet.
# This is more of a proof of operations right now.
# Plus I don't know what sort of test cases to write.
# Base them on test rails testcases?
# Write something original and complicated?
# Base on the GoPro specs?
# Something uber simple?

# SERIAL ONLY
# This test only works for serial camera.
# Wifi cameras currently too secure and lack the ability to create folders and spoof files.

# HAWAII ONLY
# This test only works (well, I've only tested it on) for Hawaii models
# Rockey Point cameras have different serial commands.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include Test_utils
  def initialize()
    super
  end # initialize

  def setup(options)
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @options = options
    @host = Host.new
    #(log_fail("This test requires a serial camera!"); exit! 1) if @options[:serialdev] == nil
    @camera = tu_get_camera()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
      @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    set_options()
  end # setup

#####
  def runtest_simple()
    set_tc_name("#{@test_file}_runtest_get_file_counter")
    ret, msg = @camera.set_capture_mode("PHOTO")
    (log_fail(msg); exit! 1) unless ret
  end # runtest_simple
#####

  def runtest()
    unless @options[:serialdev]
      log_warn("LIMITED TEST MODE: This test is only fully supported on serial cameras!")
      return runtest_limited()
    else
      log_info("FULL TEST MODE: Serial cameras can run the full test.")
      return runtest_full()
    end # if
  end # runtest

    # New folder cases:
    # - last folder not full, image.
    # - last folder full, image.
    # - last folder not full, video.
    # - last folder full, video.
    # - last folder not at all full, burst.
    # - last folder close to full, burst recording in new folder.
    # - last folder full, burst into new folder.
    # - last folder not full, timelapse.
    # - timelapse of folder limit.

    # SKIPPED ON WIFI
    # File counter rollover via image, new folder and rollback file counter.
    # File counter rollover via video, new folder and rollback file counter.
    # File counter rollover via burst, new group number, new folder number, and file counter rolls over.
    # File counter rollover via timelapse, new group number, new folder, and file counter rolls over.
    # - Image at no capture (all folders FULL).
    # - Video at no capture (all folders FULL).
    # - Burst at no capture (all folders FULL).
    # - Timelapse at no capture (all folders FULL).
    # - Chaptered video.
    # - 3D of all kinds.
    # - Other modes.

    # Curses! We have to start from scratch!
    # WE HAVE TO CLEAR THE CONTENTS OTHERWISE WE RUN THE RISK OF FULL FOLDERS PRE-EXISITING!
    # This screws with the is it in the next folder? Test.
    # Actually this test is pretty weak.
    
#    @camera.set_multi_photo_timelapse(0.5) ###### WHY DOES THIS WORK?
#    (log_fail(msg); exit! 4) unless ret

#    files_left = 997

##### This doesn't work well. It can overshoot.
=begin ##### Tries to get close to the folder limit with timelapse.
    5.times do |n|
      ml = @camera.get_medialist()
      puts "GOT MEDIALIST (Time #{n+1} of 5)"
      # What is the last folder?
      last_folder = ml.last.split("/")[0]
      puts "LAST FOLDER: #{last_folder}"
      # How many files are in the last folder?
      files_current = ml.count { |f| f.start_with?(last_folder) }
      puts "FOUND #{files_current} FILES"
      # How many more files can there be in the last folder?
      files_left = 997 - files_current
      puts "NEED #{files_left} MORE FILES"
      # Are we close enough to do the test?
      break if files_left <= 40
      # Guess not. Make more files!
      duration = files_left / 2.0
      puts "DURATION OF CAPTURE: #{duration}"
      @camera.start_capture()
      sleep(duration)
      @camera.stop_capture()
    end # do
=end

  # This comes up a lot.
  def get_last_file_counter()
    ml = @camera.get_medialist()
    return false, "get_last_file_counter: Could not get medialist." unless ml and ml.length > 0
    counter = ml.last.match(/\d\d\d\d/).to_s.to_i
    return counter, "get_last_file_counter: Returned #{counter}"
  end # get_last_file_counter

  # This is also useful. COunts how many DCF objects appear in a given folder.
  def get_dcf_count(folder)
    ml = @camera.get_medialist()
    return false, "get_dcf_count: Could not get medialist." unless ml
    count = ml.count { |x| x.start_with?(folder) and (x.end_with?("MP4") or x.end_with?("JPG")) }
    return count, "get_dcf_count: Returned #{count}"
  end # get_dcf_count

  # This gives the folder name that follows numerically next.
  # It does not look for what the next folder should be based on the files and folders found on the camera.
  def get_next_folder(folder)
    return false, "next_folder(): Invalid foldername." unless folder.match(/\d\d\dGOPRO/)
    return false, "next folder(): Folder 999GOPRO has no next folder." if folder == "999GOPRO"
    ret = "#{folder[0..3].to_i + 1}GOPRO"
    return ret, "next_folder(): Returned #{ret}"
  end # next_folder

  # This test happens whenever the file counter is too close to 9999 to do the 999 DCF objects test.
  # This is a rare treat for the wifi camera, since the file counter can't be set directly.
  # After this has run, the file counter should be back down to a low number.
  def file_counter_rollover_test(counter)
    # Randomly pick a mode to use for the rolling over.
    rand_test_mode = ["photo","video","burst","timelapse"][rand(4)]
    set_tc_name("#{@test_file}_file_counter_rollover_test_(#{rand_test_mode})")
    # Now swap to burst mode to get close to the 9999 limit without going over.
    # Also setup to do 30 pictures per burst.
############################################################################################################
##### HEY ACTUALLY I AM TAKING OVER THIS BIT OF CODE TO JUST SET THE FILE COUNTER BACK TO A LOW NUMBER #####
############################################################################################################
log_warn("file_counter_rollover_test: HELP I HAVE BEEN HIJACKED TO RESET THE FILE COUNTER TO A LOW NUMBER!")
    if counter > 9000 #####<=9968
      ret, msg = @camera.set_capture_mode("BURST")
      (log_fail(msg); exit! 1) unless ret
      ret, msg = @camera.set_multi_photo_burst("30_1")
      (log_fail(msg); exit! 2) unless ret
    end # if
    # Take bursts until we're too close to do bursts.
    while counter > 9000 #####<= 9968
      @camera.start_capture()
      sleep(4)
      @camera.stop_capture()
      sleep(1)
      counter, msg = get_last_file_counter()
    end # while
########################## TO HERE
    # Now take single images until we ##### BLAH BLAH BLAH....
#####    if counter <= 9997
      
#####    end
  end # file_counter_rollover_test


  # This is the limited test that the wifi cameras can run.
  # The plan is to make it do four folder fillings, one for each mode.
  # If it gets to a good state for a file counter test, it'll do one of those too.
  # A good state is one with a high file counter, which happens every now and then.
  def runtest_limited()

    if false ##### true ##### false
      ml = @camera.get_medialist()
      ml.each { |x| puts x }
      return nil
    end # if

    # Run the following four times, once for each mode.
    ["photo","video","burst","timelapse"].each do |capture_mode|

    set_tc_name("#{@test_file}_runtest_limited_#{capture_mode}")

    # Blow away existing files.
    # Do we NEED to do this for each mode, or just once at the start?
    # There might be stray full folders that would ruin this test.
    # Those stray folders will be gone for the next mode anyway...
    ret, msg = @camera.delete_all_media()
    (log_fail(msg); exit! 1) unless ret
log_info("Deleted all media")

    # Take one picture to get the file counter.
    # We need to make sure we won't hit the file counter limit during the test.
    ret, msg = @camera.set_capture_mode("PHOTO")
    (log_fail(msg); exit! 2) unless ret
    @camera.start_capture()
    sleep(1)
    @camera.stop_capture()
    sleep(1)
    counter, msg = get_last_file_counter()
    (log_fail(msg); exit! 3) unless counter
log_info("Took image. counter: #{counter}")

    # If we're going to hit the file counter limit, run a file counter rollover test.
    if counter > 9000 # IT'S OVER NINE THOUSAND!
log_info("Doing a file counter rollover test, because now is a good time for that.")
      file_counter_rollover_test(counter)
    end

    # We need the folder names.
    ml = @camera.get_medialist()
    msg = "Could not get medialist for initial folder name."
    (log_fail(msg); exit! 4) unless ml and ml.length > 0
    this_folder = ml.last[0..7]
    next_folder, msg = get_next_folder(this_folder)
    (log_fail(msg); exit! 5) unless next_folder
log_info("Folder names found: #{this_folder} and #{next_folder}")

    # Now swap to burst mode to get near 999 DCF objects "quickly".
    # Also setup to do 30 pictures per burst.
    ret, msg = @camera.set_capture_mode("BURST")
    (log_fail(msg); exit! 6) unless ret
    ret, msg = @camera.set_multi_photo_burst("30_1")
    (log_fail(msg); exit! 7) unless ret
log_info("Went to BURST mode.")

    # Count the DCF objects in this folder.
    dcf_count, msg = get_dcf_count(this_folder)
    (log_fail(msg); exit! 8) unless dcf_count
log_info("DCF COUNT: #{dcf_count}")

    # Take chunks of 30 pictures via burst mode until we get close to the 999 DCF files limit.
    while dcf_count < 968
log_info("Starting BURST capture for 30 more DCF objects.")
      @camera.start_capture()
      sleep(4)
      @camera.stop_capture()
      sleep(1)
      dcf_count, msg = get_dcf_count(this_folder)
      (log_fail(msg); exit! 9) unless dcf_count
#      ml = @camera.get_medialist #####
#      ml.each { |x| puts x } #####
log_info("DCF COUNT: #{dcf_count}")# (#{this_folder})")
    end
log_info("Done with BURST chunks.")

    # Swap to photo mode to get to 999 DCF objects exactly.
    ret, msg = @camera.set_capture_mode("PHOTO")
    (log_fail(msg); exit! 10) unless ret
log_info("Went to PHOTO mode.")

    # Take pictures via photo mode until we get right up to the limit of 999 DCF objects.
    while dcf_count < 998
log_info("Starting PHOTO capture for single DCF objects.")
      @camera.start_capture()
      sleep(1)
      @camera.stop_capture()
      sleep(1)
      dcf_count, msg = get_dcf_count(this_folder)
      (log_fail(msg); exit! 11) unless dcf_count
log_info("DCF COUNT: #{dcf_count}")
    end # while
log_info("Done with single captures.")
      
    # Swap to the right mode and capture until we hit the DCF 999 limit and need to move to a new folder.
    ret, msg = @camera.set_capture_mode(capture_mode.upcase)
    (log_fail(msg); exit! 12) unless ret
log_info("Switched to #{capture_mode} mode")

    # Take a few (4) more captures.
    ##### The count and durations here need adjusting based on the capture_mode.
    ##### One capture for burst mode is enough. The others can do a few. For now.
    ((capture_mode=="burst")?(1):(4)).times do ##### FIX ME
log_info("Doing a few more captures...")
      @camera.start_capture()
      sleep(11) ##### FIX ME
      @camera.stop_capture()
#      last_media = @camera.get_last_media(((capture_mode="video")?("MP4"):("JPG")), hash=false)
    end # do
  
    # Validate that that last one was in the next folder.
    ##### Actually we need to do better than that. The last one might be, but was the second one?
    ##### Also, what about file numbering checks for files in the new folder?
    ml = @camera.get_medialist()
puts "GOT MEDIALIST. LAST: #{ml.last}"
    # What is the last folder?
    new_folder = ml.last[0..8]
puts "NEW FOLDER: #{new_folder}"
    if new_folder != next_folder
      log_fail("Folder mismatch! #{new_folder} #{next_folder}")
    else 
      log_pass("PASS! Folders match!")
    end # if

    end # each capture_mode
  end # runtest_limited

  def runtest_full()
    ["photo","video"].each do |capture_mode|
      set_tc_name("#{@test_file}_runtest_full_#{capture_mode}_clean_slate")
      ret, msg = @camera.clean_slate_and_set_file_counter(998)
      (log_fail(msg); exit! 1) unless ret
      ret, msg = @camera.set_capture_mode(capture_mode.upcase)
      (log_fail(msg); exit! 1) unless ret
      4.times { @camera.easy_capture(capture_mode) }
      dump_full_medialist()
    end # each capture_mode
  return nil #####

# FOLDERS
# All folders are named xxxGOPRO where xxx is in 100-999
#$ validate this after new folder made for 999 DCF objects in STARTUP
#$ validate this after new folder made for 9999 DCF object in STARTUP
# Each folder shall have no more than 999 DCF objects.
# If 999GOPRO exists and it has 999 DCF objects, the next non-existant folder is used.
# - Should that folder also hit 999 DCF objects, the next non-existant folder is used.
# - This repeats until all 899 folders exist, after which NO CAPTURE. (NEW FOLDER logic)

# STARTUP
# On startup, camera sets the folder to use based on the following rules:
# - Starts in the lowest folder with less than 999 DCF objects. (non-FULL folders)
# - - EXCEPT if that folder has a DCF object with file number 9999 in it!
# - - This exception declares that folder as being FULL even without 999 DCF objects.
# - If all folders are FULL (either with 999 DCFs or they have a #9999 file), NO CAPTURE.
# === SKIPPING 3D folder names.
# Maximum limit of 999 DCF objects in any folder.

# FILES
# All file names fit DCIM/vvvGOPRO/xxxxyyyy.zzz
# - vvv is the folder number in 100 to 999.
# - xxxx is GOPR for PHOTO and VIDEO.
# - xxxx is Gnnn for BURST and TIMELAPSE, where nnn is a group number in 001-999.
# === SKIP xxxx conventions for all other modes.
# - zzz is in [JPG, LRV, THM, MP4]
# - yyyy is the file number, 0001-9999.
# File number always counts up for the modes in this test.
# File number never resets unless a factory reset happens.
# Same file number for LRV and THM as the matching MP4 is all one DCF object.

# TIMELAPSE
# Should the file number roll over while doing timelapse, the group number too.
# I assume that the folder counter will as well, thus NEW FOLDER logic applies here.

# BURST
# Very special case: If current folder has so many DCF objects...
# that a burst would go over the 999 DCF objects limit...
# the burst is captured in a new folder per the NEW FOLDER logic.
# Each burst shares a group number.

# ROLLOVER RULES
# When file number rollsover, group number and folder number do too.
# When group number rolls over, folder number does too. File number does NOT rollover!
# To be clear: "folder number rolls over" means it does the NEW FOLDER logic.

    set_tc_name("#{@test_file}_runtest")

    @camera.set_capture_mode("BURST")
    @camera.easy_capture("multi")
    dump_full_medialist() #####
 
    return nil #####

    ret, msg = clean_slate_and_set_file_counter(9995)
    (log_fail(msg); exit! 1) unless ret
    file_make("100GOPRO", "G9989995.JPG")
    sleep(1)
    @camera.do_reset()
    disable_power_save()
    @camera.set_capture_mode("BURST")
    easy_capture(5)
    dump_full_medialist() #####
    easy_capture(5)
    dump_full_medialist() #####

    return nil ##### BAIL OUT

    
#    ret, msg = @camera.set_capture_mode("VIDEO") #"PHOTO")
#    (log_fail(msg); exit! 2) unless ret
    easy_capture(3)
    dump_full_medialist() #####
    easy_capture(3)
    dump_full_medialist() #####

    ret, msg = clean_slate_and_set_file_counter(4567)
    (log_fail(msg); exit! 1) unless ret
    easy_capture(3)
    dump_full_medialist() #####
    easy_capture(3)
    dump_full_medialist() #####

    ret, msg = clean_slate_and_set_file_counter(9999)
    (log_fail(msg); exit! 1) unless ret
    easy_capture(3)
    dump_full_medialist() #####
    easy_capture(3)
    dump_full_medialist() #####

  end # runtest_full

#####
  def runtest_testrails_cases()
    # C334599: File Naming > Encode Tests > Video - Single Chapter
    set_tc_name("#{@test_file}_C334599")
    res, msg = @camera.delete_all_media()
    (log_fail(msg); exit! 1) unless res
    ret, msg = @camera.set_capture_mode("VIDEO")
    (log_fail(msg); exit! 2) unless res
    easy_capture(11)
    easy_capture(11)
  end # runtest_testrails_cases

#####
  def runtest_custom()
    [["PHOTO","JPG",3],["VIDEO","MP4",11]].each do |msd|
      mode = msd[0]
      suffix = msd[1]
      duration = msd[2]
      tc_prefix = "#{@test_file}_runtest_#{mode.downcase}_"

      # Start the camera in a clean state.
      set_tc_name "#{tc_prefix}clean_state"
      res, msg = @camera.delete_all_media()
      (log_fail(msg); exit! 1) unless res
      # So figure out why this factory reset doesn't reset the file counter.
      # A factory reset is the only thing that should reset it!
      # Maybe this isn't a "real" factory reset?
      res, msg = @camera.do_factory_reset("USER")
      (log_fail(msg); exit! 2) unless res
      act = get_full_medialist()
      exp = []
      (log_fail "Medialist values do not match. Act: #{act} Exp: #{exp}"; exit! 3) if act != exp
      log_pass "Camera obtained a clean state."

      # Take that first capture.
      set_tc_name("#{tc_prefix}first_capture")
      ret, msg = @camera.set_capture_mode(mode)
      (log_fail(msg); exit! 1) unless res
      easy_capture(duration)
      act = get_full_medialist()
      exp = ["100GOPRO\GOPR0001.#{suffix}"]
      (log_fail "Medialist values do not match. Act: #{act} Exp: #{exp}"; exit! 2) if act != exp
      log_pass "First capture created correct file."
    end # each msd

  end # runtest_custom
#####

  def cleanup()
    set_tc_name("#{@test_file}_cleanup")
  end # cleanup

  # Useful for debugging, but probably not something you want to keep around.
#####
  def dump_full_medialist
    puts ""
    puts "FULL MEDIA LIST:"
    get_full_medialist.each { |x| puts x }
    puts ""
  end # dump_full_medialist
#####

end # Test

# Monkey patch the camera-side interface functions in.
# Be sure to relocate these if they're useful elsewhere.
# This sure makes it easy, right?
class SerialCamera < Camera

  # What follows are some of the functions needed to get the above working.
  # Most of these rely on SerialCamera#send_serial, and so are only good for serial cameras.

  # Get the list of all valid top-level folders on the camera.
  # Can also get a list of all top-level folders, valid or not.
  # There is currently no equivallent function in camera interfaces.
  def get_all_folders(only_valid_folders=true)
    # List the folders.
    send_serial("ls C:\\DCIM\\*")
    # Read the response.
    resp = read_serial_resp() # May need more time?
    if only_valid_folders
      # Pull out and return just the valid folders.
      valid_folders = resp.scan(/...GOPRO/)
      return valid_folders
    else
      # Pull out and return all the folders.
      all_folders = []
      # Find them based on the brackets, but then remove the brackets.
      # This logic could be improved. Maybe take the last text on lines starting with d-?
      resp.scan(/\[.*\]/).each { |x| all_folders << x.gsub(/[\[\]]/,"") }
      return all_folders
    end
  end # get_all_folders

  # Pull the "full" list of files from all top-level folders.
  # This will skip subdirectories!
  # DCF specs declare subdirectories are ok, so long as they do not share the name of a file.
  def get_full_medialist(suffix=nil, only_valid_folders=true)
    dirs = get_all_folders(only_valid_folders)
    return [] if dirs == nil
    return [] if dirs.length == 0
    # Get files for each directory found.
    retval = []
    dirs.each do |dir|
      # Skip these cases.
      next if dir == "."
      next if dir == ".."
      # Get a list of files in this directory.
      # This is basically the code from get_medialist.
      # You might want to just call get_medialist when you merge this...
      send_serial("ls C:\\DCIM\\#{dir}\\*")
      data = ""
      10.times do
        resp = read_serial_resp(limit=2.0)
        data += resp
        break if resp.match(/a:.>/) != nil
      end # 10 times
      lines = data.split("\r\n")
      # Work magic and pull out file names.
      lines.each do |f|
        f.delete!("\u0000")
        fields = f.split()
        next if fields.length == 0
        next if fields[0][0] != "f" # Files only, skip directories.
        (ltp_log($VERB, "Skipping #{f}"); next) if fields.length < 7
        fname = fields[6]
        # Skip non-matching suffix (if specified).
        next if suffix != nil and suffix != fname[-suffix.length..-1]
        retval << ["C:", "DCIM", dir, fname].join("\\")
      end # each lines
    end # each dirs
    return retval
  end # get_full_medialist

  # Sure, it's nice to abstract these one-liners, but do you really want/need to?
  def file_make(folder, file)
    send_serial("dmesg rtos -1 > C:\\DCIM\\#{folder}\\#{file}")
  end # file_make

  def file_exists?(folder, file)
    get_full_medialist.include?("C:\\DCIM\\#{folder}\\#{file}")
  end # file_exists?

  def file_delete(folder, file)
    send_serial("rm C:\\DCIM\\#{folder}\\#{file}")
  end # file_delete

  def folder_make(folder)
    send_serial("mkdir C:\\DCIM\\#{folder}")
  end # folder_make

  def folder_exists?(folder)
    get_all_folders(false).include?(folder)
  end # folder_exists?

  # Because... sanity? Could replace calls to this in the testcases...
  def easy_capture(capture_mode, duration=11.0)
    start_video_capture() if capture_mode == "video"
    start_photo_capture() if capture_mode == "photo"
    start_multi_capture() if capture_mode == "multi"
    sleep(duration)
    stop_video_capture() if capture_mode == "video"
    stop_photo_capture() if capture_mode == "photo"
    stop_multi_capture() if capture_mode == "multi"
    sleep(1.0)
  end # easy_capture

  # Am I even using this? #####
  def file_numbers(file)
    log_warn("The logic behind file_numbers() could be improved.") #####
    ret = {} ##### I don't know if I like this.
    ret[:folder] = file.match(/...GOPRO/).gsub(/GOPRO/,"").to_i
    ret[:group] = file.match(/G\d\d\d/)
    ret[:group] = ret[:group].gsub(/G/,"").to_i if ret[:group] != nil
    ret[:file] = file.match(/\d\d\d\d\./).gsub(/\./,"").to_i
    ret[:suffix] = file.match(/\..../).gsub(/\./,"")
    return ret
  end # file_numbers

  # Removes all media and does an "ALL" factory reset, but...
  # The next file encoded will have the number you passed in! (In folder 100GOPRO/)
  # This allows this test to run no matter what the current camera state is.
  def clean_slate_and_set_file_counter(to_number)
    # Bail if this number is invalid.
    if to_number <= 0 or to_number > 9999 or (not to_number.is_a? Integer)
      msg = "Invalid value passed to clean_slate_and_set_file_counter()"
      log_warn(msg); return false, msg
    end # if
    ltp_log($INFO, "Cleaning the camera's state, and setting the file counter.")
    ret, msg = delete_all_media(); return ret, msg unless ret
    ret, msg = do_factory_reset("ALL"); return ret, msg unless ret
    disable_power_save()
    # No need to do anything more if 0001 is the desired file number.
    unless to_number == 1
      spoof = (to_number-1).to_s.rjust(4,"0") # Pads with 0's.
      folder_make("100GOPRO")
      file_make("100GOPRO", "GOPR#{spoof}.JPG")
      ret, msg = do_reset(); return ret, msg unless ret
      disable_power_save()
      ret, msg = delete_all_media(); return ret, msg unless ret
      sleep(3)
    end
    msg = "File counter set successfully to: #{to_number.to_s.rjust(4,"0")}"
    ltp_log($INFO, msg)
    return true, msg
  end # clean_state_and_set_file_counter

end # Test

if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :save_dir, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOG_LEVEL = $LL_VERB if options[:verb] == true
        options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end

