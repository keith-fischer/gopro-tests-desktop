# test_preview_bitrate.rb
# Test the preview bitrates

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()

  end

  def runtest

    #test_params = tu_get_video_all_res  # OBSOLETE
    test_params = tu_get_video_res_with_protune()

    if test_params[0].empty? && test_params[1].empty? && test_params[2].empty? && test_params[3].empty?
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end

    test_params.each { |settings|
      next if settings.empty?
      settings.each { |video_mode, pt, res, fps, fov|

        protune_str = (pt == "ON") ? "protune_" : ""
        
        @camera.get_preview_resolutions().each { |prev_res|
          @camera.get_preview_bitrates(prev_res).each  { |prev_br|

            set_tc_name("preview_#{prev_res}_res_#{prev_br}_bitrate_#{video_mode}_#{protune_str}#{res}_#{fps}_#{fov}")

            @camera.set_capture_mode("VIDEO")
            log_info("Setting camera to #{video_mode}/#{res}/#{fps}/#{fov}")
            ret, msg = @camera.set_video(video_mode.upcase, res, fps, fov)
            (ret == false) ? (fail(msg); next) : log_info(msg)

            log_info("Setting preview resolution to #{prev_res}")
            ret, msg = @camera.set_preview_resolution(prev_res)            
            (ret == false) ? (fail(msg); next) : log_info(msg)
            sleep 2

            log_info("Setting preview bitrate to #{prev_br}")
            ret, msg = @camera.set_preview_bitrate(prev_res, prev_br)
            (ret == false) ? (fail(msg); next) : log_info(msg)
            sleep 2

            ret, msg = getTSFile
            (ret == false) ? (fail(msg); next) : log_info(msg)

            ret, calculated_bitrate = getCalculatedDeltaPVBitrate(prev_res, prev_br, msg)

            ret ? pass : fail("bitrate (#{calculated_bitrate}) is not within 25 percent of #{@camera.preview[prev_res][:bitrate][prev_br]}")

          }
        }
      }
    }

  end # end test_preview

  def getTSFile
    amba_m3u8_location = "#{@options[:save_dir]}/amba.m3u8"

    FileUtils.rm(amba_m3u8_location) if File.exists?(amba_m3u8_location)

    ts_location = "#{@options[:save_dir]}/#{Time.now.strftime("%Y-%m-%d_%H_%M_%S")}.ts"

    rs = @camera.http_get("http://#{@camera.ip}:#{@camera.http_port}/live/amba.m3u8")

    if rs.code == '200'
      open(amba_m3u8_location, 'wb'){|file| file.write(rs.body)}
    else
      return false, "Unable to download ts file: amba.m3u8"
    end

    #    result = system("wget #{amba_m3u8_http} -P #{logs_dir}")
    #    return "Unable to download amba.m3u8", nil if !result

    tsfile = `tail -n1 #{amba_m3u8_location} | grep amba_hls`

    rs = @camera.http_get("http://#{@camera.ip}:#{@camera.http_port}/live/#{tsfile}")

    if rs.code == '200'
      open(ts_location, 'wb'){|file| file.write(rs.body)}
    else
      return  false, "Unable to download ts file: #{tsfile}"
    end

    #        ts_http = "http://#{c.host}:#{c.file_server_port}/live/#{tsfile}"
    #        result = system("wget -O #{ts_location} #{ts_http}")
    #    return "Unable to download ts file: #{tsfile}", nil if !result

    #    system("curl #{ts_http} >> #{ts_location}")
    return true, ts_location

  end

  def getCalculatedDeltaPVBitrate(rv_key, bv_key, ts_location)
    outfile = "#{@options[:save_dir]}/#{File.basename(ts_location)}.264"

    cmd = "ffmpeg -y -i #{ts_location} -vcodec copy -an -f h264 #{outfile}"
    #    puts "COMMAND #{cmd} \t RESULT #{result[0]}"

    o,e,s = Open3.capture3(cmd)

    bitrate = /bitrate=(?<bitrate>\s*\d+[.]\d+)kbits\/s/.match(e)[:bitrate]
    duration = /time=(?<time>\d{2}[:]\d{2}[:]\d{2}[.]\d+)/.match(e)[:time]
    actual_res = /(?<res>\d{3,6}[x]\d{3,6})/.match(e)[:res]

    size = File.size(outfile)

    # b/s
    calculated_bitrate = ((size * 8)/(Time.parse(duration).usec/1000000.0)).round(2)

    #    value_delta = (calculated_bitrate - Settings.pv_bitrate[rv_key][bv_key].to_i).round(2)
    value_delta = (calculated_bitrate - @camera.preview[rv_key][:bitrate][bv_key].to_i).round(2)
    #    percentage_delta = ((calculated_bitrate / Settings.pv_bitrate[rv_key][bv_key].to_i) - 1).round(2)
    percentage_delta = ((calculated_bitrate / @camera.preview[rv_key][:bitrate][bv_key].to_i) - 1).round(2)

    if percentage_delta > 0.25 || percentage_delta < -0.25
      return false, calculated_bitrate
    else
      return true, calculated_bitrate
    end
=begin
    percentage_delta > 0.25 || percentage_delta < -0.25? compliant = "NO" : compliant = "YES"

    info = "#{capture_mode},#{rv_key},#{bv_key},#{calculated_bitrate},#{actual_res},#{Settings.pv_bitrate[rv_key][bv_key]},#{value_delta},#{percentage_delta},#{compliant}"

    if compliant == "NO"
      return info, true
    else
      return info, false
    end
=end
  end

  def cleanup
  end
end # end Test class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [ :ip, :pc, :serial,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only, :video_protune,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :setup_orientation, :shuffle, :set_defaults, :dryrun, :save_dir ]
    options = t.parse_options(ARGV, use_options)
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
