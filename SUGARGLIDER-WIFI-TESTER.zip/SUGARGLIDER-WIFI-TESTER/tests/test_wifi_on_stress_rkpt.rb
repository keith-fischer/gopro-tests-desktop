require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  #This test is for ROCKYPOINT only

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("test_wifi_on_stress_rkpt_setup")
    @host = Host.new
    @camera = tu_get_camera()
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil

    if @camera.name() != "ROCKYPOINT"
      puts("This test is for ROCKYPOINT only!!! Exiting...")
      exit 1
    end

    set_options()
  end

  def runtest
    default_iter = 10
    iter = @options[:n_iter].to_i if @options[:n_iter] != nil
    default_dur = 330
    dur = @options[:duration].to_i if @options[:duration] != nil
    if @options[:duration_range_low] and @options[:duration_range_high]
      dur = rand(@options[:duration_range_low]..@options[:duration_range_high])
      log_info("Using a duration of #{dur}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
    end
    if iter == nil
      log_warn("# Iterations not set.  Running with default of #{default_iter}")
      iter = default_iter
    end

    set_tc_name("Power_on_#{iter}_iterations")
    log_info("Running test for #{iter} iterations")
    (1..iter).each { |n|
      log_info("Iteration #{n}. Powering on.")

      #Turning camera on
      result = @camera.api2_camera_power_on_ok?
      if result == false
        log_fail("Unable to turn camera on")
        exit ExitCode::CAMERA_OFF
      end
      sleep(5)
      @camera.send_status_api2 
      #Turning preview on
      @camera.send_live_stream_start_v2     
      sleep(2)
      @camera.send_status_api2 
      
      if dur == nil
        log_warn("Duration not set. Running with default of #{default_dur}")
        dur = default_dur
      end
      log_info("Sleeping for #{dur} seconds")
      sleep(dur)
    }
    log_pass("Successfully powering on #{iter} iterations at #{dur} seconds each time")
  end

end # class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  $exitcode = 0
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev,
      :logfile, :verb, :n_iter, :duration,
      :setup_default_mode, :setup_led, :setup_beep, :setup_orientation]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    #    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
