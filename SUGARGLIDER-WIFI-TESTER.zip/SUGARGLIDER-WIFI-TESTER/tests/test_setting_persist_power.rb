# test_media_list.rb

require_relative './test_setting_persist_modes.rb'

class PowerTest < Test
  #include TestUtils
  def initialize
    super
  end

  # This function overrides the one from the _modes test.
  def setups_tc_name
    @is_power_test = true
    "#test_settings_persist_power_setup"
  end

  def runpowertest
    # Test the various mode settings using the _mode test.
    # Since @is_power_test is true, it will cycle the power for us.
    runtest
    # The additional code for testing setup menu items will go here.
    # Yes: Video Mode, Default Mode, Beep Volume, Number of LEDs
    # Maybe: Orientation, On Screen Display Enabled, Date & Time settings.
  end # runpowertest

  # An easy method to call to toggle the camera's power.
  def toggle_power(iteration_number)
    set_tc_name("power_cycle_iteration_#{iteration_number}")
    if @camera.interfaces.include?(:wifi)
      result = toggle_power_off_on_via_wifi()
    else
      result = toggle_power_off_on_via_serial()
    end
    if result == false
      log_fail("Camera did not toggle power successfully")
      @camera.detect_crash_and_reboot() if @camera.interfaces.include?(:serial)
    else
      log_pass("Toggled power successfully.")
    end
    return result
  end # toggle_power

  # We also need to include the functions that actually toggle the power.
  # These come from test_power_off_on.rb.
  def toggle_power_off_on_via_wifi(timeout=30)
    return api2_toggle_power_off_on if @camera.remote_api_version() == 2
    # true = power ON, false = power OFF
    curr_state = @camera.get_bacpac_status(:camera_power)
    if curr_state == true
      @camera.set(:power_pw, "OFF", wait_time=5, decode=false,
      expected=nil, tries=2, interval=5, target="bacpac")
    end
    start_time = Time.now()
    @camera.set(:power_pw, "ON", wait_time=3, decode=false,
    expected=nil, tries=2, interval=5, target="bacpac")
    elapsed = 0
    # Wait first for bacpac to detect camera powered
    while true
      elapsed = Time.now() - start_time
      break if @camera.get_bacpac_status(:camera_power) == true
      return false if elapsed > timeout
      sleep 1.0
    end
    # Then wait for camera to report status OK
    while true
      elapsed = Time.now() - start_time
      break if @camera.get_status(:ok) == true
      return false if elapsed > timeout
      sleep 1.0
    end
    elapsed = Time.now() - start_time
    return elapsed
  end # toggle_power_off_on_via_wifi

  def api2_toggle_power_off_on()
    @camera.send_camera_sleep_api2
    sleep(5)
    # RP/Hal need an extra 5 seconds.  curl was coming back true
    sleep(5) if ["ROCKYPOINT", "HALEIWA","HIMALAYAS"].include?(@camera.name)
    return @camera.api2_camera_power_on_ok?
  end #api2_toggle_power_off_on

  def toggle_power_off_on_via_serial(timeout=30)
    start_time = Time.now()
    ret, msg = @camera.do_reset(force=false)
    if ret == true
      result = Time.now() - start_time
    else
      log_warn(msg)
      result = false
    end
    return result
  end # toggle_power_via_serial

end # PowerTest

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = PowerTest.new
    use_options = [:ip, :pc, :serialdev, :battoutlet,
      :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov,
      :photo_resolution, :photo_continuous,
      :multi_photo_burst, :multi_photo_timelapse, :full,
      :setup_default_mode, :setup_led, :setup_beep,
      :video_spot_metering, :setup_orientation,
      :shuffle, :set_defaults, :dryrun, :verb]

    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runpowertest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
