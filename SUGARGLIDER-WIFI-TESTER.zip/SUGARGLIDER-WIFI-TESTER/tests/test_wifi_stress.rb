require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  #This test is for all cameras

  def setup(options)
    @options = options
    @test_file = __FILE__
    #set_tc_name("test_wifi_stress")
    @host = Host.new
    @camera = tu_get_camera()

    set_options()
  end

  def runtest

    default_iter    = 1000
    default_dur     = 1      # delay between wifi bounces in seconds
    max_wifi_errors = 3
    gpErrors        = 0
    gpStatus        = false

    iter = @options[:n_iter].to_i if @options[:n_iter] != nil
    if iter == nil
      log_info("n_iter not set. Running with default of #{default_iter}")
      iter = default_iter
    end

    dur = @options[:duration].to_i if @options[:duration] != nil
    if @options[:duration_range_low] and @options[:duration_range_high]
      dur = rand(@options[:duration_range_low]..@options[:duration_range_high])
      log_info("Using a duration of #{dur}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
    end
    if dur == nil
      log_info("Duration not set. Running with default of #{default_dur}")
      dur = default_dur
    end

    set_tc_name("Wifi Stress Bounce #{iter}_iterations")

    log_info("Running test for #{iter} iterations")


    (1..iter).each { |n|

      log_info("Iteration #{n} Bouncing host's WiFi...")

      # Bounce the wifi
      @host.bounce_wifi()

      log_info("Sleeping for #{dur} seconds")
      sleep(dur)

      # gpStatus is either "false" or non-nil pointer to JSON hash
      gpStatus = @camera.http_gpcontrol_check
      log_verb("gpControl/status=#{gpStatus}")
      if gpStatus != false
        gpErrors = 0
        log_info("PASS iteration# #{n}")
        next 
      else
        s = "Unable to communicate from host to camera (#{@ip})"
        sleep 5.0
        log_warn(s)
        gpErrors += 1
        if gpErrors >= max_wifi_errors
          log_warn("Reached #{gpErrors} ERRORS")
          break # FAIL TEST if we reach MAX errors errors
        end
      end

    } # iteration loop

    if gpStatus == false
      s = "Unable to communicate from host to camera (#{@ip})"
      log_warn(s)
      log_fail("wifi stress had #{gpErrors} errors")
      #fail()
    else
      log_pass("Successfully bounced wifi for #{iter} iterations at #{dur} seconds each time")
      #pass()
    end

  end  # runtest


end # class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  $exitcode = 0
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev,
      :logfile, :verb, :n_iter, :duration,
      :setup_default_mode, :setup_led, :setup_beep, :setup_orientation]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    #    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
