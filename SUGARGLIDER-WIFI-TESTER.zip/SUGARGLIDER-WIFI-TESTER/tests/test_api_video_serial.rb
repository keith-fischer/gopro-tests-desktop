# test_api_video_serial.rb
# Description: Runs through all RES/FPS/FOV combinations setting
#   all three and then checking they were set correctly.
#   Optionally can --shuffle them and run for many --iterations
#
require 'set'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file} setup")
    @host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    #    @camera.delete_all_media()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()
  end

  def runtest()
    iterations = @options[:n_iter].to_i
    n = 0
    while true
      # Enumerate all the test combinations
      test_params = []
      @camera.get_video_resolution().each do |res|
        next if @options[:video_resolution] != nil and @options[:video_resolution] != res
        @camera.get_video_fps(res).each do |fps|
          next if @options[:video_fps] != nil and @options[:video_fps] != fps
          next if !@camera.video_protune_support?(res, fps)
          @camera.get_video_fov(res, fps).each do |fov|
            next if @options[:video_fov] != nil and @options[:video_fov] != fov
            test_params << [res, fps, fov]
          end # fov
        end # fps
      end # res

      if test_params.length == 0
        log_warn("No tests to run!  Check script options")
        return
      end
      test_params.shuffle! if @options[:shuffle]
      prev_res, prev_fps, prev_fov = nil, nil, nil
      test_params.each { |res, fps, fov|
        log_info("Adding test [#{res}, #{fps}, #{fov}]")
      }

      # Set the capture parameters (optionally shuffling)
      test_params.each { |r, fs, fv|
        set_tc_name("#{r}_#{fs}_#{fv}")
        log_info("Setting #{r}/#{fs}/#{fv}")
        n += 1
        arr = [1,2,3,4]
        arr.shuffle! if @options[:shuffle]
        vm = (@camera.is_ntsc?(r, fs)) ? "NTSC" : "PAL"
        arr.each { |i|
          # Args are (hash, key, wait_time, verify)
          @camera.set(@camera.video_mode, vm, 2.0, false) if i == 1
          @camera.set(@camera.vid_res, r, 1.0, false) if i == 2
          @camera.set(@camera.fps, fs, 1.0, false) if i == 3
          @camera.set(@camera.fov, fv, 1.0, false) if i == 4
        }

        # Now check that the expected values are there
        failed_arr = []
        result = nil
        failed_arr << assert(@camera.is_alive?, "Camera is crashed")

        2.times {
          @camera.send_serial(@camera.vid_res[:get])
          result = @camera.expect(@camera.vid_res[r], timeout=2)
          break if result != nil
        }
        failed_arr << assert(result != nil, "Camera RES was not set to #{r} successfully")

        2.times {
          @camera.send_serial(@camera.fps[:get])
          result = @camera.expect(@camera.fps[fs], timeout=2)
          break if result != nil
        }
        failed_arr << assert(result != nil, "Camera FPS was not set to #{fs} successfully")

        2.times {
          @camera.send_serial(@camera.fov[:get])
          result = @camera.expect(@camera.fov[fv], timeout=2)
          break if result != nil
        }
        failed_arr << assert(result != nil, "Camera FOV was not set to #{fv} successfully")

        next if has_failure?(failed_arr)
        pass("Capture mode set successfully")

        break if iterations != nil and n >= iterations
      }

      break if iterations == nil or n >= iterations
    end # while true
  end # runtest

  def cleanup

  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:serialdev, :battoutlet, :usboutlet,
      :video_resolution, :video_fps, :video_fov,
      :setup_beep, :shuffle, :n_iter, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
