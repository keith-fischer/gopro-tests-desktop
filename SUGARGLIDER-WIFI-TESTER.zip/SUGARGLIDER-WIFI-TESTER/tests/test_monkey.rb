# Monkey test
#
# Description: Resets the camera to defaults and randomly triggers
#     the SHUTTER and POWER buttons to exercise the camera in 
#     random ways.  This test is Wi-Fi ONLY and Hero3/3+ ONLY
# Options: 
#    [--iterations N]   Number of steps to perform
#    [--duration SECS]  Length of time to for which to run
#    [--quick]          Drive the test faster
#    [--shuffle SEED]   Set the random seed to SEED
#    [--beep 0]         Turn off the beep sound

require 'pp'
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Monkey
  include LogUtils
  def initialize(seed, camera, options)
    @c          = camera
    @seed       = seed
    @iterations = options[:n_iter].to_i
    @duration   = options[:duration]
    if options[:duration_range_low] and options[:duration_range_high]
      @duration = rand(options[:duration_range_low]..options[:duration_range_high])
      log_info("Using a duration of #{@duration}. Range is (#{options[:duration_range_low]}..#{options[:duration_range_high]}).")
    end
    @log_file   = options[:log_file]
    @quick      = options[:quick]
    @quiet      = options[:beep] == 0
    
    @count = 1
    # Track how many steps back the last good settings dump was
    @stepsback = 0
    # Make sure we have a camera class with a wireless_settings_screen
    begin
      @wireless_screen = @c.screens[:wireless_settings]
      log_info("Found wireless settings screen in camera object")
    rescue StandardError
      log_warn("No wireless settings screen found in camera object")
      log_warn("Skipping screen detection")
      @wireless_screen = nil
    end
  end

  def on_wireless_screen?()
    return false if @wireless_screen == nil
    curr_screen = @c.get_lcd_section(0)
    return false if curr_screen == false
    return (curr_screen[:data] == @wireless_screen)
  end

  def dump_current_settings()
    if @c.curr_status == nil
      log_error("Unable to print last-known camera settings (nil)")
    else
      if @stepsback > 0
        log_warn("Last-known camera settings are from #{@stepsback} steps back")
      else
        log_warn("Last known camera settings;")
      end
      pp @c.decoded_curr_status
      File.open(@log_file, 'a') { |f| PP.pp(@c.decoded_curr_status, out=f) } \
        if @log_file != nil
     end
  end

  def toggle_power()
    log_info("Step #{@count} - Toggling POWER")
    t = (@quick == nil) ? 4.0 : 1.0
    @c.set(:power_pw, "TOGGLE", wait_time=t, decode=false)
  end
  
  def toggle_shutter()
    log_info("Step #{@count} - Toggling SHUTTER")
    t = (@quick == nil) ? 4.0 : 1.0
    @c.set(:shutter_sh, "TOGGLE", wait_time=t, decode=false)

    if @c.busy?
      # Photo or Burst, just wait for it to finish
      if [1, 2].include?(@c.status(:mode)) # Photo or Burst
        @c.wait_until_not_busy(interval=1.0, timeout=30.0)
      else
        sleep(5 + Random.rand(10))  # Encode for U(5, 15) seconds
      end
    end
  end
  
  # Start the monkey
  def run()
    srand @seed
    start_time = Time.now()
    begin
      # Fill in camera initial status structure
      log_info("Camera OK? %s" %(@c.ok?))
      while true do
        # Handle quiet_mode
        if @quiet and @c.status(:beeping_sound) != 0
          @c.set(:setup_beep, 0, wait_time=1.0, decode=false)
        end
        # Skip past wireless settings screen
        if on_wireless_screen?
          log_info("Skipping Wireless settings screen... ")
          @c.set(:power_pw, "TOGGLE", wait_time=1.0, decode=false)
        end
        
        # Take a random step
        p = rand(0..1)
        if p == 0
          toggle_power()
        else
          toggle_shutter()
        end
        @count += 1
        
        # Check camera status (causing it to update @c.curr_status)
        @c.ok? ? @stepsback = 0 : @stepsback += 1
        @c.update_decoded_status
        
        # Get multek if in mirroring mode
##        puts @c.get_multek if $mirror
        
        # Check if we should break
        break if @iterations != nil and @count > @iterations
        break if @duration != nil and (Time.now() - start_time) > @duration
      end
    rescue StandardError=>e
      t = Time.now
      log_warn("Current time: %s (lasted %s seconds)" %[t, (t - start_time).to_i])
      log_warn("Reason: %s" %e.to_s)
      log_warn(e.backtrace.join("\n"))
      dump_current_settings
      return false, "Monkey execution loop unexpectedly exited at step #{@count}"
    end
    return true, "Monkey execution loop finished #{@count} steps successfully"
  end # run
end # class Monkey
  
class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file} setup")
    @host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    @camera.delete_all_media()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip], 
                         @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    set_options()
    @seed = options[:seed]
    @seed = srand >> 100 if (@seed == nil or @seed == false)
    
    # Reset defaults
    # set_defaults()
  end
  
  def runtest
    set_tc_name("#{@test_file}-executing")
    log_info("Using seed #{@seed}")
    monkey = Monkey.new(@seed, @camera, @options)
    ret, msg = monkey.run()
    ret == true ? log_pass(msg) : log_fail(msg)
  end
  
  def cleanup
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :beep,
      :battoutlet, :usboutlet, :reset_on_failure,
       :n_iter, :duration, :quick, :shuffle, :verb
    ]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
