# test_media_download.rb

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include Test_utils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit! 1
    end
    @camera.delete_all_media()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    set_options()
  end

  def runtest

    download_video if @options[:download_video] == true

    download_photo if @options[:download_single_photo] == true

    download_burst if @options[:download_burst] == true

    download_time_lapse if @options[:download_time_lapse] == true

    if @options[:download_continuous] == true
      download_sps if @camera.photo_continuous_support? == true
    end
    #TODO
    #download_piv if @camera.video_piv_support? == true

  end # end runtest

  def download_video

    test_params = tu_get_video_all_res()

    if test_params[0].empty? && test_params[1].empty? && test_params[2].empty? && test_params[3].empty?
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end

    # Now run each test
    duration = (@options[:duration] != nil) ?  options[:duration] : 5 #seconds

    test_params.each() { |r|
      next if r.empty?
      r.each {|vm, p, res, fps, fov|
        vm = vm.upcase
        protune_str = (p == "ON") ? "_protune" : ""

        set_tc_name("#{vm}_#{res}_#{fps}_#{fov}#{protune_str}")

        log_info("Capturing #{duration} seconds video")
        ret, msg = @camera.capture_video(vm, p, res, fps, fov, duration, retries=1)
        (ret == false) ? (fail(msg); next) : log_info(msg)

        # Otherwise copy the file over
        log_info("Downloading media")
        cur_video = @camera.get_last_media("MP4", hash=false)
        to_dir = tu_get_download_dir(@options[:save_dir], res, fps, fov)

        ret, msg = @camera.download_media(cur_video, to_dir)

        if ret == false
          fail(msg)
          next
        else
          # Verify MP4's field of view is really what it says (expected value
          # saved in metadata). This test can only be done when MP4 is local.
          ret = tu_analyze_mp4_fov(msg, fov)
          log_pass if !has_failure?(ret)
        end
      }
    }# end test_params

  end

  def download_photo
    test_params = []

    # Capture images
    @camera.get_photo_resolutions().each { |res|
      next if @options[:photo_resolution] != nil and @options[:photo_resolution] != res
      set_tc_name("#{res}_single_photo")
      @camera.delete_all_media()
      ret, msg = @camera.capture_photo_single(res, retries=2)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      resp, msg = download("single", res, nil)
      fail(msg) if resp == false
      log_pass
    }

  end

  def download_burst
    # Get the parameters for all test cases.  Shuffle if necessary
    test_params = []
    @camera.get_photo_resolutions.each { |res|
      next if @options[:photo_resolution] != nil and @options[:photo_resolution] != res
      @camera.get_multi_photo_burst_rates(res).each { |burst|
        next if @options[:multi_shot_burst] != nil and @options[:multi_shot_burst] != burst
        log_verb("Adding test [#{res}, burst=#{burst}]")
        test_params << [res, burst]
      }
    }
    log_warn("No tests to run!  Check RES/BURST chosen") if test_params == []
    test_params.shuffle! if @options[:shuffle]

    test_params.each { |res, burst|
      set_tc_name("#{res}_burst_#{burst}")
      @camera.delete_all_media()

      ret, msg = @camera.capture_photo_burst(res, burst)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      resp, msg = download("burst", res, burst)
      resp == false ? fail(msg) : log_pass
    }
  end

  def download_time_lapse
    test_params = []
    @camera.get_photo_resolutions.each { |res|
      next if @options[:photo_resolution] != nil and @options[:photo_resolution] != res
      @camera.get_multi_photo_timelapse_rates(res).each { |pes|
        next if @options[:multi_shot_timelapse] != nil and @options[:multi_shot_timelapse].to_s != pes.to_s
        log_verb("Adding test [#{res}, time-lapse=#{pes}]")
        test_params << [res, pes]
      }
    }

    min_photos = @options[:min_pes_pho].to_i
    min_length = @options[:min_pes_len].to_i

    test_params.each { |res, pes|
      set_tc_name("#{res}_time_lapse_#{pes}")
      @camera.delete_all_media()

      ret, msg = @camera.capture_photo_timelapse(res, pes, min_photos, min_length)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      resp, msg = download("pes", res, pes)
      resp == false ? fail(msg) : log_pass
    }
  end

  #continuous shots
  def download_sps
    test_params = []
    @camera.get_photo_resolutions().each { |res|
      next if @options[:photo_resolution] != nil and @options[:photo_resolution] != res
      @camera.get_photo_continuous_rates(res).each { |sps|
        next if @options[:photo_continuous] != nil and @options[:photo_continuous] != sps
        log_verb("Adding test [#{res}, continuous-shots=#{sps}]")
        test_params << [res, sps]
      }
    }

    # Capture images
    test_params.each { |res, sps|
      set_tc_name("#{res}_sps_#{sps}")
      @camera.delete_all_media()
      ret, msg = @camera.capture_photo_continuous(res, sps, duration=1.0)
      (ret == false) ? (fail(msg); next) : log_info(msg)

      resp, msg = download("sps", res, sps)
      resp == false ? fail(msg) : log_pass
    }
  end

  #photo-in-video (JPG only)
  def download_piv

  end

  def download(type, res, value)
    base_dir = @options[:save_dir]
    # Gets the full directory path for downloads
    # Path will be /base_dir/res/mode/value_str (e.g. /tmp/5MED/burst/3_1)
    log_info("Downloading media")
    full_dir = tu_get_download_dir(base_dir, res, type, value)
    @camera.download_all_media(full_dir, stop_after=nil)
  end

  def cleanup
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev,
      :photo_resolution, :photo_burst, :photo_timelapse, :photo_continuous,
      :video_resolution, :video_fps, :video_fov, :video_protune, :ntsc_only, :pal_only, :duration,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun,
      :download_video, :download_single_photo, :download_burst, :download_time_lapse, :download_continuous]
    options = t.parse_options(ARGV, use_options)
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue Exception => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
