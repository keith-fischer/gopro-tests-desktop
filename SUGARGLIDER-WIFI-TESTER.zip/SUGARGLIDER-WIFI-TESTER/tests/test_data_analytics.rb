require_relative '../libs/data_analytics_events'
require_relative '../libs/data_analytics_decode'
require_relative '../libs/data_analytics'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/camera'
require_relative '../libs/test_utils'
require_relative '../libs/dlipower'

class Test < TestCase
  include Data_analytics_decode
  include Data_analytics_events
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    @outfile = nil;
    set_tc_name("#{@test_file} setup")
    if @options[:ip] == nil
      log_error("Must specify ip address (--ip)")
      exit 1
    elsif @options[:pc] == nil
      log_error("Must specify pairing code (--pc)")
      exit 1
    end

#    @camera = get_wifi_camera(@options[:ip], @options[:pc])
    @camera = tu_get_camera()
    # If camera is able to offload analytics file only using Wi-Fi, do it
    if (@camera.name == "ROCKYPOINT" and @camera.build > "00.37") or \
       (@camera.name == "HALEIWA" and @camera.build > "00.26") or \
       (@camera.name == "HIMALAYAS" and @camera.build > "00.00") or \
       (["PIPE", "BACKDOOR"].include?(@camera.name) and @camera.build > "02.01.04")
       @wifi_offload = true
    else
      @wifi_offload = false
    end

    if @wifi_offload == false
      if @options[:serialdev] == nil
        log_error("Camera can't offload logs only using Wi-Fi." + \
          "Must specify serial device (--serial)")
        exit 1
      else
        @sercam = get_serial_camera(@options[:serialdev])
      end
    else
      @sercam = nil
    end

    @host = Host.new()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil

    if @options[:analytic_version] == nil
      @ana_ver = @camera.analytics_version
    else
      @ana_ver = @options[:analytic_version]
    end
    @analytics = DataAnalytics.new(@ana_ver, @camera.name)
    load_ver(@ana_ver)
    @filter = @options[:filter]

    @last_matched_event = [nil] * 10
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  # Some events change between versions
  def load_ver(ver)
    case ver
    when "0.0.0"
      @quick_capture_event  = "FLAG_1"
      @osd_event            = "FLAG_1"
      @video_format_event   = "FLAG_1"
      @video_protune_event  = "FLAG_2"
      @lowlight_event       = "FLAG_2"
      @video_sharpness_event = "FLAG_4"
      @video_color_event    = "FLAG_2"
      @flag_4_event         = "FLAG_4"
    when "0.1.0", "0.2.1"
      @quick_capture_event  = "USER_SETTINGS"
      @osd_event            = "USER_SETTINGS"
      @video_format_event   = "USER_SETTINGS"
      @video_protune_event  = "VIDEO_PROTUNE_SETTINGS"
      @lowlight_event       = "USER_SETTINGS"
      @video_sharpness_event = "VIDEO_PROTUNE_SETTINGS"
      @video_color_event    = "VIDEO_PROTUNE_SETTINGS"
      @flag_4_event         = "VIDEO_PROTUNE_SETTINGS"
    end
  end

  def runtest
    case @camera.name
    when "PIPE", "BACKDOOR"
      @fname = "data_analytics.bin"
      @capture_modes = ["VIDEO", "VIDEO_PIV", "VIDEO_LOOPING", "VIDEO_TIMELAPSE",
                        "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT",
                        "BURST", "TIMELAPSE", "NIGHTLAPSE"]
      @protune_modes = @capture_modes
      @default_modes = @capture_modes
      @fullpath = "c:\\misc\\data_analytics.bin"
      runlist = runlist_hawaii()
      @has_default_mode = true
    when "ROCKYPOINT"
      @fname = nil # Use the camera default (RP_data_temp.bin)
      @capture_modes = ["VIDEO", "VIDEO_LOOPING", "PHOTO", "BURST", "TIMELAPSE"]
      @protune_modes = ["VIDEO"]
      @default_modes = @capture_modes
      @fullpath = nil # Use camera defaults
      runlist = runlist_rockypoint()
      @has_default_mode = true
      # For legacy reasons, camera reports looping value 1 in status
      # even when it is off (it correctly writes the startup event as OFF)
      # so we need to check both OFF and 5 as looping values at startup
      @looping_kludge = true
    when "HALEIWA"
      @fname = nil # Use the camera default
      @capture_modes = ["VIDEO", "PHOTO", "BURST", "TIMELAPSE"]
      @protune_modes = []
      @default_modes = @capture_modes
      @fullpath = nil
      runlist = runlist_haleiwa()
      @has_default_mode = false
      @looping_kludge = true
    when "HIMALAYAS"
      @fname = nil # Use the camera default
      @capture_modes = ["VIDEO", "PHOTO", "BURST", "TIMELAPSE"]
      @protune_modes = []
      @default_modes = @capture_modes
      @fullpath = nil
      runlist_himalayas()
      @has_default_mode = false
      @looping_kludge = true
    else
      log_error("Unsupported camera type: #{@camera.name} for data analytics script")
      return false
    end
    runlist.each { |r|
      begin
        if @filter == nil or r.to_s.match(@filter)
          method(r).call()
        else
          log_info("Skipping #{r} based on filter (#{@filter})")
        end
      rescue WifiCameraError
        log_fail("Lost communication with camera")
        tu_reset_camera()
      # rescue StandardError => e
      #   log_fail("General error: #{e.to_s}")
      #   puts e.backtrace.join("\n")
      #   tu_reset_camera()
      end
    }
    return true
  end

  def runlist_hawaii()
    [
      :verify_startup_params,
      :verify_log_restore,
      :verify_camera_mode_wifi,
      :verify_camera_default_mode,
      :verify_video_format,
      :verify_video_res,
      :verify_video_fps,
      :verify_video_fov,
      # :verify_p_button, if @sercam != nil
      # :verify_s_button, if @sercam != nil
      # :verify_menu_button, if @sercam != nil
      # :verify_shutter,
      :verify_wifi_off_on,
      :verify_wifi_mode,
      :verify_low_light,
      :verify_video_looping,
      :verify_video_piv,
      # :verify_low_battery,      # Causes reboot that cuts Wi-Fi
      # :verify_over_temp,        # Causes reboot that cuts Wi-Fi
      # :verify_ring_buffer,
      :verify_protune_state,
      :verify_spot_meter,
      :verify_white_balance,
      :verify_color,
      :verify_iso_video,
      :verify_video_protune_shutter_speed,
      :verify_iso_mode_video,
      :verify_iso_photo_min,
      :verify_iso_photo_max,
      :verify_iso_multi_shot_min,
      :verify_iso_multi_shot_max,
      :verify_sharpness,
      :verify_protune_exposure,
      :verify_photo_res,
      :verify_continuous_setting,
      :verify_night_photo_exp_setting,
      :verify_night_lapse_exp_setting,
      :verify_burst_setting,
      :verify_time_lapse_interval,
      :verify_night_lapse_interval,
      :verify_orientation,
      :verify_quick_capture,
      :verify_lcd_brightness,
      :verify_lcd_sleep_timer,
      :verify_locate,
      :verify_osd,
      :verify_led_blink,
      :verify_beep_volume,
      :verify_auto_off,
      :verify_delete_last,
      :verify_delete_all,
      :verify_hilight_tag,
      :verify_media_counters,
      :verify_hilight_tag_capture_media_types,
      :verify_protune_reset,
      :verify_datetime,
    ]
  end

  def runlist_rockypoint()
    [
      :verify_startup_params,
      :verify_log_restore,
      :verify_camera_mode_wifi,
      :verify_looping_mode_rp,
      :verify_camera_default_mode,
      :verify_video_format,
      :verify_video_res,
      :verify_video_fps,
      :verify_video_fov,
      :verify_video_fps_ntsc_pal_switch,
      :verify_protune_capture_mode_switch,
      # :verify_p_button, # Can we fake button presses on RP?
      # :verify_s_button, # And will it hit the event logging code?
      # :verify_menu_button,
      :verify_shutter,
      :verify_wifi_off_on,
      :verify_wifi_mode,
      :verify_low_light,
      :verify_locate,
      :verify_video_looping,
      :verify_protune_state,
      :verify_iso_video,
      :verify_sharpness,
      :verify_spot_meter,
      :verify_photo_res,
      :verify_burst_setting,
      :verify_time_lapse_interval,
      :verify_orientation,
      :verify_led_blink,
      :verify_beep_volume,
      :verify_delete_last,
      :verify_delete_all,
      :verify_hilight_tag,
      :verify_media_counters,
      :verify_hilight_tag_capture_media_types,
      :verify_protune_reset,
      :verify_datetime,
      # # freeform_actions,
      # # just_view_events()
    ]
  end

  def runlist_haleiwa()
    [
      :verify_startup_params,
      :verify_log_restore,
      :verify_camera_mode_wifi,
      :verify_camera_default_mode,
      :verify_video_format,
      :verify_video_res,
      :verify_video_fps,
      # :verify_p_button, # Can we fake button presses on RP/Hal?
      # :verify_s_button, # And will it hit the event logging code?
      # :verify_menu_button,
      :verify_shutter,
      :verify_wifi_off_on,
      :verify_wifi_mode,
      :verify_low_light,
      :verify_video_looping,
      :verify_spot_meter,
      :verify_burst_setting,
      :verify_time_lapse_interval,
      :verify_orientation,
      :verify_lcd_brightness,
      :verify_lcd_sleep_timer,
      :verify_led_blink,
      :verify_beep_volume,
      :verify_hilight_tag,
      :verify_media_counters,
      :verify_datetime,
      # freeform_actions,
      # just_view_events,
    ]
  end

  def runlist_himalayas()
    [
      :verify_hilight_tag,  # HLWA-1585  TBD: enable this changes are ported over
      :verify_startup_params,
      :verify_log_restore,
      :verify_camera_mode_wifi,
      :verify_camera_default_mode,
      :verify_video_format,
      :verify_video_res,
      :verify_video_fps,
      # :verify_p_button, # Can we fake button presses on RP/Hal?
      # :verify_s_button, # And will it hit the event logging code?
      # :verify_menu_button,
      :verify_shutter,
      :verify_wifi_off_on,
      :verify_wifi_mode,
      :verify_low_light,
      :verify_video_looping,
      :verify_spot_meter,
      :verify_burst_setting,
      :verify_time_lapse_interval,
      :verify_orientation,
      :verify_led_blink,
      :verify_beep_volume,
      :verify_media_counters,
      :verify_datetime,
      # freeform_actions,
      # just_view_events,
    ]
  end

  def process_data(filename)
    log_info("Parsing analytics file #{filename}")
    events = []
    f = File.open(filename, "r")
    while f.eof? == false
      # Parse the timestamp (unpack as binary)
      ts_bin = f.read(4)
      ts = ts_bin.unpack('B8B8B8B8').reverse.join
      y, mon, d = ts[0..5], ts[6..9], ts[10..14]
      h, min, s = ts[15..19], ts[20..25], ts[26..31]

      # Parse the event (unpack as hex)
      ev = f.read(4).unpack('H*')[0]
      name, p1, p2, p3 = ev[0..1], ev[2..3], ev[4..5], ev[6..7]

      ### Needed for a while on RKPT/HAL since they 0xFF pad files.
      if ts_bin == "\xff\xff\xff\xff" or \
        (name == "ff" and p1 == "ff" and p2 == "ff" and p3 == "ff")
        log_warn("Breaking due to EOF (0xFF) timestamp or event")
        break
      end

      tr_ev = @analytics.translate_entry(y, mon, d, h, min, s, name, p1, p2, p3)
      log_verb(ts_bin.unpack('H*')[0] + ev)
      log_verb("%s/%s/%s %s:%s:%s, event=%s, p1=%s, p2=%s, p3=%s" % tr_ev)

      # Verify the timestamp validity
      ret, msg = @analytics.validate_timestamp(*tr_ev[0..5])
      log_warn(msg) if ret == false

      # If any events were unrecognized, throw a warning (FAIL, maybe?)
      tr_ev[6..9].each { |x|
        if x.to_s.match("UNKNOWN") != nil
          log_warn("Possible bad event (code=#{name}, p1=#{p1}, p2=#{p2}, p3=#{p3})")
          break
        end
      }
      events << tr_ev
    end
    f.close()
    return events
  end

  # Translates mode into the p2 values VIDEO/PHOTO/MULTI_SHOT
  def get_style(m)
    return "VIDEO" if ["VIDEO", "VIDEO_PIV", "VIDEO_LOOPING", "VIDEO_TIMELAPSE"].include?(m)
    return "PHOTO" if ["PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"].include?(m)
    return "MULTI_SHOT" if ["BURST", "TIMELAPSE", "NIGHTLAPSE"].include?(m)
    log_warn("get_style() unrecognized mode #{m}")
    return nil
  end

  def get_analytics_events()
    # Use Wi-Fi only to get analytics file if possible
    lcl_f = false
    if @wifi_offload == true
      3.times { |n|
        log_verb("Try num #{n}")
        @outfile = "/tmp/analytics.bin"
        # wget signature is (url, local_file, overwrite?)
        lcl_f = @host.wget(@camera.get_analytics_url, @outfile, true)
        log_verb("lcl_f== #{lcl_f}")
        break if lcl_f != false
        sleep 5
      }
    # Otherwise use combination of serial and wi-fi to get it
    else
      ret, msg = @sercam.dump_analytics(@fname)
      return false, msg if ret == false
      # Strip off the drive letter and add to URL for SD card contents
      url = File.join("http://#{@camera.ip}:#{@camera.http_port}/videos", msg.split("\\")[1..-1])
      # url = "http://%s:%s/videos/MISC/%s" %[@camera.ip, @camera.http_port, @fname]
      3.times {
        lcl_f = @host.wget(url, "/tmp", true)
        break if lcl_f != false
        sleep 3.0
        log_verb("Retry wget...")
      }
    end
    if lcl_f == false or lcl_f == nil
      return false, "Unable to download #{url}"
    else
      return true, process_data(lcl_f)
    end
  end

  def clear_analytics()
    if @filter != nil
      log_info("Skipping clear() based on usage of filter")
      return
    end
    # Use Wi-Fi only to clear analytics file if possible
    if @wifi_offload == true
      resp = @camera.clear_analytics
      ret, msg = false, "Clear analytics had bad HTTP response"
      ret, msg = true, "Analytics cleared" if @camera.http_resp_ok(resp)
    # Otherwise use combination of serial and wi-fi to get it
    else
      log_info("Clearing analytics buffer and deleting file")
      ret, msg = @sercam.del_analytics(@fullpath)
      ret == true ? log_verb(msg) : log_warn(msg)
      @sercam.clear_analytics_buffer()
    end
    ret == true ? log_verb(msg) : log_warn(msg)
    return
  end

  # Type-aware matching
  def match(x, y, strict)
    # puts "MATCH(#{x}, #{y})"
    if x.is_a?(Fixnum) and y.is_a?(Fixnum)
      return x == y
    else
      x = x.to_s if x.is_a?(String) == false
      y = y.to_s if y.is_a?(String) == false
      # Strict comparison is exact
      return x == y if strict == true
      # Otherwise compare with string::match()
      return x.match(y) != nil
    end
  end

  # Returns true if a matching event is found in @events
  # ev_name - The :name of the event (see data_analytics_events.rb)
  # p1val, p2val, p3val - the values to match up ("*" means wild-card)
  # del - delete the matching event from the events list
  def verify_event(ev_name, p1val, p2val, p3val, del=true, strict=false)
    p1val = @analytics.unused if p1val == nil
    p2val = @analytics.unused if p2val == nil
    p3val = @analytics.unused if p3val == nil
    log_verb("Trying to match event=#{ev_name}, p1=#{p1val}, p2=#{p2val}, p3=#{p3val}")
    ret = false
    idx = nil
    @events.each_with_index { |entry, index|
      y, mon, d, h, min, s, name, p1, p2, p3 = entry
      log_debug("got timestamp #{y}, #{mon}, #{d}, #{h}, #{min}, #{s}")
      log_debug("verify_event: ev_name=#{ev_name}, p1val=#{p1val}, name=#{name}, p1=#{p1}")
      # p name, p1, p2, p3
      next if (name != ev_name)
      next if (p1val != "*" and match(p1, p1val, strict) != true)
      next if (p2val != "*" and match(p2, p2val, strict) != true)
      next if (p3val != "*" and match(p3, p3val, strict) != true)
      ret = true
      idx = index
      @last_matched_event = entry
      break
    }
    if ret == true
      str = "Matching event found: #{ev_name} | p1=#{p1val} | p2=#{p2val} | p3=#{p3val}"
      if idx != nil and del == true
        @events.delete_at(idx)
      end
    else
      str = "No matching event: #{ev_name} | p1=#{p1val} | p2=#{p2val} | p3=#{p3val}"
    end
    return ret, str
  end

  # Find a matching event, but it must not match any non-nil parameters
  def verify_param_not(ev_name, p1val, p2val, p3val, del=true, strict=false)
    ret = false
    idx = nil
    @events.each_with_index { |entry, index|
      y, mon, d, h, min, s, name, p1, p2, p3 = entry
      log_debug("got timestamp #{y}, #{mon}, #{d}, #{h}, #{min}, #{s}")
      next if (name != ev_name)
      next if (p1val != nil and p1.match(p1val) != nil)
      next if (p2val != nil and p2.match(p2val) != nil)
      next if (p3val != nil and p3.match(p3val) != nil)
      ret = true
      idx = index
      break
    }
    if ret == true
      log_verb("Matching event with non-matching params found: #{@events[idx]}")
      if idx != nil and del == true
        @events.delete_at(idx)
      end
    else
      log_verb("No event with non-matching params found")
    end
    return ret
  end

  def freeform_actions()
    set_tc_name("freeform")
    clear_analytics()
    sleep(1.0)
    puts "Perform actions for 30 seconds"
    sleep(30.0)
    retval, msg = get_analytics_events()
    log_fail(msg) if retval == false
  end

  def just_view_events()
    set_tc_name("just_viewing")
    retval, msg = get_analytics_events()
    log_fail(msg) if retval == false
  end

  def verify_startup_params()
    set_tc_name("startup_params")
    clear_analytics()
    sleep(1.0)
    @camera.send_camera_sleep_api2
    sleep(10.0)
    @camera.api2_camera_power_on_ok?
    retval, msg = get_analytics_events()
    log_fail(msg) if retval == false
    # Analytics file was success
    @events = msg

    sz=File.size(@outfile)
    log_verb("#{@outfile} sz=#{sz}")
    # Data Log version
    set_tc_name("data_log_version")
    p1, p2, p3 = @ana_ver.split(".").map { |m| m.to_i.to_s }
    ret, msg = verify_event("DATA_LOG_VERSION", p1, p2, p3)
    s = @last_matched_event[7..9].join(".")
    (ret == false) ? log_fail(msg) : log_pass("Data log version: #{s}")

    # Camera Model
    set_tc_name("camera_model")
    ret, msg = verify_event("CAMERA_MODEL", @camera.data_log_model, nil, nil)
    s = @last_matched_event[7]
    (ret == false) ? log_fail(msg) : log_pass("Camera model: #{s}")

    # Firmware version
    set_tc_name("firmware_version")
    if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
      maj = @camera.type.to_i
      min, rev = @camera.build.split(".").map { |n| n.to_i }
    else
      maj, min, rev = @camera.build.split(".").map { |n| n.to_i }
    end
    ret, msg = verify_event("FIRMWARE_VERSION", maj, min, rev)
    s = @last_matched_event[7..9].join(".")
    (ret == false) ? log_fail(msg) : log_pass("Firmware version: #{s}")

    # Charging status
    # Usually our cameras are plugged in (="ON")
    # But may or may not be full already (="CHARGING/NOT_CHARGING")
    # So we accept any value "*" for p2
    set_tc_name("initial_charging_state")
    ret, msg = verify_event("POWER_CHARGING_STATUS", "*", "*", "*")
    s = @last_matched_event[7..8].join("--")
    (ret == false) ? log_fail(msg) : log_pass("Initial charging state: #{s}")

    # Wi-Fi status
    set_tc_name("initial_wifi_state")
    ret, msg = verify_event("WIFI_CONNECTION_STATUS", "ON", "CONNECTED", "*")
    s = @last_matched_event[6..9].join("--")
    (ret == false) ? log_fail(msg) : log_pass(s)

    # Initial default camera mode
    set_tc_name("initial_default_camera_mode")
    if @has_default_mode == false
      log_skip("Camera does not have default mode setting")
      exp_mode = "VIDEO"
    else
      def_mode = @camera.get_setting_name_by_sym_api2(:setup_default_mode, refresh=true)
      exp_mode = nil
      if @ana_ver < "0.2.0"
        exp_mode = def_mode
      else
        mode_cmd = nil
        if def_mode == "VIDEO"
          mode_cmd = :video_submode
        elsif def_mode == "PHOTO"
          mode_cmd = :photo_submode
        elsif def_mode == "MULTI_SHOT"
          mode_cmd = :multi_photo_submode
        end

        if mode_cmd == nil
          log_warn("Unrecognized top-level default mode #{def_mode}. Try to verify directly")
          exp_mode = def_mode
        else
          begin
            curr_mode = @camera.get_setting_name_by_sym_api2(mode_cmd, refresh=false)
            exp_mode = curr_mode
          rescue
            log_warn("Unable to lookup mode from '#{mode_cmd}' symbol.")
          end
        end
      end # ana_ver >= "0.2.0"
    end # @has_default_mode

    if exp_mode != nil
      ret, str = verify_event("DEFAULT_MODE", exp_mode, nil, "CAMERA")
      s = @last_matched_event[6..7].join("--")
      (ret == false) ? log_fail(str) : log_pass(s)
    else
      log_fail("Unable to determine default mode.  Script error.")
    end

    # Initial camera mode (should == default mode)
    set_tc_name("initial_camera_mode")
    ret, str = verify_event("CAMERA_MODE", exp_mode, nil, "*")
    s = @last_matched_event[6..7].join("--")
    (ret == false) ? log_fail(str) : log_pass(s)

    # Beep sound
    set_tc_name("initial_beep_sound")
    val = "BEEP_" + @camera.get_setting_name_by_sym_api2(:setup_beep, refresh=false)
    ret, str = verify_event("BEEP_SOUND", val, nil, "CAMERA")
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial beep sound: #{s}")

    # Initial LED Blink
    set_tc_name("initial_led_blink")
    val = @camera.get_setting_name_by_sym_api2(:setup_led, refresh=false)
    ret, str = verify_event("LED_BLINK", val, nil, "CAMERA")
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial LED blink: #{s}")

    # Initial battery level
    set_tc_name("initial_battery_level")
    ret, str = verify_event("BATTERY_LEVEL", "*", nil, nil)
    s = @last_matched_event[7]
    log_warn("Is value #{s} really correct???  Double-check it.") if s == "10_PERCENT"
    (ret == false) ? log_fail(str) : log_pass("Initial battery level: #{s}")

    # Initial Camera Accessory
    set_tc_name("initial_camera_accessory")
    ret, str = verify_event("CAMERA_ACCESSORY", "*", "*", "CAMERA")
    (ret == false) ? log_fail(str) : log_pass("Initial camera accessory event seen")

    # Initial flag_1
    if @ana_ver < "0.1.0"
      set_tc_name("initial_flag_1")
      ret, str = verify_event("FLAG_1", "*", "*", "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Flag 1: #{s}")
    end

    # Audio Input
    if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name) == false
      set_tc_name("initial_audio_input")
      ret, str = verify_event("AUDIO_INPUT", "*", nil, "*")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial audio input: #{s}")
    end

    # Initial Video Res
    set_tc_name("initial_video_res")
    val = @camera.get_setting_name_by_sym_api2(:video_resolution, refresh=false)
    vid_submode = @camera.get_setting_name_by_sym_api2(:video_submode, refresh=false)
    if @ana_ver >= "0.2.0"
      ret, str = verify_event("VIDEO_RESOLUTION", val, vid_submode, "CAMERA")
    else
      ret, str = verify_event("VIDEO_RESOLUTION", val, nil, "CAMERA")
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial video resolution: #{s}")

    # Initial Video FPS
    set_tc_name("initial_video_fps")
    val = @camera.get_setting_name_by_sym_api2(:video_fps, refresh=false)
    if @ana_ver >= "0.2.0"
      ret, str = verify_event("FRAMES_PER_SECOND", val, vid_submode, "CAMERA")
    else
      ret, str = verify_event("FRAMES_PER_SECOND", val, nil, "CAMERA")
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial FPS: #{s}")

    # Initial Video FOV
    set_tc_name("initial_video_fov")
    val = @camera.get_setting_name_by_sym_api2(:video_fov, refresh=false)
    if @ana_ver >= "0.2.0"
      ret, str = verify_event("FIELD_OF_VIEW", val, vid_submode, "CAMERA")
    else
      ret, str = verify_event("FIELD_OF_VIEW", val, nil, "CAMERA")
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial FOV: #{s}")

    # Initial Video looping
    set_tc_name("initial_video_looping")
    val = @camera.get_setting_name_by_sym_api2(:video_looping, refresh=false)
    ret, str = verify_event("LOOPING_VALUE", val, nil, "CAMERA")
    if @looping_kludge
      ret2, str2 = verify_event("LOOPING_VALUE", "OFF", nil, "CAMERA")
      log_debug("ret1=#{ret}, ret2=#{ret2}, str1=#{str}, str2=#{str2}")
      ret ^= ret2 # XOR.  Exactly one must be true
      str = "Unable to match LOOPING_VALUE, OFF/5, NOT_USED, CAMERA"
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial video looping: #{s}")

    # Initial Video time-lapse interval
    if @camera.video_timelapse_support? == true
      set_tc_name("initial_video_time_lapse_interval")
      val = @camera.get_setting_name_by_sym_api2(:video_timelapse, refresh=false)
      ret, str = verify_event("TIME_LAPSE_INTERVAL", val, "VIDEO", "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial video time-lapse interval: #{s}")
    end

    # Initial Photo Res
    set_tc_name("initial_photo_resolution")
    val = @camera.get_setting_name_by_sym_api2(:photo_resolution, refresh=false)
    if @ana_ver >= "0.2.0"
      photo_sub_mode = @camera.get_setting_name_by_sym_api2(:photo_submode, refresh=false)
      ret, str = verify_event("PHOTO_RESOLUTION", val, photo_sub_mode, "CAMERA")
    else
      ret, str = verify_event("PHOTO_RESOLUTION", val, nil, "CAMERA")
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial photo resolution: #{s}")

    # Initial multi-shot res
    set_tc_name("initial_multi_shot_resolution")
    if @ana_ver < "0.2.0"
      log_skip("Not applicable for analytic version < 0.2.0")
    else
      val = @camera.get_setting_name_by_sym_api2(:multi_photo_resolution, refresh=false)
      multi_sub_mode = @camera.get_setting_name_by_sym_api2(:multi_photo_submode,
        refresh=false)
      ret, str = verify_event("PHOTO_RESOLUTION", val, multi_sub_mode, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial multi_shot resolution: #{s}")
    end

    # Initial continuous shot
    if @camera.photo_continuous_support? == true
      set_tc_name("initial_continuous_shot")
      val = @camera.get_setting_name_by_sym_api2(:photo_continuous, refresh=false)
      ret, str = verify_event("CONTINUOUS_SHOT_VALUE", val, nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial continuous shot setting: #{s}")
    end

    # Initial night photo shutter exposure
    if @camera.photo_night_support? == true
      set_tc_name("initial_night_photo_shutter_exp")
      val = @camera.get_setting_name_by_sym_api2(:photo_shutter_ev, refresh=false)
      ret, str = verify_event("NIGHT_PHOTO_SHUTTER_EXPOSURE", val, nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial night photo shutter exp: #{s}")
    end

    # Initial burst value
    set_tc_name("initial_burst_value")
    val = @camera.get_setting_name_by_sym_api2(:multi_photo_burst, refresh=false)
    ret, str = verify_event("BURST_VALUE", val, nil, "CAMERA")
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial burst value: #{s}")

    # Initial time-lapse interval
    set_tc_name("initial_time_lapse_interval")
    val = @camera.get_setting_name_by_sym_api2(:multi_photo_timelapse, refresh=false)
    if @ana_ver >= "0.1.0"
      ret, str = verify_event("TIME_LAPSE_INTERVAL", val, "MULTI_SHOT", "CAMERA")
    else
      ret, str = verify_event("TIME_LAPSE_INTERVAL", val, nil, "*")
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial time-lapse interval: #{s}")

    if @camera.multi_photo_nightlapse_support? == true
      # Initial night-lapse exposure
      set_tc_name("initial_night_lapse_shutter_exp")
      val = @camera.get_setting_name_by_sym_api2(:multi_photo_shutter_ev, refresh=false)
      ret, str = verify_event("NIGHT_LAPSE_SHUTTER_EXPOSURE", "*", nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial night-lapse exposure: #{s}")

      # Initial night-lapse interval
      set_tc_name("initial_night_lapse_interval")
      val = @camera.get_setting_name_by_sym_api2(:multi_photo_nightlapse, refresh=false)
      ret, str = verify_event("NIGHT_LAPSE_INTERVAL", "*", nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial night-lapse interval: #{s}")
    end

    # Initial Spot Metering
    set_tc_name("initial_spot_metering")
    val = @camera.get_setting_name_by_sym_api2(:video_spot_metering, refresh=false)
    if @ana_ver >= "0.2.0"
      ret, str = verify_event("SPOT_METERING", val, exp_mode, "CAMERA")
    else
      ret, str = verify_event("SPOT_METERING", val, "*", "CAMERA")
    end
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial spot metering: #{s}")

    if @ana_ver >= "0.1.0"
      # User settings replaces flag 2
      set_tc_name("initial_user_settings")
      ret, str = verify_event("USER_SETTINGS", "*", "*", "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial user settings: #{s}")

      # NOTE: Removing because there is no status for 'Not updating FW' and
      # as such, this should not be logged on every boot.
      # # FW Update status replaces flag 3
      # set_tc_name("initial_fw_update")
      # ret, str = verify_event("FW_UPDATE_STATUS", "*", "*", "CAMERA")
      # s = @last_matched_event[7]
      # (ret == false) ? log_fail(str) : log_pass("Initial FW update status: #{s}")
    else
      # Initial flag 2
      set_tc_name("initial_flag_2")
      ret, str = verify_event("FLAG_2", "*", "*", "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial flag 2: #{s}")

      # Initial flag 3
      set_tc_name("initial_flag_3")
      ret, str = verify_event("FLAG_3", "*", "*", "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial flag 3: #{s}")
    end

    # Initial flag 4 / video protune settings
    set_tc_name("initial_flag_4")
    ret, str = verify_event(@flag_4_event, "*", "*", "CAMERA")
    s = @last_matched_event[7]
    (ret == false) ? log_fail(str) : log_pass("Initial flag 4: #{s}")

    if @camera.video_protune_support? == true
      # Initial white balance
      wb_vals = @camera.get_protune_white_balance()

      if wb_vals != nil and wb_vals.compact.empty? == false
        set_tc_name("initial_white_balance_video")
        val = @camera.get_setting_name_by_sym_api2(:video_pt_wb, refresh=false)
        if @ana_ver >= "0.2.0"
          ret, str = verify_event("WHITE_BALANCE_VALUE", val, curr_mode, "CAMERA")
        else
          ret, str = verify_event("WHITE_BALANCE_VALUE", val, "VIDEO", "CAMERA")
        end
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial white balance: #{s}")
      end

      # Initial video ISO
      iso_vals = @camera.get_video_protune_iso()
      if iso_vals != nil and iso_vals.compact.empty? == false
        set_tc_name("initial_video_protune_iso")
        val = @camera.get_setting_name_by_sym_api2(:video_pt_iso, refresh=false)
        ret, str = verify_event("VIDEO_PROTUNE_ISO", val, nil, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial video ISO: #{s}")
      end

      ex_vals = @camera.get_protune_exposure()
      if ex_vals != nil and ex_vals.compact.empty? == false
        # Initial exposure compensation
        set_tc_name("initial_exposure_compensation")
        val = @camera.get_setting_name_by_sym_api2(:video_pt_ev, refresh=false)
        ret, str = verify_event("EXPOSURE_COMPENSATION", val, "*", "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial exposure compensation: #{s}")
      end
    end

    if @camera.photo_protune_support? == true
      if @ana_ver <= "0.1.0"
        # Initial photo white-balance
        set_tc_name("initial_white_balance_photo")
        val = @camera.get_setting_name_by_sym_api2(:photo_pt_wb, refresh=false)
        ret, str = verify_event("WHITE_BALANCE_VALUE", val, "PHOTO", "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial white balance: #{s}")

        # Initial photo ISO
        set_tc_name("initial_photo_protune_iso")
        val = @camera.get_setting_name_by_sym_api2(:photo_pt_iso, refresh=false)
        ret, str = verify_event("PHOTO_PROTUNE_ISO", val, nil, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial photo ISO: #{s}")
      else
        # # Initial photo white-balance
        # set_tc_name("initial_white_balance_photo")
        # photo_sub_mode = @camera.get_setting_name_by_sym_api2(:photo_submode, refresh=false)
        # val = @camera.get_setting_name_by_sym_api2(:photo_pt_wb, refresh=false)
        # ret, str = verify_event("WHITE_BALANCE_VALUE", val, photo_sub_mode, "CAMERA")
        # s = @last_matched_event[7]
        # (ret == false) ? log_fail(str) : log_pass("Initial white balance: #{s}")

        # Initial photo ISO MIN
        set_tc_name("initial_photo_protune_iso_min")
        val = @camera.get_setting_name_by_sym_api2(:photo_pt_iso_min, refresh=false)
        ret, str = verify_event("PHOTO_PROTUNE_ISO_MIN", val, photo_sub_mode, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial photo ISO MIN: #{s}")

        # Initial photo ISO MAX
        set_tc_name("initial_photo_protune_iso_max")
        val = @camera.get_setting_name_by_sym_api2(:photo_pt_iso, refresh=false)
        ret, str = verify_event("PHOTO_PROTUNE_ISO_MAX", val, photo_sub_mode, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial photo ISO MAX: #{s}")
      end
    end

    if @camera.multi_photo_protune_support? == true
      if @ana_ver <= "0.1.0"
        # Initial Multi-shot White Balance
        set_tc_name("initial_multi_shot_white_balance")
        val = @camera.get_setting_name_by_sym_api2(:multi_photo_pt_wb, refresh=false)
        ret, str = verify_event("WHITE_BALANCE_VALUE", val, "MULTI_SHOT", "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial white balance: #{s}")

        # Initial photo ISO
        set_tc_name("initial_multi_shot_protune_iso")
        val = @camera.get_setting_name_by_sym_api2(:multi_photo_pt_iso, refresh=false)
        ret, str = verify_event("PHOTO_PROTUNE_ISO", val, nil, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial photo ISO: #{s}")
      else
        # # Initial Multi-shot White Balance
        # set_tc_name("initial_multi_shot_white_balance")
        # multi_sub_mode = @camera.get_setting_name_by_sym_api2(:multi_photo_submode, refresh=false)
        # val = @camera.get_setting_name_by_sym_api2(:multi_photo_pt_wb, refresh=false)
        # ret, str = verify_event("WHITE_BALANCE_VALUE", val, multi_sub_mode, "CAMERA")
        # s = @last_matched_event[7]
        # (ret == false) ? log_fail(str) : log_pass("Initial white balance: #{s}")

        # Initial Multi-shot ISO Min
        set_tc_name("initial_multi_shot_protune_iso_min")
        val = @camera.get_setting_name_by_sym_api2(:multi_photo_pt_iso_min, refresh=false)
        ret, str = verify_event("MULTI_SHOT_PROTUNE_ISO_MIN", val, multi_sub_mode, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial photo ISO MIN: #{s}")

        # # Initial Multi-shot ISO Max
        set_tc_name("initial_multi_shot_protune_iso_max")
        val = @camera.get_setting_name_by_sym_api2(:multi_photo_pt_iso, refresh=false)
        ret, str = verify_event("MULTI_SHOT_PROTUNE_ISO_MAX", val, multi_sub_mode, "CAMERA")
        s = @last_matched_event[7]
        (ret == false) ? log_fail(str) : log_pass("Initial photo ISO MAX: #{s}")
      end
    end

    # Initial photos avail
    set_tc_name("initial_photos_avail")
    exp_photos_avail = @camera.get_photos_avail()
    msb = exp_photos_avail >> 8
    lsb = exp_photos_avail & 0xFF
    ret, str = verify_event("PHOTOS_AVAILABLE", msb, lsb, nil)
    (ret == false) ? log_fail(str) : log_pass("Initial photos avail: #{exp_photos_avail}")

    # Initial photos on card
    set_tc_name("initial_photos_on_card")
    exp_n_photos = @camera.get_n_photos()
    msb = exp_n_photos >> 8
    lsb = exp_n_photos & 0xFF
    ret, str = verify_event("PHOTOS_ON_CARD", msb, lsb, nil)
    (ret == false) ? log_fail(str) : log_pass("Initial photos on card: #{exp_n_photos}")

    # Initial video mins avail
    set_tc_name("initial_video_mins_avail")
    exp_mins_avail = @camera.get_mins_avail()
    msb = exp_mins_avail >> 8
    lsb = exp_mins_avail & 0xFF
    ret, str = verify_event("VIDEO_MINS_AVAILABLE", msb, lsb, nil)
    (ret == false) ? log_fail(str) : log_pass("Initial video mins avail: #{exp_mins_avail}")

    # Initial videos on card
    set_tc_name("initial_videos_on_card")
    exp_num_videos = @camera.get_n_videos()
    msb = exp_num_videos >> 8
    lsb = exp_num_videos & 0xFF
    ret, str = verify_event("VIDEOS_ON_CARD", msb, lsb, nil)
    (ret == false) ? log_fail(str) : log_pass("Initial videos on card: #{exp_num_videos}")

    if ["PIPE", "ROCKYPOINT", "HIMALAYAS"].include?(@camera.name) == false
      # Initial LCD volume
      set_tc_name("initial_lcd_volume")
      ret, str = verify_event("LCD_VOLUME", "*", nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial LCD volume: #{s}")

      # Initial LCD brightness
      set_tc_name("initial_lcd_brightness")
      val = @camera.get_setting_name_by_sym_api2(:setup_lcd_brightness, refresh=false)
      ret, str = verify_event("LCD_BRIGHTNESS", val, nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial LCD brightness: #{s}")

      # Initial LCD sleep
      set_tc_name("initial_lcd_sleep")
      val = @camera.get_setting_name_by_sym_api2(:setup_lcd_auto_off, refresh=false)
      ret, str = verify_event("LCD_SLEEP", val, nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial LCD sleep: #{s}")
    end

    if @ana_ver >= "0.2.0"
      set_tc_name("initial_shutter_speed")
      val = @camera.get_setting_name_by_sym_api2(:video_pt_shutter_speed, refresh=false)
      ret, str = verify_event("VIDEO_PROTUNE_SHUTTER_SPEED", val, nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial Video Shutter Speed: #{s}")
    end

    # Manufacturing Date
    set_tc_name("manufacturing_date")
    ret, str = verify_event("MFG_DATE", "YEAR", "WEEK", nil)
    year = @last_matched_event[7]
    week = @last_matched_event[8]

    if year == nil or year == 0
      log_fail("Year (#{year}) invalid")
    else
      y = year.split("_")[1].to_i
      # Guess at the valid manufacturing years for each model
      case @camera.release
      when "HD4", "HX1", "HD3"
        min, max = 2014, 2017
      else
        min, max = 2014, 2020
      end
      if ret == false
        log_fail
      elsif y < min
        log_fail("Invalid year (#{y}) < min (#{min})")
      elsif y > max
        log_fail("Invalid year (#{y}) > max (#{max})")
        log_info("Modify test script if we are not EOL yet")
      else
        log_pass("Mfg Date : #{y}, #{week}")
      end
    end

    if @ana_ver >= "0.2.0" and ["PIPE", "BACKDOOR"].include?(@camera.name)
      # Initial Language setting
      set_tc_name("initial_language")
      ret, str = verify_event("LANGUAGE", "*", nil, "CAMERA")
      s = @last_matched_event[7]
      (ret == false) ? log_fail(str) : log_pass("Initial language: #{s}")
    end

    # # Initial
    # set_tc_name("initial_")
    # ret = verify_event("", "*", nil, "CAMERA")
    # s = @last_matched_event[7]
    # (ret == false) ? log_fail : log_pass("Initial : #{s}")

    # # External battery level
    # set_tc_name("initial_external_battery_level")
    # ret = verify_event("EXTERNAL_BATTERY_LEVEL", "*", nil, nil)
    # s = @last_matched_event[7]
    # (ret == false) ? log_fail : log_pass("Initial external battery level: #{s}")
  end

  # Verify that the log buffer persists across graceful shutdown
  def verify_log_restore()
    set_tc_name("log_restore")
    clear_analytics()
    sleep(1.0)
    @camera.set_video_format("NTSC")
    sleep(2.0)
    @camera.set_video_format("PAL")
    sleep(2.0)
    @camera.set_video_format("NTSC")
    sleep(2.0)
    @camera.send_camera_sleep_api2
    sleep(5.0)
    @camera.api2_camera_power_on_ok?
    sleep(5.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return) if retval == false
    # Analytics file was success
    @events = msg
    ret = []
    ret << verify_event(@video_format_event, "PAL", "*", "GOPRO_APP")
    ret << verify_event(@video_format_event, "NTSC", "*", "GOPRO_APP")
    if ret.include?(false)
      log_fail("Log did not persist across boots")
    else
      log_pass("Log persisted across boots")
    end
  end

  ### Deprecated in favor of the Wi-Fi version
  # def verify_camera_mode()
  #   set_tc_name("camera_mode_idle_setup")
  #   all_modes = [
  #     "VIDEO", "PHOTO", "BURST", "TIMELAPSE",
  #     "PLAYBACK", "SETTINGS", "FW_UPDATE",
  #     "MTP", "SOS",
  #     "VIDEO_PIV",
  #     "VIDEO_LOOPING",
  #     "VIDEO_TIMELAPSE", "PHOTO_CONTINUOUS", "PHOTO_NIGHT", "NIGHTLAPSE",
  #   ]
  #   clear_analytics()
  #   all_modes.each { |m|
  #     sleep(1.0)
  #     log_info("Setting camera mode #{m}")
  #     @sercam.set_capture_mode(m)
  #     sleep(3.0)
  #   }
  #   retval, msg = get_analytics_events()
  #   (log_fail(msg); return) if retval == false
  #   # Analytics file was success
  #   @events = msg
  #   all_modes.each { |m|
  #     set_tc_name("camera_mode_#{m.downcase}_idle")
  #     ret = []
  #     ret << verify_event("CAMERA_MODE", m, nil, "CAMERA")
  #     # ret << verify_event("SHUTTER_STATUS", "OFF", nil, nil)
  #     ret.include?(false) ? log_fail : log_pass
  #   }
  # end

  # Doesn't reach playback/mtp/sos/fwupdate modes
  # But better representation of how smarty would do
  def verify_camera_mode_wifi()
    @camera.set_capture_mode("PHOTO")
    sleep 3.0
    set_tc_name("camera_mode_wifi_idle_setup")
    clear_analytics()
    @capture_modes.each { |m|
      sleep(1.0)
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
    }
    retval, msg = get_analytics_events()
    (log_fail(msg); return) if retval == false
    # Analytics file was success
    @events = msg
    @capture_modes.each.each { |m|
      set_tc_name("camera_mode_#{m.downcase}_via_wifi")
      ret, msg = verify_event("CAMERA_MODE", m, nil, "*", true, true)
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_looping_mode_rp()
    @camera.set_capture_mode("PHOTO")
    sleep 3.0
    clear_analytics()
    sleep 2.0
    2.times {
      @camera.set_capture_mode("VIDEO_LOOPING")
      sleep 3.0
    }
    retval, msg = get_analytics_events()
    (log_fail(msg); return) if retval == false
    # Analytics file was success
    @events = msg
    set_tc_name("camera_mode_video_looping_via_wifi")
    ret, msg = verify_event("CAMERA_MODE", "VIDEO_LOOPING", nil, "*", true, true)
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_camera_default_mode()
    set_tc_name("default_camera_mode_setup")
    log_info("Setting initial camera default mode PHOTO")
    if ["BACKDOOR", "PIPE"].include?(@camera.name)
      @camera.set_default_mode_sub_mode("PHOTO")
    elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
      @camera.set_default_capture_mode("PHOTO")
    else
      log_skip("Camera type (#{@camera.name}) unsupported")
      return false
    end
    sleep(3.0)
    clear_analytics()
    @default_modes.each { |m|
      sleep(1.0)
      log_info("Setting camera default mode #{m}")
      if ["BACKDOOR", "PIPE"].include?(@camera.name)
        @camera.set_default_mode_sub_mode(m)
      elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
        @camera.set_default_capture_mode(m)
      else
        log_skip("Camera type (#{@camera.name}) unsupported")
      end
      sleep(3.0)
    }
    retval, msg = get_analytics_events()
    (log_fail(msg); return) if retval == false
    # Analytics file was success
    @events = msg
    @default_modes.each { |m|
      set_tc_name("default_camera_mode_#{m.downcase}")
      ret, msg =  verify_event("DEFAULT_MODE", m, nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_video_format()
    set_tc_name("video_format_setup")
    clear_analytics()
    sleep(1.0)
    @camera.set_video_format("NTSC")
    sleep(2.0)
    @camera.set_video_format("PAL")
    sleep(2.0)
    @camera.set_video_format("NTSC")
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return) if retval == false
    # Analytics file was success
    @events = msg
    set_tc_name("video_format_ntsc")
    ret, msg = verify_event(@video_format_event, "NTSC", "*", "GOPRO_APP")
    ret == false ? log_fail(msg) : log_pass(msg)
    set_tc_name("video_format_pal")
    ret, msg = verify_event(@video_format_event, "PAL", "*", "GOPRO_APP")
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_video_res()
    if @ana_ver >= "0.2.0"
      @all_modes = ["VIDEO", "VIDEO_PIV", "VIDEO_LOOPING", "VIDEO_TIMELAPSE"]
      @all_modes = ["VIDEO_TIMELAPSE"]
    else
      @all_modes = ["VIDEO"]
    end
    @all_modes.each { |mode|
      set_tc_name("camera_setting_#{mode.downcase}_res_setup")
      all_res = @camera.get_video_resolution()
      mode_str = mode
      case mode
      when "VIDEO"
        res_arr = all_res
      when "VIDEO_PIV"
        res_set = Set.new()
        all_res.each { |res|
          @camera.get_video_fps(res).each { |fps|
            res_set << res if @camera.video_piv_support?(res, fps) }}
        res_arr = res_set.to_a
      when "VIDEO_LOOPING"
        res_set = Set.new()
        all_res.each { |res|
          @camera.get_video_fps(res).each { |fps|
            res_set << res if @camera.video_looping_support?(res, fps) }}
        res_arr = res_set.to_a
      when "VIDEO_TIMELAPSE"
        res_arr = @camera.get_video_timelapse_resolution()
        mode_str = "VIDEO_TIMELAPSE"
      end

      @camera.set_capture_mode(mode)
      @camera.set_video_protune("OFF") if @camera.video_protune_support?
      @camera.set(:video_resolution, res_arr[1])
      res_arr.each { |res|
        set_tc_name("camera_setting_#{mode.downcase}_res_#{res.downcase}")
        clear_analytics()
        @camera.set(:video_resolution, res)
        retval, msg = get_analytics_events()
        (log_fail(msg); next) if retval == false
        # Analytics file was success
        @events = msg
        if @ana_ver >= "0.2.0"
          ret, msg = verify_event("VIDEO_RESOLUTION", res, mode_str, "GOPRO_APP")
        else
          ret, msg = verify_event("VIDEO_RESOLUTION", res, nil, "GOPRO_APP")
        end
        ret == false ? log_fail(msg) : pass(msg)
      }
    }
  end # verify_video_res

  def verify_video_fps()
    if @ana_ver >= "0.2.0"
      @all_modes = ["VIDEO", "VIDEO_PIV", "VIDEO_LOOPING", "VIDEO_TIMELAPSE"]
      @all_modes = ["VIDEO_PIV"]
    else
      @all_modes = ["VIDEO"]
    end
    @all_modes.each { |mode|
      res_fps_arr = []
      mode_str = mode
      case mode
      when "VIDEO"
        @camera.get_video_resolution().each { |res|
          @camera.get_video_fps(res).each { |fps|
            res_fps_arr << [res, fps] }}
      when "VIDEO_PIV"
        @camera.get_video_resolution().each { |res|
          @camera.get_video_fps(res).each { |fps|
            res_fps_arr << [res, fps] if @camera.video_piv_support?(res, fps) }}
      when "VIDEO_LOOPING"
        @camera.get_video_resolution().each { |res|
          @camera.get_video_fps(res).each { |fps|
            res_fps_arr << [res, fps] if @camera.video_looping_support?(res, fps) }}
      when "VIDEO_TIMELAPSE"
        next # No concept of FPS
      end

      @camera.set_capture_mode(mode)
      @camera.set_video_protune("OFF") if @camera.video_protune_support?
      already_tested = Set.new

      ["NTSC", "PAL"].each { |vf|
        @camera.set_video_format(vf)
        res_fps_arr.each { |res, fps|
          next if @camera.already_set?(:video_fps, fps)[0] == true
          next if already_tested.include?(fps)
          next if @camera.is_ntsc?(res, fps) and vf == "PAL"
          next if !@camera.is_ntsc?(res, fps) and vf == "NTSC"

          set_tc_name("camera_setting_#{mode.downcase}_fps_#{fps}")
          log_info("Setting #{res}/#{fps}")
          clear_analytics()

          @camera.set(:video_resolution, res)
          @camera.set(:video_fps, fps)
          retval, msg = get_analytics_events()
          (log_fail(msg); next) if retval == false
          # Analytics file was success
          @events = msg
          # Sometimes it is logged as CAMERA and sometimes GOPRO_APP
          # it's ok either way
          if @ana_ver >= "0.2.0"
            ret, msg = verify_event("FRAMES_PER_SECOND", fps, mode_str, "*")
          else
            ret, msg = verify_event("FRAMES_PER_SECOND", fps, nil, "*")
          end
          ret == false ? log_fail(msg) : log_pass(msg)
          already_tested << fps
        } # res,fps
      } # vf
    }
  end # verify_video_fps

  def verify_video_fps_ntsc_pal_switch()
    @camera.set_capture_mode("VIDEO")
    @camera.set_video_protune("OFF") if @camera.video_protune_support? == true
    @camera.set_video("NTSC", "1080", "30", "W")
    already_tested = []
    @camera.get_video_resolution().shuffle.each { |res|
      @camera.get_video_fps(res).each { |fps|
        next if @camera.already_set?(:video_fps, fps)[0] == true
        next if @camera.is_ntsc?(res, fps) == false
        next if already_tested.include?(fps)

        set_tc_name("camera_setting_fps_ntsc_pal_switch_setup")
        fov = @camera.get_video_fov(res, fps)[0]
        ret = []
        clear_analytics()
        @camera.set_video("NTSC", res, fps, fov)
        @camera.set_video_format("PAL")
        pal_fps = @camera.get_setting_name_by_sym_api2(:video_fps)
        set_tc_name("camera_setting_#{fps}fps_#{pal_fps}fps_ntsc_pal_switch")
        @camera.set_video_format("NTSC")

        retval, msg = get_analytics_events()
        (log_fail(msg); next) if retval == false
        # Analytics file was success
        @events = msg

        # Sometimes it is logged as CAMERA and sometimes GOPRO_APP
        # it's ok either way
        ret << verify_event("FRAMES_PER_SECOND", fps, nil, "*")
        # Log msg may only be trigered if fps actually changes
        # Cases like 48FPS -> 48FPS -> 48FPS may not have these entries
        ret << verify_event("FRAMES_PER_SECOND", pal_fps, nil, "*") if fps != pal_fps
        ret << verify_event("FRAMES_PER_SECOND", fps, nil, "*") if fps != pal_fps
        if ret.include?(false)
          log_fail("NTSC/PAL switch did not generate FPS event for #{fps}/#{pal_fps} fps")
        else
          log_pass("FPS events for #{fps}/#{pal_fps} fps seen")
        end
        already_tested << fps
      } # fps
    } # res
  end

  def verify_video_fov()
    if @ana_ver >= "0.2.0"
      @all_modes = ["VIDEO", "VIDEO_PIV", "VIDEO_LOOPING", "VIDEO_TIMELAPSE"]
    else
      @all_modes = ["VIDEO"]
    end
    @all_modes.each { |mode|
      @camera.set_capture_mode(mode)
      @camera.set_video_protune("OFF") if @camera.video_protune_support? == true
      already_tested = Set.new
      mode_str = mode
      @camera.get_video_resolution().shuffle.each { |res|
        @camera.get_video_fps(res).each { |fps|
          @camera.get_video_fov(res, fps).each { |fov|
            case mode
            when "VIDEO"
            when "VIDEO_PIV"
              next if @camera.video_piv_support?(res, fps, fov) == false
            when "VIDEO_LOOPING"
              next if @camera.video_looping_support?(res, fps, fov) == false
            when "VIDEO_TIMELAPSE"
              next # No FOV concept in Video Timelapse
            end
            next if already_tested.include?(fov)
            next if @camera.get_setting_name_by_sym_api2(:video_fov, refresh=false) == fov

            set_tc_name("camera_setting_#{mode.downcase}_fov_#{fov.downcase}")
            clear_analytics()
            if @camera.is_ntsc?(res, fps)
              @camera.set_video_format("NTSC")
            else
              @camera.set_video_format("PAL")
            end
            @camera.set_video_resolution(res)
            @camera.set_video_fps(fps)
            @camera.set(:video_fov, fov)
            retval, msg = get_analytics_events()
            (log_fail(msg); next) if retval == false

            # Analytics file was success
            @events = msg
            if @ana_ver >= "0.2.0"
              ret, msg = verify_event("FIELD_OF_VIEW", fov, mode_str, "GOPRO_APP")
            else
              ret, msg = verify_event("FIELD_OF_VIEW", fov, nil, "GOPRO_APP")
            end
            ret == false ? log_fail(msg) : log_pass(msg)
            already_tested << fov
          } # fov
        } # fps
      } # res
    } # mode
  end # verify_video_fov

  def verify_protune_capture_mode_switch()
    set_tc_name("protune_capture_mode_switch_setup")

    options = @options
    options[:video_pt] = "OFF"
    options[:setup_orientation] = "UP"
    video_params = tu_get_video_res_with_protune(@camera, options).flatten(1)

    video_params.each { |vp|
      set_tc_name("protune_capture_mode_switch_setup")
      vm, res, fps, fov, ll, spot, pt, wb, co, sh, iso, ex = vp
      log_debug("video params: #{vm}, #{res}, #{fps}, #{fov}")
      log_debug("video params: #{ll}, #{spot}, #{pt}, #{wb}, #{co}, #{sh}, #{iso}, #{ex}")
      @camera.set_video_protune("OFF")
      @camera.set_video(vm, res, fps, fov)

      ret = []
      clear_analytics()
      @camera.set_video_protune("ON")
      sleep 3.0
      pt_res = @camera.get_setting_name_by_sym_api2(:video_resolution)
      pt_fps = @camera.get_setting_name_by_sym_api2(:video_fps, refresh=false)
      pt_fov = @camera.get_setting_name_by_sym_api2(:video_fov, refresh=false)
      set_tc_name("%s-%s-%s_switch_to_protune_%s-%s-%s" \
        % [res, fps, fov, pt_res, pt_fps, pt_fov])
      # sleep 3
      # @camera.set_video_protune("OFF")
      # sleep 3

      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      # Verify settings changed when ProTune enabled
      ret << verify_event("VIDEO_RESOLUTION", pt_res, nil, "*") if res != pt_res
      ret << verify_event("FRAMES_PER_SECOND", pt_fps, nil, "*") if fps != pt_fps
      ret << verify_event("FIELD_OF_VIEW", pt_fov, nil, "*") if fov != pt_fov

      # Rockypoint behavior no longer maintains non/ProTune settings separately
      # If settings change is required when switching ProTune ON, it happens,
      # and settings REMAIN when ProTune is turned OFF
      # # Verify settings changed when ProTune disabled
      # ret << verify_event("VIDEO_RESOLUTION", res, nil, "*") if res != pt_res
      # ret << verify_event("FRAMES_PER_SECOND", fps, nil, "*") if fps != pt_fps
      # ret << verify_event("FIELD_OF_VIEW", fov, nil, "*") if fov != pt_fov
      if ret.include?(false)
        log_fail("ProTune toggle did not result in RES/FPS/FOV events generated")
      else
        log_pass("ProTune toggle caused expected RES/FPS/FOV events")
      end
    } # video_params
  end

  def verify_p_button()
    set_tc_name("p_button_press")
    @camera.set_capture_mode("VIDEO")
    sleep(3.0)
    clear_analytics()
    sleep(3.0)
    @sercam.short_press_button("P_BUTTON")
    sleep(3.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return false) if retval == false
    # Analytics file was success
    @events = msg
    ret, msg = verify_event("BUTTON_PRESSED", "P_SHORT_PRESS", "S_NO_ACTION", "W_NO_ACTION")
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_s_button()
    set_tc_name("s_button_press")
    @camera.set_capture_mode("PHOTO")
    sleep(3.0)
    clear_analytics()
    sleep(3.0)
    @sercam.short_press_button("S_BUTTON")
    sleep(3.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return false) if retval == false
    # Analytics file was success
    @events = msg
    ret, msg = verify_event("BUTTON_PRESSED", "P_NO_ACTION", "S_SHORT_PRESS", "W_NO_ACTION")
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_menu_button()
    set_tc_name("menu_button_press")
    @camera.set_capture_mode("VIDEO")
    sleep(3.0)
    clear_analytics()
    sleep(3.0)
    @sercam.short_press_button("MENU_BUTTON")
    sleep(3.0)
    # Press it twice so we don't stay in a menu and cause camera == busy
    @sercam.short_press_button("MENU_BUTTON")
    sleep(3.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return false) if retval == false
    # Analytics file was success
    @events = msg
    ret, msg = verify_event("BUTTON_PRESSED", "P_NO_ACTION", "S_NO_ACTION", "W_SHORT_PRESS")
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_shutter()
    all_modes = @capture_modes
    all_modes.each { |m|
      set_tc_name("camera_mode_#{m.downcase}_shutter")
      log_info("Setting camera mode #{m}")
      ret = []
      clear_analytics()
      sleep(3.0)
      # Trigger a mode change so that mode == VIDEO definitely is logged
      if m == "VIDEO"
        log_info("First setting to PHOTO mode to ensure event is logged")
        @camera.set_capture_mode("PHOTO")
        sleep(3.0)
      end
      r, msg = @camera.set_capture_mode(m)
      (r == true) ? log_info(msg) : log_warn(msg)
      sleep(3.0)
      @camera.start_capture()
      sleep(5.0)
      sleep(30.0) if m == "PHOTO_NIGHT" # Have to wait for shutter if it is long
      if ["PHOTO", "BURST", "PHOTO_NIGHT"].include?(m) == false
        @camera.stop_capture()
        sleep(10.0)
        sleep(5.0) if m == "BURST"  # Burst takes even longer sometimes
      end
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret << verify_event("CAMERA_MODE", m, nil, "*")
      ret << verify_event("SHUTTER_STATUS", "ON", nil, nil)
      if ["PHOTO", "BURST", "PHOTO_NIGHT"].include?(m) == false
        ret << verify_event("SHUTTER_STATUS", "OFF", nil, nil)
      end
      ret.include?(false) ? log_fail("Shutter events not seen") : log_pass("Shutter OK")
    }
  end

  def verify_wifi_off_on()
    set_tc_name("wifi_off_on")
    log_skip("Please test manually")
  end

  def verify_wifi_mode()
    all_modes = ["OFF", "APP", "RC", "NETWORK", "SMART"]
    all_modes.each { |m|
      set_tc_name("wifi_mode_#{m.downcase}")
      log_skip("Please test manually")
    }
  end

  def verify_low_light()
    set_tc_name("low_light")
    @camera.set_capture_mode("VIDEO")
    sleep(3.0)
    @camera.get_video_resolution().shuffle.each { |res|
      @camera.get_video_fps(res).shuffle.each { |fps|
        @camera.get_video_fov(res, fps).each { |fov|
          # Find the first mode that supports low-light mode
          next if not @camera.video_low_light_support?(res, fps, fov)
          set_tc_name("low_light_off_on")
          log_info("Testing low-light for mode #{res}/#{fps}/#{fov}")
          clear_analytics()
          vm = @camera.is_ntsc?(res, fps) ? "NTSC" : "PAL"
          @camera.set_video(vm, res, fps, fov)
          @camera.set_video_low_light("OFF")
          sleep 3
          @camera.set_video_low_light("ON")
          sleep 3
          @camera.set_video_low_light("OFF")
          sleep 3
          # Get the events
          retval, msg = get_analytics_events()
          (log_fail(msg); return nil) if retval == false
          # Analytics file was success
          @events = msg
          # Want to verify it is not set, then set, then not set again.
          ret = []
          if @camera.name == "ROCKYPOINT" and @ana_ver > "0.0.0"
            ret << verify_event(@lowlight_event,
              "LOW_LIGHT_ON", "FIELD_7_CHANGED", "GOPRO_APP")
            ret << verify_event(@lowlight_event,
              "LOW_LIGHT_OFF", "FIELD_7_CHANGED", "GOPRO_APP")
          else
            ret << verify_event(@lowlight_event, "LOW_LIGHT_ON", "*", "GOPRO_APP")
            ret << verify_event(@lowlight_event, "LOW_LIGHT_OFF", "*", "GOPRO_APP")
          end
          ret.include?(false) ? log_fail("Low-light ON/OFF events absent/malformed") : log_pass
          # Will only hit here if test completed.  Just return something
          return nil
        }
      }
    }
    log_skip("No capture mode supporting low_light found")
  end

  def verify_video_looping()
    set_tc_name("video_looping")
    @camera.set_capture_mode("VIDEO_LOOPING")
    sleep(3.0)
    @camera.get_video_resolution().shuffle.each { |res|
      @camera.get_video_fps(res).shuffle.each { |fps|
        @camera.get_video_fov(res, fps).each { |fov|
          # Find the first mode that supports looping
          next if not @camera.video_looping_support?(res, fps, fov)
          vm = @camera.is_ntsc?(res, fps) ? "NTSC" : "PAL"
          @camera.set_video(vm, res, fps, fov)
          looping_intervals = @camera.get_video_looping_intervals()
          looping_intervals.each { |loo|
            set_tc_name("video_looping_#{loo.to_s.downcase}_min")
            log_info("Testing video looping #{loo} min. for mode #{res}/#{fps}/#{fov}")
            clear_analytics()
            # Camera will skip setting the value if it's already set so we avoid this
            if @camera.already_set?(:video_looping, loo)[0] == true
              looping_intervals.each { |l|
                (@camera.set_video_looping(l); break) if (loo != l)
              }
            end
            @camera.set_video_looping(loo)
            sleep 3
            # Get the events
            retval, msg = get_analytics_events()
            (log_fail(msg); next) if retval == false
            # Analytics file was success
            @events = msg
            ret, msg = verify_event("LOOPING_VALUE", loo.to_s, nil, "GOPRO_APP")
            ret == false ? log_fail(msg) : log_pass(msg)
          }
          # Will only hit here if test completed.  Just return something
          return nil
        }
      }
    }
    log_skip("No capture mode supporting low_light found")
  end

  def verify_video_piv()
    set_tc_name("video_piv")
    @camera.set_capture_mode("VIDEO_PIV")
    sleep(3.0)
    @camera.get_video_resolution().shuffle.each { |res|
      @camera.get_video_fps(res).shuffle.each { |fps|
        @camera.get_video_fov(res, fps).each { |fov|
          # Find the first mode that supports PIV
          next if not @camera.video_piv_support?(res, fps, fov)
          vm = @camera.is_ntsc?(res, fps) ? "NTSC" : "PAL"
          @camera.set_video(vm, res, fps, fov)
          piv_intervals = @camera.get_video_piv_intervals()
          piv_intervals.each { |piv|
            set_tc_name("video_piv_value_#{piv}s")
            log_info("Testing video piv interval #{piv}s for mode #{res}/#{fps}/#{fov}")
            clear_analytics()
            if @camera.already_set?(:video_piv, piv)[0] == true
              piv_intervals.each { |p|
                (@camera.set_video_piv(p); break) if (piv != p)
              }
            end
            @camera.set_video_piv(piv)
            sleep 3
            # Get the events
            retval, msg = get_analytics_events()
            (log_fail(msg); next) if retval == false
            # Analytics file was success
            @events = msg
            ret, msg = verify_event("PHOTO_IN_VIDEO_VALUE", piv.to_s, nil, "GOPRO_APP")
            ret == false ? log_fail(msg) : log_pass(msg)
          }
          # Will only hit here if test completed.  Just return something
          return nil
        }
      }
    }
    log_skip("No capture mode supporting low_light found")
  end

  def verify_video_timelapse_intervals()
    set_tc_name("video_timelapse_intervals")
    @camera.set_capture_mode("VIDEO_TIMELAPSE")
    sleep(3.0)
    @camera.get_video_timelapse_res().shuffle.each() { |res|
      @camera.set_video_resolution(res)
      @camera.get_video_timelapse_intervals().each() { |pes|
        set_tc_name("video_timelapse_interval_#{pes}_res_#{res}")
        log_info("Testing video timelapse interval #{pes}s for res #{res}")
        clear_analytics()
        @camera.set_video_timelapse(pes)
        sleep 3
        # Get the events
        retval, msg = get_analytics_events()
        (log_fail(msg); next) if retval == false
        # Analytics file was success
        @events = msg
        ret, msg = verify_event("TIME_LAPSE_INTERVAL", pes.to_s, nil, "GOPRO_APP")
        ret == false ? log_fail(msg) : log_pass(msg)
      }
      # Will only hit here if test completed.  Just return something
      return nil
    }
    log_error("Did not find any video time-lapse modes for camera")
  end

  def verify_low_battery()
    set_tc_name("low_battery_shutdown")
    log_skip("Please test manually (t appc status lowbatt)")
    return nil
  end

  def verify_over_temp()
    set_tc_name("over_temp_shutdown")
    log_skip("Please test manually (t appc status overtemp)")
    return nil
  end

  def verify_ring_buffer()
    set_tc_name("log_buffer_size")
    clear_analytics()
    # Ring buffer size is 2^15 = 32768
    @sercam.send_serial("dbg off")
    buff_size = 1<<15
    @sercam.log_analytic_event(0, 9, 9, 9)
    log_info("Filling log buffer with #{buff_size} entries")
    p Time.now()
    @sercam.log_fake_analytic_events(buff_size)
    p Time.now()
    sleep(3.0)
    @sercam.send_serial("dbg on")
    # Get the events
    retval, msg = get_analytics_events()
    (log_fail(msg); return false) if retval == false
    # Analytics file was success
    @events = msg
    ret = []
    ret << verify_event("DATA_LOG_VERSION", 9, 9, 9)
    if ret.include?(true)
      log_fail("Matched initial entry (should have been overwritten)")
    else
      log_pass("Initial entry not found (correctly overwritten)")
    end
  end

  def verify_protune_state()
    @capture_modes.each { |m|
      set_tc_name("protune_off_on_#{m.downcase}")
      case m
      when "VIDEO"
        next if @camera.video_protune_support? == false
        meth = @camera.method("set_video_protune")
        flag = @video_protune_event
      when "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"
        next if @camera.photo_protune_support? == false
        meth = @camera.method("set_photo_protune")
        flag = "FLAG_5"
      when "BURST", "TIMELAPSE", "NIGHTLAPSE"
        next if @camera.multi_photo_protune_support? == false
        meth = @camera.method("set_multi_photo_protune")
        flag = "FLAG_6"
      else
        # Don't even log a result because it confuses people
        log_info("ProTune not supported for mode #{m} on #{@camera.name}")
        next
      end

      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      meth.call("OFF")
      sleep(3.0)
      clear_analytics()
      sleep(3.0)
      meth.call("ON")
      sleep(3.0)
      meth.call("OFF")
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      ret << verify_event(flag, "PROTUNE_ON", "*", "GOPRO_APP", false)
      ret << verify_event(flag, "PROTUNE_SUBMODE_#{m}", "*", "GOPRO_APP", false) if @ana_ver > "0.0.0"
      ret << verify_event(flag, "PROTUNE_OFF", "*", "GOPRO_APP")
      ret.include?(false) ? log_fail("ProTune events missing/malformed") : log_pass
    }
  end

  def verify_spot_meter()
    @capture_modes.each { |m|
      set_tc_name("spot_metering_state_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      if ["VIDEO", "VIDEO_LOOPING", "VIDEO_PIV"].include?(m)
        meth = @camera.method("set_video_spot_metering")
      elsif ["PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"].include?(m)
        meth = @camera.method("set_photo_spot_metering")
      elsif ["BURST", "TIMELAPSE", "NIGHTLAPSE"].include?(m)
        meth = @camera.method("set_multi_photo_spot_metering")
      else
        log_warn("Skipping spot meter for mode #{m}")
        next
      end
      # To ensure the camera hits both OFF and ON at least once
      meth.call("OFF")
      sleep(3.0)
      meth.call("ON")
      sleep(3.0)
      meth.call("OFF")
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      style = nil
      if ["BACKDOOR", "PIPE"].include?(@camera.name)
        if @ana_ver >= "0.2.0"
          style = m
        else
          style = get_style(m)
        end
      elsif ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
        style = get_style(m) if @ana_ver > "0.0.0"
      else
        log_skip("Camera type (#{@camera.name}) unsupported")
        return false
      end
      ret = []
      ret << verify_event("SPOT_METERING", "ON", style, "GOPRO_APP")
      ret << verify_event("SPOT_METERING", "OFF", style, "GOPRO_APP")
      ret.include?(false) ? log_fail("Spot-metering events missing/malformed") : log_pass
    }
  end

  def verify_white_balance()
    all_modes = [@camera.video_protune_modes, @camera.photo_protune_modes,
                 @camera.multi_protune_modes].compact.reduce(:+)
    all_modes.each { |m|
      set_tc_name("white_balance_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      case m
      when "VIDEO"
        meth = @camera.method("set_video_protune_white_balance")
      when "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"
        meth = @camera.method("set_photo_protune_white_balance")
      when "BURST", "TIMELAPSE", "NIGHTLAPSE"
        meth = @camera.method("set_multi_photo_protune_white_balance")
      else
        log_warn("#{m} is not one of the known ProTune modes.")
        next
      end
      wb_arr = @camera.get_protune_white_balance()
      # To ensure the camera hits all settings
      meth.call(wb_arr[1])
      sleep 3.0
      wb_arr.each { |wb|
        meth.call(wb)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      fail_str = "Following values failed: "
      @camera.get_protune_white_balance().each { |wb|
        ret << verify_event("WHITE_BALANCE_VALUE", wb, m, "GOPRO_APP")
        fail_str += "(#{wb})"
      }
      ret.include?(false) ? log_fail(fail_str) : log_pass("All values passed.")
    }
  end

  def verify_color()
    all_modes = ["VIDEO", "PHOTO", "BURST"]
    all_modes.each { |m|
      set_tc_name("protune_color_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      if m == "VIDEO"
        meth = @camera.method("set_video_protune_color")
        flag = @video_color_event
      elsif m == "PHOTO"
        meth = @camera.method("set_photo_protune_color")
        flag = "FLAG_5"
      elsif m == "BURST"
        meth = @camera.method("set_multi_photo_protune_color")
        flag = "FLAG_6"
      else
        log_warn("#{m} is not one of the known ProTune modes.")
        next
      end
      # To ensure the camera hits all settings
      col_arr = @camera.get_protune_color()
      meth.call(col_arr[1])
      sleep(3.0)
      col_arr.each { |c|
        meth.call(c)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      ret << verify_event(flag, "PROTUNE_COLOR", "*", "GOPRO_APP")
      ret << verify_param_not(flag, "PROTUNE_COLOR", nil, nil)
      ret.include?(false) ? log_fail(ret.join(",")) : log_pass
    }
  end

  def verify_iso_video()
    all_modes = ["VIDEO"]
    all_modes.each { |m|
      set_tc_name("iso_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      if m == "VIDEO"
        meth = @camera.method("set_video_protune_iso")
      else
        log_warn("#{m} is not one of the known ProTune modes.")
        next
      end
      iso_arr = @camera.get_video_protune_iso()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      iso_arr.each { |iso|
        ret << verify_event("VIDEO_PROTUNE_ISO", iso, nil, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Video ISO events missing/malformed") : log_pass
    }
  end

  def verify_video_protune_shutter_speed()
    all_modes = ["VIDEO"]
    all_modes.each { |m|
      set_tc_name("protune_shutter_speed_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      if m == "VIDEO"
        meth = @camera.method("set_video_protune_shutter_speed")
      else
        log_warn("#{m} is not one of the known ProTune modes.")
        next
      end
      speeds = @camera.get_video_protune_shutter_speeds()
      # To ensure the camera hits all settings
      meth.call(speeds[1])
      sleep(3.0)
      speeds.each { |s|
        meth.call(s)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      speeds.each { |s|
        ret << verify_event("VIDEO_PROTUNE_SHUTTER_SPEED", s, nil, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Shutter speed events missing/malformed") : log_pass
    }
    # Set back to AUTO so later tests aren't messed up.
    @camera.set_video_protune_shutter_speed("AUTO")
  end

  # Hawaii Phase 4
  def verify_iso_mode_video()
    all_modes = ["VIDEO"]
    all_modes.each { |m|
      set_tc_name("iso_mode_max_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      iso_arr = @camera.get_video_protune_iso_modes()
      # To ensure the camera hits all settings
      meth = @camera.method("set_video_protune_iso_mode")
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      iso_arr.each { |iso|
        ret << verify_event("VIDEO_PROTUNE_ISO_MODE", iso, nil, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("ISO mode events missing/malformed") : log_pass
    }
  end

  def verify_iso_photo()
    all_modes = @camera.photo_protune_modes
    all_modes.each { |m|
      set_tc_name("iso_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      meth = @camera.method("set_photo_protune_iso")
      iso_arr = @camera.get_photo_protune_iso()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_photo_protune_iso().each { |iso|
        ret << verify_event("PHOTO_PROTUNE_ISO", iso, nil, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Photo ISO events missing/malformed") : log_pass
    }
  end

  # For Hawaii Phase 4
  def verify_iso_photo_min()
    all_modes = @camera.photo_protune_modes
    all_modes.each { |m|
      set_tc_name("iso_min_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      # First ensure ISO_MAX is set to maximum value
      @camera.set_photo_protune_iso(@camera.get_photo_protune_iso().max)
      clear_analytics()
      meth = @camera.method("set_photo_protune_iso_min")
      iso_arr = @camera.get_photo_protune_iso_min()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_photo_protune_iso_min().each { |iso|
        ret << verify_event("PHOTO_PROTUNE_ISO_MIN", iso, m, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Photo ISO MIN events missing/malformed") : log_pass
    }
  end

  # For Hawaii Phase 4
  def verify_iso_photo_max()
    all_modes = @camera.photo_protune_modes
    all_modes.each { |m|
      set_tc_name("iso_max_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      # First ensure ISO_MIN is set to minimum value
      @camera.set_photo_protune_iso_min(@camera.get_photo_protune_iso_min().min)
      clear_analytics()
      meth = @camera.method("set_photo_protune_iso")
      iso_arr = @camera.get_photo_protune_iso()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_photo_protune_iso().each { |iso|
        ret << verify_event("PHOTO_PROTUNE_ISO_MAX", iso, m, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Photo ISO MAX events missing/malformed") : log_pass
    }
  end

  def verify_iso_multi_shot()
    all_modes = @camera.multi_protune_modes
    all_modes.each { |m|
      set_tc_name("iso_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      meth = @camera.method("set_multi_photo_protune_iso")
      iso_arr = @camera.get_photo_protune_iso()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_photo_protune_iso().each { |iso|
        ret << verify_event("MULTI_SHOT_PROTUNE_ISO", iso, nil, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Multi-shot ISO events missing/malformed") : log_pass
    }
  end

  # For Hawaii Phase 4
  def verify_iso_multi_shot_min()
    all_modes = @camera.multi_protune_modes
    all_modes.each { |m|
      set_tc_name("iso_min_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      # First ensure ISO_MAX is set to maximum value
      @camera.set_multi_photo_protune_iso(@camera.get_photo_protune_iso().max)
      clear_analytics()
      meth = @camera.method("set_multi_photo_protune_iso_min")
      iso_arr = @camera.get_photo_protune_iso_min()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_photo_protune_iso_min().each { |iso|
        ret << verify_event("MULTI_SHOT_PROTUNE_ISO_MIN", iso, m, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Multi-shot ISO MIN events missing/malformed") : log_pass
    }
  end

  # For Hawaii Phase 4
  def verify_iso_multi_shot_max()
    all_modes = @camera.multi_protune_modes
    all_modes.each { |m|
      set_tc_name("iso_max_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      # First ensure ISO_MIN is set to minimum value
      @camera.set_multi_photo_protune_iso_min(@camera.get_photo_protune_iso_min().min)
      clear_analytics()
      meth = @camera.method("set_multi_photo_protune_iso")
      iso_arr = @camera.get_photo_protune_iso()
      # To ensure the camera hits all settings
      meth.call(iso_arr[1])
      sleep(3.0)
      iso_arr.each { |iso|
        meth.call(iso)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_photo_protune_iso().each { |iso|
        ret << verify_event("MULTI_SHOT_PROTUNE_ISO_MAX", iso, m, "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Multi-shot ISO MAX events missing/malformed") : log_pass
    }
  end

  def verify_sharpness()
    all_modes = ["VIDEO", "PHOTO", "BURST"]
    all_modes.each { |m|
      if m == "VIDEO"
        next if @camera.video_protune_support? == false
        meth = @camera.method("set_video_protune_sharpness")
        flag = @video_sharpness_event
      elsif m == "PHOTO"
        next if @camera.photo_protune_support? == false
        meth = @camera.method("set_photo_protune_sharpness")
        flag = "FLAG_5"
      elsif m == "BURST"
        next if @camera.multi_photo_protune_support? == false
        meth = @camera.method("set_multi_photo_protune_sharpness")
        flag = "FLAG_6"
      else
        log_warn("#{m} is not one of the known ProTune modes.")
        next
      end
      set_tc_name("sharpness_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      sleep(3.0)
      @camera.get_protune_sharpness().each { |sh|
        meth.call(sh)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      # Should fail due to RKPT-2316
      if @camera.name == "ROCKYPOINT" and @ana_ver > "0.0.0"
        ret << verify_event(flag, "PROTUNE_SHARPNESS_OFF",
          "FIELD_3_CHANGED / FIELD_4_CHANGED", "GOPRO_APP", del=true, strict=false)
        ret << verify_event(flag, "PROTUNE_SHARPNESS_ON",
          "FIELD_3_CHANGED / FIELD_4_CHANGED", "GOPRO_APP", del=true, strict=false)
      else
        @camera.get_protune_sharpness().each { |sh|
          ret << verify_event(flag, "PROTUNE_SHARPNESS_#{sh}", "*", "GOPRO_APP")
        }
      end
      ret.include?(false) ? log_fail("Sharpness events missing/malformed") : log_pass
    }
  end

  def verify_protune_exposure()
    all_modes = ["VIDEO", "PHOTO", "BURST"]
    all_modes.each { |m|
      set_tc_name("exposure_#{m.downcase}")
      log_info("Setting camera mode #{m}")
      @camera.set_capture_mode(m)
      sleep(3.0)
      clear_analytics()
      if m == "VIDEO"
        meth = @camera.method("set_video_protune_exposure")
      elsif m == "PHOTO"
        meth = @camera.method("set_photo_protune_exposure")
      elsif m == "BURST"
        meth = @camera.method("set_multi_photo_protune_exposure")
      else
        log_warn("#{m} is not one of the known ProTune modes.")
        next
      end
      ex_arr = @camera.get_protune_exposure()
      # To ensure the camera hits all settings
      meth.call(ex_arr[1])
      sleep(3.0)
      ex_arr.each { |ex|
        meth.call(ex)
        sleep(3.0)
      }
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret = []
      @camera.get_protune_exposure().each { |ex|
        ret << verify_event("EXPOSURE_COMPENSATION", ex.to_s, get_style(m), "GOPRO_APP")
      }
      ret.include?(false) ? log_fail("Exposure comp. events missing/malformed") : log_pass
    }
  end

  def verify_photo_res()
    @capture_modes.each { |mode|
      case mode
      when "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"
        @camera.set_capture_mode(mode)
        sym = :photo_resolution
      when "BURST", "TIMELAPSE", "NIGHTLAPSE"
        @camera.set_capture_mode(mode)
        sym = :multi_photo_resolution
      else
        next
      end

      @camera.get_photo_resolutions().each{ |res|
        set_tc_name("camera_setting_#{mode.downcase}_res_#{res.downcase}")
        clear_analytics()
        @camera.set(sym, res)
        sleep(3.0)

        retval, msg = get_analytics_events()
        (log_fail(msg); next) if retval == false
        @events = msg
        if @ana_ver >= "0.2.0"
          ret, msg = verify_event("PHOTO_RESOLUTION", res, mode, "GOPRO_APP")
        else
          ret, msg = verify_event("PHOTO_RESOLUTION", res, nil, "GOPRO_APP")
        end
        ret == false ? log_fail(msg) : log_pass(msg)
      }
    }

  end

  def verify_continuous_setting()
    @camera.set_capture_mode("PHOTO_CONTINUOUS")
    res = @camera.get_photo_resolutions()[0]
    @camera.set_photo_resolution(res)
    sps_arr = @camera.get_photo_continuous_rates(res)
    # To ensure the camera hits all settings
    @camera.set_photo_continuous(sps_arr[1])
    sleep(3.0)
    sps_arr.each { |sps|
      set_tc_name("continuous_shot_setting_#{sps}_sps")
      ret = []
      clear_analytics()
      @camera.set_photo_continuous(sps)
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret, msg = verify_event("CONTINUOUS_SHOT_VALUE", sps, nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_night_photo_exp_setting()
    @camera.set_capture_mode("PHOTO_NIGHT")
    res = @camera.get_photo_resolutions()[0]
    @camera.set_photo_resolution(res)
    se_arr = @camera.get_photo_shutter_exposure_intervals()
    # To ensure the camera hits all settings
    @camera.set_photo_shutter_exposure(se_arr[1])
    sleep(3.0)
    se_arr.each { |se|
      set_tc_name("night_photo_exp_len_#{se.downcase}")
      ret = []
      clear_analytics()
      @camera.set_photo_shutter_exposure(se)
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret, msg = verify_event("NIGHT_PHOTO_SHUTTER_EXPOSURE", se, nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_night_lapse_exp_setting()
    @camera.set_capture_mode("NIGHTLAPSE")
    res = @camera.get_photo_resolutions()[0]
    @camera.set_photo_resolution(res)
    se_arr = @camera.get_photo_shutter_exposure_intervals()
    # To ensure the camera hits all settings
    @camera.set_multi_photo_shutter_exposure(se_arr[1])
    sleep(3.0)

    se_arr.each { |se|
      set_tc_name("night_lapse_exp_len_#{se.downcase}")
      ret = []
      clear_analytics()
      @camera.set_multi_photo_shutter_exposure(se)
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret, msg = verify_event("NIGHT_LAPSE_SHUTTER_EXPOSURE", se, nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_burst_setting()
    @camera.set_capture_mode("BURST")
    bu_arr = @camera.get_multi_photo_burst_rates()
    # To ensure the camera hits all settings
    @camera.set_multi_photo_burst(bu_arr[1]) if bu_arr.length > 1
    sleep(3.0)

    bu_arr.each { |bu|
      set_tc_name("burst_photo_setting_#{bu}")
      ret = []
      clear_analytics()
      @camera.set_multi_photo_burst(bu, true)
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret, msg = verify_event("BURST_VALUE", bu, nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_time_lapse_interval()
    @camera.set_capture_mode("TIMELAPSE")
    pes_arr = @camera.get_multi_photo_timelapse_rates()
    # To ensure the camera hits all settings
    @camera.set_multi_photo_timelapse(pes_arr[1])
    sleep(3.0)

    pes_arr.each { |pes|
      set_tc_name("timelapse_interval_#{pes}")
      ret = []
      clear_analytics()
      @camera.set_multi_photo_timelapse(pes)
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      if @ana_ver == "0.0.0"
        ret, msg = verify_event("TIME_LAPSE_INTERVAL", pes, "*", "GOPRO_APP")
      else
        ret, msg = verify_event("TIME_LAPSE_INTERVAL", pes, get_style("TIMELAPSE"), "GOPRO_APP")
      end
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_night_lapse_interval()
    @camera.set_capture_mode("NIGHTLAPSE")
    pes_arr = @camera.get_multi_photo_nightlapse_rates()
    # Need to set shutter exposure to AUTO so all intervals are available
    @camera.set_multi_photo_shutter_exposure("AUTO")
    # To ensure the camera hits all settings
    @camera.set_multi_photo_nightlapse(pes_arr[1])
    sleep(3.0)

    pes_arr.each { |pes|
      set_tc_name("night_lapse_interval_#{pes}")
      ret = []
      clear_analytics()
      @camera.set_multi_photo_nightlapse(pes)
      sleep(3.0)
      retval, msg = get_analytics_events()
      (log_fail(msg); next) if retval == false
      # Analytics file was success
      @events = msg
      ret, msg = verify_event("NIGHT_LAPSE_INTERVAL", pes, nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_orientation()
    set_tc_name("upd_setting")
    clear_analytics()
    if not ["HALEIWA", "HIMALAYAS"].include?(@camera.name)
      @camera.set_orientation("AUTO")
      sleep(2.0)
      @camera.set_orientation("UP")
      sleep(3.0)
      @camera.set_orientation("DOWN")
      sleep(3.0)
      @camera.set_orientation("AUTO")
      sleep(2.0)
    elsif  # NO AUTO for Haleiwa and Himalayas
      sleep(3.0)
      @camera.set_orientation("UP")
      sleep(3.0)
      @camera.set_orientation("DOWN")
      sleep(3.0)
      @camera.set_orientation("UP")
      sleep(5.0)
    end
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    @events = msg
    if @camera.name == "ROCKYPOINT" and @ana_ver > "0.0.0"
      ret1, msg1 = verify_event(@video_format_event, "ORIENT_UP",
        "FIELD_2_CHANGED", "GOPRO_APP", del=true, strict=false)
      ret2, msg2 = verify_event(@video_format_event, "ORIENT_DOWN",
        "FIELD_2_CHANGED / FIELD_3_CHANGED", "GOPRO_APP", del=true, strict=false)
      ret3, msg3 = verify_event(@video_format_event, "ORIENT_AUTO",
        "FIELD_3_CHANGED", "GOPRO_APP", del=true, strict=false)
      ret = ret1 & ret2 & ret3
      msg = "#{msg1} / #{msg2} / #{msg3}"
    elsif not ["HALEIWA", "HIMALAYAS"].include?(@camera.name) # Hawaii, mostly
      ret1, msg1 = verify_event(@video_format_event, "ORIENT_AUTO", "*", "GOPRO_APP")
      ret2, msg2 = verify_event(@video_format_event, "ORIENT_DOWN", "*", "GOPRO_APP")
      ret = ret1 & ret2
      msg = "#{msg1} / #{msg2}"
    else
      ret1, msg1 = verify_event(@video_format_event, "ORIENT_DOWN", "*", "GOPRO_APP") # DOWN
      ret2, msg2 = verify_param_not(@video_format_event, "ORIENT_DOWN", nil, nil) # UP
      ret = ret1 & ret2
      msg = "#{msg1} / #{msg2}"
    end
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_quick_capture()
    set_tc_name("quick_capture_setup")
    clear_analytics()
    @camera.set_quick_capture("OFF")
    @camera.set_quick_capture("ON")
    @camera.set_quick_capture("OFF")
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    @events = msg
    set_tc_name("quick_capture_on")
    if @quick_capture_event == "USER_SETTINGS"
      ret, msg = verify_event(@quick_capture_event,
        "QUICK_CAPTURE_ON", "FIELD_4_CHANGED", "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
      set_tc_name("quick_capture_off")
      ret, msg = verify_event(@quick_capture_event,
        "QUICK_CAPTURE_OFF", "FIELD_4_CHANGED", "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    else
      ret, msg = verify_event(@quick_capture_event, "QUICK_CAPTURE", "*", "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
      set_tc_name("quick_capture_off")
      ret, msg = verify_param_not(@quick_capture_event, "QUICK_CAPTURE", nil, nil)
      ret == false ? log_fail(msg) : log_pass(msg)
    end
  end

  def verify_osd()
    set_tc_name("osd_setup")
    clear_analytics()
    @camera.set_osd("ON")
    @camera.set_osd("OFF")
    @camera.set_osd("ON")
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    @events = msg
    if @quick_capture_event == "USER_SETTINGS"
      ret, msg = verify_event(@osd_event,
        "ON_SCREEN_DISPLAY_ON", "FIELD_5_CHANGED", "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
      set_tc_name("quick_capture_off")
      ret, msg = verify_event(@quick_capture_event,
        "ON_SCREEN_DISPLAY_OFF", "FIELD_5_CHANGED", "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    else
      set_tc_name("osd_on")
      ret, msg = verify_event(@osd_event, "ON_SCREEN_DISPLAY", "*", "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
      set_tc_name("osd_off")
      ret, msg = verify_param_not(@osd_event, "ON_SCREEN_DISPLAY", nil, nil)
      ret == false ? log_fail(msg) : log_pass(msg)
    end
  end

  def verify_led_blink()
    set_tc_name("led_blink_setup")
    clear_analytics()
    sleep(2.0)
    if ["BACKDOOR", "PIPE"].include?(@camera.name)
      led_arr = ["0", "2", "4"]
    elsif ["ROCKYPOINT"].include?(@camera.name)
      led_arr = ["OFF", "ON"]
    elsif ["HALEIWA", "HIMALAYAS"].include?(@camera.name)
      led_arr = ["BOTH", "FRONT", "BACK", "OFF"]
    else
      log_skip("Camera type (#{@camera.name}) unsupported")
      return false
    end
    @camera.set_led(led_arr[1])
    led_arr.each { |n|
      @camera.set_led(n)
    }
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    @events = msg
    led_arr.each{ |n|
      set_tc_name("led_blink_#{n}")
      ret, msg = verify_event("LED_BLINK", "#{n}", nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_beep_volume()
    set_tc_name("beep_volume_setup")
    clear_analytics()
    sleep(2.0)
    if ["BACKDOOR", "PIPE"].include?(@camera.name)
      beep_arr = ["100", "70", "0"]
    elsif ["ROCKYPOINT"].include?(@camera.name)
      beep_arr = ["100", "70", "0"]
    elsif ["HALEIWA", "HIMALAYAS"].include?(@camera.name)
      beep_arr = ["OFF", "ON"]
    else
      log_skip("Camera type (#{@camera.name}) unsupported")
      return false
    end
    @camera.set_beep_volume(beep_arr[1])
    beep_arr.each { |n|
      @camera.set_beep_volume(n)
    }
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    @events = msg
    beep_arr.each{ |n|
      set_tc_name("beep_volume_#{n}")
      ret, msg = verify_event("BEEP_SOUND", "BEEP_#{n}", nil, "GOPRO_APP")
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_auto_off()
    set_tc_name("auto_off_setup")
    clear_analytics()
    sleep(2.0)
    auto_off_arr = ["0", "60", "120", "180", "300"]
    @camera.set(:setup_auto_off, auto_off_arr[1])
    auto_off_arr.each { |n|
      @camera.set(:setup_auto_off, n)
    }
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    @events = msg
    auto_off_arr.each{ |n|
      set_tc_name("auto_power_off_#{n}s")
      ret, msg = verify_event("AUTO_POWER_OFF", "#{n}", nil, "GOPRO_APP", true, true)
      ret == false ? log_fail(msg) : log_pass(msg)
    }
  end

  def verify_delete_last()
    set_tc_name("delete_last_setup")
    @camera.set_capture_mode("PHOTO")
    sleep(3.0)
    @camera.start_capture()
    sleep(3.0)
    clear_analytics()
    sleep(2.0)
    @camera.delete_last_file()
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    set_tc_name("delete_last")
    @events = msg
    ret, msg = verify_event("DELETE_FILE", "DELETE_LAST", "OK", "GOPRO_APP")
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_delete_all()
    set_tc_name("delete_all_setup")
    @camera.set_capture_mode("PHOTO")
    sleep(3.0)
    @camera.start_capture()
    sleep(3.0)
    clear_analytics()
    sleep(2.0)
    @camera.delete_all_media()
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    set_tc_name("delete_all")
    @events = msg
    ret, msg = verify_event("DELETE_FILE", "DELETE_ALL", "OK", "GOPRO_APP")
    ret == false ? log_fail(msg) : log_pass(msg)
  end

  def verify_locate()
    set_tc_name("locate_setup")
    clear_analytics()
    sleep(2.0)
    @camera.send_locate_camera_api2(0)
    sleep(4.0)
    @camera.send_locate_camera_api2(1)
    sleep(2.0)
    @camera.send_locate_camera_api2(0)
    sleep(2.0)
    retval, msg = get_analytics_events()
    (log_fail(msg); return nil) if retval == false
    # Analytics file was success
    set_tc_name("locate")
    @events = msg
    ret = []
    ret << verify_event("USER_SETTINGS", "LOCATE_ON", "FIELD_6_CHANGED", "GOPRO_APP")
    ret << verify_event("USER_SETTINGS", "LOCATE_OFF", "FIELD_6_CHANGED", "GOPRO_APP")
    (ret.include?(false)) ? log_fail("Locate ON/OFF events missing/malformed") : log_pass
  end

  def verify_hilight_tag()
    tag_limit = @camera.hilight_tag_limit
    set_tc_name("hilight_tag")
    if tag_limit == nil
      log_skip("Skipping because missing @hilight_tag_limit member.  Tagging supported?")
      return
    end

    clear_analytics()
    # Every camera should support these
    ret, msg = @camera.set_capture_mode("VIDEO")
    (log_fail(msg); return nil) if ret == false
    sleep(3.0)
    ret, msg = @camera.set_video("NTSC", "1080", "30", "W")
    (log_fail(msg); return nil) if ret == false
    ret, msg = @camera.start_capture()
    (log_fail(msg); return nil) if ret == false

    # Perform the capture and tagging
    sleep(10)
    (1..(tag_limit+2)).each { |n|
      log_info("Tagging hilight #{n} of #{tag_limit}")
      @camera.tag_hilight()
      sleep(2.0)
    }
    ret, msg = @camera.stop_capture()
    (log_fail(msg); return nil) if ret == false

    # Verify tag message and tag_limit message
    ret, msg = get_analytics_events()
    (log_fail(msg); return nil) if ret == false
    @events = msg
    ret, msg = verify_event("HIGHLIGHT_TAG", "TAG_INSERTED", "ENCODE", "GOPRO_APP")
    ret == false ? log_fail(msg) : log_pass(msg)

    set_tc_name("hilight_tag_limit_reached")
    ret, msg = verify_event("HIGHLIGHT_TAG", "TAG_LIMIT_REACHED", "ENCODE", "GOPRO_APP")
    ret == false ? log_fail(msg) : log_pass(msg)
    return
  end

  def verify_hilight_tag_capture_media_types()
    @capture_modes.each { |mode|
      next if not mode.match(/VIDEO/)
      set_tc_name("hilight_tag_capture_#{mode.downcase}_media")
      clear_analytics()
      @camera.set_capture_mode(mode)

      case mode
      when "VIDEO"
        @camera.set_video("NTSC", "1080", "30", "W")
        dur = 10
      when "VIDEO_LOOPING"
        @camera.set_video("NTSC", "1080", "30", "W")
        loo = @camera.get_video_looping_intervals[0]
        @camera.set_video_looping(loo)
        dur = 10
      when "VIDEO_TIMELAPSE"
        res = @camera.get_video_timelapse_resolution[0]
        pes = @camera.get_video_timelapse_intervals[0]
        @camera.set_video_resolution(res)
        @camera.set_video_timelapse(pes)
        dur = 10
      when "VIDEO_PIV"
        piv = @camera.get_video_piv_intervals[0]
        @camera.set_video("NTSC", "1080", "30", "W")
        @camera.set_video_piv(piv)
        dur = piv.to_f*2.1
      else
        next
      end

      # Perform the capture and tagging
      ret, msg = @camera.start_capture()
      (log_fail(msg); return nil) if ret == false
      sleep(3)
      @camera.tag_hilight()
      sleep(dur)
      ret, msg = @camera.stop_capture()
      (log_fail(msg); return nil) if ret == false
      sleep(3)

      # Verify tag message
      ret, msg = get_analytics_events()
      (log_fail(msg); return nil) if ret == false
      @events = msg
      if @ana_ver >= "0.2.0"
        ret, msg = verify_event("HIGHLIGHT_TAG", "TAG_INSERTED", "#{mode} / ENCODE", "GOPRO_APP")
      else
        ret, msg = verify_event("HIGHLIGHT_TAG", "TAG_INSERTED", "ENCODE", "GOPRO_APP")
      end
      (ret == false) ? log_fail(msg) : log_pass(msg)
    }
  end # highlight_tag_capture_media_types

  ### Does not currently work as of HD4.XX.03.01.20
  # def verify_hilight_tag_playback_media_types()
  #   @capture_modes.each { |mode|
  #     next if not mode.match(/VIDEO/)
  #     set_tc_name("hilight_tag_playback_#{mode.downcase}_media")
  #     @camera.delete_all_media()
  #     clear_analytics()

  #     case mode
  #     when "VIDEO"
  #       @camera.capture_video("NTSC", "1080", "30", "W", 10)
  #     when "VIDEO_LOOPING"
  #       loo = @camera.get_video_looping_intervals[0]
  #       @camera.capture_looping("NTSC", "1080", "30", "W", loo, 10)
  #     when "VIDEO_TIMELAPSE"
  #       res = @camera.get_video_timelapse_resolution[0]
  #       pes = @camera.get_video_timelapse_intervals[0]
  #       @camera.capture_video_timelapse("NTSC", res, "W", pes, 10)
  #     when "VIDEO_PIV"
  #       piv = @camera.get_video_piv_intervals[0]
  #       @camera.capture_piv("NTSC", "1080", "30", "W", piv, piv*2.1)
  #     else
  #       next
  #     end

  #     case mode
  #     when "VIDEO", "VIDEO_LOOPING", "VIDEO_TIMELAPSE"
  #       f = @camera.get_medialist("MP4")[0]
  #       if f == nil
  #         fail("Unable to find captured media to tag")
  #         next
  #       end
  #       @camera.send_tag_hilight_playback_api2(f, 0)
  #     when "VIDEO_PIV"
  #     end

  #     # Verify tag message
  #     ret, msg = get_analytics_events()
  #     (log_fail(msg); return nil) if ret == false
  #     @events = msg
  #     ret, msg = verify_event("HIGHLIGHT_TAG", "TAG_INSERTED", "#{mode} / PLAYBACK", "GOPRO_APP")
  #     (ret == false) ? log_fail(msg) : log_pass(msg)
  #   }
  # end # highlight_tag_playback_media_types

  ### Actually a manual test.  We cannot control light value reported
  # def verify_light_value()
  #   all_modes = ["PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT",
  #                       "BURST", "TIMELAPSE", "NIGHTLAPSE"]
  #   all_modes.each { |mode|
  #     clear_analytics()
  #     @camera.set_capture_mode(mode)

  #     set_tc_name("light_values_#{mode.downcase}")
  #     @camera.get_light_values().each { |lv|
  #       @camera.set_light_value(lv)
  #     }

  #     ret, msg = get_analytics_events()
  #     (log_fail(msg); return nil) if ret == false
  #     @events = msg

  #     results = []
  #     str = []
  #     @camera.get_light_values().each { |lv|
  #       ret, msg = verify_event("LIGHT_VALUE", lv, mode, "GOPRO_APP")
  #       results << ret
  #       str << msg if ret == false
  #     }
  #     if results.include?(false)
  #       log_fail(str.join(" / "))
  #     else
  #       pass("All light values successful for #{mode}")
  #     end
  #   }
  # end

  def verify_media_counters
    set_tc_name("media_counters_setup")
    @camera.delete_all_media()
    @capture_modes.each { |mode|
      next if not mode.match(/VIDEO/)
      clear_analytics()
      case mode
      when "VIDEO"
        @camera.capture_video("NTSC", "1080", "30", "W", 10)
      when "VIDEO_LOOPING"
        loo = @camera.get_video_looping_intervals[0]
        @camera.capture_looping("NTSC", "1080", "30", "W", loo, 10)
      when "VIDEO_TIMELAPSE"
        res = @camera.get_video_timelapse_resolution[0]
        pes = @camera.get_video_timelapse_intervals[0]
        @camera.capture_video_timelapse("NTSC", res, "W", pes, 10)
      when "VIDEO_PIV"
        piv = @camera.get_video_piv_intervals[0]
        @camera.capture_piv("NTSC", "1080", "30", "W", piv, piv*2.1)
      else
        log_warn("Unknown video mode #{mode}")
        next
      end

      ret, msg = get_analytics_events()
      (log_fail(msg); return nil) if ret == false
      @events = msg

      set_tc_name("video_minutes_available_mode_#{mode.downcase}")
      exp_mins_avail = @camera.get_mins_avail()
      msb = exp_mins_avail >> 8
      lsb = exp_mins_avail & 0xFF
      ret, str = verify_event("VIDEO_MINS_AVAILABLE", msb, lsb, nil)
      (ret == false) ? log_fail(str) : pass("Video mins avail. correct (#{exp_mins_avail})")

      set_tc_name("videos_on_card_mode_#{mode.downcase}")
      exp_num_videos = @camera.get_n_videos()
      msb = exp_num_videos >> 8
      lsb = exp_num_videos & 0xFF
      ret, str = verify_event("VIDEOS_ON_CARD", msb, lsb, nil)
      (ret == false) ? log_fail(str) : pass("Videos on card correct (#{exp_num_videos})")

      if mode == "VIDEO_PIV"
        set_tc_name("photos_available_mode_#{mode.downcase}")
        exp_photos_avail = @camera.get_photos_avail()
        pp exp_photos_avail
        msb = exp_photos_avail >> 8
        lsb = exp_photos_avail & 0xFF
        ret, str = verify_event("PHOTOS_AVAILABLE", msb, lsb, nil)
        (ret == false) ? log_fail(str) : pass("Photos avail. correct (#{exp_photos_avail})")

        set_tc_name("photos_on_card_mode_#{mode.downcase}")
        exp_n_photos = @camera.get_n_photos()
        msb = exp_n_photos >> 8
        lsb = exp_n_photos & 0xFF
        ret, str = verify_event("PHOTOS_ON_CARD", msb, lsb, nil)
        (ret == false) ? log_fail(str) : pass("# Photos correct (#{exp_n_photos})")
      end
    }

    res = @camera.get_photo_resolutions().shuffle[0]
    @capture_modes.each { |mode|
      next if mode.match(/VIDEO/)
      clear_analytics()
      case mode
      when "PHOTO"
        @camera.capture_photo_single(res)
      when "PHOTO_CONTINUOUS"
        sps = @camera.get_photo_continuous_rates[0]
        @camera.capture_photo_continuous(res, sps, 10)
      when "PHOTO_NIGHT"
        @camera.capture_photo_night(res, 10)
      when "BURST"
        burst = @camera.get_multi_photo_burst_rates[0]
        @camera.capture_multi_photo_burst(res, burst)
      when "TIMELAPSE"
        tlapse = @camera.get_multi_photo_timelapse_rates[0]
        @camera.capture_multi_photo_timelapse(res, tlapse, 2.1*tlapse.to_f)
      when "NIGHTLAPSE"
        nlapse = @camera.get_multi_photo_nightlapse_rates[0]
        @camera.capture_multi_photo_nightlapse(res, nlapse, 2.1*nlapse.to_f)
      else
        log_warn("Unknown non-video mode #{mode}")
        next
      end
      ret, msg = get_analytics_events()
      (log_fail(msg); return nil) if ret == false
      @events = msg

      set_tc_name("photos_available_mode_#{mode.downcase}")
      exp_photos_avail = @camera.get_photos_avail()
      msb = exp_photos_avail >> 8
      lsb = exp_photos_avail & 0xFF
      ret, str = verify_event("PHOTOS_AVAILABLE", msb, lsb, nil)
      (ret == false) ? log_fail(str) : pass("Photos avail. correct (#{exp_photos_avail})")

      set_tc_name("photos_on_card_mode_#{mode.downcase}")
      exp_n_photos = @camera.get_n_photos()
      msb = exp_n_photos >> 8
      lsb = exp_n_photos & 0xFF
      ret, str = verify_event("PHOTOS_ON_CARD", msb, lsb, nil)
      (ret == false) ? log_fail(str) : pass("# Photos correct (#{exp_n_photos})")
    }
  end # verify_media_counters

  def verify_protune_reset()
    @protune_modes.each { |mode|
      @camera.set_capture_mode(mode)
      clear_analytics()
      case mode
      when "VIDEO"
        @camera.send_video_protune_reset()
      when "PHOTO", "PHOTO_CONTINUOUS", "PHOTO_NIGHT"
        @camera.send_photo_protune_reset()
      when "BURST", "TIMELAPSE", "NIGHTLAPSE"
        @camera.send_multi_photo_protune_reset()
      else
        log_info("Skipping non-ProTune mode #{mode}")
        next
      end
      set_tc_name("protune_reset_mode_#{mode.downcase}")
      sleep(1.0)
      ret, msg = get_analytics_events()
      (log_fail(msg); return nil) if ret == false
      @events = msg

      ret, str = verify_event("PROTUNE_RESET", "PROTUNE_RESET", mode, "GOPRO_APP")
      ret == false ? log_fail(str) : log_pass(str)
    }
  end # verify_protune_reset

  def verify_lcd_brightness()
    @camera.setup_lcd_brightness_api2.keys.each { |val|
      clear_analytics()
      set_tc_name("lcd_brightness_#{val.downcase}")
      resp = @camera.set(:setup_lcd_brightness, val)
      if resp[:success] == false
        fail("Unable to set LCD Brightness to #{val}")
        next
      end

      ret, msg = get_analytics_events()
      (log_fail(msg); return nil) if ret == false
      @events = msg
      ret, str = verify_event("LCD_BRIGHTNESS", val, nil, "GOPRO_APP")
      ret == false ? log_fail(str) : log_pass(str)
    }
  end

  def verify_lcd_sleep_timer()
    vals = @camera.setup_lcd_sleep_api2.keys
    @camera.set_lcd_auto_off(vals[1])
    vals.each { |val|
      clear_analytics()
      set_tc_name("lcd_sleep_timer_#{val.downcase}")
      @camera.set_lcd_auto_off(val)
      ret, msg = get_analytics_events()
      (log_fail(msg); return nil) if ret == false
      @events = msg
      ret, str = verify_event("LCD_SLEEP", val, nil, "GOPRO_APP")
      ret == false ? log_fail(str) : log_pass(str)
    }
  end

  def verify_datetime()
    set_tc_name("date_and_time")
    failed_arr = []
    clear_analytics()

    t = Time.now.strftime("%Y-%m-%d-%H-%M-%S")
    exp_year, exp_month, exp_day, exp_hour, exp_min, exp_sec = t.split('-')
    # gpCommand work with YEAR-2000.
    # Analytics uses YEAR-2014
    exp_year_ana = exp_year.to_i - 2014
    exp_year_gpc = exp_year.to_i - 2000

    date_time_str = ""
    [exp_year_gpc, exp_month, exp_day, exp_hour, exp_min, exp_sec].each { |n|
      date_time_str += @camera.wifi_itohs(n.to_i).upcase
    }
    log_info("Date to set on camera: %02d-%02d-%02d %02d:%02d:%02d" \
          % [exp_year_gpc, exp_month.to_i, exp_day.to_i,
            exp_hour.to_i, exp_min.to_i, exp_sec.to_i])
    begin
      resp = @camera.send_date_time_api2(date_time_str)
      if resp == false
        log_fail("Unable to set date on camera.  See log.")
        return
      end
      sleep(1.0)
      act_date_time = @camera.get_status_api2(:date_time)
    rescue WifiCamera::HTTPError
      fail("HTTP error running date_time test")
      return
    end
    act_year  = @camera.wifi_hstoi(act_date_time[0..2])[0]
    act_month = @camera.wifi_hstoi(act_date_time[3..5])[0]
    act_day   = @camera.wifi_hstoi(act_date_time[6..8])[0]
    act_hour  = @camera.wifi_hstoi(act_date_time[9..11])[0]
    act_min   = @camera.wifi_hstoi(act_date_time[12..14])[0]
    act_sec   = @camera.wifi_hstoi(act_date_time[15..17])[0]
    log_info("Date from camera: %02d-%02d-%02d %02d:%02d:%02d" \
      % [act_year, act_month, act_day, act_hour, act_min, act_sec])


    ret, msg = get_analytics_events()
    (log_fail(msg); return nil) if ret == false
    @events = msg

    failed_arr = []
    ret, msg = verify_event("RTC_DATE_SET", exp_year_ana, exp_month.to_i, exp_day.to_i)
    failed_arr << msg if ret == false
    ret, msg = verify_event("RTC_TIME_SET", exp_hour.to_i, exp_min.to_i, exp_sec.to_i)
    failed_arr << msg if ret == false
    return if has_failure?(failed_arr)
    log_pass("Date/Time events seen")
  end

  def cleanup
    @host.kill_status_process() if @host != nil
  end
end # Test class

# $LOGLEVEL = $LL_VERB
# t = Test.new
# t.process_data2(ARGV[0])
# exit 1

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :shuffle, :set_defaults,
       :battoutlet, :usboutlet, :reset_on_failure, :filter,
      :analytic_file, :generate_analytic_file, :analytic_version, :save_dir, :quick, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB # if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
