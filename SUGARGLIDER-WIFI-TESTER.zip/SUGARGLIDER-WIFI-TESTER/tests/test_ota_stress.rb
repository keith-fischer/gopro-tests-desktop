# test_ota_stress.rb
# Description: Loops OTA firmware updates
#
# Tests the following items:
#   - Item1
#   - Item2
#   - Item3

require_relative '../libs/camera'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require_relative '../libs/dlipower'
require_relative '../libs/installHandler.rb'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    @tc_name = "#{@test_file} setup"
    @host = Host.new
    @camera = tu_get_camera()
    # Option to verify update happens by checking capture mode before and after update.
    @camera.remote_api_version() == 2 ? @mode_check = true : @mode_check = false
    @camera.squelch_status = true if @camera.interfaces.include?(:wifi)
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
  end

  def runtest
    if @options[:base_fw_file] != nil
      base_ih = InstallHandler.new(@camera, @options[:base_fw_file])
    end
    ih = InstallHandler.new(@camera, @options[:fw_file])
    log_info("Deleting all media...")
    @camera.delete_all_media() # Can't perform ota with full disk
    do_version_check(ih)
    log_info("Camera release of FW file: #{ih.fw_rel()}")
    log_info("Camera model of FW file: #{ih.fw_cam()}")
    log_info("Firmware version of FW file: #{ih.fw_ver}")
    n = 1
    limit = @options[:n_iter] == nil ? 1 : @options[:n_iter].to_i
    while n <= limit
      log_info("Performing update cycle #{n} of #{limit}")
      if @options[:base_fw_file] != nil
        log_info("Reverting to FW version #{base_ih.fw_ver}")
        @camera.set_capture_mode("PHOTO") if @mode_check
        log_warn("Failed to switch to PHOTO MODE.") unless do_mode_check("PHOTO")
        start = Time.now()
        result = base_ih.do_ota_update(true)
        time_taken = Time.now() - start
        if result == true
          if do_mode_check("VIDEO")
            log_pass("Update successful in %0.2f seconds" %(time_taken))
          else
            log_fail("Update was not successful. Capture mode check failed.")
            #exit 1
          end
        else
          log_fail("Update was not successful. Issue doing OTA update.")
        end
        sleep(5)
      end
      log_info("Updating to FW version #{ih.fw_ver}")
      @camera.set_capture_mode("PHOTO")
      log_warn("Failed to switch to PHOTO MODE.") unless do_mode_check("PHOTO")
      start = Time.now()
      result = ih.do_ota_update(true)
      time_taken = Time.now() - start

      if result == false
        log_fail("Update was not successful. Issue doing OTA update.")
      else
        if not do_mode_check("VIDEO")
          log_fail("Update was not successful. Capture mode check failed, not in VIDEO mode")
          result = false
        end
        if not do_version_check(ih)
          log_fail("Update not successful. Camera version does not match FW upgrade version")
          result = false
        end
        if result == true
          if time_taken < 100
            log_warn("Upgrade seemed to happen, but still didn't take a lot of time #{time_taken}s")
          end
            log_pass("Update successful in %0.2f seconds" %(time_taken))
        end
      end
      n += 1
      sleep(10)
    end
  end

  def do_version_check(ih)
    cam_release, cam_type, cam_build = @camera.get_cam_info()
    log_info("Comparing camera version to firmware upgrade version...")
    log_info("Firmware release: #{ih.fw_rel}")
    log_info("Firmware type: #{ih.fw_cam}")
    log_info("Firmware build: #{ih.fw_ver}")
    log_info("Camera release: #{cam_release}")
    log_info("Camera type: #{cam_type}")
    log_info("Camera build: #{cam_build}")
    # Compare the new fw version with what was suppose to be set.
    if (ih.fw_rel == cam_release) # Release version match.
      if ( (ih.fw_cam == "XX") or (cam_type.to_i == ih.fw_cam.to_i) ) # Types match or new FW is type XX.
        if (cam_build.to_i == ih.fw_ver.to_i) # Builds match.
          return true
        end
      end
    end
    return false
  end

  def do_mode_check(want_mode)
    # Always pass this check if mode_check is false.
    return true unless @mode_check
    found_mode = @camera.get_current_capture_mode().upcase
    retval = (want_mode == found_mode)
    log_info("do_mode_check returning #{retval}. (found: #{found_mode} wanted: #{want_mode})")
    return retval
  end # do_mode_check

  def cleanup
  end

end # end Test class

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :n_iter, :fw_file, :base_fw_file,
      :battoutlet, :usboutlet, :reset_on_failure, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
    t.cleanup
  rescue StandardError => e
    require_relative '../libs/log_utils'; include LogUtils
    log_error(e.to_s + "\n" + e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
