# extends-video-capture.rb
# Description: Sets the camera to a specific RES/FPS/FOV and records
#     for --duration seconds or until SD card is full.
#     Optionally deletes the card when full and starts over.
# Options:
#   [--vid_res RES]     Sets the RES to use
#   [--fps FPS]         Sets the FPS to use
#   [--fov FOV]         Sets the FOV to use
#   [--protune OFF|ON]  Sets ProTune setting (default off)
#   [--iterations N]    Perform N fill-card --> format iterations
#   [--duration SECS]   Capture videos of SECS length each iteration. 
#                       Otherwise it runs until the SD card is full
# Tests for:
#   - Camera did not crash
#   - Correct file names
#   - Correct chapter size of video files
#   - Correct metadata of video files

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../libs/exitcodes'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    # Check required options
    required = [:vid_res, :fps, :fov]
    required.each { |r|
      if @options[r] == nil
        log_warn("Required option #{r} not found")
        exit 1
      end
    }
    
    @host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    @camera.delete_all_media()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options(@options)
  end

  def test_capture(res, fps, fov, pt, duration)
    @camera.set_capture_mode("VIDEO")
    vm = @camera.is_ntsc?(res, fps) ? "NTSC" : "PAL"
    @camera.set_video(vm, res, fps, fov)
    log_info("Capturing #{duration} seconds of #{res}/#{fps}/#{fov} video")
    @camera.start_capture()
    start_time = Time.now()
    while true
      elapsed = Time.now() - start_time
      if elapsed > duration
        @camera.stop_capture()
        break
      end
      interval = [60.0, (duration-elapsed)].min()
      log_info("Time elapsed is %0.2f seconds" %elapsed)
      sleep(interval)
      break if not @camera.busy?
    end
    
    if @camera.is_alive? == false
      fail("Camera unresponsive")
      exit ExitCode::CAMERA_FREEZE
    end
   
    # Test that the first file starts with 'GOPR'
    mp4files = @camera.get_medialist("MP4")
    temp = mp4files.map { |f| f.match(/GOPR\d{4}.MP4/) }
    files = temp.compact.map { |f| f[0] }
    if files.length == 0
      fail("No 'GOPR' files found on SD card.")
      return
    elsif files.length > 1
      fail("Should be one and only one 'GOPR' file. files=#{files}")
      return
    end
    first_file = files[0]
    
    failed_arr = []
    # Test that subsequent chapters are named correctly
    temp = mp4files.map { |f| f.match(/GP\d{6}.MP4/) }
    files = temp.compact.map { |f| f[0] }
    (1..files.length).each { |n|
      exp = "GP%02d%s.MP4" %[n, first_file[4..7]]
      f_seen = false
      files.each { |f|
        if f.match(exp) != nil
          f_seen = true
          break
        end
      }
      if not f_seen
        failed_arr << "Expected chapter #{exp} not seen"
      end
    }
    
    # Test that RES/FPS of all files are correct
    # Not using the test_util because it is hard-coded to use the local file
    # and we want to grab the metadata over HTTP
    mp4files.each { |mp4file|
      log_info("Checking file #{mp4file} metadata...")
      # Compare the MP4 file
      exp = VideoMetadata.new()
      exp.aspect_ratio       = @camera.video_capture_modes[res][:aspect_ratio]
      exp.audio_channels     = @camera.audio_channels
      exp.audio_codec        = @camera.audio_codec
      exp.audio_sample_rate  = @camera.audio_sample_rate
      exp.video_bitrate      = @camera.video_capture_modes[res][:fps][fps][:bitrate]
      exp.colorspace         = @camera.colorspace
      exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:frame_rate]
      exp.has_timecode       = @camera.video_capture_modes[res][:fps][fps][:timecode]
      exp.height             = @camera.video_capture_modes[res][:height]
      exp.video_codec        = @camera.video_codec
      exp.width              = @camera.video_capture_modes[res][:width]
      exp.profile_level      = @camera.getProfileLevel(res,fps)
      act = @host.get_video_metadata(@camera.get_media_url(mp4file))
      if act == nil
        fail("Unable to open video file")
        return
      end

      failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio, "aspect_ratio")
      failed_arr << assert_equal(exp.audio_channels, act.audio_channels, "audio_channels")
      failed_arr << assert_equal(exp.audio_codec, act.audio_codec, "audio_codec")
      failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate, "audio_sample_rate")
      #    failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15, "video_bitrate")
      failed_arr << assert_equal(exp.colorspace, act.colorspace, "colorspace")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate, "frame_rate")
      failed_arr << assert_equal(exp.has_timecode, act.has_timecode, "has_timecode")
      failed_arr << assert_equal(exp.width, act.width, "width")
      failed_arr << assert_equal(exp.height, act.height, "height")
      failed_arr << assert_equal(exp.video_codec, act.video_codec, "video_codec")
      failed_arr << assert_equal(exp.profile_level, act.profile_level, "profile_level")
  
      # Compare the LRV file (if applicable)
      # ALL chapters generate LRV files.
      if lrvfile != nil and pt == false
        exp = VideoMetadata.new()
        exp.audio_channels     = @camera.audio_channels
        exp.audio_codec        = @camera.audio_codec
        exp.audio_sample_rate  = @camera.audio_sample_rate
        # TODO bitrate
        exp.colorspace         = @camera.colorspace
        exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:lrv_fps]
        exp.has_timecode       = @camera.video_capture_modes[res][:fps][fps][:timecode]
        exp.height             = @camera.video_capture_modes[res][:lrv_height]
        exp.video_codec        = @camera.video_codec
        exp.width              = @camera.video_capture_modes[res][:lrv_width]
  
        act = @host.get_video_metadata(lrvfile)
        if act == nil
          fail("Unable to open video file")
          return
        end
        log_info("Checking LRV file metadata")
        failed_arr << assert_equal(exp.audio_channels, act.audio_channels, "lrv audio_channels")
        failed_arr << assert_equal(exp.audio_codec, act.audio_codec, "lrv audio_codec")
        failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate, "lrv audio_sample_rate")
        # TODO bitrate
        failed_arr << assert_equal(exp.colorspace, act.colorspace, "lrv colorspace")
        failed_arr << assert_equal(exp.frame_rate, act.frame_rate, "lrv frame_rate")
        failed_arr << assert_equal(exp.has_timecode, act.has_timecode, "lrv has_timecode")
        failed_arr << assert_equal(exp.width, act.width, "lrv width")
        failed_arr << assert_equal(exp.height, act.height, "lrv height")
        failed_arr << assert_equal(exp.video_codec, act.video_codec, "lrv video_codec")
      end
    }
    # TODO Analyze THM file (if applicable)
    return if has_failure?(failed_arr)  # Will log a fail if it sees one
    pass("All tests passed")
  end

  def runtest()
    res = @options[:video_resolution]
    fps = @options[:video_fps]
    fov = @options[:video_fov]
    pt = (@options[:video_protune] == "ON")
    secs_avail = 60 * @camera.get_status(:video_minutes_available)
    iterations = (@options[:n_iter] != nil) ? @options[:n_iter].to_i : 1
    duration = (@options[:duration] != nil) ? @options[:duration] : secs_avail
    if @options[:duration_range_low] and @options[:duration_range_high]
      duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
      log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
    end

    tc_str = "#{res}_#{fps}_#{fov}"
    tc_str += "_protune" if pt == true
    set_tc_name(tc_str)
    log_verb("%s/%s/%s Pro=%s, Iter=%s, Dur=%s" \
       %[res, fps, fov, pt, iterations, duration])
    n = 1
    begin
      while n <= iterations
        n += 1
        test_capture(res, fps, fov, pt, duration)
        @camera.delete_all_media()
      end  
    rescue StandardError => e
      log_error(e.to_s + "\n" + e.backtrace.join("\n"))
    end
  end # end runtest

  def cleanup

  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc,
      :battoutlet, :usboutlet,
      :video_resolution, :video_fps, :video_fov, :setup_beep,
      :video_protune, :video_protune_color, :video_protune_white_balance, :video_protune_exposure,
      :duration, :n_iter]
    options = t.parse_options(ARGV, use_options)
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
