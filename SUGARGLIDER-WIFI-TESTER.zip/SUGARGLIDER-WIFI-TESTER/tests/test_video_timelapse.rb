# test_video_timelapse.rb
# Description: Iterates over all RES/FPS/FOV that support time-lapse
#              and attempts to encode a video in each mode.  Then it
#              verifies the video metadata (specific items below).
# Tests the following items:
#   - The following video metadata is correct:
#     - aspect_ratio
#     - audio_channels
#     - audio_codec
#     - audio_sample_rate
#     - bitrate
#     - colorspace
#     - frame_rate
#     - has_timecode
#     - height
#     - width
#     - video_codec
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    if !@camera.video_timelapse_support?()
      log_info("#{@camera.name} doesn't support video timelapse feature")
      exit 1
    end

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    tu_keep_or_delete_all_media()
    tu_verify_sd_status()
    sleep(3.0)
  end

  def runtest()
    # Enumerate all the test combinations
    test_params = tu_get_video_timelapse_res()

    if test_params.length == 0
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    else
      log_info("Running #{test_params.length} test cases")
    end
    test_params.shuffle! if @options[:shuffle]

    counter = 0
    test_params.each do |vm, res, fov, pes, orient|
      begin
        counter += 1
        next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
        log_info("Running test #{counter} of #{test_params.length}")
        tc_name = "#{vm}_#{res}_timelapse_#{pes}s_#{orient}"
        set_tc_name( tc_name )

        prev_video = @camera.get_last_media("MP4", hash=false)

        duration = @options[:duration] != nil ? @options[:duration] : (60 * pes.to_f)
        # The default duration achieves 30 frame-per-sec and encodes 2 seconds of media.
        # It only does 2 seconds because timelapse takes a really long time!

        # Or just pick a duration at random if the duration is a range.
        if @options[:duration_range_low] and @options[:duration_range_high]
          duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
          log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
        end
        # Require a minumum encoding length that ensure's two seconds of resulting media.
        # Do this even if a duration was specified.
        if duration.to_f < (60 * pes.to_f)
          duration = (60 * pes.to_f)
          log_warn("Duration is below minimum required duration to cause 2 seconds of resulting media. Defaulting to #{duration}.")
        end

        log_info("Capturing #{pes}s video timelapse @ #{res}/#{fov} (dur=#{duration})")

        ret, msg = @camera.capture_video_timelapse(vm, res, fov, pes, duration, orient)
        (ret == false) ? (fail(msg); next) : log_info(msg)

        cur_video = @camera.get_last_media("MP4", hash=false)
        (fail("No new video was found after encoding"); next) if prev_video == cur_video

        tu_map_media_list( __FILE__, tc_name, [cur_video] )

        # Metadata
        failed_arr = []

        failed_arr << tu_wifi_analyze_video_timelapse_metadata(cur_video, vm, res)

        #File name convention
        failed_arr << tu_analyze_file_name("VIDEO", File.basename(cur_video))

        #gpMediaList or camera roll verification
        failed_arr << tu_wifi_analyze_gpmedialist_params("VIDEO_TIMELAPSE", vm, nil, res)

        #Analyze if mp4/lrv/thm exists over http (since there is no way to check
        #if thm exists on SD card, and doesn't hurt to check mp4/lrv as well)
        failed_arr << tu_wifi_check_media_existence("VIDEO_TIMELAPSE", cur_video, vm, "OFF", res, nil, nil, true)

        # has_failure() will log a fail if it sees one
        log_pass("All metadata checks passed") if !has_failure?(failed_arr)
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    end # end test_params
  end # end runtest

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :keep_media, :download_media,
      :battoutlet, :usboutlet, :reset_on_failure, :setup_orientation,
      :video_resolution, :video_fps, :video_fov, :video_timelapse, :range,
      :video_spot_metering, :video_low_light, :ntsc_only, :pal_only,
      :duration, :shuffle, :save_dir, :verb, :quick]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
