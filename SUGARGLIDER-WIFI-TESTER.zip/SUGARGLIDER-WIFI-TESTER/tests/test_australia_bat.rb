# Australia BAT
# # 1. flash camera
       # - ota only
# 2. check build version via cv command
# "browse mode, not each submode"
# 3. browse mode to video
# 4. browse mode to photo
# 5. browse mode to burst
# 6. browse mode to timelapse
# 7. browse mode to settings/setup
# 8. encode video
#                 - duration 5 minutes. need to check that file exists. any metadata failure doesn't fail BAT
#                 - use default video resolution only
# 9 encode photo. need to check that file exists. any metadata failure doesn't fail BAT
#                 - use default resolution only
# 10. encode burst. need to check that file exists. any metadata failure doesn't fail BAT
#                 - use default resolution only
# 11. encode timelapse. need to check that file exists. any metadata failure doesn't fail BAT
#                 - use default resolution only
#                 - duration 5 minutes

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/installHandler.rb'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'
require_relative '../tools/compare_settings_json'

require 'json'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    json_file = File.read(@camera.temp_json_loc)
    @old_json_hash = JSON.parse(json_file)

    tu_keep_or_delete_all_media()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    # set_options()

  end

  def do_version_check(ih)
    cam_info = @camera.get_cam_info_dnssd()
    cam_release = cam_info[:rel]
    cam_type = cam_info[:type]
    cam_build = cam_info[:build]
    log_info("Comparing camera version to firmware upgrade version...")
    log_info("Firmware release: #{ih.fw_rel}")
    log_info("Firmware type: #{ih.fw_cam}")
    log_info("Firmware build: #{ih.fw_ver}")
    log_info("Camera release: #{cam_release}")
    log_info("Camera type: #{cam_type}")
    log_info("Camera build: #{cam_build}")
    # Compare the new fw version with what was suppose to be set.
    if (ih.fw_rel == cam_release) # Release version match.
      if ( (ih.fw_cam == "XX") or (cam_type.to_i == ih.fw_cam.to_i) ) # Types match or new FW is type XX.
        if (cam_build.to_i == ih.fw_ver.to_i) # Builds match.
          return true
        end
      end
    end
    return false
  end

  def info_cmd_check()
    # get camera info through camera/cv no longer supported.
    # getting camera info through dnssd should work
    cam_info = @camera.get_cam_info_dnssd()
    # getting bacpac info through bacpac/cv still works.
    bacpac_info = @camera.get_bacpac_info()
    if cam_info.nil?
      fail("error getting camera info through mDNS command")
    elsif bacpac_info.nil?
      fail("error getting bacpac info using bacpac/cv command")
    else
      pass("Successful in getting both camera/bacpack info through mDNS and bacpac/cv commands")
    end
  end #info_cmd_check

  def do_mode_check(want_mode)
    # Always pass this check if mode_check is false.
    return true unless @mode_check
    found_mode = @camera.get_current_capture_mode().upcase
    retval = (want_mode == found_mode)
    log_info("do_mode_check returning #{retval}. (found: #{found_mode} wanted: #{want_mode})")
    return retval
  end # do_mode_check

  def reset_camera()
    result = false
    3.times { |n|
      log_info("Try #{n+1} of 3 waiting for Wi-Fi")
      @host.send_serial("t api system reset force", @camera.serial_iface)
      sleep(30)
      3.times {
        @host.send_serial("t api wireless mode app", @camera.serial_iface)
        sleep 1
      }
      result = @host.wait_for_wifi_camera(@camera.ip)
      break if result == true
    }
    return result
  end

  def ota_update()
    # Make sure .ota.zip is appended if necessary
    fw = @options[:fw_file]
    fw += ".ota" if fw.match(".ota") == nil
    fw += ".zip" if fw.match(".zip") == nil

    ih = InstallHandler.new(@camera, fw)
    do_version_check(ih)
    log_info("Camera release of FW file: #{ih.fw_rel()}")
    log_info("Camera model of FW file: #{ih.fw_cam()}")
    log_info("Firmware version of FW file: #{ih.fw_ver}")

    log_info("Updating to FW version #{ih.fw_ver}")
    @camera.set_capture_mode("PHOTO")
    log_warn("Failed to switch to PHOTO MODE.") unless do_mode_check("PHOTO")
    start = Time.now()
    result = ih.do_ota_update(true)
    time_taken = Time.now() - start

    if result == false
      fail("Update was not successful. Issue doing OTA update.")
    elsif do_mode_check("VIDEO") == false
      fail("Update was not successful. Capture mode check failed, not in VIDEO mode")
    elsif do_version_check(ih) == false
      fail("Update not successful. Camera version does not match FW upgrade version")
    elsif time_taken < 100
      log_skip("Inconclusive. Update didn't take enough time (#{time_taken}s.")
    else
      pass("Update successful in %0.2f seconds" %(time_taken))
      return true
    end
    return false
  end # ota_update

  def runtest()
    # 1) Perform info command check(mDNS / bacpac/cv)
    set_tc_name("info_cmd_check")
    ret = info_cmd_check()

    # 2) Perform OTA update
    set_tc_name("ota_update")
    if @options[:fw_file] == nil
      log_skip("Skipping OTA update since no FW file specified")
    else
      ret = ota_update()
    end

    # 3) Check firmware version
    set_tc_name("firmware_version")
    if @options[:fw_file] != nil
      ih = InstallHandler.new(@camera, @options[:fw_file])
      if do_version_check(ih) == true
        pass("Camera FW %s.%02d.%s is correct" \
          %[@camera.release, @camera.type, @camera.build])
      else
        fail("Something wrong with camera FW version %s.%02d.%s" \
          %[@camera.release, @camera.type, @camera.build])
      end
    else
      log_skip("Skipping version check since no FW file specified")
    end

  	# 4-7) Set mode video/photo/burst/timelapse
    log_info("Initially setting PHOTO mode before testing mode changes")
    @camera.set_capture_mode("PHOTO")
    @camera.wait_until_not_busy
  	["VIDEO", "PHOTO", "BURST", "TIMELAPSE"].each { |m|
  		set_tc_name("set_mode_#{m.downcase}")
      @camera.wait_until_not_busy
      ret, msg = @camera.set_capture_mode(m)
      (ret == true) ? pass(msg) : fail(msg)
  	}

    # 8) Settings needs a workaround for now since the JSON doesn't have
    # a value for setup mode (should be 5).
    set_tc_name("set_mode_setup")
    resp = @camera.send_mode(5)
    actual_mode = @camera.get_status_api2(:mode)
    if actual_mode == 5
      pass("Mode set to SETUP correctly")
    else
      fail("Unable to enter SETUP (actual mode=#{actual_mode})")
    end

    # 9) Capture 5 minutes of video at defaults.  Verify file existence only.
    vm = "NTSC"
    res, fps, fov = "1080", "60", "W"
    duration = 300
    set_tc_name("capture_video_#{res}_#{fps}_#{fov}")

    begin
      before = @camera.get_medialist("MP4")
      ret, msg = @camera.capture_video(vm, res, fps, fov, duration)
      if ret == false
        fail(msg)
      else
        log_info(msg)
        mp4files = @camera.get_medialist("MP4") - before
        if mp4files.length == 1
          pass("Successfully captured #{mp4files[0]}")
        else
          fail("MP4 files on card did not increase by exactly 1. before=%s, after=%s" \
            %[before, mp4files+before])
        end
      end
    rescue StandardError => e
      if before == false
        fail("Error parsing gpmedialist MP4 data; see test logs")
      else
        fail("#{e}.to_s  See test logs.")
      end
    end

    # 10) Capture Photo.  Verify file existence only.
    res = "12WIDE"
    set_tc_name("capture_photo_#{res}")

    begin
      before = @camera.get_medialist("JPG")
      ret, msg = @camera.capture_photo_single(res)
      (ret == false) ? fail(msg) : log_info(msg)
      jpgfiles = @camera.get_medialist("JPG") - before
      if jpgfiles.length == 1
        pass("Successfully captured #{jpgfiles[0]}")
      else
        fail("JPG files on card did not increase by exactly 1. new_media=%s" \
          %jpgfiles)
      end
    rescue StandardError => e
      if before == false
        fail("Error parsing gpmedialist JPG data; see test logs")
      else
        fail("#{e}.to_s  See test logs.")
      end
    end

    # 11) Capture Burst.  Verify file existence only.
    res = "12WIDE"
    burst = "30_1"
    set_tc_name("capture_#{burst}_burst_#{res}")

    begin
      before = @camera.get_medialist("JPG")
      ret, msg = @camera.capture_multi_photo_burst(res, burst)
      (ret == false) ? fail(msg) : log_info(msg)
      jpgfiles = @camera.get_medialist("JPG") - before
      if jpgfiles.length == 30
        pass("Successfully captured %s files starting with #{jpgfiles[0]}" \
          %jpgfiles.length)
      else
        fail("JPG files on card did not increase by exactly 30. after=%s" \
          %jpgfiles)
      end
    rescue StandardError => e
      if before == false
        fail("Error parsing gpmedialist JPG data; see test logs")
      else
        fail("#{e}.to_s  See test logs.")
      end
    end

    # 12) Capture Time-Lapse.  Verify file existence only.
    res = "12WIDE"
    pes = "0.5"
    duration = 300
    set_tc_name("capture_#{pes}_timelapse_#{res}")

    begin
      before = @camera.get_medialist("JPG")
      ret, msg = @camera.capture_multi_photo_timelapse(res, pes, duration)
      (ret == false) ? fail(msg) : log_info(msg)
      jpgfiles = @camera.get_medialist("JPG") - before
      if jpgfiles.length > duration
        pass("Successfully captured %s files starting with #{jpgfiles[0]}" \
          %jpgfiles.length)
      else
        fail("JPG files on card did not increase by enough (>#{duration}). " + \
          "after=#{jpgfiles}")
      end
    rescue StandardError => e
      if before == false
        fail("Error parsing gpmedialist JPG data; see test logs")
      else
        fail("#{e}.to_s  See test logs.")
      end
    end

    # Get current camera settings json for comparison
    if !@camera.get_settings_json_hash
      log_error("error getting settings json")
    else
      currhash = @camera.settings_json_hash
    end
    compare_settings_json(@old_json_hash, currhash, false)

  end # runtest

  def cleanup
    tu_save_media("BAT")
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :save_dir, :verb, :fw_file, :download_media,
      :serialdev, :usboutlet, :battoutlet, :keep_media]
    options = t.parse_options(ARGV, use_options)
    options[:ip] = "10.5.5.9" if options[:ip] == nil
    options[:pc] = "goproher" if options[:pc] == nil
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
