# test_burst.rb

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    @camera.do_factory_reset("USER") if @camera.interfaces.include?(:serial)
    sleep(5.0) if @camera.interfaces.include?(:serial)
    set_options()

    # Start preview stream on cameras that we want to test it
    if @camera.test_preview_stream == true
      ret, msg = @host.get_system_camera_ip(@camera.ip)
      ret == true ? @camera.system_address = msg : (log_info(msg); exit 1)
      @camera.send_live_stream_start
      @camera.start_streaming_protocol()
    end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest

    # Get the parameters for all test cases.  Shuffle if necessary
    test_params = tu_get_multi_photo_burst_test_params()
    failed_arr = []

    if test_params.empty?
      log_info("No tests to run!  Check RES/BURST chosen")
      return
    else
      log_info("Running #{test_params.length} test cases")
    end
    test_params.shuffle! if @options[:shuffle]

    # Put camera in right mode for testing the first preview stream.
    @camera.set_capture_mode("BURST") if @camera.test_preview_stream == true

    counter = 0
    test_params.each { |res, bu, orient, spot, pt, wb, col, sh, iso, ex|
      counter += 1
      next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
      log_info("Running test #{counter} of #{test_params.length}")

      tc_name = "#{res}_#{bu}_#{orient}"
      tc_name += "_spot_#{spot}" if spot != nil
      tc_name += "_protune_#{pt}" if pt != nil
      tc_name += "_#{wb}"  if wb != nil
      tc_name += "_#{col}" if col != nil
      tc_name += "_#{iso}" if iso != nil
      tc_name += "_#{sh}"  if sh != nil
      tc_name += "_#{ex}"  if ex != nil
      set_tc_name(tc_name)

      ntsc_ts_before = "#{@options[:save_dir]}/#{tc_name}_ntsc_before.ts"
      ntsc_ts_after = "#{@options[:save_dir]}/#{tc_name}_ntsc_after.ts"
      pal_ts_before = "#{@options[:save_dir]}/#{tc_name}_pal_before.ts"
      pal_ts_after = "#{@options[:save_dir]}/#{tc_name}_pal_after.ts"

      begin
        tu_keep_or_delete_all_media()
        tu_verify_sd_status()

        # Capture the pictures
        list_before = @camera.get_medialist("JPG")
        log_verb("List before burst: #{list_before}")

        #ts file contains different frame rate depending on video format
        if @camera.test_preview_stream == true
          #ts file contains different frame rate depending on video format
          ret, msg = @camera.set_video_format("NTSC")
          log_info("Saving preview streaming (ts) file in NTSC mode before capture")
          failed_arr << msg if ret == false
          isTimeout_ntsc_before = tu_save_idle_stream(ntsc_ts_before)
          if isTimeout_ntsc_before == false
            failed_arr <<  tu_analyze_photo_ts_idled_metadata(ntsc_ts_before, "NTSC")
          else
            failed_arr << "Unable to get idle stream #{ntsc_ts_before}"
          end

          ret, msg = @camera.set_video_format("PAL")
          log_info("Saving preview streaming (ts) file in PAL mode before capture")
          failed_arr << msg if ret == false
          isTimeout_pal_before = tu_save_idle_stream(pal_ts_before)
          if isTimeout_pal_before == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_before, "PAL")
          else
            failed_arr << "Unable to get idle stream #{pal_ts_before}"
          end
        end

        ret, msg = @camera.capture_multi_photo_burst(res, bu, orient, spot, pt, wb, col, sh, iso, ex)
        # Check that capture was successful
        if ret == false
          if @camera.interfaces.include?(:serial)
            if @camera.is_alive?
              @camera.do_reset()
            else
              @camera.detect_crash_and_reboot()
            end
          end
          fail(msg)
          next
        end
        log_info(msg)

        if @camera.test_preview_stream == true
          ret, msg = @camera.set_video_format("NTSC")
          log_info("Saving preview streaming (ts) file in NTSC mode after capture")
          failed_arr << msg if ret == false
          isTimeout_ntsc_after = tu_save_idle_stream(ntsc_ts_after)
          if isTimeout_ntsc_after == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_after, "NTSC")
          else
            failed_arr << "Unable to get idle stream #{ntsc_ts_after}"
          end

          ret, msg = @camera.set_video_format("PAL")
          log_info("Saving preview streaming (ts) file in PAL mode after capture")
          failed_arr << msg if ret == false
          isTimeout_pal_after = tu_save_idle_stream(pal_ts_after)
          if isTimeout_pal_after == false
            failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_after, "PAL")
          else
            failed_arr << "Unable to get idle stream #{pal_ts_after}"
          end
        end

        # Check the number of pics taken matches expectations
        list_after = @camera.get_medialist("JPG")
        log_verb("List after burst: #{list_after}")
        jpg_array = list_after - list_before
        tu_map_media_list( __FILE__, tc_name, jpg_array )
        exp = bu.split("_")[0].to_i    # e.g. 10_1 -> 10 photos
        act = jpg_array.length
        log_info("Checking that we have #{exp} photos")
        failed_arr << assert_equal(exp, act, "Number of pics expected (#{exp}) != taken (#{act})")

        jpg_array.sort.each { |jpgfile|

          sleep 1
          f = tu_basename(jpgfile) # Just get GYYYXXXX.JPG
          # File name convention checks
          failed_arr << tu_analyze_file_name("BURST", f)
          if @camera.interfaces.include?(:wifi)
            # Metadata checks over HTTP (faster)
            full_path =  @camera.get_media_url(jpgfile)
            failed_arr << tu_analyze_photo_metadata(full_path, :burst, res, bu)
            # GPMediaList or camera roll verification
            failed_arr << tu_wifi_analyze_gpmedialist_params("BURST")
          else
            ############## Skip over serial for now
            # Metadata checks
            #to_dir = @options[:save_dir]
            #to_dir = "/tmp" if to_dir == nil
            #full_path = @camera.download_media(fname, to_dir)
            #failed_arr << tu_analyze_photo_metadata(full_path, :burst, res, nil)
          end
          # Group and object number verification
          log_info("Checking group numbering")
          grp_num = f[1..3].to_i
          exp_grp_num = grp_num if exp_grp_num == nil
          failed_arr << assert_equal(exp_grp_num, grp_num,
          "(#{f}) Group # exp=#{exp_grp_num}, act=#{grp_num}")

          log_info("Checking file index numbering")
          obj_num = f[4..7].to_i
          exp_obj_num = obj_num if exp_obj_num == nil
          failed_arr << assert_equal(exp_obj_num, obj_num,
          "(#{f}) Object # exp=#{exp_obj_num}, act=#{obj_num}")
          if exp_obj_num == 999
            exp_grp_num +=1
            exp_obj_num = 1
          else
            exp_obj_num += 1
          end
        }

        # Log any failures in quality/metadata and move on to the next
        if has_failure?(failed_arr)
          if @camera.interfaces.include?(:serial)
            if @camera.is_alive?
              @camera.do_reset()
            else
              @camera.detect_crash_and_reboot()
            end
            sleep(5.0)
          end
        else
          log_pass
        end
        failed_arr.clear
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    }

    # Stop preview streaming if it was started
    if @camera.test_preview_stream == true
      @camera.send_live_stream_stop
      @camera.stop_streaming_protocol
    end

  end # end runtest

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @host.kill_status_process() if @host
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev,
      :multi_photo_resolution, :multi_photo_burst, :keep_media,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :multi_photo_spot_meter, :multi_photo_pt, :multi_photo_pt_wb, :multi_photo_pt_sharp,
      :multi_photo_pt_iso, :multi_photo_pt_color, :multi_photo_pt_ev, :range, :download_media,
      :shuffle, :set_defaults, :battoutlet, :usboutlet, :reset_on_failure, :dryrun, :verb, :full]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
