# test_video_simple_metadata.rb
# Description: Part two of the serial metadata test.  This script must
# be pointed to the directory where the SD card is loaded via the 
# '--save_dir' argument.  It then reads /tmp/metadata-dump.txt to match up
# what the expected RES/FPS/FOV should be for the MP4 files in save_dir.
# Tests the following items:
#   - The following video metadata is correct:
#     - aspect_ratio
#     - audio_channels
#     - audio_codec
#     - audio_sample_rate
#     - bitrate
#     - colorspace
#     - frame_rate
#     - has_timecode
#     - height
#     - width
#     - video_codec
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    $host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
    elsif @options[:ip] != nil and @options[:pc] != nil
      @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    # Add ability to do metadata analysis over Wi-Fi
    if @options[:save_dir] == nil
      cam_ip = "10.5.5.9"
      if not $host.pingable?(cam_ip)
        ssid, pc = @camera.enable_app_mode()
        if ssid == false
          log_error("Unable to enable APP mode on camera")
          exit 1
        else
          sleep(15)
          retries = 5
          (1..retries).each { |n|
            ret = $host.connect_to_ap(ssid, pc)
            (sleep(5); next) if ret == false
            if not $host.wait_for_wifi_camera(cam_ip, timeout=30)
              if n < retries
                log_info("Retrying Wi-Fi connection (#{n+1} of #{retries})")
                next
              else
                log_error("Unable to connect to camera Wi-Fi")
                exit 1
              end
            end
          }
        end
      end
      @wifi_cam = get_wifi_camera(cam_ip)
    end
  end

  def test_metadata()
    if File.exists?($metadata_dump_file)
      log_warn("#{$metadata_dump_file} exists!  Deleting to start fresh")
      File.delete($metadata_dump_file)
    end
    if $video_data != []
      file_arr = $video_data
    else
      file_arr = []
      File.open($data_log, "r").each { |line|
        log_verb(line)
        res, fps, fov, pt, mp4file = line.split(",")
        next if [res, fps, fov, pt, mp4file].include?(nil)
        # FPS needs to be converted to int or float depending
        (fps.to_i == fps.to_f) ? fps = fps.to_i : fps = fps.to_f
        file_arr << [res.strip, fps, fov.strip, pt.strip, mp4file.strip]
      }
    end

    save_dir = @options[:save_dir]
    if save_dir != nil
      if not File.directory?(save_dir)
        log_warn("Unable to find directory #{save_dir}")
        exit 1
      end
      all_files = Dir.glob(File.join(save_dir, "**", "*.MP4"))
    else
      all_files = @wifi_cam.get_medialist()
    end

    file_arr.each { |res, fps, fov, pt, mp4file|
      if pt == "OFF"
        set_tc_name("#{res}_#{fps}_#{fov}_metadata")
      else
        set_tc_name("#{res}_#{fps}_#{fov}_protune_metadata")
      end
      curr_file = nil
      all_files.each { |f| 
        if File.basename(f) == mp4file
          if save_dir != nil
            curr_file = f
          else
            curr_file = @wifi_cam.get_media_url(f)
          end
          break
        end
      } # end all_files.each
      if curr_file == nil
        fail("Unable to find #{mp4file} on camera")
        next
      else
        check_meta(curr_file, res, fps, fov, pt)
      end
    } # end file_arr.each
  end # end def test_metadata
  
  def check_meta(mp4file, res, fps, fov, pt)
    # Metadata should match expectations
    # Failure messages will be added to the failed array
    failed_arr = []
    
    pt_flag = (pt == "ON")  # Convert ON/OFF to true/false

    # Compare the MP4 file
    exp = VideoMetadata.new()
    exp.aspect_ratio       = @camera.video_capture_modes[res][:aspect_ratio]
    exp.audio_channels     = @camera.audio_channels
    exp.audio_codec        = @camera.audio_codec
    exp.audio_sample_rate  = @camera.audio_sample_rate
    exp.video_bitrate      = @camera.get_bitrate(res, fps, pt)
    exp.colorspace         = @camera.colorspace
    exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:frame_rate]
    exp.has_timecode       = @camera.mp4_has_timecode?(res, fps)
    exp.height             = @camera.video_capture_modes[res][:height]
    exp.video_codec        = @camera.video_codec
    exp.width              = @camera.video_capture_modes[res][:width]
    exp.profile_level      = @camera.get_profile_level(res, fps, pt)

    act = $host.get_video_metadata(mp4file)
    if act == nil
      fail("Unable to open video file")
      return
    end
    log_info("Checking MP4 file metadata")
    failed_arr << assert_equal(exp.aspect_ratio, act.aspect_ratio,
    "aspect_ratio (exp=#{exp.aspect_ratio} != act=#{act.aspect_ratio})")
    failed_arr << assert_equal(exp.audio_channels, act.audio_channels,
    "audio_channels (exp=#{exp.audio_channels} != act=#{act.audio_channels})")
    failed_arr << assert_equal(exp.audio_codec, act.audio_codec,
    "audio_codec (exp=#{exp.audio_codec} != act=#{act.audio_codec})")
    failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate,
    "audio_sample_rate (exp=#{exp.audio_sample_rate} != act=#{act.audio_sample_rate})")
    failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
    "video_bitrate (exp=#{exp.video_bitrate} not within 15% of act=#{act.video_bitrate})")
    failed_arr << assert_equal(exp.colorspace, act.colorspace,
    "colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
    failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
    "frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
    failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
    "has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
    failed_arr << assert_equal(exp.width, act.width,
    "width (exp=#{exp.width} != act=#{act.width})")
    failed_arr << assert_equal(exp.height, act.height,
    "height (exp=#{exp.height} != act=#{act.height})")
    failed_arr << assert_equal(exp.video_codec, act.video_codec,
    "video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
    failed_arr << assert_equal(exp.profile_level, act.profile_level,
    "AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")
    
    # ProTune mode should not produce LRV files in HD3/+
    # ProTune SHOULD produce LRV in HD4
    if ["WHITE", "SILVER", "BLACK", "SILVER_PLUS", "BLACK_PLUS"].include?(@camera.name)
      expect_lrv = false if pt_flag == true
    end

    meta_info_fields = [
      "%s / %s / %s" %[res, fps, fov], 
      act.width,
      act.height,
      act.frame_rate,
      act.video_bitrate,
      act.profile_level,
      act.audio_bitrate,
      act.audio_codec,
      act.audio_channels,
      act.audio_sample_rate,
      act.colorspace,
      act.aspect_ratio,
      act.video_codec
    ]

    # Now check for LRV existence
    expect_lrv = @camera.has_lrv?(res, fps, fov, pt)
    lrvfile = mp4file[0...-3] + "LRV"
    if @options[:save_dir] != nil
      file_exists = File.exists?(lrvfile)
      act = $host.get_video_metadata(lrvfile) if file_exists == true
    else
      act = $host.get_video_metadata(lrvfile)
      file_exists = (act != nil)
    end
    lrv_exists = (file_exists == true) ? "YES" : "NO"

     # Compare the LRV file (if applicable)
    if expect_lrv == true and file_exists == false
      failed_arr << "LRV file not found at #{lrvfile}"
      meta_info_fields += [lrv_exists, "", "", "", "", "", "", "", "", "", ""]
    elsif expect_lrv == false and file_exists == true
      failed_arr << "Unexpected LRV file found."
      meta_info_fields += [lrv_exists, "", "", "", "", "", "", "", "", "", ""]
    elsif expect_lrv == false and file_exists == false
      # Correct case if we do not expect the LRV.  Skip to the next.
      meta_info_fields += [lrv_exists, "", "", "", "", "", "", "", "", "", ""]
    elsif expect_lrv == true and file_exists == true
      meta_info_fields += [
      lrv_exists,
      act.width,
      act.height,
      act.frame_rate,
      act.video_bitrate,
      act.audio_sample_rate,
      act.audio_codec,
      act.audio_channels,
      act.colorspace,
      act.aspect_ratio,
      act.video_codec
    ]
      exp = VideoMetadata.new()
      exp.audio_channels     = @camera.audio_channels
      exp.audio_codec        = @camera.audio_codec
      exp.audio_sample_rate  = @camera.audio_sample_rate
      exp.video_bitrate      = @camera.get_lrv_bitrate(res, fps)
      exp.colorspace         = @camera.colorspace
      exp.frame_rate         = @camera.video_capture_modes[res][:fps][fps][:lrv_fps]
      exp.has_timecode       = @camera.lrv_has_timecode?(res, fps)
      exp.height             = @camera.get_lrv_height(res, fps)
      exp.video_codec        = @camera.video_codec
      exp.width              = @camera.get_lrv_width(res, fps)
      exp.profile_level      = @camera.get_lrv_profile_level(res, fps)
      
      log_info("Checking LRV file metadata")
      failed_arr << assert_equal(exp.audio_channels, act.audio_channels,
      "lrv_audio_channels (exp=#{exp.audio_channels} != act=#{act.audio_channels})")
      failed_arr << assert_equal(exp.audio_codec, act.audio_codec,
      "lrv_audio_codec (exp=#{exp.audio_codec} != act=#{act.audio_codec})")
      failed_arr << assert_equal(exp.audio_sample_rate, act.audio_sample_rate,
      "lrv_audio_sample_rate (exp=#{exp.audio_sample_rate} != act=#{act.audio_sample_rate})")
      if exp.video_bitrate != nil
        failed_arr << assert_delta(exp.video_bitrate, act.video_bitrate, exp.video_bitrate*0.15,
        "lrv_video_bitrate (exp=#{exp.video_bitrate} not within 15% of act=#{act.video_bitrate})")
      end
      failed_arr << assert_equal(exp.colorspace, act.colorspace,
      "lrv colorspace (exp=#{exp.colorspace} != act=#{act.colorspace})")
      failed_arr << assert_equal(exp.frame_rate, act.frame_rate,
      "lrv frame_rate (exp=#{exp.frame_rate} != act=#{act.frame_rate})")
      failed_arr << assert_equal(exp.has_timecode, act.has_timecode,
      "lrv has_timecode (exp=#{exp.has_timecode} != act=#{act.has_timecode})")
      failed_arr << assert_equal(exp.width, act.width,
      "lrv_width (exp=#{exp.width} != act=#{act.width})")
      failed_arr << assert_equal(exp.height, act.height,
      "lrv_height (exp=#{exp.height} != act=#{act.height})")
      failed_arr << assert_equal(exp.video_codec, act.video_codec,
      "lrv_video_codec (exp=#{exp.video_codec} != act=#{act.video_codec})")
      failed_arr << assert_equal(exp.profile_level, act.profile_level,
      "LRV AVC profile level (exp=#{exp.profile_level} != act=#{act.profile_level})")
    else
      log_warn("Unhandled case! pt_flag=%s, expect_lrv=%s, lrvfile=%s, file_exists=%s" \
        %[pt_flag, expect_lrv, lrvfile, file_exists])
    end

    # TODO Analyze THM file (if applicable)
    #expect_thm = ...
    thmfile = mp4file[0...-3] + "THM"
    qual = $host.get_quality(thmfile)
    if qual > 0
      log_info("THM file exists (quality=#{qual})")
      thm_exists = "YES"
    else
      log_info("THM does not exist for this mode")
      thm_exists = "NO"
    end

    meta_info_fields += [
      thm_exists
    ]
    temp = ["%s"] * meta_info_fields.length
    meta_info_str = temp.join(",") %meta_info_fields
    if @options[:full] == true
      File.open($metadata_dump_file, "a") { |f| f.puts(meta_info_str) } 
    end

    # Finally fail the test if any errors are in our array
    failed_arr.compact!
    if failed_arr.length > 0
      fail(failed_arr.join(","))
      return
    end
    log_pass("All metadata checks passed")
  end

  def runtest()
    # This global will hold mapping between RES/FPS/FOV/PT and video files
    $video_data = []
    # From simple_video_capture.rb
    $data_log = File.join("/tmp", "#{@camera.addr}-capture-data.txt")
    if not File.exists?($data_log)
      log_error("#{$data_log} not found!")
      return
    end
    
    test_metadata()
  end # end runtest

  def cleanup
    @camera.set_wireless_mode("OFF") if @camera
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :save_dir, :full,
                   :battoutlet, :usboutlet, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    $metadata_dump_file = "/tmp/metadata-dump.txt"
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
