# test_video_simple_capture.rb
# Description: The first part of a two-part test ov video metadata via
# serial console commands.  In part one the camera iterates over all 
# RES/FPS/FOV with both ProTunes off and on (if supported) and captures 
# a short video.  Details of the capture are recorded to a file saved on the
# host computer in /tmp/metadata-dump.txt.
#
# For part 2 the test operator must take the SD card out of the camera and
# load it on the host system before running test_video_simple_metadata.rb

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils

  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    $host = Host.new
    if @options[:serialdev] != nil
      @camera = get_serial_camera(@options[:serialdev])
     elsif @options[:ip] != nil and @options[:pc] != nil
       @camera = get_wifi_camera(@options[:ip], @options[:pc])
    else
      log_error("Must specify either serial or ip/pc")
      exit 1
    end
    @camera.powerstrip = PowerStrip.new(@options[:power_ip], 
                         @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.exit_mass_storage_mode() if @camera.is_mounted?
    @camera.delete_all_media() if not @options[:quick]
    @camera.exit_mass_storage_mode() if @camera.is_mounted?
    set_options()
  end

  def test_capture(vm, res, pt, fps, fov, duration, tries=2)
    (1..tries).each { |n|
      @camera.disable_power_save()
      sleep(3.0)
      log_info("TRY #{n} -- Capturing #{duration} seconds of #{vm}/#{res}/#{fps}/#{fov} video")
          
      # ret, msg = @camera.capture_video(vm, res, fps, fov, duration, nil, retries=1)
      ret, msg = @camera.capture_video(vm, res, fps, fov, duration, ll=nil, spot=nil, 
        pt, wb=nil, co=nil, sh=nil, iso=nil, ex=nil)
      if ret == false
        @camera.do_reset()
        sleep(3.0)
        next if n < tries
        fail(msg)
        return
      end
      
      mp4file = @camera.last_video_attempted
      if mp4file == nil
        @camera.do_reset()
          sleep(3.0)
          next if n < tries
          fail("No MP4 file name seen in logging output")
          return
      else
        log_info("Checking that #{mp4file} is on the SD card")
        if @camera.find_file(mp4file) == true
          $video_data << [res, fps, fov, pt, mp4file]
          s = "#{res}, #{fps}, #{fov}, #{pt}, #{mp4file}"
          File.open($data_log, "a") { |f| f.puts(s) } if $data_log != nil
          pass("Capture successful and video file #{mp4file} found on SD card")
          return
        else
          @camera.do_reset()
          sleep(3.0)
          next if n < tries
          fail("Unable to find #{mp4file} on SD card")
          return
        end
      end
    } # end tries
  end

  def runtest()
    # This global will hold mapping between RES/FPS/FOV/PT and video files
    $video_data = []
    # Something like /tmp/ttyUSB0-capture-data.txt
    $data_log = File.join("/tmp", "#{@camera.addr}-capture-data.txt")
    if File.exists?($data_log)
      log_warn("#{$data_log} exists!  Deleting to start fresh")
      File.delete($data_log)
    end
    
    if @options[:quick] == true
      test_metadata()
      return
    end
    
    # Enumerate all the test combinations
    test_params = []
    ["NTSC", "PAL"].each do |vm|
      next if vm == "PAL" and @options[:ntsc_only] == true
      next if vm == "NTSC" and @options[:pal_only] == true
      @camera.get_video_resolution().each do |res|
        next if @options[:video_resolution] != nil and @options[:video_resolution] != res
        @camera.get_video_fps(res).each do |fps|
          next if vm == "PAL" and not @camera.is_pal?(res, fps)
          next if vm == "NTSC" and not @camera.is_ntsc?(res, fps)
          next if @options[:video_fps] != nil and @options[:video_fps] != fps
          @camera.get_video_fov(res, fps).each do |fov|
            next if @options[:video_fov] != nil and @options[:video_fov] != fov
            log_verb("Adding test [#{vm}, #{res}, #{fps}, #{fov}]")
            test_params << [vm, res, fps, fov]
          end # fov
        end # fps
      end # res
    end # vm
    if test_params.length == 0
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end
    test_params.shuffle! if @options[:shuffle]
    
    # Now run each test
    duration = (@options[:duration] != nil) ?  @options[:duration] : 5 #seconds
    if @options[:duration_range_low] and @options[:duration_range_high]
      duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
      log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
    end

    if @options[:video_pt] == nil or @options[:video_pt] == "OFF"
      test_params.each do |vm, res, fps, fov|
        set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_capture")
        begin
          test_capture(vm, res, "OFF", fps, fov, duration)
          break if @hard_fail and @assertion_failed
        rescue StandardError => e
          log_error(e.to_s + "\n" + e.backtrace.join("\n"))
        end
      end # end test_params
    end # end protune=nil/OFF
    if @options[:video_pt] == nil or @options[:video_pt] == "ON"
      test_params.each do |vm, res, fps, fov|
        set_tc_name("#{vm}_#{res}_#{fps}_#{fov}_protune_capture")
        begin
          test_capture(vm, res, "ON", fps, fov, duration)
          break if @hard_fail and @assertion_failed
        rescue StandardError => e
          log_error(e.to_s + "\n" + e.backtrace.join("\n"))
        end
      end # end test_params
    end # end protune=nil/ON 
  end # end runtest

  def cleanup
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, 
      :battoutlet, :usboutlet, 
      :video_resolution, :video_fps, :video_fov,
      :video_spot_metering, :video_low_light, :ntsc_only, :pal_only,
      :video_pt, :video_pt_color, :video_pt_wb, :video_pt_iso, :video_pt_sharp, :video_pt_ev,
      :setup_default_mode, :def_video_submode, :set_defaults, :full, :quickcapture,
      :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :duration, :shuffle, :save_dir, :verb, :quick]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
