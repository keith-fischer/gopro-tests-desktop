# test_muid.rb
# Description:  Verifies the GoPro Media Unique IDentified (MUID),
# GoPro's version of a UUID for each media file.
# Tests the following items:
#   - MUID for videos
#   - MUID for photos
# Reference: https://wiki.gopro.com/display/FEH/UUID+investigations

require 'digest'
require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def intialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
    set_options()
  end

  # Verifies the MUID on all files
  def verify_mp4_muid()
    # Initialize previous MUID for comparisons
    @prev_muid = nil

    # Save the time the video was created
    date_str = @camera.get_status_api2(:date_time)

    # Download the videos
    save_dir = @options[:save_dir]
    n = 0
    base_tc_name = @tc_name
    media = @camera.get_medialist("MP4")
    if media == nil or media.empty?
      fail("No media found")
      return false
    end

    # Check each MUID

    # NOTE: Jira ticket FWAU-234 may require getting the entire file instead of partially
    media.each { |m|
      n += 1
      set_tc_name(base_tc_name + "_file#{n}") if n > 1
      url = @camera.get_media_url(m)
      ranges = ["0-500000", "-2000000"] # First 500 kB and last 2000 kB.
      muid = nil
      ranges.each { |byte_range|
        ret = @host.curl(url, local=save_dir, overwrite=true, range=byte_range)
        (ret == false) ? (fail("Unable to get #{url}"); return) : log_info(ret)
        muid = tu_read_muid_mp4(ret)
        break if muid != nil
        log_verb("Could not find MUID atom in byte range #{range}")
      }
      if muid == nil
        fail("Unable to find mUID atom in file #{m}")
      else
        verify_muid(muid, date_str) if muid != nil
      end
    }
  end

  def verify_jpg_muid()
    # Initialize previous MUID for comparisons
    @prev_muid = nil

    # Save the time the video was created
    date_str = @camera.get_status_api2(:date_time)

    # Download the first couple photos
    save_dir = @options[:save_dir]
    n = 0
    base_tc_name = @tc_name
    media = @camera.get_medialist("JPG")[0..1]
    if media == nil or media.empty?
      fail("No media found")
      return false
    end

    # Check each MUID
    media.each { |m|
      n += 1
      set_tc_name(base_tc_name + "_file#{n}") if n > 1
      url = @camera.get_media_url(m)
      ret = @host.curl(url, local=save_dir, overwrite=true) # Just download the whole image
      (ret == false) ? (fail("Unable to get #{url}"); return) : log_info(ret)
      muid = tu_read_muid_jpg(ret)
      verify_muid(muid, date_str)
    }
  end

  def permissive_md5_fail(str)
    if @options[:permissive] and ["BACKDOOR", "PIPE"].include?(@camera.name)
      str += ".  Known issue (BKDR-4514). Will not fix."
      log_skip(str)
    else
      fail(str)
    end
  end

  # relax causes the timestamp limits to be relaxed by M minutes
  # Useful for chaptered video, etc.
  def verify_muid(muid, date_str)
    # Set the expected values
    exp_csn = Digest::MD5.new.update(@camera.serialno.upcase).hexdigest
    # Ex. "%0F%01%02%10%28%0B" -> [15, 1, 2, 16, 40, 11] Y,M,D,h,m,s
    exp_year, exp_month, exp_day, exp_hour, exp_min, exp_sec = \
    date_str.split("%").reject{|n| n.empty?}.map {|h| h.to_i(16)}
    exp_year += 2000

    log_verb("MD5 calc: %s => %s" %[@camera.serialno.upcase, exp_csn])
    log_verb("MUID MD5: %s => %s" %[@camera.serialno.upcase, muid[:md5sn]])
    log_verb("RTOS time: %s-%s-%s %s:%02d:%02d" \
    %[exp_year, exp_month, exp_day, exp_hour, exp_min, exp_sec])
    log_verb("MUID time: %s-%s-%s %s:%02d:%02d" \
    %[muid[:year], muid[:month], muid[:day], muid[:hour], muid[:mins], muid[:secs]])
    log_verb("MUID tick:#{muid[:top_ms].to_s(2)} tock:#{muid[:bot_ms].to_s(2)}")

    base_tc_name = @tc_name
    set_tc_name(base_tc_name + "_md5_enc_ser_num")
    fail_str = assert_equal(exp_csn, muid[:md5sn],
    "Wrong encoded (MD5) camera serial number")
    fail_str == nil ? pass : permissive_md5_fail(fail_str)
    set_tc_name(base_tc_name + "_year")
    fail_str = assert_equal(exp_year, muid[:year], "MUID: Year mismatch")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_month")
    fail_str = assert_equal(exp_month, muid[:month], "MUID: Month mismatch")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_day")
    fail_str = assert_equal(exp_day, muid[:day], "MUID: Day mismatch")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_hour")
    fail_str = assert_equal(exp_hour, muid[:hour], "MUID: Hour mismatch")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_minutes")
    fail_str = assert((muid[:mins] >= 0 && muid[:mins] < 60),
    "MUID: Minutes not between 0 and 59") # Any valid is ok
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_seconds")
    fail_str = assert((muid[:secs] >= 0 && muid[:secs] < 60),
    "MUID: Seconds not between 0 and 59") # Any valid is ok
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_ms_tick_top16")
    fail_str = assert(muid[:top_ms] > 0, "MUID: Top 16 bits of ms tick are zero")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_ms_tick_bot16")
    fail_str = assert(muid[:bot_ms] > 0, "MUID: Bottom 16 bits of ms tick are zero")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_reserved1")
    fail_str = assert_equal(0, muid[:rsvd1], "MUID: Reserved 1 is nonzero")
    fail_str == nil ? pass : fail(fail_str)
    set_tc_name(base_tc_name + "_reserved2")
    fail_str = assert_equal(0, muid[:rsvd2], "MUID: Reserved 2 is nonzero")
    fail_str == nil ? pass : fail(fail_str)
    if @prev_muid != nil
      set_tc_name(base_tc_name + "_not_match_prev")
      fail_str = assert(muid != @prev_muid, "MUID matches previous file MUID.  Not unique!")
      fail_str == nil ? pass : fail(fail_str)
    end
    @prev_muid = muid
    return true
  end

  def runtest
    set_tc_name("verify_muid_video")
    @camera.delete_all_media()
    sleep(5.0)
    # Capture chapter length + 180 seconds to ensure a second chapter
    video_params = tu_get_video_res_with_protune()[0].shuffle[0]
    vm, res, fps, fov, orient, ll, spot, pt = video_params[0..7]
    chap_len = (@camera.chapter_size * 8) / (1000000 * @camera.get_bitrate(res, fps, pt))
    duration = (chap_len + 180).to_i
    log_info("Capturing single video for %02d:%02d" %[duration/60, duration%60])
    video_params.insert(4, duration)
    ret, msg = @camera.capture_video(*video_params)
    ret = true
    (ret == false) ? fail(msg) : verify_mp4_muid()

    if @camera.video_looping_support? == true
      set_tc_name("verify_muid_video_looping")
      @camera.delete_all_media()
      sleep(5.0)
      # Get the minimum looping interval
      intervals = @camera.get_video_looping_intervals().reject { |n| n.to_i == 0 }
      min_interval = intervals.sort_by { |s| s.to_i }[0] # Sort strings as integers
      chap_len = @camera.looping_chapter_len[min_interval]
      # Make the video for second chapter +20 seconds long
      duration = chap_len * 60 + 20
      params_tmp = tu_get_video_res_with_protune()[0].shuffle[0]
      video_params = params_tmp[0..3] << min_interval << duration
      ret, msg = @camera.capture_looping(*video_params)
      (ret == false) ? fail(msg) : verify_mp4_muid()
    end

    if @camera.video_piv_support? == true
      set_tc_name("verify_muid_video_piv")
      @camera.delete_all_media()
      sleep(5.0)
      piv = @camera.get_video_piv_intervals[0]
      duration = piv.to_i * 2.1
      params_tmp = tu_get_piv_res.shuffle[0]
      video_params = params_tmp[0..3] << piv << duration
      ret, msg = @camera.capture_piv(*video_params)
      if ret == false
        fail(msg)
      else
        base_tc_name = @tc_name
        set_tc_name("#{base_tc_name}_mp4")
        verify_mp4_muid()
        set_tc_name("#{base_tc_name}_jpg")
        verify_jpg_muid()
      end
    end

    set_tc_name("verify_muid_single_photo")
    @camera.delete_all_media()
    sleep(5.0)
    photo_params = tu_get_photo_test_params.shuffle[0]
    ret, msg = @camera.capture_photo_single(*photo_params)
    (ret == false) ? fail(msg) : verify_jpg_muid()

    if @camera.photo_continuous_support? == true
      set_tc_name("verify_muid_continuous_photo")
      @camera.delete_all_media()
      sleep(5.0)
      duration = 5
      params_tmp = tu_get_photo_continuous_test_params.shuffle[0]
      photo_params = params_tmp[0..1] << duration
      photo_params += params_tmp[2..-1]
      ret, msg = @camera.capture_photo_continuous(*photo_params)
      (ret == false) ? fail(msg) : verify_jpg_muid()
    end

    if @camera.photo_night_support? == true
      set_tc_name("verify_muid_night_photo")
      @camera.delete_all_media()
      sleep(5.0)
      duration = 5
      params_tmp = tu_get_photo_night_test_params[0]
      photo_params = [params_tmp[0]] << duration
      ret, msg = @camera.capture_photo_night(*photo_params)
      (ret == false) ? fail(msg) : verify_jpg_muid()
    end

    set_tc_name("verify_muid_burst_photo")
    @camera.delete_all_media()
    sleep(5.0)
    photo_params = tu_get_multi_photo_burst_test_params.shuffle[0]
    ret, msg = @camera.capture_multi_photo_burst(*photo_params)
    (ret == false) ? fail(msg) : verify_jpg_muid()

    set_tc_name("verify_muid_timelapse_photo")
    @camera.delete_all_media()
    sleep(5.0)
    # Just take 0.5s timelapse.
    params_tmp = tu_get_multi_photo_timelapse_test_params[0]
    duration = params_tmp[1].to_f * 2.1 # PES value * 2.1
    photo_params = params_tmp[0..1] << duration
    photo_params += params_tmp[2..-1]
    ret, msg = @camera.capture_multi_photo_timelapse(*photo_params)
    (ret == false) ? fail(msg) : verify_jpg_muid()

    if @camera.multi_photo_nightlapse_support? == true
      set_tc_name("verify_muid_nightlapse_photo")
      @camera.delete_all_media()
      sleep(5.0)
      pes = @camera.get_multi_photo_nightlapse_rates[0]
      duration = pes.to_i * 2.1
      params_tmp = tu_get_photo_continuous_test_params.shuffle[0]
      photo_params = [params_tmp[0]] << pes << duration
      ret, msg = @camera.capture_multi_photo_nightlapse(*photo_params)
      (ret == false) ? fail(msg) : verify_jpg_muid()
    end
  end

  def cleanup
    @host.kill_status_process() if @host
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :photo_resolution, :photo_shutter_ev, :photo_pt, :photo_spot_metering,
      :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :save_dir, :shuffle, :quick, :full, :verb, :permissive]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil

    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
