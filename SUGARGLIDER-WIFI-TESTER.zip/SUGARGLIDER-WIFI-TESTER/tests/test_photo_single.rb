# test_photo_single.rb
# Description:  Tests the single shot still image functionality
# Tests the following items:
#   - Filename compliance (GOPRXXXX)
#   - Metadata (res, format)
#   - gpMediaList parameters (used for camera roll on Smarty)

require 'fileutils'

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def intialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.do_factory_reset("USER") if @camera.interfaces and @camera.interfaces.include?(:serial)
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()

    tu_keep_or_delete_all_media()
    tu_verify_sd_status()

    # Start preview stream on cameras that we want to test it
    if @camera.test_preview_stream == true
      ret, msg = @host.get_system_camera_ip(@camera.ip)
      ret == true ? @camera.system_address = msg : (log_info(msg); exit 1)
      @camera.send_live_stream_start
      @camera.start_streaming_protocol()
    end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    failed_arr = []

    if @options[:raw] == "ON" && @options[:wdr] == "ON"
      log_error("Incompatible settings. RAW and WDR can not both be ON. Exiting.")
      exit 1
    end

    test_params = tu_get_photo_test_params

    if test_params.empty?
      log_warn("No tests to run!  Check RES/ProTune values")
    else
      log_info("Running #{test_params.length} test cases")
    end
    test_params.shuffle! if @options[:shuffle]

    # Put camera in right mode for testing the first preview stream.
    @camera.set_capture_mode("PHOTO") if @camera.test_preview_stream == true

    counter = 0
    test_params.each { |res, orient, spot, pt, wb, col, sh, iso, ex|
      counter += 1
      next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
      log_info("Running test #{counter} of #{test_params.length}")

      tc_name = "#{res}_#{orient}"
      tc_name += "_spot_#{spot}" if spot != nil #to be compatible with pre-Hawaii camera models which doesn't support spot metering
      tc_name += "_protune_#{pt}" if pt != nil  #to be compatible with pre-Hawaii camera models which doesn't support protune
      tc_name += "_#{wb}"  if wb != nil
      tc_name += "_#{col}" if col != nil
      tc_name += "_#{iso}" if iso != nil
      tc_name += "_#{sh}"  if sh != nil
      tc_name += "_#{ex}"  if ex != nil
      set_tc_name(tc_name)

      failed_arr = []
      ntsc_ts_before = "#{@options[:save_dir]}/#{tc_name}_ntsc_before.ts"
      ntsc_ts_after = "#{@options[:save_dir]}/#{tc_name}_ntsc_after.ts"
      pal_ts_before = "#{@options[:save_dir]}/#{tc_name}_pal_before.ts"
      pal_ts_after = "#{@options[:save_dir]}/#{tc_name}_pal_after.ts"

      if @camera.interfaces.include?(:wifi)
        begin
          list_before = @camera.get_medialist("JPG")
          ret, msg = @camera.set_capture_mode("PHOTO")
          (fail(msg); next) if ret == false

          if @camera.test_preview_stream == true
            #ts file contains different frame rate depending on video format
            ret, msg = @camera.set_video_format("NTSC")
            log_info("Saving preview streaming (ts) file in NTSC mode before capture")
            failed_arr << ret if ret == false
            isTimeout_ntsc_before = tu_save_idle_stream(ntsc_ts_before)
            if isTimeout_ntsc_before == false
              ret = tu_analyze_photo_ts_idled_metadata(ntsc_ts_before, "NTSC")
              failed_arr << ret if !ret.empty?()
            else
              failed_arr << "Unable to get idle stream #{ntsc_ts_before}"
            end

            ret, msg = @camera.set_video_format("PAL")
            log_info("Saving preview streaming (ts) file in PAL mode before capture")
            failed_arr << msg if ret == false
            isTimeout_pal_before = tu_save_idle_stream(pal_ts_before)
            if isTimeout_pal_before == false
              ret = tu_analyze_photo_ts_idled_metadata(pal_ts_before, "PAL")
              failed_arr << ret if !ret.empty?()
            else
              failed_arr << "Unable to get idle stream #{pal_ts_before}"
            end
          end

          if @camera.has_raw_support?
            ret, msg = @camera.set_photo_raw( @options[:raw] ? @options[:raw] : "OFF" )
            ret ? log_info(msg) : (fail(msg); next)
          end

          if @camera.has_wdr_support?
            ret, msg = @camera.set_photo_wdr( @options[:wdr] ? @options[:wdr] : "OFF" )
            ret ? log_info(msg) : (fail(msg); next)
          end

          ret, msg = @camera.capture_photo_single(res, orient, spot, pt, wb, col, sh, iso, ex)
          ret ? log_info(msg) : (fail(msg); next)

          if @camera.test_preview_stream == true
            ret, msg = @camera.set_video_format("NTSC")
            log_info("Saving preview streaming (ts) file in NTSC mode after capture")
            failed_arr << msg if ret == false
            isTimeout_ntsc_after = tu_save_idle_stream(ntsc_ts_after)
            if isTimeout_ntsc_after == false
              ret = tu_analyze_photo_ts_idled_metadata(ntsc_ts_after, "NTSC")
              failed_arr << ret if !ret.empty?()
            else
              failed_arr << "Unable to get idle stream #{ntsc_ts_after}"
            end

            ret, msg = @camera.set_video_format("PAL")
            log_info("Saving preview streaming (ts) file in PAL mode after capture")
            failed_arr << msg if ret == false
            isTimeout_pal_after = tu_save_idle_stream(pal_ts_after)
            if isTimeout_pal_after == false
              ret = tu_analyze_photo_ts_idled_metadata(pal_ts_after, "PAL")
              failed_arr << ret if !ret.empty?()
            else
              failed_arr << "Unable to get idle stream #{pal_ts_after}"
            end
          end

          list_after = @camera.get_medialist("JPG")
          if (list_before == false) and (list_after == false)
            (fail("photo capture failed, NO media: list_after=#{list_after} list_before=#{list_before}");next)
          end
          list = list_after - list_before
          tu_map_media_list( __FILE__, tc_name, list )
          exp = 1
          act = list.length

          failed_arr << assert_equal(exp, act, "# new media files incorrect (exp=#{exp}, act=#{act})")
          next if has_failure?(failed_arr)

          full_path =  @camera.get_media_url(list[0])
          # File name convention
          failed_arr << tu_analyze_file_name("PHOTO", File.basename(list[0]))

          # Metadata checks
          failed_arr << tu_analyze_photo_metadata(full_path, :single, res, nil)

          # GPMedialist checks
          failed_arr << tu_wifi_analyze_gpmedialist_params("PHOTO", nil)

          if @camera.test_preview_stream == true
            failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_before, "NTSC")
            failed_arr << tu_analyze_photo_ts_idled_metadata(ntsc_ts_after, "NTSC")
            failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_before, "PAL")
            failed_arr << tu_analyze_photo_ts_idled_metadata(pal_ts_after, "PAL")
          end

          unless has_failure?( failed_arr )
            log_pass( "Test passed." )
            if( @camera.has_raw_support? && @options[:raw] == "ON" )
              set_tc_name( "raw_ON_" + tc_name )
              log_pass( "Test passed." )
            end # raw pass
            if( @camera.has_wdr_support? && @options[:wdr] == "ON" )
              set_tc_name( "wdr_ON_" + tc_name )
              log_pass( "Test passed." )
            end # wdr pass
          end # has_failure?

        rescue WifiCameraError
          fail("Lost communication with camera")
          tu_reset_camera()
        rescue StandardError => e
          fail("General error: #{e.to_s}")
          puts e.backtrace.join("\n")
          tu_reset_camera()
        end #rescue block
      else
        #serial
        ret, msg = @camera.set_photo_protune(pt)
        if ret == false
          fail(msg)
          @camera.reset_board() if @camera.is_alive? == false
          next
        end

        if @camera.has_raw_support?
          ret, msg = @camera.set_photo_raw( @options[:raw] ? @options[:raw] : "OFF" )
          (fail(msg); @camera.reset_board() unless @camera.is_alive?; next) unless ret
          log_info(msg)
        end

        if @camera.has_wdr_support?
          ret, msg = @camera.set_photo_wdr( @options[:wdr] ? @options[:wdr] : "OFF" )
          (fail(msg); @camera.reset_board() unless @camera.is_alive?; next) unless ret
          log_info(msg)
        end

        ret, msg = @camera.capture_photo_single(res, spot, pt, wb, col, sh, iso, ex)
        if ret == false
          fail(msg)
          @camera.reset_board() if @camera.is_alive? == false
          next
        end
        log_info(msg)
        jpgfile = tu_basename(msg)
        tu_map_media_list( __FILE__ , tc_name, [ jpgfile ] ) # Might want to check this works.
        # Just check the filename convention
        failed_arr << assert(@camera.find_file(jpgfile), "#{jpgfile} not found on SD card")
        failed_arr << tu_analyze_file_name("PHOTO", jpgfile)

        unless has_failure?( failed_arr )
          log_pass( "Test passed." )
          if( @camera.has_raw_support? && @options[:raw] == "ON" )
            set_tc_name( "raw_ON_" + tc_name )
            log_pass( "Test passed." )
          end # raw pass
          if( @camera.has_wdr_support? && @options[:wdr] == "ON" )
            set_tc_name( "wdr_ON_" + tc_name )
            log_pass( "Test passed." )
          end # wdr pass
        end # has_failure?

      end # wifi or serial

    } #end test_params
    # Stop preview streaming if it was started
    if @camera.test_preview_stream == true
      @camera.send_live_stream_stop
      @camera.stop_streaming_protocol
    end
  end

  def cleanup
    tu_save_media()
    tu_map_media_done()
    @host.kill_status_process() if @host
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :photo_resolution, :photo_shutter_ev, :photo_pt, :photo_spot_metering,
      :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :setup_orientation,
      :save_dir, :shuffle, :quick, :full, :verb, :rc_info, :range, :keep_media,
      :download_media, :raw, :wdr]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil

    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
