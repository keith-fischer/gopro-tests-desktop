# test_photo_in_video.rb
# Description: Iterates over all RES/FPS/FOV  (no ProTunes)
#              and tests PIV settings on each.  It encodes
#              video and checks for JPGs.  Also checks for
#              the absence of JPGs on unsupported RES/FPS
#
# Note: Running with the --quick flag will skip all the
# negative tests and all FOV other than wide.

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    if !@camera.video_piv_support?()
      log_info("#{@camera.name} doesn't support photo in video feature")
      exit 1
    end

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()
  end

  def runtest
    failed_arr = []

    test_params = tu_get_piv_res()
    if test_params.empty?
      log_warn("No tests to run!  Check RES/FPS/PIV values")
    else
      log_info("Running #{test_params.length} test cases")
    end
    test_params.shuffle! if @options[:shuffle]

    counter = 0
    test_params.each() { |vm, res, fps, fov, piv, orient, ll, spot|
      counter += 1
      next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
      log_info("Running test #{counter} of #{test_params.length}")

      tc_name = "#{vm}_#{res}_#{fps}_#{fov}_piv_#{piv}_#{orient}"
      tc_name += "_spot_#{spot}" if spot
      tc_name += "_low_light_#{ll}" if ll
      set_tc_name(tc_name)

      begin
        tu_keep_or_delete_all_media()
        tu_verify_sd_status()

        before_list = @camera.get_medialist()

        # Set the length of the capture and expected number of photos. Not encoding piv "OFF" option
        # Duration can also be a random number in a range.
        if @options[:duration_range_low] and @options[:duration_range_high]
          duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
          log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
          exp_num_photos = duration.to_i / piv.to_i
        elsif @options[:duration] != nil
          duration = @options[:duration].to_f
          exp_num_photos = duration / piv.to_i
        else
          duration = piv.to_i * 2.5
          exp_num_photos = 2
        end
        # Random or low user-specified durations might cause this. There's no maximum.
        if duration < piv.to_i * 2.5
          duration = piv.to_i * 2.5
          log_warn("Duration is below minimum required duration. Defaulting to #{duration}.")
          exp_num_photos = 2
        end

        ret, msg = @camera.capture_piv(vm, res, fps, fov, piv, duration, orient, ll, spot)
        if ret == false
          fail(msg)
          next
        else
          log_info(msg)
        end

        # Check that we have the correct number of JPG files
        after_list = @camera.get_medialist()
        all_files = after_list - before_list
        tu_map_media_list( __FILE__, tc_name, all_files )
        jpg_files = all_files.reject{ |f| f.split(".")[1] != "JPG" }
        mp4_files = all_files.reject{ |f| f.split(".")[1] != "MP4" }

        if mp4_files.empty?
          fail("No video was found after capturing photo-in-video")
          next
        end

        log_info("Checking that we have 1 MP4 file")
        failed_arr << assert_equal(1, mp4_files.length, "Expected MP4 files not found")
        mp4_files.each { |f| log_verb("#{f}") }

        log_info("Checking that we have #{exp_num_photos} JPG files")
        failed_arr << assert_equal(exp_num_photos, jpg_files.length,
        "Expected (#{exp_num_photos}) JPG files != actual (#{jpg_files.length})")
        jpg_files.each { |f| log_verb("#{f}") }

        mp4file = tu_basename(mp4_files[0])
        #Analyze file naming convention
        failed_arr << tu_analyze_file_name("VIDEO", mp4file)
        next if has_failure?(failed_arr)

        jpg_files.sort!.each { |f|
          jpgfile = tu_basename(f)
          failed_arr << tu_analyze_file_name("PIV", jpgfile)

          # Test that group number is correct
          log_info("Checking group numbering")
          grp_num = jpgfile[1..3].to_i
          exp_grp_num = grp_num if exp_grp_num == nil
          failed_arr << assert_equal(exp_grp_num, grp_num,
          "(#{jpgfile}) Group # exp=#{exp_grp_num}, act=#{grp_num}")

          # Test object number is correct
          log_info("Checking file index numbering")
          obj_num = jpgfile[4..8].to_i
          exp_obj_num = obj_num if exp_obj_num == nil
          failed_arr << assert_equal(exp_obj_num, obj_num,
          "(#{jpgfile}) Object # exp=#{exp_obj_num}, act=#{obj_num}")
          if exp_obj_num == 999
            exp_obj_num = 1
            exp_grp_num += 1
          else
            exp_obj_num += 1
          end
        }

        if @camera.interfaces.include?(:wifi)
          #Checking MP4 metadata
          failed_arr << tu_wifi_analyze_video_metadata(mp4_files[0], "OFF", res, fps, fov)

          #Check MP4 gpmedialist params
          failed_arr << tu_wifi_analyze_gpmedialist_params("VIDEO", vm, "OFF", res, fps, fov)

          #TODO - jpg resolution for piv seems be different from burst/time lapse in HD3+. Revisit this in HD4
          #Check JPG metadata
          #jpgfile = @camera.get_last_jpg_url(cur_media)
          #tu_analyze_photo_metadata(jpgfile, :piv, res, p)

          #Check JPG gpmedialist params
          failed_arr << tu_wifi_analyze_gpmedialist_params("PIV")

        end

        pass("Metadata checks passed") if !has_failure?(failed_arr)
        failed_arr.clear()
      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    } # end test_params.each
  end

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @camera.detect_crash_and_reboot() if @camera and @camera.interfaces and @camera.interfaces.include?(:serial)
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only, :video_piv, :video_low_light,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering, :setup_orientation, :range,
      :duration, :set_defaults, :dryrun, :verb, :full, :shuffle, :keep_media, :download_media]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
