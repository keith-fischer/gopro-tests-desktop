# test_video_metadata.rb
# Description: Iterates over all RES/FPS/FOV with both ProTunes
#              off and on (if supported).  Also checks LRV and THM.
# Tests the following items:
#   - Preview is available before and after capture
#   - # of videos on the card increments correctly
#   - # of minutes left on SD card decrements correctly
#   - The following video metadata is correct
#     - aspect_ratio
#     - audio_channels
#     - audio_codec
#     - audio_sample_rate
#     - bitrate
#     - colorspace
#     - frame_rate
#     - has_timecode
#     - height
#     - width
#     - video_codec
require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/host_utils'
require_relative '../libs/testcase'
require_relative '../libs/test_utils'

class Test < TestCase
  include TestUtils
  def initialize
    super
  end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()

    tu_keep_or_delete_all_media()
    tu_verify_sd_status()

    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
    @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil
    set_options()

    # Start preview stream on cameras that we want to test it
    if @camera.test_preview_stream == true
      ret, msg = @host.get_system_camera_ip(@camera.ip)
      if ret == true
        log_info("Setting host interface IP to camera: #{msg}")
        @camera.system_address = msg
        log_info("Be sure to add port-forwarding for port #{@camera.streaming_port}")
      else
        log_error(msg)
        exit 1
      end
      @camera.send_live_stream_start
      @camera.start_streaming_protocol()
    end
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest

    failed_arr = []

    # Enumerate all the test combinations
    test_params = tu_get_video_res_with_protune()

    if test_params[0].empty? && test_params[1].empty?
      log_warn("No tests to run!  Check res/fps and camera @video_capture_modes")
      return
    end

    total_tc = test_params[0].length + test_params[1].length
    counter = 0

    # Testcases' metadata is also appeneded to one of two CSV files.
    # Ensure that the files exist and are empty by writing the headings to that file.
    ["ON","OFF"].each { |p| File.open(csv_filename(p), "w") { |f| f.puts(csv_headings_string()) } }

    # Now run each test
    duration = (@options[:duration] != nil) ?  @options[:duration] : 10 #seconds

    test_params.each() { |r|
      next if r.empty?
      r.each {|vm, res, fps, fov, orient, ll, spot, p, wb, co, sh, iso, ex|

        counter += 1
        next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
        log_info("Running test #{counter} of #{total_tc}")

        # Deal with random duration ranges.
        if @options[:duration_range_low] and @options[:duration_range_high]
          duration = rand(@options[:duration_range_low]..@options[:duration_range_high])
          log_info("Using a duration of #{duration}. Range is (#{@options[:duration_range_low]}..#{@options[:duration_range_high]}).")
        end

        # Add all relevant info to the test case name
        tc_name = "#{vm}_#{res}_#{fps}_#{fov}_#{orient}"
        tc_name += "_spot_#{spot}" if spot
        tc_name += "_ll_#{ll}" if ll
        tc_name += "_protune_#{p}"
        tc_name += "_#{wb}" if wb
        tc_name += "_#{co}" if co
        tc_name += "_#{sh}" if sh
        tc_name += "_#{iso}" if iso
        tc_name += "_#{ex}" if ex

        set_tc_name(tc_name)
        ts_capture_filename = "#{@options[:save_dir]}/#{tc_name}_captured.ts"
        ts_idle_filename = "#{@options[:save_dir]}/#{tc_name}_idled.ts"

        begin  # Want to rescue from Errors within the test loop
          prev_video = @camera.get_last_media("MP4", hash=false)
          fail("Unable to get mediaList") if prev_video == false

          if @camera.has_eis_support? && @options[:eis]
            if @camera.video_eis_support?(res, fps)
              # Set res/fps before setting EIS to make sure it is available.
              ret, msg = @camera.set_single_video_settings(vm, res, fps, fov)
              if ret 
                log_info(msg)
              else
                fail(msg)
                next
              end
              ret, msg = @camera.set_video_eis(@options[:eis])
              if ret
                log_info(msg)
              else
                fail(msg)
                next
              end
            end
          end

          if @camera.has_awf_support? && @options[:awf]
            ret, msg = @camera.set_video_awf(@options[:awf])
            if ret
              log_info(msg)
            else
              fail(msg)
              next
            end
          end

          if @camera.test_preview_stream == true
            #Remove old ts file
            File.delete(ts_capture_filename) if File.exists?(ts_capture_filename)

            ret, msg = @camera.set_single_video_settings(vm, res, fps, fov, orient, ll, spot, p, wb, co, sh, iso, ex)
            (ret == false) ? (fail(msg); next) : log_info(msg)

            @camera.save_ts_filename = ts_capture_filename
            log_info("Saving ts file #{ts_capture_filename}")

            act_sream_supported_captured = @camera.process_single_video_capture(duration)
          else
            ret, msg = @camera.capture_video(vm, res, fps, fov, duration, orient, ll, spot, p, wb, co, sh, iso, ex)
            (ret == false) ? (fail(msg); next) : log_info(msg)
          end

          cur_video = @camera.get_last_media("MP4", hash=false)
          (fail("No new video was found after encoding"); next) if prev_video == cur_video

          # Append the line of actual metadata for this testcase to the appropriate file.
          File.open(csv_filename(p), "a") { |f| f.puts(csv_get_metadata_line(vm, res, fps, fov, cur_video)) }

          tu_map_media_list( __FILE__, tc_name, [cur_video] )

          ### Metadata and other checks
          # First, check preview streaming res and metadata
          if @camera.test_preview_stream == true
            #2 ts file: one is during encoding to be statically named in following format: /<save_dir>/<tc_name>_captured.ts. This file is created during capture_video method.
            #           one is not during encoding to be statically named in following format: /<save_dir>/<tc_name>_idled.ts. This file is created here with save_ts_file method call.

            #verify '/<save_dir>/<tc_name>_captured.ts'
            #During encoding, preview stream is only available when lrv exists. Expected fps is same as LRV fps
            if @camera.has_lrv?(res, fps, fov)

              failed_arr << tu_analyze_mpeg_ts_captured_metadata(ts_capture_filename, p, res, fps, fov)

              #verify stream_supported bit during capture. Expected 1 when lrv exists
              failed_arr << assert_equal(1, act_sream_supported_captured, "Stream_supported bit is incorrect during capture. Expected 1. Actual #{act_sream_supported_captured}")

            else

              #if lrv doesn't exist, such ts file should not exist
              failed_arr << assert_equal(false, File.exists?(ts_capture_filename), "#{ts_capture_filename} exists when it should not")

              #verify stream_supported bit during capture. Expected 0 when lrv does not exist
              failed_arr << assert_equal(0, act_sream_supported_captured, "Stream_supported bit is incorrect during capture. Expected 0. Actual #{act_sream_supported_captured}")

            end
            #idle stream
            isTimeout = tu_save_idle_stream(ts_idle_filename)

            if isTimeout == false
              #verify '/<save_dir>/<tc_name>_idled.ts'
              #During idling, preview stream is always available, even if lrv exists. Expected NTSC fps = 29.97, Expected PAL fps = 25
              failed_arr << tu_analyze_mpeg_ts_idled_metadata(ts_idle_filename, vm, p, res, fps, fov)
            else
              failed_arr << ("Unable to get idle stream #{ts_idle_filename}. Possibly timeout due to too many missing packets")
            end

            #get stream_supported bit during idle
            act_stream_supported_idle = @camera.get_status(:stream_supported)
            #verify stream_supported bit during idle. Expected 1 always
            failed_arr << assert_equal(1, act_stream_supported_idle, "Stream_supported bit is incorrect during idle. Expected 1. Actual #{act_stream_supported_idle}")
          end

          failed_arr << tu_wifi_analyze_video_metadata(cur_video, p, res, fps, fov)

          #File name convention
          failed_arr << tu_analyze_file_name("VIDEO", File.basename(cur_video))

          #gpMediaList or camera roll verification
          failed_arr << tu_wifi_analyze_gpmedialist_params("VIDEO", vm, p, res, fps, fov)

          #Analyze if mp4/lrv/thm exists over http (since there is no way to check
          #if thm exists on SD card, and doesn't hurt to check mp4/lrv as well)
          failed_arr << tu_wifi_check_media_existence("VIDEO", cur_video, vm, p, res, fps, fov, true)

          failed_arr << tu_wifi_verfiy_low_light(res, fps)

          if has_failure?( failed_arr ) # Will log any failures for main test case.
            if( @camera.has_eis_support? && @options[:eis] )
              set_tc_name( 'eis_' + @options[:eis] + '_' + tc_name )
              log_fail( 'Main test case did not pass with this setting.' )
            end # eis fail
            if( @camera.has_awf_support? && @options[:awf] )
              set_tc_name( 'awf_' + @options[:awf] + '_' + tc_name )
              log_pass( 'Main test case did not pass with this setting.' )
            end # awf fail
          else # No failures.
            log_pass( 'Test case passed.' ) # Pass main test case.
            if( @camera.has_eis_support? && @options[:eis] )
              set_tc_name( 'eis_' + @options[:eis] + '_' + tc_name )
              log_pass( 'Test case passed.' )
            end # eis pass
            if( @camera.has_awf_support? && @options[:awf] )
              set_tc_name( 'awf_' + @options[:awf] + '_' + tc_name )
              log_pass( 'Test case passed.' )
            end # awf pass
          end # has_failure?

          failed_arr.clear

        rescue WifiCameraError
          fail("Lost communication with camera")
          tu_reset_camera()
        rescue StandardError => e
          fail("General error: #{e.to_s}")
          puts e.backtrace.join("\n")
          tu_reset_camera()
        end
      } # end r.each

    } # end test_params.each

    # Stop preview streaming if it was started
    if @camera.test_preview_stream == true
      @camera.send_live_stream_stop
      @camera.stop_streaming_protocol
    end
  end

  def cleanup
    tu_map_media_done()
    tu_save_media()
    @host.kill_status_process() if @host
  end

  # Functions for creating csv file of metadata are below.
  # Maybe consider pulling these out into a different module?
  # A generic CSV formatter probably wouldn't work for this data, due to duplicate field names.
  # Is there an elegant way to avoid pulling the metadata twice? Once below, once in tets_utils when it runs the validation?

  # Returns a string of the coilumn headings for the CSV data.
  def csv_headings_string
    return "Video Mode,Res/Fps/FoV,W,H,FPS,Mbps,Level,Audio kbps, Audio Codec, # Ch.,Sample Rate,Colorspace,Aspect Ratio,Video Codec,LRV?,W,H,FPS,Video Mbps,Audio kbps, Sample Rate,Audio Codec,# Ch.,Colorspace,Aspect Ratio,Video Codec,THM?,\n"
  end # csv_headings_string

  # Returns a string that is a line of one testcase's metadata in CSV format.
  def csv_get_metadata_line(vm, res, fps, fov, filename)
    # Start the CSV data with the video mode, and a string with the expected resolution, frames per second, and field of view.
    csv_line = "#{vm},#{res} / #{fps} / #{fov},"
    # Get the full url of the mp4 file which has the metadata we want.
    csv_mp4_filename = @camera.get_media_url(filename)
    # Get the metadata. Use a short variable name for metadata to limit line lengths.
    m = @host.get_video_metadata(csv_mp4_filename)
    if m # If there is metadata...
      # Parse the metadata, adding the result to the line for this testcase.
      csv_line += "#{m.width},#{m.height},#{m.frame_rate},#{m.video_bitrate},#{m.profile_level},#{m.audio_bitrate},#{m.audio_codec},"
      csv_line += "#{m.audio_channels},#{m.audio_sample_rate},#{m.colorspace},#{m.aspect_ratio},#{m.video_codec},"
    else # There's no metadata, so add an error string instead.
      csv_line += "ERROR" + ","*12
      log_warn("Couldn't find metadata for file #{csv_mp4_filename}")
    end # if m
    # Get the full urls for the lrv and thm files by replacing the tails of the video file with the correct extensions.
    csv_lrv_filename = csv_mp4_filename[0..-4] + "LRV"
    csv_thm_filename = csv_mp4_filename[0..-4] + "THM"
    # Determine if those files exist.
    csv_lrv_exists = @camera.media_exists?(csv_lrv_filename)
    csv_thm_exists = @camera.media_exists?(csv_thm_filename)
    # If the LRV file exists...
    if csv_lrv_exists
      # Get the metadata for the lrv file.
      m = @host.get_video_metadata(csv_lrv_filename)
      if m # If there is metadata...
        # Add metadata for the lrv file.
        csv_line += "YES,#{m.width},#{m.height},#{m.frame_rate},#{m.video_bitrate},#{m.audio_bitrate},#{m.audio_sample_rate},#{m.audio_codec},"
        csv_line += "#{m.audio_channels},#{m.colorspace},#{m.aspect_ratio},#{m.video_codec},"
      else
        # The file exists but the metadata does not? Put in an error string.
        csv_line += "ERROR" + ","*11
        log_warn("Couldn't find metadata for file #{csv_lrv_filename}")
      end # if m
    else # The LRV file doesn't exist...
      # Add the string for when there is no LRV file.
      csv_line += "NO" + ","*11
    end # if csv_lrv_exists
    # Add metadata for the thm file.
    csv_line += ( ( csv_thm_exists ) ? ( "YES,\n" ) : ( "NO,\n" ) )
    # Return this line of metadata
    return csv_line
  end

  # Returns the filename to use for saving the CSV of metadata.
  def csv_filename(p)
    if @options[:logfile] != nil
      dir = File.dirname(@options[:logfile])
    else
      dir = @options[:save_dir]
    end
    filename = "META-PROTUNE_#{p}-#{@camera.release}-#{@camera.type}-#{@camera.build}.csv"
    return File.join(dir, filename) if dir
    log_warn("No logfile or save_dir specified. Saving metadata csv file to current directory.")
    return filename
  end # csv_filename

end # Test

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :battoutlet, :usboutlet, :reset_on_failure,
      :video_resolution, :video_fps, :video_fov, :ntsc_only, :pal_only,
      :video_pt, :video_pt_wb, :video_pt_color, :video_pt_iso, :video_pt_sharp, :video_pt_ev,
      :duration, :video_low_light, :full, :range, :keep_media, :download_media, :eis, :awf,
      :setup_default_mode, :setup_led, :setup_beep, :video_spot_metering,
      :setup_orientation, :shuffle, :set_defaults, :save_dir, :dryrun, :quick, :verb]
    options = t.parse_options(ARGV, use_options)
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    options[:save_dir] = "/tmp" if options[:save_dir] == nil
    t.setup(options)
    t.runtest()
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
