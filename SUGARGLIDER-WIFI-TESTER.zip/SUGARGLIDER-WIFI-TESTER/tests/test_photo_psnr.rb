# test_photo_psnr
# Check the PSNRs of all the photo modes to try to find quality issues
# Photos must have been taken of a STATIC subject (!!)

require_relative '../libs/camera'
require_relative '../libs/dlipower'
require_relative '../libs/testcase'
require_relative '../libs/host_utils'
require_relative '../libs/test_utils'
require 'fileutils'

class Test < TestCase
  include TestUtils

  def initialize
      super
    end

  def setup(options)
    @options = options
    @test_file = __FILE__
    set_tc_name("#{@test_file}_setup")
    @host = Host.new
    @camera = tu_get_camera()
    @camera.powerstrip = PowerStrip.new(@options[:power_ip],
                         @options[:power_usr], @options[:power_pwd])
    @camera.battoutlet = @options[:battoutlet] if @options[:battoutlet] != nil
    @camera.usboutlet = @options[:usboutlet] if @options[:usboutlet] != nil
    @camera.pushy = Pushy.new(*@options[:pushy].split) if @options[:pushy] != nil

    # LEDs can lower the PSNR of the image
    @camera.set_led("0") if @camera.release == "HD4"
    @camera.set_led("OFF") if ["ROCKYPOINT", "HALEIWA", "HIMALAYAS"].include?(@camera.name)
    @host.spawn_status_process(@camera.make_status_url) if @camera.name == "ROCKYPOINT"
  end

  def runtest
    base_dir = @options[:save_dir]
    test_params = tu_get_photo_test_params()
    log_info("Executing #{test_params.length} tests.")
    counter = 0
    test_params.each { |res, orient, spot, pt, wb, col, sh, iso, ex|
      counter += 1
      next if tu_should_skip(counter, @options[:range_min], @options[:range_max])
      log_info("Running test #{counter} of #{test_params.length}")

      tc_name = "psnr_#{res}_orient_#{orient}"
      tc_name += "_protune_#{pt}" if pt != nil  #to be compatible with pre-Hawaii camera models which doesn't support protune
      tc_name += "_spot_#{spot}" if spot != nil #to be compatible with pre-Hawaii camera models which doesn't support spot metering
      tc_name += "_#{wb}"  if wb != nil
      tc_name += "_#{col}" if col != nil
      tc_name += "_#{iso}" if iso != nil
      tc_name += "_#{sh}"  if sh != nil
      tc_name += "_#{ex}"  if ex != nil
      set_tc_name(tc_name)

      begin
        @camera.delete_all_media()
        sleep(5.0)

        ret, msg = @camera.capture_photo_single( \
          res, orient, spot, pt, wb, col, sh, iso, ex)
        (ret == false) ? (fail(msg); next) : log_info(msg)

        # Photo/SPS mode
        if @camera.photo_continuous_support?(res) == true
          @camera.get_photo_continuous_rates(res).each { |sps|
            next if @options[:photo_continuous] != nil and @options[:photo_continuous] != sps
            ret, msg = @camera.capture_photo_continuous( \
              res, sps, orient, 3, spot, pt, wb, col, sh, iso, ex)
            (ret == false) ? (fail(msg); next) : log_info(msg)
          }
        end

        # Burst mode
        @camera.get_multi_photo_burst_rates(res).each { |burst|
          next if @options[:multi_photo_burst] != nil and @options[:multi_photo_burst] != burst
          ret, msg = @camera.capture_multi_photo_burst( \
            res, burst, orient, spot, pt, wb, col, sh, iso, ex)
          (ret == false) ? (fail(msg); next) : log_info(msg)
        }

        # Time-lapse
        min_photos = @options[:min_pes_pho].to_i
        min_length = @options[:min_pes_len].to_i
        @camera.get_multi_photo_timelapse_rates(res).each { |pes|
          dur = ((pes.to_f * min_photos) + 1).to_i
          ret, msg = @camera.capture_multi_photo_timelapse( \
            res, pes, dur, orient, spot, pt, wb, col, sh, iso, ex)
          (ret == false) ? (fail(msg); next) : log_info(msg)
        }

        # Make the output directory
        subdirs = [res, orient, spot, pt, wb, col, sh, iso, ex].map { |m| m.to_s }
        img_dir = File.join(@options[:save_dir], subdirs)
        begin
          FileUtils::mkdir_p(img_dir)
        rescue StandardError
          fail("Unable to create #{img_dir}.  Permission issue?")
          next
        end

        # Download the files
        ret, msg = @camera.download_all_media(img_dir)
        (ret == false) ? (fail(msg); next) : log_info(msg)

        #Identify reference image
        ref_img = Dir.glob(File.join(img_dir, "GOPR*.JPG")).sort()[0]
        if ref_img == nil
          fail("No reference image (GOPR*.JPG) found.")
          next
        else
          log_info("Using reference image #{ref_img}")
        end

        # Finally compare the PSNRs.
        all_images = Dir.glob(File.join(img_dir, "*.JPG")).sort()
        # min_psnr = @camera.photo_modes[res][:min_psnr]
        min_psnr = 30
        failed_arr = []
        passed_arr = []
        all_images.each { |img|
          next if img == ref_img
          ret, psnr = @host.get_psnr(img, ref_img)
          if ret == false
            failed_arr << "Failed to get PSNR for image #{img}"
          else
            log_verb("#{img} PSNR=#{psnr}")
            if psnr > min_psnr
              passed_arr << img
            else
              failed_arr << "Image #{img} PSNR %0.2f < #{min_psnr}" %psnr
            end
          end
        }
        # Delete passing photos to save space.
        FileUtils::rm(passed_arr)
        next if has_failure?(failed_arr)
        pass("PSNR passed")

      rescue WifiCameraError
        fail("Lost communication with camera")
        tu_reset_camera()
      rescue StandardError => e
        fail("General error: #{e.to_s}")
        puts e.backtrace.join("\n")
        tu_reset_camera()
      end
    } # end get_photo_resolutions.each
  end

  def cleanup
    if @camera
      @camera.set_led("4") if @camera and @camera.release == "HD4"
      @camera.set_led("ON") if @camera.name == "ROCKYPOINT"
      @camera.set_led("BOTH") if @camera.name == "HALEIWA"
      @camera.set_led("BOTH") if @camera.name == "HIMALAYAS"
      @host.kill_status_process() if @host
    end
  end
end

# Execution starts here
# Overall exceptions are handled here.
# Test-case level exceptions are handled in runtest()
if __FILE__ == $0
  $LOGLEVEL = $LL_INFO
  $LOGLEVEL = $LL_WARN
  default_save_dir = "/tmp/psnr-#{Time.now.strftime($FILE_TIME_STR)}"
  begin
    t = Test.new
    use_options = [:ip, :pc, :serialdev, :save_dir, :battoutlet, :usboutlet, :reset_on_failure,
      :photo_resolution, :photo_continuous, :multi_photo_burst,
      :photo_shutter_ev, :photo_pt, :photo_spot_metering,
      :photo_pt_wb, :photo_pt_color, :photo_pt_iso, :photo_pt_sharp, :photo_pt_ev,
      :min_pes_length, :min_pes_photos, :range,
      :setup_default_mode, :setup_osd, :setup_led, :setup_beep, :photo_spot_metering, :setup_orientation,
      :save_dir, :shuffle, :verb]
    options = t.parse_options(ARGV, use_options)
    options[:save_dir] = default_save_dir if options[:save_dir] == nil
    $LOGLEVEL = $LL_VERB if options[:verb] == true
    t.setup(options)
    t.runtest
  rescue StandardError => e
    t.log_error(e.to_s)
    t.log_info(e.backtrace.join("\n"))
    t.tu_reset_camera()
  ensure
    t.cleanup if t != nil
    t.final_actions() if t != nil
  end
end
