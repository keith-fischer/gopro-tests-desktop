# NOTE!!! Because some files will be edited often for local testing,
# we want them not to be overwritten in every 'git pull', so
# we copy them out of the git directory and point to them with
# environment variables.
# Ideally these should be system-wide and should be set in
# /etc/environment (must re-login or restart after setting)
#
# TRIGGER - points to this file
# HOSTAGENT - points to the hostagent you want to use
# CAMERA_CONF - points to the camera conf you want to use
#
### Also roster files for the camera model you are testing.
# SILVER_PLUS
# BLACK_PLUS
# BACKDOOR
# PIPE
# ROCKYPOINT
# STREAKY
# SQUIRRELS
# Etc...

### Example entries for /etc/environment
# TRIGGER="/home/qa/SUGARGLIDER-WIFI-TESTER/jenkins-trigger.rb"
# HOSTAGENT="/home/qa/SUGARGLIDER-WIFI-TESTER/hostagent.rb"
# CAMERA_CONF="/home/qa/cameras.conf"
# STREAKY="/home/qa/streaky.txt"

require 'optparse'

# Returns cam NAME, Model #, FW ver.
# f in format HD3.01.00.03 ==> "HD3", "01", "00.03"
def parse_fw_fname(f)
  begin
    fields = File.basename(f).split(".")
    return fields[0], fields[1], fields[2..(fields.length - 1)].join(".")
  rescue
    puts "Error parsing firmware name #{f}"
    return nil
  end
end

if __FILE__ == $0
  # ENVIRONMENT VARIABLES must be pre-set in /etc/environment
  roster_hash = {
    "HD5" => {
    "01" => ENV['STREAKY'],
    "02" => ENV['SQUIRRELS'],
    "03" => ENV['MARGARETRIVER']
    },

    "HD4" => {
    "01" => ENV['BACKDOOR'],
    "02" => ENV['PIPE']
    },

    "HX1" => {
    "01" => ENV['ROCKYPOINT']
    },

    "HD3" => {
    "21" => ENV['HALEIWA'],
    "22" => ENV['HIMALAYAS']
    },
  }

  run_type = []

  options = {}
  options[:fw]          = nil
  options[:bat]         = nil
  options[:individual]  = nil
  options[:verb]        = nil

  op = OptionParser.new do |opts|
    opts.banner = "Usage: ruby jenkins-trigger.rb -f [FIRMWARE] [--bat | --individual] -h"
    opts.on("-f", "--fw FILE", "Firmware file (e.g. HD3.11.02.01)") {
      |o|   options[:fw] = o}
    opts.on("", "--bat","Do a BAT automation run") {
      |o| options[:bat] = "BAT" }
    opts.on("", "--individual", "Do a set of individual automation tests run") {
      |o| options[:individual] = "INDIVIDUAL" }
    opts.on("", "--verb", "Verbose logging") {
      |o| options[:verb] = true }
    opts.on("-h", "--help", "Display this message and exit") { puts op; exit }
  end
  op.parse!(ARGV)

  # Error check the args
  if options[:fw] == nil
    puts "Firmware not specified!"
    exit 1
  end

  if options[:bat] == nil and options[:individual] == nil
    puts "Must specify at least one of the following options: --bat, --individual"
    exit 1
  end

  run_type << options[:bat]
  run_type << options[:individual]

  cam_name, cam_type, fw_ver = parse_fw_fname(options[:fw])
  (puts "Unknown camera release #{cam_name}" ; exit 1) if roster_hash[cam_name] == nil
  if cam_type == "XX"
    puts "Shared builds have type 'XX' so we look for the first roster in existence"
    roster = nil
    roster_hash[cam_name].keys.each { |t|
      r = roster_hash[cam_name][t]
      if r != nil and File.file?(r)
        puts "First match for #{cam_name}.#{cam_type} is #{r}"
        roster = r
        break
      end
    }
  else
    roster = roster_hash[cam_name][t]
  end

  # Error check the env variables
  hostagent = ENV['HOSTAGENT']
  if hostagent == nil or not File.file?(hostagent)
    puts "Unable to find HOSTAGENT file: '#{hostagent}'"
    exit 1
  end
  if roster == nil or not File.file?(roster)
    puts "Unable to find test roster file: '#{roster}'"
    exit 1
  end
  cam_conf = ENV['CAMERA_CONF']
  if cam_conf == nil or not File.file?(cam_conf)
    puts "Unable to find CAMERA_CONF file: '#{cam_conf}'"
    exit 1
  end

  run_type.each { |r|
    next if r == nil
    puts "Loading roster for model=#{cam_name}, type=#{cam_type}, run=#{r}"
    f = "#{cam_name}.#{cam_type}.#{fw_ver}.ota.zip"

    # Finally run the test script
    # "-f" - specifies FIRMWARE
    # "-m" - emails results
    # "-t" - reports into testrail
    dir = File.dirname(hostagent)
    ha = File.basename(hostagent)
    cmd = "cd #{dir}; ruby #{ha} -c #{cam_conf} -r #{roster} -f #{f} --runtype #{r}"
    cmd += " -m"
    cmd += " -t" if options[:bat] != nil
    cmd += " --verb" if options[:verb] == true
    #cmd += " --runlabel #{run_type.upcase}"
    puts cmd
    # exec will REPLACE the current process, get all the output, and return the exit code
    #	code =  exec(cmd)  # nothing can be executed after exec line
    code = system(cmd) # can execute after this line
    #loop again if needed since Pipe & Backdoor uses same build
  } # end run_type
end
