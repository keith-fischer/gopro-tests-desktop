import serial
import sys
import time
import hero4Send
import hero4Tester

class snifferRead():

	def __init__(self):
		self.gpReceive = serial.Serial()
		self.gpReceive.baudrate = 115200
		self.gpReceive.bytesize = 8
		self.gpReceive.stopbits = 1
		self.gpReceive.xonxoff = 0
		self.gpReceive.rtscts = 0
		self.gpReceive.timeout = 0
		usb = raw_input('Enter USB port# (just number): ')
		self.gpReceive.port = '/dev/ttyUSB' + usb
		print 'connected to ' + self.gpReceive.port
		self.gpReceive.parity = serial.PARITY_NONE
		self.gpReceive.open()
		time.sleep(5)

	def startReadConnetion(self, fname, wf):
		helloFlag = False
		start = time.time()
		while (True):
			if wf: f = open(fname, 'a')
			r = ''
			time.sleep(.5)
			data = self.gpReceive.read(16) 
			if len(data)>0: 
				while(data):
					r += data
					data = self.gpReceive.read(16)				
				print r
				
				if 'Hello' in r:
					helloFlag = True

				if helloFlag & wf:	
					f.write(str(r))

				start = time.time()
			if wf: f.close()
			end = time.time()
			TIME = end - start

			if (TIME > 1800):
				print 'Time out!'
				break

	# def errorCode(self, resp):
	# 	print 'in'

if __name__ == '__main__':

	writeToFile = False #write response echo to file?

	#get firmware version
	f = hero4Tester.tester()
	# fw = f.fw()
	fw = 'eee'

	#Start sniffer read
	sR = snifferRead()
	sR.startReadConnetion(fw, writeToFile)

