import xlrd
from xlrd import open_workbook


class xlread():

    def __init__(self):
        self.path4B = "excelBlack4.xlsx"
        self.path4S = "excelSilver4.xlsx"
        self.path3B = "excelBlack3+.xlsx"
        self.path3S = "excelSilver3+.xlsx"
        self.path4B_i = "excelIllegal4black.xlsx"
        self.path4S_i = "excelIllegal4silver.xlsx"


    def cmdsFromExcel(self, path, skip_get, rep, cfname):
        wb = xlrd.open_workbook(path)
        first_sheet = wb.sheet_by_index(0)
        get_cmd = ''
        GET = False
        f = open(cfname, 'a')

        for i in range(12, first_sheet.nrows):
            CELL = first_sheet.cell(i,3)
            cell_left = first_sheet.cell(i,2)
            
            if GET:
                if CELL.value:
                    if get_cmd:
                        for i in range(0, rep): f.write(str(CELL.value)+'\n')
                        if skip_get is False:
                            f.write(str(get_cmd)+'\n')
                    else:
                        get_cmd = CELL.value                
                else:
                    GET = False
                    get_cmd = ''

            else:
                if CELL.value == 'GET':
                    GET = True
                elif CELL.value == 'USER':
                    pass
                elif CELL.value:
                    for i in range(0, rep): f.write(str(CELL.value)+'\n')
        f.close()

    def cmdGen(self, cfname, run, camera, model, getCheck, repCmd):
        #clear old commands file
        f = open(cfname, 'w')
        f.close()

        #Grab settings from ini, and generate commands file
        for r in range (0, run):
            if camera == '3':
                if model in ('Black','black'):
                    self.cmdsFromExcel(self.path3B, getCheck, repCmd, cfname)
                    if getCheck: print '*** Parsed commands for HERO3+ Black without GET commands. ***\n--> Created COMMANDS.TXT file'
                    else: print '*** Parsed commands for HERO3+ Black with GET commands. ***\n--> Created COMMANDS.TXT file'
                else:
                    self.cmdsFromExcel(self.path3S, getCheck, repCmd, cfname)
                    if getCheck: print '*** Parsed commands for HERO3+ Silver without GET commands. ***\n--> Created COMMANDS.TXT file'
                    else: print '*** Parsed commands for HERO3+ Silver with GET commands. ***\n--> Created COMMANDS.TXT file'

            elif camera == '4':
                if model in ('Black','black'):
                    if 'illegal' in cfname:
                        self.cmdsFromExcel(self.path4B_i, getCheck, repCmd, cfname)
                        if getCheck: print '*** Parsed illegal commands for HERO4 Black without GET commands. ***\n--> Created COMMANDS.TXT file'
                        else: print '*** Parsed illegal commands for HERO4 Black with GET commands. ***\n--> Created COMMANDS.TXT file'
                    else:
                        self.cmdsFromExcel(self.path4B, getCheck, repCmd, cfname)
                        if getCheck: print '*** Parsed commands for HERO4 Black without GET commands. ***\n--> Created COMMANDS.TXT file'
                        else: print '*** Parsed commands for HERO4 Black with GET commands. ***\n--> Created COMMANDS.TXT file'
                else:
                    if 'illegal' in cfname:
                        self.cmdsFromExcel(self.path4S_i, getCheck, repCmd, cfname)
                        if getCheck: print '*** Parsed illegal commands for HERO4 Silver without GET commands. ***\n--> Created COMMANDS.TXT file'
                        else: print '*** Parsed illegal commands for HERO4 Silver with GET commands. ***\n--> Created COMMANDS.TXT file'
                    else:
                        self.cmdsFromExcel(self.path4S, getCheck, repCmd, cfname)
                        if getCheck: print '*** Parsed commands for HERO4 Silver without GET commands. ***\n--> Created COMMANDS.TXT file'
                        else: print '*** Parsed commands for HERO4 Silver with GET commands. ***\n--> Created COMMANDS.TXT file'
            else: print 'UNKNOWN Camera Model'

if __name__ == "__main__":
    xl = xlread()
    xl.bs()
    