import serial
import time
import os
import hero4Tester_win
import sys

class commander():

	def __init__(self):
		self.gpSend = serial.Serial()
		self.gpSend.baudrate = 115200
		self.gpSend.bytesize = 8
		self.gpSend.stopbits = 1
		self.gpSend.xonxoff = 0
		self.gpSend.rtscts = 0
		self.gpSend.timeout = 0
		com = raw_input("Starting Command Center....\nEnter port COM# (just number):")
		self.gpSend.port = 'COM' + com
		print 'Connected to ' + self.gpSend.port
		self.gpSend.parity = serial.PARITY_NONE
		self.gpSend.open()
		self.commands = []
		self.passed = 0
		self.failed = 0
		self.unknown = 0
		self.chFlag = True

	def clearCache(self):
		self.passed = 0
		self.failed = 0
		self.unknown = 0

	def startGopro4(self, fname):
		self.gpSend.write('!\n')
		for i in range(101): 
			time.sleep(.06)
			sys.stdout.write("\rBooting HERO4, Please wait .... %d%%" %i)
			sys.stdout.flush()
		sys.stdout.write('\n')
		return self.read(fname)

	def startGopro3(self, fname):
		raw_input("Press 'Enter' to start HERO3+")
		# os.remove(fname)
		self.gpSend.write('!')
		print "Starting HERO3+, Please wait ....."
		for i in range(101): 
			time.sleep(.06)
			sys.stdout.write("\rHERO4 is booting: %d%%" %i)
			sys.stdout.flush()
		sys.stdout.write('\n')

	def getDeviceID(self, fname):  
		self.gpSend.write('YY 0 0 0 0 1 0 0\n\r')
		return self.read(fname)

	def hero3Plus(self, cmd, fname):
		w = cmd + '\n'
		self.gpSend.write(str(w)) 
		self.read(fname)

	def writeYYCommand(self, dId, cmdHex, fname, t):
		w = 'YY 0 0 ' + dId + ' ' + cmdHex + '\n\r'
		self.gpSend.write(str(w)) 
		if 'final' not in t:
			r = self.read(fname, t)
			return r

	def writeZZCommand(self, cmdHex, fname):
		w = 'ZZ 0 0 ' + cmdHex + '\n\r'
		self.gpSend.write(str(w)) 
		# self.read(fname)

	def writeCommand(self, cmdHex, fname):
		w = cmdHex + '\n\r'
		print w
		self.gpSend.write(str(w)) 
		self.read(fname)

	def yyResp(self, s_pos):
		ln = s_pos + 1
		ack = ln + 1
		res = ack + 1
		tid = res + 1
		tcb = tid + 1
		channel = tcb + 1
		api = channel + 1
		api_id = api + 1
		error_code = api_id + 1
		dataln1 = error_code + 1
		dataln2 = dataln1 + 1
		return {'ln':ln, 'ack':ack, 'res':res, 'tid':tid, 'tcb':tcb, 'channel':channel, 'api':api, 'api_id':api_id, 'error_code':error_code, 'dataln1':dataln1, 'dataln2':dataln2}
		

	def read(self, fname, t='valid'):
		helloFlag = False
		chFile =  open(fname, 'a')
		start = time.time()
		status = 'Error'
		while (True):
			r = ''
			time.sleep(.5)
			data = self.gpSend.read(8) 
			if len(data)>0: 
				while(data):
					r += data
					data = self.gpSend.read(8)				
				resp_l = r.split()
				status = self.replyparser(resp_l, t, fname)

				chFile.write(str(r))
				chFile.write(str(status))
				print r
				print status

				start = time.time()						
			end = time.time()
			TIME = end - start
			if (TIME > 1):
				chFile.write('\n' + ('-' * 70) + '\n')
				chFile.close()
			return status

	def replyparser(self, l, t, fname):
		if('protocol' in l):
			return 'HERO4 is turned ON!'
		
		elif(self.chFlag):	
			if('responseHandler:OK' in l):
				string_pos = l.index('responseHandler:OK')
				channel = string_pos - 1
				self.chFlag = False
				print '+++ HERO has turned ON and BacPac handshake is complete +++\n' + '+++ Channel ID#: ' + l[channel] + ' +++'
				return l[channel]

		elif('in:' in l):
			string_pos = l.index('in:')	
			yy = self.yyResp(string_pos)
			return self.respLn(l, yy) + self.e_code(l, yy, t) + self.data_ln(l, yy) + self.resp_data(l, yy)
		
		else: 
			return 'Error receiving data from camera - ERD'

	def respLn(self, l, yy):
		return '\nResult:\n' + 'Length of YY Response: ' + l[yy['ln']] + '\n'

	def e_code(self, l, yy, t):
		if int(l[yy['ln']],16) >= 5:
			if t == 'valid':
				if int(l[yy['error_code']],16) == 0:
					self.passed += 1
					return 'Error Code: Pass\n'
				elif int(l[yy['error_code']],16) == 1:
					self.failed += 1
					return 'Error Code: Fail\n'
				else:
					self.unknown += 1
					return 'Error Code: Unknown\n'

			else: 
				if int(l[yy['error_code']],16) == 1:
					self.passed += 1
					return 'Error Code: Pass\n'
				elif int(l[yy['error_code']],16) == 0:
					self.failed += 1
					return 'Error Code: Fail\n'
				else:
					self.unknown += 1
					return 'Error Code: Unknown\n'
		else:
			return "*****  Wrong channel ID# *****"
		
	def data_ln(self, l, yy):
		data_ln = l[yy['dataln2']]
		if data_ln > 0:
			return 'Length of response data: ' + data_ln + '\n'
		else:
			return 'Null Data\n'

	def resp_data(self, l, yy):
		if int(l[yy['dataln2']], 16) > 0:
			data_bgn = yy['dataln2'] + 1
			data_end = data_bgn + int(l[yy['dataln2']], 16)
			return 'Response data: ' + ' '.join(str(l[i]) for i in range(data_bgn, data_end)) + '\n'
		else: 
			return '\n'

	def result_summary(self):
		r = '\n' + ('=' * 30) + '\nResult summary:\nTotal commands Passed: {}\nTotal commands Failed: {} \nTotal unknown responses: {}\n' .format(self.passed, self.failed, self.unknown)
		return r

if __name__ == '__main__':

	######################
	#works only for HERO4#
	######################

	#get firmware version
	f = hero4Tester_win.tester()
	fw = f.fw()
	c = commander()

	c.startGopro4(fw)

	ask = raw_input("Did HERO boot? (Y/n): ")
	if (ask in ('n', 'N')):
		#Re-attempt to Start GoPro
		c.startGopro4(fw)

	auto = raw_input('Do you want to enter the complete command yourself? Y/n: ' )
	if auto in ('N', 'n'):
		ask = raw_input('Test ZZ or YY commands? (Z/y): ')
		if ask in ('y', 'Y'):
			dId = c.getDeviceID(fw)
			while (True):
				cmd = raw_input("Enter YY command(just command): ")
				c.writeYYCommand(dId, cmd, fw)
		else:
			while (True):
				cmd = raw_input("Enter ZZ command(just Payload Bytes): ")
				c.writeZZCommand(cmd, fw)
	else:
		while (True):
			cmd = raw_input("Enter complete command: ")
			c.writeCommand(cmd, fw)