import ConfigParser
import ast

class BoundOut():

	def __init__(self):
		self.b = ConfigParser.ConfigParser()
		self.b.read("bounds.ini")
		##  grab from ini config file  ##

		#test bound or out-bound or both?
		self.bound = ast.literal_eval(self.ConfigMap("test")['bound'])
		self.out_bound = ast.literal_eval(self.ConfigMap("test")['out_bound'])

		#out of bound settings
		self.ofb_g = int(self.ConfigMap("out_of_bound")['group'], 16)
		self.ofb_id = int(self.ConfigMap("out_of_bound")['id'], 16)
		self.ofb_b1 = int(self.ConfigMap("out_of_bound")['len_byte1'], 16)
		self.ofb_b2 = int(self.ConfigMap("out_of_bound")['len_byte2'], 16)
		self.ofb_res = int(self.ConfigMap("out_of_bound")['vid_res'], 16)
		self.ofb_fps = int(self.ConfigMap("out_of_bound")['vid_fps'], 16)
		self.ofb_fov =  int(self.ConfigMap("out_of_bound")['vid_fov'], 16)

		#API group
		self.api_ch = self.ConfigMap("API_group")['channel']
		self.api_mod = self.ConfigMap("API_group")['mode']
		self.api_vid = self.ConfigMap("API_group")['video']
		self.api_ph = self.ConfigMap("API_group")['photo']
		self.api_mul = self.ConfigMap("API_group")['multi']
		self.api_set = self.ConfigMap("API_group")['settings']
		self.api_stat = self.ConfigMap("API_group")['status']
		self.api_sdc = self.ConfigMap("API_group")['sdcard']

		#API ID
		self.api_id_ch = self.ConfigMap("API_id")[self.api_ch]
		self.api_id_mod = self.ConfigMap("API_id")[self.api_mod]
		self.api_id_vid = self.ConfigMap("API_id")[self.api_vid]
		self.api_id_ph = self.ConfigMap("API_id")[self.api_ph]
		self.api_id_mul = self.ConfigMap("API_id")[self.api_mul]
		self.api_id_set = self.ConfigMap("API_id")[self.api_set]
		self.api_id_stat = self.ConfigMap("API_id")[self.api_stat]
		self.api_id_sdc = self.ConfigMap("API_id")[self.api_sdc]

		#Values
		self.val = self.ConfigMap("value")	
		self.ntsc = self.ConfigMap("value")['format_ntsc']
		self.pal = self.ConfigMap("value")['format_pal']
		self.yr1 = self.ConfigMap("value")['time_y1']
		self.yr2 = self.ConfigMap("value")['time_y2']
		self.month = self.ConfigMap("value")['month']
		self.date = self.ConfigMap("value")['date']
		self.mins = self.ConfigMap("value")['mins']
		self.secs = self.ConfigMap("value")['secs']

		self.api_id = []
		self.api_g = []
		self.parameters = {}


	def ConfigMap(self, section):
		dict_1 = {}
		options = self.b.options(section)
		for option in options:
			try:
				dict_1[option] = self.b.get(section, option)
				if dict_1[option] == -1:
					DebugPrint("skip: %s" % option)
			except:
				print("exception on %s!" % option)
				dict_1[option] = None
		return dict_1

	def apiG(self):			#API group list
		for g in self.ConfigMap("API_group"):
			self.api_g.append(int(self.ConfigMap("API_group")[g], 16))
		self.api_g.sort()
		return self.api_g


	def apiId(self):		#API ID list	
		for g in self.api_g:
			self.api_id.append(self.ConfigMap("API_id")[str(g)].split(', '))
		return self.api_id

	def parms(self):						#Values as dic of lists
		for key in self.val:
			self.parameters[key] = self.val[key].split(', ')
		return self.parameters

	def boundGen(self, fname):
		#Length byte 1
		api_g = self.apiG()
		api_id = self.apiId()
		parameters = self.parms()
		f = open(fname, 'w')
		ln_byte1 = 0
		for g in range (0, len(api_id)):
			for i in api_id[g]: 
				if len(parameters[str(api_g[g])+' '+str(i)])>0:
					for v in range(0, len(parameters[str(api_g[g])+' '+str(i)])):
						grp = str('%x'%(api_g[g] + self.ofb_g))
						g_id = str('%x'%(int(i, 16) + self.ofb_id))
						l_b1 = str('%x'%(ln_byte1 + self.ofb_b1))
						p = parameters[str(api_g[g])+' '+str(i)][v]
						if p: 
							parm = str(int(p) +1)
						else: parm = p

						if len(parm) > 0: l_b2 = str(len(parm.split(' ')) + self.ofb_b2)
						else: l_b2 = str(self.ofb_g)
						f.write(grp+' '+g_id+' '+l_b1+' '+l_b2+' '+parm+'\n')
		f.close()

if __name__ == '__main__':
	bo = BoundOut()

	##  grab from ini config file  ##

	#test bound or out-bound or both?
	bound = ast.literal_eval(bo.ConfigMap("test")['bound'])
	out_bound = ast.literal_eval(bo.ConfigMap("test")['out_bound'])

	#out of bound settings
	ofb_g = int(bo.ConfigMap("out_of_bound")['group'], 16)
	ofb_id = int(bo.ConfigMap("out_of_bound")['id'], 16)
	ofb_b1 = int(bo.ConfigMap("out_of_bound")['len_byte1'], 16)
	ofb_b2 = int(bo.ConfigMap("out_of_bound")['len_byte2'], 16)
	ofb_res = int(bo.ConfigMap("out_of_bound")['vid_res'], 16)
	ofb_fps = int(bo.ConfigMap("out_of_bound")['vid_fps'], 16)
	ofb_fov =  int(bo.ConfigMap("out_of_bound")['vid_fov'], 16)

	#API group
	api_ch = bo.ConfigMap("API_group")['channel']
	api_mod = bo.ConfigMap("API_group")['mode']
	api_vid = bo.ConfigMap("API_group")['video']
	api_ph = bo.ConfigMap("API_group")['photo']
	api_mul = bo.ConfigMap("API_group")['multi']
	api_set = bo.ConfigMap("API_group")['settings']
	api_stat = bo.ConfigMap("API_group")['status']
	api_sdc = bo.ConfigMap("API_group")['sdcard']

	#API ID
	api_id_ch = bo.ConfigMap("API_id")[api_ch]
	api_id_mod = bo.ConfigMap("API_id")[api_mod]
	api_id_vid = bo.ConfigMap("API_id")[api_vid]
	api_id_ph = bo.ConfigMap("API_id")[api_ph]
	api_id_mul = bo.ConfigMap("API_id")[api_mul]
	api_id_set = bo.ConfigMap("API_id")[api_set]
	api_id_stat = bo.ConfigMap("API_id")[api_stat]
	api_id_sdc = bo.ConfigMap("API_id")[api_sdc]

	#Values
	val = bo.ConfigMap("value")	
	ntsc = bo.ConfigMap("value")['format_ntsc']
	pal = bo.ConfigMap("value")['format_pal']
	yr1 = bo.ConfigMap("value")['time_y1']
	yr2 = bo.ConfigMap("value")['time_y2']
	month = bo.ConfigMap("value")['month']
	date = bo.ConfigMap("value")['date']
	mins = bo.ConfigMap("value")['mins']
	secs = bo.ConfigMap("value")['secs']


	# Output text file name
	if out_bound:
		fname = 'outBound'+str(ofb_g) +str(ofb_id) +str(ofb_b1) +str(ofb_b2) +str(ofb_res) +str(ofb_fps) +str(ofb_fov) +'.txt'
	else: fname = 'justBound.txt'
		


	#API group list
	api_g = []
	for g in bo.ConfigMap("API_group"):
		api_g.append(int(bo.ConfigMap("API_group")[g], 16))
	api_g.sort()

	#API ID list
	api_id = []
	for g in api_g:
		api_id.append(bo.ConfigMap("API_id")[str(g)].split(', '))

	#Length byte 1
	ln_byte1 = 0

	#Length byte 2
	#Variable: depends on parameter(s)

	#Values as dic of lists
	parameters = {}
	for key in val:
		parameters[key] = val[key].split(', ')

	#API Group out of bound
	g_ofb_min = min(api_g)
	g_ofb_max = max(api_g) + 1
	g_ofb = [g_ofb_min, g_ofb_max]

	#API_id out of bound
	id_ofb = []
	id_ofb_minmax = []
	#convert to ints
	for l in api_id:
		temp = []
		for v in l:
			temp.append(int(v, 16))
		id_ofb.append(temp)
	#create min/max
	for i in id_ofb:
		id_ofb_minmax.append([min(i), max(i)])

	#Value out of bound
	v_ofb = {}
	v_minmax = {}
	#convert to int
	for k in parameters:
		temp = []
		for v in parameters[k]:
			try:
				temp.append(int(v, 16))
			except: pass
		v_ofb[k] = temp
	# create min/max
	for k in v_ofb:
		if v_ofb[k]:
			v_minmax[k] = [min(v_ofb[k]), max(v_ofb[k])]

	f = open(fname, 'w')

#*******************************************************
#                BOUND GENERATOR
#*******************************************************

	#bound command generator
	if bound:
		for g in range (0, len(api_id)):
			for i in api_id[g]: 
				if len(parameters[str(api_g[g])+' '+str(i)])>0:
					for v in range(0, len(parameters[str(api_g[g])+' '+str(i)])):
						grp = str(api_g[g])
						g_id = str(i) 
						l_b1 = str(ln_byte1)
						parm = parameters[str(api_g[g])+' '+str(i)][v]
						if len(parm) > 0: l_b2 = str(len(parm.split(' ')))
						else: l_b2 = '0'
						f.write(grp+' '+g_id+' '+l_b1+' '+l_b2+' '+parm+'\n')


#*******************************************************
#                OUT OF BOUND GENERATOR
#*******************************************************

	#out-bound command generator
	if out_bound:
		for g in range (0, len(api_id)):
			for i in api_id[g]: 
				if len(parameters[str(api_g[g])+' '+str(i)])>0:
					for v in range(0, len(parameters[str(api_g[g])+' '+str(i)])):
						grp = str('%x'%(api_g[g] + ofb_g))
						g_id = str('%x'%(int(i, 16) + ofb_id))
						l_b1 = str('%x'%(ln_byte1 + ofb_b1))
						p = parameters[str(api_g[g])+' '+str(i)][v]
						if p: 
							parm = str(int(p) +1)
						else: parm = p

						if len(parm) > 0: l_b2 = str(len(parm.split(' ')) + ofb_b2)
						else: l_b2 = str(ofb_g)
						f.write(grp+' '+g_id+' '+l_b1+' '+l_b2+' '+parm+'\n')
	f.close()

