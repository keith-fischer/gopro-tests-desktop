#!/usr/bin/env python
""" Automation for GoPro 4/3+ Silver/Black GCCB testing """
__author__ = "Prince Paul"
__credits__ = "Steven Martin"
__copyright__ = "Copyright 2015, Allion USA -- GoPro HERO4 BacPac Project & HERO3+ Automation"
__maintainer__ = "Prince Paul"
__email__ = "princepaul@allionusa.com"
__status__ = "Functional, Post-Development"
__documentation__ = "goproHero4GCCB_documentation.txt(outdated)"
__dependencies__ = "python-xlrd, "
__build__ = "6.1.0-phase2"

import os
import time
import hero4Send_win
import excelCmdRead
import ast
import ConfigParser
import bound_gen


class tester():

	def __init__(self):
		self.c = ConfigParser.ConfigParser()
		self.c.read("config.ini")

	def ConfigMap(self, section):
		dict1 = {}
		options = self.c.options(section)
		for option in options:
			try:
				dict1[option] = self.c.get(section, option)
				if dict1[option] == -1:
					DebugPrint("skip: %s" % option)
			except:
				print("exception on %s!" % option)
				dict1[option] = None
		return dict1

	def date(self):
		timestr = time.strftime("_%d_%m")
		return timestr

	def rname(self):
		return t.ConfigMap("Firmware")['version'] + str(self.date()) + t.ConfigMap("TestSettings")['test_notes'] + '.txt'
	
	def sname(self):
		return t.ConfigMap("Firmware")['version'] +str(self.date())+'_test_summary'+ '.txt'
	


if __name__ == '__main__':
	t = tester()
	rfname = t.rname()
	rsummary = t.sname()


	#grab from ini config file
	camera = t.ConfigMap("Camera")['hero']
	model = t.ConfigMap("Camera")['model']
	getCheck = ast.literal_eval(t.ConfigMap("TestSettings")['skip_get'])
	repCmd = int(t.ConfigMap("TestSettings")['command_times'])
	run = int(t.ConfigMap("TestSettings")["run"])
	cfname = t.ConfigMap("CommandFile")['name']
	icfname = t.ConfigMap("InvalidCommandFile")['name']
	ifname = t.ConfigMap("Illegal")['name']
	verify = ast.literal_eval(t.ConfigMap("TestSettings")['verify'])
	valid = ast.literal_eval(t.ConfigMap("TestSettings")['valid'])
	invalid = ast.literal_eval(t.ConfigMap("TestSettings")['invalid'])
	manual = ast.literal_eval(t.ConfigMap("TestSettings")['manual'])
	illegal = ast.literal_eval(t.ConfigMap("TestSettings")['illegal'])

	#Generate commands file from excel
	if ast.literal_eval(t.ConfigMap("CommandFile")['create']):
		xl = excelCmdRead.xlread()
		xl.cmdGen(cfname, run, camera, model, getCheck, repCmd)
	else:	pass

	#Generate invalid commands file
	if ast.literal_eval(t.ConfigMap("InvalidCommandFile")['create']):
		b = bound_gen.BoundOut()
		b.boundGen(icfname)
	else:	pass

	#Generate illegal commands file from excel
	if ast.literal_eval(t.ConfigMap("Illegal")['create']):
		xl = excelCmdRead.xlread()
		xl.cmdGen(ifname, run, camera, model, getCheck, repCmd)
	else:	pass
	
	#Start GCCB sender	
	gS = hero4Send_win.commander()

	#Start GoPro HERO
	if camera == '3': 
		#boot Hero 3+
		gS.startGopro3(rfname)
		ask = raw_input("Did HERO3+ boot? (Y/n): ")
		if (ask in ('n', 'N')):
		#Re-attempt to Start GoPro
			gS.startGopro3(rfname)

		#execute commands in sequence from the commands file
		commands = open(cfname, 'r')
		for cmd in commands.readlines():
			if verify:
				raw_input("Press 'Enter' to continue test: ")
			else:	time.sleep(1)
			gS.hero3Plus(cmd, fname)

	else:
		raw_input("Press 'Enter' to start the test")
		#boot HERO4
		boot = gS.startGopro4(rfname)

		#Re-attempt to Start GoPro
		
		if (not boot): 
			print 'Re-attempting to Turn-ON camera'
			boot = gS.startGopro4(rfname) 
		
		if boot:
			if('ON!' in boot):
				#Get channel ID
				dID = gS.getDeviceID(rfname)
				save_summary = open(rsummary, 'w')
				
				while manual:
					t = raw_input('Testing ZZ or YY command? \n(Enter z/y or Press "Enter" to continue automation): ')
					if t in ('z', 'Z'):
						cmd = raw_input('Enter ZZ command: ')
						gS.writeZZCommand(cmd, rfname)
					elif t in ('y', 'Y'):
						cmd = raw_input('Enter YY command (w/o channel ID): ')
						gS.writeYYCommand(dID, cmd, rfname, 'valid')
					else:
						manual = False

				#execute valid commands in sequence from the commands file
				if valid:
					resp = ' '
					commands = open(cfname, 'r')
					for cmd in commands.readlines():
						if verify:
							raw_input("Press 'Enter' to continue testing: ")
						else: time.sleep(1)
						if 'ERD' in resp: 
							print '\n***** Terminating test *****'
							break
						resp = gS.writeYYCommand(dID, cmd, rfname, 'valid')

					print gS.result_summary()
					save_summary.write('Valid Commands test results:')
					save_summary.write(gS.result_summary())

				#clear results cache
				gS.clearCache()

				#execute invalid commands in sequence from the commands file
				if invalid:
					resp = ' '
					commands = open(icfname, 'r')
					for cmd in commands.readlines():
						if verify:
							raw_input("Press 'Enter' to continue testing: ")
						else:	time.sleep(1)
						if 'ERD' in resp: 
							print '\n***** Terminating test ***** '
							break
						resp = gS.writeYYCommand(dID, cmd, rfname, 'invalid')

					print gS.result_summary()
					save_summary.write('\nInvalid Commands test results:')
					save_summary.write(gS.result_summary())


				#clear results cache
				gS.clearCache()


				#execute valid commands in sequence from the commands file
				if illegal:
					resp = ' '
					commands = open(ifname, 'r')
					for cmd in commands.readlines():
						raw_input("Press 'Enter' to continue illegal command testing: ")
						if 'ERD' in resp: 
							print '\n***** Terminating test *****'
							break
						resp = gS.writeYYCommand(dID, cmd, rfname, 'valid')

					print gS.result_summary()
					save_summary.write('\nIllegal Commands test results:')
					save_summary.write(gS.result_summary())
				
				if valid or invalid or manual or illegal:
					settings = open('config.ini', 'r')
					save_summary.write('\n\n'+('-' * 30)+'\nTest settings:\n'+('-' * 30))
					for line in settings.readlines():
						save_summary.write(line)
					settings.close()
				save_summary.close()

				print "End of Test\nTurning OFF camera"
				gS.writeYYCommand(dID, '8 2 0 1 1', rfname, 'final')

		else: 
			print '\n' + ('=' * 64) + '\nUnable to Turn-On camera, check connections and/or Documentation\n    ***** Turn OFF the camera if its already ON *****\n' + ('=' * 64)

