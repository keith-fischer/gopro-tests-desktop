#include "australia_common.h"

#define AUSTRALIA_STRING_MODEL_STREAKY L"STREAKY"