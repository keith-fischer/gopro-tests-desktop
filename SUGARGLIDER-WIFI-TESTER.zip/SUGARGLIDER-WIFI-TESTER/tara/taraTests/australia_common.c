#include <wchar.h>
#include "squirrels.h"
#include "streaky.h"

static char * australia_brand_name = AUSTRALIA_STRING_BRAND;
static wchar_t australia_models[2][10] = { AUSTRALIA_STRING_MODEL_STREAKY, AUSTRALIA_STRING_MODEL_SQUIRRELS };

char * australia_get_brand_name()
{
	return australia_brand_name;
}

wchar_t *australia_get_model(int row)
{
	return australia_models[row];
}

wchar_t * australia_get_models_arr()
{
	return (wchar_t *) &australia_models;
}

int australia_get_models_arr_length()
{
	return sizeof(australia_models) / sizeof(*australia_models);
}