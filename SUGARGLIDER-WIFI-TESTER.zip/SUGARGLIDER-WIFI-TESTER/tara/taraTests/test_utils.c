#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "test_utils.h"
#include <wchar.h>

//using selection sort
void sort_string(wchar_t **fps_arr, int last)
{
//	printf("%s \n", __FUNCTION__);
	int largest;
	wchar_t * tempData;

	for (int i = 0; i < last; i++)
	{
		largest = i;
		for (int j = i + 1; j < last; j++)
		{
//			printf("fps_arr[j] %s \t index %d \n", fps_arr[j], j);
			if (atof(fps_arr[j]) > atof(fps_arr[largest]))
				largest = j;
		}

		tempData = fps_arr[i];
		fps_arr[i] = fps_arr[largest];
		fps_arr[largest] = tempData;
	}
}