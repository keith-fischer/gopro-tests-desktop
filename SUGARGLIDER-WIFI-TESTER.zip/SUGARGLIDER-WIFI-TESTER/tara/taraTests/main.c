#include <stdio.h>  // for printf()
#include <stdlib.h>
#include <string.h>
#include "hawaii_common.h"
#include "australia_common.h"
#include "test_video.h"
#include "test_photo.h"
#include <wchar.h>
#include <mbstring.h>
#include <locale.h>


int main(int argc, char * argv[])
{
	//wchar_t *australia_brand = australia_get_brand_name();
	char *australia_brand;
	australia_brand = australia_get_brand_name();
	char *hawaii_brand = hawaii_get_brand_name();

	if (argc == 1)
	{
		printf("Please enter a brand. Options: %s, %s \n", australia_brand, hawaii_brand);
		exit(EXIT_FAILURE);
	}

	for (int i = 1; i < argc; i++)
	{
		printf("command input %s \n", argv[i]);
		if (strcmp(argv[i], australia_brand) == 0)
		{
			int australia_models_arr_length;

			australia_models_arr_length = australia_get_models_arr_length();
			for (int j = 0; j < australia_models_arr_length; j++)
			{
				wchar_t * str = australia_get_model(j);
				printf("brand %s \t model %s \n", australia_brand, str);
				test_video_runtest(australia_brand, str);
			}

		}
		else if (strcmp(argv[i], hawaii_brand) == 0)
		{
			int hawaii_models_arr_length = hawaii_get_models_arr_length();

			for (int j = 0; j < hawaii_models_arr_length; j++)
			{
				wchar_t * str = hawaii_get_model(j);
				printf("%s \t brand %s \n", __FUNCTION__, hawaii_brand);
				printf("%s \t model %s \n", __FUNCTION__, str);
				test_video_runtest(hawaii_brand, str);
			}
		}
		/*
		else
		{
		test_video_runtest(argv[1], "JUNK");
		}
		*/

		else
		{
			printf("Unrecognized model brand. Options: %ls, %ls \n", australia_brand, hawaii_brand);
//			wprintf(L"Unrecognized model brand. Options: %s, %s \n", australia_brand, hawaii_brand);
			exit(EXIT_FAILURE);
		}

	}
	return 0;
}

