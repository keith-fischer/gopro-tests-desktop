void init(char *brand, wchar_t *model);
void test_video_runtest(char *brand, wchar_t *model);

//HAWAII TESTS
void test_hawaii_video_res();
void test_hawaii_video_spot_meter();

//AUSTRALIA TESTS
void test_australia_res();
void test_australia_spot_meter();