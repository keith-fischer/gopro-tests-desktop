#include "test_photo.h"
#include "hawaii_common.h"
#include "australia_common.h"
#include <wchar.h>

HAWAII_VIDEO_DEFAULTS_FRONT_REAR *cur_hawaii_video_defaults;