#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>
#include "test_video.h"
#include "australia_common.h"
#include "hawaii_common.h"
#include "hawaii_pipe.h"
#include "hawaii_backdoor.h"



//HAWAII VARIABLES
HAWAII_VIDEO *cur_hawaii_video_res_structure;
HAWAII_VIDEO_DEFAULTS_FRONT_REAR *cur_hawaii_video_defaults_structure;
wchar_t * cur_hawaii_model;
wchar_t * hawaii_front_def_mode;
wchar_t * hawaii_front_def_res;
wchar_t * hawaii_front_def_fps;
wchar_t * hawaii_front_def_fov;
wchar_t * hawaii_front_def_low_light;
wchar_t * hawaii_front_def_spot_meter;
wchar_t * hawaii_front_def_protune;
wchar_t * hawaii_front_def_protune_wb;
wchar_t * hawaii_front_def_protune_color;
wchar_t * hawaii_front_def_protune_iso;
wchar_t * hawaii_front_def_protune_sharp;
wchar_t * hawaii_front_def_protune_ev;

//AUSTRALIA VARIABLES
AUSTRALIA_FRONT_REAR_VIDEO_DEFAULTS *cur_australia_video_defaults;


void init(char *brand, wchar_t *cam_model)
{
	char * australia_brand = australia_get_brand_name();

	char * hawaii_brand = hawaii_get_brand_name();
	wchar_t * hawaii_backdoor = hawaii_get_model_name_backdoor();
	wchar_t * hawaii_pipe = hawaii_get_model_name_pipe();

	if (strcmp(brand, hawaii_brand) == 0)
	{
		if (wcscmp(cam_model, hawaii_backdoor) == 0)
		{
			printf("In hawaii:%s \n", cam_model);
			cur_hawaii_model = hawaii_get_model_name_backdoor();
			cur_hawaii_video_res_structure = hawaii_video_get_backdoor_res_structure();
			cur_hawaii_video_defaults_structure = hawaii_video_get_backdoor_defaults_structure();

		}
		else if (wcscmp(cam_model, hawaii_pipe) == 0)
		{
			printf("In hawaii:%s \n", cam_model);
			cur_hawaii_model = hawaii_get_model_name_pipe();
			cur_hawaii_video_res_structure = hawaii_video_get_pipe_res_structure();
			cur_hawaii_video_defaults_structure = hawaii_video_get_pipe_defaults_structure();
		}

		hawaii_front_def_mode = hawaii_video_get_front_default_mode(cur_hawaii_video_defaults_structure);
		hawaii_front_def_res = hawaii_video_get_front_default_res(cur_hawaii_video_defaults_structure);
		hawaii_front_def_fps = hawaii_video_get_front_default_fps(cur_hawaii_video_defaults_structure);
		hawaii_front_def_fov = hawaii_video_get_front_default_fov(cur_hawaii_video_defaults_structure);
		hawaii_front_def_low_light = hawaii_video_get_front_default_low_light(cur_hawaii_video_defaults_structure);
		hawaii_front_def_spot_meter = hawaii_video_get_front_default_spot_meter(cur_hawaii_video_defaults_structure);
		hawaii_front_def_protune = hawaii_video_get_front_default_protune(cur_hawaii_video_defaults_structure);
		hawaii_front_def_protune_wb = hawaii_video_get_front_default_protune_white_balance(cur_hawaii_video_defaults_structure);
		hawaii_front_def_protune_color = hawaii_video_get_front_default_protune_color(cur_hawaii_video_defaults_structure);
		hawaii_front_def_protune_iso = hawaii_video_get_front_default_protune_iso(cur_hawaii_video_defaults_structure);
		hawaii_front_def_protune_sharp = hawaii_video_get_front_default_protune_sharpness(cur_hawaii_video_defaults_structure);
		hawaii_front_def_protune_ev = hawaii_video_get_front_default_protune_ev(cur_hawaii_video_defaults_structure);

	}
	else if (strcmp(brand, australia_brand) == 0)
	{

	}
	else
	{
		printf("%s:%s Unrecognized brand %s. \n", __FILE__, __FUNCTION__, brand);
		return;
	}

}

void test_video_runtest(char *brand, wchar_t *cam_model)
{
	printf("%s \n", __FUNCTION__);
	char * australia_brand = australia_get_brand_name();

	char * hawaii_brand = hawaii_get_brand_name();

	init(brand, cam_model);

	if (strcmp(brand, hawaii_brand) == 0)
	{
		test_hawaii_video_res();
		//test_hawaii_spot_meter();
	}
	else if (strcmp(brand, australia_brand) == 0)
	{
		test_australia_res();
		test_australia_spot_meter();
	}
	else
	{
		printf("%s:%s Unrecognized brand %s. \n", __FILE__, __FUNCTION__, brand);
		return;
	}


}

//HAWAII TESTS
void test_hawaii_video_res()
{
	printf("%s \n", __FUNCTION__);
	
	wchar_t * keys_input = malloc(256 * sizeof(wchar_t));
	if (keys_input == NULL)
		exit(EXIT_FAILURE);
	keys_input[0] = '\0';	

	int vm_num;
	int res_num;
	int fps_num;
	int fov_num;
	int low_light_val;
	int low_light_num;
	int fps_arr_length;
	int fov_arr_length;

	wchar_t *mode = HAWAII_STRING_FRONT_VIDEO;
	wchar_t *vm;
	wchar_t *res;
	wchar_t *fps;
	wchar_t *fov = HAWAII_STRING_FRONT_VIDEO_FOV_W;	
	wchar_t *low_light = HAWAII_STRING_FRONT_LOW_LIGHT_NA;
	wchar_t *cur_fps = HAWAII_STRING_FRONT_VIDEO_FPS_60;

	wchar_t **fps_arr = malloc(10 * sizeof(wchar_t*));
	if (fps_arr == NULL)
		exit(EXIT_FAILURE);
	wchar_t **fov_arr = malloc(3 * sizeof(wchar_t*));
	if (fov_arr == NULL)
		exit(EXIT_FAILURE);

	vm_num = hawaii_video_get_front_format_arr_length();
	for (int v = 0; v < vm_num; v++)
	{
		vm = hawaii_video_get_front_format(v);
		printf("%s \t video format %ls \n", __FUNCTION__, vm);

		res_num = cur_hawaii_video_res_structure->num_res;
//		printf("%s \t total res num %d \n", __FUNCTION__, res_num);

		for (int i = 0; i < res_num; i++)
		{
			res = cur_hawaii_video_res_structure->res_table[i].res_name;

			fps_num = cur_hawaii_video_res_structure->res_table[i].num_fps;
//			printf("%s \t total fps num %d for res %s \n", __FUNCTION__, fps_num, res);
			for (int j = 0; j < fps_num; j++)
			{
				fps = cur_hawaii_video_res_structure->res_table[i].fps_table[j].fps_name;	
				fps_arr_length = hawaii_video_get_fps(cur_hawaii_video_res_structure, vm, res, fps_arr);			

				fov_num = cur_hawaii_video_res_structure->res_table[i].fps_table[j].num_fov;
//				printf("%s \t total fov num %d \n", __FUNCTION__, fov_num);
				for (int k = 0; k < fov_num; k++)
				{
					//fov
					fov_arr_length = hawaii_video_get_fov(cur_hawaii_video_res_structure, vm, res, fps, fov_arr);
					if (wcscmp(vm, HAWAII_STRING_FRONT_NTSC) == 0)
					{
//						printf("%s \t in NTSC \n", __FUNCTION__);
						if (cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.ntsc == 1)
						{
//							printf("%s \t found fov in ntsc \n", __FUNCTION__);
							//return cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.protune_support;
							fov = cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capture_config.fov;
							cur_fps = HAWAII_STRING_FRONT_VIDEO_FPS_60;
						}
						else
							continue;
					}
					else if (wcscmp(vm, HAWAII_STRING_FRONT_PAL) == 0)
					{
//						printf("%s \t in PAL \n", __FUNCTION__);
						if (cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.pal == 1)
						{
//							printf("%s \t found fov in pal \n", __FUNCTION__);
							//return cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.protune_support;
							fov = cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capture_config.fov;
							cur_fps = HAWAII_STRING_FRONT_VIDEO_FPS_50;
						}
						else
							continue;
					}

					//low_light
					low_light_val = cur_hawaii_video_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.auto_low_light_support;
					if (low_light_val == 1)
					{
						low_light_num = hawaii_video_get_front_low_light_arr_length();
						for (int l = 0; l < low_light_num; l++)
						{
							low_light = hawaii_video_get_front_low_light(l);

							//always reset ui (manufacturer reset)
							hawaii_video_get_keys_input(
								cur_hawaii_model,
								mode,
								res,
								cur_fps, fps, fps_arr, fps_arr_length,
								fov, fov_arr, fov_arr_length,
								low_light,
								hawaii_front_def_spot_meter,
								hawaii_front_def_protune,
								hawaii_front_def_protune_wb,
								hawaii_front_def_protune_color,
								hawaii_front_def_protune_iso,
								hawaii_front_def_protune_sharp,
								hawaii_front_def_protune_ev,
								keys_input);
							//clearing keys input for next loop
							keys_input[0] = '\0';
						}
						//resetting some values to default
						fov = HAWAII_STRING_FRONT_VIDEO_FOV_W;
						low_light = HAWAII_STRING_FRONT_LOW_LIGHT_NA;
					}
					else
					{
						//always reset ui (manufacturer reset)
						hawaii_video_get_keys_input(
							cur_hawaii_model,
							mode,
							res,
							cur_fps, fps, fps_arr, fps_arr_length,
							fov, fov_arr, fov_arr_length,
							low_light,
							hawaii_front_def_spot_meter,
							hawaii_front_def_protune,
							hawaii_front_def_protune_wb,
							hawaii_front_def_protune_color,
							hawaii_front_def_protune_iso,
							hawaii_front_def_protune_sharp,
							hawaii_front_def_protune_ev,
							keys_input);
						//clear keys input for next loop
						keys_input[0] = '\0';
						//resetting some values to default
						fov = HAWAII_STRING_FRONT_VIDEO_FOV_W;
						low_light = HAWAII_STRING_FRONT_LOW_LIGHT_NA;
					}
					
				} //fov loop					
			} //fps loop
		} //res loop
	} //format loop
	/*
	int mode_arr_length = hawaii_video_get_front_mode_arr_length();
	for (int i = 0; i < mode_arr_length; i++)
	{
		wchar_t * mode = hawaii_video_get_front_mode(i);
		hawaii_video_get_keys_input(
			"BACKDOOR",
			cur_hawaii_video_res_structure,
			mode,
			hawaii_front_def_res,
			hawaii_front_def_fps,
			hawaii_front_def_fov,
			hawaii_front_def_low_light,
			hawaii_front_def_spot_meter,
			hawaii_front_def_protune,
			hawaii_front_def_protune_wb,
			hawaii_front_def_protune_color,
			hawaii_front_def_protune_iso,
			hawaii_front_def_protune_sharp,
			hawaii_front_def_protune_ev,
			keys_input);
		
		printf(" \n final keys %s for mode %s \n", keys_input, mode);
		keys_input[0] = '\0';
	}
	*/



	/*
	wchar_t * fps_keys = malloc(20 * sizeof(wchar_t));
	if (fps_keys == NULL)
		exit(EXIT_FAILURE);
	fps_keys[0] = '\0';

	wchar_t *cur_fps = "12.5";
	wchar_t *to_fps = "12.5";
	wchar_t *fps_arr[] = { "24", "50", "60", "48", "12.5" };

	hawaii_video_get_button_pressed_fps(cur_fps, to_fps, fps_arr, 5, fps_keys);
	printf(" '%s' \n", fps_keys);
	*/
	/*
	wchar_t * fov_keys = malloc(7 * sizeof(wchar_t));
	if (fov_keys == NULL)
		exit(EXIT_FAILURE);
	fov_keys[0] = '\0';

	wchar_t *cur_fov = "W";
	wchar_t *to_fov = "N";
	wchar_t *fov_arr[] = { "W", "M", "N"};

	hawaii_video_get_button_pressed_fov(cur_fov, to_fov, fov_arr, 3, fov_keys);
	printf(" '%s' \n", fov_keys);
	*/
	/*
	int fps_arr_length;
	wchar_t **fps_arr =  malloc(10 * sizeof(wchar_t *));
	if (fps_arr == NULL)
	exit(EXIT_FAILURE);
	
	fps_arr_length = hawaii_video_get_fps(cur_hawaii_video_res_structure, "PAL", "1080", fps_arr);
	

	for (int i = 0; i < fps_arr_length; i++)
	{
		printf("index %d \t fps %s \n", i, fps_arr[i]);
	}	
	*/
	/*
	wchar_t **fov_arr = malloc(5 * sizeof(wchar_t *));
	if (fov_arr == NULL)
		exit(EXIT_FAILURE);

	int fov_arr_length = hawaii_video_get_fov(cur_hawaii_video_res_structure, "NTSC", "1080", "30", fov_arr);
	for (int i = 0; i < fov_arr_length; i++)
	{
		printf("index %d \n", i);
		printf("index %d \t fov %s \n", i, fov_arr[i]);
	}
	*/
	
	/*
	int low_light = hawaii_video_is_low_light_supported(cur_hawaii_video_res_structure, "NTSC", "4K", "30", "W");
	printf("low-light %d \n", low_light);
	*/

	/*
	wchar_t **res_arr = malloc(20 * sizeof(wchar_t *));
	if (res_arr == NULL)
	exit(EXIT_FAILURE);

	int res_arr_length = hawaii_video_get_res(cur_hawaii_video_res_structure, "PAL", res_arr);
	for (int i = 0; i < res_arr_length; i++)
	{
		printf("index %d \t res %s \n", i, res_arr[i]);
	}
	*/

	/*
	int protune = hawaii_video_is_protune_supported(cur_hawaii_video_res_structure, "NTSC", "720", "60", "W");
	printf("protune %d \n", protune);
	*/

	//create a general function that creates xml request
		//get tags to send in request
		//construct keys_input and tags in xml format
		//return fully formed xml request
	//send xml request to Testlibrary
	//create a general function that performs assertion based on xml response
	//send results to Testlibrary to have them written to a file
	free(keys_input);
	//free(fps_arr);
	//free(fov_arr);
	//free(res_arr);
//	free(fps_keys);
//	free(fov_keys);
}

void test_hawaii_video_spot_meter()
{
	/*
	printf("%s \n", __FUNCTION__);
	wchar_t * keys_input = malloc(256 * sizeof(wchar_t));
	if (keys_input == NULL)
		exit(EXIT_FAILURE);
	keys_input[0] = '\0';

	for (int i = 0; i < mode_arr_length; i++)
	{
		wchar_t * mode = hawaii_video_get_front_mode(i);
		hawaii_video_get_keys_input(hawaii_front_def_mode,
			hawaii_front_def_res,
			hawaii_front_def_fps,
			hawaii_front_def_fov,
			hawaii_front_def_low_light,
			hawaii_front_def_spot_meter,
			hawaii_front_def_protune,
			hawaii_front_def_protune_wb,
			hawaii_front_def_protune_color,
			hawaii_front_def_protune_iso,
			hawaii_front_def_protune_sharp,
			hawaii_front_def_protune_ev,
			keys_input);
	}
	free(keys_input);
*/

}

//AUSTRALIA TESTS
void test_australia_res()
{
	printf("%s \n", __FUNCTION__);
}

void test_australia_spot_meter()
{
	printf("%s \n", __FUNCTION__);
}