#include "hawaii_common.h"
#include "hawaii_pipe.h"
#include <wchar.h>

//PIPE - This is probably not needed!!! defaults settings because testlibrary already reset it
static HAWAII_VIDEO_DEFAULTS_FRONT_REAR pipe_video_defaults =
{
	{
		HAWAII_STRING_FRONT_VIDEO,
		HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
		HAWAII_STRING_FRONT_VIDEO_FPS_30,
		HAWAII_STRING_FRONT_VIDEO_FOV_W,
		HAWAII_STRING_FRONT_LOW_LIGHT_NA,
		HAWAII_STRING_FRONT_SPOT_METER_OFF,
		HAWAII_STRING_FRONT_PROTUNE_OFF,
		HAWAII_STRING_FRONT_WHITE_BALANCE_AUTO,
		HAWAII_STRING_FRONT_COLOR_GOPRO,
		HAWAII_STRING_FRONT_ISO_1600,
		HAWAII_STRING_FRONT_SHARPNESS_HIGH,
		HAWAII_STRING_FRONT_EV_0
	},

	{
		HAWAII_STRING_REAR_VIDEO,
		HAWAII_STRING_REAR_RES_1080S,
		HAWAII_STRING_REAR_FPS_30,
		HAWAII_STRING_REAR_FOV_WIDE,
		HAWAII_STRING_REAR_LOW_LIGHT_NA,
		HAWAII_STRING_REAR_SPOT_METER_OFF,
		HAWAII_STRING_REAR_PROTUNE_OFF,
		HAWAII_STRING_REAR_WHITE_BALANCE_AUTO,
		HAWAII_STRING_REAR_COLOR_GOPRO,
		HAWAII_STRING_REAR_ISO_1600,
		HAWAII_STRING_REAR_SHARPNESS_HIGH,
		HAWAII_STRING_REAR_EV_0
	}
};

static HAWAII_VIDEO pipe_video_resolution =
{
	.num_res = 12,
	.res_table = (HAWAII_VIDEO_RES[])
	{
		[0] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_4K,
			.num_fps = 3,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_4K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_4K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_4K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[1] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_4K_S,
			.num_fps = 1,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_4K_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[2] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
			.num_fps = 6,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_48,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[3] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[4] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[5] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[3] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_S,
			.num_fps = 2,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[4] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3,
			.num_fps = 2,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[5] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_1440,
			.num_fps = 7,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_80,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_80,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[3] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_48,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[4] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[5] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[6] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[6] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
			.num_fps = 7,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_80,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_80,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[3] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_48,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[4] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[5] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[6] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[7] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_1080,
			.num_fps = 8,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_120,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_90,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_90,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_90,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[3] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
									{
										.protune_support = 1,
										.auto_low_light_support = 1,
										.looping = 1,
										.ntsc = 0,
										.pal = 1
									}
							}
						}
					}//fov table end
				},
				[4] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_48,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_48,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[5] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[6] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
									{
										.protune_support = 1,
										.auto_low_light_support = 0,
										.looping = 1,
										.ntsc = 0,
										.pal = 1
									}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[7] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[8] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_960,
			.num_fps = 3,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_120,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_960,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_960,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_960,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[9] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_720_S,
			.num_fps = 3,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_120,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720_S,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[10] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_720,
			.num_fps = 6,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_240,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_240,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_120,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_120,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[3] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 1,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[4] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[5] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[11] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_WVGA,
			.num_fps = 1,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_240,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_WVGA,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_240,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.looping = 1,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		}
	} //res table end
}; //video resolution (video single & looping)

//photo-in-video (piv) resolution
static HAWAII_VIDEO pipe_piv_resolution =
{
	.num_res = 3,
	.res_table = (HAWAII_VIDEO_RES[])
	{
		[0] = {
			.res_name= HAWAII_STRING_FRONT_VIDEO_RES_1440,
			.num_fps = 1,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1440,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[1] = {
			.res_name= HAWAII_STRING_FRONT_VIDEO_RES_1080,
			.num_fps = 3,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 1,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_24,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_1080,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_24,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[2] = {
			.res_name= HAWAII_STRING_FRONT_VIDEO_RES_720,
			.num_fps = 4,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_60,
					.num_fov = 2,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_60,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_50,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_50,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				},
				[2] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[3] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 3,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
									{
										.protune_support = 0,
										.auto_low_light_support = 0,
										.ntsc = 0,
										.pal = 1
									}
							}
						},
						[1] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_M,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						},
						[2] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_720,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_N,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		}
	} //res table end
};// (piv resolutions)

static HAWAII_VIDEO pipe_video_timelapse_resolution =
{
	.num_res = 2,
	.res_table = (HAWAII_VIDEO_RES[])
	{
		[0] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_4K,
			.num_fps = 2,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_4K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_4K,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		},
		[1] = {
			.res_name = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3,
			.num_fps = 2,
			.fps_table = (HAWAII_VIDEO_FPS[])
			{
				[0] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_30,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_30,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 1,
									.pal = 0
								}
							}
						}
					}//fov table end
				},
				[1] = {
					.fps_name = HAWAII_STRING_FRONT_VIDEO_FPS_25,
					.num_fov = 1,
					.fov_table = (HAWAII_VIDEO_FOV[])
					{
						[0] = {
							.video_config =
							{
								.capture_config =
								{
									.resolution = HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3,
									.fps = HAWAII_STRING_FRONT_VIDEO_FPS_25,
									.fov = HAWAII_STRING_FRONT_VIDEO_FOV_W,
								},
								.capabilities =
								{
									.protune_support = 0,
									.auto_low_light_support = 0,
									.ntsc = 0,
									.pal = 1
								}
							}
						}
					}//fov table end
				}
			}//fps table end
		}
	} //res table end
}; // (video pes resolutions)




//methods
wchar_t * hawaii_get_model_name_pipe()
{
	return HAWAII_STRING_MODEL_PIPE;
}

HAWAII_VIDEO * hawaii_video_get_pipe_res_structure()
{
	return &pipe_video_resolution;
}

HAWAII_VIDEO * hawaii_piv_get_pipe_res_structure()
{
	return &pipe_piv_resolution;
}

HAWAII_VIDEO * hawaii_video_timelapse_get_pipe_res_structure()
{
	return &pipe_video_timelapse_resolution;
}

HAWAII_VIDEO_DEFAULTS_FRONT_REAR *hawaii_video_get_pipe_defaults_structure()
{
	return &pipe_video_defaults;
}
