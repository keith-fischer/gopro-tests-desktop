#include <wchar.h>

void init(wchar_t *model);
void test_photo_runtest(wchar_t *model);
void test_photo_mode();
void test_photo_spot_meter();