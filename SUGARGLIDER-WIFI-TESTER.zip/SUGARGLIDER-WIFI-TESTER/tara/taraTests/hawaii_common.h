#include <wchar.h>

#ifndef HAWAII_COMMOM_H
#define HAWAII_COMMOM_H



//FRONT VALUES
#define HAWAII_STRING_FRONT_VIDEO L"VIDEO"
#define HAWAII_STRING_FRONT_VIDEO_TIME_LAPSE L"T LAPSE VID"
#define HAWAII_STRING_FRONT_VIDEO_PHOTO L"VID + PHOTO"
#define HAWAII_STRING_FRONT_VIDEO_LOOPING L"LOOPING"

#define HAWAII_STRING_FRONT_VIDEO_RES_4K L"4K"
#define HAWAII_STRING_FRONT_VIDEO_RES_4K_S L"4K S"
#define HAWAII_STRING_FRONT_VIDEO_RES_2_7K L"2.7K"
#define HAWAII_STRING_FRONT_VIDEO_RES_2_7K_S L"2.7K S"
#define HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3 L"2.7K4:3"
#define HAWAII_STRING_FRONT_VIDEO_RES_1440 L"1440"
#define HAWAII_STRING_FRONT_VIDEO_RES_1080 L"1080"
#define HAWAII_STRING_FRONT_VIDEO_RES_1080_S L"1080 S"
#define HAWAII_STRING_FRONT_VIDEO_RES_960 L"960"
#define HAWAII_STRING_FRONT_VIDEO_RES_720 L"720"
#define HAWAII_STRING_FRONT_VIDEO_RES_720_S L"720 S"
#define HAWAII_STRING_FRONT_VIDEO_RES_WVGA L"WVGA"

#define HAWAII_STRING_FRONT_VIDEO_FPS_240 L"240"
#define HAWAII_STRING_FRONT_VIDEO_FPS_120 L"120"
#define HAWAII_STRING_FRONT_VIDEO_FPS_100 L"100"
#define HAWAII_STRING_FRONT_VIDEO_FPS_90 L"90"
#define HAWAII_STRING_FRONT_VIDEO_FPS_80 L"80"
#define HAWAII_STRING_FRONT_VIDEO_FPS_60 L"60"
#define HAWAII_STRING_FRONT_VIDEO_FPS_50 L"50"
#define HAWAII_STRING_FRONT_VIDEO_FPS_48 L"48"
#define HAWAII_STRING_FRONT_VIDEO_FPS_30 L"30"
#define HAWAII_STRING_FRONT_VIDEO_FPS_25 L"25"
#define HAWAII_STRING_FRONT_VIDEO_FPS_24 L"24"
#define HAWAII_STRING_FRONT_VIDEO_FPS_15 L"15"
#define HAWAII_STRING_FRONT_VIDEO_FPS_12_5 L"12.5"

#define HAWAII_STRING_FRONT_VIDEO_FOV_W L"W"
#define HAWAII_STRING_FRONT_VIDEO_FOV_M L"M"
#define HAWAII_STRING_FRONT_VIDEO_FOV_N L"N"

#define HAWAII_STRING_FRONT_LOW_LIGHT_ON L"ON"
#define HAWAII_STRING_FRONT_LOW_LIGHT_OFF L"0FF"
#define HAWAII_STRING_FRONT_LOW_LIGHT_NA L"N/A"

#define HAWAII_STRING_FRONT_SPOT_METER_ON L"ON"
#define HAWAII_STRING_FRONT_SPOT_METER_OFF L"OFF"

#define HAWAII_STRING_FRONT_PROTUNE_ON L"ON"
#define HAWAII_STRING_FRONT_PROTUNE_OFF L"OFF"

#define HAWAII_STRING_FRONT_WHITE_BALANCE_AUTO L"AUTO"

#define HAWAII_STRING_FRONT_COLOR_GOPRO L"GOPRO"

#define HAWAII_STRING_FRONT_ISO_1600 L"1600"

#define HAWAII_STRING_FRONT_SHARPNESS_HIGH L"HIGH"

#define HAWAII_STRING_FRONT_EV_0 L"0"

#define HAWAII_STRING_FRONT_NTSC L"NTSC"
#define HAWAII_STRING_FRONT_PAL L"PAL"

//REAR VALUES
#define HAWAII_STRING_REAR_VIDEO L"Video"
#define HAWAII_STRING_REAR_VIDEO_TIME_LAPSE L"Time Lapse Video"
#define HAWAII_STRING_REAR_VIDEO_PHOTO L"Video + Photo"
#define HAWAII_STRING_REAR_VIDEO_LOOPING L"Looping"

#define HAWAII_STRING_REAR_RES_1080S L"1080 SuperView"

#define HAWAII_STRING_REAR_FPS_30 L"30"

#define HAWAII_STRING_REAR_FOV_WIDE L"Wide"

#define HAWAII_STRING_REAR_LOW_LIGHT_ON L"ON"
#define HAWAII_STRING_REAR_LOW_LIGHT_NA L"N/A"

#define HAWAII_STRING_REAR_SPOT_METER_ON L"ON"
#define HAWAII_STRING_REAR_SPOT_METER_OFF L"OFF"

#define HAWAII_STRING_REAR_PROTUNE_ON L"ON"
#define HAWAII_STRING_REAR_PROTUNE_OFF L"OFF"

#define HAWAII_STRING_REAR_WHITE_BALANCE_AUTO L"Auto"

#define HAWAII_STRING_REAR_COLOR_GOPRO L"GoPro Color"

#define HAWAII_STRING_REAR_ISO_1600 L"1600"

#define HAWAII_STRING_REAR_SHARPNESS_HIGH L"High"

#define HAWAII_STRING_REAR_EV_0 L"0"

//GENERAL STRING
#define HAWAII_STRING_BRAND "HAWAII"
#define HAWAII_STRING_BUTTON_MODE_F1 L"F1"
#define HAWAII_STRING_BUTTON_SHUTTER_F2 L"F2"
#define HAWAII_STRING_BUTTON_MENU_F3 L"F3"

//COMMON DATA STRUCTURE
//VIDEO CONTEXTUAL SETTINGS
typedef struct
{
	wchar_t *mode;
	wchar_t *res;
	wchar_t *fps;
	wchar_t *fov;
	wchar_t *low_light;
	wchar_t *spot_meter;
	wchar_t *protune;
	wchar_t *white_balance;
	wchar_t *color;
	wchar_t *iso;
	wchar_t *sharpness;
	wchar_t *ev;
} HAWAII_VIDEO_DEFAULTS;

typedef struct
{
	HAWAII_VIDEO_DEFAULTS front;
	HAWAII_VIDEO_DEFAULTS rear;
} HAWAII_VIDEO_DEFAULTS_FRONT_REAR;

//VIDEO RESOLUTION
//Capture capabilities
typedef struct
{
	// 1 if protune is supported
	int protune_support;
	// 1 if auto low light is supported
	int auto_low_light_support;
	// 1 if video looping is supported
	int looping;
	// 1 identify if broadcast is supported
	int ntsc;
	// 1 identify if pal is supported
	int pal;
} HAWAII_VIDEO_CAPABILITIES;

// Capture configuration
typedef struct
{
	wchar_t * resolution;
	wchar_t * fps;
	wchar_t * fov;
} HAWAII_VIDEO_CAPTURE_CONFIGURATION;

// camera configuration structure 
typedef struct
{
	// capture configuration containing res,fps,fov, config
	HAWAII_VIDEO_CAPTURE_CONFIGURATION capture_config;
	// capabilities
	HAWAII_VIDEO_CAPABILITIES capabilities;
} HAWAII_VIDEO_CONFIGURATION;

// fov structure
typedef struct
{
	HAWAII_VIDEO_CONFIGURATION video_config;
} HAWAII_VIDEO_FOV;

// fps structure
typedef struct
{
	wchar_t * fps_name;
	int num_fov;
	HAWAII_VIDEO_FOV *fov_table;
} HAWAII_VIDEO_FPS;

// res structure
typedef struct
{
	wchar_t * res_name;
	int num_fps;
	HAWAII_VIDEO_FPS *fps_table;
} HAWAII_VIDEO_RES;

// video res structure
typedef struct
{
	int num_res;
	HAWAII_VIDEO_RES *res_table;
} HAWAII_VIDEO;

//methods
char * hawaii_get_brand_name();
wchar_t * hawaii_get_model(int row);
wchar_t * hawaii_get_models_arr();
int hawaii_get_models_arr_length();
wchar_t * hawaii_video_get_front_mode(int row);
wchar_t * hawaii_video_get_front_mode_arr();
int hawaii_video_get_front_mode_arr_length();
wchar_t * hawaii_video_get_front_format(int row);
wchar_t * hawaii_video_get_front_format_arr();
int hawaii_video_get_front_format_arr_length();
wchar_t * hawaii_video_get_front_low_light(int row);
wchar_t * hawaii_video_get_front_low_light_arr();
int hawaii_video_get_front_low_light_arr_length();
wchar_t * hawaii_video_get_front_spot_meter(int row);
wchar_t * hawaii_video_get_front_spot_meter_arr();
int hawaii_video_get_front_spot_meter_arr_length();
wchar_t * hawaii_video_get_front_protune(int row);
wchar_t * hawaii_video_get_front_protune_arr();
int hawaii_video_get_front_protune_arr_length();

int hawaii_video_get_res(HAWAII_VIDEO *video_structure, wchar_t *vm, wchar_t **mem);
int hawaii_video_get_fps(HAWAII_VIDEO *video_structure, wchar_t *vm, wchar_t *res, wchar_t **mem);
int hawaii_video_get_fov(HAWAII_VIDEO *video_structure, wchar_t *vm, wchar_t *res, wchar_t *fps, wchar_t **mem);
int hawaii_video_is_low_light_supported(HAWAII_VIDEO *video_structure, wchar_t *vm, wchar_t *res, wchar_t *fps, wchar_t *fov);
int hawaii_video_is_protune_supported(HAWAII_VIDEO *video_structure, wchar_t *vm, wchar_t *res, wchar_t *fps, wchar_t *fov);

void hawaii_video_get_keys_input(	
	wchar_t *model,
	wchar_t *mode,
	wchar_t *res,
	wchar_t *cur_fps, wchar_t *fps, wchar_t **fps_arr, int fps_arr_length,
	wchar_t *fov, wchar_t **fov_arr, int fov_arr_length,
	wchar_t *low_light,
	wchar_t *hawaii_video_front_spot_meter,
	wchar_t *hawaii_video_front_protune,
	wchar_t *hawaii_video_front_protune_wb,
	wchar_t *hawaii_video_front_protune_color,
	wchar_t *hawaii_video_front_protune_iso,
	wchar_t *hawaii_video_front_protune_sharp,
	wchar_t *hawaii_video_front_protune_ev,
	wchar_t *keys);
void hawaii_video_get_keys_input_protune();
void hawaii_video_get_button_pressed_mode(wchar_t *mode_set, wchar_t *mem);
void hawaii_video_get_button_pressed_res(wchar_t *model, wchar_t *res, wchar_t *mem);
void hawaii_video_get_button_pressed_fps(wchar_t *cur_fps, wchar_t *to_fps, wchar_t **fps_arr, int fps_length, wchar_t *mem);
void hawaii_video_get_button_pressed_fov(wchar_t *to_fov, wchar_t **fov_arr, int fov_length, wchar_t *mem);
void hawaii_video_get_button_pressed_low_light(wchar_t *low_light, wchar_t *mem);
void hawaii_video_get_button_pressed_spot_meter(wchar_t *spot_meter, wchar_t *mem);
void hawaii_video_get_button_pressed_protune(wchar_t *protune, wchar_t *mem);
void hawaii_video_get_button_pressed_protune_white_balance(wchar_t *wb);
void hawaii_video_get_button_pressed_protune_color(wchar_t *color);
void hawaii_video_get_button_pressed_protune_iso(wchar_t *iso);
void hawaii_video_get_button_pressed_protune_sharpness(wchar_t *sharp);
void hawaii_video_get_button_pressed_protune_ev(wchar_t *ev);

//HAWAII_VIDEO *hawaii_video_get_pipe_res_structure();
//HAWAII_VIDEO *hawaii_video_get_backdoor_res_structure();
//HAWAII_VIDEO_DEFAULTS_FRONT_REAR *hawaii_video_get_pipe_defaults_structure();
//HAWAII_VIDEO_DEFAULTS_FRONT_REAR *hawaii_video_get_backdoor_defaults_structure();
wchar_t * hawaii_video_get_front_default_mode(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_res(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_fps(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_fov(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_low_light(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_spot_meter(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_protune(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_protune_white_balance(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_protune_color(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_protune_iso(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_protune_sharpness(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);
wchar_t * hawaii_video_get_front_default_protune_ev(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model);

#endif // !HAWAII_COMMOM_H