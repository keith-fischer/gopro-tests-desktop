#include "hawaii_common.h"

#define HAWAII_STRING_MODEL_BACKDOOR  L"BACKDOOR"

wchar_t * hawaii_get_model_name_backdoor();

HAWAII_VIDEO *hawaii_video_get_backdoor_res_structure();
HAWAII_VIDEO * hawaii_piv_get_backdoor_res_structure();
HAWAII_VIDEO * hawaii_video_timelapse_get_backdoor_res_structure();
HAWAII_VIDEO_DEFAULTS_FRONT_REAR *hawaii_video_get_backdoor_defaults_structure();