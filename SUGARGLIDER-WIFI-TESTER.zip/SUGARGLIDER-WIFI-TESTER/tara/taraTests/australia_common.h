#ifndef AUSTRALIA_COMMON_H
#define AUSTRALIA_COMMON_H

//methods
char *australia_get_brand_name();
wchar_t *australia_get_model(int row);
wchar_t *australia_get_models_arr();
int australia_get_models_arr_length();

#define AUSTRALIA_STRING_FRONT_VIDEO "AUSTRALIA VIDEO"
#define AUSTRALIA_STRING_BRAND "AUSTRALIA"

typedef struct
{
	wchar_t *mode;
	wchar_t *res;
	wchar_t *fps;
	wchar_t *fov;
	wchar_t *low_light;
	wchar_t *spot_meter;
	wchar_t *protune;
	wchar_t *white_balance;
	wchar_t *color;
	wchar_t *iso;
	wchar_t *sharpness;
	wchar_t *ev;
} AUSTRALIA_VIDEO_DEFAULTS;


typedef struct
{
	AUSTRALIA_VIDEO_DEFAULTS front;
	AUSTRALIA_VIDEO_DEFAULTS rear;
} AUSTRALIA_FRONT_REAR_VIDEO_DEFAULTS;

#endif // !AUSTRALIA_COMMON_H