#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "hawaii_common.h"
#include "hawaii_backdoor.h"
#include "hawaii_pipe.h"
#include "test_utils.h"
#include <wchar.h>

static char *hawaii_brand_name = HAWAII_STRING_BRAND;
static wchar_t hawaii_models[2][9] = { HAWAII_STRING_MODEL_BACKDOOR, HAWAII_STRING_MODEL_PIPE };
static wchar_t hawaii_video_front_mode[4][15] = { HAWAII_STRING_FRONT_VIDEO, HAWAII_STRING_FRONT_VIDEO_TIME_LAPSE, HAWAII_STRING_FRONT_VIDEO_PHOTO, HAWAII_STRING_FRONT_VIDEO_LOOPING };
static wchar_t hawaii_video_front_format[2][5] = { HAWAII_STRING_FRONT_NTSC, HAWAII_STRING_FRONT_PAL };
static wchar_t hawaii_video_front_low_light[2][4] = { HAWAII_STRING_FRONT_LOW_LIGHT_ON, HAWAII_STRING_FRONT_LOW_LIGHT_OFF };
static wchar_t hawaii_video_front_spot_meter[2][4] = { HAWAII_STRING_FRONT_SPOT_METER_OFF, HAWAII_STRING_FRONT_SPOT_METER_ON };
static wchar_t hawaii_video_front_protune[2][4] = { HAWAII_STRING_FRONT_PROTUNE_OFF, HAWAII_STRING_FRONT_PROTUNE_ON };
static wchar_t hawaii_rear_mode[4][20] = { HAWAII_STRING_REAR_VIDEO, HAWAII_STRING_REAR_VIDEO_TIME_LAPSE, HAWAII_STRING_REAR_VIDEO_PHOTO, HAWAII_STRING_REAR_VIDEO_LOOPING };

char * hawaii_get_brand_name()
{
	return hawaii_brand_name;
}

wchar_t * hawaii_get_model(int row)
{
	return hawaii_models[row];
}

wchar_t * hawaii_get_models_arr()
{
	return (wchar_t *) &hawaii_models;
}

int hawaii_get_models_arr_length()
{
	return sizeof(hawaii_models) / sizeof(hawaii_models[0]);
}

wchar_t * hawaii_video_get_front_mode(int row)
{
	return hawaii_video_front_mode[row];
}

wchar_t * hawaii_video_get_front_mode_arr()
{
	return (wchar_t *) &hawaii_video_front_mode;
}

int hawaii_video_get_front_mode_arr_length()
{
	return sizeof(hawaii_video_front_mode) / sizeof(hawaii_video_front_mode[0]);
}

wchar_t * hawaii_video_get_front_format(int row)
{
	return hawaii_video_front_format[row];
}

wchar_t * hawaii_video_get_front_format_arr()
{
	return (wchar_t *)&hawaii_video_front_format;
}

int hawaii_video_get_front_format_arr_length()
{
	return sizeof(hawaii_video_front_format) / sizeof(hawaii_video_front_format[0]);
}

wchar_t * hawaii_video_get_front_spot_meter(int row)
{
	return hawaii_video_front_spot_meter[row];
}

wchar_t * hawaii_video_get_front_low_light(int row)
{
	return hawaii_video_front_low_light[row];
}

wchar_t * hawaii_video_get_front_low_light_arr()
{
	return (wchar_t *)&hawaii_video_front_low_light;
}

int hawaii_video_get_front_low_light_arr_length()
{
	return sizeof(hawaii_video_front_low_light) / sizeof(hawaii_video_front_low_light[0]);
}

wchar_t * hawaii_video_get_front_spot_meter_arr()
{
	return (wchar_t *) &hawaii_video_front_spot_meter;
}

int hawaii_video_get_front_spot_meter_arr_length()
{
	return sizeof(hawaii_video_front_spot_meter) / sizeof(hawaii_video_front_spot_meter[0]);
}

wchar_t * hawaii_video_get_front_protune(int row)
{
	return hawaii_video_front_protune[row];
}

wchar_t * hawaii_video_get_front_protune_arr()
{
	return (wchar_t *) &hawaii_video_front_protune;
}

int hawaii_video_get_front_protune_arr_length()
{
	return sizeof(hawaii_video_front_protune) / sizeof(hawaii_video_front_protune[0]);
}

int hawaii_video_get_res(HAWAII_VIDEO *cur_res_structure, wchar_t *vm, wchar_t **mem)
{
//	printf("%s \t vm %s \n", __FUNCTION__, vm);

	int fps_num;
	int res_num;
	int fov_num;
	int res_arr_index = 0;
	wchar_t * prev_res_name = L"";

	res_num = cur_res_structure->num_res;
//	printf("total res num %d \n", res_num);

	for (int i = 0; i < res_num; i++)
	{
		fps_num = cur_res_structure->res_table[i].num_fps;

		for (int j = 0; j < fps_num; j++)
		{
			fov_num = cur_res_structure->res_table[i].fps_table[j].num_fov;
//			printf("%s \t total fov num %d \n", __FUNCTION__, fov_num);

			for (int k = 0; k < fov_num; k++)
			{
				if (wcscmp(vm, HAWAII_STRING_FRONT_NTSC) == 0)
				{
//					printf("%s \t in NTSC \n", __FUNCTION__);
					if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.ntsc == 1)
					{
						if (wcscmp(prev_res_name, cur_res_structure->res_table[i].res_name) != 0)
						{
//							printf("%s found fov in ntsc \n", __FUNCTION__);
							mem[res_arr_index] = cur_res_structure->res_table[i].res_name;
							res_arr_index++;
							prev_res_name = cur_res_structure->res_table[i].res_name;
						}
					}
				}
				else if (wcscmp(vm, HAWAII_STRING_FRONT_PAL) == 0)
				{
//					printf("%s \t in PAL \n", __FUNCTION__);
					if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.pal == 1)
					{
						if (wcscmp(prev_res_name, cur_res_structure->res_table[i].res_name) != 0)
						{
//							printf("%s found fov in pal \n", __FUNCTION__);
							mem[res_arr_index] = cur_res_structure->res_table[i].res_name;
							res_arr_index++;
							prev_res_name = cur_res_structure->res_table[i].res_name;
						}
					}
				}
			} //fov loop
		} //fps loop
	} //res loop
//	printf("%s returning \n", __FUNCTION__);
	return res_arr_index;
}

//return all fps for that vm & res
int hawaii_video_get_fps(HAWAII_VIDEO *cur_res_structure, wchar_t *vm, wchar_t *res, wchar_t **mem)
{
	int fps_num;
	int res_num;
	int fov_num;
	int fps_arr_index = 0;
	wchar_t * prev_fps_name = L"";

//	printf("%s \t vm %s \t res %s \n", __FUNCTION__, vm, res);

	res_num = cur_res_structure->num_res;
//	printf("%s total res num %d \n", __FUNCTION__, res_num);

	for (int i = 0; i < res_num; i++)
	{
		if (wcscmp(res, cur_res_structure->res_table[i].res_name) == 0)
		{
			fps_num = cur_res_structure->res_table[i].num_fps;
//			printf("%s \t total fps num %d for res %s \n", __FUNCTION__, fps_num, res);

			for (int j = 0; j < fps_num; j++)
			{
				fov_num = cur_res_structure->res_table[i].fps_table[j].num_fov;
//				printf("%s \t total fov num %d \n", __FUNCTION__, fov_num);

				for (int k = 0; k < fov_num; k++)
				{
					if (wcscmp(vm, HAWAII_STRING_FRONT_NTSC) == 0)
					{
//						printf("%s \t in NTSC \n", __FUNCTION__);
						if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.ntsc == 1)
						{
							if (wcscmp(prev_fps_name, cur_res_structure->res_table[i].fps_table[j].fps_name) != 0)
							{
//								printf("%s \t found fov in ntsc \t fps_arr_index %d \n", __FUNCTION__, fps_arr_index);
								mem[fps_arr_index] = cur_res_structure->res_table[i].fps_table[j].fps_name;
								fps_arr_index++;
								prev_fps_name = cur_res_structure->res_table[i].fps_table[j].fps_name;
							}
						}
					}
					else if (wcscmp(vm, HAWAII_STRING_FRONT_PAL) == 0)
					{
//						printf("%s \t in PAL", __FUNCTION__);
						if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.pal == 1)
						{
							if (wcscmp(prev_fps_name, cur_res_structure->res_table[i].fps_table[j].fps_name) != 0)
							{
//								printf("%s \t found fov in pal \n", __FUNCTION__);
								mem[fps_arr_index] = cur_res_structure->res_table[i].fps_table[j].fps_name;
								fps_arr_index++;
								prev_fps_name = cur_res_structure->res_table[i].fps_table[j].fps_name;
							}
						}
					}
				} //fov loop
			} //fps loop
		}
	} //res loop
//	printf("%s \t returning \n", __FUNCTION__);
	return fps_arr_index;
}

//return all fov for that vm, res & fps
int hawaii_video_get_fov(HAWAII_VIDEO *cur_res_structure, wchar_t *vm, wchar_t *res, wchar_t *fps, wchar_t **mem)
{
	int fps_num;
	int res_num;
	int fov_num;
	int fov_arr_index = 0;

//	printf("%s \t vm %s \t res %s \t fps %s \n", __FUNCTION__, vm, res, fps);

	res_num = cur_res_structure->num_res;
//	printf("%s \t total res num %d \n", __FUNCTION__, res_num);

	for (int i = 0; i < res_num; i++)
	{
		if (wcscmp(res, cur_res_structure->res_table[i].res_name) == 0)
		{
			fps_num = cur_res_structure->res_table[i].num_fps;
//			printf("%s \t total fps num %d for res %s \n", __FUNCTION__, fps_num, res);

			for (int j = 0; j < fps_num; j++)
			{
				if (wcscmp(fps, cur_res_structure->res_table[i].fps_table[j].fps_name) == 0)
				{
					fov_num = cur_res_structure->res_table[i].fps_table[j].num_fov;
//					printf("%s \t total fov num %d \n", __FUNCTION__, fov_num);

					for (int k = 0; k < fov_num; k++)
					{
						if (wcscmp(vm, HAWAII_STRING_FRONT_NTSC) == 0)
						{
//							printf("%s \t in NTSC \n", __FUNCTION__);
							if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.ntsc == 1)
							{
//								printf("%s \t found fov in ntsc \t fov_arr_index %d \n", __FUNCTION__, fov_arr_index);
								mem[fov_arr_index] = cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capture_config.fov;
								fov_arr_index++;
							}
						}
						else if (wcscmp(vm, HAWAII_STRING_FRONT_PAL) == 0)
						{
//							printf("%s \t in PAL", __FUNCTION__);
							if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.pal == 1)
							{
//								printf("%s \t found fov in pal \n", __FUNCTION__);
								mem[fov_arr_index] = cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capture_config.fov;
								fov_arr_index++;
							}
						}
					} //fov loop
				}	
			} //fps loop
		}
	} //res loop

//	printf("%s \t returning \n", __FUNCTION__);
	return fov_arr_index;
}

//1 = yes low light supported, 0 = no low light not supported
int hawaii_video_is_low_light_supported(HAWAII_VIDEO *cur_res_structure, wchar_t *vm, wchar_t *res, wchar_t *fps, wchar_t *fov)
{
	int fps_num;
	int res_num;
	int fov_num;

	printf("video mode %s \n", vm);
	printf("res %s \n", res);

	res_num = cur_res_structure->num_res;
	printf("total res num %d \n", res_num);

	for (int i = 0; i < res_num; i++)
	{
		if (wcscmp(res, cur_res_structure->res_table[i].res_name) == 0)
		{
			fps_num = cur_res_structure->res_table[i].num_fps;
			printf("total fps num %d for res %s \n", fps_num, res);

			for (int j = 0; j < fps_num; j++)
			{
				if (wcscmp(fps, cur_res_structure->res_table[i].fps_table[j].fps_name) == 0)
				{
					fov_num = cur_res_structure->res_table[i].fps_table[j].num_fov;
					printf("total fov num %d \n", fov_num);

					for (int k = 0; k < fov_num; k++)
					{
						if (wcscmp(vm, HAWAII_STRING_FRONT_NTSC) == 0)
						{
							printf("in NTSC \n");
							if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.ntsc == 1)
							{
								printf("found fov in ntsc \n");
								return cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.auto_low_light_support;
							}
						}
						else if (wcscmp(vm, HAWAII_STRING_FRONT_PAL) == 0)
						{
							printf("in PAL");
							if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.pal == 1)
							{
								printf("found fov in pal \n");
								return cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.auto_low_light_support;
							}
						}
					} //fov loop
				}
			} //fps loop
		}
	} //res loop
	printf("returning \n");
	return 0;
}

//1 = yes low light supported, 0 = no low light not supported
int hawaii_video_is_protune_supported(HAWAII_VIDEO *cur_res_structure, wchar_t *vm, wchar_t *res, wchar_t *fps, wchar_t *fov)
{
	int fps_num;
	int res_num;
	int fov_num;

	printf("video mode %s \n", vm);
	printf("res %s \n", res);

	res_num = cur_res_structure->num_res;
	printf("total res num %d \n", res_num);

	for (int i = 0; i < res_num; i++)
	{
		if (wcscmp(res, cur_res_structure->res_table[i].res_name) == 0)
		{
			fps_num = cur_res_structure->res_table[i].num_fps;
			printf("total fps num %d for res %s \n", fps_num, res);

			for (int j = 0; j < fps_num; j++)
			{
				if (wcscmp(fps, cur_res_structure->res_table[i].fps_table[j].fps_name) == 0)
				{
					fov_num = cur_res_structure->res_table[i].fps_table[j].num_fov;
					printf("total fov num %d \n", fov_num);

					for (int k = 0; k < fov_num; k++)
					{
						if (wcscmp(vm, HAWAII_STRING_FRONT_NTSC) == 0)
						{
							printf("in NTSC \n");
							if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.ntsc == 1)
							{
								printf("found fov in ntsc \n");
								return cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.protune_support;
							}
						}
						else if (wcscmp(vm, HAWAII_STRING_FRONT_PAL) == 0)
						{
							printf("in PAL");
							if (cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.pal == 1)
							{
								printf("found fov in pal \n");
								return cur_res_structure->res_table[i].fps_table[j].fov_table[k].video_config.capabilities.protune_support;
							}
						}
					} //fov loop
				}
			} //fps loop
		}
	} //res loop
	printf("returning \n");
	return 0;
}

void hawaii_video_get_keys_input(
	wchar_t *model,
	wchar_t *mode,
	wchar_t *res,
	wchar_t *cur_fps, wchar_t *fps, wchar_t **fps_arr, int fps_arr_length,
	wchar_t *fov, wchar_t **fov_arr, int fov_arr_length,
	wchar_t *low_light,
	wchar_t *spot_meter,
	wchar_t *hawaii_video_front_protune,
	wchar_t *hawaii_video_front_protune_wb,
	wchar_t *hawaii_video_front_protune_color,
	wchar_t *hawaii_video_front_protune_iso,
	wchar_t *hawaii_video_front_protune_sharp,
	wchar_t *hawaii_video_front_protune_ev, 
	wchar_t *keys)
{
//	printf("%s \n", __FUNCTION__);
	
	wchar_t *f1_space = malloc(4 * sizeof(wchar_t));
	if (f1_space == NULL)
		exit(EXIT_FAILURE);
	wchar_t *f1 = HAWAII_STRING_BUTTON_MODE_F1;	
	
	wchar_t *f3_space = malloc(4 * sizeof(wchar_t));
	if (f3_space == NULL)
		exit(EXIT_FAILURE);
	wchar_t *f3 = HAWAII_STRING_BUTTON_MENU_F3;	
	
	wchar_t * mode_keys = malloc(15 * sizeof(wchar_t));
	if (mode_keys == NULL)
		exit(EXIT_FAILURE);
	mode_keys[0] = '\0';
	
	wchar_t * res_keys = malloc(34 * sizeof(wchar_t));
	if (res_keys == NULL)
		exit(EXIT_FAILURE);
	res_keys[0] = '\0';

	wchar_t * fps_keys = malloc(20 * sizeof(wchar_t));
	if (fps_keys == NULL)
		exit(EXIT_FAILURE);
	fps_keys[0] = '\0';

	wchar_t * fov_keys = malloc(7 * sizeof(wchar_t));
	if (fov_keys == NULL)
		exit(EXIT_FAILURE);
	fov_keys[0] = '\0';
	
	wchar_t * low_light_keys = malloc(4 * sizeof(wchar_t));
	if (low_light_keys == NULL)
		exit(EXIT_FAILURE);
	low_light_keys[0] = '\0';
	
	wchar_t * spot_meter_keys = malloc(4 * sizeof(wchar_t));
	if (spot_meter_keys == NULL)
		exit(EXIT_FAILURE);
	spot_meter_keys[0] = '\0';

	wchar_t * protune_keys = malloc(100 * sizeof(wchar_t));
	if (protune_keys == NULL)
		exit(EXIT_FAILURE);
	protune_keys[0] = '\0';

	wchar_t * protune_vars_keys;
	protune_vars_keys = L"";

	swprintf(f1_space, 4, L"%s ", f1);
	swprintf(f3_space, 4, L"%s ", f3);
	
	hawaii_video_get_button_pressed_mode(mode, mode_keys);
	hawaii_video_get_button_pressed_res(model, res, res_keys);
	hawaii_video_get_button_pressed_fps(cur_fps, fps, fps_arr, fps_arr_length, fps_keys);
	hawaii_video_get_button_pressed_fov(fov, fov_arr, fov_arr_length, fov_keys);
	hawaii_video_get_button_pressed_low_light(low_light, low_light_keys);
	hawaii_video_get_button_pressed_spot_meter(spot_meter, spot_meter_keys);
    hawaii_video_get_button_pressed_protune(hawaii_video_front_protune, protune_keys);
	/*
	if (wcscmp(protune_keys, HAWAII_STRING_FRONT_PROTUNE_ON) == 0)
	{
		protune_vars_keys = hawaii_video_get_keys_input_protune(hawaii_video_front_protune_wb, 
																hawaii_video_front_protune_color,
																hawaii_video_front_protune_iso,
																hawaii_video_front_protune_sharp,
																hawaii_video_front_protune_ev);
	}
	*/
	//start keys input @Video idle screen
	wcscat(keys, f3_space);
//	printf("keys 1 '%ls' \n", keys);
	wcscat(keys, mode_keys);
//	printf("keys 2 '%ls' \n", keys);
	wcscat(keys, f1_space);
//	printf("keys 3 '%ls' \n", keys);
	wcscat(keys, res_keys);
//	printf("keys 4 '%ls' \n", keys);
	wcscat(keys, f1_space);
//	printf("keys 5 '%ls' \n", keys);
	wcscat(keys, fps_keys);
//	printf("keys 6 '%ls' \n", keys);
	wcscat(keys, f1_space);
//	printf("keys 7 '%ls' \n", keys);
	wcscat(keys, fov_keys);
//	printf("keys 8 '%ls' \n", keys);
	wcscat(keys, f1_space);
//	printf("keys 9 '%ls' \n", keys);
	wcscat(keys, low_light_keys);
//	printf("keys 10 '%ls' \n", keys);
	wcscat(keys, f1_space);
//	printf("keys 11 '%ls' \n", keys);
	wcscat(keys, spot_meter_keys);
//	printf("keys 12 '%ls' \n", keys);
	wcscat(keys, f1_space);
//	printf("keys 13 '%ls' \n", keys);
	wcscat(keys, protune_keys);
//	printf("keys 14 '%ls' \n", keys);
	//if protune is on
//	swprintf(keys, "%s%s", keys, f1_space);
//	swprintf(keys, "%s%s", keys, protune_vars_keys);	

	printf("keys \'%ls\' \n", keys);
	free(f1_space);
	free(f3_space);
	free(mode_keys);
	free(res_keys);
	free(fps_keys);
    free(fov_keys);
	free(low_light_keys);
	free(spot_meter_keys);
	free(protune_keys);
//	printf("%s \t returning \n", __FUNCTION__);
}

void hawaii_video_get_keys_input_protune( wchar_t *hawaii_front_def_protune_wb,
											wchar_t *hawaii_front_def_protune_color,
											wchar_t *hawaii_front_def_protune_iso,
											wchar_t *hawaii_front_def_protune_sharp,
											wchar_t *hawaii_front_def_protune_ev)
{

}

void hawaii_video_get_button_pressed_mode(wchar_t *mode, wchar_t *mem)
{
	printf("%s \t %ls \n", __FUNCTION__, mode);
	int arr_length;

	wchar_t * f2_space = malloc(4 * sizeof(wchar_t));
	if (f2_space == NULL)
		exit(EXIT_FAILURE);

	swprintf(f2_space, 4, L"%s ", HAWAII_STRING_BUTTON_SHUTTER_F2);
	
	arr_length = hawaii_video_get_front_mode_arr_length();

	for (int i = 0; i < arr_length; i++)
	{
		wchar_t * str = hawaii_video_get_front_mode(i);
		if (wcscmp(mode, str) == 0)
		{
			break;
		}
		else
		{
//			swprintf(mem, 4, L"%s%s", mem, f2_space);
			wcscat(mem, f2_space);
		}
	}
//	printf("%s \t returning '%s' \n", __FUNCTION__, mem);
	free(f2_space);	
}

void hawaii_video_get_button_pressed_res(wchar_t *model, wchar_t *res, wchar_t *mem)
{
	printf("%s \t model %ls \t res %ls \n", __FUNCTION__, model, res);

	if (wcscmp(model, HAWAII_STRING_MODEL_BACKDOOR) == 0)
	{
		if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_1080) == 0)
		{
			swprintf(mem, 1, L"");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_1080_S) == 0)
		{
			swprintf(mem, 4, L"F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_960) == 0)
		{
			swprintf(mem, 7, L"F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_720) == 0)
		{
			swprintf(mem, 10, L"F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_720_S) == 0)
		{
			swprintf(mem, 13, L"F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_WVGA) == 0)
		{
			swprintf(mem, 16, L"F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_4K) == 0)
		{
			swprintf(mem, 19, L"F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_2_7K) == 0)
		{
			swprintf(mem, 22, L"F2 F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_1440) == 0)
		{
			swprintf(mem, 25, L"F2 F2 F2 F2 F2 F2 F2 F2 ");
		}
	}
	else if (wcscmp(model, HAWAII_STRING_MODEL_PIPE) == 0)
	{
		if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_1080) == 0)
		{
			swprintf(mem, 1, L"");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_1080_S) == 0)
		{
			swprintf(mem, 4, L"F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_960) == 0)
		{
			swprintf(mem, 7, L"F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_720) == 0)
		{
			swprintf(mem, 10, L"F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_720_S) == 0)
		{
			swprintf(mem, 13, L"F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_WVGA) == 0)
		{
			swprintf(mem, 16, L"F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_4K) == 0)
		{
			swprintf(mem, 19, L"F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_4K_S) == 0)
		{
			swprintf(mem, 22, L"F2 F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_2_7K) == 0)
		{
			swprintf(mem, 25, L"F2 F2 F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_2_7K_S) == 0)
		{
			swprintf(mem, 28, L"F2 F2 F2 F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_2_7K_4_3) == 0)
		{
			swprintf(mem, 31, L"F2 F2 F2 F2 F2 F2 F2 F2 F2 F2 ");
		}
		else if (wcscmp(res, HAWAII_STRING_FRONT_VIDEO_RES_1440) == 0)
		{
			swprintf(mem, 34, L"F2 F2 F2 F2 F2 F2 F2 F2 F2 F2 F2 ");
		}
	}
//	printf("%s \t returning '%s' \n", __FUNCTION__, mem);
}

void hawaii_video_get_button_pressed_fps(wchar_t *cur_fps, wchar_t *to_fps, wchar_t **fps_arr, int fps_length, wchar_t *mem)
{
	printf("%s cur_fps %ls \t to_fps %ls \t fps_length %d \n", __FUNCTION__, cur_fps, to_fps, fps_length);

	sort_string(fps_arr, fps_length);

	wchar_t *f2_space = malloc(4 * sizeof(wchar_t));
	if (f2_space == NULL)
		exit(EXIT_FAILURE);
	int cur_fps_index;
	int found_cur_fps_index = 0;
	int to_fps_index;
	int button_pressed;
	swprintf(f2_space, 4, L"%s ", HAWAII_STRING_BUTTON_SHUTTER_F2);

	if (wcscmp(cur_fps, to_fps) == 0)
		swprintf(mem, 1, L"");
	else
	{
		for (int i = 0; i < fps_length; i++)
		{
//			printf("%s \t index %d \n", __FUNCTION__, i);
			//search for to_fps index
			if (wcscmp(to_fps, fps_arr[i]) == 0)
				to_fps_index = i;

			if (found_cur_fps_index == 0)
			{
				//search for cur_fps index
				if (wcscmp(cur_fps, fps_arr[i]) == 0)
				{
					cur_fps_index = i;
					found_cur_fps_index = 1;
				}
				else if (wcscmp(cur_fps, fps_arr[i]) < 0)
				{
					if (i != (fps_length - 1))
					{
						cur_fps_index = i - 1;
						found_cur_fps_index = 1;
					}
					else if (i == (fps_length - 1))	//has reached the end of array
					{
						cur_fps_index = i;
						found_cur_fps_index = 1;
					}
				}
				else if (wcscmp(cur_fps, fps_arr[i]) > 0)
				{
					if (i == (fps_length - 1))	//has reached the end of array
					{
						cur_fps_index = i;
						found_cur_fps_index = 1;
					}
				}
			}
		}

//		printf("cur_fps_index %d \n", cur_fps_index);
//		printf("to_fps index %d \n", to_fps_index);

		//to get button pressed value
		//formula: abs(cur_fps_index - fps_length) + to_fps_index
		button_pressed = abs(cur_fps_index - fps_length) + to_fps_index;
		if (button_pressed >= fps_length)
			button_pressed -= fps_length;

//		printf("button pressed %d \n", button_pressed);

		for (int i = 0; i < button_pressed; i++)
//						swprintf(mem, 4, L"%s%s", mem, f2_space);
			//			swprintf(mem, 4, L"%s", f2_space);
			wcscat(mem, f2_space);

//		printf("%s returning \t mem '%s' \n", __FUNCTION__, mem);
	}
	free(f2_space);
}

void hawaii_video_get_button_pressed_fov(wchar_t *to_fov, wchar_t **fov_arr, int fov_length, wchar_t *mem)
{
	printf("%s \t fov %ls \t fov_length %d \n", __FUNCTION__, to_fov, fov_length);

	wchar_t *f2_space = malloc(4 * sizeof(wchar_t));
	if (f2_space == NULL)
		exit(EXIT_FAILURE);
	swprintf(f2_space, 4, L"%s ", HAWAII_STRING_BUTTON_SHUTTER_F2);

	for (int i = 0; i < fov_length; i++)
	{
		if (wcscmp(fov_arr[i], to_fov) == 0)
		{
			break;
		}
		else
		{
			wcscat(mem, f2_space);
		}
	}
//	printf("%s \t returning '%s' \n", __FUNCTION__, mem);
	free(f2_space);
}


void hawaii_video_get_button_pressed_low_light(wchar_t *low_light, wchar_t *mem)
{
	printf("%s \t %ls \n", __FUNCTION__, low_light);
	int arr_length;

	wchar_t * f2_space = malloc(4 * sizeof(wchar_t));
	if (f2_space == NULL)
		exit(EXIT_FAILURE);
	swprintf(f2_space, 4, L"%s ", HAWAII_STRING_BUTTON_SHUTTER_F2);

	if (wcscmp(low_light, HAWAII_STRING_FRONT_LOW_LIGHT_NA) == 0)
		return;
	else
	{
		arr_length = hawaii_video_get_front_low_light_arr_length();

		for (int i = 0; i < arr_length; i++)
		{
			wchar_t * str = hawaii_video_get_front_low_light(i);
			if (wcscmp(low_light, str) == 0)
			{
				break;
			}
			else
			{
//				swprintf(mem, 4, L"%s%s", mem, f2_space);
				wcscat(mem, f2_space);
			}
		}
	}
	
//	printf("%s \t returning '%s' \n", __FUNCTION__, mem);
	free(f2_space);
}

void hawaii_video_get_button_pressed_spot_meter(wchar_t *spot_meter, wchar_t *mem)
{
	printf("%s \t %ls \n", __FUNCTION__, spot_meter);
	int arr_length;

	wchar_t * f2_space = malloc(4 * sizeof(wchar_t));
	if (f2_space == NULL)
		exit(EXIT_FAILURE);

	swprintf(f2_space, 4, L"%s ", HAWAII_STRING_BUTTON_SHUTTER_F2);

	arr_length = hawaii_video_get_front_spot_meter_arr_length();

	for (int i = 0; i < arr_length; i++)
	{
		wchar_t * str = hawaii_video_get_front_spot_meter(i);
		if (wcscmp(spot_meter, str) == 0)
		{
			break;
		}
		else
		{
//			swprintf(mem, 4, L"%s%s", mem, f2_space);
			wcscat(mem, f2_space);
		}
	}
//	printf("%s \t returning '%s' \n", __FUNCTION__, mem);
	free(f2_space);
}

void hawaii_video_get_button_pressed_protune(wchar_t *protune, wchar_t *mem)
{
	printf("%s \t %ls \n", __FUNCTION__, protune);
	int arr_length;

	wchar_t * f2_space = malloc(4 * sizeof(wchar_t));
	if (f2_space == NULL)
		exit(EXIT_FAILURE);
	swprintf(f2_space, 4, L"%s ", HAWAII_STRING_BUTTON_SHUTTER_F2);

	arr_length = hawaii_video_get_front_protune_arr_length();

	for (int i = 0; i < arr_length; i++)
	{
		wchar_t * str = hawaii_video_get_front_protune(i);
		if (wcscmp(protune, str) == 0)
		{
			break;
		}
		else
		{
//			swprintf(mem, 4, L"%s%s", mem, f2_space);
			wcscat(mem, f2_space);
		}
	}
//	printf("returning '%s' \n", mem);
	free(f2_space);
}

void hawaii_video_get_button_pressed_protune_white_balance(wchar_t *wb)
{

}

void hawaii_video_get_button_pressed_protune_color(wchar_t *color)
{

}

void hawaii_video_get_button_pressed_protune_iso(wchar_t *iso)
{

}

void hawaii_video_get_button_pressed_protune_sharpness(wchar_t *sharp)
{

}

void hawaii_video_get_button_pressed_protune_ev(wchar_t *ev)
{

}

//GET FRONT VALUES
wchar_t * hawaii_video_get_front_default_mode(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.mode;
}

wchar_t * hawaii_video_get_front_default_res(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.res;
}

wchar_t * hawaii_video_get_front_default_fps(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.fps;
}

wchar_t * hawaii_video_get_front_default_fov(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.fov;
}

wchar_t * hawaii_video_get_front_default_low_light(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.low_light;
}

wchar_t * hawaii_video_get_front_default_spot_meter(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.spot_meter;
}

wchar_t * hawaii_video_get_front_default_protune(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.protune;
}

wchar_t * hawaii_video_get_front_default_protune_white_balance(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.white_balance;
}

wchar_t * hawaii_video_get_front_default_protune_color(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.color;
}

wchar_t * hawaii_video_get_front_default_protune_iso(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.iso;
}

wchar_t * hawaii_video_get_front_default_protune_sharpness(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.sharpness;
}

wchar_t * hawaii_video_get_front_default_protune_ev(HAWAII_VIDEO_DEFAULTS_FRONT_REAR *model)
{
	return model->front.ev;
}