#include "hawaii_common.h"

#define HAWAII_STRING_MODEL_PIPE L"PIPE"

wchar_t * hawaii_get_model_name_pipe();

HAWAII_VIDEO *hawaii_video_get_pipe_res_structure();
HAWAII_VIDEO * hawaii_piv_get_pipe_res_structure();
HAWAII_VIDEO * hawaii_video_timelapse_get_pipe_res_structure();
HAWAII_VIDEO_DEFAULTS_FRONT_REAR *hawaii_video_get_pipe_defaults_structure();