void sort_string(wchar_t **fps_arr, int last);
