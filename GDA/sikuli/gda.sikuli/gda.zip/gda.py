
import java.lang.System
import java
import sys
import os
import shutil
from time import strftime
from sikuli import *
from __builtin__ import True, False

import org.sikuli.basics.SikulixForJython
import org.sikuli.script.ImagePath
#autogda00@gmail.com
#access4auto=gmail.com
#autogda00 = gopro account
#import HelperLib
#from guide import *
failcount=0
failexit=3
gda_settings={}
startupcnt=0
##########################################
#
##########################################
def getdatetime():
    return strftime("%Y%m%d_%H%M%S")
##########################################
#
##########################################
def gettime():
    return strftime("%H:%M:%S")
##########################################
#
##########################################
def log(info):
    print(getdatetime()+" "+info)

##########################################
# passfail 1=fail, 0=pass,-1 error, status
##########################################
def reportstatus(passfail,testinfo):
    global failcount
    global failexit
    
    if passfail==0:
        print "=========================================="
        log( "PASSED: " + testinfo)
        print "=========================================="
        failcount = 0
    elif passfail==1:
        print "******************************************"
        log( "FAILED: " + testinfo)
        print "******************************************"
        failcount += 1
    elif passfail==-1:
        print "###########################################"
        log( "ERROR: " + testinfo)
        print "###########################################"
        failcount += 1
    else:
        print "------------------------------------------"
        log("STATUS: " + testinfo)
        #print "STATUS: " + testinfo
        print "------------------------------------------"

    if failcount>failexit:
        print "###########################################"        
        log( "Aborting Test Run: Too many subsequent fails")
        print "###########################################"        
        exit(1)

##########################################
#
##########################################
def PATTERN(image):
#    SmartyLib.Log("SmartyLib.PATTERN:"+str(image) )
    return Pattern(image).similar(Pattern_Similar_Value)
    
##########################################
#
##########################################
def refreshregion(GP):
    GP.focus()
    r0 = GP.focusedWindow()
    if not r0:
        print "Failed: Window region not found"
        return None
    else:
        r0.highlight(1)
        return r0
    
##########################################
#
##########################################
def setsettings(name,data,dtype = ""):
    if not data:
        print " No data"
        
    else:
        gda_settings[name]=data
        if dtype=="array":
            print name+"="
            arr = gda_settings[name]       
            for item in arr:
                print "-->"+str(item)
        else:
            print name + "=" + gda_settings[name]

##########################################
#
##########################################
def GetEnvInfo():
    global gda_settings
    print "GetEnvInfo>"
    setsettings("SikuliVersion",Env.getSikuliVersion())
    setsettings("SikuliDataPath",Env.getSikuliDataPath())
    setsettings("isMac",str(Env.isMac()))
    setsettings("isWindows",str(Env.isWindows()))
    setsettings("BundleFolder",getBundleFolder())
    setsettings("ParentPath",getParentPath())
    setsettings("OS",str(Settings.getOS()))
    setsettings("OSVersion",str(Settings.getOSVersion()))
    setsettings("ImagePath",getImagePath(),"array")    
    print "<GetEnvInfo"

    
##########################################
#
##########################################
def getmactitle():
    print "getmactitle"
    cmd = """
    tell application "Finder"
	    activate
	
	    delay 1
        get title of front window
    end tell
    """
    txt = runScript(cmd)
    return txt

##########################################
#
##########################################
def AppStart(appname):
    global gda_settings
    print "openApp>"
    ext=""
    if gda_settings["isWindows"]=="True":
        ext=".exe"
        reportstatus(-2,"WINDOWS:"+gda_settings["OSVersion"])
        
    if gda_settings["isMac"]=="True":
        ext=".app"
        reportstatus(-2,"MAC:"+gda_settings["OSVersion"])
    a1 = App(appname)
    if not a1:
        a1 = openApp(appname+ext)
        print "openApp"
        
        a1 = App(appname)
        if a1:
            if not a1.isRunning():
                waitcount =10
                while not a1.isRunning():
                    waitcount = waitcount - 1
                    if waitcount == 0:
                        print "failed startup timeout"
                        exit(1)
                    wait(1)
        else:
            print "App " + appname + " failed to startup"
            exit(1)
    wait(5)
    a1.focus()
    wait(2)
    r0 = a1.focusedWindow()
    if not r0:
        print "Failed: Window region not found"
        exit(1)
        
    r0.highlight(1)
    print "<openApp"
    return a1, r0



##########################################
#
##########################################
def Test_Welcome(r0):
    

    #wait("GoProDesktopApp_GPLogo.png").find("Welcome_GDA_Title.png")
    r1 = r0.find("Welcome_getstarted.png")
    r1.find("GoproLogo.png")

    r1.find("Welcome GDA.png")
    r1.find("Welcome_Manage.png")
    r1.find("Welcome_Edit.png")
    r1.find("Welcome_Share.png")

    r2 = r1.find(Pattern("Welcome_AutoLaunch.png").similar(0.80))
    # enable
    r2.find(Pattern("Welcome_UnChecked_AutoLaunch.png").similar(0.90)).click("Welcome_Unchecked_btn.png")

    # disable
    r2.find(Pattern("Welcome_UnChecked_AutoLaunch.png").similar(0.90)).click("Welcome_Checked_btn.png")

    r1.click("Welcome_GetStarted_btn.png")

    
##########################################
#
##########################################
def CLICK(REGION, PATTERN,sleeep=1):
    n = REGION.click(PATTERN)
    if n>0:
		reportstatus(0,"CLICK:"+PATTERN.getFilename())
    else:
		reportstatus(1,"CLICK:"+PATTERN.getFilename())
    	
    wait(sleeep)
    
##########################################
#
##########################################
def Click_Verify(REGION, PATTERN1,PATTERN2,timeout=10,sleeep=1):
	CLICK(REGION,PATTERN1)
	wait(sleeep)
	WAIT(REGION,PATTERN2,timeout)
	wait(sleeep)
    
##########################################
#
##########################################
def FIND(REGION,PATTERN,sleeep=1):
    
    if REGION.find(PATTERN).highlight(1):
        reportstatus(0,"FIND:"+PATTERN.getFilename())
    else:
        reportstatus(1,"FIND:"+PATTERN.getFilename())    
    wait(sleeep)
    
##########################################
#
##########################################
def WAIT(REGION,PATTERN,timeout=10,sleeep=1):
    if REGION.wait(PATTERN,timeout).highlight(1):
        reportstatus(0,"WAIT:"+PATTERN.getFilename())
    else:
        reportstatus(1,"WAIT:"+PATTERN.getFilename())

    wait(sleeep)
##########################################
#
##########################################
def TYPE(REGION,PATTERN,txt,sleeep=1):
    if txt:
        if REGION.type(PATTERN,txt)>0:
            reportstatus(0,"TYPE:"+txt+" "+PATTERN.getFilename())
        else:
            reportstatus(1,"TYPE:"+txt+" "+PATTERN.getFilename())
    	wait(sleeep)
    
##########################################
#
##########################################
def signout(region):

    try:     
        CLICK(region,Pattern("signout_tool.png").similar(0.90).targetOffset(14,2))
        CLICK(region,Pattern("signout_signout.png").similar(0.90).targetOffset(-24,-8))
    except:
        print "Sign Out not found"
        

##########################################
#
##########################################
def signin_validate(region):
    try:
        WAIT(region,Pattern("signin_logo.png").similar(0.90),10)
    except:
        print "sign in not found"
        signout(region)

    WAIT(region,Pattern("signin_logo.png").similar(0.90),30)
    
    FIND(region,Pattern("signin_form.png").similar(0.90))
    
    FIND(region,Pattern("signin_email.png").similar(0.90).targetOffset(-169,29))
    
    FIND(region,Pattern("signin_pw.png").similar(0.90).targetOffset(-199,-39))
    
    FIND(region,Pattern("signin_needAccountJoinNow.png").similar(0.90).targetOffset(63,2))
    
    FIND(region,Pattern("signin_forgotpw.png").similar(0.90).targetOffset(1,19))
    
    FIND(region,Pattern("signin_resendConfirmation.png").similar(0.90).targetOffset(-3,14))

    FIND(region,Pattern("signin_signin.png").similar(0.90))
    
    
##########################################
#
##########################################
def signin_Login(region,login,pw):

    TYPE(region,Pattern("signin_email.png").similar(0.90).targetOffset(-169,29),login)

    TYPE(region,Pattern("signin_pw.png").similar(0.90).targetOffset(-199,-39),pw)
    
    CLICK(region,Pattern("signin_signin.png").similar(0.90))
    
    WAIT(region,Pattern("getstarted_getstartedWithGP.png").similar(0.90),15)

##########################################
#
##########################################
def getstarted_validate(region):
    FIND(region,Pattern("getstarted_choosefolder.png").similar(0.90).targetOffset(0,96))

    FIND(region,Pattern("getstarted_connectcamera.png").similar(0.90).targetOffset(-3,94))    

    FIND(region,Pattern("getstarted_title.png").similar(0.91))

    # selected
    FIND(region,Pattern("media_selected.png").similar(0.90))
    #assumes first time login
    CLICK(region,Pattern("popup_mediafolderindex.png").similar(0.90).targetOffset(141,0))

    CLICK(region,"getstarted_addmedia2.png")
    
    CLICK(region,Pattern("dialogFindGPMedia_Cancel.png").similar(0.90).targetOffset(-15,7))

    CLICK(region,Pattern("recentadd_unselected.png").similar(0.90))
    # selected
    WAIT(region,Pattern("recentadd_select.png").similar(0.90),5)  

    CLICK(region,Pattern("media_unselected.png").similar(0.90))

    WAIT(region,Pattern("media_selected.png").similar(0.90),5)
    
##########################################
#
##########################################
def addmedia_validate(region):
    CLICK(region,Pattern("getstarted_choosefolder.png").similar(0.90).targetOffset(0,96))
    
    WAIT(region,Pattern("dialogFindGPMedia_Title.png").similar(0.90),10)
      
    FIND(region,Pattern("dialogFindGPMedia_ChooseFolders.png").similar(0.90))
      
    CLICK(region,Pattern("dialogFindGPMedia_Addfolder.png").similar(0.90).targetOffset(-6,-19))
    
    #assume the dialog pops up over the GoPro region
    #WAIT(region,Pattern("osxdialog_filedialog.png").similar(0.90).targetOffset(40,2))
    #wait(1)    
    #region.waitVanish(Pattern("osxdialog_filedialog.png").similar(0.90).targetOffset(40,2),5)
    type(Key.ENTER)

    wait(1)

    CLICK(region,Pattern("dialogFindGPMedia_Addfolder.png").similar(0.90).targetOffset(0,37))
    

    CLICK(region,Pattern("GPSettings_seconditem.png").similar(0.90).targetOffset(43,17))
    
    CLICK(region,Pattern("dialogYsure_Remove.png").similar(0.90))
    

    CLICK(region,Pattern("GPSettings_BackToMedia.png").similar(0.90).targetOffset(-29,-30))
    
    # region.click(Pattern("dialogFindGPMedia_Cancel.png").similar(0.90).targetOffset(-15,7))

def startup(region):
   
    #######################################
    ###  firststartup    
    #
    WAIT(region,Pattern("startup_title.png").similar(0.91))
    
    FIND(region,Pattern("startup_logo.png").similar(0.90))

    FIND(region,Pattern("startup_importmedia.png").similar(0.91))

    FIND(region,Pattern("startup_findmoments.png").similar(0.90))

    FIND(region,Pattern("startup_happycam.png").similar(0.90))
    
    CLICK(region,Pattern("startup_autoLaunchCamOnGP.png").similar(0.90))

    CLICK(region,Pattern("startup_unslectedAutoLaunchGP.png").similar(0.91))


    CLICK(region,Pattern("startup_continue.png").similar(0.90))

def startup_newAcct(region):
    WAIT(region,Pattern("startupCreateAcct_title.png").similar(0.91))

    FIND(region,Pattern("startupCreateAcct_form1.png").similar(0.90))

    FIND(region,Pattern("startupCreateAcct_form2.png").similar(0.91))
    
    FIND(region,Pattern("startupCreateAcct_form3.png").similar(0.90))

    CLICK(region,Pattern("startupCreateAcct.png").similar(0.90))
    
 
    
    
##########################################
#
##########################################
def imagelist():
	find("startup_img_logo.png")
	find("startup_txt_title.png")
	find("startup_img_importmedia.png")
	find("startup_img_findmoments.png")
	find("startup_img_camhappy.png")
	find("startup_checked_autolaunchcam.png")
	find("startup_unchecked_autolaunchcam.png")
	find("startup_btn_continue.png")

	find("createacct_txt_title.png")
	find("createacct_txt_subtitle.png")
	find("createacct_txtbox_email.png")
	find("createacct_txtbox_password.png")
	find("createacct_checked_getnews.png")
	find("createacct_unchecked_getnews.png")
	find("createacct_checked_iacknowledge.png")
	find("createacct_unchecked_iacknowledge.png")
	find("createacct_btn_getacct.png")
	find("createacct_btn_signin.png")

	find("signin_img_logo.png")
	find("signin_txt_title.png")
	find("signin_txtbox_emailpw.png")
	find("signin_btn_signin.png")
	find("signin_btn_forgot.png")
	find("signin_btn_resendemail.png")
	find("signin_btn_needacct.png")

    #######################################
    ###  signin
    
    find(Pattern("signin_logo.png").similar(0.90))
    
    find(Pattern("signin_form.png").similar(0.90))
    
    find(Pattern("signin_email.png").similar(0.90).targetOffset(-169,29))
    
    find(Pattern("signin_pw.png").similar(0.90).targetOffset(-199,-39))
    
    find(Pattern("signin_needAccountJoinNow.png").similar(0.90).targetOffset(63,2))
    
    find(Pattern("signin_forgotpw.png").similar(0.90).targetOffset(1,19))
    
    find(Pattern("signin_resendConfirmation.png").similar(0.90).targetOffset(-3,14))

    find(Pattern("signin_signin.png").similar(0.90))
  
    #######################################
    ###  getstarted  
    find(Pattern("getstarted_getstartedWithGP.png").similar(0.90))
    
    find(Pattern("getstarted_connectcamera.png").similar(0.90).targetOffset(-3,94))

    find(Pattern("getstarted_choosefolder.png").similar(0.90).targetOffset(0,96))

    #######################################
    ###  dialogFindGPMedia  
    
    find(Pattern("dialogFindGPMedia_Title.png").similar(0.90))
    
    find(Pattern("dialogFindGPMedia_ChooseFolders.png").similar(0.90))
    
    click(Pattern("dialogFindGPMedia_Addfolder.png").similar(0.90).targetOffset(-6,-19))

    find(Pattern("osxdialog_filedialog.png").similar(0.90).targetOffset(40,2))
    
    find(Pattern("dialogFindGPMedia_Cancel.png").similar(0.90).targetOffset(-15,7))


    #######################################
    ###  createacct  


    find(Pattern("signin_logo.png").similar(0.90))
    
    find("createacct_title.png")

    find("createacct_form.png")

    find("createacct_forgot_resend.png")

    
    #######################################
    ###  connectcam     
    
    find(Pattern("connectcam_title.png").similar(0.90))

    find(Pattern("connectcam_info.png").similar(0.90))

    find(Pattern("connectcam_gotit.png").similar(0.90).targetOffset(7,-16))

    #######################################
    ###  media
    #unselected
    find(Pattern("media_unselected.png").similar(0.90))
    # selected
    find(Pattern("media_selected.png").similar(0.90))

    

    #######################################
    ###  recentadd
    #unselected
    find(Pattern("recentadd_unselected.png").similar(0.90))
    # selected
    find(Pattern("recentadd_select.png").similar(0.90))

    find(Pattern("recentadd_title.png").similar(0.90))
    

    #######################################
    ###  edits
    #unselected
    find(Pattern("edits_unselected.png").similar(0.90))
    # selected
    find(Pattern("edits_selected.png").similar(0.90))
    
    find(Pattern("edits_title.png").similar(0.90))

    find(Pattern("edits_createedit.png").similar(0.91))

    
    find(Pattern("edits_screentxt.png").similar(0.90))
    

    

    #######################################
    ###  gensettings    
    #unselected
    find(Pattern("densettings_unselected.png").similar(0.90))
    
    # selected
    
    find(Pattern("gensettings_selected.png").similar(0.90)) 

    find(Pattern("gensettings_title.png").similar(0.90))
    
    find(Pattern("gensettings_import.png").similar(0.90))

    find(Pattern("gensettings_media.png").similar(0.90))

    find(Pattern("gensettings_addnew.png").similar(0.90))

    find(Pattern("gensettings_options.png").similar(0.90))
    
    
    
 
    #######################################
    ###  camsettings    
    #unselected
    find(Pattern("camsettings_unselected.png").similar(0.90))
    # selected
    find(Pattern("camsettings_selected.png").similar(0.90))

    find(Pattern("camsettings_title.png").similar(0.90))
    find(Pattern("camsettings_title2.png").similar(0.90))
    
    
    #######################################
    ###  firststartup    
    #
    find(Pattern("startup_title.png").similar(0.91))
    
    find(Pattern("startup_logo.png").similar(0.90))

    find(Pattern("startup_importmedia.png").similar(0.90))

    find(Pattern("startup_findmoments.png").similar(0.90))

    find(Pattern("startup_happycam.png").similar(0.90))
    
    click(Pattern("startup_autoLaunchCamOnGP.png").similar(0.90))
    click(Pattern("startup_unslectedAutoLaunchGP.png").similar(0.90))
    

    click(Pattern("startup_continue.png").similar(0.90))

    #######################################
    ###  firststartup create account    
    #
    wait(Pattern("startupCreateAcct_title.png").similar(0.90))

    find(Pattern("startupCreateAcct_form1.png").similar(0.90))

    find(Pattern("startupCreateAcct_form2.png").similar(0.91))
    
    find(Pattern("startupCreateAcct_form3.png").similar(0.90))

    click(Pattern("startupCreateAcct.png").similar(0.90))
    
    wait(Pattern("popup_mediafolderindex.png").similar(0.90))
	
    
    
    
    
##########################################
#
##########################################
def BAT(gp,gpr):
    global startup
    gpr=refreshregion(gp)
    if startupcnt == 0:
        startup(gpr)
        gpr=refreshregion(gp)
        startup_newAcct(gpr)
        startup=1
    gpr=refreshregion(gp)    
    signin_validate(gpr)    
    gpr=refreshregion(gp)
    signin_Login(gpr,"autogda00@gmail.com","autogda00")
    gpr=refreshregion(gp)
    startup=1
    getstarted_validate(gpr)
    gpr=refreshregion(gp)
    addmedia_validate(gpr)
    signout(gpr)    

##########################################
# main script
##########################################

GetEnvInfo()
gp,gpr=AppStart("GoPro")
if not gp:
    print "AppStart Failed"
    exit(1)
gp.focus()
setsettings("getWindow",gp.getWindow())
#setsettings("PID",gp.getPID())
#setsettings("getName",gp.getName())
BAT(gp,gpr)
#BAT(gp,gpr)
#BAT(gp,gpr)

