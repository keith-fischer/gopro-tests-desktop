#!/usr/bin/python
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
# File: SmartServer.py
# Description: A server that provides an API for sending and receiving
#              messages from it
# Author: Sean Foley
# Date Created: 23 May 2015
#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#=#
"""
How to use a SmartServer:

For Servers:
  1. Import this file
  2. Declare a new SmartServer
  3. Register a message handler, which is a reference to a method that
     takes processes all messages sent to the server and returns a string
     response to the client.
  4. Start the server
  5. Make some clients, do stuff with server
  6. Stop the server

  Example:
    import SmartServer

    def messageHandler(msg):
      return "%s received" % msg

    server = SmartServer()
    server.registerMessageHandler(messageHandler)
    server.start()

    # Make some clients, do stuff with server

    server.stop()


For Clients:
  0. Assumption: A server is already running
  1. Import this file
  2. Use static methods in SmartServer to get a socket & connect to the server
  3. Send messages to the server as many times as you like
  4. Disconnect from the server

  Example:
    import SmartServer

    client = SmartServer.connectToServer()

    for i in range(10):
      response = client.sendMessageAndGetResponse( str(i) )
      print "Response: %s" % response

    SmartServer.disconnectFromServer(client)

"""

import ast        # for ast.literal_eval
import errno      # for error checking values
import os         # for os.path.exists and os.remove
import random     # for random.randint
import select     # for monitoring sockets in a non-blocking way using select
import socket     # for network programming!
import sys        # for sys.exit
import threading  # for connection manager, client handlers
import time       # for sleep
import traceback  # for printing exceptions

from optparse import OptionParser  # for easy/fancy commandline parsing

# Set to True to enable logging for debugging purposes
DEBUG_LOGGING_ENABLED = True


#==============================================================================
# Global library functions
#==============================================================================
#--------------------------------------------------------------------------
# Method: sendMessage
# Input conn: A non-blocking socket that is connected to a client/server
# Optional Input callerName: A unique name given by the calling method
#                            (used for debugging)
# Postcondition: The method has called [socket].send until all of msg
#                was sent over the socket
# Returns: True if send was successful or False otherwise
#--------------------------------------------------------------------------
def sendMessage(conn, msg, callerName="Not specified"):

    # Prepend the length of the message and delimit it from the rest
    # of the message so the receiving end knows how much message to read
    msg = "%d%s%s" % (len(msg), SmartServer.MSG_DELIMITER, msg)

    totalBytesSent = 0
    while (totalBytesSent < len(msg)):
        try:
            bytesSent = conn.send( msg[totalBytesSent:] )
            totalBytesSent += bytesSent
        except socket.error as e:
            err = e.args[0]

            # Socket broke on the other end?
            if (err == "timed out"):
                errStr  = "Warning in receiveMessage:\n"
                errStr += "  Caller: %s\n" % callerName
                errStr += "  Client socket broke or was "
                errStr += "disconnected.\n"
                print errStr

                # QUESTION:
                # Should we close the socket? Or do something else?

                return False

            # Socket resource temporarily  unavailable
            elif (err == errno.EWOULDBLOCK) or (err == errno.EAGAIN):
                continue

            else:
                print "Error in sendMessage:"
                print "  Exception occurred while trying to send message."
                print "  Caller: %s" % callerName
                traceback.print_exc()
                return False

    # Everything went well
    return True


#--------------------------------------------------------------------------
# Method: receiveMessage
# Input conn: A non-blocking socket that is connected to a client/server
# Optional Input callerName: A unique name given by the calling method
#                            (used for debugging)
# Postcondition: The method has run select on a socket and, if there is
#                data to read, has read all of it and returned the
#                completed message
#--------------------------------------------------------------------------
def receiveMessage(conn, callerName="Not specified"):
    readableFds  = [conn]
    writeableFds = []
    errorFds     = [conn]
    timeout      = 1  # seconds

    readFds,writeFds,errFds = select.select(readableFds,
                                                writeableFds,
                                                errorFds,
                                                timeout)

    # If there are no readable sockets, go back to waiting
    if (len(readFds) + len(errFds) == 0):
        return None

    # One of the sockets has an error
    if (len(errFds) > 0):
        print "Error in receiveMessage:"
        print "  Socket returned an error. Hmmm, what to do?"
        return None

    # Hooray! There is something to read on the socket!
    if (len(readFds) > 0):
        msg       = ""
        msgLength = None
        chunk     = None

        # Read the message from the socket into msg
        while (msgLength is None) or (len(msg) < msgLength):
            try:
                chunk = conn.recv(SmartServer.MAX_MSG_SIZE)
            except socket.error as e:
                err = e.args[0]

                # Socket broke on the other end?
                if (err == "timed out"):
                    errStr  = "Warning in receiveMessage:\n"
                    errStr += "  Caller: %s\n" % callerName
                    errStr += "  Client socket broke or was "
                    errStr += "disconnected.\n"
                    print errStr

                    # QUESTION:
                    # Should we close the socket? Or do something else?

                    return None

                # Socket resource temporarily  unavailable
                elif (err == errno.EWOULDBLOCK) or (err == errno.EAGAIN):
                    continue

                else:
                    errStr  = "\nError in receiveMessage:"
                    errStr += "  Caller: %s\n" % callerName
                    errStr += "  Unexpected socket error (err: %s)\n" % err
                    print errStr
                    traceback.print_exc()
            except:
                print "\nUnexpected error in receiveMessage:"
                traceback.print_exc()

            # Append partial message to msg
            if (len(chunk) > 0):
                if (DEBUG_LOGGING_ENABLED):
                    print "Got some data (%d bytes)!\n" % len(chunk),
                    print "chunk == %s" % chunk
                msg += chunk

                # Determine message length if we don't already know
                if (msgLength is None):

                    # First message should contain the message length and
                    # a delimiter that separates it from the rest of the
                    # message
                    if (SmartServer.MSG_DELIMITER not in msg):
                        print "Error in receiveMessage:"
                        print "  Malformed message."
                        print "  msg==", msg
                        return None

                    # Extract the message length out of the message and then
                    # remove it and the delimiter
                    # try:
                    #     msgLength = int(msg.split(SmartServer.MSG_DELIMITER)[0])
                    # except:
                    #     print "Error in receiveMessage:"
                    #     print "  Cannot extract message length from message."
                    #     print "  msg ==", msg
                    #     return None

                    # Put msg back together without the length & delim fields
                    #msg = "".join(msg.split(SmartServer.MSG_DELIMITER)[1:])

                    if (DEBUG_LOGGING_ENABLED):
                        note = "\n[receiveMessage Debug]:\n"
                        note += "  Caller: %s\n" % callerName
                        note += "  Obtained msg length: %d\n" % len(msg)
                        print note

        # if (DEBUG_LOGGING_ENABLED):
        #     note = "[receiveMessage Debug]:"
        #     note += "  Caller: %s\n" % callerName
        #     note += "  Complete message assembled (length: %d)\n" % (len(msg))
        #     note += "  msg == %s" % msg
        #     print note

        # return the completed message
        return msg


#==============================================================================
# End of library functions
#==============================================================================


#==============================================================================
#
# SmartClient class
# Description: A simple API to make socket-based clients connect to servers
#
#==============================================================================
class SmartClient(object):
    # Static variables (DO NOT MODIFY!)
    HOST         = "127.0.0.1"
    MAX_MSG_SIZE = 4096  # bytes


    #--------------------------------------------------------------------------
    # Static Method: getServerPort
    # Input name: The name of a SmartServer
    # Postcondition: The method has obtained the server's port number based
    #                on its name from a file created by the server when it
    #                was started
    #--------------------------------------------------------------------------
    @staticmethod
    def getServerPort(name):
        filename = "%s.port" % name

        try:
            with open(filename, "r") as f:
                port = int(f.read())
                return int(port)
        except Exception as e:
            if (DEBUG_LOGGING_ENABLED):
                print "Error in SmartServer.getServerPort:"
                print "  Cannot get server's port number from [%s]" % filename
                traceback.print_exc()
            return None


    #--------------------------------------------------------------------------
    # Static Method: connectToServer
    # Postcondition: The method has established a connection to the socket-
    #                based server
    # Returns: A tuple (a,b) such that
    #          a ---> Session ID assigned by the server
    #          b ---> A socket object on which the user can call send
    #                 and recv methods. User is responsible for calling close
    #                 when done.
    #--------------------------------------------------------------------------
    @staticmethod
    def connectToServer(host, port):
        # Retry-after-failed-connection configuration settings
        timeBetweenRetries = 1  # seconds
        maxNumRetries      = 5

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        connectSuccessful = False
        for i in range(maxNumRetries):
            try:
                sock.connect( (host, port) )
                connectSuccessful = True
                break
            except:
                if (DEBUG_LOGGING_ENABLED):
                    print "[SmartClient.connectToServer]",
                    print "Cannot connect to server on port %d." % port,
                    print "Trying again in %d seconds" % timeBetweenRetries,
                    print "(attempt %d of %d)" % (i+1,maxNumRetries)

                time.sleep(timeBetweenRetries)

        if (not connectSuccessful):
            return None

        sessionID = sock.recv(SmartClient.MAX_MSG_SIZE)
        if (DEBUG_LOGGING_ENABLED):
            print "[SmartClient.connectToServer]",
            print "Session %s connected to server on port %d" %(sessionID,port)

        return sock


    #--------------------------------------------------------------------------
    # Static Method: disconnectFromServer
    # Input clientSock: A client socket object
    # Postcondition: The method has closed the client socket
    #--------------------------------------------------------------------------
    @staticmethod
    def disconnectFromServer(clientSocket):
        msg = SmartServer.MSG_GOODBYE
        SmartClient.sendMessageAndGetResponse(clientSocket, msg)
        clientSocket.close()


    #--------------------------------------------------------------------------
    # Static Method: sendMessageAndGetResponse
    # Input sock: A socket object created by SmartServer.connectToServer
    # Input msg: A string containing a message to send to the server
    # Postcondition: The method has sent msg to the SmartServer, waited for
    #                a response and returned the response to the caller
    #--------------------------------------------------------------------------
    @staticmethod
    def sendMessageAndGetResponse(sock, msg):
        # Defensive code
        if (sock is None) or (msg is None):
            return None

        # Prepend the message length so the other end knows how much to
        # read
        success = sendMessage(sock, msg)

        # Did the message get sent ok?
        if (not success):
            print "Error in sendMessageAndGetResponse:"
            print "  sendMessage(sock,msg) call failed"
            return None

        # Wait for a response
        response = None
        while (response is None):
            response = receiveMessage(sock)

        return response


#==============================================================================
# SmartServer class
#==============================================================================
class SmartServer(object):
    # Static variables (DO NOT MODIFY!)
    DEFAULT_PORT       = 8081  # in loving memory of Peter Cavender
    HOST               = "127.0.0.1"
    MAX_MSG_SIZE       = 4096 # bytes
    BIND_RETRY_TIMEOUT = 5               # 5 seconds
    MAX_CONNECTIONS    = 100             # Maximum of 10 simultaneous clients
    MSG_DELIMITER      = "|"       # delim to use b/w len(msg) and msg
    MSG_GOODBYE        = "<<<goodbye>>>" # msg notifying server of disconnect

    # When a SmartServer starts, it tries to use this port.
    # If this port cannot be bound, it will try the next port and the next
    # until it is able to bind one
    BASE_PORT          = 14441  # In loving memory of Peter Cavender
    MAX_PORT           = 65535  # maximum possible TCP port

    # Messages that cause the server to act in certain ways
    MSG_ERROR          = "Error"
    MSG_EXIT           = "Exit"


    #--------------------------------------------------------------------------
    # Thread Class: Thread_ConnectionManager
    # Description: Handles accepting of incoming connections and creating
    #              ClientHandler threads to handle client messages
    #--------------------------------------------------------------------------
    class Thread_ConnectionManager(threading.Thread):
        #----------------------------------------------------------------------
        # Initializer
        # Input port: The port to run the server on
        # Input msgHandler: A method reference for how to handle client msgs
        # Input stopThreadsEvent: An event. If set, stop this thread
        #----------------------------------------------------------------------
        def __init__(self, port, msgHandler, stopThreadsEvent):
            super(SmartServer.Thread_ConnectionManager,self).__init__()

            self.msgHandler        = msgHandler
            self._stopThreadsEvent = stopThreadsEvent
            self.port              = port


        #----------------------------------------------------------------------
        # Start the thread
        #----------------------------------------------------------------------
        def run(self):
            # Create the socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

            # Set socket.SO_REUSEADDR=1 so socket can be reused w/o waiting
            # for timeout
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            # Keep trying to bind the socket until it works
            while (True):
                try:
                    sock.bind( (SmartServer.HOST,self.port) )
                    break
                except:
                    if (DEBUG_LOGGING_ENABLED):
                        print "[ConnectionManager]",
                        print "Cannot bind socket on port %d." % self.port,
                        print "Trying again in",
                        print "%d sec..." % SmartServer.BIND_RETRY_TIMEOUT

                    time.sleep(SmartServer.BIND_RETRY_TIMEOUT)

            if (DEBUG_LOGGING_ENABLED):
                print "[ConnectionManager] Socket bound to port %d" % self.port

            sock.listen(SmartServer.MAX_CONNECTIONS)

            currentSessionID = 1

            # configure select
            readableFds  = [sock]
            writeableFds = []
            errorFds     = [sock]
            timeout      = 1  # seconds

            # Listen for client connections and handle them
            clientThreads = []
            while (True):
                # Stop thread if called to do so & wait for client threads to exit
                if (self._stopThreadsEvent.isSet()):
                    if (DEBUG_LOGGING_ENABLED):
                        print "[ConnectionManager : Stop]: Closing socket..."
                    sock.close()

                    # Wait for all connected-client-threads to return before
                    # continuing
                    if (DEBUG_LOGGING_ENABLED):
                        print "[ConnectionManager : Stop]:",
                        print "Waiting for client threads to return..."
                    for clientThread in clientThreads:
                        clientThread.join()

                    if (DEBUG_LOGGING_ENABLED):
                        print "[ConnectionManager : Stop]:",
                        print "Returning from thread..."
                    return

                # Check for incoming connections
                readFds,writeFds,errFds = select.select(readableFds,writeableFds,errorFds,timeout)

                # Check for socket error
                if (len(errFds) > 0):
                    print "Error in Thread_ConnectionManager.run (Session %s):" % currentSessionID
                    print "  Error occurred during select of socket"
                    sys.exit(1)

                # Readable data on the socket means there's an incoming
                # connection, so let's accept it and spin off a client handler
                # thread
                if (len(readFds) > 0) and (readFds[0] == sock):
                    conn,addr = sock.accept()
                    conn.setblocking(0)

                    # Send client its session ID
                    success = sendMessage(conn, str(currentSessionID))

                    if (not success):
                        print "Error in Thread_ConnectionManager.__init__:"
                        print "  sendMessage(conn,msg) failed."
                        sys.exit(1)

                    # Create a new thread to handle the client
                    clientHandlerThread = SmartServer.Thread_ClientHandler(currentSessionID,conn,addr,self.msgHandler,self._stopThreadsEvent)
                    clientThreads.append(clientHandlerThread)
                    clientHandlerThread.start()

                    currentSessionID += 1


    #--------------------------------------------------------------------------
    # Thread Class: Thread_ClientHandler
    # Description: Class that handles 2-way communication with a single client
    #--------------------------------------------------------------------------
    class Thread_ClientHandler(threading.Thread):
        #----------------------------------------------------------------------
        # Initializer
        # Input sessionID: The unique session ID assoc. with this connection
        # Input conn: XXX
        # Input addr: A tuple of (IP_ADDRESS, ???)
        # Input msgHandler: A method reference for how to handle client msgs
        # Input stopThreadsEvent: An event. If set, stop this thread
        #----------------------------------------------------------------------
        def __init__(self, sessionID, conn, addr, msgHandler, stopThreadsEvent):
            super(SmartServer.Thread_ClientHandler, self).__init__()

            self.sessionID         = sessionID
            self.conn              = conn
            self.addr              = addr
            self.msgHandler        = msgHandler
            self._stopThreadsEvent = stopThreadsEvent


        #----------------------------------------------------------------------
        # Start the thread
        #----------------------------------------------------------------------
        def run(self):
            # Infinite loop:
            #   1. Check if we need to stop thread
            #   2. Wait for message from client
            #   3. Process client's message
            #   4. Respond to client's message
            while (True):
                # Stop thread if necessary
                if (self._stopThreadsEvent.isSet()):
                    if (DEBUG_LOGGING_ENABLED):
                        s  = "[ClientHandler] Stop called. "
                        s += "Session %s thread returning" % self.sessionID
                        print s
                    break

                # Wait for a new message to arrive from the client
                msg = receiveMessage(self.conn, self.sessionID)

                if (msg == None) or (len(msg) == 0):
                    if (DEBUG_LOGGING_ENABLED):
                        print "[Thread_ClientHandler Session %d]: Waiting for message from client..." % self.sessionID
                    break
                print msg

                # # Check for disconnect message
                # if (msg == SmartServer.MSG_GOODBYE):
                #     success = sendMessage(self.conn, SmartServer.MSG_GOODBYE)
                #
                #     if (not success):
                #         print "Error in Thread_ClientHandler.run:"
                #         print "  sendMessage(self.conn, msg) failed."
                #         sys.exit(1)
                #
                #     self.conn.close()
                #
                #     if (DEBUG_LOGGING_ENABLED):
                #         print "[Session: %d]:" % self.sessionID,
                #         print "Received goodbye from client."
                #         print "Shutting down thread."
                #     return

                # Determine how to respond to the message we just received
                response = str( self.msgHandler(msg) )

                # Any errors?
                if (response is None) or (len(response) == 0):
                    print "Error in Thread_ClientHandler.run:"
                    print "  Response has an invalid value: \"%s\"" % response

                # Non-error case
                if (response.lower() == SmartServer.MSG_ERROR):
                    print "\n\n************* MSG_ERROR (%d) ************\n\n" % self.sessionID
                    pass
                elif (response.lower() == SmartServer.MSG_EXIT):
                    print "\n\n************* MSG_EXIT (%d) ************\n\n" % self.sessionID
                    break

                # Send response
                else:
                    success = sendMessage(self.conn, response)

                    if (not success):
                        print "Error in Thread_ClientHandler.run:"
                        print "  sendMessage(self.conn, msg) failed."
                        sys.exit(1)


    #--------------------------------------------------------------------------
    # Initializer
    # Input name: A unique name to give the server
    # Optional Input port: Specify the port number to use for the server
    #--------------------------------------------------------------------------
    def __init__(self, name, port=None):
        # Keep track of all running threads for when stop() is called
        self._stopThreadsEvent = threading.Event()
        self._threads          = []

        self._name       = name
        self._port       = port
        self._msgHandler = None

        # Filename containing the server's port number
        self._portIndicatorFilename = "%s.port" % self._name

        # Temporarily not used because of above temporary logic
        # Set the default port handler in case the user never specifies one
        self._portHandler = self.defaultPortHandler

        if (port is not None):
            self.port = port


    #--------------------------------------------------------------------------
    # Method registerPortHandler
    # Input portHandler: A reference to a method that determines what port the
    #                   server should use and return a corresponding integer
    #--------------------------------------------------------------------------
    def registerPortHandler(self, portHandler):
        self._portHandler = portHandler


    #--------------------------------------------------------------------------
    # Method registerMessageHandler
    # Input msgHandler: A reference to a method that takes a message sent by a
    #                   client, processes it and returns a string for the
    #                   server to return to the client
    #--------------------------------------------------------------------------
    def registerMessageHandler(self,msgHandler):
        self._msgHandler = msgHandler


    #--------------------------------------------------------------------------
    # Method defaultPortHandler
    # Postcondition: The method has returned the first open port number
    #                between SmartServer.BASE_PORT and SmartServer.MAX_PORT
    #--------------------------------------------------------------------------
    def defaultPortHandler(self):
        port = SmartServer.BASE_PORT
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        while (True):
            try:
                sock.bind( (SmartServer.HOST, port) )
                sock.close()
                return port
            except:
                if (DEBUG_LOGGING_ENABLED):
                    print "Unable to bind port %d." % port,
                    print "Trying port %d..." % (port+1)

                port += 1

                if (port > SmartServer.MAX_PORT):
                    print "Error in SmartServer.start:"
                    print "  Cannot bind any ports between",
                    print "%d and" % SmartServer.BASE_PORT,
                    print "%d" % SmartServer.MAX_PORT
                    sys.exit(1)


    #--------------------------------------------------------------------------
    # Method: start
    # Postcondition: The method has started the server (i.e. create & bind
    #                socket and start accepting connections.
    #                Each new connection spawns a thread to handle 2-way
    #                communication
    #--------------------------------------------------------------------------
    def start(self):
        if (self._port is None):
            self._port = self._portHandler()

        if (self._msgHandler is None):
            print "Error in SmartServer.start:"
            print "  Message handler is not set. Please call"
            print "  registerMessageHandler() before starting server"
            serverStarted = False
        else:
            # Start the thread that handles incoming connections
            self.connectionManager = SmartServer.Thread_ConnectionManager(
                self._port,
                self._msgHandler,
                self._stopThreadsEvent)
            self.connectionManager.start()

            # Try to connect a client to the server before declaring the server
            # to be running
            numRetries = 12
            timeBetweenRetries = 0.25  # seconds

            for i in range(numRetries):
                testClient = SmartClient.connectToServer(SmartServer.HOST,
                                                         self._port)

                if (testClient is not None):
                    SmartClient.disconnectFromServer(testClient)
                    break
                else:
                    time.sleep(timeBetweenRetries)

            if (DEBUG_LOGGING_ENABLED):
                print "[SmartServer] Server started"

            serverStarted = True

            # Write the port number to a hidden file
            try:
                f = open(self._portIndicatorFilename, "w")
                f.write(str(self._port))
            except Exception as e:
                print "Error in SmartServer.start:"
                print "  Unable to write port to [%s]" % self._portIndicatorFilename
                traceback.print_exc()
                sys.exit(1)
            finally:
                f.close()

        return serverStarted


    #--------------------------------------------------------------------------
    # Method: stop
    # Postcondition: The method has triggered events in all running threads,
    #                telling them to exit after they finish their current
    #                loop iteration
    #--------------------------------------------------------------------------
    def stop(self):
        self._stopThreadsEvent.set()

        # Wait for connection manager thread to stop (which waits for all of
        # its client threads to return before returning)
        self.connectionManager.join()

        # Delete the hidden file indicating the server's port
        if (os.path.exists(self._portIndicatorFilename)):
            os.remove(self._portIndicatorFilename)

        # Clear the stop event
        self._stopThreadsEvent.clear()


    #--------------------------------------------------------------------------
    # Getter Method: getName
    #--------------------------------------------------------------------------
    def getName(self):
        return self._name


# End of SmartServer definition


#==============================================================================
#
# A u t o m a t e d   U n i t   T e s t i n g
#
#==============================================================================
#------------------------------------------------------------------------------
# Unit Test 1
# Test: Create a SmartServer and register a message handler
# Pass Criteria: No errors occur
# Returns: True if test passed, False otherwise
#------------------------------------------------------------------------------
def performUnitTest1():
    def messageHandler(): return None

    # Perform the test
    try:
        server1 = SmartServer("unitTest1ServerA", 14441)
        server2 = SmartServer("unitTest1ServerB")

        server1.registerMessageHandler(messageHandler)
        server2.registerMessageHandler(messageHandler)

        testResultStr = "PASS"
    except:
        testResultStr = "FAIL"

    # Print summary
    print "[Unit Test 1] Instantiate a SmartServer [%s]" % testResultStr

    # Return result
    if (testResultStr == "PASS"):
        return True
    else:
        return False


#------------------------------------------------------------------------------
# Unit Test 2
# Test: Create a SmartServer, connect one client to it and send N messages
#       from the client to the server.
# Pass Criteria: Messages returned from the server are what we expect based
#                on the definition of the registered mesage handler
# Returns: True if test passed, False otherwise
#------------------------------------------------------------------------------
def performUnitTest2():
    # Inner Method: Defines how to handle messages sent to the server
    def unitTest2MessageHandler(msg): return msg

    # Create the server, start it, and give it a moment to get setup
    serverName = "UnitTest2Server"
    server     = SmartServer(serverName)
    server.registerMessageHandler(unitTest2MessageHandler)
    server.start()

    # Setup the client socket and connect to the server
    client = SmartClient.connectToServer(SmartServer.HOST,
                                            SmartServer.DEFAULT_PORT)

    # Run the test
    messages  = ["This", "is", "Unit", "Test", "1"]
    responses = []
    numMessagesToSend = len(messages)

    for message in messages:
        response = SmartClient.sendMessageAndGetResponse(client,message)
        responses.append(response)

    SmartClient.disconnectFromServer(client)
    server.stop()

    # Did the test pass?
    testResultStr = "PASS" if (messages == responses) else "FAIL"

    # Print test status
    print "[Unit Test 2]",
    print "Client sends server %d messages and gets" % numMessagesToSend,
    print "expected responses [%s]" % testResultStr

    # Return result
    if (testResultStr == "PASS"):
        return True
    else:
        return False


#------------------------------------------------------------------------------
# Unit Test 3
# Test: Create a SmartServer and N clients, all of which send messages to the
#       server ~simultaneously using threads
# Pass Criteria: Messages returned from the server are what we expect based
#                on the definition of the registered mesage handlers for each
#                server
# Returns: True if test passed, False otherwise
#------------------------------------------------------------------------------
unitTest3ResultsLock = threading.Lock()
unitTest3Results     = []
unitTest3ServerName  = "UnitTest3Server"
unitTest3NumClients  = 10
unitTest3NumMessages = 1000


class Thread_UnitTest3Client(threading.Thread):
    def __init__(self, clientName, port, numMsgToSend, results, resultsLock):
        super(Thread_UnitTest3Client,self).__init__()

        self.clientName   = clientName
        self.port         = port
        self.numMsgToSend = numMsgToSend
        self.results      = results       # where to store results
        self.resultsLock  = resultsLock

    def run(self):
        testFailed = False
        client = SmartClient.connectToServer(SmartServer.HOST,self.port)

        for i in range(0,self.numMsgToSend):
            message  = "msg%d from %s" % (i, self.clientName)
            response = SmartClient.sendMessageAndGetResponse(client,message)
            testFailed = True if (message != response) else False

        if (DEBUG_LOGGING_ENABLED):
            print "[UnitTest3Client %s]" % self.clientName,
            print "Finished sending messages. Disconnecting from server."

        SmartClient.disconnectFromServer(client)

        testResultStr = "FAIL" if (testFailed) else "PASS"

        self.resultsLock.acquire()
        self.results.append(testResultStr)
        self.resultsLock.release()


def performUnitTest3():
    # Define message handlers for each server
    def unitTest3MessageHandler(msg): return msg

    # Create the server and give it a moment to start
    server = SmartServer(unitTest3ServerName)
    server.registerMessageHandler(unitTest3MessageHandler)
    server.start()

    clientThreads     = []
    port = SmartClient.getServerPort(unitTest3ServerName)

    # Start the client threads
    for i in range(unitTest3NumClients):
        clientThread = Thread_UnitTest3Client(str(i),
                                                port,
                                                unitTest3NumMessages,
                                                unitTest3Results,
                                                unitTest3ResultsLock)
        clientThreads.append(clientThread)
        clientThread.start()

    # Wait for all the threads to finish before continuing
    for i in range(unitTest3NumClients):
        clientThreads[i].join()

    server.stop()

    # Determine test result
    unitTest3ResultsLock.acquire()
    results       = [x for x in unitTest3Results]
    testResultStr = "PASS" if ("FAIL" not in results) else "PASS"
    unitTest3ResultsLock.release()

    # Print test result
    print "[Unit Test 3] %d clients" % unitTest3NumClients,
    print "each send %d messages to server" % unitTest3NumMessages,
    print "simultaneously and get expected responses [%s]" % testResultStr

    if (testResultStr == "PASS"):
        return True
    else:
        return False


#------------------------------------------------------------------------------
# Unit Test 4
# Test: 1. Create X SmartServers.
#       2. Create Y clients for each SmartServer
#       3. Each client sends its server N messages simultaneously
# Pass Criteria: Messages returned from servers are as expected based on the
#                definition of the registered message handlers for each server
# Returns: True if test passed, False otherwise
#------------------------------------------------------------------------------
unitTest4NumServers     = 10
unitTest4NumClients     = 5
unitTest4NumMessages    = 500
unitTest4BaseServerName = "UnitTest4Server"
unitTest4Results        = []
unitTest4ResultsLock    = threading.Lock()


def performUnitTest4():
    # Define message handlers for each server
    def unitTest4MessageHandler(msg): return msg

    # database of servers and corresponding clients
    db = {}

    # Create & start servers
    for i in range(unitTest4NumServers):
        serverName = "%s%d" % (unitTest4BaseServerName, i)
        server     = SmartServer(serverName)
        server.registerMessageHandler(unitTest4MessageHandler)
        server.start()

        port = SmartClient.getServerPort(serverName)

        # Prepare clients for this server
        clientThreads = []
        for j in range(unitTest4NumClients):
            clientThread = Thread_UnitTest3Client(str(j),
                                                    port,
                                                    unitTest4NumMessages,
                                                    unitTest4Results,
                                                    unitTest4ResultsLock)
            clientThreads.append(clientThread)

        db[serverName] = (server,clientThreads)

    # Start the client threads for each server
    for serverName in db:
        clientThreads = db[serverName][1]
        for clientThread in clientThreads:
            clientThread.start()

    # wait for all the threads to finish
    for serverName in db:
        clientThreads = db[serverName][1]
        for clientThread in clientThreads:
            clientThread.join()

    # Stop all the servers
    for serverName in db:
        server = db[serverName][0]
        server.stop()

    # Determine test result
    unitTest4ResultsLock.acquire()
    results       = [x for x in unitTest4Results]
    testResultStr = "PASS" if ("FAIL" not in results) else "PASS"
    unitTest4ResultsLock.release()

    # Print test result
    print "[Unit Test 4] %d servers with" % unitTest4NumServers,
    print "%d clients each," % unitTest4NumClients,
    print "process %d messages all simultaneously" % unitTest4NumMessages,
    print "[%s]" % testResultStr

    if (testResultStr == "PASS"):
        return True
    else:
        return False


#------------------------------------------------------------------------------
# Unit Test 5
# Test: Create a SmartServer, connect one client to it and send one really
#       long message to it
# Pass Criteria: Message returned from the server is the same as the message
#                sent
# Returns: True if test passed, False otherwise
#------------------------------------------------------------------------------
def performUnitTest5():
    # Inner Method: Defines how to handle messages sent to the server
    def unitTest5MessageHandler(msg): return msg

    # Create the server, start it, and give it a moment to get setup
    serverName = "UnitTest5Server"
    server     = SmartServer(serverName)
    server.registerMessageHandler(unitTest5MessageHandler)
    server.start()

    # Setup the client socket and connect to the server
    client = SmartClient.connectToServer(SmartServer.HOST,
                                            SmartServer.DEFAULT_PORT)

    # Run the test
    bigMsg = str( range(1000000) )
    response = SmartClient.sendMessageAndGetResponse(client, bigMsg)

    SmartClient.disconnectFromServer(client)
    server.stop()

    # Did the test pass?
    testResultStr = "PASS" if (bigMsg == response) else "FAIL"

    # Print test status
    print "[Unit Test 5]",
    print "Client sends server a %d byte message and gets" % len(bigMsg),
    print "expected response [%s]" % testResultStr

    # Return result
    if (testResultStr == "PASS"):
        return True
    else:
        return False


#------------------------------------------------------------------------------
# Method: performUnitTesting
# Postcondition: The method has run automated tests on the SmartServer class
#------------------------------------------------------------------------------
def performUnitTesting():
    tests = []
    tests.append(performUnitTest1)
    tests.append(performUnitTest2)
    tests.append(performUnitTest3)
    tests.append(performUnitTest4)
    tests.append(performUnitTest5)

    title = "SmartServer: Automated Unit Testing"

    print "=" * (len(title)+2)
    print title
    print "=" * (len(title)+2)

    for test in tests:
        testPassed = test()

        if (not testPassed):
            print "Test failed. Stopping test sequence"
            sys.exit(1)


# If script is run instead of being imported, run unit tests
if (__name__ == "__main__"):
    usageStr  = "%s <FLAGS>" % sys.argv[0]
    epilogStr = "Example:\n  %s --test" % sys.argv[0]

    parser = OptionParser(usage=usageStr, epilog=epilogStr)
    parser.add_option("-t", "--test",
                        dest="runTests",
                        action="store_true", default=False,
                        help="Run automated self tests")

    options,args = parser.parse_args()
    runTests     = options.runTests

    # Run automated testing?
    if (runTests):
        performUnitTesting()

    # No flags set
    else:
        parser.print_help()
        sys.exit(1)

