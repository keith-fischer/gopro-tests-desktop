from flask import Flask, json, request
# --------------------------------------------------------------------------
# Very simple REST server using Flask
# --------------------------------------------------------------------------
JSON_FIELD = "banner"
PORT = 8081
callback = None
app = Flask(__name__)

# --------------------------------------------------------------------------
# USAGE:
# simplerestserver.callback=MyClass.my_callback # static method
# simplerestserver.JSON_FIELD="banner" #this JSON field will get sent to the my_callback
# simplerestserver.start() #main thread get consumed here and return back on the callback
# --------------------------------------------------------------------------
# POST /banner HTTP/1.1
# Host: 127.0.0.1:8081
# Content-Type: application/json
# Cache-Control: no-cache
# {"banner":"camera tests\n Line2\n Line3 camera tests\n Line4\n Line5"}
# --------------------------------------------------------------------------
@app.route('/banner', methods=['POST', 'GET'])
def main():
    global callback
    try:
        _data = request.data
        # validate the received values
        if _data:
            _obj = json.loads(_data)
            if _obj and JSON_FIELD in _obj:
                msg = "%s" % _obj[JSON_FIELD]
                if not callback:
                    callback = _callback
                    msg = "Recieved msg:%s\nSet the callback method on flaskserver.callback " % _obj[JSON_FIELD]
                callback(msg)
                return json.dumps({JSON_FIELD: msg})

            else:
                info = 'No %s field' % JSON_FIELD
                return json.dumps({'error': info})
        else:
            return json.dumps({'error': 'No Data'})

    except Exception as e:
        return json.dumps({'error': str(e)})

# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
def _callback(msg):
    print msg
# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
def start():
    app.run(port=PORT)

#if __name__ == "__main__":
    #start()