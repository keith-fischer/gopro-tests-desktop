import SmartServer


# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
class RunServer:
    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    count =0
    externalresponse = None

    # --------------------------------------------------------------------------
    # method
    # --------------------------------------------------------------------------
    def __init__(self, external_response):
        RunServer.externalresponse=external_response
        self.server = SmartServer.SmartServer("banner")
        if self.server:

            print str(self.server.HOST)
            print str(self.server.BASE_PORT)
            print str(self.server.DEFAULT_PORT)
            print str(self.server.getName())

            self.server.registerMessageHandler(external_response)
            if self.server.start():
                RunServer.count = 0
            else:
                print "Failed to start smartserver"
                print str(self.server.MSG_ERROR)
        else:
            print "Failed to start smartserver"
            print str(self.server.MSG_ERROR)
            exit(1)

    # --------------------------------------------------------------------------
    # method
    # --------------------------------------------------------------------------
    @staticmethod
    def responseHandler(msg):
        RunServer.externalresponse(msg)
        RunServer.count += 1
        print "%s recieved:%s" % (str(RunServer.count),msg)
        return "%s received:%s" % (str(RunServer.count),msg)

    def serverStop(self):
        self.server.stop()


