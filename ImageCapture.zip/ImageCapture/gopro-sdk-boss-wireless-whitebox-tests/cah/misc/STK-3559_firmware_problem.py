#!/usr/bin/python

import sys

DIMENSIONS_4K          = ("4K",         3840, 2160)
DIMENSIONS_2_7K        = ("2.7K",       2704, 1520)
DIMENSIONS_2_7K_4_BY_3 = ("2.7K (4:3)", 2704, 2028)
DIMENSIONS_1440P       = ("1440p",      1920, 1440)
DIMENSIONS_1080P       = ("1080p",      1920, 1080)
DIMENSIONS_960P        = ("960p",       1280, 960)
DIMENSIONS_720P        = ("720p",       1280, 720)
DIMENSIONS_WVGA        = ("WVGA",       848,  480)

DIMENSIONS = (DIMENSIONS_4K,
              DIMENSIONS_2_7K,
              DIMENSIONS_2_7K_4_BY_3,
              DIMENSIONS_1440P,
              DIMENSIONS_1080P,
              DIMENSIONS_960P,
              DIMENSIONS_720P,
              DIMENSIONS_WVGA)

BITRATE_15MBPS_TECHNICAL  = 15 * 2**20
BITRATE_15MBPS_COLLOQUIAL = 15 * 1000000

FPS_VALUES = [24,25,30,48,50,60,80,90,100,120,240]


def getMinBitrate(width, height, fps, fpsDivisor):
    return (width * height) * (fps / fpsDivisor) / 20


def getMaxBitrate(width, height, fps, fpsDivisor):
    return (width * height) * (fps / fpsDivisor) / 2


def main():

    header = ""
    header += "||Resolution"
    header += "||New Width"
    header += "||New Height"
    header += "||Orig. FPS"
    header += "||FPS Divisor"
    header += "||Min Accepted Bitrate"
    header += "||Max Accepted Bitrate"
    header += "||Colloquial Bitrate Accepted"
    header += "||Technical Bitrate Accepted"
    header += "||"
    print header

    uniqueFps = []
    fpsDivisor = 1

    for dimension in DIMENSIONS:
        resolutionName,width,height = dimension

        for fps in FPS_VALUES:
            minBitrate = getMinBitrate(width,height,fps,fpsDivisor)
            maxBitrate = getMaxBitrate(width,height,fps,fpsDivisor)

            if minBitrate <= BITRATE_15MBPS_COLLOQUIAL <= maxBitrate:
                isColloquailBitrateOk = "{color:green}True{color}"
            else:
                isColloquailBitrateOk = "{color:red}False{color}"

            if minBitrate <= BITRATE_15MBPS_TECHNICAL <= maxBitrate:
                isTechnicalBitrateOk = "{color:green}True{color}"
            else:
                isTechnicalBitrateOk = "{color:red}False{color}"

            row = "|%s|%d|%d|%d|%d|%d|%d|%s|%s|" % (resolutionName,
                                                    width,
                                                    height,
                                                    fps,
                                                    fpsDivisor,
                                                    minBitrate,
                                                    maxBitrate,
                                                    isColloquailBitrateOk,
                                                    isTechnicalBitrateOk)
            print row


if (__name__ == "__main__"):
    main()
