#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: cameraHelper.py
# Description: XXX
# Author: Sean Foley
# Date Created: 29 April 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import argparse
import errno
import os
import pexpect
import select
import socket
import sys
import threading
import time
import traceback


class StartNetcatServerThread(threading.Thread):
    """
    A thread class used to make the camera start netcat_a9s listening on the appropriate port.
    Used to either receive a file or send one.
    """

    def __init__(self, serialPort, baudRate, command):
        threading.Thread.__init__(self)
        self.__serialPort = serialPort
        self.__baudRate = baudRate
        self.__command = command

    def run(self):
        executeCommand(self.__serialPort, self.__baudRate, self.__command)


def isNetcatPresentOnCamera(serialPort, baudRate):
    """
    Verify that the camera has netcat available on it. Otherwise, none of this stuff will work!

    :param serialPort: The serial port / device to talk to
    :param baudRate: The speed in bits/sec at which to communicate with the serial port
    :return: True if the camera has netcat; False otherwise
    """

    netcatBinaryPath = "/tmp/fuse_d/netcat_a9s"
    netcatFoundStr = "netcat found"
    netcatNotFoundStr = "netcat not found"
    cmd = "if [ -e '%s' ]; then echo '%s'; else echo '%s'; fi" % (netcatBinaryPath, netcatFoundStr, netcatNotFoundStr)

    outputStr = executeCommand(serialPort, baudRate, cmd)
    outputStr = outputStr.strip()

    if outputStr.endswith(netcatFoundStr):
        print "\n\nNetcat found"
        return True
    elif outputStr.endswith(netcatNotFoundStr):
        print "\n\nNetcat not found"
        return False
    else:
        print "\n\nUnexpected error: Cannot determine whether netcat exists or not"
        print 'outputStr: """%s"""' % outputStr
        sys.exit(1)


def parseCommandline():
    """
    Parse arguments from the commandline

    :return:
    """

    usageStr = "%s <serial port> [optional arguments]" % sys.argv[0]
    descriptionStr = "A tool to ease automated interactions with a serial port / device"
    epilogStr = "Example: $ %s /dev/cu.SLAB_USBtoUART23 -x \"ls -l\"" % sys.argv[0]

    parser = argparse.ArgumentParser(usage=usageStr, description=descriptionStr, epilog=epilogStr)

    parser.add_argument(
        "-p", "--serialport",
        help="Specify the serial port / device to communicate with",
        type=str,
        required=True,
        default=None)

    parser.add_argument(
        "-b", "--baudrate",
        help="Specify the baud rate of the serial port/device",
        type=str,
        default="115200")

    # User can either --execute, --sendfile or --getfile, not a combination of two or more!
    group = parser.add_mutually_exclusive_group()

    group.add_argument(
        "-x", "--execute",
        help="Execute this command on the other end of the serial port",
        type=str,
        default=None)

    group.add_argument(
        "-s", "--sendfile",
        help="Send a file to the other end of the serial port",
        metavar="FILENAME",
        type=str,
        default=None)

    group.add_argument(
        "-g", "--getfile",
        help="Get a file from the other end of the serial port",
        type=str,
        default=None)

    return parser.parse_args()


def executeCommand(serialPort, baudRate, cmd):
    """
    Execute a command on the serial port / device

    :param serialPort: The serial port / device to talk to
    :param baudRate: The speed in bits/sec at which to communicate with the serial port
    :param cmd: The command to run on the serial port
    :return: The stdout/stderr output of the child's response as a string
    """

    linuxPrompt = r"/[ -~]* [%$#>]" # slash, anything printable, space, percent/dollar/pound/greaterthan
    cmdTimeout = -1  # seconds (-1: inifinte)
    screenCmd   = "screen %s %s" % (serialPort, baudRate)

    child = pexpect.spawn(screenCmd)

    # Specify where to send the output of the serial port
    child.logfile = sys.stdout
    #child.logfile = open("screen.log", "w")

    # TODO: Determine why the commented out lines below cause an error
    #child.sendcontrol("d") # Press CTRL+d to send EOF in case a previous command is stuck
    #time.sleep(0.10)
    #child.sendcontrol("c") # Press CTRL+c to send SIGINT in case a previous command is stuck
    #time.sleep(0.10)
    child.sendline("")     # Press ENTER to make sure the prompt comes up
    child.expect(linuxPrompt, timeout=cmdTimeout)

    child.sendline(cmd)
    child.expect(linuxPrompt, timeout=cmdTimeout)
    childResponse = child.before # the child's response before the above expectation (i.e. output of previous command)

    # Press CTRL+a, k, y to exit screen cleanly
    child.sendcontrol("a")
    child.send("k")
    child.send("y")

    child.close()
    child.wait()

    return childResponse


def sendFileToCamera(serialPort, baudRate, filename):
    """
    Send a file to the GoPro using netcat_a9s, which should be on the camera already

    :param serialPort: The serial port / device to talk to
    :param baudRate: The speed in bits/sec at which to communicate with the serial port
    :param filename: The name of the file (on host) to send to the camera
    :return: True if file was sent successfully; False otherwise
    """

    if not os.path.exists(filename):
        print "Error: File not found: '%s'" % filename
        return False

    command = "/tmp/fuse_d/netcat_a9s -c -l -p 14441 > /tmp/fuse_d/%s" % filename
    netcatThread = StartNetcatServerThread(serialPort, baudRate, command)
    netcatThread.start()
    time.sleep(1.000)

    # Read filename into buffer
    with open(filename, "rb") as f:
        data = f.read()

    # Connect to server, which (should be) listening on camera
    SERVER_IP    = "10.5.5.9"
    SERVER_PORT  = 14441
    try:
        print "Connecting to server..."
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect( (SERVER_IP, SERVER_PORT) )
    except socket.error as e:
        print "Error conneting to server. Error: '%s'" % e
        return False

    totalBytesSent = 0
    while totalBytesSent < len(data):
        try:
            totalBytesSent += sock.send(data[totalBytesSent:])

        except socket.error as e:
            err = e.args[0]

            if (err == "timed out"):
                print "Error: Socket broke or disconnected"
                return False
            elif err == errno.EWOULDBLOCK or err == errno.EAGAIN:
                continue

            else:
                print "Error: Exception occurred while trying to send message."
                traceback.print_exc()

    sock.close()
    netcatThread.join() # wait for thread to finish before continuing
    return True


def getFileFromCamera(serialPort, baudRate, filename):
    """
    Get a file from the GoPro camera using netcat_a9s, which should be on the camera already

    :param serialPort: The serial port / device to talk to
    :param baudRate: The speed in bits/sec at which to communicate with the serial port
    :param filename: The name of the file (on host) to send to the camera
    :return: True if file was sent successfully; False otherwise
    """

    # Determine whether the file exists on the camera
    fileExistsStr = "file exists"
    fileNotFoundStr = "file not found"
    cmd = "if [ -e '%s' ]; then echo '%s'; else echo '%s'; fi" % (filename, fileExistsStr, fileNotFoundStr)
    outputStr = executeCommand(serialPort, baudRate, cmd)
    outputStr = outputStr.strip()

    if outputStr.endswith(fileExistsStr):
        print "\n\nFile found"
    elif outputStr.endswith(fileNotFoundStr):
        print "\n\nError: File not found on camera: '%s'" % filename
        return False
    else:
        print "\n\nUnexpected error: File's existence cannot be determined"
        print 'Output of executeCommand:\n """%s"""' % outputStr
        sys.exit(1)

    # Tell the camera to send [filename] to the first client to connect to it
    command = "/tmp/fuse_d/netcat_a9s -c -l -p 14441 < %s" % filename
    netcatThread = StartNetcatServerThread(serialPort, baudRate, command)
    netcatThread.start()
    time.sleep(1.000)

    # Connect to the camera as client to download file
    SERVER_IP    = "10.5.5.9"
    SERVER_PORT  = 14441
    MAX_MSG_SIZE = 100 * 1024 # 100KB
    try:
        print "Connecting to camera..."
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect( (SERVER_IP, SERVER_PORT) )
        sock.setblocking(0) # non-blocking socket
    except socket.error as e:
        print "Error conneting to server. Error: '%s'" % e
        return False

    selectTimeoutInSec = 1.000 # sec
    msg = ""
    while True:
        readFds,writeFds,errFds = select.select([sock], [], [], selectTimeoutInSec)

        # Check for socket error
        if len(errFds) > 0:
            print "Socket error occurred during select on socket"
            sys.exit(1)

        if len(readFds) > 0 and readFds[0] == sock:
            partialMsg = sock.recv(MAX_MSG_SIZE)
            #print "Debug: Partial message received: %d bytes" % len(partialMsg)
            msg += partialMsg
        else:
            print "Select timed out. Total bytes read: %d" % len(msg)
            break

    print "Message received: %d bytes" % len(msg)
    sock.close()

    localFilename = filename.split("/")[-1]
    print "Saving to '%s'" % localFilename
    with open(localFilename, "wb") as f:
        f.write(msg)

    #netcatThread.join() # wait for thread to finish before continuing
    return True


def main():
    """
    Script begins here

    :return: 0 on exit success; 1 otherwise
    """

    args = parseCommandline()

    isNetcatAvailable = isNetcatPresentOnCamera(args.serialport, args.baudrate)

    if not isNetcatAvailable:
        print "Error: Netcat is not available on camera. Script will not work"
        sys.exit(1)

    if args.execute is not None:
        output = executeCommand(args.serialport, args.baudrate, args.execute)
        time.sleep(2)
        print "Debug - output: %s" % output
    elif args.sendfile is not None:
        success = sendFileToCamera(args.serialport, args.baudrate, args.sendfile)
        print "Success: %s" % success
    elif args.getfile is not None:
        success = getFileFromCamera(args.serialport, args.baudrate, args.getfile)
        print "Success: %s" % success


if (__name__ == "__main__"):
    main()

