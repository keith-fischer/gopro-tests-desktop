#------------------------------------------------------------------------------
# Video Media
#------------------------------------------------------------------------------
# Template:
# videoTests+=( <FILE PATH>
#               <WIDTH>
#               <HEIGHT>
#               <FPS>
#               <FPS DIVISOR>
#               <DURATION MS> )
#------------------------------------------------------------------------------
#-----------------------------
# Resolution: 4K (3840x2160)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0105.MP4 3840 2160 30 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0106.MP4 3840 2160 24 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0107.MP4 3840 2160 25 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0764.MP4 3840 2160 24 1 60000" )

# Protune enabled
videoTests+=( "DCIM/100GOPRO/GOPR5062.MP4 3840 2160 30 1 60000 protune enabled" )
videoTests+=( "DCIM/100GOPRO/GOPR5063.MP4 3840 2160 25 1 60000 protune enabled" )

# Chaptered video
videoTests+=( "DCIM/100GOPRO/GOPR5350.MP4 3840 2160 30 1 532544" ) # Also transcodes GP015350.MP4, GP025350.MP4, GP035350.MP4, GP045350.MP4

# Time Lapse Video
# Note: FPS is always 30 according to https://gopro.com/support/articles/how-do-i-use-time-lapse-video
videoTests+=( "DCIM/100GOPRO/GOPR4534.MP4 3840 2160 30 1 300000 time lapse video" )

#-----------------------------
# Resolution: 2.7K (2704x1520)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0765.MP4 2704 1520 60 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0766.MP4 2704 1520 48 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0767.MP4 2704 1520 30 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0768.MP4 2704 1520 24 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0880.MP4 2704 1520 50 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0881.MP4 2704 1520 48 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0882.MP4 2704 1520 25 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0883.MP4 2704 1520 24 1 60000" )

#-----------------------------
# Resolution: 2.7K 4:3 (2704x2028)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0913.MP4 2704 2028 30 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0914.MP4 2704 2028 25 1 60000" )

#-----------------------------
# Resolution: 1440p (1920x1440)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0884.MP4 1920 1440 80 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0885.MP4 1920 1440 60 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0886.MP4 1920 1440 48 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0887.MP4 1920 1440 30 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0888.MP4 1920 1440 24 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0889.MP4 1920 1440 80 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0890.MP4 1920 1440 50 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0891.MP4 1920 1440 48 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0892.MP4 1920 1440 25 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0893.MP4 1920 1440 24 1 60000" )

#-----------------------------
# Resolution: 1080p(1920x1080)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0894.MP4 1920 1080 120 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0895.MP4 1920 1080 90 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0896.MP4 1920 1080 80 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0897.MP4 1920 1080 60 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0898.MP4 1920 1080 48 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0899.MP4 1920 1080 30 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0917.MP4 1920 1080 24 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0233.MP4 1920 1080 120 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0234.MP4 1920 1080 90 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0235.MP4 1920 1080 80 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0236.MP4 1920 1080 50 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0237.MP4 1920 1080 48 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0238.MP4 1920 1080 25 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0239.MP4 1920 1080 24 1 60000" )

# Looping video (FOV: SuperView) (Interval: 5 minutes)
videoTests+=( "DCIM/100GOPRO/G0105064.MP4 1920 1080 30 1 60000 Looping video (file1), FOV:SuperView, Interval:5min" )
videoTests+=( "DCIM/100GOPRO/G0105065.MP4 1920 1080 30 1 60000 Looping video (file2), FOV:SuperView, Interval:5min" )
videoTests+=( "DCIM/100GOPRO/G0105066.MP4 1920 1080 30 1 60000 Looping video (file3), FOV:SuperView, Interval:5min" )
videoTests+=( "DCIM/100GOPRO/G0105067.MP4 1920 1080 30 1 60000 Looping video (file4), FOV:SuperView, Interval:5min" )
videoTests+=( "DCIM/100GOPRO/G0105068.MP4 1920 1080 30 1 60000 Looping video (file5), FOV:SuperView, Interval:5min" )
videoTests+=( "DCIM/100GOPRO/G0105069.MP4 1920 1080 30 1 60000 Looping video (file6), FOV:SuperView, Interval:5min" )

# Chaptered video
videoTests+=( "DCIM/100GOPRO/GOPR5344.MP4 1920 1080 60 1 1000" ) # Also transcodes GP015344.MP4, GP025344.MP4 (takes 30-35 min!)

# EIS (Electronic Image Stabilization) enabled
videoTests+=( "DCIM/100GOPRO/GOPR5346.MP4 1920 1080 30 1 60000" )

# Low Light: ON
videoTests+=( "DCIM/100GOPRO/GOPR5347.MP4 1920 1080 60 1 60000" )

# Video containing HiLights
videoTests+=( "DCIM/100GOPRO/GOPR5349.MP4 1920 1080 60 1 60000" )

#-----------------------------
# Resolution: 960p(1280x960)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0240.MP4 1280 960 120 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0241.MP4 1280 960 60 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0244.MP4 1280 960 120 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0245.MP4 1280 960 50 1 60000" )

#-----------------------------
# Resolution: 720p(1280x720)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0901.MP4 1280 720 240 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0902.MP4 1280 720 120 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0903.MP4 1280 720 100 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0904.MP4 1280 720 60 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0905.MP4 1280 720 30 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0906.MP4 1280 720 240 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0907.MP4 1280 720 120 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0908.MP4 1280 720 100 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0909.MP4 1280 720 50 1 60000" )
videoTests+=( "DCIM/100GOPRO/GOPR0910.MP4 1280 720 25 1 60000" )

#-----------------------------
# Resolution: WVGA(848x480)
#-----------------------------
# Format: NTSC
videoTests+=( "DCIM/100GOPRO/GOPR0911.MP4 848 480 240 1 60000" )

# Format: PAL
videoTests+=( "DCIM/100GOPRO/GOPR0912.MP4 848 480 240 1 60000" )

#------------------------------------------------------------------------------
# Photo Media
#------------------------------------------------------------------------------
# Template:
# videoTests+=( <FILE PATH> <NUMBER OF PHOTOS> )
#------------------------------------------------------------------------------
# Multishot: Time Lapse
photoTests+=( "DCIM/100GOPRO/G0115071.JPG 110" )

# Multishot: Night Lapse
photoTests+=( "DCIM/100GOPRO/G0125181.JPG 110" )
