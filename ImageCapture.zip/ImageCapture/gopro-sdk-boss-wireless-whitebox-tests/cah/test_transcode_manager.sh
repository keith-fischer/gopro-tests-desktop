#!/usr/local/bin/bash
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: test_transcode_manager.sh
# Description: XXX
# Dependencies:
#   1. Install updated copy of bash (brew install bash)
#   2. serial.exp: XXX
#   3. Media library from [WIKI LINK] on SD CARD              <--- TODO: Finish
# Author: Sean Foley, Behrokh Farzad
# Date Created: 27 April 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#
# TODO List
#   1. Delete .TRV file after video is transcoded
#

# Parse commandline
if [ $# -ne 2 ]; then
	echo "Usage:   $0 <LINUX SERIAL DEVICE> <TEST RUN LABEL>"
	echo "Example: $0 /dev/cu.SLAB_USBtoUART1 Australia_v21"
	exit 1
fi
SERIAL_PORT="$1"
TEST_RUN_LABEL="${2/ /_}"

TEST_MEDIA_LIBRARY="https://wiki.gopro.com/pages/viewpage.action?spaceKey=SQ&title=Recorded+Videos+for+CAH"

TEST_TIMESTAMP=$(date +%Y%m%d-%H%M%S)
TEST_RUN_DIR="test_run_${TEST_TIMESTAMP}_${TEST_RUN_LABEL}"
TRANSCODE_TEST_LOG="$TEST_RUN_DIR/transcode_test_$TEST_TIMESTAMP.log"
TEST_RESULT_LOG="$TEST_RUN_DIR/test_results.wiki.markup"
TEST_BIN="/tmp/fuse_d/transcode_test"

DIMENSIONS_4K="3840 2160"
DIMENSIONS_2_7K="2704 1520"
DIMENSIONS_2_7K_4_BY_3="2704 2028"
DIMENSIONS_1440P="1920 1440"
DIMENSIONS_1080P="1920 1080"
DIMENSIONS_960P="1280 960"
DIMENSIONS_720P="1280 720"
DIMENSIONS_WVGA="848 480"

MEDIA_TYPE_VIDEO="Video"
MEDIA_TYPE_PHOTO="Photo"

#------------------------------------------------------------------------------
# Media Library on SD card
#------------------------------------------------------------------------------
declare -a videoTests
declare -a photoTests

# Execute San Diego QA team's Australia tests
source SDQA_Australia.tests.sh

# Execute Firmware QA team's video tests
# source FWQA_Build_Medias.tests.sh


#------------------------------------------------------------------------------
# Function: getFormattedTime
#   Get the date/time in a nicely formatted string
#------------------------------------------------------------------------------
function getFormattedTime {
	# [Dec 25 2016 15:16:17]
	echo "$(date "+%Y-%m-%d %H:%M:%S %Z")"
}


#------------------------------------------------------------------------------
# Function: getResolutionName
#   Given a width and height in pixels, get a resolution name
#
# Input $1: The width, in pixels, of a video
# Input $2: The height, in pixels, of a video
# Postcondition: The function has output a resolution name to stdout
#------------------------------------------------------------------------------
function getResolutionName {
	width="$1"
	height="$2"

	dimensions="$width $height"

	if [ "$dimensions" == "$DIMENSIONS_4K" ]; then
		echo "4K"
	elif [ "$dimensions" == "$DIMENSIONS_2_7K" ]; then
		echo "2.7K"
	elif [ "$dimensions" == "$DIMENSIONS_2_7K_4_BY_3" ]; then
		echo "2.7K (4:3)"
	elif [ "$dimensions" == "$DIMENSIONS_1440P" ]; then
		echo "1440p"
	elif [ "$dimensions" == "$DIMENSIONS_1080P" ]; then
		echo "1080p"
	elif [ "$dimensions" == "$DIMENSIONS_960P" ]; then
		echo "960p"
	elif [ "$dimensions" == "$DIMENSIONS_720P" ]; then
		echo "720p"
	elif [ "$dimensions" == "$DIMENSIONS_WVGA" ]; then
		echo "WVGA"
	else
		echo "Resolution unknown (w:$width, h:$height)"
	fi
}


#------------------------------------------------------------------------------
# Function: runOnCamera
#   Run a command on the camera via serial / debug board
#
# Input $1: A string containing the /dev/XXX device (serial port) to talk to
# Input $2: A string containing a command to run on the camera
# Optional Input $3: If "false", debug logging will not occur
# Postcondition: The function has executed $2 on the camera
#------------------------------------------------------------------------------
function runOnCamera {
	local SERIAL_PORT="$1"
	CMD="$2"
	ENABLE_DEBUG_LOGGING=${3:-"true"}

	if [ "$ENABLE_DEBUG_LOGGING" = "true" ]; then
		echo "[$(getFormattedTime)] [On Camera]: $CMD"
	fi

	CAMERA_OUTPUT=$(./serial.exp $SERIAL_PORT "$CMD")

	if [ $? -ne 0 ]; then
		echo "Unable to establish connection to serial port: '$SERIAL_PORT'"
		exit 1
	fi
}


#------------------------------------------------------------------------------
# Function: getModelNameAndFirmwareVersion
#   Get strings for the model and firmware version of the camera
#
# Input $1: The serial port of the camera
# Postcondition: The function has set the following global variables:
#   modelName       == <model name of the camera>
#   firmwareVersion == <firmware version of the camera>
#------------------------------------------------------------------------------
function getModelNameAndFirmwareVersion {
	serialPort="$1"
	CONFIG_FILE="/tmp/fuse_b/conf.json"

	# Soak up the config file from the camera
	runOnCamera "$serialPort" "cat $CONFIG_FILE" false
	configFile="$CAMERA_OUTPUT"

	modelName="$(echo "$configFile" | grep CSI_MODEL_NAME | sed 's|.*:.*\"\([^\"]*\)\".*|\1|g')"
	firmwareVersion="$(echo "$configFile" | grep CSI_FIRMWARE_VERSION | sed 's|.*:.*\"\([^\"]*\)\".*|\1|g')"
}


#------------------------------------------------------------------------------
# Function: applyTranscodingRules
#   Apply transcoding rules to a video's parameters
#
# Input $1: The width, in pixels, of the video
# Input $2: The height, in pixels, of the video
# Input $3: The framerate of the video
# Input $4: The "fps divisor" (what you have to divide framerate by to get
#           a new desired frame rate)
# Input $5: The duration, in milliseconds, of the video
# Postcondition: The function has set the following global variables per the
#                known transcoding rules:
#                width, height, fps, fpsDivisor, duration
#------------------------------------------------------------------------------
function applyTranscodingRules {
	width="$1"
	height="$2"
	fps="$3"
	fpsDivisor="$4"
	duration="$5"

	# Transcoding Rules:
	#   Rules are defined on the Wiki below:
	#     https://wiki.gopro.com/pages/viewpage.action?spaceKey=PMH&title=Cloud+Video+Modes
	#
	#   Current Implementation of Rules:
	#     1. If res is 1440p or 2.7K (4:3), transcode video to 1440p
	#     2. If res is 4K, 2.7K or 1080p, transcode video to 1920x1080
	#     3. Framerate is never changed
	#     4. Bitrate is always set to "15 Mbps", which is defined by the firmware
	#        as 15,000,000 instead of the normal definition (15*1024*1024==15728640)

	resolution="$width $height"

	# Rule 1
	if [ "$resolution" == "$DIMENSIONS_1440P" -o \
		 "$resolution" == "$DIMENSIONS_2_7K_4_BY_3" ]; then
		 read width height <<< "$DIMENSIONS_1440P"

	# Rule 2
	elif [ "$resolution" == "$DIMENSIONS_4K" -o \
		   "$resolution" == "$DIMENSIONS_2_7K" -o \
		   "$resolution" == "$DIMENSIONS_1080P" ]; then
		read width height <<< "$DIMENSIONS_1080P"
	fi

	# Rule 3
	# Nothing to do

	# Rule 4
	minBitrate=$(( width*height * (fps / fpsDivisor) / 20 ))
	maxBitrate=$(( width*height * (fps / fpsDivisor) / 2 ))

	# Correct definition of 15Mbps
	#bitrate=15728640

	# Firmware's definition of 15Mbps
	bitrate=15000000

	# Warn user of any expected failures
	# if [ $bitrate -lt $minBitrate ]; then
	# 	echo "Warning: Bitrate ($bitrate) is less tha minBitrate ($minBitrate)."
	# 	echo "         Transcode will probably fail."
	# elif [ $bitrate -gt $maxBitrate ]; then
	# 	echo "Warning: Bitrate ($bitrate) is greater than maxBitrate ($maxBitrate)."
	# 	echo "         Transcode will probably fail."
	# fi
}


#------------------------------------------------------------------------------
# Function: performTestPostProcessing
#   Perform post-processing on logs after testing is complete
#
# Input $1: Test execution time (in seconds)
#------------------------------------------------------------------------------
function performTestPostProcessing {
	runtime=$1

	# Let's format the time elapsed all pretty so it's super readable!
	SECONDS_PER_MINUTE=$(( 60 ))
	SECONDS_PER_HOUR=$(( 60 * 60 ))
	SECONDS_PER_DAY=$(( 60 * 60 * 24 ))

	numHours=$(( runtime / SECONDS_PER_HOUR ))
	runtime=$(( runtime - (numHours * SECONDS_PER_HOUR) ))
	numMinutes=$(( runtime / SECONDS_PER_MINUTE ))
	runtime=$(( runtime - (numMinutes * SECONDS_PER_MINUTE) ))
	numSeconds=$runtime

	formattedTimeElapsed=$(printf "%.2d:%.2d:%.2d" $numHours $numMinutes $numSeconds)
	echo "*Test Run Time:* $formattedTimeElapsed" >> $TEST_RESULT_LOG

}


#------------------------------------------------------------------------------
# Function: validateTranscodingResult
#   Determine whether the transcode was successful and log pass/fail
#
# Input $1: The file path of the video just transcoded
# Input $2: The media type (see MEDIA_TYPE_XXX at top of file)
# Input $3: The formatted start time of the transcode
# Input $4: The duration of the transcode in seconds
# Input $5: The stdout from the camera during execution of transcode_test
#------------------------------------------------------------------------------
function validateTranscodingResult {
	local filePath="$1"
	local mediaType="$2"
	local transcodeStartTime="$3"
	local transcodeDuration="$4"
	local TEST_LOGS="$5"

	# This is what it looks like when a transcode is successful:
	#   pTranMan->Transcode success. Output path: /tmp/fuse_d/DCIM/100GOPRO/GOPR0105.TRV    
	local filePathNoExt="${filePath##*/}"           # remove everything up to the last slash
	local filePathNoExt="${filePathNoExt%.*}"       # remove the ".xxx" extension
	local SUCCESS_INDICATOR="Transcode success. Output path:.*\.TRV"

	# Verify that the transcode was successful via logs
	echo "$TEST_LOGS" | grep "$SUCCESS_INDICATOR" > /dev/null
	if [ $? -eq 0 ]; then
		echo "Transcode Status: Successful"
		testStatus="{color:green}PASS{color}"
	else
		echo "Transcode Status: Failed"
		testStatus="{color:red}FAIL{color}"
	fi

	case "$mediaType" in
		"$MEDIA_TYPE_VIDEO")
			# Add table row with transcoding test result
			row=""
			row="$row|$startTimeFormatted"
			row="$row|$transcodeDuration"
			row="$row|$notes"
			row="$row|$filePath"
			row="$row|$(getResolutionName $origWidth $origHeight)"
			row="$row|$origWidth"
			row="$row|$origHeight"
			row="$row|$origFps"

			row="$row|$(getResolutionName $width $height)"
			row="$row|$width"
			row="$row|$height"
			row="$row|$fps"
			row="$row|$fpsDivisor"

			row="$row|$duration"
			row="$row|$testStatus"
			row="$row|"
			;;

		"$MEDIA_TYPE_PHOTO")
			row=""
			row="$row|$startTimeFormatted"
			row="$row|$transcodeDuration"
			row="$row|$filePath"
			row="$row|$fileCount"
			row="$row|$notes"
			row="$row|$testStatus"
			row="$row|"
			;;

		*)
			echo "Error: Unexpected media type: '$mediaType'"
			exit 1
			;;
	esac

	echo "$row" >> $TEST_RESULT_LOG
}


#==============================================================================
# Script begins here
#==============================================================================
testRunStartTime=$(date +%s)

# Test pre-processing
mkdir -p "$TEST_RUN_DIR"
getModelNameAndFirmwareVersion "$SERIAL_PORT"  # sets modelName and firmwareVersion

# Test report headers
echo "h2. Transcode Manager Test Results:" >> $TEST_RESULT_LOG
echo "*Camera Model:* $modelName" >> $TEST_RESULT_LOG
echo "*Firmware Version:* $firmwareVersion" >> $TEST_RESULT_LOG
echo "*Test Media Library:* $TEST_MEDIA_LIBRARY" >> $TEST_RESULT_LOG
echo "*Test Start Time:* $(getFormattedTime)" >> $TEST_RESULT_LOG
echo "h2. Logs:" >> $TEST_RESULT_LOG
echo "*RTOS*: [^RTOS.log]" >> $TEST_RESULT_LOG
echo "*transcode_test:* [^transcode_test.log]" >> $TEST_RESULT_LOG
echo "h2. Summary:" >> $TEST_RESULT_LOG
echo "(To be filled in manually)" >> $TEST_RESULT_LOG

#--------------
# Video Tests
#--------------
# Header for video tests
videoTestHeader="h3. Video Tests:\n"
videoTestHeader="$videoTestHeader||Start Time"
videoTestHeader="$videoTestHeader||Trans. Time (sec)"
videoTestHeader="$videoTestHeader||Notes"
videoTestHeader="$videoTestHeader||File Path"
videoTestHeader="$videoTestHeader||Original Resolution"
videoTestHeader="$videoTestHeader||Original Width"
videoTestHeader="$videoTestHeader||Original Height"
videoTestHeader="$videoTestHeader||Original Frame Rate"
videoTestHeader="$videoTestHeader||New Resolution"
videoTestHeader="$videoTestHeader||New Width"
videoTestHeader="$videoTestHeader||New Height"
videoTestHeader="$videoTestHeader||New Frame Rate"
videoTestHeader="$videoTestHeader||FPS Divisor"
videoTestHeader="$videoTestHeader||Duration (ms)"
videoTestHeader="$videoTestHeader||Test Status"
videoTestHeader="$videoTestHeader||"
echo -e "$videoTestHeader" >> $TEST_RESULT_LOG

# Run video transcode tests
for parameters in "${videoTests[@]}"; do
	startTime=$(date +%s)
	startTimeFormatted=$(getFormattedTime)
	mediaType="$MEDIA_TYPE_VIDEO"

	read filePath origWidth origHeight origFps origFpsDivisor origDuration notes <<< "$parameters"
	if [ -z "$notes" ]; then
		notes=" "
	fi
	applyTranscodingRules "$origWidth" "$origHeight" "$origFps" "$origFpsDivisor" "$origDuration"

	# Transcode the video
	runOnCamera "$SERIAL_PORT" "$TEST_BIN -v $filePath -w $width -h $height -b $bitrate"
	echo "$CAMERA_OUTPUT" >> $TRANSCODE_TEST_LOG

	# Cleanup: Delete TRV file
	#runOnCamera "$SERIAL_PORT" "$TEST_BIN -z $filePath"
	#echo "$CAMERA_OUTPUT" >> $TRANSCODE_TEST_LOG

	endtime=$(date +%s)
	timeElapsed=$(( endtime - startTime ))
	validateTranscodingResult "$filePath" "$mediaType" "$startTimeFormatted" "$timeElapsed" "$CAMERA_OUTPUT"
done

echo -e "\n" >> $TEST_RESULT_LOG

#--------------
# Photo Tests
#--------------
# Header for photo tests
photoTestHeader="h3. Photo Tests:\n"
photoTestHeader="$photoTestHeader||Start Time"
photoTestHeader="$photoTestHeader||Trans. Time (sec)"
photoTestHeader="$photoTestHeader||File Path"
photoTestHeader="$photoTestHeader||Num Photos"
photoTestHeader="$photoTestHeader||Notes"
photoTestHeader="$photoTestHeader||Test Status"
photoTestHeader="$photoTestHeader||"
echo -e "$photoTestHeader" >> $TEST_RESULT_LOG

# Run photo transcoder tests
for parameters in "${photoTests[@]}"; do
	startTime=$(date +%s)
	startTimeFormatted=$(getFormattedTime)
	mediaType="$MEDIA_TYPE_PHOTO"

	read filePath fileCount notes <<< "$parameters"
	if [ -z "$notes" ]; then
		notes=" "
	fi

	# Transcode the photos into a video
	runOnCamera "$SERIAL_PORT" "$TEST_BIN -p $filePath -c $fileCount"
	echo "$CAMERA_OUTPUT" >> $TRANSCODE_TEST_LOG

	# Cleanup: Delete TRV file
	#runOnCamera "$SERIAL_PORT" "$TEST_BIN -z $filePath"
	#echo "$CAMERA_OUTPUT" >> $TRANSCODE_TEST_LOG

	endtime=$(date +%s)
	timeElapsed=$(( endtime - startTime ))
	validateTranscodingResult "$filePath" "$mediaType" "$startTimeFormatted" "$timeElapsed" "$CAMERA_OUTPUT"
done

# Finish up logging
testRunEndTime=$(date +%s)
performTestPostProcessing $((testRunEndTime - testRunStartTime))

