#!/usr/local/bin/bash
# Prerequisite: Bash is installed by brew (brew install bash) so things like associative arrays are available
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: generate_media_test_code.sh
# Description: Generates test cases in the form of associative arrays to be sourced by the TranscodeManager test
#              framework (i.e. test_transcode_manager.sh)
# Author: Sean Foley
# Date Created: 17 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

if [ -z "$(which ffprobe)" ]; then
	echo "Error: ffprobe not installed. Please install by running the command below."
	echo "  $ brew install ffmpeg"
	exit 1
fi

if [ $# -lt 2 ]; then
	echo "Usage: $0 <ARRAY NAME> <FILE1> [<FILE2> ... <FILEN>]"
	exit 1
fi
arrayName="$1"
shift 1
filePaths="$@"

# Start generating bash code
MEDIA_DIR="DCIM/100GOPRO"

for filePath in $filePaths; do
	# Does the file exist?
	if [ ! -f "$filePath" ]; then
		echo "Error: File not found: '$filePath'"
		exit 1
	fi

	filename="$MEDIA_DIR/$(basename $filePath)"

	eval $(ffprobe -v error -of flat=s=_ -select_streams v:0 -show_entries stream=height,width $filePath)
	width="$streams_stream_0_width"
	height="$streams_stream_0_height"
	duration="$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 $filePath)"
	rawFramerate=$(ffprobe -v error -select_streams v:0 -show_entries stream=avg_frame_rate -of default=noprint_wrappers=1:nokey=1 $filePath)
	framerate=$(printf "%.0f" $(echo $rawFramerate | bc -l))
	#echo "Debug: [$filename] ($width x $height) @ $framerate fps for $duration sec"

	# Output bash code for each item in the array (this is used in the TranscodeManager test framework)
	echo "$arrayName+=( \"$filename $width $height $framerate 1 $duration\" )"

done