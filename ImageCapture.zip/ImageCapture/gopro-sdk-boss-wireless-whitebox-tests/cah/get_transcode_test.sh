#!/usr/local/bin/bash
# Note: Requires bash version installed by brew (brew install bash)
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: get_transcode_test.sh
# Description: Tool that fetches the version of transcode_test (a test binary
#              that uses CAH's TranscodeManager) that corresponds to a
#              user-specified firmware release.
#              Since CAHA and transcode_test both statically link
#              TranscodeManager, this is the only way we can be sure we're
#              testing the correct version of TranscodeManager.
# Author: Sean Foley
# Date Created: 12 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#
# Function: checkForError
# Input $1: The return code of a command just executed
# Input $2: An error message to print if the command fails
# Returns: None
#
function checkForError {
	cmdReturnValue="$1"
	errMsg="$2"

	#echo "Debug: cmdReturnValue: '$cmdReturnValue'"
	if [ "$cmdReturnValue" != "0" ]; then
		echo "Error: $errMsg"
		exit 1
	fi
}


#---------------------
# Begin primary work
#---------------------
if [ $# -ne 1 ]; then
	echo "Usage:   $0 <FIRMWARE TAG>"
	echo "Example: $0 HD5.XX.00.21.00"
	exit 1
fi
firmwareTag="$1"

DEFAULT_REPOS_DIR="/Users/$USER/repos"
REPOS_DIR=${REPOS_DIR:-$DEFAULT_REPOS_DIR}

FIRMWARE_REPO="git@github.com:GPFW/BANZAI.git"
FIRMWARE_DIR="${FIRMWARE_REPO##*/}"
FIRMWARE_DIR="${FIRMWARE_DIR%.git}"
LINUX_REPO_DIR="banzai_link"
TRANSCODE_TEST_BIN="transcode_test"
TRANSCODE_TEST_VERSION="Debug/bin"

# Clone firmware repo if necessary
if [ ! -d "$REPOS_DIR/$FIRMWARE_DIR" ]; then
	echo "Firmware repo not found. Cloning into $REPOS_DIR"
	git clone "$FIRMWARE_REPO" > /dev/null
	checkForError $? "Unable to clone $FIRMWARE_REPO."
fi

pushd "$REPOS_DIR/$FIRMWARE_DIR" > /dev/null

	echo "Refreshing $FIRMWARE_DIR repo..."
	git fetch --all &> /dev/null
	checkForError $? "Unable to refresh repo."

	echo "Checking out tag: $firmwareTag"
	git checkout "$firmwareTag" &> /dev/null
	checkForError $? "Unable to checkout tag: '$firmwareTag'"

	echo "Updating submodules (warning: this will take 10-20 min the first time it's done!)"
	git submodule update --init --recursive --force > /dev/null
	checkForError $? "Unable to update submodules."

	if [ ! -d "$LINUX_REPO_DIR" ]; then
		echo "Error: Linux repo not found. Cannot continue."
		exit 1
	fi

	echo "Locating $TRANSCODE_TEST_BIN binary..."
	transcodeTestBinary=$(find "$PWD/$LINUX_REPO_DIR" -name "$TRANSCODE_TEST_BIN" | grep "$TRANSCODE_TEST_VERSION")
	if [ -z "$transcodeTestBinary" ]; then
		echo "Error: transcode_test binary not found."
		exit 1
	fi

popd >/dev/null # $FIRMWARE_DIR

echo "Copying $transcodeTestBinary to ./${TRANSCODE_TEST_BIN}_${firmwareTag}"
cp "$transcodeTestBinary" "./${TRANSCODE_TEST_BIN}_${firmwareTag}"
checkForError $? "Unable to copy '$transcodeTestBinary' to './${TRANSCODE_TEST_BIN}_${firmwareTag}'"

echo "Done."

