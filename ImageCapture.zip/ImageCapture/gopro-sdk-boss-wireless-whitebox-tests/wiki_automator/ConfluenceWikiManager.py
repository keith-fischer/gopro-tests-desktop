#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: ConfluenceWikiManager.py
# Overview: A class designed to allow users to programmatically create/delete/edit Confluence Wiki pages via RESTful
#           API calls (note: requires Confluence Wiki v5.5+)
# Author: Sean Foley
# Date Created: 18 May 2016
#
# Useful REST API Documentation:
#   https://developer.atlassian.com/confdev/confluence-rest-api/confluence-rest-api-examples
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
TODO List:

    Determine how to do markup in the body text and have it show up in the final wiki

"""

import ast
import base64
import getpass
import json
import os
import pprint
import sys
import traceback
import urllib2
import requests


class ConfluenceWikiManager:
    """
    An API that helps in the creation, deletion and edition of wiki pages programmatically
    """

    # Static member variables
    GOPRO_WIKI_SERVER = "https://wiki.gopro.com"


    def __init__(self, wikiServerUrl, username, password):
        self.__username = username
        self.__password = password
        self.__baseUrl = "%s/rest/api/content" % wikiServerUrl

        encodedAuthStr = base64.encodestring("%s:%s" % (username,password)).strip()
        self.__headers = {
            "Content-Type": "application/json",
            "Authorization": "Basic %s" % encodedAuthStr
        }


    def createPage(self, title, body, spaceKey, ancestors=None):
        """
        Create a new wiki page

        :param title: The title of the new page
        :param body: The text of the new page
        :param spaceKey: The unique ID of a wiki space
        ;param ancestors: An optional list of ancestors of the form {'id': '<WIKI PAGE ID>'} (i.e. a list of dicts)
        :return: The server's JSON response
        """

        headers = {"Content-Type": "application/json"}

        data = {
            'type': 'page',
            'title': title,
            'space': {'key': spaceKey},
            'body': {
                'storage': {
                    'value': body,
                    #'representation': 'storage'
                    'representation': 'wiki'
                }
            }
        }

        if ancestors is not None:
            data['ancestors'] = []
            for ancestor in ancestors:
                data['ancestors'].append(ancestor)

        data = json.dumps(data)

        try:
            response = requests.post(self.__baseUrl,
                                     data=data,
                                     auth=(self.__username, self.__password),
                                     headers=headers
                                     )
        except requests.exceptions.Timeout:
            print "Timed out trying to connect"
            sys.exit(1)
        except requests.exceptions.ConnectionError:
            print "ConnectionError occurred."
            sys.exit(1)
        except:
            print "Unknown error occurred."
            traceback.print_exc()
            sys.exit(1)

        return response


    def attachFileToPage(self, filePath, pageID):
        """
        Attach a file to an existing wiki page

        :param filePath: The path to the file to attach
        :param pageID: A string containing the page ID of the wiki page to delete
        :return:
        """

        # Example from API (tested, works)
        #   curl -v -S -u <USERNAME>:<PASSWORD>
        #     -X POST
        #     -H "X-Atlassian-Token: no-check"
        #     -F "file=@playground.py"
        #     -F "comment=this is my file"
        #     "https://wiki.gopro.com/rest/api/content/<PAGE ID>/child/attachment"

        headers = {"X-Atlassian-Token": "no-check"}
        attachFileUrl = "%s/%s/child/attachment" % (self.__baseUrl, pageID)

        if not os.path.exists(filePath):
            print "Error: File not found '%s'" % filePath
            return

        # Note to self: The "multiparty/form-data" was obtained from the output of a successful curl command
        filename = filePath.split("/")[-1]
        files = {'file': (filename, open(filePath, 'rb'), "multipart/form-data")}

        try:
            response = requests.post(
                attachFileUrl,
                headers=headers,
                files=files,
                auth=(self.__username, self.__password)
            )
        except requests.exceptions.Timeout:
            print "Timed out trying to connect"
            sys.exit(1)
        except requests.exceptions.ConnectionError:
            print "ConnectionError occurred."
            sys.exit(1)
        except:
            print "Unknown error occurred."
            traceback.print_exc()
            sys.exit(1)

        return response


    def deletePage(self, pageID):
        """
        Delete a wiki page given its page ID

        :param pageID: A string containing the page ID of the wiki page to delete
        :return: The server's response
        """

        # curl -v -S -u <USERNAME>:<PASSWORD> -X DELETE https://wiki.gopro.com/rest/api/content/<PAGE ID>
        deleteUrl = "%s/%s" % (self.__baseUrl, pageID)
        headers = {"Content-Type": "application/json"}

        try:
            response = requests.delete(deleteUrl, headers=headers, auth=(self.__username,self.__password))
        except requests.exceptions.Timeout:
            print "Timed out trying to connect"
            sys.exit(1)
        except requests.exceptions.ConnectionError:
            print "ConnectionError occurred."
            sys.exit(1)
        except:
            print "Unknown error occurred."
            traceback.print_exc()
            sys.exit(1)

        DELETE_SUCCESSFUL = 204 # HTTP status code: No content
        if response.status_code != requests.codes.ok and response.status_code != DELETE_SUCCESSFUL:
            print "Warning: Status code came back: %s" % response.status_code

        response.raise_for_status()
        return response


    def editPage(self):
        # TODO: Implement
        pass


#-----------------------------------------------------------------------------------------------------------------------
# Informal unit testing
#-----------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    username = raw_input("Username: ")
    password = getpass.getpass("Password: ")
    title    = raw_input("Page Title: ")
    wiki = ConfluenceWikiManager("https://wiki.gopro.com", username, password)
    response = wiki.createPage("test3", "SQ", "This is the {color:green}body{color}")

    print "Response:\n%s" % ast.literal_eval(pprint.pformat(response))
