#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: wiki_automator.py
# Description: A tool to facilitate automation of wiki page work such as creating pages, uploading files, deleting
#              pages, etc
# Author: Sean Foley
# Date Created: 20 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import argparse
import traceback
from ConfluenceWikiManager import *

# Actions supported by this framework
ACTION_CREATE_NEW_PAGE = "create"
ACTION_DELETE_EXISTING_PAGE = "delete"
ACTION_ATTACH_FILE_TO_EXISTING_PAGE = "attach"

SUPPORTED_ACTIONS = (
    ACTION_CREATE_NEW_PAGE,
    ACTION_DELETE_EXISTING_PAGE,
    ACTION_ATTACH_FILE_TO_EXISTING_PAGE
)


def parseCommandline():
    """
    Reads and extracts information from the commandline

    :return: An argparse Namespace object containing all the argument values
    """

    usageStr = "%s <action> <username> <password | passwordfile> <arguments>" % sys.argv[0]
    descriptionStr = "A tool to facilitate automation of creating/deleting wiki pages, uploading attachments, etc"

    epilogStr = 'Examples:\n'
    epilogStr += 'Create new page in "SQ" space:\n'
    epilogStr += '%s -a create -u sfoley -p abcd1234 -t "Test Results" -b report.txt -k SQ\n\n' % sys.argv[0]
    epilogStr += 'Create new page in "SQ" space as a child of page 12345678:\n'
    epilogStr += '%s -a create -u sfoley -p abcd1234 -t "Test Results" -b report.txt -k SQ -i 12345678\n\n' %sys.argv[0]
    epilogStr += 'Delete page that has ID 12345678\n'
    epilogStr += '%s -a delete -u sfoley -passwordfile secret.txt --id 12345678\n\n' % sys.argv[0]
    epilogStr += 'Attach a file to page that has ID 12345678\n'
    epilogStr += '%s -a attach -u sfoley -p abcd1234 -i 12345678 -f fileToUpload.log' % sys.argv[0]

    parser = argparse.ArgumentParser(prog=sys.argv[0],
                                     usage=usageStr,
                                     epilog=epilogStr,
                                     description=descriptionStr,
                                     formatter_class=argparse.RawTextHelpFormatter)

    parser.add_argument("-a", "--action",
                           help="What action to take",
                           type=str,
                           required=True,
                           choices=SUPPORTED_ACTIONS,
                           default=None)

    parser.add_argument("-u", "--username",
                        help="Specify your Confluence Wiki username",
                        type=str,
                        required=True,
                        default=None)

    password = parser.add_mutually_exclusive_group(required=True)
    password.add_argument("-p", "--password",
                        help="Your Confluence Wiki password",
                        type=str,
                        default=None)

    password.add_argument("--passwordfile",
                        help="A text file containing your Confluence Wiki password",
                        type=str,
                        default=None)

    # Flags for creating new pages
    parser.add_argument("-t", "--title",
                                 help="The title of the new wiki page",
                                 type=str,
                                 default="<PAGE TITLE>")

    parser.add_argument("-b", "--body",
                                 help="A text file containing page's body as wiki markup",
                                 type=str,
                                 default=None)

    parser.add_argument("-k", "--spacekey",
                        help="The unique space ID/key of where to create the new page",
                        type=str,
                        default=None)

    # Flags for creating/deleting pages or uploading attachments
    parser.add_argument("-i", "--id",
                                 help="Specify the page ID of an existing Wiki page",
                                 type=str,
                                 default=None)

    # Flags for uploading attachments
    parser.add_argument("-f", "--filepath",
                        help="Specify the path to a file to attach",
                        type=str,
                        default=None)

    args = parser.parse_args()

    # Make sure we have all the information we need
    if args.action == ACTION_CREATE_NEW_PAGE:
        if args.title is None:
            print "Error: Required argument missing: -t|--title"
            parser.print_help()
            sys.exit(1)

        elif args.body is None:
            print "Error: Required argument missing: -b|--body"
            parser.print_help()
            sys.exit(1)

        elif args.spacekey is None:
            print "Error: Required argument missing: -k|--spacekey"
            parser.print_help()
            sys.exit(1)

    elif args.action == ACTION_DELETE_EXISTING_PAGE or args.action == ACTION_ATTACH_FILE_TO_EXISTING_PAGE:
        if args.id is None:
            print "Error: Required argument missing: -i|--pageid"
            parser.print_help()
            sys.exit(1)

    elif args.action == ACTION_ATTACH_FILE_TO_EXISTING_PAGE:
        if args.filepath is None:
            print "Error: Required argument missing: -f|--filepath"
            parser.print_help()
            sys.exit(1)

    return args


def handleResponse(response):
    """
    Handle an response from ConfluenceWikiManager.XXX, which are return values from requests.post and requests.delete

    :param response: A return value from one of the ConfluenceManager.XXX methods
    :return: None
    """

    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        print "HTTP Error: '%s'" % e.message
        sys.exit(1)
    except:
        print "Unknown Error: '%s'" % e.message
        sys.exit(1)


def getWikiPageInfo(response):
    """
    Get the full Wiki URL and pageID from a ConfluenceWikiManager.XXX return value

    :param response: A return value from one of the ConfluenceWikiManager.XXX methods
    :return: A tuple of the form (pageID, fullWikiURL)
    """

    try:
        response = response.json()
    except:
        print "Error: Unable to parse response"
        print "Response: '%s'" % response
        return None

    # Get the Wiki Page ID
    pageID = response.get('id')
    if pageID is None:
        print "Error: Unable to parse page ID from response dict"
        return None

    # Get the full Wiki URL
    linksDict = response.get('_links')
    if linksDict is None:
        print "Error: Unable to parse URL from response dict"
        return None

    baseUrl = linksDict.get('base')
    if baseUrl is None:
        print "Error: Unable to get base URL from links dict"
        return None

    pageUrl = linksDict.get('webui')
    if pageUrl is None:
        print "Error: Unable to obtain the webui/page URL from links dict"
        return None

    wikiUrl = baseUrl + pageUrl

    return (pageID, wikiUrl)


def main():
    """
    Script starts here. Hur dur.

    :return: 0 on exit success; 1 otherwise
    """

    args = parseCommandline()

    # Get password from file if necessary
    if args.passwordfile is not None:
        try:
            with open(args.passwordfile, "r") as f:
                password = f.readlines()[0]
        except IOError:
            print "Error: Unable to open password file: '%s'" % args.passwordfile
            sys.exit(1)
        except IndexError:
            print "Error: Unable to read password from first line of password file: '%s'" % args.passwordfile
            sys.exit(1)
        except:
            print "Error: Unexpected error occurred while trying to read password file."
            traceback.print_exc()
            sys.exit(1)
    elif args.password is not None:
        password = args.password
    else:
        print "Unexpected error: args.password == None == args.passwordfile"
        sys.exit(1)

    # Get body text from file
    bodyText = ""
    if args.body is not None:
        try:
            with open(args.body, "r") as f:
                bodyText = f.read()
        except IOError:
            print "Error: Unable to open/read body text file: '%s'" % args.body
            sys.exit(1)
        except:
            print "Error: Unexpected error occurred while trying to read body text file."
            traceback.print_exc()
            sys.exit(1)

    wiki = ConfluenceWikiManager(ConfluenceWikiManager.GOPRO_WIKI_SERVER, args.username, password)

    # Handle creation of new wiki pages
    if args.action == ACTION_CREATE_NEW_PAGE:
        if args.id is not None:
            ancestors = [{'id': str(args.id)}]
        else:
            ancestors = None

        response = wiki.createPage(args.title, bodyText, args.spacekey, ancestors)
        handleResponse(response)

        wikiPageInfo = getWikiPageInfo(response)
        if wikiPageInfo is None:
            print "Error: Unable to obtain page info from response"
            sys.exit(1)
        pageID,wikiUrl = wikiPageInfo

        print "Page created"
        print "Page ID: %s" % pageID
        print "URL: %s" % wikiUrl

    # Handle deletion of wiki pages
    elif args.action == ACTION_DELETE_EXISTING_PAGE:
        response = wiki.deletePage(args.id)
        DELETE_SUCCESSFUL = 204 # HTTP status code: No content
        if not response.status_code == DELETE_SUCCESSFUL:
            print "Error: Unexpected HTTP response"
            response.raise_for_status()
            sys.exit(1)

        print "Page deleted"

    # Handle attaching files to existing wiki pages
    elif args.action == ACTION_ATTACH_FILE_TO_EXISTING_PAGE:
        response = wiki.attachFileToPage(args.filepath, args.id)
        handleResponse(response)

        print "File attached to page: '%s'" % args.filepath


if __name__ == "__main__":
    main()