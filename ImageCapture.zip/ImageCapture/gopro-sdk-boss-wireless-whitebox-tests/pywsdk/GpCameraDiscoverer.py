#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraDiscoverer.py
# Description: Defines a class that uses mDNS to discover a connected GoPro camera
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import netifaces as ni
import re
import GpCamera
from QAToolbox import *
from zeroconf import *

logger = Logger(Logger.LOG_LEVEL_DEBUG)

class GpZeroconfListener:
    """
    Listens for mDNS responses. Used with Zeroconf
    """
    def __init__(self):
        self.isServiceFound = False
        self.ipAddress = None

    def remove_service(self, zeroconf, type, name):
        pass

    def add_service(self, zeroconf, type, name):
        info = zeroconf.get_service_info(type, name)
        logger.logNoise("Service Info: %s" % info)
        self.ipAddress = ".".join(str(ord(c)) for c in info.address)
        self.isServiceFound = True
        logger.logNoise("Service discovered: %s" % self.ipAddress)


class GpCameraDiscoverer:
    """
    Uses mDNS to discover a connected GoPro camera and obtain its IP address
    """

    def __init__(self):
        self.wakeUpTheCamera()

        service = "_gopro-web._tcp.local."
        zeroconf = Zeroconf()
        zeroconfListener = GpZeroconfListener()
        ServiceBrowser(zeroconf, service, zeroconfListener)
        self.__ipAddress = None

        TIME_BETWEEN_CHECKS = 1.000 # seconds
        MAX_CONNECTION_WAIT_TIME = 10.000 # seconds
        waitTimeElapsed = 0.0 # seconds

        logger.logDebug("Waiting for zeroconf to discover camera...")
        while (not zeroconfListener.isServiceFound) and (waitTimeElapsed <= MAX_CONNECTION_WAIT_TIME):
            time.sleep(TIME_BETWEEN_CHECKS)
            waitTimeElapsed += TIME_BETWEEN_CHECKS

        if (not zeroconfListener.isServiceFound):
            logger.logError("Camera was not discovered within %.2f second time limit" % MAX_CONNECTION_WAIT_TIME)
            sys.exit(1)
        else:
            logger.logDebug("Camera discovered. IP Address: %s" % zeroconfListener.ipAddress)
            self.__ipAddress = zeroconfListener.ipAddress


    def wakeUpTheCamera(self):
        """
        Wake up, silly camera!
        Search through ifconfig information, determine which interface is connected to the GoPro camera,
        then extract the MAC address and send a Wake On Lan (WOL) packet(s) to prod it into wakefulness

        :return: True if there were no errors; False otherwise
        """

        # Find the interface that is connected to the GoPro camera
        regex = re.compile("10\.5\.5\.")
        gpCameraInterface = None

        logger.logDebug("Identifying which network interface is connected to a GoPro camera...")
        for interface in ni.interfaces():
            try:
                interfaceIpAddr = ni.ifaddresses(interface)[ni.AF_INET][0]['addr']
            except KeyError:
                continue

            if (regex.match(interfaceIpAddr) is not None):
                logger.logDebug("Connected GoPro camera found on interface: %s" % interface)
                gpCameraInterface = interface
                break

        if (gpCameraInterface is None):
            logger.logWarning("Unable to determine interface to the camera. Are you connected to the camera?")
            return False

        # Send the WOL packet(s) to wake up the camera
        cameraIpAddress = "10.5.5.9"
        gpCameraMacAddr = ni.ifaddresses(gpCameraInterface)[ni.AF_LINK][0]['addr']
        logger.logDebug("Sending Wake on Lan to camera...")
        sendWakeOnLan(gpCameraMacAddr, cameraIpAddress)
        return True


    def getIpAddress(self):
        return self.__ipAddress


    def getCameraUrl(self):
        return "http://" + self.__ipAddress



#-----------------------------------------------------------------------------------------------------------------------
# Unit Tests
#-----------------------------------------------------------------------------------------------------------------------
def testDiscoverCamera():
    discoverer = GpCameraDiscoverer()
    logger.logDebug("IP Address of Discovered Camera: %s" % discoverer.getIpAddress())
    return True

if (__name__ == "__main__"):
    if (not testDiscoverCamera()):
        logger.logError("testDiscoverCamera failed")
        sys.exit(1)
