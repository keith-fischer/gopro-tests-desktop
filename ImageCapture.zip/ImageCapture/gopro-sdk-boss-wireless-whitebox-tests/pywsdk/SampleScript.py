#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: SampleScript.py
# Description: An example of how to use various features of the PyWSDK
# Author: Sean Foley
# Date Created: 9 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
Background:

The purpose of the PyWSDK is to provide a platform-independent tool to control GoPro cameras.

Before trying to use the SDK, please make sure that your system is connected via WiFi to the GoPro camera you wish
to control.

Due to camera firmware constraints, you almost always have to allow 1-2 polling periods (i.e. 500ms) to elapse before
sending additional commands. This is typically by calling gpCameraObject.waitForPollingPeriod(numPollingPeriods=XXX)
"""

# This should be all you need to import. It imports other things that you might want
from GpCamera import *


def recordVideo(camera):
    """
    Record a video in 1080p, show its filename and then download it

    :param camera: An instantiated GpCamera object
    :return: None
    """

    # Change sub mode to video
    camera.changeSubMode(GpCameraSubModes.VIDEO)
    camera.waitForPollingPeriod()

    # Set resolution to 1080p @ 60fps
    camera.setSetting(GpCameraSetting.VIDEO_RESOLUTION, GpCameraSettingOption.VIDEO_RESOLUTION_1080)
    camera.setSetting(GpCameraSetting.VIDEO_FPS,        GpCameraSettingOption.VIDEO_FPS_60)

    # Record for 5.000 seconds
    camera.setShutter(True)
    camera.sleep(5000)
    camera.setShutter(False)
    camera.waitForPollingPeriod(1)

    # Print out the name of the video we just recorded
    videoFilePath = camera.getMostRecentMediaFilePath(GpMediaType.MEDIA_TYPE_VIDEO)
    videoFilename = videoFilePath.split("/")[-1]
    print "Recorded video: '%s'" % videoFilePath

    # Download video we just took
    videoUrl = camera.getVideoDownloadUri(videoFilePath)
    camera.downloadMedia(videoUrl, videoFilename)


def takePhoto(camera):
    """
    Take some photos, show their filenames and then download them

    :param camera: An instantiated GpCamera object
    :return: None
    """

    # Change sub mode to photo
    camera.changeSubMode(GpCameraSubModes.SINGLE)

    # Set megapixels to 12MP wide
    camera.setSetting(GpCameraSetting.PHOTO_RESOLUTION, GpCameraSettingOption.PHOTO_RESOLUTION_12MP_WIDE)

    # Take several photos
    NUM_PHOTOS = 3
    for i in range(NUM_PHOTOS):
        camera.setShutter(True)
        camera.waitForPollingPeriod(numPollingPeriods=3)  # some cameras need more time after activating shutter

        # Print out name of photo we just took
        photoFilePath = camera.getMostRecentMediaFilePath(GpMediaType.MEDIA_TYPE_PHOTO)
        camera.waitForPollingPeriod()
        photoFilename = photoFilePath.split("/")[-1]
        print "Took photo: '%s'" % photoFilePath

        # Download photo we just took
        photoUrl = camera.getPhotoDownloadUri(photoFilePath)
        camera.waitForPollingPeriod()
        camera.downloadMedia(photoUrl, photoFilename)
        camera.waitForPollingPeriod()


def main():
    """
    Script starts here
    :return: 0 on success; 1 otherwise
    """

    # Discover the camera over mDNS, get its IP/MAC addresses and establish a connection
    camera = GpCamera.connectOnCurrentWiFiNetwork()

    # Examples of how to use the SDK:
    recordVideo(camera)
    takePhoto(camera)


if __name__ == "__main__":
    main()

