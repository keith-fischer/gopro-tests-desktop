#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpControlManager.py
# Description: A helper class that simplifies obtaining REST URLs to control the GoPro camera
# Author: Sean Foley
# Date Created: 1 March 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import pprint
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_WARNING)

# Note: gpControl definitions and explanations can be found here:
#       https://wiki.gopro.com/display/SSP/gpControl+Command+Definitions

class GpControlManager:
    """
    A helper class that simplifies obtaining RESTful gpControl URLs to control the GoPro camera
    """

    # Setup commands
    SET_LOCATE             = '/gp/gpControl/command/system/locate?p=%s'
    SET_DATE               = '/gp/gpControl/command/setup/date_time?p=%%%02x%%%02x%%%02x%%%02x%%%02x%%%02x'

    # Media commands
    DELETE_FILE            = '/gp/gpControl/command/storage/delete?p=%s'
    DELETE_ALL_FILES       = '/gp/gpControl/command/storage/delete/all'
    DELETE_LAST_FILE       = '/gp/gpControl/command/storage/delete/last'
    GET_MEDIA_LIST         = '/gp/gpMediaList'
    GET_VIDEO_METADATA     = '/gp/gpMediaMetadata?p=%s&t=videoinfo'

    # Settings/Status commands
    SETTINGS               = '/gp/gpControl'
    STATUS                 = '/gp/gpControl/status'
    SET_SETTING            = '/gp/gpControl/setting/%s/%s'

    # Camera Control commands
    SET_SHUTTER            = '/gp/gpControl/command/shutter?p=%s'
    CHANGE_MODE            = '/gp/gpControl/command/mode?p=%s'
    CHANGE_SUB_MODE        = '/gp/gpControl/command/sub_mode?mode=%s&sub_mode=%s'
    TAG_MOMENT             = '/gp/gpControl/command/storage/tag_moment'
    SLEEP                  = '/gp/gpControl/command/system/sleep' # warning: can't send more URLs after this!

    # Camera as a Hub: Transcode Manager Commands
    GET_TRANSCODE_HISTORY  = '/gp/gpControl/command/transcode/history'
    GET_TRANSCODE_ESTIMATE = '/gp/gpControl/command/transcode/estimate?source=DCIM/%s&' + \
                             'res=%s&' + \
                             'fps_divisor=%s&' + \
                             'in_ms=%s&' + \
                             'out_ms=%s'
    START_TRANSCODE        = '/gp/gpControl/command/transcode/request?source=DCIM/%s&' + \
                             'res=%s&' + \
                             'fps_divisor=%s&' + \
                             'in_ms=%s&' + \
                             'out_ms=%s'
    GET_TRANSCODE_STATUS   = '/gp/gpControl/command/transcode/status?id=%s'
    CANCEL_TRANSCODE       = '/gp/gpControl/command/transcode/cancel?id=%s'

    # WiFi commands
    SSID_SCAN              = '/gp/gpControl/command/wireless/ssid/scan?p=1'  # Value is always 1
    SSID_LIST              = '/gp/gpControl/command/wireless/ssid/list'
    SSID_SAVE              = None # TODO
    SSID_SELECT            = 'gp/gpControl/command/wireless/ssid/select?ssid=%s&auth_type=%s&pw=%s'
    SSID_DELETE            = None # TODO
