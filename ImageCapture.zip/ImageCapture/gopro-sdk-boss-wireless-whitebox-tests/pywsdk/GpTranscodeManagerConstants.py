#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpTranscodeManagerSettings.py
# Description: Lookup table for Camera As a Hub (CAH) Transcode Manager settings
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

# Source: https://wiki.gopro.com/display/SSP/gpControl+Command+Definitions

class GpTranscodeManagerResponse:
    """
    A lookup table of transcode manager response keys
    """
    KEY_COMPLETION_PERCENTAGE = "completion"
    KEY_ESTIMATED_TIME_IN_SEC = "estimate"
    KEY_FAILURE_REASON        = "failure_reason"
    KEY_ID                    = "id"
    KEY_SOURCE_FILENAME       = "source"
    KEY_STATUS_DICT           = "status"
    KEY_TRANSCODE_STATUS      = "status"
    KEY_TRANSCODED_FILENAME   = "output"


class GpTranscodeManagerSettings:
    """
    A lookup table of transcode manager settings
    """

    # Pixel dimensions for each resolution (width,height)
    DIMENSIONS_4K          = (3840, 2160)
    DIMENSIONS_2_7K        = (2704, 1520)
    DIMENSIONS_2_7K_4_BY_3 = (2704, 1520)
    DIMENSIONS_1440P       = (1920, 1440)
    DIMENSIONS_1080P       = (1920, 1080)
    DIMENSIONS_960P        = (1280, 960)
    DIMENSIONS_720P        = (1280, 720)
    DIMENSIONS_WVGA        = (848, 480)

    # From source: &res={0 = 1080, 1 = 960, 2 = 720, 3 = WVGA, 4 = 640x480, 5 = 432x240, 6 = 320x240}
    RESOLUTION_1080       = "0"
    RESOLUTION_960        = "1"
    RESOLUTION_720        = "2"
    RESOLUTION_WVGA       = "3"
    RESOLUTION_640_BY_480 = "4"
    RESOLUTION_432_BY_240 = "5"
    RESOLUTION_320_BY_240 = "6"

    # Note: The transcoder has the option of taking, for example, a 60fps video and making it be 30fps.
    #       To do this, it uses an "fps divisor". To change 60fps into 30fps, you divide the fps by 2, so the
    #       fps divisor would be 2 in this case.
    #
    # From source: &fps_divisor={0 = 1/1, 1 = 1/2, 2 = 1/3, 3 = 1/4, 4 = 1/8}
    FPS_DIVISOR_1 = "0"
    FPS_DIVISOR_2 = "1"
    FPS_DIVISOR_3 = "2"
    FPS_DIVISOR_4 = "3"
    FPS_DIVISOR_8 = "4"

    # From source:
    #   &in_ms={clip in time in mS, 0 = start of file}
    #   &out_ms={clip out time in mS, 0 = end of file}
    CLIP_IN_TIME_START_OF_FILE = "0"
    CLIP_OUT_TIME_END_OF_FILE  = "0"


class GpTranscodeManagerStatus:
    """
    A lookup table of transcode manager status values
    """

    # status: 0 = TRANSCODE_STARTED,
    #         1 = TRANSCODE_IN_PROGRESS,
    #         2 = TRANSCODE_JOB_COMPLETE,
    #         3 = TRANSCODE_CANCEL_COMPLETE,
    #         4 = TRANSCODE_FAILED.
    STATUS_TRANSCODE_STARTED         = 0
    STATUS_TRANSCODE_IN_PROGRESS     = 1
    STATUS_TRANSCODE_JOB_COMPLETE    = 2
    STATUS_TRANSCODE_CANCEL_COMPLETE = 3
    STATUS_TRANSCODE_FAILED          = 4


class GpTranscodeManagerFailure:
    """
    A lookup table of transcode manager failure types
    """

    # failure_reason:  0 = NONE,
    #                 -1 = BAD_FILE,
    #                 -2 = BAD_CONFIG,
    #                 -3 = INSUFFICIENT_SD,
    #                 -4 = BUSY,
    #                 -256 UNKNOWN
    FAILURE_REASON_NONE            = 0
    FAILURE_REASON_BAD_FILE        = -1
    FAILURE_REASON_BAD_CONFIG      = -2
    FAILURE_REASON_INSUFFICIENT_SD = -3
    FAILURE_REASON_BUSY            = -4
    FAILURE_REASON_UNKNOWN         = -256

class GpTranscodeManagerHistory:
    """
    A lookup table of transcode manager history keys
    """
    KEY_HISTORY = "history"
