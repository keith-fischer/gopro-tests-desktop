#!/usr/bin/python

import sys
from GpCameraDiscoverer import *


# Find the camera
discoverer = GpCameraDiscoverer()
cameraUrl = discoverer.getCameraUrl()
camera = GpCamera(cameraUrl)

camera.changeMode(GpCameraModes.MODE_SETUP)
camera.waitForPollingPeriod()

validLCDSleepTimes = (GpCameraSettingOption.SETUP_LCD_SLEEP_NEVER,
                      GpCameraSettingOption.SETUP_LCD_SLEEP_1_MIN,
                      GpCameraSettingOption.SETUP_LCD_SLEEP_2_MIN,
                      GpCameraSettingOption.SETUP_LCD_SLEEP_3_MIN)

for validSleepTime in validLCDSleepTimes:
    success = camera.setSetting(GpCameraSetting.SETUP_LCD_SLEEP, validSleepTime)

    sleepTimeDescription = validSleepTime[0]
    if (not success):
        logger.logError("Unable to set LCD sleep time to: %s" % sleepTimeDescription)

    camera.waitForPollingPeriod()

