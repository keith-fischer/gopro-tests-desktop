#!/usr/bin/python
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# File: TranscodeManagerTests.py
# Description: A test suite of positive and negative tests for the Camera As a Hub (CAH) Transaction Manager feature
# Author: Sean Foley
# Date Created: 28 March 2016
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

import inspect
import math
import os

from GpCameraDiscoverer import *
from IntegrationTestBase import *


class TranscodeManagerTests(IntegrationTestBase):

    # ------------------------------------------------------------------------------------------------------------------
    # Helper methods
    # ------------------------------------------------------------------------------------------------------------------
    def logCurrentTestName(self):
        """
        Print the current test name (warning: This only works with Python 2.7)
        :return: None
        """

        msg = "Test: %s" % inspect.stack()[1][3]
        colorizedMsg = getColorString(msg, PrintColors.COLOR_GREEN)
        logger.logDebug(colorizedMsg)


    def recordVideo(self, durationInMs):
        """
        Record a video

        :param durationInMs: The duration of the video, in milliseconds
        :return: None
        """

        # Record a short video
        self.camera.changeSubMode(GpCameraSubModes.VIDEO)
        self.camera.waitForPollingPeriod()
        self.camera.setShutter(True)
        self.camera.sleep(durationInMs)
        self.camera.setShutter(False)
        self.camera.waitForPollingPeriod()


    def getPathOfLastVideoRecorded(self):
        """
        Get the file path of the last video recorded

        :return: The file path of the last video recorded
        """

        mediaList = self.camera.getMediaList()
        if (mediaList is None):
            self.fail("Unable to get media list from camera")

        filename = GpCamera.getMostRecentMediaFile(mediaList, GpMediaType.MEDIA_TYPE_VIDEO)
        if (filename is None):
            self.fail("Unable to get path of short video we just recorded")
        self.camera.waitForPollingPeriod()

        return filename


    def getTranscodeStatus(self, transcodeId):
        """
        Get transcode status for a certain transcode ID

        :param transcodeId: The ID of a transcode process
        :return: The camera's response to a transcode query request
        """

        status = self.camera.getTranscodeStatus(transcodeId)
        if (status is None):
            self.fail("Unable to get transcode status")

        return status


    def getTranscodeStatusValue(self, statusJson, statusKey):
        """
        Get a certain value from the camera's response to a transcode status query

        :param statusJson: The camera's JSON response to a query for transcode status
        :param statusKey: One of GpTranscodeManagerResponse.KEY_XXX values
        :return: The value associated with statusKey in the transcode manager status (see note below)
        """

        """
        Note: Transcode status looks like this:

        {u'status': {u'completion': 0,
             u'estimate': 5,
             u'failure_reason': 0,
             u'id': 429496729674,
             u'output': u'',
             u'source': u'DCIM\\100GOPRO\\GOPR0074.MP4',
             u'status': 0}}
        """

        statusDict = statusJson.get(GpTranscodeManagerResponse.KEY_STATUS_DICT)
        if (statusDict is None):
            self.fail("Unable to get status key from transcode status response:\nResponse: %s" % statusJson)

        value = statusDict.get(statusKey)
        if (value is None):
            self.fail("Unable to get key '%s' from transcode manager status:\n%s" % (statusKey,
                                                                                     pprint.pformat(statusDict)))

        return value


    # ------------------------------------------------------------------------------------------------------------------
    # Positive tests: Basic Acceptance
    # ------------------------------------------------------------------------------------------------------------------
    def testGetTranscodeHistory(self):
        """
        Make sure that queries to the camera for transcode history work

        :return: None
        """

        self.logCurrentTestName()

        jsonResponse = self.camera.getTranscodeHistory()
        self.camera.waitForPollingPeriod()

        history = jsonResponse.get(GpTranscodeManagerHistory.KEY_HISTORY)
        if (history is None):
            self.fail("Unable to get history from camera response")

        logger.logError("TODO: Verify more content from the response when it is available")
        if (history != []):
            # TODO: Verify the content and form of each history item
            pass


    def testGetTranscodeEstimate(self):
        """
        Verify that there are no problems with obtaining a transcode estimate

        :return: None
        """

        self.logCurrentTestName()

        self.recordVideo(10000) # ms
        filePath = self.getPathOfLastVideoRecorded()

        # Get an estimate of how long it would take to transcode the entire video we just recorded down to WVGA
        # resolution with the same frame rate
        estimateInSec = self.camera.getTranscodeEstimate(filePath,
                                                         GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                         GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                         GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                         GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        # TODO: Consider a better form of verification than the below
        if (estimateInSec < 2):
            self.fail("Suspiciously low transcoding time estimate: %d seconds" % estimateInSec)


    def testStartTranscode(self):
        """
        Verify that a transcode can be started

        :return: None
        """

        self.logCurrentTestName()

        self.recordVideo(10000) # ms
        filePath = self.getPathOfLastVideoRecorded()

        estimateInSec = self.camera.getTranscodeEstimate(filePath,
                                                         GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                         GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                         GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                         GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        # Start transcoding the video we just recorded into WVGA resolution (same frame rate, whole file)
        transcodeId = self.camera.startTranscode(filePath,
                                                 GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                 GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                 GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                 GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        if (transcodeId is None):
            self.fail("Unable to start transcoding of file: '%s'" % filePath)
        else:
            self.camera.sleep(estimateInSec * 1000) # ms


    def testGetTranscodeStatus(self):
        """
        Verify that the status of the transcode manager is what we expect

        :return: None
        """

        self.logCurrentTestName()

        self.recordVideo(10000) # ms
        filePath = self.getPathOfLastVideoRecorded()
        POLL_PERIOD = 500 # ms

        estimateInSec = self.camera.getTranscodeEstimate(filePath,
                                                         GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                         GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                         GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                         GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        # Start transcoding the video we just recorded into WVGA resolution (same frame rate, whole file)
        transcodeId = self.camera.startTranscode(filePath,
                                                 GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                 GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                 GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                 GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        timeElapsedInMs = 0
        logger.logDebug("Verifying that status has all expected keys...")
        while (timeElapsedInMs <= (estimateInSec*1000)):
            status = self.getTranscodeStatus(transcodeId)
            self.camera.waitForPollingPeriod()
            logger.logNoise("Time Elapsed: %d ms, Status:\n%s" % (timeElapsedInMs, pprint.pformat(status)))

            # Verify that all expected keys are present in the response
            self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_ESTIMATED_TIME_IN_SEC)
            self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_FAILURE_REASON)
            self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_ID)
            self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_TRANSCODED_FILENAME)
            self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_SOURCE_FILENAME)
            self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_TRANSCODE_STATUS)

            self.camera.sleep(POLL_PERIOD)
            timeElapsedInMs += POLL_PERIOD


    def testCancelTranscode(self):
        """
        Test transcode manager's ability to cancel an in-progress transcode

        :return: None
        """

        self.logCurrentTestName()

        self.recordVideo(10000)
        filePath = self.getPathOfLastVideoRecorded()

        estimateInSec = self.camera.getTranscodeEstimate(filePath,
                                                         GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                         GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                         GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                         GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        # Start transcoding the video we just recorded into WVGA resolution (same frame rate, whole file)
        transcodeId = self.camera.startTranscode(filePath,
                                                 GpTranscodeManagerSettings.RESOLUTION_WVGA,
                                                 GpTranscodeManagerSettings.FPS_DIVISOR_1,
                                                 GpTranscodeManagerSettings.CLIP_IN_TIME_START_OF_FILE,
                                                 GpTranscodeManagerSettings.CLIP_OUT_TIME_END_OF_FILE)
        self.camera.waitForPollingPeriod()

        # Verify that the transcode status becomes <STARTED> or <IN PROGRESS>
        status = self.getTranscodeStatus(transcodeId)
        self.camera.waitForPollingPeriod()
        transcodeStatus = self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_TRANSCODE_STATUS)

        if (transcodeStatus not in (GpTranscodeManagerStatus.STATUS_TRANSCODE_STARTED,
                                    GpTranscodeManagerStatus.STATUS_TRANSCODE_IN_PROGRESS)):
            self.fail("Transcode status is not <STARTED> or <IN PROGRESS>")

        # Cancel the transcode
        self.camera.cancelTranscode(transcodeId)
        self.waitForPollingPeriod()

        MAX_WAIT_TIME_FOR_CANCEL_COMPLETE = 5000 # ms
        POLL_PERIOD = 500 # ms
        timeElapsedInMs = 0

        while (timeElapsedInMs <= MAX_WAIT_TIME_FOR_CANCEL_COMPLETE):
            print "Bughunter DEBUG -----> Time Elapsed: %d (max: %d)" % (timeElapsedInMs, MAX_WAIT_TIME_FOR_CANCEL_COMPLETE)
            status = self.getTranscodeStatus(transcodeId)
            transcodeStatus = self.getTranscodeStatusValue(status, GpTranscodeManagerResponse.KEY_TRANSCODE_STATUS)

            if (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_JOB_COMPLETE):
                self.fail("Oops... transcode completed before we could cancel...")
            elif (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_CANCEL_COMPLETE):
                break

            t1 = time.time()
            self.waitForPollingPeriod()
            t2 = time.time()
            timeElapsedInMs += int(math.ceil(t2 - t1)) * 1000

            #self.camera.sleep(POLL_PERIOD)
            #timeElapsedInMs += POLL_PERIOD

        if (transcodeStatus != GpTranscodeManagerStatus.STATUS_TRANSCODE_CANCEL_COMPLETE):
            self.fail("Failed to cancel the in-progress transcode")


    # ------------------------------------------------------------------------------------------------------------------
    # Positive tests: Functional
    # ------------------------------------------------------------------------------------------------------------------
    def testTranscodeVideo(self):
        """
        Verify that we are able to successfully transcode a video

        :return: None
        """

        """
        From Testrail:
        https://testrail.gopro.lcl/index.php?/suites/view/10650&
                group_by=cases:section_id&
                group_order=asc&
                group_id=129802

		C1465533	4k 12.5 fps -> 1080p 12.5 fps / 15Mbps
        C1465532	4k 15 fps -> 1080p 15 fps / 15Mbps
        C1465276	2.7k 4:3 25 fps -> 1080p 25 fps / 15Mbps
        C1465531	Source video at/above 1080p 24 fps -> 1080p 24 fps / 15Mbps
        C1465530	Source video at/above 1080p 25 fps -> 1080p 25 fps / 15Mbps
        C1465171	Source video at/above 1080p 30 fps -> 1080p 30 fps / 15Mbps
        C1465529	Source video at/above 1080p 48 fps -> 1080p 48 fps / 15Mbps
        C1465528	Source video at/above 1080p 50 fps -> 1080p 50 fps / 15Mbps
        C1465172	Source video at/above 1080p 60 fps -> 1080p 60 fps / 15Mbps
        C1465527	Source video at/above 1080p 80 fps -> 1080p 80 fps / 15Mbps
        C1465173	Source video at/above 1080p 90 fps -> 1080p 90 fps / 15Mbps
        C1465526	Source video at/above 1080p 120 fps -> 1080p 120 fps / 15Mbps
        C1465175	960p 120 fps -> 960p 120 fps / 15Mbps
        C1465176	960p 100 fps -> 960p 100 fps / 15Mbps
        C1465177	960p 30 fps -> 960p 30 fps / 15Mbps
        C1465535	960p 25 fps -> 960p 25 fps / 15Mbps
        C1465178	720p 240 fps -> 720p 240 fps / 15Mbps
        C1465179	720p 60 fps -> 720p 60 fps / 15Mbps
        C1465534	720p 50 fps -> 720p 50 fps / 15Mbps
        C1465180	480p 240 fps -> 480p 240 fps / 15Mbps
        """

        self.logCurrentTestName()




    # ------------------------------------------------------------------------------------------------------------------
    # Negative tests
    # ------------------------------------------------------------------------------------------------------------------


    # ------------------------------------------------------------------------------------------------------------------
    # Stress tests
    # ------------------------------------------------------------------------------------------------------------------
    def ___testEstimateAccuracy(self):
        """
        Verify that the camera's estimate of how long it will take to transcode is relatively accurate

        :return: None
        """

        self.logCurrentTestName()

        pass



if (__name__ == "__main__"):
    ENV_GENERATE_XML_REPORT = "GENERATE_XML_REPORT"
    GENERATE_REPORT_TRUE = "1"

    if (os.environ.get(ENV_GENERATE_XML_REPORT) == GENERATE_REPORT_TRUE):
        print "Running test suite and generating XML output..."
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output="test-reports"))
    else:
        print "Running test suite and sending result to stdout..."
        unittest.main()
