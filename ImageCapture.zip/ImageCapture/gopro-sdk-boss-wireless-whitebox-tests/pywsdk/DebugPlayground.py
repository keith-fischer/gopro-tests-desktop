#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: DebugTesting.py
# Description: Used to test PyWSDK during development
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

from GpCamera import *
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_DEBUG)

#-----------------------------------------------------------------------------------------------------------------------
# Method: main
#-----------------------------------------------------------------------------------------------------------------------
def main():
    camera = GpCamera.connectOnCurrentWiFiNetwork()

    """
    camera.snapshotSsidScanResults()
    ssidList = camera.listSsidScanResults()

    ssidName = "GP-LABs"
    ssidPassword = "g0proqaL4bs"

    ssidSelected = None
    for ssid in ssidList:
        if ssid['ssid'] == ssidName:
            ssidSelected = ssid

    if ssidSelected is None:
        logger.logError("Failed to find desired SSID")
        sys.exit(1)

    camera.connectToSsid(ssidSelected['ssid'], ssidSelected['auth_type'], ssidPassword)
    """










def testSetDate(camera):
    """
    Test to figure out why I can't seem to successfully send the date to the camera

    :param camera: An initialized GpCamera object
    :return: None
    """

    d = datetime.date(16, 10, 20)  # Date: November 20, 2016
    t = datetime.time(12, 34, 56)  # Time: 12:34:56 AM
    dt = datetime.datetime.combine(d, t)
    camera.setDateTime(dt)

    # TODO: Determine why the date isn't being set when we post the URL to the camera (but it does in a web browser)
    #import requests
    ##url = "http://10.5.5.9/gp/gpControl/command/system/locate?p=0"   # disable locate
    #url = "http://10.5.5.9/gp/gpControl/command/setup/date_time?p=%10%0a%14%0c%22%38".replace("%", "\%")
    #print "\nURL: %s" % url
    #response = requests.post(url)
    #print "Response: %s (%s)" % (response.status_code, response.reason)




if (__name__ == "__main__"):
    main()
