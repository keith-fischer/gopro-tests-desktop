#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpOAuthManager.py
# Description: Provides a utility to obtain OAuth tokens for accessing GoPro's staging/production APIs
# Author: Sean Foley
# Date Created: 25 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import requests
import sys
import GpCloudManager as gpcm
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_DEBUG)

class GpOAuthManager:
    def __init__(self, username, password, environment):
        """
        Initializer

        :param username: The username (i.e. email address) used to access GoPro's cloud API
        :param password: The password used to access GoPro's cloud API
        :param environment: A dict from one of the GpCloudManager.ENVIRONMENT_XXX values
        :return: None
        """

        self.__username = username
        self.__password = password
        self.__environment = environment

        # Sanity check
        for key in ('description', 'base_url', 'client_id', 'client_secret'):
            if key not in self.__environment:
                logger.logError("Expected key '%s' not found in environment\n%s" % (key,self.__environment))
                sys.exit(1)


    def getToken(self):
        """
        Get an OAuth access token from the remote server

        :return: The token as a string or None if there was an error
        """

        url = "%s/v1/oauth2/token" % self.__environment.get('base_url')
        headers = {'Content-Type': 'application/json'}
        data = {
            "client_id": self.__environment.get('client_id'),
            "client_secret": self.__environment.get('client_secret'),
            "grant_type": "password",
            "scope": "root root:channels public me upload media_library_beta live",
            "username": self.__username,
            "password": self.__password
        }

        response = requests.post(url, data)

        try:
            response.raise_for_status()
            responseJson = response.json()
        except:
            logger.logError("Unexpected response from GoPro server:")
            traceback.print_exc()
            return None

        logger.logDebug("Response:\n%s" % pprint.pformat(responseJson))

        token = responseJson.get('access_token')
        if token is None:
            logger.logError("Unable to get token from response")
            return None

        return token


#-----------------------------------------------------------------------------------------------------------------------
# Informal unit testing
#-----------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) != 3+1:
        print "Usage: %s <email address> <password> <production | staging>" % sys.argv[0]
        print "Example: %s dmurphy password1234 production" % sys.argv[0]
        sys.exit(1)
    username,password,environment = sys.argv[1:]

    if environment == "production":
        environment = gpcm.GpCloudManager.ENVIRONMENT_PRODUCTION
    elif environment == "staging":
        environment = gpcm.GpCloudManager.ENVIRONMENT_STAGING
    else:
        logger.logError("Invalid value for <environment>: '%s'" % environment)
        sys.exit(1)

    auth = GpOAuthManager(username, password, environment)
    token = auth.getToken()

    print "Token: %s" % token
