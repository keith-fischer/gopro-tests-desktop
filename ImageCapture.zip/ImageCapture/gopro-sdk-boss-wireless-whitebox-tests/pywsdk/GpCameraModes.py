#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraModeGroups.py
# Description: A data structure class that holds GoPro camera mode groups
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class GpCameraModes:
    """
    Data structure class that holds GoPro camera mode groups
    """

    # Note: These values are hard-coded from the camera's settings JSON data (gp/gpControl)
    MODE_VIDEO      = "video"
    MODE_PHOTO      = "photo"
    MODE_MULTI_SHOT = "multi_shot"
    MODE_PLAYBACK   = "playback"
    MODE_SETUP      = "setup"
