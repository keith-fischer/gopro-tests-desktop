#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: testRockyPointCrash.py
# Description: A crash has been observed in ETA, Smarty, Android WSDK and PyWSDK where the RockyPoint v02.00 camera
#              will crash. Here, we try to reproduce it without using the iOS/Android/Embedded-Linux WSDK
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import time
from GpCamera import *
from GpCameraDiscoverer import *
from GpCameraModes import *
from GpCameraSubModes import *


def main():
    # Find the camera
    discoverer = GpCameraDiscoverer()
    cameraUrl = discoverer.getCameraUrl()
    camera = GpCamera(cameraUrl)

    #--------------------------------
    camera.waitForPollingPeriod()
    camera.deleteAllFilesOnSdCard()
    camera.waitForPollingPeriod(2)
    #--------------------------------

    camera.changeSubMode(GpCameraSubModes.SINGLE)
    camera.waitForPollingPeriod()

    for i in range(50):
        camera.setShutter(True)
        camera.waitForPollingPeriod(2)



if (__name__ == "__main__"):
    main()