#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraInfo.py
# Description: Stores information (MAC address, SSID, model name, etc) about a GoPro camera and provides a
#   convenient API to access the data
# Author: Sean Foley
# Date Created: 29 February 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

from QAToolbox import *
import GpCameraStatusConstants

logger = Logger(Logger.LOG_LEVEL_WARNING)

class GpCameraInfo:
    """
    Stores information about a GoPro camera and provides a convenient API to access it
    """

    # Static class variables
    UNKNOWN_VALUE = "???"

    # Dictionary keys for self.__cameraInfoDict
    LABEL_AP_MAC_ADDR            = "AP Mac Address"
    LABEL_AP_SSID                = "AP SSID"
    LABEL_BOARD_TYPE             = "Board Type"
    LABEL_FW_VERSION             = "Firmware Version"
    LABEL_MODEL_NAME             = "Model Name"
    LABEL_SERIAL_NUMBER          = "Serial Number"
    LABEL_WIFI_BARS              = "Wifi Bars"
    LABEL_REMAINING_PHOTOS       = "Photos Remaining"
    LABEL_REMAINING_VTIME        = "Video Time Remaining"
    LABEL_REMAINING_SPACE        = "Space Remaining (MB)"
    LABEL_INTERNAL_BATTERY_LEVEL = "Internal Battery Level"


    def __init__(self, settingsJson, jsonHelper):
        """
        Class initializer

        :param settingsJson: A python dict of JSON data from gp/gpControl on the GoPro camera
        :param jsonHelper: A GpCameraJsonHelper object to help get and parse tricky JSON status info
        :return: None
        """

        # Dictionary keys for GoPro camera settings JSON data (i.e. settingsJson)
        KEY_JSON_CAMERA_INFO = "info"
        KEY_STATUS           = "status"
        KEY_AP_MAC_ADDR      = "ap_mac"
        KEY_AP_SSID          = "ap_ssid"
        KEY_BOARD_TYPE       = "board_type"
        KEY_FW_VERSION       = "firmware_version"
        KEY_MODEL_NAME       = "model_name"
        KEY_SERIAL_NUMBER    = "serial_number"

        # Dictionary keys for GoPro camera status JSON data (i.e. statusJson)
        KEY_WIFI_BARS              = GpCameraStatusConstants.STATUS_WIFI_BARS
        KEY_REMAINING_PHOTOS       = GpCameraStatusConstants.STATUS_REMAINING_PHOTOS
        KEY_REMAINING_VTIME        = GpCameraStatusConstants.STATUS_REMAINING_VIDEO_TIME
        KEY_REMAINING_SPACE        = GpCameraStatusConstants.STATUS_REMAINING_SPACE
        KEY_INTERNAL_BATTERY_LEVEL = GpCameraStatusConstants.STATUS_INTERNAL_BATTERY_LEVEL

        try:
            infoDict = settingsJson[KEY_JSON_CAMERA_INFO]
        except KeyError:
            logger.logError("Unable to get info from JSON dict with key: %s" % KEY_JSON_CAMERA_INFO)
            infoDict = {}

        statusValuesDict = jsonHelper.getStatusValues( [KEY_WIFI_BARS,
                                                        KEY_REMAINING_PHOTOS,
                                                        KEY_REMAINING_VTIME,
                                                        KEY_REMAINING_SPACE,
                                                        KEY_INTERNAL_BATTERY_LEVEL])

        d = {}
        try:
            d[GpCameraInfo.LABEL_AP_MAC_ADDR]      = self.__getValueFromDict(KEY_AP_MAC_ADDR,      infoDict)
            d[GpCameraInfo.LABEL_AP_SSID]          = self.__getValueFromDict(KEY_AP_SSID,          infoDict)
            d[GpCameraInfo.LABEL_BOARD_TYPE]       = self.__getValueFromDict(KEY_BOARD_TYPE,       infoDict)
            d[GpCameraInfo.LABEL_FW_VERSION]       = self.__getValueFromDict(KEY_FW_VERSION,       infoDict)
            d[GpCameraInfo.LABEL_MODEL_NAME]       = self.__getValueFromDict(KEY_MODEL_NAME,       infoDict)
            d[GpCameraInfo.LABEL_SERIAL_NUMBER]    = self.__getValueFromDict(KEY_SERIAL_NUMBER,    infoDict)

            d[GpCameraInfo.LABEL_WIFI_BARS] = self.__getValueFromDict(
                GpCameraStatusConstants.STATUS_WIFI_BARS,
                statusValuesDict)

            d[GpCameraInfo.LABEL_REMAINING_PHOTOS] = self.__getValueFromDict(
                KEY_REMAINING_PHOTOS,
                statusValuesDict)

            d[GpCameraInfo.LABEL_REMAINING_VTIME] = self.__getValueFromDict(
                KEY_REMAINING_VTIME,
                statusValuesDict)

            d[GpCameraInfo.LABEL_REMAINING_SPACE] = self.__getValueFromDict(
                KEY_REMAINING_SPACE,
                statusValuesDict)

            batteryLevelRaw = self.__getValueFromDict(
                GpCameraStatusConstants.STATUS_INTERNAL_BATTERY_LEVEL,
                statusValuesDict)

            # The following rules come from a comment by Patrick Fitzpatrick in the wiki page below
            # https://wiki.gopro.com/display/SSP/gpControl+Status
            if (batteryLevelRaw == 0):
                batteryLevelStr = "0 bars"
            elif (batteryLevelRaw == 1):
                batteryLevelStr = "1 bar"
            elif (batteryLevelRaw == 2):
                batteryLevelStr = "2 bars"
            elif (batteryLevelRaw == 3):
                batteryLevelStr = "full"
            elif (batteryLevelRaw == 4):
                batteryLevelStr = "charging"
            else:
                logger.logError("Unexpected batteryLevelRaw value: '%s'" % batteryLevelRaw)
                batteryLevelStr = GpCameraInfo.UNKNOWN_VALUE

            d[GpCameraInfo.LABEL_INTERNAL_BATTERY_LEVEL] = batteryLevelStr

        except KeyError as e:
            logger.logWarning("Expected key not found. Camera info may be incomplete. Error: %s" % e.message)
        finally:
            self.__cameraInfoDict = d

        """
        # The main dictionary holding clear human-readable camera information
        self.__cameraInfoDict = { self.__KEY_AP_MAC_ADDR      : self.__getValueFromDict(KEY_AP_MAC_ADDR,      infoDict),
                                  self.__KEY_AP_SSID          : self.__getValueFromDict(KEY_AP_SSID,          infoDict),
                                  self.__KEY_BOARD_TYPE       : self.__getValueFromDict(KEY_BOARD_TYPE,       infoDict),
                                  self.__KEY_FW_VERSION       : self.__getValueFromDict(KEY_FW_VERSION,       infoDict),
                                  self.__KEY_MODEL_NAME       : self.__getValueFromDict(KEY_MODEL_NAME,       infoDict),
                                  self.__KEY_SERIAL_NUMBER    : self.__getValueFromDict(KEY_SERIAL_NUMBER,    infoDict),
                                  self.__KEY_WIFI_BARS        : self.__getValueFromDict(KEY_WIFI_BARS,        infoDict),
                                  self.__KEY_REMAINING_PHOTOS : self.__getValueFromDict(KEY_REMAINING_PHOTOS, infoDict),
                                  self.__KEY_REMAINING_VTIME  : self.__getValueFromDict(KEY_REMAINING_VTIME,  infoDict),
                                  self.__KEY_REMAINING_SPACE  : self.__getValueFromDict(KEY_REMAINING_SPACE,  infoDict)
                                  }
        """


    # ------------------------------------------------------------------------------------------------------------------
    # Getters
    # ------------------------------------------------------------------------------------------------------------------
    def getInfo(self):
        return self.__cameraInfoDict


    def getInfoString(self):
        maxKeyLength = max( [len(x) for x in self.__cameraInfoDict.keys()] )
        s = ""

        for key in self.__cameraInfoDict:
            whitespacePaddingSize = 3
            whitespace = " " * ((maxKeyLength - len(key)) + whitespacePaddingSize)
            s += "%s:%s%s\n" % (key, whitespace, self.__cameraInfoDict[key])

        s = s.rstrip()
        return s


    def getMacAddr(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_AP_MAC_ADDR]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    def getSsid(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_AP_SSID]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    def getBoardType(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_BOARD_TYPE]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    def getFirmwareVersion(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_FW_VERSION]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    def getModelName(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_MODEL_NAME]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    def getSerialNumber(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_SERIAL_NUMBER]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    def getInternalBatteryLevel(self):
        try:
            return self.__cameraInfoDict[GpCameraInfo.LABEL_INTERNAL_BATTERY_LEVEL]
        except KeyError:
            return GpCameraInfo.UNKNOWN_VALUE


    # ------------------------------------------------------------------------------------------------------------------
    # Private member functions
    # ------------------------------------------------------------------------------------------------------------------
    def __getValueFromDict(self, key, jsonDict):
        """
        Helper method: Attempt to get a key from a dict of JSON data. If a problem occurs, output warning

        :param key: A key into jsonDict
        :param jsonDict: A python dict of JSON data
        :return: The jsonDict[key] if the key is presentin the dict; None otherwise
        """

        if (key not in jsonDict):
            errMsg = "Unable to get key [%s] from dict\n" % key
            errMsg += "Dict: %s" % pprint.pformat(jsonDict)
            logger.logWarning(errMsg)
            return GpCameraInfo.UNKNOWN_VALUE
        else:
            return jsonDict[key]


