#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraJsonHelper.py
# Description: A helper class designed to make handling the GoPro camera's JSON responses easier
#              Such tasks include but are not limited to:
#              * Getting a specific status value (e.g. "is locate turned on right now?")
#              * Getting the camera's current mode or submode
# Author: Sean Foley
# Date Created: 26 February 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
This list gp/gpControl/status IDs and their corresponding names is generated from calling printCameraStatusIdDict()

1  internal_battery_present
2  internal_battery_level
3  external_battery_present
4  external_battery_level
6  system_hot
8  system_busy
9  quick_capture_active
10  encoding_active             <---- this indicates whether the shutter is active
11  lcd_lock_active
13  video_progress_counter
14  broadcast_progress_counter
15  broadcast_viewers_count
16  broadcast_bstatus
17  enable
19  state
20  type
21  pair_time
22  state
23  scan_time_msec
24  provision_status
26  remote_control_version
27  remote_control_connected
28  pairing
29  wlan_ssid
30  ap_ssid
31  app_count
32  enable
33  sd_status
34  remaining_photos
35  remaining_video_time
36  num_group_photos
37  num_group_videos
38  num_total_photos
39  num_total_videos
40  date_time
41  ota_status
42  download_cancel_request_pending
43  mode
44  sub_mode
45  camera_locate_active
46  video_protune_default
47  photo_protune_default
48  multi_shot_protune_default
49  multi_shot_count_down
54  remaining_space
55  supported
56  wifi_bars
57  current_time_msec
58  num_hilights
59  last_hilight_time_msec
60  next_poll_msec
61  analytics_ready
62  analytics_size
63  in_contextual_menu
64  remaining_timelapse_time
"""

import collections
import pprint
from GpCameraController import *
from GpControlManager import *
from GpCameraModes import *
import GpCameraStatusConstants

class GpCameraJsonHelper:
    """
    Helper class used to parse and get values from GoPro camera's JSON responses more easily
    """

    def __init__(self, cameraUrl, isVerificationEnabled=True):
        """
        Class initializer

        :param cameraUrl: The URL of the GoPro camera (e.g. http://x.x.x.x)
        :param isVerificationEnabled: Whether or not the class is enabled (if not, methods will do nothing)
        """

        self.__cameraUrl = cameraUrl
        self.__cameraController = GpCameraController(self.__cameraUrl)
        self.__jsonHelper = JsonDataHelper()

        jsonSettingsDict = makeJsonDataHashable( self.__cameraController.post(GpControlManager.SETTINGS) )
        self.__statusNamesDict = self.__createStatusNamesDict(jsonSettingsDict)
        self.__modesDict = self.__createModesDict(jsonSettingsDict, self.__statusNamesDict)


    def getModeId(self, modeName):
        """
        Translate a mode name into its corresponding id from gp/gpControl/status

        :param modeName: A str value from GpCameraModes.MODE_XXX
        :return: An int id value that corresponds to modeName if found; None otherwise
        """

        for modeId in self.__modesDict:
            if (self.__modesDict[modeId]['name'] == modeName):
                return modeId

        logger.logWarning("Mode name [%s] not found in modes dict:\n%s" % (modeName,
                                                                           pprint.pformat(self.__modesDict)))
        return None


    def getModeAndSubModeId(self, subModeName):
        """
        Translates a submode name into its corresponding id from gp/gpControl/status

        :param subModeName: A str value from GpCameraSubModes.SUB_MODE_XXX
        :return: An int id value that corresponds to subModeName if found; None otherwise
        """

        IGNORED_KEYS = ['name']

        for modeId in self.__modesDict:
            for subModeId in self.__modesDict[modeId]:
                if (subModeId in IGNORED_KEYS):
                    continue

                if (self.__modesDict[modeId][subModeId] == subModeName):
                    return (modeId,subModeId)

        logger.logWarning("Submode name [%s] not found in modes dict:\n%s" % (subModeName,
                                                                              pprint.pformat(self.__modesDict)))
        return None


    def getCameraModesDict(self):
        return self.__modesDict


    def printCameraStatusIdDict(self):
        """
        Print out camera status IDs and corresponding names sorted by ID

        :return: None
        """
        ids = self.__statusNamesDict.items()
        for key,value in sorted(ids, key=lambda x: int(x[0])):
            print "%s  %s" % (key,value)


    def setVerificationEnabled(self, enabled):
        """
        Enable or disable verification. If enabled==False, no verification work will be done when methods are called

        :param enabled: Whether or not to enable verification work done by this class
        :return: None
        """
        self.__isVerificationEnabled = enabled


    def __createStatusNamesDict(self, jsonSettingsDict):
        """
        Create and return a dict of key:value pairs such that
        key   ---> index number corresponding to status indexes in gp/gpControl/status JSON from the GoPro camera
        value ---> A description of the index (e.g. "camera_locate_active")

        :param jsonSettingsDict: The camera's settings JSON (gp/gpControl)
        :return: A dict holding a mapping of id:description values outlined above
        """

        groupsDict = searchJsonWithHashPath(jsonSettingsDict, ['status', 'groups'])
        statusNamesDict = {}

        for indexKey in groupsDict:
            logger.logNoise("indexKey: %s" % indexKey)

            # ignore the "used" counter that is added to all dicts by searchJsonWithHashPath
            if (indexKey == 'used'):
                continue

            try:
                fieldsDict = groupsDict[indexKey]['fields']
            except KeyError:
                errMsg = "'fields' key not found in settingStatusGroups[%s]: " % indexKey
                errMsg += "%s\n" % pprint.pformat(groupsDict[indexKey])
                logger.logError(errMsg)

            for idKey in fieldsDict:
                logger.logNoise("idKey: %s" % idKey)
                # ignore the "used" counter that is added to all dicts by GpCameraJsonDataManager
                if (idKey == 'used'):
                    continue

                try:
                    statusName = fieldsDict[idKey]['name']
                except KeyError:
                    errMsg = "'name' key not found in fieldsDict[%s]: %s\n" % (idKey, pprint.pformat(fieldsDict[idKey]))
                    logger.logError(errMsg)
                    sys.exit(1)
                except:
                    errMsg = "Unexpected error.\nidKey: %s" % idKey
                    errMsg += "fieldsDict: %s" % pprint.pformat(fieldsDict)
                    logger.logError(errMsg)
                    sys.exit(1)

                if (idKey in statusNamesDict):
                    logger.logWarning("Key [%s] already in statusMap: %s" % (idKey, statusNamesDict))

                statusNamesDict[idKey] = statusName

        logger.logNoise("Status Names Dict:\n%s" % pprint.pformat(statusNamesDict))
        return statusNamesDict


    def __createModesDict(self, jsonSettingsDict, statusNamesDict):
        """
        Create and return a dict of the following form:

        { 'INDEX VALUE' : { 'name' : 'NAME OF MODE',
                            'sub_modes' : { 'INDEX VALUE' : 'NAME OF SUBMODE',
                                            ...
                                            'INDEX VALUE' : 'NAME OF SUBMODE'} } }

        :param jsonSettingsDict: The camera's settings JSON (gp/gpControl)
        :param statusNamesDict: A dictionary of statusId:statusName pairs from self.__createStatusNamesDict
        :return: A dict holding a mapping of mode and submode indexes to human-readable names as outlined above
        """

        # Sanity check
        if ('modes' not in jsonSettingsDict):
            logger.logError("Key [modes] not found in camera settings JSON")
            sys.exit(1)

        IGNORED_KEYS = ('used', 'settings', 'playback', 'audio')
        SPECIAL_MODES = ('setup')
        KEY_MODES            = 'modes'
        KEY_VALUE            = 'value'
        KEY_SETTINGS         = 'settings'
        KEY_CURRENT_SUB_MODE = 'current_sub_mode'
        KEY_OPTIONS          = 'options'
        KEY_NAME             = 'name'

        modesDict = {}
        jsonModesDict = jsonSettingsDict[KEY_MODES]

        for modeName in jsonModesDict:
            if (modeName in IGNORED_KEYS):
                continue

            modeId = jsonModesDict[modeName][KEY_VALUE]
            modesDict[modeId] = {KEY_NAME : modeName}

            if (modeName in SPECIAL_MODES):
                continue

            try:
                currentSubModeOptionsDict = jsonModesDict[modeName][KEY_SETTINGS][KEY_CURRENT_SUB_MODE][KEY_OPTIONS]
            except KeyError:
                traceback.print_exc()
                logger.logError("Bughunter - jsonModesDict[%s][%s]:\n%s" % (modeName,
                                                                            KEY_SETTINGS,
                                                                            pprint.pformat(
                                                                                jsonModesDict[modeName][KEY_SETTINGS])))
                sys.exit(1)

            for subModeName in currentSubModeOptionsDict:
                if (subModeName in IGNORED_KEYS):
                    continue

                subModeId = currentSubModeOptionsDict[subModeName][KEY_VALUE]
                modesDict[modeId][subModeId] = subModeName

        logger.logNoise("Modes Dict:\n%s" % pprint.pformat(modesDict))
        return modesDict


    def getStatusValue(self, statusNameStr):
        """
        Get the status of a specific item from gp/gpControl/status

        :param statusNameStr: The status name (e.g. "camera_locate_active") of an item to check the status of
        :return: The value associated with statusNameStr
        """

        statusValues = self.getStatusValues([statusNameStr])

        if (len(statusValues) == 0):
            return None
        elif (len(statusValues) > 1):
            logger.logWarning("Weird error: More than one value returned from getStatusValues: %s" % statusValues)
            return statusValues[0]
        else:
            firstKey = statusValues.keys()[0]
            return statusValues[firstKey]


    def getStatusValues(self, statusNamesList):
        """
        Get the status (from gp/gpControl/status on the GoProCamera) of a specific status item (e.g. "is locate on?")

        :param statusNamesList: A list of status names to return the status values of
        :return: A dict of statusName:statusValue pairs corresponding to statusNamesList from gp/gpControl/status JSON
        """

        # Create a dict of statusName:statusId items
        statusNameToIdDict = {}
        for statusName in statusNamesList:
            statusId = None
            for key in self.__statusNamesDict:
                if (self.__statusNamesDict[key] == statusName):
                    statusId = key
                    break

            if (statusId is None):
                warningMsg = "Status name [%s] " % statusName
                warningMsg += "not found in camera status ID map:\n %s" % pprint.pformat(self.__statusNamesDict)
                logger.logWarning(warningMsg)
            else:
                statusNameToIdDict[statusName] = statusId

        statusJson = self.__cameraController.post(GpControlManager.STATUS)

        # Note: gp/gpControl/status JSON is in the form below
        # { "status":   { STATUS   KEY:VALUE PAIRS },
        #   "settings": { SETTINGS KEY:VALUE PAIRS }
        # }
        try:
            currentStatusDict = statusJson['status']
        except KeyError:
            logger.logError("Unable to get status values dict from statusJson: %s" % statusJson)
            sys.exit(1)

        # Get the value of the requested status item
        statusNameToValueDict = {}
        for statusName in statusNameToIdDict:
            statusId = statusNameToIdDict[statusName]

            try:
                currentValue = currentStatusDict[statusId]
            except KeyError:
                errMsg = "Unable to get status value for ID [%s] from statusValuesDict" % statusId
                errMsg += "Status Values Dict:\n%s" % pprint.pformat(currentStatusDict)
                logger.logError(errMsg)
                sys.exit(1)

            statusNameToValueDict[statusName] = currentValue

        return statusNameToValueDict

