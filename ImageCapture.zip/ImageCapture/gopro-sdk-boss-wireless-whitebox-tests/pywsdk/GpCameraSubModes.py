#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraModes.py
# Description: A data structure class that holds GoPro camera modes
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class GpCameraSubModes:
    """
    Data structure class that holds GoPro camera modes
    """

    # Note: These values are hard-coded from the camera's settings JSON data (gp/gpControl)

    # Video modes
    VIDEO            = "Video"
    TIME_LAPSE_VIDEO = "Time Lapse Video"
    VIDEO_PLUS_PHOTO = "Video + Photo"
    LOOPING          = "Looping"

    # Photo Modes
    SINGLE     = "Single"
    CONTINUOUS = "Continuous"
    NIGHT      = "Night"

    # Multishot modes
    TIME_LAPSE  = "Time Lapse"
    NIGHT_LAPSE = "Night Lapse"
    BURST       = "Burst"



