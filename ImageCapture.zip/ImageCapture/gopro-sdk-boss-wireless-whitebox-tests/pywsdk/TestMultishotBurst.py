#!/usr/bin/python

from GpCameraDiscoverer import *
from GpCamera import *

# Find the camera
discoverer = GpCameraDiscoverer()
cameraUrl = discoverer.getCameraUrl()
camera = GpCamera(cameraUrl)

#--------------------------------
camera.waitForPollingPeriod()
camera.deleteAllFilesOnSdCard()
camera.waitForPollingPeriod()
#--------------------------------

hero4SessionBurstRates = (GpCameraSettingOption.MULTI_SHOT_BURST_RATE_3_PHOTOS_PER_1_SECOND,
                            GpCameraSettingOption.MULTI_SHOT_BURST_RATE_5_PHOTOS_PER_1_SECOND,
                            GpCameraSettingOption.MULTI_SHOT_BURST_RATE_10_PHOTOS_PER_1_SECOND,
                            GpCameraSettingOption.MULTI_SHOT_BURST_RATE_10_PHOTOS_PER_2_SECONDS)

camera.changeSubMode(GpCameraSubModes.BURST)
camera.waitForPollingPeriod()


results = {}
numIterations = 10

for rate in hero4SessionBurstRates:
    results[rate[0]] = 0

    for i in range(numIterations):
        logger.logDebug("Setting rate to: %s" % rate[0])
        success = camera.setSetting(GpCameraSetting.MULTI_SHOT_BURST_RATE, rate)
        camera.waitForPollingPeriod(3)

        if (not success):
            print "  FAILED"
            results[rate[0]] += 1
        else:
            print "  SUCCESS"

print "Results:"
for rate in results:
    print "Rate: %s, Failures: %d out of %d" % (rate, results[rate], numIterations)


