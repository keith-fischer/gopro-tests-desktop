#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCloudManager.py
# Description: Provides a utility to manage GoPro Cloud content
# Author: Sean Foley
# Date Created: 25 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import requests
import sys
from GpOAuthManager import *
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_WARNING)

class GpCloudManager:

    # Environment types
    ENVIRONMENT_PRODUCTION = {
        'description': 'production',
        'base_url': 'https://api.gopro.com',
        'client_id': '71611e67ea968cfacf45e2b6936c81156fcf5dbe553a2bf2d342da1562d05f46',
        'client_secret': '3863c9b438c07b82f39ab3eeeef9c24fefa50c6856253e3f1d37e0e3b1ead68d'
    }

    ENVIRONMENT_STAGING = {
        'description': 'staging',
        'base_url': 'https://api.staging.gopro.com',
        'client_id': '56e8a30b0d4fe6bd392e37cf9c3fac3f683becb19bd8380a0900403525dd2325',
        'client_secret': 'd507ef3566b784c807d0b9d2814d709d5f752bbbc1484ed18bf2f06b40a128f5'
    }


    def __init__(self, username, password, environment):
        """
        Initializer

        :param username: The username (i.e. email address) used to access GoPro's cloud API
        :param password: The password used to access GoPro's cloud API
        :param environment: A dict from one of the GpCloudManager.ENVIRONMENT_XXX values
        :return: None
        """

        self.__username = username
        self.__password = password
        self.__environment = environment

        # Sanity check
        for key in ('description', 'base_url', 'client_id', 'client_secret'):
            if key not in self.__environment:
                logger.logError("Expected key '%s' not found in environment\n%s" % (key,self.__environment))
                sys.exit(1)


    def getMediaList(self, token):
        """
        Get a list of media items from one's GoPro cloud account.

        Fields include: id, filename, file_extension

        :param token: A valid OAuth2 token obtained from GpOAuthManager.getToken
        :return: A list of XXX
        """

        url = "%s/media/search" % self.__environment.get('base_url')
        params = {'fields': 'id,filename,file_extension'}
        headers = {
            'Accept-Charset': 'utf-8',
            'Accept': 'application/vnd.gopro.jk.media+json; version=2.0.0',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer %s' % token
        }

        response = requests.get(url, params=params, headers=headers)

        try:
            response.raise_for_status()
            responseJson = response.json()
        except:
            logger.logError("Unexpected response from GoPro server:")
            traceback.print_exc()
            return None

        logger.logDebug("\nResponse:\n%s" % pprint.pformat(responseJson))

        embedded = responseJson.get('_embedded')
        if embedded is None:
            logger.logError("Unable to get embedded dict from response\nResponse: %s" % pprint.pformat(responseJson))
            return None

        mediaList = embedded.get('media')
        if mediaList is None:
            logger.logError("Unable to get media list from response\nResponse: %s" % pprint.pformat(responseJson))
            return None

        return mediaList


    def checkWeakAssociation(self):
        url = "%s/"


#-----------------------------------------------------------------------------------------------------------------------
# Informal unit testing
#-----------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) != 3+1:
        print "Usage: %s <email address> <password> <production | staging>" % sys.argv[0]
        print "Example: %s dmurphy password1234 production" % sys.argv[0]
        sys.exit(1)
    username,password,environment = sys.argv[1:]

    if environment == "production":
        environment = GpCloudManager.ENVIRONMENT_PRODUCTION
    elif environment == "staging":
        environment = GpCloudManager.ENVIRONMENT_STAGING
    else:
        logger.logError("Invalid value for <environment>: '%s'" % environment)
        sys.exit(1)

    gpOAuthManager = GpOAuthManager(username, password, environment)
    token = gpOAuthManager.getToken()

    gpCloudManager = GpCloudManager(username, password, environment)
    mediaList = gpCloudManager.getMediaList(token)

    print "Media List:\n%s" % pprint.pformat(mediaList)



