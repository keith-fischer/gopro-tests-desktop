#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: IntegrationTestBase.py
# Description: Defines and implements a class that XXX
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import unittest
import xmlrunner

from GpCamera import *

class IntegrationTestBase(unittest.TestCase):
    #-------------------------------------------------------------------------------------------------------------------
    # Methods that are called automatically by unittest before/after each test case
    #-------------------------------------------------------------------------------------------------------------------
    def setUp(self):
        """
        This method is automatically run before every test case
        :return: None
        """

        self.camera = GpCamera.connectOnCurrentWiFiNetwork()


    def tearDown(self):
        """
        This method is automatically run after every test case
        :return: None
        """

        COOLDOWN = 1000 # ms
        printColor("Waiting for %d ms to cool our heels before the next test..." % COOLDOWN, PrintColors.COLOR_GREEN)
        self.camera.sleep(COOLDOWN)


    #-------------------------------------------------------------------------------------------------------------------
    # SDK Wrapper Methods: Helper methods
    #-------------------------------------------------------------------------------------------------------------------
    def waitForPollingPeriod(self, numPollingPeriods=1):
        self.camera.waitForPollingPeriod(numPollingPeriods)


    #-------------------------------------------------------------------------------------------------------------------
    # SDK Wrapper Methods: Camera Control
    #-------------------------------------------------------------------------------------------------------------------
    def changeMode(self, mode, failTestOnError=True):
        """
        Change the current mode group on the camera

        :param modeGroup: A GpCameraSubModes.XXX value
        :param failTestOnError: A boolean indicating whether or not the current test should fail if there is a problem
        :return: True if there was no problem; False otherwise
        """

        success = self.camera.changeMode(mode)
        if (not success):
            errMsg = "Unable to change camera mode to: '%s'" % mode

            if (failTestOnError):
                self.fail(errMsg)
            else:
                logger.logError(errMsg)
            return False

        return True


    def changeSubMode(self, submode, failTestOnError=True):
        """
        Change the current submode on the camera

        :param mode: One of GpCameraSubModes.XXX values
        :param failTestOnError: A boolean indicating whether or not the current test should fail if there is a problem
        :return: True if there was no problem; False otherwise
        """

        success = self.camera.changeSubMode(submode)
        if (not success):
            errMsg = "Unable to change camera submode to: '%s'" % submode

            if (failTestOnError):
                self.fail(errMsg)
            else:
                logger.logError(errMsg)
            return False

        return True


    def tagMoment(self):
        """
        Tag (aka: "HiLight" or "createHilight") this moment in time in currently-recording video
        :return: True if there was no problem; False otherwise
        """

        success = self.camera.tagMoment()
        if (not success):
            self.fail("Unable to create tag/hilight")
            return False

        return True


    def sendPower(self, powerOn):
        """
        Turn the camera on or off

        :param powerOn: A boolean indicating whether to turn the camera on
        :return: True if there was no problem; False otherwise
        """
        success = self.camera.sendPower(powerOn)
        if (not success):
            self.fail("Unable to set power to: '%s'" % powerOn)
            return False

        return True


    def setPreviewEnabled(self, camera, enabled):
        # TODO: Implement
        pass


    def setShutter(self, on, failTestOnError=True):
        """
        Set or unset the shutter (used to take pictures, start/stop video recording)

        :param on: A bool indicating whether to set the shutter to on
        :param failTestOnError: A boolean indicating whether or not the current test should fail if there is a problem
        :return: True if there was no problem; False otherwise
        """

        success = self.camera.setShutter(on)
        if (not success):
            errMsg = "Unable to set the shutter to: '%s'" % on

            if (failTestOnError):
                self.fail(errMsg)
            else:
                logger.logError(errMsg)
            return False

        return True


    #-------------------------------------------------------------------------------------------------------------------
    # SDK Wrapper Methods: Media
    #-------------------------------------------------------------------------------------------------------------------
    def createHiLight(self, mediaFileName, playbackPosition):
        # TODO: Implement
        pass


    def deleteAllFilesOnSD(self):
        """
        Delete all files on the MicroSD card
        :return: True if there was no problem; False otherwise
        """

        success = self.camera.deleteAllFilesOnSdCard()
        if (not success):
            self.fail("Unable to delete all files from MicroSD card")
            return False

        return True


    def deleteFile(self, filePathOnCamera):
        # TODO: Implement
        pass


    def deleteLastFileOnSD(self):
        """
        Delete the last photo/video that was recorded on the camera
        :return: True if there were no errors; False otherwise
        """

        success = self.camera.deleteLastFileOnSdCard()
        if (not success):
            self.fail("Unable to delete last file from MicroSD card")
            return False

        return True


    def fetchHilightTags(self, filePathOnCamera):
        # TODO: Implement
        pass


    def getScreennailUri(self, filePathOnCamera, isVideo):
        # TODO: Implement
        pass


    def getThumbnailUri(self, filePathOnCamera):
        # TODO: Implement
        pass


    #-------------------------------------------------------------------------------------------------------------------
    # SDK Wrapper Methods: Setting
    #-------------------------------------------------------------------------------------------------------------------
    def resetProtuneToDefault(self, mode):
        # TODO: Implement
        # TODO: Determine how to include a mode vs submode version (more flags?)
        pass


    def setSetting(self, settingTuple, optionTuple, failTestOnError=True):
        """
        Change a setting on the camera to a specific option (e.g. video resolution = 1080)

        :param settingTuple: A GpCameraSetting.XXX value
        :param optionTuple: A GpCameraSettingOption.XXX value
        :param failTestOnError: A boolean indicating whether or not the current test should fail if there is a problem
        :return: True if there was no problem; False otherwise
        """

        if (settingTuple.__class__ is not tuple or len(settingTuple) != 2):
            logger.logError("Malformed settingTuple: '%s'" % settingTuple)
            return False
        elif (optionTuple.__class__ is not tuple or len(optionTuple) != 2):
            logger.logError("Malformed optionTuple: '%s'" % optionTuple)
            return False

        success = self.camera.setSetting(settingTuple, optionTuple)
        if (not success):
            settingName,settingID = settingTuple
            optName,optID = optionTuple
            errMsg = "Unable to set setting '%s' (ID: %s) to '%s' (ID: %s)" % (settingName,settingID,optName,optID)

            if (failTestOnError):
                self.fail(errMsg)
            else:
                logger.logError(errMsg)
            return False

        return True


    #-------------------------------------------------------------------------------------------------------------------
    # SDK Wrapper Methods: Setup
    #-------------------------------------------------------------------------------------------------------------------
    def setDateTime(self, newDate):
        # TODO: Implement
        pass


    def setLocate(self, on):
        success = self.camera.setLocate(on)
        if (not success):
            fail("Unable to set locate to: '%s'" % on)
            return False

        return True


    def setWiFiPower(self, on):
        # TODO: Determine whether this needs to be implemented
        pass


    def switchToWifiRemote(self):
        # TODO: Determine whether this needs to be implemented
        pass


    def pairToWifiRemote(self):
        # TODO: Determine whether this needs to be implemented
        pass
