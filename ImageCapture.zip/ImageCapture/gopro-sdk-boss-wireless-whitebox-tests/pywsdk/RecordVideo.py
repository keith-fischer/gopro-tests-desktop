#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: RecordVideo.py
# Description: A Utility to record videos with specific properties such as type, resolution, fps, duration
# Author: Sean Foley
# Date Created: 19 April 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import argparse
from GpCamera import *


def parseCommandlineArgs():
    """
    Parse arguments from the commandline
    :return: A tuple of the form (type,resolution,frameRate,duration) which contains VALID values
    """

    usageStr = "%s -m <VIDEO MODE> -o <FORMAT> -r <RESOLUTION> -f <FRAME RATE> -d <DURATION>" % sys.argv[0]
    epilogStr = "Example: xxx"
    descriptionStr = "A utility to record a video of a specific type/resolution/frame-rate/duration"

    VIDEO_MODES = (
        GpCameraSubModes.VIDEO,
        GpCameraSubModes.TIME_LAPSE_VIDEO,
        GpCameraSubModes.VIDEO_PLUS_PHOTO,
        GpCameraSubModes.LOOPING)

    VIDEO_FORMAT = (
        GpCameraSettingOption.SETUP_VIDEO_FORMAT_NTSC,
        GpCameraSettingOption.SETUP_VIDEO_FORMAT_PAL)

    VIDEO_RESOLUTIONS = (
        GpCameraSettingOption.VIDEO_RESOLUTION_WVGA,
        GpCameraSettingOption.VIDEO_RESOLUTION_720,
        GpCameraSettingOption.VIDEO_RESOLUTION_720_SUPERVIEW,
        GpCameraSettingOption.VIDEO_RESOLUTION_960,
        GpCameraSettingOption.VIDEO_RESOLUTION_1080,
        GpCameraSettingOption.VIDEO_RESOLUTION_1080_SUPERVIEW,
        GpCameraSettingOption.VIDEO_RESOLUTION_1440,
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K,
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K_4_3,
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K_SUPERVIEW,
        GpCameraSettingOption.VIDEO_RESOLUTION_4K,
        GpCameraSettingOption.VIDEO_RESOLUTION_4K_SUPERVIEW,
    )

    VIDEO_FRAME_RATES = (
        GpCameraSettingOption.VIDEO_FPS_12_5,
        GpCameraSettingOption.VIDEO_FPS_15,
        GpCameraSettingOption.VIDEO_FPS_24,
        GpCameraSettingOption.VIDEO_FPS_25,
        GpCameraSettingOption.VIDEO_FPS_30,
        GpCameraSettingOption.VIDEO_FPS_48,
        GpCameraSettingOption.VIDEO_FPS_50,
        GpCameraSettingOption.VIDEO_FPS_60,
        GpCameraSettingOption.VIDEO_FPS_80,
        GpCameraSettingOption.VIDEO_FPS_90,
        GpCameraSettingOption.VIDEO_FPS_100,
        GpCameraSettingOption.VIDEO_FPS_120,
        GpCameraSettingOption.VIDEO_FPS_240
    )

    parser = argparse.ArgumentParser(
        prog=sys.argv[0],
        usage=usageStr,
        epilog=epilogStr,
        description=descriptionStr)

    parser.add_argument(
        "-m",
        help="Video mode",
        type=str,
        choices=VIDEO_MODES
    )

    parser.add_argument(
        "-fm",
        help="Video format",
        type=str,
        choices=tuple( [format[0] for format in VIDEO_FORMAT] )
    )

    parser.add_argument(
        "-r",
        help="Video resolution",
        type=str,
        choices=tuple( [res[0] for res in VIDEO_RESOLUTIONS] )
    )

    parser.add_argument(
        "-f",
        help="Video frame rate",
        type=str,
        choices=tuple( [frameRate[0] for frameRate in VIDEO_FRAME_RATES] )
    )

    parser.add_argument(
        "-d",
        help="Video duration in milliseconds",
        metavar="N",
        type=int,
        default=None
    )

    args = parser.parse_args()

    # Validation
    mode = args.m
    if (not mode in VIDEO_MODES):
        print "Error: Invalid mode '%s'" % mode
        sys.exit(1)

    videoFormat = args.fm
    formatFound = False
    for format in VIDEO_FORMAT:
        formatName = format[0]
        if (formatName == videoFormat):
            videoFormat = format
            formatFound = True
            break
    if (not formatFound):
        print "Error: Invalid resolution: '%s'" % videoFormat
        sys.exit(1)

    resolution = args.r
    resolutionFound = False
    for res in VIDEO_RESOLUTIONS:
        displayName = res[0]
        if (displayName == resolution):
            resolution = res
            resolutionFound = True
            break
    if (not resolutionFound):
        print "Error: Invalid resolution: '%s'" % resolution
        sys.exit(1)

    frameRate = args.f
    frameRateFound = False
    for rate in VIDEO_FRAME_RATES:
        displayName = rate[0]
        if (displayName == frameRate):
            frameRate = rate
            frameRateFound = True
            break
    if (not frameRateFound):
        print "Error: Invalid frame rate: '%s'" % frameRate
        sys.exit(1)

    duration = args.d
    try:
        duration = int(duration)
    except (ValueError, TypeError):
        print "Error: Invalid duration: %s" % duration
        sys.exit(1)

    return (mode,videoFormat,resolution,frameRate,duration)


def main():
    """
    Script begins here!

    Prerequisite: You should be connected to a GoPro camera via WiFi before running this script

    :return: 0 if there are no errors; 1 otherwise
    """

    mode,videoFormat,resolution,frameRate,duration = parseCommandlineArgs()

    camera = GpCamera.connectOnCurrentWiFiNetwork()
    camera.waitForPollingPeriod()

    # Set camera to <MODE> with <RESOLUTION> at <FRAME RATE>
    camera.changeSubMode(mode)
    camera.waitForPollingPeriod()
    camera.setSetting(GpCameraSetting.SETUP_VIDEO_FORMAT, videoFormat)
    camera.waitForPollingPeriod()
    camera.setSetting(GpCameraSetting.VIDEO_RESOLUTION, resolution)
    camera.waitForPollingPeriod()
    camera.setSetting(GpCameraSetting.VIDEO_FPS, frameRate)
    camera.waitForPollingPeriod()

    # Record a video for <DURATION MS>
    camera.setShutter(True)
    camera.sleep(duration)
    camera.setShutter(False)
    camera.waitForPollingPeriod()

    # Get name of file just created
    filePath = GpCamera.getMostRecentMediaFile(camera.getMediaList(), GpMediaType.MEDIA_TYPE_VIDEO)

    print "Recorded video: mode=%s, videoFormat=%s, resolution=%s, framerate=%s, duration=%s, filePath=%s" % (mode,
                                                                                              videoFormat[0],
                                                                                              resolution[0],
                                                                                              frameRate[0],
                                                                                              duration,
                                                                                              filePath)


if (__name__ == "__main__"):
    main()