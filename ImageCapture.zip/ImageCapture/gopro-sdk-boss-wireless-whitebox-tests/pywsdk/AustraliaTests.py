#!/usr/bin/python
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
# File: AustraliaTests.py
# Description: A small test suite of random test to prod at the HERO5 Black camera
# Author: Sean Foley
# Date Created: 28 March 2016
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

import os
from GpCameraDiscoverer import *
from IntegrationTestBase import *

class AustraliaTests(IntegrationTestBase):
    def testMultipleShutterUse(self):
        """
        Test using the shutter multiple times
        :return: None
        """

        NUM_ITERATIONS = 5
        VIDEO_DURATION = 10000 # ms
        TIME_BETWEEN_ITERATIONS = 2000 # ms

        self.changeSubMode(GpCameraSubModes.VIDEO)
        self.waitForPollingPeriod()

        for i in range(NUM_ITERATIONS):
            self.setShutter(True)
            self.camera.sleep(VIDEO_DURATION)
            self.setShutter(False)
            self.camera.sleep(TIME_BETWEEN_ITERATIONS)


if (__name__ == "__main__"):
    ENV_GENERATE_XML_REPORT = "GENERATE_XML_REPORT"
    GENERATE_REPORT_TRUE = "1"

    if (os.environ.get(ENV_GENERATE_XML_REPORT) == GENERATE_REPORT_TRUE):
        print "Running test suite and generating XML output..."
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output="test-reports"))
    else:
        printColor("Running test suite and sending result to stdout...", PrintColors.COLOR_GREEN)
        unittest.main()
