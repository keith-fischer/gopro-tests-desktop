#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCamera.py
# Description: A simplified little brother of the iOS/Android/Embedded-C WSDK, this class is designed to provide the
#              same(-ish) functionality as the WSDK.
# Author: Sean Foley
# Date Created: 25 February 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
    TODO List:

    1. Design a clean way to use GpCameraSetting and GpCameraSettingOption classes with both HERO4 and Legacy cameras
        Idea: In GpCamera.__init__, update global variables based on the camera's JSON (i.e. if the JSON shows that
        it is a HERO4, use HERO4SettingsAndOptions. If the camera is a HERO3+ Black, use that file (once it exists)

        if (cameraType == CAMERA_TYPE_HERO4):
            GpCameraSetting = HERO4SettingsAndOptions.GpCameraSetting
            GpCameraSettingOption = HERO4SettingsAndOptions.GpCameraSettingOption

    2. Synchronize GpCameraModelStrings.py and MODEL_XXX in waitForPollingPeriod somehow...
        Note: gp/gpControl JSON gives the following:
              "model_name":"HERO4 Silver","firmware_version":"HD4.01.03.00.00",
              ...which doesn't line up with GpCameraModelStrings.py (copy-pasted from Android WSDK code)

        Idea: Use regular expression library to extract, for example, "HD4.01" from "firmware_version" and compare that
"""

import traceback
try:
    import awake
    import httplib
    import netifaces
    import requests
    import xmlrunner
    import zeroconf
except ImportError:
    print "Error: Some required third party libraries are not installed. Please install necessary libraries"
    print "  $ sudo pip install awake httplib netifaces requests xmlrunner zeroconf"
    print ""
    traceback.print_exc()

import urllib2

# Purposely importing more than this file needs so whoever imports this file gets extras for free
import GpCameraDiscoverer
from GpCameraConstants import *
from GpCameraController import *
from GpCameraInfo import *
from GpCameraJsonHelper import *
from GpCameraModelStrings import *
from GpCameraModes import *
from GpCameraSubModes import *
from GpControlManager import *
from GpTranscodeManagerConstants import *
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_DEBUG)

# TODO: Make this more generalized (see TODO list above)
import HERO4SettingsAndOptions
GpCameraSetting       = HERO4SettingsAndOptions.GpCameraSetting
GpCameraSettingOption = HERO4SettingsAndOptions.GpCameraSettingOption


class GpCamera:
    """
    A simplified little brother of the iOS/Android/Embedded-C WSDK, this class is designed to provide the
    same(-ish) functionality as the WSDK.
    """

    def __init__(self, cameraUrl, enableVerification=True):
        """
        Class initializer

        :param cameraUrl: The URL of the camera (e.g. "http://x.x.x.x"
        ;param enableVerification: bool indicating whether to verify that camera commands succeeded
        :return: None
        """

        self.__cameraUrl = cameraUrl
        self.__isVerificationEnabled = enableVerification
        self.__controller = GpCameraController(cameraUrl)

        # Make sure camera is accepting commands
        if (not self.isCameraReadyToAcceptCommands()):
            logger.logError("Camera is not accepting commands (URLs). Unable to continue.")
            sys.exit(1)

        self.__jsonHelper = GpCameraJsonHelper(cameraUrl)

        # Get the settings JSON from the camera in order to parse out status IDs
        settingsJson = self.__controller.post(GpControlManager.SETTINGS)
        self.__cameraInfo = GpCameraInfo(settingsJson, self.__jsonHelper)

        # Print colorized camera header info
        cameraInfoHeader = "=-" * 60
        headerMsg = "\n%s\n%s\n%s" % (cameraInfoHeader, self.__cameraInfo.getInfoString(), cameraInfoHeader)
        colorizedHeaderMsg = getColorString(headerMsg, PrintColors.COLOR_GREEN)
        logger.logDebug(colorizedHeaderMsg)


    def sleep(self, durationInMs):
        """
        Sleep for a number of milliseconds

        :param duration: A float value specifying to within 3 decimal places how many seconds to sleep
        :return: True if there were no errors; False otherwise
        """

        durationInSec = float(durationInMs) / 1000.0
        try:
            logger.logDebug("Sleeping for %.3f milliseconds" % durationInSec)
            time.sleep(durationInSec)
            return True
        except TypeError:
            logger.logError("Invalid type for sleep. Given: [%s] (Type: '%s')" % (durationInMs, durationInMs.__class__))
            return False


    def isCameraReadyToAcceptCommands(self):
        """
        Attempt to send a basic command to the camera

        :return: True if camera responds as expected; False otherwise
        """

        jsonResponse = self.__controller.post(GpControlManager.STATUS)
        if (jsonResponse is None):
            logger.logError("Sanity check JSON response: %s" % jsonResponse)
            return False

        return True


    def isCameraHot(self):
        return self.__jsonHelper.getStatusValue(GpCameraStatusConstants.STATUS_SYSTEM_HOT)


    def fileExists(self, filePath):
        """
        Check whether a file exists on the camera

        :param filePath: A str "<dir>/<filename>" representing a file whose existence to check for
        :return:
        """

        isFilePathFoundOnCamera = False
        mediaDict = self.getMediaList()
        KEY_DIRECTORY_NAME = 'd'
        KEY_FILE_SYSTEM    = 'fs'
        KEY_FILE_NAME      = 'n'

        for mediaDirectory in mediaDict:
            mediaDirectoryName = mediaDirectory.get(KEY_DIRECTORY_NAME)
            fileSystemList = mediaDirectory.get(KEY_FILE_SYSTEM)

            for mediaFile in fileSystemList:
                mediaFilename = mediaFile.get(KEY_FILE_NAME)
                mediaFilePath = "%s/%s" % (mediaDirectoryName, mediaFilename)

                if filePath == mediaFilePath:
                    return True

        return False


    def setVerificationEnabled(self, verificationEnabled):
        """
        Allow the user to start/stop camera command verification

        :param verificationEnabled: bool indicating whether GpCamera should verify camera commands or not
        :return: None
        """

        self.__isVerificationEnabled = verificationEnabled


    def getCameraInfo(self):
        return self.__cameraInfo


    def waitForPollingPeriod(self, numPollingPeriods=1):
        """
        Wait for numberofPollingPeriods periods

        :param numPollingPeriodsToWait: The number of polling periods to wait before returning
        :return: None
        """
        MODEL_HERO4_SESSION  = "HERO4 Session"  # HX1
        MODEL_HERO4_SILVER   = "HERO4 Silver"   # HD4
        MODEL_HERO4_BLACK    = "HERO4 Black"    # HD4
        MODEL_HERO_5_BLACK   = "HERO5 Black"    # HD5.02
        MODEL_HERO_5_SESSION = "HERO5 Session"  # HD5.03

        modelName = self.__cameraInfo.getModelName()

        for i in range(numPollingPeriods):
            if (modelName == MODEL_HERO4_SESSION):
                # Camera sometimes needs a "long" polling period to fully update
                logger.logNoise("%s detected. Polling period is 1000ms" % modelName)
                pollingPeriod = 1.000 # sec
            else:
                pollingPeriod = 0.500 # sec

            logger.logNoise("Waiting for polling period (%d ms)" % (pollingPeriod*1000))
            time.sleep(pollingPeriod)


    def getMostRecentMediaFilePath(self, mediaType):
        """
        The the dirname/filename of the most recently captured file

        :param mediaType: A GpMediaType.XXX value
        :return: The dir/filename with the largest mod timestamp or None if there was an error
        """

        """
        Helpful Note: The camera's media list response has the following form:

        [{u'd': u'100GOPRO',
          u'fs': [{u'ls': u'309495',
                   u'mod': u'1423292134',
                   u'n': u'GOPR0014.MP4',
                   u's': u'11913925'},
                  ...
                  {u'ls': u'307297',
                   u'mod': u'1423302114',
                   u'n': u'GOPR0041.MP4',
                   u's': u'14455'}
                 ]
        }]
        """

        mediaList = self.getMediaList()
        maxModificationTime = -1
        mostRecentFilePath = None

        for directoryDict in mediaList:
            dirName = directoryDict.get(GpMediaListResponse.KEY_DIRECTORY_NAME)
            if (dirName is None):
                logger.logError("Unable to get directory name from directory dict:\nDirectory Dict: %s" % directoryDict)
                return None

            fileSystemList = directoryDict.get(GpMediaListResponse.KEY_FILE_SYSTEM)
            if (fileSystemList is None):
                logger.logError("Unable to get file system list from directory dict:\nDirectory Dict: %s"%directoryDict)
                return None

            for mediaItemDict in fileSystemList:
                modTime = mediaItemDict.get(GpMediaListResponse.KEY_MODIFICATION_TIME)
                if (modTime is None):
                    logger.logError("Unable to get modification time from media item:\n%s" %
                                    pprint.pformat(mediaItemDict))
                    return None

                filename = mediaItemDict.get(GpMediaListResponse.KEY_FILENAME)
                if (filename is None):
                    logger.logError("Unable to get filename from media item:\n%s" %
                                    pprint.pformat(mediaItemDict))
                    return None

                try:
                    modTime = int(modTime)
                except ValueError:
                    logger.logError("Unable to convert modification time string '%s' into int" % modTime)
                    return None

                if (modTime > maxModificationTime and filename.endswith(mediaType)):
                    maxModificationTime = modTime
                    mostRecentFilePath = "%s/%s" % (dirName, filename)

        if (mostRecentFilePath is None):
            logger.logError("Unable to find most recent file")
            return None

        return mostRecentFilePath


    # ------------------------------------------------------------------------------------------------------------------
    # Static Helper Methods
    # ------------------------------------------------------------------------------------------------------------------
    @staticmethod
    def connectOnCurrentWiFiNetwork():
        """
        Connect to the whatever camera the WiFi network is currently connected to

        :return: An initialized GpCamera object
        """

        discoverer = GpCameraDiscoverer.GpCameraDiscoverer()
        cameraUrl = discoverer.getCameraUrl()
        camera = GpCamera(cameraUrl)

        return camera


    @staticmethod
    def getMediaListFilenames(mediaDict):
        """
        Extract a list of filenames (including path) from the gp/gpMediaList JSON data

        :param mediaDict: x['fs'] for x is JSON from gp/gpMediaList (i.e. we threw out the 'id' key)
        :return: A list containing path/filename of each file on the SD card of the camera
        """

        KEY_DIRECTORY = 'd'
        KEY_FILE_SYSTEM = 'fs'
        KEY_FILENAME = 'n'

        filenames = []

        for mediaDirDict in mediaDict:
            if (KEY_DIRECTORY not in mediaDirDict) or (KEY_FILE_SYSTEM not in mediaDirDict):
                errMsg = "Expected key [%s] or [%s] not found in mediaDirDict.\n" % (KEY_DIRECTORY, KEY_FILE_SYSTEM)
                errMsg += "Media Dir Dict:\n%s" % pprint.pformat(mediaDirDict)
                logger.logError(errMsg)
                return filenames

            mediaDir = mediaDirDict[KEY_DIRECTORY]
            fileSystemList = mediaDirDict[KEY_FILE_SYSTEM]

            for mediaItem in fileSystemList:
                try:
                    filename = mediaItem[KEY_FILENAME]
                except KeyError:
                    logger.logError("Expected key [%s] not found in media item: %s" % (KEY_FILENAME, mediaItem))
                    return filenames

                filenames.append(mediaDir + "/" + filename)

        return filenames


    # ==================================================================================================================
    # GpCamera Wrapper Methods: Architectural Notes
    #   Each method below emulates WSDK wrapper methods used in the iOS and Android Whitebox test framework and provides
    #   a simple and convenient API to send commands to the camera.
    #
    #   Each method follows the same basic pattern:
    #     1. Form the URL to be sent to the camera
    #     2. Send the URL to the camera
    #     3. Verify that there were no problems sending the URL to the camera and that the JSON response is good
    #     4. Verify that the status of the camera is what it should be (e.g. If we just enabled locate, the status
    #        should indicate that locate is currently turned on)
    # ==================================================================================================================

    # ------------------------------------------------------------------------------------------------------------------
    # Camera Setup Methods
    # ------------------------------------------------------------------------------------------------------------------
    def setLocate(self, enableLocate):
        """
        Enable or disable the Locate feature on the camera

        :param enableLocate: A bool indicating whether to turn on Locate (True) or turn off Locate (False)
        :return: True if there were no errors; False otherwise
        """

        # Get the appropriate gpControl URLs
        setLocateUrlBase = GpControlManager.SET_LOCATE

        LOCATE_ENABLED_VALUE = 1
        LOCATE_DISABLED_VALUE = 0

        if (enableLocate):
            setLocateUrl = setLocateUrlBase % str(LOCATE_ENABLED_VALUE)
            expectedLocateStatus = LOCATE_ENABLED_VALUE
        else:
            setLocateUrl = setLocateUrlBase % str(LOCATE_DISABLED_VALUE)
            expectedLocateStatus = LOCATE_DISABLED_VALUE

        # Send the URLs to the camera
        jsonResponse = self.__controller.post(setLocateUrl)

        # Verify that there were no problems sending commands to the camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred in setLocate(%s)\n%s" % (enableLocate, jsonResponse))
            return False

        if (self.__isVerificationEnabled):
            # Verify that locate was enabled or disabled appropriately
            locateStatus = self.__jsonHelper.getStatusValue(GpCameraStatusConstants.STATUS_CAMERA_LOCATE_ACTIVE)

            if (locateStatus != expectedLocateStatus):
                errMsg = "Expected locate status [%d] " % expectedLocateStatus
                errMsg += "does not match actual locate status [%d]" % locateStatus
                logger.logError(errMsg)
                return False

        return True


    def setDateTime(self, newDate):
        """
        Set the date on the camera

        :param newDate: A datetime object
        :return: True if the date/time was set successfully; False otherwise
        """

        # Get URL
        formattedSetDateUrl = GpControlManager.SET_DATE
        setDateUrl = formattedSetDateUrl % (newDate.year,
                                            newDate.month,
                                            newDate.day,
                                            newDate.hour,
                                            newDate.minute,
                                            newDate.second)

        # Post URL to camera
        logger.logDebug("Set Date URL: %s" % setDateUrl)
        jsonResponse = self.__controller.post(setDateUrl)

        # Verify no problems sending command to camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred while trying to set date to %s" % newDate)
            return False

        # Verify that date on camera matches what we sent

        # TODO: Finish after figuring out why things aren't posting to camera





    #-------------------------------------------------------------------------------------------------------------------
    # Camera Media Methods
    #-------------------------------------------------------------------------------------------------------------------
    # Template:
    # Get gpControl URLs
    # Send the URLs to the camera
    # Verify that there were no problems sending commands to the camera
    # Verify that the camera command worked

    def tagMoment(self):
        # Send the URLs to the camera
        logger.logDebug("Tagging moment (aka: Creating HiLight)")
        jsonResponse = self.__controller.post(GpControlManager.TAG_MOMENT)
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred while trying to tag moment: '%s'" % jsonResponse)
            return False

        if (self.__isVerificationEnabled):
            # TODO: Implement verification of tagged moment
            pass

        return True


    def deleteAllFilesOnSdCard(self):
        """
        Delete all the files on the camera's SD card

        :return: True if media list shows no files at end of method; False otherwise
        """
        # Get gpControl URLs
        deleteAllFilesUrl = GpControlManager.DELETE_ALL_FILES

        # Send the URLs to the camera
        logger.logDebug("Deleting all files from SD card")
        jsonResponse = self.__controller.post(deleteAllFilesUrl)
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred while trying to delete all files: %s" % jsonResponse)
            return False

        if (self.__isVerificationEnabled):
            # Verify that command worked
            mediaListRaw = self.getMediaList()
            if (mediaListRaw != []):
                errMsg = "Error in deleteAllFilesOnSdCard: Media list is not empty! Media List:\n"
                errMsg += pprint.pformat(mediaListRaw)
                logger.logError(errMsg)
                return False

        return True


    def deleteLastFileOnSdCard(self):
        """
        Delete the last file created on the SD card

        :return: True if there is one fewer media files on the SD card than there was before deleting; False otherwise
        """

        mediaListBefore = self.getMediaList()

        # Send the URLs to the camera
        jsonResponse = self.__controller.post(GpControlManager.DELETE_LAST_FILE)

        # Verify that there were no problems sending commands to the camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred while trying to delete last file on sd card: %s" % jsonResponse)
            return False

        if (self.__isVerificationEnabled):
            # Verify that the camera command worked
            mediaListAfter = self.getMediaList()

            if (len(mediaListBefore) == 0):
                if (len(mediaListAfter) == 0):
                    return True
                # This should never happen
                else:
                    errMsg = "Weird error: We started with 0 media items and now we somehow have more than 0...?\n"
                    errMsg += "Media List: %s" % pprint.pprint(mediaListAfter)
                    logger.logError(errMsg)
                    return False

            else:
                if (len(mediaListAfter) == len(mediaListBefore)-1):
                    return True
                else:
                    errMsg = "Media items before: %d, " % len(mediaListBefore)
                    errMsg += "Media items after: %d, " % len(mediaListAfter)
                    errMsg += "Expected media items: %d\n" % (len(mediaListBefore)-1)
                    errMsg += "Media List: %s" % pprint.pformat(mediaListAfter)
                    return False

        return True


    def deleteFile(self, filePath):
        """
        Delete a single file on the camera given the file path

        :param filePath: A string of the form "<folder>/<filename>" represeneting a file on the camera to delete
        :return: True if no errors occurred; False otherwise
        """

        # Get gpControl URL
        deleteFileUrl = GpControlManager.DELETE_FILE % filePath

        if (self.__isVerificationEnabled):
          numMediaItemsBefore = len(self.getMediaListFilenames(self.getMediaList()))
        else:
            numMediaItemsBefore = None

        # Send the URL to the camera
        logger.logDebug("Deleting file: '%s'" % filePath)
        jsonResponse = self.__controller.post(deleteFileUrl)
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred while sending deleteFile url to camera: %s" % jsonResponse)
            return False

        # Verify that exactly one item was deleted
        if (self.__isVerificationEnabled):
            numMediaItemsAfter = len(self.getMediaListFilenames(self.getMediaList()))

            if (numMediaItemsBefore is None):
                logger.logError("Unable to determine number of photos before. Cannot verify successful delete")
                return False
            if (numMediaItemsAfter is None):
                logger.logError("Unable to determine number of photos before. Cannot verify successful delete")
                return False

            if (numMediaItemsAfter == numMediaItemsBefore == 0):
                return True

            if (numMediaItemsAfter >= numMediaItemsBefore):
                logger.logWarning("File '%s' not deleted (file not found?): #before: %d, #after: %d" %
                                  (filePath,numMediaItemsBefore,numMediaItemsAfter))
                return False

            if (numMediaItemsAfter < (numMediaItemsBefore-1)):
                logger.logError("Too many items deleted! #before: %d, #after: %d" % (numMediaItemsBefore,
                                                                                     numMediaItemsAfter))

            # otherwise, we should be OK
            return True

        return True


    def fetchTags(self):
        # TODO: Determine how to fetch tags
        pass


    def getMediaList(self):
        """
        Get the list of media on the camera's SD card and return it

        :return: A list of dict objects with 'mod' (modified time?), 'n' (filename) and 's' (size in bytes) keys
        """

        """
        Helpful Note: The camera's media list response has the following form:

        [{u'd': u'100GOPRO',
          u'fs': [{u'ls': u'309495',
                   u'mod': u'1423292134',
                   u'n': u'GOPR0014.MP4',
                   u's': u'11913925'},
                  ...
                  {u'ls': u'307297',
                   u'mod': u'1423302114',
                   u'n': u'GOPR0041.MP4',
                   u's': u'14455'}
                 ]
        }]
        """

        # Send the URLs to the camera
        jsonResponse = self.__controller.post(GpControlManager.GET_MEDIA_LIST)

        # Verify that there were no problems sending commands to the camera
        # TODO: Determine whether this is appropriate since JSON response is expected to be filled with data, not {}

        # Verify that the camera command worked
        # Note: This can't really be disabled so don't bother with self.__isVerificationEnabled
        KEY_MEDIA_LIST = 'media' # this should be present in the media list JSON
        try:
            mediaList = jsonResponse[KEY_MEDIA_LIST]
        except KeyError:
            errMsg = "Unexpected Error: Key [%s] not found in JSON response\n" % KEY_MEDIA_LIST
            errMsg += "JSON Response: %s" % jsonResponse
            logger.logError(errMsg)
            return None

        # TODO: Consider modifying the format of the return value to be more readable (include path in filename)
        return mediaList


    def downloadMedia(self, mediaUrl, saveFilename):
        """
        Download a media item from the camera

        :param mediaUrl: The URI of a media item on the camera to download
        ;param saveFilename: The filename to give the downloaded file
        :return: True if file was downloaded successfully; False otherwise
        """

        logger.logDebug("Downloading Media from URL: '%s' to '%s'..." % (mediaUrl, saveFilename))
        startTime = time.time()
        try:
            response = urllib2.urlopen(mediaUrl)
        except urllib2.HTTPError, e:
            logger.logError('HTTPError = ' + str(e.code))
            return False
        except urllib2.URLError, e:
            logger.logError('URLError = ' + str(e.reason))
            return False
        except httplib.HTTPException, e:
            logger.logError('HTTPException')
            return False
        except Exception:
            logger.logError('Unknown Exception: ' + traceback.format_exc())
            return False

        data = response.read()
        endTime = time.time()

        with open(saveFilename, 'wb') as f:
            f.write(data)

        logger.logDebug("Media downloaded. Size: %d bytes, Download Time: %.2f sec" % (len(data), (endTime-startTime)))
        return True


    def getPhotoDownloadUri(self, filePath, getHighRes=True):
        """
        Get the URI for a photo on the camera given its file path and whether it's high resolution or not

        :param filePath: A string of the form "<folder>/<filename>" representing a file on the camera to get uri for
        :param getHighRes: Optional bool indicating whether to return URI of high res photo (True) or low res (False)
        :return: A str containing an http URI leading to the photo or None if there was an error
        """

        if not self.fileExists(filePath):
            logger.logError("File not found: '%s'" % filePath)
            return None

        # Thumbnail example
        # http://10.5.5.9:8080/gp/gpMediaMetadata?p=100GOPRO/GOPR3869.JPG
        thumbnailUri = "%s/gp/gpMediaMetadata?p=%s" % (self.__cameraUrl, filePath)

        # Full sized
        # http://10.5.5.9:8080/gp/gpMediaMetadata?p=100GOPRO/GOPR3869.JPG&t=scr
        highResUri   = "%s/gp/gpMediaMetadata?p=%s&t=scr" % (self.__cameraUrl, filePath)

        if getHighRes:
            return highResUri
        else:
            return thumbnailUri


    def getScreennailUri(self):
        # TODO: Determine how to get this information (can't use gpControl?)
        pass

    def getThumbnailUri(self):
        # TODO: Determine how to get this information (can't use gpControl?)
        pass

    def getVideoDownloadUri(self, filePath, getHighRes=True):
        """
        Get the URI for a video on the camera given its file path and whether to link the low res video file or not

        :param filePath: A string of the form "<folder>/<filename>" representing a file on the camera to get uri for
        :param getHighRes: Optional bool indicating whether to return URI of high res video (True) or low res (False)
        :return: A str containing an http URI leading to the photo or None if there was an error
        """

        if not self.fileExists(filePath):
            logger.logError("File not found: '%s'" % filePath)
            return None

        # High res video example:
        # 10.5.5.9/videos/DCIM/100GOPRO/GOPR5369.MP4
        highResVideoUri = "%s/videos/DCIM/%s" % (self.__cameraUrl, filePath)

        # Low res video example:
        # 10.5.5.9/videos/DCIM/100GOPRO/GOPR5369.LRV
        lowResVideoUri = highResVideoUri.replace("MP4", "LRV")

        if getHighRes:
            return highResVideoUri
        else:
            lowResFilePath = filePath.replace("MP4", "LRV")
            return lowResVideoUri


    def getVideoDuration(self):
        # TODO: Determine how to get this information (can't use gpControl?)
        pass

    def getVideoMetadata(self, videoUri):
        videoMetadataUrl = GpControlManager.GET_VIDEO_METADATA % videoUri

        # Send the URLs to the camera
        jsonResponse = self.__controller.post(videoMetadataUrl)

        # Verify that there were no problems sending commands to the camera
        KEY_DURATION = 'dur'
        KEY_TAGS = 'tags'

        if (KEY_DURATION not in jsonResponse):
            logger.logError("Expected key [%s] not found in JSON response:\n%s" % (KEY_DURATION,
                                                                                   pprint.pformat(jsonResponse)))
            return None
        elif (KEY_TAGS not in jsonResponse):
            logger.logError("Expected key [%s] not found in JSON response:\n%s" % (KEY_TAGS,
                                                                                   pprint.pformat(jsonResponse)))
            return None

        return jsonResponse



    #-------------------------------------------------------------------------------------------------------------------
    # Camera Control Methods
    #-------------------------------------------------------------------------------------------------------------------
    def changeMode(self, mode):
        """
        Change the mode on the camera

        :param mode: A value from GpCameraModes.MODE_XXX
        :return: True if there were no errors; False otherwise
        """

        modeId = self.__jsonHelper.getModeId(mode)
        if (modeId is None):
            logger.logError("Invalid mode: %s" % mode)
            return False

        changeModeUrl = GpControlManager.CHANGE_MODE % modeId

        # Send the URLs to the camera
        logger.logDebug("Changing mode to [%s]" % mode)
        mode = mode.lower()
        jsonResponse = self.__controller.post(changeModeUrl)

        # Verify that there were no problems sending commands to the camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Error occurred while trying to change camera mode to '%s'" % mode)
            return False

        # Verify that the camera command worked
        if (self.__isVerificationEnabled):
            self.waitForPollingPeriod()
            currentModeId = self.__jsonHelper.getStatusValue(GpCameraStatusConstants.STATUS_MODE)

            modeId = self.__jsonHelper.getModeId(mode)
            if (modeId is None):
                logger.logError("Unable to get mode id during verification step")
                return False

            if (currentModeId != modeId):
                logger.logError("Verification failed: Unable to change mode to [%s]" % mode)
                return False

        return True


    def changeSubMode(self, subMode):
        """
        Change the submode on the camera

        :param subMode: The name of the submode to change to
        :return: True if there were no errors; False otherwise
        """

        modeAndSubModeId = self.__jsonHelper.getModeAndSubModeId(subMode)
        if (modeAndSubModeId is None):
            logger.logError("Invalid submode: %s" % subMode)
            return False

        changeSubModeUrl = GpControlManager.CHANGE_SUB_MODE % modeAndSubModeId

        # Send the URL to the camera
        logger.logDebug("Changing submode to '%s'" % subMode)
        jsonResponse = self.__controller.post(changeSubModeUrl)

        # Verify that there were no problems sending commands to the camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            errMsg = "Unable to change change submode to '%s'\n" % subMode
            errMsg += "JSON Response:\n%s" % pprint.pformat(jsonResponse)
            logger.logError(errMsg)
            sys.stdout.flush()
            return False

        # Verify that the camera command worked
        if (self.__isVerificationEnabled):
            self.waitForPollingPeriod()
            currentSubModeId = self.__jsonHelper.getStatusValue(GpCameraStatusConstants.STATUS_SUB_MODE)
            modeAndSubModeId = self.__jsonHelper.getModeAndSubModeId(subMode)

            if (modeAndSubModeId is None):
                logger.logError("Unable to get submode id during verification step")
                return False
            modeId,subModeId = modeAndSubModeId

            if (currentSubModeId != subModeId):
                logger.logError("Verification failed: Unable to chagne sub mode to [%s]" % subMode)
                return False

        return True


    def tagMoment(self):
        """
        HiLight (aka: tag) the current timestamp in a currently-recording video
        :return: True if there were no errors; False otherwise
        """

        # Send the URL to the camera
        jsonResponse = self.__controller.post(GpControlManager.TAG_MOMENT)

        # Verify that there were no problems sending commands to the camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Unable to tag moment")
            return False

        # Verify that the camera command worked
        # TODO: Determine how/whether to verify this
        return True


    def sendPower(self, powerOn):
        """
        Power the camera on or off

        :param powerOn: A bool telling whether to power the camera on (True) or off (False)
        :return: True if there were no errors; False otherwise
        """

        # Send the camera some WOL (Wake On Lan) packets to get it to turn back on
        if (powerOn):
            macAddr = self.__cameraInfo.getMacAddr()
            cameraIpAddr = self.__cameraUrl.lstrip("http://")
            sendWakeOnLan(macAddr, cameraIpAddr)

        else:
            # Send the URLs to the camera
            logger.logDebug("Putting camera to sleep...")
            jsonResponse = self.__controller.post(GpControlManager.SLEEP)

            # Verify that there were no problems sending commands to the camera
            if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
                logger.logError("Error occurred while trying to put the camera to sleep")
                return False

            # Verify that the camera command worked
            # TODO: Determine how to verify that the camera is in sleep mode

        return True


    def setPreviewEnabled(self):
        # TODO: Determine how to do this
        pass


    def setShutter(self, enableShutter):
        """
        Set the shutter on the camera to either ON or OFF state

        :param enableShutter: A bool indicating whether to set the shutter to ON (True) or OFF (False)
        :return: True if the shutter was set successfully; False otherwise
        """

        SHUTTER_ON_VALUE = 1
        SHUTTER_OFF_VALUE = 0

        if (enableShutter):
            setShutterUrl = GpControlManager.SET_SHUTTER % str(SHUTTER_ON_VALUE)
        else:
            setShutterUrl = GpControlManager.SET_SHUTTER % str(SHUTTER_OFF_VALUE)

        # Send the URLs to the camera
        logger.logDebug("Setting shutter to: %s" % ("ON" if (enableShutter) else "OFF"))
        jsonResponse = self.__controller.post(setShutterUrl)

        # Verify that there were no problems sending commands to the camera
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Unable to set shutter. Response: %s" % jsonResponse)
            return False

        return True


    #-------------------------------------------------------------------------------------------------------------------
    # Camera Setting Methods
    #-------------------------------------------------------------------------------------------------------------------
    def resetProtuneToDefault(self):
        # TODO: Implement and determine whether one version or two is needed
        pass


    def setSetting(self, settingTuple, optionTuple):
        """
        Change a specific setting on the camera

        :param settingTuple: A tuple containing (<SETTING NAME>, <SETTING ID>) data from GpCameraSetting.XXX
        :param optionTuple: A tuple containing (<OPTION NAME>, <OPTION ID>) data from GpCameraSettingOption.XXX
        :return: True if the setting was updated successfully; False otherwise
        """

        try:
            settingName,settingId = settingTuple
            optionName,optionValue = optionTuple
        except ValueError:
            logger.logError("Unable to extract setting/option name and/or setting ID / option value from parameter")
            return False

        setSettingUrl = GpControlManager.SET_SETTING % (settingId, optionValue)

        # Send the URL to the camera
        logger.logDebug("Changing setting '%s' (ID: %s) to '%s' (ID: %s)" % (settingName,
                                                                             settingId,
                                                                             optionName,
                                                                             optionValue))
        jsonResponse = self.__controller.post(setSettingUrl)
        if (jsonResponse != GpCameraController.JSON_RESPONSE_OK):
            logger.logError("Unable to change setting '%s' to '%s'" % (settingId, optionValue))
            return False

        # Verify that the camera command worked
        # TODO: Determine whether changing the setting worked or not

        return True


    # ------------------------------------------------------------------------------------------------------------------
    # Camera As a Hub: Transcode Manager Methods
    # ------------------------------------------------------------------------------------------------------------------
    def getTranscodeHistory(self):
        # Send the URLs to the camera
        logger.logDebug("Querying transcode history")
        jsonResponse = self.__controller.post(GpControlManager.GET_TRANSCODE_HISTORY)

        return jsonResponse


    def getTranscodeEstimate(self, filePath, resolution, fpsDivisor, clipStartTimeInMs, clipEndTimeInMs):
        """
        Return an estimate of how long it will take to transcode a file

        :param filePath: The file path of a file upon which to make the estimate
        :param resolution: A GpTranscodeManagerSettings.FPS_XXX value
        :param fpsDivisor: A GpTranscodeManagerSetteings.FPS_DIVISOR_XXX value
        :param clipStartTimeInMs: The start time (in ms) of a clip from the video
        :param clipEndTimeInMs: The end time (in ms) of a clip from the video

        :return: The number of seconds the camera estimates it will take to transcode the video (None if error)
        """

        """
        TODO: Use optional parameters somewhere?
            // optional parameters
            &lrv={1 = generate LRV only, 0 = generate MP4+LRV+THM (default)}
            &idr={ idr interval, 0 = use same as source file, same as if param omitted}
            &gop_m={ gop_m value, 0 = use same as source file, same as if param omitted}
            &gop_n={ gop_n value, 0 = use same as source file, same as if param omitted}
            &bitrate={ bitrate, 0 = let camera decide, same as if param omitted}
        """

        # Get gpControl URL
        transcodeEstimateUrl = GpControlManager.GET_TRANSCODE_ESTIMATE % (filePath,
                                                                          resolution,
                                                                          fpsDivisor,
                                                                          str(clipStartTimeInMs),
                                                                          str(clipEndTimeInMs))

        # Send the URL to the camera
        logger.logDebug("Getting transcode time estimate for file: '%s'" % filePath)
        jsonResponse = self.__controller.post(transcodeEstimateUrl)

        # BOSS-573: Response from the camera contains unescaped backslashes, which is invalid JSON.
        # Let's work around it for now
        if (jsonResponse.__class__ is str):
            try:
                jsonResponse = json.loads( jsonResponse.strip().replace("\\", "\\\\") )
            except Exception as e:
                traceback.print_exc()
                logger.logError("Unable to convert transcode estimate response into JSON")
                return None

        status = jsonResponse.get(GpTranscodeManagerResponse.KEY_STATUS_DICT)
        if (status is None):
            logger.logError("Unable to get status key from camera response:\n%s" % jsonResponse)
            return None

        estimateInSec = status.get(GpTranscodeManagerResponse.KEY_ESTIMATED_TIME_IN_SEC)
        if (estimateInSec is None):
            logger.logError("Unable to get transcode estimate from camera reaponse:\n%s" % jsonResponse)
            return None

        logger.logNoise(jsonResponse)
        return estimateInSec


    def startTranscode(self, filePath, resolution, fpsDivisor, clipStartTimeInMs, clipEndTimeInMs):
        """
        Begin transcoding a video

        :param filePath: The file path of a file upon which to make the estimate
        :param resolution: A GpTranscodeManagerSettings.FPS_XXX value
        :param fpsDivisor: A GpTranscodeManagerSetteings.FPS_DIVISOR_XXX value
        :param clipStartTimeInMs: The start time (in ms) of a clip from the video
        :param clipEndTimeInMs: The end time (in ms) of a clip from the video

        :return: The ID of the transcode started or None if there are any errors
        """

        startTranscodeUrl = GpControlManager.START_TRANSCODE % (filePath,
                                                                resolution,
                                                                fpsDivisor,
                                                                str(clipStartTimeInMs),
                                                                str(clipEndTimeInMs))

        logger.logDebug("Starting transcode of file: '%s'" % filePath)
        jsonResponse = self.__controller.post(startTranscodeUrl)

        # BOSS-573: Response from the camera contains unescaped backslashes, which is invalid JSON.
        # Let's work around it for now
        if (jsonResponse.__class__ is str):
            try:
                jsonResponse = json.loads( jsonResponse.strip().replace("\\", "\\\\") )
            except Exception as e:
                traceback.print_exc()
                logger.logError("Unable to convert transcode estimate response into JSON")
                return None

        # Verify that the transcode started
        status = jsonResponse.get(GpTranscodeManagerResponse.KEY_STATUS_DICT)
        if (status is None):
            logger.logError("Unable to get status from camera response: '%s'" % jsonResponse)
            return None

        failureReason = status.get(GpTranscodeManagerResponse.KEY_FAILURE_REASON)
        if (failureReason is None):
            logger.logError("Unable to get failure reason from camera response: '%s'" % jsonResponse)

        if (failureReason != GpTranscodeManagerFailure.FAILURE_REASON_NONE):
            errMsg = "Failed to transcode file: '%s' - " % filePath

            if (failureReason == GpTranscodeManagerFailure.FAILURE_REASON_BAD_FILE):
                errMsg += "Bad source file"
            elif (failureReason == GpTranscodeManagerFailure.FAILURE_REASON_BAD_CONFIG):
                errMsg += "Bad configuration"
            elif (failureReason == GpTranscodeManagerFailure.FAILURE_REASON_INSUFFICIENT_SD):
                errMsg += "Insufficient space on MicroSD card"
            elif (failureReason == GpTranscodeManagerFailure.FAILURE_REASON_BUSY):
                errMsg += "System is busy"
            elif (failureReason == GpTranscodeManagerFailure.FAILURE_REASON_UNKNOWN):
                errMsg += "Unknown error occurred"
            else:
                errMsg += "Unhandled failure reason: '%s'" % failureReason

            errMsg += "\nRaw Response:\n%s" % jsonResponse

            logger.logError(errMsg)
            return None

        transcodedFilename = status.get(GpTranscodeManagerResponse.KEY_TRANSCODED_FILENAME)
        if (transcodedFilename is None):
            logger.logError("Unable to get transcoded filename from camera response:\n%s" % jsonResponse)
            return None

        transcodeId = status.get(GpTranscodeManagerResponse.KEY_ID)
        if (transcodeId is None):
            logger.logError("Unable to get transcode ID from camera response:\n%s" % jsonResponse)
            return None

        logger.logDebug("Transcoded Filename: '%s'" % transcodedFilename)
        logger.logNoise(jsonResponse)
        return transcodeId


    def getTranscodeStatus(self, transcodeId):
        """
        Get information about the specified transcode job

        :param transcodeId: The 64-bit ID of a current transcoding session
        :return: The camera's response to the query or None if there's an error
        """
        getTranscodeStatusUrl = GpControlManager.GET_TRANSCODE_STATUS % transcodeId

        logger.logDebug("Getting transcode status for ID: '%s'" % transcodeId)
        jsonResponse = self.__controller.post(getTranscodeStatusUrl)

        # BOSS-573: Response from the camera contains unescaped backslashes, which is invalid JSON.
        # Let's work around it for now
        if (jsonResponse.__class__ is str):
            try:
                jsonResponse = json.loads( jsonResponse.strip().replace("\\", "\\\\") )
            except Exception as e:
                traceback.print_exc()
                logger.logError("Unable to convert transcode estimate response into JSON")
                return None

        status = jsonResponse.get(GpTranscodeManagerResponse.KEY_STATUS_DICT)
        if (status is None):
            logger.logError("Unable to get status from camera reaponse:\n%s" % jsonResponse)
            return None

        transcodePath = status.get(GpTranscodeManagerResponse.KEY_SOURCE_FILENAME)
        if (transcodePath is None):
            logger.logError("Unable to get transcode file path from camera response:\n%s" % jsonResponse)
            return None

        transcodeStatus = status.get(GpTranscodeManagerResponse.KEY_TRANSCODE_STATUS)
        if (transcodeStatus is None):
            logger.logError("Unable to get transcode status from camera response:\n%s" % jsonResponse)
            return None

        percentComplete = status.get(GpTranscodeManagerResponse.KEY_COMPLETION_PERCENTAGE)
        if (percentComplete is None):
            logger.logError("Unable to get completion percentage from camera response:\n%s" % jsonResponse)
            return None

        debugMsg = "Transcode Status of '%s': " % transcodePath

        if (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_STARTED):
            debugMsg += "Started "
        elif (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_IN_PROGRESS):
            debugMsg += "In progress "
        elif (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_JOB_COMPLETE):
            debugMsg += "Complete "
        elif (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_CANCEL_COMPLETE):
            debugMsg += "Cancel complete "
        elif (transcodeStatus == GpTranscodeManagerStatus.STATUS_TRANSCODE_FAILED):
            debugMsg += "Failed "
        else:
            logger.logError("Unhandled transcode status: '%s'\nRaw Response:\n%s" % (transcodeStatus,jsonResponse))
            return None

        debugMsg += "(%d%% complete)" % (percentComplete * 100)
        logger.logDebug(debugMsg)

        return jsonResponse


    def cancelTranscode(self, transcodeId):
        """
        Cancel the specified transcode job

        :param transcodeId: The 64-bit ID of a current transcoding session
        :return: True if there were no errors; False otherwise
        """

        cancelTranscodeUrl = GpControlManager.CANCEL_TRANSCODE % transcodeId

        logger.logDebug("Canceling transcode ID: '%s'" % transcodeId)
        jsonResponse = self.__controller.post(cancelTranscodeUrl)

        # BOSS-573: Response from the camera contains unescaped backslashes, which is invalid JSON.
        # Let's work around it for now
        if (jsonResponse.__class__ is str):
            try:
                jsonResponse = json.loads( jsonResponse.strip().replace("\\", "\\\\") )
            except Exception as e:
                traceback.print_exc()
                logger.logError("Unable to convert transcode estimate response into JSON")
                return False

        # TODO: Determine what to do with the response JSON
        #{u'status': {u'status': 1, u'completion': 0, u'failure_reason': 0, u'source': u'DCIM\\100GOPRO\\GOPR0014.MP4', u'output': u'', u'estimate': 2, u'id': 429496729614}}

        return True


    @staticmethod
    def isValidBitrate(height, width, fps, fpsDivisor):
        """

        :param height: Height in pixels of the media
        :param width: Width in pixels of the media
        :param fps: Number of frames per second of the media
        :param fpsDivisor: Frames per second divisor of the media (explained in GpTranscodeManagerSettings)
        :return:
        """

        #lower_limit = ( height*width*(fps/fps_divisor) ) / 20
        #upper_limit = ( height*width*(fps/fps_divisor) ) / 2
        #height, width of resolution requested, if 0 - use that of input.
        #fps of input file.
        #fps_divisor, if 0- use 1

        logger.logError("TODO: Complete method")
        return False


    # ------------------------------------------------------------------------------------------------------------------
    # Wireless control methods
    # ------------------------------------------------------------------------------------------------------------------
    def snapshotSsidScanResults(self):
        """
        Save a "snapshot" of the current SSID scan results. Call GpCamera.listSsidScanResults to get list

        :return: True if there were no errors; False otherwise
        """

        # The return value should be {'scan_id': <INTEGER>}
        logger.logDebug("Taking snapshot of current SSID scan results")
        jsonResponse = self.__controller.post(GpControlManager.SSID_SCAN)

        if len(jsonResponse) != 1:
            logger.logError("Unexpected length of JSON response dict: %d" % len(jsonResponse))
            return False


    def listSsidScanResults(self):
        """
        Return SSID scan results from the current "snapshot", which is created by GpCamera.snapshotSsidScanResults

        :return: A list of dicts of the form [{'auth_type':<AUTH DESCR>, 'bars':<RSSI BARS>, 'ssid':<SSID NAME>}, ...]
        """

        logger.logDebug("Retrieving list of SSID scan results from snapshot")
        jsonResponse = self.__controller.post(GpControlManager.SSID_LIST)

        ssidList = jsonResponse.get('ssid_array')
        return ssidList


    def connectToSsid(self, ssid, authType, password):
        """
        Connect to an SSID

        :param ssid: The name of the SSID to connect to
        :param authType: The SSID's authentication type
        :param password: The SSID's password
        :return: XXX
        """

        url = GpControlManager.SSID_SELECT % (ssid, authType, password)

        logger.logDebug("Connecting to SSID '%s'" % ssid)

        print "Debug: url: '%s'" % url
        jsonResponse = self.__controller.post(url)

        print "Debug: JSON Response:\n%s" % pprint.pformat(jsonResponse)










