#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraModelStrings
# Description: A convenient camera lookup reference
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
TODO List:
    1. See TODO in GpCamera.py and do it

"""

class GpCameraModelStrings:
    HERO_2 = "HD2.01";
    HERO_2_PLUS_WIFI = "HD2.08";
    HERO_3_SHORES = "HD3.01";
    HERO_3_SHORES_REISSUE = "HD3.09";
    HERO_3_BLACKS = "HD3.02";
    HERO_3_TODOS = "HD3.03";
    HERO_3_PLUS_ULUWATU = "HD3.10";
    HERO_3_PLUS_BAWA = "HD3.11";
    HERO_4_BACKDOOR = "HD4.01";
    HERO_4_PIPE = "HD4.02";
    HERO_4_BOLINAS = "HD3.20";
    HERO_4_HALEIWA = "HD3.21";
    HERO_4_ROCKY_POINT = "HX1.01";
    HERO_4_HIMALAYAS = "HD3.22";
    HERO_5_STREAKY = "HD5.02";

    DISPLAY_HERO_2 = "Hero2";
    DISPLAY_HERO_2_PLUS_WIFI = "Hero2 Plus";
    DISPLAY_HERO_3_SHORES = "Hero3 White";
    DISPLAY_HERO_3_SHORES_REISSUE = "Hero3 White";
    DISPLAY_HERO_3_BLACKS = "Hero3 Silver";
    DISPLAY_HERO_3_TODOS = "Hero3 Black";
    DISPLAY_HERO_3_PLUS_ULUWATU = "Hero3+ Silver";
    DISPLAY_HERO_3_PLUS_BAWA = "Hero3+ Black";
    DISPLAY_HERO_4_BACKDOOR = "Hero4 Silver";
    DISPLAY_HERO_4_PIPE = "Hero4 Black";
    DISPLAY_HERO_4_BOLINAS = "Hero";
    DISPLAY_HERO_4_HALEIWA = "Hero+ LCD";
    DISPLAY_HERO_4_ROCKY_POINT = "Hero4 Session";
    DISPLAY_HERO_4_HIMALAYAS = "Hero+";

