#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraController.py
# Description: Used to send URLs to the camera and monitor whether there were any errors
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import requests
import time
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_WARNING)

class GpCameraController:
    """
    Class used to send URLs to the GoPro camera and provide retry and error checking
    """

    # Static members
    HTTP_METHOD_POST = "post"
    HTTP_METHOD_GET  = "get"
    HTTP_METHOD_PUT  = "put"
    JSON_RESPONSE_OK = {}  # indicates no error


    def __init__(self, cameraUrl):
        self.__MAX_CONNECTION_ATTEMPTS = 10
        self.__CONN_RETRY_WAIT_TIME = 1.000  # seconds
        self.__cameraBaseUrl = cameraUrl


    def send(self, url, httpMethod):
        """
        Attempt to send url to GoPro camera via HTTP type (GET or POST)

        :param url: A string containing the URL to send to the GoPro camera
        :param httpMethod: A string containing the type (see static class members HTTP_METHOD_xxx)
        :return: The camera's JSON response as a dict
        """
        isSuccessful = False
        response = None
        SERVER_RESPONSE_TIMEOUT = 5 # seconds

        if (url is None):
            return None

        fullUrl = self.__cameraBaseUrl + url
        logger.logDebug("Send URL: %s" % fullUrl)

        # POST/GET will fail if percent signs are not escaped
        fullUrl = fullUrl.replace("%", "\%")

        for i in range(self.__MAX_CONNECTION_ATTEMPTS):
            try:
                if (httpMethod == GpCameraController.HTTP_METHOD_POST):
                    response = requests.post(fullUrl, timeout=SERVER_RESPONSE_TIMEOUT)
                elif (httpMethod == GpCameraController.HTTP_METHOD_GET):
                    response = requests.get(fullUrl, timeout=SERVER_RESPONSE_TIMEOUT)
                else:
                    logger.logError("Error: Unexpected httpMethod type: %s" % httpMethod)
                    return None

                if (response.status_code == requests.codes.ok):
                    isSuccessful = True
                    break
                else:
                    logger.logWarning("Response code: %s (%s) (attempt %d of %d)" % (response.status_code,
                                                                                     response.reason,
                                                                                     i+1,
                                                                                     self.__MAX_CONNECTION_ATTEMPTS))
            except requests.exceptions.Timeout:
                logger.logError("Timed out trying to connect (threshold: %d seconds)" % SERVER_RESPONSE_TIMEOUT)
            except requests.exceptions.ConnectionError:
                errMsg = "[%s] " % httpMethod.upper()
                errMsg += "ConnectionError occurred. Trying again in %.2f seconds" % self.__CONN_RETRY_WAIT_TIME
                logger.logError(errMsg)
            except:
                errMsg = "[%s] " % httpMethod.upper()
                errMsg += "Unknown error occurred. Trying again in %.2f seconds" % self.__CONN_RETRY_WAIT_TIME
                logger.logError(errMsg)

            time.sleep(self.__CONN_RETRY_WAIT_TIME)

        if (not isSuccessful):
            errMsg = "Unable to send HTTP %s " % httpMethod
            errMsg += "url to camera after %d attempts" % self.__MAX_CONNECTION_ATTEMPTS
            logger.logError("Error: %s" % errMsg)
            return None
        else:
            try:
                logger.logNoise("Raw response from camera: '%s'" % response.content)
                return response.json()
            except AttributeError:
                logger.logError("Dafuq?")
                return None
            except ValueError:
                if (response is None):
                    logger.logWarning("Response from camera is not JSON. Content: None")
                    return None
                else:
                    logger.logWarning("Response from camera is not JSON. Content: '%s'" % response.content)
                    return response.content


    def post(self, url):
        return self.send(url, GpCameraController.HTTP_METHOD_POST)


    def get(self, url):
        return self.send(url, GpCameraController.HTTP_METHOD_GET)

    def put(self, url):
        return self.send(url, GpCameraController.HTTP_METHOD_PUT)


