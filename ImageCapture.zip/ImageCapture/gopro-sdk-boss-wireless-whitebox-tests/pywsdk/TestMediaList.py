#!/usr/local/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: TestMediaList.py
# Description: Test for the BOSS team that exercises the Camera Roll's mediaList functionality
# Author: Sean Foley
# Date Created: 1 June 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
TODO List

    1. Add flags for whether or not to generate a new media library
    2. Add flags for how many pictures to generate in media library (default: random number in [1..N])
    3. Add flags for how many videos to generate in media library (default: random number in [1..M])
    4. Generate an assortment of videos/pictures using random settings

    Example:

        TestMediaList.py --generatelibrary <NUM PHOTOS> <NUM VIDEOS> --iterations 10000
        or
        TestMediaLibrary.py --iterations 10000  # media library will be randomly generated
"""

from GpCamera import *
from QAToolbox import *

testLogger = Logger(Logger.LOG_LEVEL_DEBUG)


def printUsageAndExitWithError():
    """
    Print usage string and end script with error

    :return: None
    """
    testLogger.logError("Usage: %s <NUM TEST ITERATIONS>" % sys.argv[0])
    sys.exit(1)


def main():
    """
    Script begins here. Hur dur.

    :return: 0 on exit success; 1 otherwise
    """

    if len(sys.argv) != 1+1:
        printUsageAndExitWithError()

    try:
        numTestIterations = int(sys.argv[1])
    except ValueError:
        numTestIterations = None
        printUsageAndExitWithError()

    camera = GpCamera.connectOnCurrentWiFiNetwork()
    camera.deleteAllFilesOnSdCard()
    camera.waitForPollingPeriod()

    # Set camera to Video mode at 1080p @ 60fps with wide field of view
    camera.changeSubMode(GpCameraSubModes.VIDEO)
    camera.waitForPollingPeriod()
    camera.setSetting(GpCameraSetting.VIDEO_RESOLUTION, GpCameraSettingOption.VIDEO_RESOLUTION_1080)
    camera.waitForPollingPeriod()
    camera.setSetting(GpCameraSetting.VIDEO_FOV, GpCameraSettingOption.VIDEO_FOV_WIDE)
    camera.waitForPollingPeriod()
    camera.setSetting(GpCameraSetting.VIDEO_FPS, GpCameraSettingOption.VIDEO_FPS_60)
    camera.waitForPollingPeriod()

    # Record five videos
    printColor("Creating small video library...", PrintColors.COLOR_GREEN)
    sleepDurations = (1000, 2000, 3000, 4000, 5000)
    for sleepDuration in sleepDurations:
        camera.setShutter(True)
        camera.sleep(sleepDuration)
        camera.setShutter(False)
        camera.waitForPollingPeriod(3)

    # Iteration failures are stored here in the form (<ITER NUM>, <EXP MEDIA>, <MEDIA LIST>)
    failures = []

    printColor("Checking video library...", PrintColors.COLOR_GREEN)
    mediaList = []
    for i in range(1,numTestIterations+1):
        testLogger.logDebug("Iteration: %d of %d" % (i, numTestIterations))
        camera.waitForPollingPeriod()

        mediaList = camera.getMediaList()
        if (mediaList.__class__ is not list):
            testLogger.logError(
                "Expected mediaList.__class__ is list. Got '%s'\nMedia List:\n%s" %
                (str(mediaList.__class__), pprint.pformat(mediaList, width=120)))
            sys.exit(1)

        # Verify that the number of items in the media list equals the number of videos we just recorded
        numMediaItems = 0
        for mediaDict in mediaList:
            fsList = mediaDict.get('fs')
            if fsList is None:
                testLogger.logError("Unable to get fsList from mediaDict:\n%s" % pprint.pformat(mediaDict))
                sys.exit(1)
            numMediaItems += len(fsList)

        if numMediaItems != len(sleepDurations):
            testLogger.logError(
                "Expected media list containing %d videos. Got %d videos\nMedia List:\n%s" %
                (len(sleepDurations), numMediaItems, pprint.pformat(mediaList, width=120)))
            failures.append( (i, len(sleepDurations), mediaList) )

    passPercent = (1.00 - float(len(failures)) / float(numTestIterations)) * 100

    print ""
    print "Test Summary:"
    print "  Iterations:   %d" % numTestIterations
    print "  Failures:     %d" % len(failures)
    print "  Pass Percent: %.2f%%" % passPercent

    if len(failures) > 0:
        print ""
        printColor("Failures:", PrintColors.COLOR_RED)
        for failure in failures:
            iterationNumber,expNumMediaItems,mediaList = failure
            printColor("  [Iteration %d] Expected media items: %d, Media List: %s" % failure, PrintColors.COLOR_RED)

    return 0


if __name__ == "__main__":
    main()

