#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraConstants.py
# Description: A collection of classes with static lookup values to use in place of magic numbers
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

class GpMediaType:
    """
    A lookup table of media types used by GpCamera.getMostRecentMediaFile (and possibly others)
    """

    MEDIA_TYPE_VIDEO = "MP4"
    MEDIA_TYPE_PHOTO = "JPG"
    MEDIA_TYPE_ANY   = "any"


class GpMediaListResponse:
    """
    A lookup table of keys found in the camera's response to a media list query
    """

    KEY_DIRECTORY_NAME    = 'd'
    KEY_FILE_SYSTEM       = 'fs'
    KEY_MODIFICATION_TIME = 'mod'
    KEY_FILENAME          = 'n'
