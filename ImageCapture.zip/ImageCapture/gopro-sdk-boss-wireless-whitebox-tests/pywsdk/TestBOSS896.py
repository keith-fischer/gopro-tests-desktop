#!/usr/local/bin/python

from GpCamera import *
from QAToolbox import *

camera = GpCamera.connectOnCurrentWiFiNetwork()

camera.changeSubMode(GpCameraSubModes.VIDEO)
camera.waitForPollingPeriod()

camera.setShutter(True)
camera.sleep(3000)
camera.setShutter(False)
camera.waitForPollingPeriod(5)

mediaList = camera.getMediaList()
camera.waitForPollingPeriod(5)
dirName = mediaList[0].get('d')
filename = mediaList[0].get('fs')[0].get('n')
filePath = "%s/%s" % (dirName, filename)

metadata = camera.getMediaMetadataV4(filePath)
print "Debug: metadata:\n%s" % pprint.pformat(metadata, width=120)


