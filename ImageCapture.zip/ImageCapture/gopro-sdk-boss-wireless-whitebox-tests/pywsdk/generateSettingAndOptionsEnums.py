#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: generateSettingsAndOptionsEnum.py
# Description: Read GoPro camera JSON and output copy-pasteable code for GpCameraSetting.py containing all the
#              appropriate enum values
# Author: Sean Foley
# Date Created: 17 march 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import argparse
import traceback
import time
import copy
from QAToolbox import *

logger = Logger(Logger.LOG_LEVEL_DEBUG)
TAB_WIDTH = 4

OUTPUT_TYPE_ANDROID        = "android"
OUTPUT_TYPE_IOS            = "ios"
OUTPUT_TYPE_EMBEDDED_LINUX = "embedded linux"
OUTPUT_TYPE_PYTHON         = "python"


def normalizeText(text):
    """
    Replace characters in the string that are invalid for python variable names with valid substitutes

    :param text: A string of text
    :return: The normalized string
    """

    text = str(text)  # convert to str from unicode

    text = text.replace(" ", "_")
    text = text.replace(".", "_")
    text = text.replace("-", "NEG")
    text = text.replace(":", "_")
    text = text.replace("%", "_PERCENT")
    text = text.replace("/", "PER")
    text = text.replace("+", "PLUS")
    return text


def readCommandline():
    """
    Read commandline arguments for script configuration

    :return: A tuple of strings of the form (jsonFilename,outputFilename,outputType)
    """
    usageStr = "%s -j <JSON FILE> <-a | -i | -e | -p> [-o <OUTPUT FILENAME>]" % sys.argv[0]
    descriptionStr = "Generate settings & options enumerations from a GoPro camera's gp/gpControl JSON"
    exampleStr = """Example:
    %s -j     someFile.json -o       GpCameraSettings.java --android
    %s --json someFile.json --output GpCameraSettings.m    -i
    %s --json someFile.json --output GpCameraSettings.c    -e
    %s -j     someFile.json -o       GpCameraSettings.py   -python  -m \"my message like camera & version\"""" %(sys.argv[0],sys.argv[0],sys.argv[0],sys.argv[0])

    parser = argparse.ArgumentParser(prog=sys.argv[0],
                                     usage=usageStr,
                                     epilog=exampleStr,
                                     description=descriptionStr,
                                     formatter_class=argparse.RawTextHelpFormatter)

    parser.add_argument("-j", "--json",
                        help = "Specify the JSON file to read",
                        type = str,
                        default = None)

    parser.add_argument("-o", "--output",
                        help = "Specify the name of the output file",
                        type = str,
                        default = None)

    parser.add_argument("-m", "--message",
                        help="optional: stamps comment into output file like camera & version",
                        type=str,
                        default=None)

    # User can select exactly one of: Android, iOS, or Embedded Linux
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-a", "--android",
                       help = "Output Type: Java for Android test framework",
                       action = "store_true",
                       default = None)
    group.add_argument("-i", "--ios",
                       help = "Output Type: Objective-C for iOS test framework",
                       action = "store_true",
                       default = None)
    group.add_argument("-e", "--embeddedlinux",
                       help = "Output Type: C for Embedded Linux test framework",
                       action = "store_true",
                       default = None)
    group.add_argument("-p", "--python",
                       help = "Output Type: Python for PyWSDK test framework",
                       action = "store_true",
                       default = None)


    args = parser.parse_args()

    if (args.json is None):
        logger.logError("Must specify JSON filename")
        parser.print_help()
        sys.exit(1)
    elif (args.android is None and args.ios is None and args.embeddedlinux is None and args.python is None):
        logger.logError("Must specify an output type")
        parser.print_help()
        sys.exit(1)

    jsonFilename = args.json
    outputFilename = args.output
    if (args.android is not None):
        outputType = OUTPUT_TYPE_ANDROID
    elif (args.ios is not None):
        outputType = OUTPUT_TYPE_IOS
    elif (args.embeddedlinux is not None):
        outputType = OUTPUT_TYPE_EMBEDDED_LINUX
    elif (args.python is not None):
        outputType = OUTPUT_TYPE_PYTHON
    else:
        logger.logError("Uh... broken logic. This should never happen")
        sys.exit(1)
    message = args.message

    return (jsonFilename,outputFilename,outputType,message)


def createSettingAndOptionsDicts(jsonFilename, outputType):
    """
    Create and return a tuple containing two dictionaries:
        1. settingsEnumDict: {"SETTING_NAME_1" : "SETTING_VALUE_1", ..., "SETTING_NAME_N" : "SETTING_VALUE_N"}
        2. optionsEnumDict:  {"OPTION_NAME_1" : "OPTION_VALUE_1", ..., "OPTION_NAME_N" : "OPTION_VALUE_N"}

    :param jsonFilename: A string containing the name of a GoPro camera's gp/gpControl JSON file
    :param outputType: One of the OUTPUT_TYPE_XXX values defined in this file
    :return: A tuple of the form (settingsDict,optionsDict) as described above
    """

    settingsEnumDict = {}
    optionsEnumDict = {}

    try:
        with open(jsonFilename, "r") as inFile:
            settingsJson = json.load(inFile)
    except IOError:
        print "Unable to open/read file: '%s'. Cannot continue." % jsonFilename
        sys.exit(1)

    settingsDict = makeJsonDataHashable(settingsJson)

    KEY_MODES        = "modes"
    KEY_SETTINGS     = "settings"
    KEY_ID           = "id"
    KEY_OPTIONS      = "options"
    KEY_OPTION_VALUE = "value"
    KEY_INFO         = "info"
    KEY_CMD          = "commands"
    KEY_FILTERS      = "filters"



    infoDict = settingsDict.get(KEY_INFO)
    cmdDict = settingsDict.get(KEY_CMD)

    modesDict = settingsDict.get(KEY_MODES)


    if (modesDict is None):
        logger.logError("Unable to get key '%s' from cameraJson:\n%s" % (KEY_MODES, jsonFilename))
        sys.exit(1)

    IGNORED_KEYS = ('used')
    for modeName in modesDict:
        if (modeName in IGNORED_KEYS):
            continue

        settingsDict = modesDict[modeName].get(KEY_SETTINGS)
        if (settingsDict is None):
            logger.logError("Unable to get key '%s' from modesDict[%s].\n%s" % (KEY_SETTINGS,
                                                                                modeName,
                                                                                modesDict[modeName]))

        for settingName in settingsDict:
            if (settingName in IGNORED_KEYS):
                continue

            settingName = str(settingName)

            settingId = settingsDict[settingName].get(KEY_ID)
            if (settingId is None):
                logger.logError("Unable to get key '%s' from settingsDict:\n%s" % (KEY_ID,pprint.pformat(settingsDict)))
                sys.exit(1)

            # Create mapping of setting name to setting ID
            key = "%s_%s" % (modeName.upper(), settingName.upper())
            settingsEnumDict[key] = (settingName, settingId)

            optionsDict = settingsDict[settingName].get(KEY_OPTIONS)
            if (optionsDict is None):
                logger.logError("Unable to get key '%s' from settingsDict['%s'].\n  Keys: %s\n  Dict: %s" %
                                (KEY_OPTIONS,settingName,settingsDict.keys(),pprint.pformat(settingsDict[settingName])))
                sys.exit(1)

            for optionName in optionsDict:
                if (optionName in IGNORED_KEYS):
                    continue

                optionName = str(optionName)

                optionValue = optionsDict[optionName].get(KEY_OPTION_VALUE)
                if (optionValue is None):
                    logger.logError("Unable to get key '%s' from optionsDict['%s'].\n  Keys: %s\n  Dict: %s" %
                                    (KEY_ID, optionName, optionsDict.keys(),pprint.pformat(optionsDict[optionName])))
                    sys.exit(1)

                # Create mapping of option name to option value
                if (outputType == OUTPUT_TYPE_ANDROID):
                    logger.logError("TOOD: Implement this")
                    sys.exit(0)
                elif (outputType == OUTPUT_TYPE_IOS):
                    logger.logError("TOOD: Implement this")
                    sys.exit(0)
                elif (outputType == OUTPUT_TYPE_EMBEDDED_LINUX):
                    logger.logError("TOOD: Implement this")
                    sys.exit(0)
                elif (outputType == OUTPUT_TYPE_PYTHON):
                    key = "%s_%s_%s" % (modeName.upper(), settingName.upper(), optionName.upper())
                    optionsEnumDict[key] = (optionName, optionValue)
                else:
                    logger.logError("Unrecognized output type: '%s'" % outputType)
                    sys.exit(1)

    # Now that we have the raw dictionaries, we need to replace characters that are invalid variable names in most
    # programming languages with valid substitutes
    d = {}
    for key in settingsEnumDict:
        d[normalizeText(key)] = settingsEnumDict[key]
    settingsEnumDict = d

    d = {}
    for key in optionsEnumDict:
        d[normalizeText(key)] = optionsEnumDict[key]
    optionsEnumDict = d

    return (settingsEnumDict,optionsEnumDict, infoDict, cmdDict)


def outputAndroidCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename):
    """
    Outputs Java code for GpCameraSettings.py and GpCameraSettingOptions.py enumeration classes

    :param settingsEnumDict: The settingsEnumDict created by createSettingAndOptionsDicts
    :param optionsEnumDict: The optionsEnumDict created by createSettingAndOptionsDicts
    :param jsonFilename: The name of the JSON file from the commandline
    :param outputFilename: The name of the file to output the code to (or None to send to stdout)
    :return: True if there were no errors; False otherwise
    """

    logger.logError("TODO: Implement")


def outputiOSCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename):
    """
    Outputs Objective-C code for GpCameraSettings.py and GpCameraSettingOptions.py enumeration classes

    :param settingsEnumDict: The settingsEnumDict created by createSettingAndOptionsDicts
    :param optionsEnumDict: The optionsEnumDict created by createSettingAndOptionsDicts
    :param jsonFilename: The name of the JSON file from the commandline
    :param outputFilename: The name of the file to output the code to (or None to send to stdout)
    :return: True if there were no errors; False otherwise
    """

    logger.logError("TODO: Implement")


def outputEmbeddedLinuxCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename):
    """
    Outputs C code for GpCameraSettings.py and GpCameraSettingOptions.py enumeration classes

    :param settingsEnumDict: The settingsEnumDict created by createSettingAndOptionsDicts
    :param optionsEnumDict: The optionsEnumDict created by createSettingAndOptionsDicts
    :param jsonFilename: The name of the JSON file from the commandline
    :param outputFilename: The name of the file to output the code to (or None to send to stdout)
    :return: True if there were no errors; False otherwise
    """

    logger.logError("TODO: Implement")


def outputPythonCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename, infoDict, cmdDict, message = None):
    """
    Outputs Python code for the xxxSETTINGxxx.py and xxxOPTIONxxx.py enumeration classes

    :param settingsEnumDict: The settingsEnumDict created by createSettingAndOptionsDicts
    :param optionsEnumDict: The optionsEnumDict created by createSettingAndOptionsDicts
    :param jsonFilename: The name of the JSON file from the commandline
    :param outputFilename: The name of the file to output the code to (or None to send to stdout)
    :return: True if there were no errors; False otherwise
    """

    INDENT_WHITESPACE = " " * TAB_WIDTH

    # Determine the longest settingId and settingOption for aesthetic whitespace purposes
    maxSettingIdLength = max( [len(key) for key in settingsEnumDict] )
    maxSettingOptionLength = max( [len(key) for key in optionsEnumDict] )

    dt = "%s - %s" % (time.strftime("%d/%m/%Y"),time.strftime("%H:%M:%S"))
    cam = ""
    firm = ""
    if "model_name" in infoDict:
        cam = infoDict["model_name"]
    if "firmware_version" in infoDict:
        firm = infoDict["firmware_version"]
    outputmessage = ""
    if message:
        outputmessage = "\n------------------------\n%s\n------------------------" % message

    outputmessage += "\nCreated: %s\nCamera: %s\nFirmware: %s" % (dt,cam,firm)

    # Generate Python code
    settingStr = """class GpCameraSetting:
    \"\"\"
    An enumeration class to provide GoPro camera setting IDs

    Note: This file was automatically generated by '%s' using '%s',
          which (should) contain a GoPro camera's gp/gpControl JSON data
        %s
    \"\"\"\n\n""" % (sys.argv[0], jsonFilename, outputmessage)

    optionStr = """class GpCameraSettingOption:
    \"\"\"
    An enumeration class to provide GoPro camera setting option values.

    Note: This file was automatically generated by '%s' using '%s',
          which (should) contain a GoPro camera's gp/gpControl JSON data
    \"\"\"\n\n""" % (sys.argv[0], jsonFilename)

    groupStr = """class GpCameraSettingGroups:
    \"\"\"
    An enumeration class to provide GoPro camera grouped setting option values.

    Note: This file was automatically generated by '%s' using '%s',
          which (should) contain a GoPro camera's gp/gpControl JSON data
    \"\"\"\n\n""" % (sys.argv[0], jsonFilename)

    dictStr = """class GpCameraSettingDict:
    def __init__(self):
        self.camera_settings_dict = {}
"""

    # make class GpCameraSetting
    mainmode = ["VIDEO"]
    settingsEnumDict = sorted(settingsEnumDict.items())  # convert to a sorted list of (key,value) tuples
    for key,value in settingsEnumDict:
        whitespace = " " * (maxSettingIdLength - len(key))
        settingStr += "%s%s%s = %s\n" % (INDENT_WHITESPACE, key, whitespace, value)
        items = key.split("_")
        if not items[0] in mainmode:
            mainmode.append(items[0])
    settingStr += "%sMAIN_MODE = [" % INDENT_WHITESPACE
    endln = ""
    for item in mainmode:
        if item == "MULTI":
            item = "MULTI_SHOT"
        settingStr += "%s\"%s\"" % (endln,item)
        endln = ","
    settingStr += "]"

    #build class GpCameraSettingOption
    optionsEnumDict = sorted(optionsEnumDict.items()) # convert to a sorted list of (key,value) tuples
    for key,value in optionsEnumDict:
        whitespace = " " * (maxSettingOptionLength - len(key))
        optionStr += "%s%s%s = %s\n" % (INDENT_WHITESPACE, key, whitespace, value)

    endline = ", #"

    # build class GpCameraSettingGroups
    for key1,value1 in settingsEnumDict:
        whitespace = " " * (maxSettingOptionLength - len(key))
        grpitemoptions = None
        grpitem = "%s%s = (# %s\n" % (INDENT_WHITESPACE,key1,value1)
        matchkey = key1 + "_"
        optfound = False
        el = None
        v2 =None
        for key2, value2 in optionsEnumDict:
            if matchkey in key2:
                strposition = key2.index(matchkey)

                if strposition == 0:
                    if optfound and el:
                        grpitemoptions += el
                    else:
                        grpitemoptions = grpitem
                    optfound = True
                    grpitemoptions += "%s%sGpCameraSettingOption.%s" % (INDENT_WHITESPACE,INDENT_WHITESPACE, key2)
                    el = "%s %s\n" % (endline, value2)
                    v2 = value2
            else:
                if optfound: #close the enum group
                    grpitemoptions += ") # %s\n\n" % (str(v2))
                    groupStr += grpitemoptions
                    break

    #build dictionary

    dictitem = None
    for key1, value1 in settingsEnumDict:
        whitespace = " " * (maxSettingOptionLength - len(key1))

        dictStr += "%s%sself.camera_settings_dict[\"%s\"]%s = %s\n" % (INDENT_WHITESPACE,INDENT_WHITESPACE, key1,whitespace, value1)

        for key2, value2 in optionsEnumDict:
            if key1 in key2:
                if key2.index(key1) == 0:
                    keytemp = key2.replace(key1 + "_","")
                    newkey = key1+"|"+keytemp
                    whitespace = " " * (maxSettingOptionLength - len(newkey))
                    dictStr += "%s%sself.camera_settings_dict[\"%s\"]%s = %s\n" % (INDENT_WHITESPACE,INDENT_WHITESPACE, newkey, whitespace, value2)

    # Send to stdout if output filename is not specified
    if (outputFilename is None):
        print "# File: GpCameraSetting.py"
        print settingStr
        print "\n\n\n"

        print "# File: GpCameraSettingOption.py"
        print optionStr

    # Otherwise, save to specified file
    else:
        try:
            with open(outputFilename, "w") as outFile:
                outFile.write(settingStr)
                outFile.write("\n\n\n")
                outFile.write(optionStr)
                outFile.write("\n\n\n")
                outFile.write(groupStr)
                outFile.write("\n\n\n")
                outFile.write(dictStr)
        except IOError:
            logger.logError("Unable to open '%s' for writing" % outputFilename)
            sys.exit(1)
        except Exception as e:
            logger.logError("Unexpected error: " % e.message)
            traceback.print_exc()
            sys.exit(1)


def main():
    """
    Script starts here.

    :return: 0 on success; 1 otherwise
    """

    jsonFilename,outputFilename,outputType, message = readCommandline()
    settingsEnumDict,optionsEnumDict, infoDict, cmdDict = createSettingAndOptionsDicts(jsonFilename, outputType)

    # Output code appropriate to the specified output type
    if (outputType == OUTPUT_TYPE_ANDROID):
        outputAndroidCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename)
    elif (outputType == OUTPUT_TYPE_IOS):
        outputiOSCode(settingsEnumDict, optionsEnumDict, outputFilename)
    elif (outputType == OUTPUT_TYPE_EMBEDDED_LINUX):
        outputEmbeddedLinuxCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename)
    elif (outputType == OUTPUT_TYPE_PYTHON):
        outputPythonCode(settingsEnumDict, optionsEnumDict, jsonFilename, outputFilename, infoDict, cmdDict, message)
    else:
        logger.logError("Unrecognized output type: '%s'" % outputType)


# If script is run by itself rather than imported, call main()
if (__name__ == "__main__"):
    main()


