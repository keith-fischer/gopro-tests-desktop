#!/usr/local/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: analyze_logs.py
# Description: Used to analyze GoPro camera RTOS logs
# Author: Sean Foley
# Date Created: 12 May 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

"""
TODO List

LinuxErrorAnalyzer:
    An analyzer that reports any time the word "error" appears in the logs--but only if the log filename contains
    the word "linux". Include JIRA ticket references similar to InterestingEventAnalyzer

InterestingEventAnalyzer:
    * Consider putting filenames in the report if we ever analyze more than one for a single test run
    * Colorize the good (green) and bad (red) output
    * Determine how to detect reboots

Consider implementing a tool to parse RTOS logs into reboot cycles
    <FILENAME>.bootcycle1
    <FILENAME>.bootcycle2
    ...
    <FILENAME>.bootcycleN

"""

import argparse
import sys
from LogAnalyzer import *

from CameraSummaryAnalyzer    import *  # Any flavor
from InterestingEventAnalyzer import *  # Any flavor
from RTOSTranscodeAnalyzer    import *  # RTOS flavor
from LinuxUploadAnalyzer      import *  # Linux flavor
from LinuxMooseAnalyzer       import *  # Linux flavor (special, disabled unless specifically enabled)

# Static global variables
LOG_FLAVOR_RTOS = "rtos"
LOG_FLAVOR_LINUX = "linux"
LOG_FLAVORS = (LOG_FLAVOR_RTOS, LOG_FLAVOR_LINUX)

mainLogger = Logger(Logger.LOG_LEVEL_DEBUG)


def parseCommandlineArgs():
    """
    Read and parse commandline

    :return: The result of argparse.ArgumentParser.parse_args(), which contains all the parsed commandline stuff
    """

    usageStr = "%s -f <LOG FLAVOR> [-s <SPECIAL ANALYZERS>] -l <LOG1> [LOG2 ... LOGN]" % sys.argv[0]
    descriptionStr = "A tool to automate log analysis of various types of GoPro logging"
    epilogStr = """Example:
    %s -f rtos rtoslog1.log rtoslog2.log
    %s --flavor linux linuxlog.log
    %s -f linux -s JakartaMediaAnalyzer linuxlog.log""" % (sys.argv[0], sys.argv[0], sys.argv[0])

    parser = argparse.ArgumentParser(prog=sys.argv[0],
                                     usage=usageStr,
                                     description=descriptionStr,
                                     epilog=epilogStr,
                                     formatter_class=argparse.RawTextHelpFormatter)

    parser.add_argument(
        "-f", "--flavor",
        help="Specify the flavor of log file",
        choices=LOG_FLAVORS,
        required=True
    )
    parser.add_argument(
        "-s", "--enablespecial",
        help="Enable special Analyzers that are disabled by default",
        nargs="+",
        default=[]
    )
    parser.add_argument(
        "-l", "--logfiles",
        help="Specify a list of log files to consume",
        nargs="+",
        required=True
    )

    args = parser.parse_args()
    return args


def main():
    """
    Script starts here. Hur dur.
    :return: 1 if there is an error; 0 otherwise
    """

    args = parseCommandlineArgs()
    filenames = args.logfiles
    specialAnalyzers = args.enablespecial

    logAnalyzer = LogAnalyzer(filenames)
    logAnalyzer.addAnalyzer( CameraSummaryAnalyzer() )

    # Add Analyzers based on the log flavor
    logFlavor = args.flavor
    if logFlavor == LOG_FLAVOR_RTOS:
        logAnalyzer.addAnalyzer( RTOSTranscodeAnalyzer() )
    elif logFlavor == LOG_FLAVOR_LINUX:
        logAnalyzer.addAnalyzer( LinuxUploadAnalyzer() )
    else:
        mainLogger.logError("Invalid log flavor '%s'. This should never happen!" % logFlavor)
        sys.exit(1)

    logAnalyzer.addAnalyzer( InterestingEventAnalyzer() )

    # Add user-specified special Analyzers that are normally disabled by default
    for specialAnalyzer in specialAnalyzers:
        classDeclarationStr = specialAnalyzer + "()"
        try:
            logAnalyzer.addAnalyzer( eval(classDeclarationStr) )
        except:
            mainLogger.logError("Unable to add special analyzer '%s'" % specialAnalyzer)
            traceback.print_exc()
            sys.exit(1)

    logAnalyzer.analyze()
    reports = logAnalyzer.getReports()


    print """
 .------------------.___________________________________
/                   | L U M B E R J A C K  |           |`-.,_
\###################| L O G   R E A D E R  |###########|,-'`
 `------------------'----------------------:           l
                                            /           \\
                                           /             \\
                                         ,'               `.
                                      .d8b.               .d8b.
                                      "Y8888p..       ,.d8888P"
                                        "Y88888888888888888P"
                                           ""YY8888888PP""
    """

    print "=-" * 40
    print "Reports:"
    print "=-" * 40
    for analyzerName,report in reports:
        print "[Analyzer: %s]" % analyzerName
        print report
        print ""


if __name__ == "__main__":
    main()

