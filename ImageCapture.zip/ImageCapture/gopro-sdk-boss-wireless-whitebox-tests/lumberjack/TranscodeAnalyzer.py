import pprint
import re
from Analyzer import *

class TranscodeAnalyzer(Analyzer):

    UNINITIALIZED_TRANSCODE = {
        'sourceFilename':"???.MP4",
        'origWidth':"<W>",
        'origHeight':"<H>",
        'origFps':"<FPS>",
        'origBitrate':"<BITRATE>",
        'progress':0,
        'isInitialized':False,
        'isStarted':False,
        'isComplete':False,
        'outputFilename':None,
        'newWidth':"<W>",
        'newHeight':"<H>",
        'newDuration':"<DURATION>",
        'newFps':"<FPS>",
        'transcodeTime':"<TRANSCODE TIME>"
    }

    def __init__(self):
        # [00109852][CA9_1] pb_parse_file_lite File = C:\DCIM\100GOPRO\GOPR0106.MP4, Width = 3840, Height = 2160, timescale = 24000, frm_duration = 1001 AR_16x9 1 fps 24 bitrate 60188549
        self.__transcodeInitRegex     = re.compile("pb_parse_file_lite File = (C:.*\.MP4).*Width = ([0-9]+), Height = ([0-9]+).*fps ([[0-9]+) bitrate ([0-9]+)")

        # [00135174][CA9_1] 25029 ms - Video: Dmx/Dec/Enc/Mux       560      550      544      544  - Audio:  Dmx/Mux  1258 1150, progress pcnt 37
        self.__transcodeProgressRegex = re.compile("progress pcnt ([0-9]+)")

        #[00508968][CA9_1] Output File: C:\DCIM\100GOPRO\GOPR0233.TRV  HxW 1080x1920  Dur 60201 ms  Frames/Sec 119.88  Time 117547 ms
        self.__transcodeCompleteRegex = re.compile("Output File: *(C:.*\.TRV) *HxW *([0-9]+)x([0-9]+) *Dur *([0-9]+) ms *Frames/Sec *([0-9\.]+) *Time *([0-9]+) ms")

        self.__currentTranscode = TranscodeAnalyzer.UNINITIALIZED_TRANSCODE.copy()
        self.__transcodeDatae = []


    def analyze(self, line, timestamp=None):
        """
        Look for instances of transcoding initializing, starting, progressing, stopping, completing

        :param line: A str containing a single line of log text
        :param timestamp: A str containing the formatted timestamp of the line
        :return: None
        """

        # Check for transcode initializing
        ret = self.__transcodeInitRegex.search(line)
        if ret is not None:
            # In case a previous transcode did not complete successfully...
            if self.__currentTranscode.get('isInitialized') == True:
                self.__transcodeDatae.append(self.__currentTranscode)
                self.__currentTranscode = TranscodeAnalyzer.UNINITIALIZED_TRANSCODE.copy()

            sourceFilename,origWidth,origHeight,origFps,origBitrate = ret.groups()
            self.__currentTranscode['isInitialized']  = True
            self.__currentTranscode['sourceFilename'] = sourceFilename.split("\\")[-1]
            self.__currentTranscode['origWidth']      = origWidth
            self.__currentTranscode['origHeight']     = origHeight
            self.__currentTranscode['origFps']        = origFps
            self.__currentTranscode['origBitrate']    = origBitrate
            return

        # Check for new transcode making progress
        ret = self.__transcodeProgressRegex.search(line)
        if ret is not None:
            progress = ret.groups()[0]

            previousProgress = int(self.__currentTranscode.get('progress'))
            updatedProgress = int(progress)

            # Odd scenario that was seen in BOSS-752 logs where one transcode stopped being logged and another started
            # up in the middle
            if updatedProgress < previousProgress:
                self.__transcodeDatae.append(self.__currentTranscode)
                self.__currentTranscode = TranscodeAnalyzer.UNINITIALIZED_TRANSCODE.copy()
                return
            else:
                self.__currentTranscode['isStarted'] = True
                self.__currentTranscode['progress']  = progress
                return

        # Check for transcode finishing
        ret = self.__transcodeCompleteRegex.search(line)
        if ret is not None:
            filePath,newHeight,newWidth,newDuration,newFps,transcodeTime = ret.groups()
            self.__currentTranscode['isComplete']     = True
            self.__currentTranscode['outputFilename'] = filePath.split("\\")[-1]
            self.__currentTranscode['newWidth']       = newWidth
            self.__currentTranscode['newHeight']      = newHeight
            self.__currentTranscode['newDuration']    = newDuration
            self.__currentTranscode['newFps']         = newFps
            self.__currentTranscode['transcodeTime']  = transcodeTime

            self.__transcodeDatae.append(self.__currentTranscode)
            self.__currentTranscode = TranscodeAnalyzer.UNINITIALIZED_TRANSCODE.copy()
            return


    def getReport(self):
        """
        Get a summary report of what the analyzer found

        :return: A str containing the report
        """

        # Cleanup any leftovers that didn't complete
        if self.__currentTranscode.get('isInitialized') == True:
            self.__transcodeDatae.append(self.__currentTranscode)

        report = ""
        for transcodeData in self.__transcodeDatae:
            report += "  Transcode Input:  '%s' " % transcodeData.get('sourceFilename')
            report += "(%sx%s) " % (transcodeData.get('origWidth'), transcodeData.get('origHeight'))
            report += "@ %s fps " % transcodeData.get('origFps')
            report += "with %s bps bitrate)\n" % transcodeData.get('origBitrate')

            if transcodeData.get('isComplete') == True:
                report += "  Transcode Output: '%s' " % transcodeData.get('outputFilename')
                report += "(%sx%s) " % (transcodeData.get('newWidth'), transcodeData.get('newHeight'))
                report += "@ %s fps\n" % transcodeData.get('newFps')
                report += "  Time to Transcode: %s ms\n" % transcodeData.get('transcodeTime')

            elif transcodeData.get('isStarted') == True:
                report += "  Transcode Output: None. Transcode started but stopped at %s%%\n" % transcodeData.get('progress')

            elif transcodeData.get('isInitialized'):
                report += "  Transcode Output: None. Transcode did not start\n"

            else:
                status = "Error: transcodeData has an unexpected form:\n%s" % pprint.pformat(transcodeData)

            report += "\n"

        return report


