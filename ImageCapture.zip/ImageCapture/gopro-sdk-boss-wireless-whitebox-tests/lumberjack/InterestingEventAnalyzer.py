
import re
from Analyzer import *


class InterestingEventAnalyzer(Analyzer):
    def __init__(self):

        # A list of tuples of the form (regex, description) such that:
        #   regex       : A compiled regular expression to identify a line of logging
        #   description : A human-readable translation of what regex implies
        tags = []

        # A list of tuples of the form (timestamp, description, line) such that:
        #   timestamp   : A formatted timestamp string
        #   description : A human-readable translation of what happened during the current line of logging
        #   line        : The current line of logging
        self.__interestingData = []

        #--------------------------------
        # Generally good/neutral things
        #--------------------------------
        tags.append((re.compile("Powering off\.\.\."),
                     "Camera shutdown"))
        # TODO: Add good things like reboot

        #-----------------------
        # Generally bad things
        #-----------------------
        tags.append((re.compile("Thermal shutdown daemon.*ungraceful"),
                      "Thermal shutdown")) # RTOS
        tags.append((re.compile("DSP assertion"),
                     "STK-3751: DSP Assertion"))
        tags.append((re.compile("DSP no response from VOUT"),
                      "STK-3751: DSP not responding")) # RTOS
        tags.append((re.compile("^Oops: CPU Exception"),
                     "Kernel oops")) # RTOS
        tags.append((re.compile("\[sched_delayed\]"),
                     "Kernel: Scheduling Problem!!"))  # Mark Petersen email (Friday, June 3, 2016 at 4:46 PM)

        #--------------------------------
        # CAH (Camera As a Hub) related
        #--------------------------------
        # Good things
        tags.append((re.compile("uploadFile:.*file.*DCIM.*\.TRV"),
                    "CAH: Upload file"))
        tags.append((re.compile("UPLOAD Complete for item.*\.TRV"),
                    "CAH: Upload complete"))
        tags.append((re.compile("CONNECTED to Internet"),
                     "Connected to Internet"))
        tags.append((re.compile("Starting womDaemon daemon"),
                     "WOM starting"))
        tags.append((re.compile("pb_parse_file_lite File"),
                     "Setting up transcode"))
        tags.append((re.compile("progress pcnt 0"),
                     "Transcode beginning"))
        tags.append((re.compile("Output File:.*\.TRV"),
                     "Transcode successful"))
        tags.append((re.compile("Transcode success"),
                     "Transcode successful"))

        # Bad things
        tags.append((re.compile("womDaemon.*no-longer-running"),
                     "WOM daemon not running"))  # Wireless Offload Manager
        tags.append((re.compile("uploadFile: Error gumi empty"),
                     "Upload error"))
        tags.append((re.compile("transcode failed"),
                     "Transcode failed"))
        tags.append((re.compile("transcode timed out"),
                     "BOSS-733: Transcode timed out"))
        tags.append((re.compile("Transcode did not complete in time"),
                    "Transcode timed out"))
        tags.append((re.compile("Source file to be transcoded"),
                     "Transcoding file"))

        # TODO: Determine what logs says CAH(A) is starting/stopping
        # TODO: Device token fetching?
        # TODO: Provisioning errors?
        # TODO: WiFi state errors?
        # TODO: [ 2412.568872] [sched_delayed] sched: RT throttling activated  (Mark Petersen: "very bad")
        # TODO: AmbaDSP_WaitEventFlag(0x80, 1, 1000) timeout ---> some kind of DSP problem, should run dsp -4096 > c:\dsp_log.txt (sends to SD card)


        #-----------------------------------------------------------------------
        # Logs to explicitly ignore due to them being uninteresting or spammed
        #-----------------------------------------------------------------------
        uninterestingLogs = []

        self.__tags = tags
        self.__uninterestingLogs = uninterestingLogs


    def analyze(self, line, timestamp=None):
        """
        Look for interesting events in each line of logging

        :param line: A str containing a single line of log text
        :param timestamp: A str containing the formatted timestamp of the line
        :return: None
        """

        for regex,description in self.__tags:
            ret = regex.search(line)
            if ret is not None:
                isLineInteresting = True
                for meh in self.__uninterestingLogs:
                    if meh in line:
                        isLineInteresting = False

                if isLineInteresting:
                    self.__interestingData.append( (timestamp,description,line) )


    def getReport(self):
        """
        Get a summary report of what the analyzer found

        :return: A str containing the report
        """

        report = ""

        if len(self.__interestingData) == 0:
            report = "None"
        else:
            maxDescriptionLen = max( [len(x[1]) for x in self.__interestingData] )

            for timestamp,description,line in self.__interestingData:
                paddingLen = 1
                whitespace = " " * (maxDescriptionLen - len(description) + paddingLen)

                report += "  [%s] [%s]%s-- %s\n" % (timestamp, description, whitespace, line)

        return report

