import re
from Analyzer import *

class CameraSummaryAnalyzer(Analyzer):
    def __init__(self):
        # Linux regexes
        self.__linuxSerialRegex          = re.compile(":  SERIAL *=(.*)")
        self.__linuxNameRegex            = re.compile(":  NAME *=(.*)")
        self.__linuxFirmwareVersionRegex = re.compile(":  VERSION *=(.*)")
        self.__linuxModelRegex           = re.compile(":  MODEL *=(.*)")

        # RTOS regexes
        self.__rtosSerialRegex          = re.compile('"camera serial number":"([^"]+)",')
        self.__rtosFirmwareVersionRegex = re.compile('"firmware version":"([^"]+)",')
        self.__rtosModelRegex           = re.compile('"camera type":"([^"]+)",')

        self.__serial   = None
        self.__name     = None
        self.__firmware = None
        self.__model    = None


    def analyze(self, line, timestamp=None):
        """
        Search the logs for camera summary information (i.e. model, serial, name, firmware version, ...)

        :param line: A str containing a single line of log text
        :param timestamp: A str containing the formatted timestamp of the line
        :return: None
        """

        # Look for the serial number
        if self.__serial is None:
            ret = self.__linuxSerialRegex.search(line)
            if ret is not None:
                self.__serial = ret.groups()[0]
                return

            ret = self.__rtosSerialRegex.search(line)
            if ret is not None:
                self.__serial = ret.groups()[0]
                return

        # Look for the camera name
        if self.__name is None:
            ret = self.__linuxNameRegex.search(line)
            if ret is not None:
                self.__name = ret.groups()[0]
                return

        # Look for the camera's firmware version string
        if self.__firmware is None:
            ret = self.__linuxFirmwareVersionRegex.search(line)
            if ret is not None:
                self.__firmware = ret.groups()[0]
                return

            ret = self.__rtosFirmwareVersionRegex.search(line)
            if ret is not None:
                self.__firmware = ret.groups()[0]
                return

        # Look for the camera model
        if self.__model is None:
            ret = self.__linuxModelRegex.search(line)
            if ret is not None:
                self.__model = ret.groups()[0]
                return

            ret = self.__rtosModelRegex.search(line)
            if ret is not None:
                self.__model = ret.groups()[0]
                return


    def getReport(self):
        """
        Get a summary report of what the analyzer found

        :return: A str containing the report
        """

        report = ""
        report += "  Camera Name: %s\n" % (self.__name     if self.__name     is not None else "Unknown")
        report += "  Serial:      %s\n" % (self.__serial   if self.__serial   is not None else "Unknown")
        report += "  Model:       %s\n" % (self.__model    if self.__model    is not None else "Unknown")
        report += "  Firmware:    %s\n" % (self.__firmware if self.__firmware is not None else "Unknown")

        return report

