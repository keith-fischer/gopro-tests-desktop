# ----------------------------------------------------------------------------------------------------------------------
# File: QAToolbox.py
# Description: A library of useful items!
# Author: Sean Foley
# Date Created: 6 January 2016
# ----------------------------------------------------------------------------------------------------------------------

import awake
import json
import pprint
import socket
import sys
import time
import traceback


# ----------------------------------------------------------------------------------------------------------------------
# Class: Logger
# Description: A class that allows the user to set a logging level and then [DESCRIPTION]
# ----------------------------------------------------------------------------------------------------------------------
class Logger:
    # Static variables
    LOG_LEVEL_UNKNOWN = -1
    LOG_LEVEL_NOISE   = 0
    LOG_LEVEL_DEBUG   = 1
    LOG_LEVEL_WARNING = 2
    LOG_LEVEL_ERROR   = 3

    LOG_LEVEL_LABELS = {LOG_LEVEL_NOISE   : "noise",
                        LOG_LEVEL_DEBUG   : "debug",
                        LOG_LEVEL_WARNING : "warning",
                        LOG_LEVEL_ERROR   : "error"}

    # Same dict as LOG_LEVEL_LABELS but with key:values switched
    LOG_LEVEL_VALUES = {y:x for x,y in LOG_LEVEL_LABELS.iteritems()}

    LOG_LEVEL_UNKNOWN_LABEL = "unknown"


    # ------------------------------------------------------------------------------------------------------------------
    # Initializer
    # ------------------------------------------------------------------------------------------------------------------
    def __init__(self, logLevel):
        self.__logLevel = None

        if (logLevel.__class__ is int):
            self.setLogLevel(logLevel)

        elif (logLevel.__class__ is str):
            self.setLogLevel(Logger.getLogLevelValue(logLevel))

        else:
            print "Error in Logger.__init__: Unrecognized log level type: %s" % str(logLevel.__class__)
            self.__logLevel = Logger.LOG_LEVEL_UNKNOWN

        self.__initialized = True if (self.__logLevel != Logger.LOG_LEVEL_UNKNOWN) else False
        if (not self.__initialized):
            print "Warning: Logger is not initialized and cannot be used"


    # ------------------------------------------------------------------------------------------------------------------
    # Static Methods
    # ------------------------------------------------------------------------------------------------------------------
    @staticmethod
    def getLogLevelLabel(logLevelValue):
        if (logLevelValue in Logger.LOG_LEVEL_LABELS):
            return Logger.LOG_LEVEL_LABELS[logLevelValue]
        else:
            return Logger.LOG_LEVEL_UNKNOWN_LABEL

    @staticmethod
    def getLogLevelValue(logLevelLabel):
        if (logLevelLabel in Logger.LOG_LEVEL_VALUES):
            return Logger.LOG_LEVEL_VALUES[logLevelLabel]
        else:
            return Logger.LOG_LEVEL_UNKNOWN


    # ------------------------------------------------------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------------------------------------------------------
    def getLogLevel(self):
        return self.__logLevel

    def setLogLevel(self, newLogLevelValue):
        if (newLogLevelValue in Logger.LOG_LEVEL_LABELS):
            self.__logLevel = newLogLevelValue
        else:
            self.__logLevel = Logger.LOG_LEVEL_UNKNOWN


    # ------------------------------------------------------------------------------------------------------------------
    # Logging Helper Functions
    # ------------------------------------------------------------------------------------------------------------------
    def logNoise(self, msg):
        self.__log(self.LOG_LEVEL_NOISE, msg)

    def logDebug(self, msg):
        self.__log(self.LOG_LEVEL_DEBUG, msg)

    def logWarning(self, msg):
        self.__log(self.LOG_LEVEL_WARNING, msg)

    def logError(self, msg):
        self.__log(self.LOG_LEVEL_ERROR, msg)


    # ------------------------------------------------------------------------------------------------------------------
    # Private Function: __log
    #
    # Input level: The level at which msg is logged
    # Input msg: A string to print out
    #
    # Postcondition: The method has printed msg wrapped in the calling method
    #   if the given (level) is greater than or equal to the global log level
    # ------------------------------------------------------------------------------------------------------------------
    def __log(self, level, msg):
        if (level >= self.__logLevel):
            callingMethodName = sys._getframe(2).f_code.co_name
            logLabel = self.getLogLevelLabel(level)

            try:
                callingClassName = str(sys._getframe(2).f_locals['self'].__class__)
                callingClassName = callingClassName.split(".")[-1]
                callingClassName += "."
            except KeyError:
                callingClassName = ""

            if (not self.__initialized):
                print "Error in %s: Logger is not initialized" % callingMethodName
            else:
                logMsg = "[%s in %s%s]: %s" % (logLabel.capitalize(), callingClassName, callingMethodName, msg)

                if (level == Logger.LOG_LEVEL_WARNING):
                    printColor(logMsg, PrintColors.COLOR_YELLOW)
                elif (level == Logger.LOG_LEVEL_ERROR):
                    printColor(logMsg, PrintColors.COLOR_RED)
                else:
                    print logMsg


# ----------------------------------------------------------------------------------------------------------------------
# Class: JsonDataHelper
# ----------------------------------------------------------------------------------------------------------------------
class JsonDataHelper:
    """
    Converts JSON data into a set of dicts-within-dicts (i.e. no lists) so that every value can be hashed to directly
    without guessing at index numbers. Class also provides a convenient API to search the data
    """

    def __init__(self, logger=None):
        """
        Class initializer

        :param logger: Optional argument to specify a Logger object so logging can be kept maintained across classes
        :return:
        """
        if (logger is not None):
            self.logger = logger
        else:
            self.logger = Logger(Logger.LOG_LEVEL_WARNING)

        # Note: JSON data must be loaded by calling initWithFile or initWithDict
        self.__jsonDict = None


    def initWithFile(self, jsonFilename):
        """
        Initialize the class by getting JSON content from a file.

        :param jsonFilename: The name of the file containing the JSON to process
        :return: True if there was no error; False otherwise
        """

        try:
            with open(jsonFilename, "r") as inFile:
                jsonData = json.load(inFile)
        except:
            self.logger.logError("Unable to read JSON file: %s. Manager will not be usable" % jsonFilename)
            traceback.print_exc()
            return False

        self.__jsonDict = makeJsonDataHashable(jsonData)
        return True


    def initWithDict(self, jsonDict):
        """
        Initialize the class by getting JSON content from a dict.

        :param jsonDict: A Python dict containing JSON data
        :return: True if there was no error; False otherwise
        """

        if (jsonDict.__class__ != dict):
            self.logger.logError("Parameter jsonDict must be a dict")
            sys.exit(1)

        self.__jsonDict = makeJsonDataHashable(jsonDict)
        return True


# ----------------------------------------------------------------------------------------------------------------------
# Global Helper functions
# ----------------------------------------------------------------------------------------------------------------------
def searchJsonWithHashPath(jsonDict, keys=None, logger=Logger(Logger.LOG_LEVEL_WARNING)):
    """
    Search through the nested dictionaries in the class's internally stored JSON data

    ;param jsonDict: A dict of JSON data that has been sent through makeJsonDataHashable (so it's all dict-within-dict)
    :param keys: A list of str such that keys forms a "hash path" into the internally stored JSON dict-within-dict
    :return: The sought target in the JSON data if found; None otherwise
    """
    if (jsonDict is None):
        logger.logError("Manager was not properly initialized and cannot be used.")
        return None

    if (keys is None):
        return jsonDict

    # Sanity check
    if (len(keys) == 0):
        logger.logWarning("Length of keys list is zero")
        return None

    dictIterator = jsonDict
    for key in keys:
        if (key in dictIterator):
            dictIterator = dictIterator[key]
        else:
            logger.logWarning("Key \"%s\" not found in JSON dict" % key)
            return None

    # Update the visitor count
    if ('used' not in dictIterator):
        logger.logWarning('Key "%s" not found in dictIterator: %s' % ('used', pprint.pformat(dictIterator)))
    else:
        dictIterator['used'] += 1

    return dictIterator


def sendWakeOnLan(macAddr, ipAddr, logger=Logger(Logger.LOG_LEVEL_WARNING)):
    """
    Send a number of Wake On Lan (WOL) packets to the camera to get it to wake up

    :param macAddr: The MAC address of the device to send WOL to
    :param ipAddr: The IP address of the device to send WOL to
    :return:
    """
    PACKETS_TO_SEND = 3
    TIME_BETWEEN_PACKETS = 1.000 # sec

    # Send a few WOL (Wake On Lan) packets
    logger.logDebug("Sending %d Wake On Lan (WOL) packets to (IP: %s, MAC: %s) to wake it up." %
                    (PACKETS_TO_SEND, ipAddr, macAddr))
    for i in range(PACKETS_TO_SEND):
        try:
            awake.wol.send_magic_packet(macAddr, dest=ipAddr)
            time.sleep(TIME_BETWEEN_PACKETS)
        except socket.error as e:
            logger.logError("Error sending Wake On Lan (WOL) packet: '%s'" % e.message)


def makeJsonDataHashable(data, logger=Logger(Logger.LOG_LEVEL_WARNING)):
    """


    TODO: Rewrite this


    Convert all list-of-dicts into dicts where the keys are the display_value key from each dict within the list
    This is done so we can hash all the data from the JSON object w/o having to search in lists for the piece of
    information we want

    The function has converted lists within jsonData to dictionaries that have keys corresponding to
    display_name from the JSON data

    :param data: A dictionary of JSON data read from a GoPro camera's settings. When method is called recursively,
                data is any element found in the initial input (expected: dict, list or str,unicode,int,float)
    :return: The massaged dict
    """

    # Base Case 1: Sent a string ---> Do nothing
    if (data.__class__ in (str,unicode,int,float)):
        logger.logNoise("Constant value found so do nothing: %s" % str(data))
        return data

    # Recursive Case 1: Sent a list ---> might be able to convert to dict with display_name keys
    elif (data.__class__ is list):
        logger.logNoise("Found list: Length: %d" % len(data))
        newDict = {}
        newDict['used'] = 0
        for i in range(len(data)):
            if (data[i].__class__ is dict):
                logger.logNoise("List item: data[%d]: %s" % (i, str(data[i])))
                data[i] = makeJsonDataHashable(data[i])

                # This shouldn't happen!
                if (data[i] is None):
                    logger.logError("Error: We somehow destroyed the data!")
                    sys.exit(1)

                # This bit is tricky. If we have a list that contains dictionaries, we want to convert
                #   the list into a dictionary of key:value pairs such that each value is the former list item.
                #   This means each value needs to be associated with a key.
                #   If we cannot find a meaningful key to use, then we cannot convert the list-of-dicts into a
                #   dict-of-dicts...
                #   One possible solution would be to use the list index as the key but this may make searching
                #   ugly...?
                if ('path_segment' in data[i]):
                    newKey = data[i]['path_segment']
                elif ('display_name' in data[i]):
                    newKey = data[i]['display_name']
                elif ('id' in data[i]):
                    newKey = str(data[i]['id'])
                else:
                    """
                    errMsg = "Unable to convert list to dict because no usable key found in data[%d]\n" % i
                    errMsg += "data[%d]: %s\n\n" % (i, pprint.pformat(data[i]))
                    errMsg += "data: %s" % pprint.pformat(data)
                    logger.logNoise(errMsg)
                    return data # can't convert to dictionary w/o a key
                    """
                    # Experiment: This may make searching ugly?
                    newKey = str(i)

                newDict[newKey] = data[i]

        logger.logNoise("Converted list to dict: %s" % newDict)
        return newDict

    # Recursive Case 2: Sent a dictionary ---> Go through key:value pairs, making entries consistent
    elif (data.__class__ is dict):
        logger.logNoise(">>> Found dict")
        for key in data:
            logger.logNoise("Key in dict: %s" % key)
            data[key] = makeJsonDataHashable(data[key])
            if (data[key].__class__ is dict):
                data[key]['used'] = 0
        data['used'] = 0
        logger.logNoise("<<< End of dict")
        return data

    else:
        logger.logError("Unknown data type: %s" % data.__class__)


# ----------------------------------------------------------------------------------------------------------------------
# Print out text in color!
# ----------------------------------------------------------------------------------------------------------------------
class PrintColors:
    """
    A lookup table of values that can be used to print out text in color. Goes hand in hand with printColor
    and getColorString below
    """

    # High intensity colors (the "regular" ones are '\033[3Xm' (for X in [0..7]) but are too dark)
    COLOR_BLACK  = '\033[90m'
    COLOR_RED    = '\033[91m'
    COLOR_GREEN  = '\033[92m'
    COLOR_YELLOW = '\033[93m'
    COLOR_BLUE   = '\033[94m'
    COLOR_PURPLE = '\033[95m'
    COLOR_CYAN   = '\033[96m'
    COLOR_WHITE  = '\033[97m'

    # Turn off special coloring
    COLOR_OFF = '\033[0m'


def printColor(msg, color):
    """
    Print out a string of text in color

    :param msg: The string to print
    :param color: One of PrintColors.XXX values
    :return: None
    """

    print "%s%s%s" % (color,msg,PrintColors.COLOR_OFF)


def getColorString(msg, color):
    """
    Get a string of text wrapped in special code so that, when printed, will be in color

    :param msg: The string to wrap
    :param color: One of PrintColors.XXX values
    :return: A string wrapped in special command code to colorize it
    """

    return "%s%s%s" % (color,msg,PrintColors.COLOR_OFF)

