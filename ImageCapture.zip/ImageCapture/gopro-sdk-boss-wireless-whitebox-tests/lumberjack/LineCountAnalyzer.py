
from Analyzer import *

class LineCountAnalyzer(Analyzer):
    def __init__(self):
        self.__numLines = 0

    def analyze(self, line, timestamp=None):
        self.__numLines += 1

    def getReport(self):
        return "Number of lines: %d" % self.__numLines
