import re
from Analyzer import *

class UploadAnalyzer(Analyzer):

    UNINITIALIZED_UPLOAD = {
        'isInitialized':False,
        'isComplete':False,
        'sourceFilename':"<SOURCE FILENAME>",
        'uploadedFilename':"<UPLOADED FILENAME>",
        'filesize':0
    }

    def __init__(self):
        # [INFO]: Gopro Uploading file [/tmp/fuse_d/DCIM/100GOPRO/GOPR0106.TRV] [113493317] bytes wxh (1920x1080) src [/tmp/fuse_d/DCIM/100GOPRO/GOPR0106.MP4]
        self.__startUploadRegex = re.compile("Gopro Uploading file \[(.*\.TRV)\] \[([0-9]+)\] bytes")

        # [NOTICE]: UPLOAD Complete for item [/tmp/fuse_d/DCIM/100GOPRO/GOPR0106.TRV]
        self.__uploadCompleteRegex = re.compile("UPLOAD Complete for item \[(.*\.TRV)\]")

        self.__currentUpload = UploadAnalyzer.UNINITIALIZED_UPLOAD.copy()
        self.__uploadDatae = []


    def analyze(self, line, timestamp=None):
        """
        Look for instances of transcoding initializing, starting, progressing, stopping, completing

        :param line: A str containing a single line of log text
        :param timestamp: A str containing the formatted timestamp of the line
        :return: None
        """

        ret = self.__startUploadRegex.search(line)
        if ret is not None:
            # In case a previous upload did not finish...
            if self.__currentUpload.get('isInitialized') == True:
                self.__uploadDatae.append(self.__currentUpload)
                self.__currentUpload = UploadAnalyzer.UNINITIALIZED_UPLOAD.copy()

            filePath,filesize = ret.groups()
            sourceFilename = filePath.split("/")[-1]

            self.__currentUpload['isInitialized'] = True
            self.__currentUpload['sourceFilename'] = sourceFilename
            self.__currentUpload['filesize']      = filesize
            return

        ret = self.__uploadCompleteRegex.search(line)
        if ret is not None:
            uploadedFilename = ret.groups()[0]
            self.__currentUpload['isComplete'] = True
            self.__currentUpload['uploadedFilename'] = uploadedFilename

            self.__uploadDatae.append(self.__currentUpload)
            self.__currentUpload = UploadAnalyzer.UNINITIALIZED_UPLOAD.copy()
            return


    def getReport(self):
        """
        Get a summary report of what the analyzer found

        :return: A str containing the report
        """

        # Cleanup any leftovers that didn't complete
        if self.__currentUpload.get('isInitialized') == True:
            self.__uploadDatae.append(self.__currentUpload)

        report = ""
        for uploadDatum in self.__uploadDatae:
            report += "  Upload File: '%s' " % uploadDatum.get('sourceFilename')
            if uploadDatum.get('isComplete') == True:
                report += "(complete)\n"
            else:
                report += "(incomplete)\n"

        return report
