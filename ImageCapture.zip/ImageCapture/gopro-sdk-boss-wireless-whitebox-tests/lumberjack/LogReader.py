#!/usr/local/bin/python

import os
import pprint
import re
import sys


class TimeStampRegexes:

    TRANSCODE_MANAGER = re.compile("^(20[0-9][0-9])-([0-9][0-9])-([0-9][0-9])." +
                                   "([0-9][0-9]):([0-9][0-9]):([0-9][0-9])\.([0-9][0-9][0-9])")


class LogReader:
    """
    A utility class that provides an convenient API that allows reading a set of log files one line at a time
    without worrying about transitioning between files
    """

    def __init__(self, filenames):
        """
        Initializer

        :param filenames: A list of log filenames
        :return: None
        """

        self.__filenames = []
        self.__nextFilenamesIndex = 0  # index of the next log file to read

        self.__log = None
        self.__logIndex = 0

        # Store timestamp information for each line as it is read (if there is any)
        self.__year        = None
        self.__month       = None
        self.__day         = None
        self.__hour        = None
        self.__minute      = None
        self.__second      = None
        self.__millisecond = None

        # Only store log files that actually exist
        for filename in filenames:
            if not os.path.exists(filename):
                print "Warning: File not found: '%s'" % filename
            else:
                self.__filenames.append(filename)

        if len(self.__filenames) < 1:
            print "Warning: No log files found."


    def getCurrentLogFilename(self):
        """
        Getter
        :return: The filename of the current log
        """
        return self.__filenames[self.__nextFilenamesIndex-1]


    def __readLogFile(self, filename):
        """
        Private method that reads the next log file into a list of str

        :param filename: The log filename to read
        :return: The list of str containing the contents of filename or None if there's an error
        """

        try:
            with open(filename, "r") as f:
                data = f.readlines()
        except IOError:
            print "Error: Unable to open/read file: '%s'" % filename
            return None

        return data


    def getNextLine(self):
        """
        Get the next line of logging from the current file. Read in the next file if necessary
        :return: A string containing the contents of the next line of logging or None if there's an error
        """

        # If current log is empty...
        if self.__log is None:
                # If there are more logs we can read...
            if self.__nextFilenamesIndex < len(self.__filenames):
                    # Read the next log file and prepare to return lines from it
                self.__log = self.__readLogFile(self.__filenames[self.__nextFilenamesIndex])
                self.__nextFilenamesIndex += 1
                self.__logIndex = 0
            else:
                return None

        line = self.__log[self.__logIndex]
        self.__logIndex += 1

        if self.__logIndex >= len(self.__log):
            self.__log = None

        # check for timestamp and store if there is one
        ret = TimeStampRegexes.TRANSCODE_MANAGER.search(line)
        if ret is not None:
            self.__year,self.__month,self.__day,self.__hour,self.__minute,self.__second,self.__millisecond =ret.groups()

        return line.strip()


    def getCurrentTimestamp(self):
        """
        Get information regarding the current timestamp, if any is available
        :return: A str containing as much as is known about the current timestamp
        """

        year        = self.__year        if self.__year        is not None else "XX"
        month       = self.__month       if self.__month       is not None else "XX"
        day         = self.__day         if self.__day         is not None else "XX"
        hour        = self.__hour        if self.__hour        is not None else "XX"
        minute      = self.__minute      if self.__minute      is not None else "XX"
        second      = self.__second      if self.__second      is not None else "XX"
        millisecond = self.__millisecond if self.__millisecond is not None else "XX"

        formattedDateStr = "%s-%s-%s @ %s:%s:%s.%s" % (year,month,day,hour,minute,second,millisecond)
        return formattedDateStr


#-----------------------------------------------------------------------------------------------------------------------
# Informal unit tests
#-----------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    print "Running unit test(s)..."
    NUM_FILES = 3
    filenames = {}

    # Generate some "logs" to read: Each log has one more line of logging than the last (first has 1)
    for i in range(1,NUM_FILES+1):
        filename = "unit_test_file_%d.txt" % i
        filenames[filename] = []

        with open(filename, "w") as f:
            for j in range(1,i+1):
                line = "File: %s, Line: %d" % (filename,j)
                filenames[filename].append(line)
                f.write("%s\n" % line)

    reader = LogReader(filenames)
    logFilenames = {}

    line = reader.getNextLine()
    while line is not None:
        filename = reader.getCurrentLogFilename()
        if filename not in logFilenames:
            logFilenames[filename] = []
        logFilenames[filename].append(line)
        line = reader.getNextLine()

    if filenames == logFilenames:
        print "Unit Testing: PASS"
    else:
        print "Unit Testing: FAIL"
        print "filenames:    %s" % pprint.pformat(filenames)
        print "logFilenames: %s" % pprint.pformat(logFilenames)

    for filename in filenames:
        os.remove(filename)

