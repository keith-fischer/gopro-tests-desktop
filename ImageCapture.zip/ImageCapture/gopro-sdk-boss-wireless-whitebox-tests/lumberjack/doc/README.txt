=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                            .------------------.___________________________________
                           /                   | L U M B E R J A C K  |           |`-.,_
                           \###################| L O G   R E A D E R  |###########|,-'`
                            `------------------'----------------------:           l
                                                                       /           \\
                                                                      /             \\
                                                                    ,'               `.
                                                                 .d8b.               .d8b.
                                                                 "Y8888p..       ,.d8888P"
                                                                   "Y88888888888888888P"
                                                                      ""YY8888888PP""
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Authors: Sean Foley,
Project Created: 12 May 2016

----------
Overview
----------
The Lumberjack log reader is a tool designed to help automate identification of issues in GoPro RTOS logs.

It does this by having a LogAnalyzer object send the logs through a set of "analyzer" objects, each of which is
designed to hunt down and identify a specific type/piece of information.

---------------------------
Architecture/Design Notes
---------------------------
An "analyzer" is a class derived from the Analyzer abstract base class and should define two methods:

analyze(self, line):
  This method reads/parses line, storing whatever interesting or useful information it is designed to find

getReport(self):
  This method returns a string containing the summary report of what the analyzer found and

----------

A LogAnalyzer takes a set of log filenames and uses a LogReader to send each line of logging through each registered
analyzer by calling its .analyze(line) method. Thus, each analyzer goes through the logs at the same pace.

It was decided to do it
this way instead of sending the entire log all at once through each analyzer because this method theoretically allows
analyzers to share information with each other "on the fly". Such a mechanism is not yet implemented but may be in the
future.

Next, the LogAnalyzer will call the .getReport() method on each analyzer, concatenating reports together until the
user invokes LogAnalyzer.getReports().

----------

To register an analyzer with a LogAnalyzer, instantiate the analyzer object and pass it to the LogAnalyzer.

----------

Example Usage:

from ThingAnalyzer import *
filenames = sys.argv[1:]
logAnalyzer = LogAnalyzer(filenames)
logAnalyzer.addAnalyzer( ThingAnalyzer() )
logAnalyzer.analyze()
reports = logAnalyzer.getReports()

