import re
from Analyzer import *

class LinuxMooseAnalyzer(Analyzer):
    """
    A special analyzer that is disabled by default. Used for debug testing
    """

    def __init__(self):
        pass


    def analyze(self, line, timestamp=None):
        """
        No op

        :param line: A str containing a single line of log text
        :param timestamp: A str containing the formatted timestamp of the line
        :return: None
        """

        print "Moose: [%s] %s" % (timestamp, line)


    def getReport(self):
        """
        Get a summary report of what the analyzer found

        :return: A str containing the report
        """

        return "report str"