#!/usr/local/bin/python

import abc  # abstract base class

class Analyzer:
    """
    A base class from which all analyzers should inherit. Derived classes should override all methods below
    """

    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def analyze(self, line, timestamp=None):
        """
        Analyze the current line, saving internally whatever (state) data is desirable

        :param line: A str representing one line of text from a log file
        :param timestamp: A str representing the formatted timestamp of the line
        :return: None
        """
        pass


    @abc.abstractmethod
    def getReport(self):
        """
        Return a summary of the data collected thus far.

        :return: A str containing a summary of the information collected
        """

        pass


#-----------------------------------------------------------------------------------------------------------------------
# Informal unit tests
#-----------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":

    class ProperThingAnalyzer(Analyzer):
        """
        A class that inherits from Analyzer and properly overrides the analyze and getReport methods like it should
        """
        def __init__(self):
            pass

        def analyze(self, line):
            pass

        def getReport(self):
            pass

    class ImproperThingAnalyzer(Analyzer):
        """
        A class that inherits from Analyzer but does not define analyze and getReport methods
        """
        def __init__(self):
            pass

    # Positive test
    try:
        goodAnalyzerObject = ProperThingAnalyzer()
        positiveTestPassed = True
    except:
        positiveTestPassed = False

    # Negative test
    # Negative test
    try:
        badAnalyzerObject  = ImproperThingAnalyzer()
        negativeTestPassed = False
    except TypeError:
        negativeTestPassed = True

    print "Positive Unit Tests: %s" % "PASS" if positiveTestPassed else "FAIL"
    print "Negative Unit Tests: %s" % "PASS" if negativeTestPassed else "FAIL"
