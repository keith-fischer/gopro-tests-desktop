#!/usr/local/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: LogAnalyzer.py
# # Description: A class designed to use AnalysisModule derived objects to perform complex automated analysis
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import sys

from Analyzer import *
from LogReader import *
from QAToolbox import *


class LogAnalyzer:
    """
    Uses (derived) Analyzer objects to perform complex analysis on log files
    """

    def __init__(self, filenames):
        """
        Initializer

        :param filenames: A list of log filenames
        :return: None
        """

        self.__reader = LogReader(filenames)
        self.__analyzers = []
        self.__logger = Logger(Logger.LOG_LEVEL_DEBUG)


    def addAnalyzer(self, analyzer):
        """
        Adds an analyzer module to the list of analyzers that the system will use to analyze the logs

        :param analyzer: An object derived from an Analyzer object
        :return: True if the analyzer was added successfully; False otherwise
        """

        if not isinstance(analyzer, Analyzer):
            logger.logError("Cannot add analyzer. Is not a %s" % str(Analyzer))
            return False

        self.__analyzers.append(analyzer)
        return True


    def analyze(self):
        """
        For each line of logging, call each registered Analyzer's analyze method.
        Then, each Analyzer's getReport method to get its summary report.

        :return: None
        """

        if self.__reader is None:
            self.__logger.logError("LogReader is not configured. Cannot continue")
            sys.exit(1)

        line = self.__reader.getNextLine()
        timestamp = self.__reader.getCurrentTimestamp()
        while line is not None:
            for analyzer in self.__analyzers:
                analyzer.analyze(line, timestamp)
            line = self.__reader.getNextLine()
            timestamp = self.__reader.getCurrentTimestamp()


    def getReports(self):
        """
        Call each analyzer's getReport method and then print it.

        :return: A list of tuples of the form (className, report) with reports from each registered Analyzer
        """

        reports = []
        for analyzer in self.__analyzers:
            analyzerName = analyzer.__class__.__name__
            report = analyzer.getReport()
            reports.append( (analyzerName,report) )

        return reports


#-----------------------------------------------------------------------------------------------------------------------
# Informal unit testing
#-----------------------------------------------------------------------------------------------------------------------
if (__name__ == "__main__"):
    NUM_LOG_FILES = 3
    reportStrFormatted = "Number of lines: %d"
    expectedNumLines = NUM_LOG_FILES * (NUM_LOG_FILES + 1) / 2  # summation of 1..n formula

    # Define a trivial Analyzer class
    class LineCountAnalyzer(Analyzer):
        def __init__(self):
            self.__numLines = 0

        def analyze(self, line):
            self.__numLines += 1

        def getReport(self):
            return reportStrFormatted % self.__numLines

    # Generate some logs to read: Each log has one more line of logging than the last (first has 1)
    filenames = []
    for i in range(1,NUM_LOG_FILES+1):
        filename = "unit_test_file_%d.txt" % i
        filenames.append(filename)

        with open(filename, "w") as f:
            for j in range(1,i+1):
                f.write("File: %s, Line: %d\n" % (filename, i))

    # Analyze the log files
    logAnalyzer = LogAnalyzer(filenames)
    logAnalyzer.addAnalyzer(LineCountAnalyzer())
    logAnalyzer.analyze()
    reports = logAnalyzer.getReports()

    testPassed = True
    if len(reports) != 1:
        testPassed = False
    else:
        analyzerName,report = reports[0]

        if analyzerName != "LineCountAnalyzer":
            testPassed = False

        elif report != reportStrFormatted % expectedNumLines:
            testPassed = False

    if testPassed:
        print "Unit testing: PASS"
    else:
        print "Unit testing: FAIL"
        print "Reports:"
        for analyzerName,report in reports:
            print "  Analyzer: '%s'" % analyzerName
            print "  Report: %s" % report

    for filename in filenames:
        os.remove(filename)

