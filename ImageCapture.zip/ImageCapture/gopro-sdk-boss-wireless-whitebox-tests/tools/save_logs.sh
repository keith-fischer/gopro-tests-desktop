#!/bin/bash
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: save_logs.sh
# Description: Save logs from a GoPro camera connected to a debug board to a file
# Author: Sean Foley
# Date Created: 2 June 2016
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

if [ $# -ne 4 ]; then
	echo "Usage: $0 <MODEL> <RTOS | LINUX> <FIRMWARE VERSION> <SERIAL PORT>"
	exit 1
fi

model="$1"
logFlavor="$2"
firmware="$3"
serialPort="$4"
logFilename="${model}_${logFlavor}_${firmware}_$(date +%Y%m%d_%H%M%S).log"

script -a -t 0 "$logFilename" screen $serialPort 115200
