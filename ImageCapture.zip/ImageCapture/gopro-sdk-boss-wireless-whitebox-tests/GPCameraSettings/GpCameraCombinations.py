import copy
import GpCameraSettings_Util
import sys, getopt
from QAToolbox import *
import json

# class Combinations
#   __init__
#       getdictfromlist
#       generate_combinations
#           searchblacklist
#
#           evalblaclist
#               find_modebyid
#               getsettingoption
#               findblacklistwhiteitems
#                   isblacklisted
#               updateblacklist
#           getsettinginfo
# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
class Combinations:
    def __init__(self, camera_dict):
        self.BlacklistDict = {}
        self.modeslist = []
        self.modesdict = {}
        self.camera_dict = camera_dict
        self.modes_dict=self.getdictfromlist(camera_dict,"modes")
        self.filters_dict=self.getdictfromlist(camera_dict,"filters")
        self.combinationlist = None
        #self.find_combinations()
        self.generate_combinations()
        a= json.dumps(self.modesdict, sort_keys=True,indent=4, separators=(',', ': '))
        print a
        # b=self.getstructure(self.modesdict,1)
        # self.getstructure(self.camera_dict, 1)
        # #self.getstructure(self.filters_dict, 1)
        # print b

    def getstructure(self,data, tab=0):
        dump=""
        if type(data) is dict:
            print ' ' * tab + '{'
            for key in data:
                print ' ' * tab + '  ' + key + ':'
                self.getstructure(data[key], tab + 4)
            print ' ' * tab + '}'
        elif type(data) is list and len(data) > 0:
            print ' ' * tab + '['
            self.getstructure(data[0], tab + 4)
            print ' ' * tab + '  ...'
            print ' ' * tab + ']'

    def addobjitem(self, _obj, _key, _value):
        if type(_obj) == list:
            for listitem in _obj:
                self.addlistitem(listitem, None, _value)
            _obj.append(_value)
        elif type(_obj) == dict:
            for dictitemkey, disctiemval in _obj.items():
                self.addlistitem(_obj[dictitemkey], dictitemkey, _value)
        elif type(_obj) == str:
            if _obj == _value:
                return False


    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def getsettinginfo(self,setting):
        info = "%s:" % setting["display_name"]
        for option in setting["options"]:
            info += "%s," % option["display_name"]
        return info

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def generate_combinations(self):
        #iterate modes>check if mode is in blacklist>check what the prequisite is and requered state
        for modes in self.modes_dict:
            mainmode = modes["display_name"]

            for mode in modes["settings"]:
                if mode["display_name"] == "Low Light":
                    info = ""
                info = ""
                blacklist = self.searchblacklist(mode["id"])
                if blacklist:
                    #process blacklist, look for white list or all options are black and options not listed
                    self.evalblaclist(mainmode, mode, blacklist)
                    #info += "blacklist:%s" % str(blacklist)
                else:
                    #process no blacklist, list all options
                    info = "MainMode:%s|%s" % (mainmode, self.getsettinginfo(mode))
                    self.updateblacklist(info, mode)
                    self.evalmode(info)
                    print info

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def updateblacklist(self,key,value):
        rc = False
        if key in self.BlacklistDict:
            if value not in self.BlacklistDict[key]:
                self.BlacklistDict[key].append(value)
        else:
            l = list()
            l.append(value)
            self.BlacklistDict[key]=l
            return True
        return rc

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def getblacklist(self,key):
        if self.BlacklistDict.has_key(key):
            return self.BlacklistDict[key]
        return None

    def getmodesliststr(self,mode):
        optionslist = ""
        for optionitem in mode["options"]:
            optionslist += "%s," % optionitem["display_name"]
        info = "%s:%s" % (mode["display_name"], optionslist)
        return info

    def updatedict(self,_dict,_key):
        rc = False
        if not _key in _dict:
            if len(_dict) > 0:
                for k, v in _dict.items():
                    r, d = self.updatedict(v, k)
                    if r:
                        return r,d
            _dict[_key] = {}


        return rc, _dict[_key]

    def evalmode(self, modes):
        modelist = modes.split("|")
        h1 = self.modesdict
        for modeitem in modelist:
            h2 = {}
            #h1 = self.updatedict(h1, modeitem)

            mode = modeitem.split(":")
            if len(mode) > 1:
                modename = mode[0]
                modeval = mode[1]
                options = modeval.split(",")
                r, h1 = self.updatedict(h1, modename)
                r, h1 = self.updatedict(h1, modeval)
                for option in options:
                    #print "%s:%s" % (modename,option)
                    self.updatedict(h1, option)
            elif len(mode) > 0:
                modename = mode[0]
                #print modename
                h1=self.updatedict(h1, modename)
            else:
                print str(mode)

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def evalblaclist(self, mainmode, mode, filterlist):
        for filteritem in range(0,len(filterlist)):
            info3 = ""
            info1 = ""
            info2 = ""
            info4 = ""
            info5 = ""
            activated = filterlist[filteritem]["activated_by"]
            if len(activated)>1:
                info1 = ""
            for activateitem in activated:
                modeitem = self.find_modebyid(activateitem["setting_id"])
                activateitem["setting"] = modeitem
                activateitem["optionname"] = self.getsettingoption(modeitem, activateitem["setting_value"])
                info1 += "%s:%s|" % (modeitem["display_name"], activateitem["optionname"])
                info2 += "%s:%s|" % (mode["display_name"],activateitem["optionname"])
                #info3 += "%s:%s|" % (mode["display_name"], activateitem["optionname"])

            blacklist = filterlist[filteritem]["blacklist"]
            blacklist["setting"] = self.find_modebyid(blacklist["setting_id"])
            info4 = self.findblacklistwhiteitems(info4, filterlist[filteritem])
            if info4:
                # info += info2
                # print "MainMode:%s|%s" % (mainmode, info)
                # self.updateblacklist(mainmode+"|"+info, filterlist)
                #info5 = "%sB-MainMode:%s|%s%s" % (len(activated), mainmode, info1, info4)
                info5 = "MainMode:%s|%s%s" % (mainmode, info1, info4)
            else:

                #info += "MainMode:%s|%s%s" % (mainmode, info, mode["display_name"])
                #if len(activated) > 1:
                #    info5 = ">1MainMode:%s|%s" % (mainmode, info1)
                if len(activated) > 0:
                    info5 = "MainMode:%s|%s" % (mainmode, info1)
                else:
                    info5 = "MainMode:%s|%s" % (mainmode, info2)
                info5 += "|%s" % self.getmodesliststr(mode)
            # massage
            if "|Resolution:" in info5 and "MainMode:Video" in info5 and not "|Video Sub Mode:" in info5:
                info5 = info5.replace("|Resolution:", "|Video Sub Mode:Video|Resolution:")
            if "|Protune:OFF|" in info5:
                info5 = info5.replace("|Protune:OFF|", "|Protune:ON|")
                #info5 += "|%s" % self.getmodesliststr(mode)
            if "||" in info5:
                info5 = info5.replace("||", "|")
            if "Video Sub Mode:" not in info5:
                info5 = info5.replace("MainMode:Video", "MainMode:Video|Video Sub Mode:Video")
            if "|EV Comp:Night|" in info5:
                info1 = ""
            self.updateblacklist(info5, filterlist)
            print info5
            self.evalmode(info5)

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def searchblacklist(self,id):
        filterlist = []
        info = ""
        for filter in self.filters_dict:
            if id == filter["blacklist"]["setting_id"]:
                filterlist.append(filter)
        if len(filterlist)>0:
            return filterlist
        return None

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def find_combinations(self):
        for item1 in self.filters_dict:
            info = ""
            #print str(item1)
            if "activated_by" in item1:
                info += self.eval_activated(item1["activated_by"])
                #print info

            if "blacklist" in item1:
                if "setting_id" in item1["blacklist"]:
                    foundsetting =  self.find_modebyid(item1["blacklist"]["setting_id"])
                    item1["blacklist"]["setting"] = foundsetting
                    info += "%s:" % item1["blacklist"]["setting"]["display_name"]
                    info += self.findblacklistwhiteitems(info,item1)

                    print info
                    #print "blacklist:%s-%s" % (foundsetting["main_mode"],foundsetting)

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def eval_activated(self, activated):
        info = ""
        for item1 in activated:
            if "setting_id" in item1:
                foundsetting =  self.find_modebyid(item1["setting_id"])
                item1["setting"] = foundsetting
                mm = foundsetting["main_mode"]
                if mm == "Setup":
                    info += "%s:" % ( foundsetting["display_name"])
                else:
                    info += "%s|%s:" % (foundsetting["main_mode"],foundsetting["display_name"])
                if foundsetting["display_name"] == "Protune":
                    print foundsetting["display_name"]
                if "setting_value" in item1:
                    item1["setting_option"] = self.getsettingoption(foundsetting,item1["setting_value"])
                    info += "%s|" % item1["setting_option"]
        return info

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def find_modebyid(self, id):
        for item1 in self.modes_dict:
            #print str(item1)
            if "settings" in item1:
                for item2 in item1["settings"]:
                    if "id" in item2:
                        if id == item2["id"]:
                            item2["main_mode"] = item1["display_name"]
                            return item2

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def getsettingoption(self, settingdict, optionidx):
        info = ""
        if "options" in settingdict:
            #return settingdict["options"][optionidx]["display_name"]
            for item1 in settingdict["options"]:
                if "value" in item1:
                    if optionidx == item1["value"]:
                        info = item1["display_name"]
                        return info

        return ""

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def isblacklisted(self, blackvalues, whtvalue):
        if not whtvalue in blackvalues:
            return True
        return False

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def findblacklistwhiteitems(self, info, filteritem):
        info2 = ""
        blacklist = filteritem["blacklist"]
        activated = filteritem["activated_by"]
        if "setting" in blacklist and "values" in blacklist:
            if "options" in blacklist["setting"]:
                whtlist = []
                for item1 in blacklist["setting"]["options"]:
                    if self.isblacklisted(blacklist["values"],item1["value"]):
                        whtlist.append(item1["display_name"])
                info2 += "%s:" % blacklist["setting"]["display_name"]
                if len(whtlist)>0:
                    for item1 in whtlist:
                        info2 += "%s," % item1
                else:
                    return None #info2+="N/A"

        return info2

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def getdictfromlist(self,dictlist, dictname):
        for dictitem in dictlist:
            if dictname in str(dictitem):
                return copy.deepcopy(dictlist[dictitem])

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def findsetting(self,mode_dict,setting_id):
        for key1, value1 in mode_dict.items():
            mainmode = None
            if type(value1) != dict:
                continue
            if "display_name" in value1:
                mainmode = value1["display_name"]
                settings = None
                if "settings" in value1:
                    settings = value1["settings"]
                    for setting in settings:
                        if type(setting) == unicode:
                            if "id" in settings[setting]:
                                #print "%s - %s" % (mainmode,str(settings[setting]))
                                if setting_id == settings[setting]["id"]:
                                    return mainmode, settings[setting]
        return None, None

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def find_in_dict(self,_dict,fld,val):
        for key1, value1 in _dict.items():
            if type(value1) == dict:
                if fld in value1:
                    if value1[fld]==val:
                        return value1
        return None

    # --------------------------------------------------------------------------
    #
    # --------------------------------------------------------------------------
    def map_modes_filter(self,mode_dict, filter_dict):
        modeslist = []
        map = ""
        for key1,value1 in filter_dict.items():
            #print "key1:%s\nvalue1:%s" % (key1, value1)
            info = ""
            if type(value1)==dict:
                if "activated_by" in value1:
                    act=value1.get("activated_by")
                    for actitem in act:
                        #print "activated_by:%s" % act[actitem]
                        if not type(actitem)==str or type(act[actitem]) != dict:
                            continue
                        _setting_id=act[actitem].get("setting_id")
                        mainmode, mode_item = self.findsetting(mode_dict,_setting_id)
                        if mode_item:
                            if not "MAIN_MODE:" in info:
                                info += "MAIN_MODE:%s|" % mainmode
                            if "MAIN_MODE" in mode_item:
                                mode_item["MAIN_MODE"] += "|" + mainmode
                            else:
                                mode_item["MAIN_MODE"] = mainmode
                            info+="%s-" % mode_item["display_name"]
                            setting_value = act[actitem].get("setting_value")
                            opt = self.find_in_dict(mode_item["options"],"value",setting_value)
                            info += "%s|" % opt["display_name"]
                            act[actitem]["SETTING"] = mode_item
                            value1["activated_by"]=act
                            #print "FOUND:"+info + str(filter_dict[key1])
                black = value1.get("blacklist")
                if "setting_id" in black:
                    mainmode, mode_item = self.findsetting(mode_dict, black["setting_id"])
                    if "MAIN_MODE" in mode_item:
                        mode_item["MAIN_MODE"] += "|"+mainmode
                    else:
                        mode_item["MAIN_MODE"] = mainmode
                    black["SETTING"] = mode_item
                    value1["WHITE"] = []
                    optlist = mode_item["options"]
                    for key2, value2 in optlist.items():
                        if type(value2) == dict:
                            bvals = black["values"]
                            if key2 not in bvals:
                                wht= value2
                                value1["WHITE"].append(wht)
                    lbl = mode_item["display_name"]
                    if lbl =="Resolution":
                        print "debug"
                    info += "%s:" % lbl
                    for w in value1["WHITE"]:
                        info += "%s|" % w["display_name"]
                    print info

                    # filter_dict[key1]=value1
                    # if _setting_id and _setting_id>=0:
                    #     for key2, value2 in mode_dict.items():
                    #         print "key2:%s\nvalue2%s" % (key2,value2)
                    #         if type(value2) == dict:
                    #             if "display_name" in value2:
                    #                 print "%s" % str(value2["display_name"])
                    #             if "settings" in value2:
                    #                 settings = value2["settings"]
                    #                 for modeitems in settings:
                    #                     print "modeitems:%s" % modeitems
                    #                     if type(settings[modeitems]) == dict:
                    #                         _id=settings[modeitems].get("id")
                    #                         if _id and _id>=0:
                    #                             if _setting_id==_id:
                    #                                 print "FOUND:"

                                            # if "id" in settings[modeitems]:
                                            #     if act[actitem]["setting_id"] == settings[modeitems]["id"]:
                                            #         print "FOUND"
                                            #         if "options" in modeitems:
                                            #             for opt in modeitems["options"]:
                                            #                 print "%s" % opt


# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
def main(argv):
    inputfile = ''
    outputfile = ''

    for i in range(0,len(argv)):
        if argv[i] == "-j":
            i+=1
            inputfile = argv[i]

    if not inputfile:
        print "Incorrect args"
        exit(-1)
    print 'Input file:', inputfile
    #print 'Output file is "', outputfile

    try:
        with open(inputfile, "r") as inFile:
            settingsJson = json.load(inFile)
    except IOError:
        print "Unable to open/read file: '%s'. Cannot continue." % inputfile
        sys.exit(1)

    combo = Combinations(settingsJson)

    print str(combo)


if __name__ == "__main__":
   main(sys.argv[1:])


