#!/usr/bin/python
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: RecordVideo.py
# Description: A Utility to record many types of images from camera used for making test image sets for GDA
# Author: Sean Foley / Keith Fischer
# Date Created: 19 April 2016
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

#import argparse
import os
import platform
#import json
from GpCamera import *
from GpCameraDiscoverer import *
import GpCameraWifiConnect
#from GpCameraSettings_Util import *
import GpCameraSettings_Util


def debugtest():
    rc, gpcamerasetting, gpcamerasetting_option, gpcamerasetting_groups, gpcamerasetting_dict = GpCameraSettings_Util.loadclasses("HERO4 Black")



######################################################
#
#
#
######################################################
class CameraSettings:
    camera_name = None
    main_mode = None  # video
    sub_mode = None  # looping
    protune = None  # on|off
    video_format = None  # ntsc", "pal
    video_res = None  # WVGA", "960", "720", "720 SuperView
    fps = None  # 60, 120
    fov = None  # wide", "medium", "narrow"
    spot = None  # on|off
    lowlight = None  # on|off
    interval = None  # Max", 5, 20, 60, 120
    duration = 0
    id = 0

    def __init__(self, cameraname,
                 mainmode,
                 submode,
                 interval=None,
                 protune=None,
                 videoformat=None,
                 videores=None,
                 fps=None,
                 fov=None,
                 spot=None,
                 lowlight=None,
                 duration=None,
                 count=None):
        self.camera_name = cameraname
        self.main_mode = mainmode
        self.sub_mode = submode
        self.interval = interval
        self.protune = protune
        self.video_format = videoformat
        self.video_res = videores
        self.fps = fps
        self.fov = fov
        self.spot = spot
        self.lowlight = lowlight
        self.duration = duration
        self.id = count


######################################################
#
#
#
######################################################
class CameraControl:
    cameraname = None
    camerasettings = None

    def __init__(self, camera, cammodes, camera_name):
        self.cameraname = camera_name
        self.camera = camera
        self.cammodes = cammodes

    def cameracontrol(self, camera_settings):
        self.camerasettings = camera_settings

        # pt = GpCameraSettingOption.VIDEO_PROTUNE_ON
        # testcount += 1
        # print "-------------------------------"
        # print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
        #     f) + "-pt:on-" + "-duration:" + str(dur)
        # rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
        # print str(rc) + " - " + lastfile
        # print "-------------------------------"


######################################################
# sequence through array item combinations
# add array items and array name label
# reset the index to zero for each array
# sequence the array index
# reference each array by index to retrieve data
# load data into returnlist array, each item value relates to each arrayitems[i][ii] index value
# use getvaluebyname fetch data by name
######################################################
class arraycombinations:
    arrayitems = []
    arrayid = []
    returnlist = []
    arrayname = {}
    reset = True

    def __init__(self):
        self.arrayitems = []
        self.arrayid = []
        self.returnlist = []
        self.arrayname = {}
        self.reset = True

    def addarray(self, arname, ar):
        if ar:
            self.arrayitems.append(ar)
            self.arrayname[arname] = len(self.arrayitems) - 1

    def resetarrayid(self):
        self.arrayid = []
        for i in range(0, len(self.arrayitems)):
            self.arrayid.append(0)

    def getcombination(self):
        # set indexes
        arlen = len(self.arrayid) - 1
        for i in range(arlen, -1, -1):
            if not self.reset and i == arlen:
                self.arrayid[i] += 1
            arlenitems = len(self.arrayitems[i]) - 1
            if i == 0 and self.arrayid[i] > arlenitems:
                self.returnlist = []
                return  # all combinations have been processed

            if self.arrayid[i] > arlenitems:
                self.arrayid[i] = 0
                ii = i - 1
                if ii >= 0:
                    self.arrayid[ii] += 1
        self.reset = False
        self.returnlist = []
        for i in range(0, len(self.arrayid)):
            rc = self.arrayitems[i]
            ii = self.arrayid[i]
            # if i==0 and ii>=len(rc):
            #     self.returnlist = []
            #     return
            rc = rc[ii]
            self.returnlist.append(rc)
        return

    def getvaluebyname(self, arname):
        if arname in self.arrayname:
            id = self.arrayname[arname]
            return self.returnlist[id]
        return None


######################################################
# CameraModeSettings
# has all the camera mode settings info. Can iterate all camera settings
#
######################################################
class CameraModeSettings:
    listener = {}  # class requires method: cameracontrol(camerasettings)
    modes = {}
    mode_item = None
    main_sub_modes = []
    main_sub_modes_item = None
    main_sub_modes_id = 0
    duration = []
    duration_item = None
    duration_id = 0
    video_res = []
    video_res_item = None
    video_res_id = 0
    cam_name = None
    interval = []
    interval_item = None
    interval_id = 0
    interval_ok = False
    video_format = []
    video_format_id = 0
    video_format_item = None
    currentmodekey = None
    instance_count = 0
    count = 0
    camera = None

    def __init__(self, camera, cammodes, cameraname, listenerobj):
        self.cam_name = cameraname
        self.listener = listenerobj
        self.camera = camera
        self.cammodes = cammodes
        self.set_camera_mode()
        self.iterate_cameramodes()

    def evalsubmode(self):
        if self.main_sub_modes_item == "Video|Looping":
            self.interval = ["Max", "5 Minutes", "20 Minutes", "60 Minutes", "120 Minutes"]  # Max|5 Minutes|20 Minutes|60 Minutes|120 Minutes
            self.interval_ok = True
            return

        elif self.main_sub_modes_item == "video|video":
            self.interval = []  # N/A
            self.interval_ok = False
            return

        elif self.main_sub_modes_item == "video|videophoto":
            self.interval = [5, 10, 30, 60]  # 5 Seconds|10 Seconds|30 Seconds|60 Seconds
            self.interval_ok = True
            return

        elif self.main_sub_modes_item == "video|videophoto":
            self.interval = [.5, 1, 2, 5, 10, 30, 60]  # 0.5 Seconds|1 Second|2 Seconds|5 Seconds|10 Seconds|30 Seconds|60 Seconds
            self.interval_ok = True
            return

    def makekey(self):
        self.currentmodekey = self.main_sub_modes_item

        self.video_res_item = self.video_res[self.video_res_id]
        self.currentmodekey += "|" + self.video_res_item

        self.video_format_item = self.video_format[self.video_format_id]
        self.currentmodekey += "|" + self.video_format_item + "|"

        # self.instance_count += 1
        self.mode_item = None

        tempkey = self.currentmodekey + str(self.instance_count)
        if tempkey in self.modes:
            self.currentmodekey = tempkey
            self.mode_item = self.modes[self.currentmodekey]
            return

        print "Mode Not Found:" + tempkey
        self.currentmodekey = None

    def getarrayitem(self, id, arrayobject):
        if arrayobject and id < len(arrayobject):
            return id
        return -1

    def evalmode(self, key, mode_obj):
        obj = None
        if key in self.mode_item:
            obj = self.mode_item[key]
        return obj

    def iterate_cameramodes(self):
        self.instance_count = 0
        if not self.main_sub_modes or not len(self.main_sub_modes) > 0:
            print "ERROR: camera, main_sub_modes not defined"
            return
        self.count = 0
        for self.main_sub_modes_id in range(0, len(self.main_sub_modes)):
            self.main_sub_modes_item = self.main_sub_modes[self.main_sub_modes_id]
            self.evalsubmode()
            if self.interval_ok:
                self.interval_id += 1
                if self.interval_id < len(self.interval):
                    self.interval_item = self.interval[self.interval_id]
                else:
                    return
            for self.duration_id in range(0, len(self.duration)):
                for self.video_res_id in range(0, len(self.video_res)):
                    for self.video_format_id in range(0, len(self.video_format)):
                        for self.instance_count in range(1, 5):

                            self.makekey()
                            self.interval_id = 0
                            self.interval_item = None
                            while self.interval_id >= 0:
                                self.interval_id = self.getarrayitem(self.interval_id, self.interval)
                                if self.interval_id >= 0:
                                    self.interval_item = self.interval[self.interval_id]
                                    self.interval_id += 1
                                else:
                                    self.interval_item = None
                                    self.interval_id = -1
                                    if self.interval_ok:
                                        break

                                sinterval = ""
                                combo = {}
                                if self.mode_item:
                                    if self.interval_item:
                                        sinterval = str(self.interval_item) + ":"
                                    # print str(modecount)+self.currentmodekey + "=" + str(sinterval)+str(self.mode_item)
                                    mainmode = self.main_sub_modes_item.split("|")[0]
                                    submode = self.main_sub_modes_item.split("|")[1]

                                    combo = arraycombinations()

                                    fpslist = self.evalmode("fps", self.mode_item)
                                    combo.addarray("fps", fpslist)
                                    fovlist = self.evalmode("fov", self.mode_item)
                                    combo.addarray("fov", fovlist)
                                    ptlist = self.evalmode("pt", self.mode_item)
                                    combo.addarray("pt", ptlist)
                                    spotlist = self.evalmode("spot", self.mode_item)
                                    combo.addarray("spot", spotlist)
                                    lowlightlist = self.evalmode("lowlight", self.mode_item)
                                    combo.addarray("lowlight", lowlightlist)
                                    combo.resetarrayid()
                                    combo.getcombination()

                                    while combo.returnlist and len(combo.returnlist) > 0:
                                        fps = combo.getvaluebyname("fps")
                                        fov = combo.getvaluebyname("fov")
                                        pt = combo.getvaluebyname("pt")
                                        spot = combo.getvaluebyname("spot")
                                        lowlight = combo.getvaluebyname("lowlight")
                                        self.duration_item = self.duration[self.duration_id]
                                        self.count += 1
                                        camerasettings = CameraSettings(self.cam_name, mainmode, submode, self.interval_item, pt, self.video_format[self.video_format_id], self.video_res[self.video_res_id], fps, fov, spot, lowlight, self.duration_item, self.count)

                                        # self.listener(str(modecount) + self.currentmodekey + "=" + str(sinterval) + str(self.mode_item))
                                        self.listener(self.camera, self.cammodes, camerasettings)
                                        combo.getcombination()

    def set_camera_mode(self):
        if self.cam_name == "XHERO4 Black":
            rc, self.cammodes.gpcamerasetting, self.cammodes.gpcamerasetting_option, self.cammodes.gpcamerasetting_groups, self.cammodes.gpcamerasetting_dict = GpCameraSettings_Util.loadclasses("HERO4 Black")
            if not rc:
                print "Failed to load camera settings classes"
                return False


            self.main_sub_modes = ["Video|Looping", "Video|Video", "video|videophoto", "video|timelapse", "photo|single", "photo|continous", "photo|night", "multi|burst", "multi|timelapse", "multi|night"]
            self.duration = [5000,30000,60000,120000]  # seconds 1,5,10,30,5min,10min
            #self.interval = ["Max", "5 Minutes", "20 Minutes", "60 Minutes", "120 Minutes"]  # looping
            self.video_format = ["ntsc", "pal"]
            self.video_res = ["WVGA", "960", "720", "720 SuperView", "4K", "4K SuperView", "2.7K", "2.7K SuperView", "1440", "1080", "1080 SuperView"]

            self.modes["Video|Video|WVGA|ntsc|1"] = {"fps": [240], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|WVGA|pal|1"] = {"fps": [240], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|WVGA|ntsc|1"] = {"fps": [240], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|WVGA|pal|1"] = {"fps": [240], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|960|ntsc|1"] = {"fps": [60, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|960|pal|1"] = {"fps": [50, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|960|ntsc|1"] = {"fps": [60, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|960|pal|1"] = {"fps": [50, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|720|ntsc|1"] = {"fps": [30], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|720|ntsc|2"] = {"fps": [60, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|720|pal|1"] = {"fps": [25], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|720|pal|2"] = {"fps": [50, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720|ntsc|1"] = {"fps": [30], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|720|ntsc|2"] = {"fps": [60, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720|pal|1"] = {"fps": [25], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|720|pal|2"] = {"fps": [50, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|720 SuperView|ntsc|1"] = {"fps": [60, 120], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|720 SuperView|pal|1"] = {"fps": [50, 120], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720 SuperView|ntsc|1"] = {"fps": [60, 120], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720 SuperView|pal|1"] = {"fps": [50, 120], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|4K|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|4K|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K|ntsc|1"] = {"fps": [24], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|4K SuperView|ntsc|1"] = {"fps": [24], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|4K SuperView|pal|1"] = {"fps": [24], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K SuperView|ntsc|1"] = {"fps": [24], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K SuperView|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|2.7K|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K|ntsc|2"] = {"fps": [48, 60], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|2.7K|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K|pal|2"] = {"fps": [48, 50], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|2.7K|ntsc|1"] = {"fps": [24, 30], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K|ntsc|2"] = {"fps": [48, 60], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|2.7K|pal|1"] = {"fps": [24, 25], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K|pal|2"] = {"fps": [48, 50], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|2.7K SuperView|ntsc|1"] = {"fps": [30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K SuperView|pal|1"] = {"fps": [25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K SuperView|ntsc|1"] = {"fps": [30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K SuperView|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|2.7K 4:3|ntsc|1"] = {"fps": [30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K 4:3|pal|1"] = {"fps": [25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K 4:3|ntsc|1"] = {"fps": [30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K 4:3|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|1440|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1440|ntsc|2"] = {"fps": [48, 60, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1440|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1440|pal|2"] = {"fps": [48, 50, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1440|ntsc|1"] = {"fps": [24, 30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1440|ntsc|2"] = {"fps": [48, 60, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1440|pal|1"] = {"fps": [24, 25], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1440|pal|2"] = {"fps": [48, 50, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|1080|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080|ntsc|2"] = {"fps": [48, 60], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080|ntsc|3"] = {"fps": [90, 120], "pt": ["on", "off"], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080|pal|2"] = {"fps": [48, 50], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080|pal|3"] = {"fps": [90, 120], "pt": ["on", "off"], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|ntsc|1"] = {"fps": [24, 30], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080|ntsc|2"] = {"fps": [48, 60], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|ntsc|3"] = {"fps": [90, 120], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|pal|1"] = {"fps": [24, 25], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080|pal|2"] = {"fps": [48, 50], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|pal|3"] = {"fps": [90, 120], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|1080 SuperView|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080 SuperView|ntsc|2"] = {"fps": [48, 60, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080 SuperView|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080 SuperView|pal|2"] = {"fps": [48, 50, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|ntsc|1"] = {"fps": [24, 30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|ntsc|2"] = {"fps": [48, 60, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|pal|1"] = {"fps": [24, 25], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|pal|2"] = {"fps": [48, 50, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            return True

        elif self.cam_name == "HERO4 Black":
            rc, self.cammodes.gpcamerasetting, self.cammodes.gpcamerasetting_option, self.cammodes.gpcamerasetting_groups, self.cammodes.gpcamerasetting_dict = GpCameraSettings_Util.loadclasses("HERO4 Black")
            if not rc:
                print "Failed to load camera settings classes"
                return False
            self.main_sub_modes = GpCameraSettings_Util.getsubmodeslist(self.cammodes.gpcamerasetting.MAIN_MODE,self.cammodes.gpcamerasetting_dict.camera_settings_dict)
            if not self.main_sub_modes or len(self.main_sub_modes)==0:
                print "Submodes not found"
            self.duration = [5000, 30000, 60000, 120000]  # seconds 1,5,10,30,5min,10min

            self.video_format = GpCameraSettings_Util.getkeyslist("SETUP_VIDEO_FORMAT|",self.cammodes.gpcamerasetting_dict.camera_settings_dict,True)
            self.video_res = GpCameraSettings_Util.getkeyslist("VIDEO_RESOLUTION|",self.cammodes.gpcamerasetting_dict.camera_settings_dict,True)

            self.modes["Video|Video|WVGA|ntsc|1"] = {"fps": [240], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|WVGA|pal|1"] = {"fps": [240], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|WVGA|ntsc|1"] = {"fps": [240], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|WVGA|pal|1"] = {"fps": [240], "fov": ["wide"], "spot": ["on", "off"]}


        elif self.cam_name == "HERO5 Black":
            self.main_sub_modes = ["Video|Looping", "Video|Video", "video|videophoto", "video|timelapse", "photo|single", "photo|continous", "photo|night", "multi|burst", "multi|timelapse", "multi|night"]
            self.duration = [5000, 30000, 60000, 120000]  # seconds 1,5,10,30,5min,10min
            # self.interval = ["Max", "5 Minutes", "20 Minutes", "60 Minutes", "120 Minutes"]  # looping
            self.video_format = ["ntsc", "pal"]
            self.video_res = ["WVGA", "960", "720", "720 SuperView", "4K", "4K SuperView", "2.7K", "2.7K SuperView", "1440", "1080", "1080 SuperView"]

            self.modes["Video|Video|WVGA|ntsc|1"] = {"fps": [240], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|WVGA|pal|1"] = {"fps": [240], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|WVGA|ntsc|1"] = {"fps": [240], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|WVGA|pal|1"] = {"fps": [240], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|960|ntsc|1"] = {"fps": [60, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|960|pal|1"] = {"fps": [50, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|960|ntsc|1"] = {"fps": [60, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|960|pal|1"] = {"fps": [50, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|720|ntsc|1"] = {"fps": [30], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|720|ntsc|2"] = {"fps": [60, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|720|pal|1"] = {"fps": [25], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|720|pal|2"] = {"fps": [50, 120], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720|ntsc|1"] = {"fps": [30], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|720|ntsc|2"] = {"fps": [60, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720|pal|1"] = {"fps": [25], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|720|pal|2"] = {"fps": [50, 120], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|720 SuperView|ntsc|1"] = {"fps": [60, 120], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|720 SuperView|pal|1"] = {"fps": [50, 120], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720 SuperView|ntsc|1"] = {"fps": [60, 120], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|720 SuperView|pal|1"] = {"fps": [50, 120], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|4K|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|4K|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K|ntsc|1"] = {"fps": [24], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|4K SuperView|ntsc|1"] = {"fps": [24], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|4K SuperView|pal|1"] = {"fps": [24], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K SuperView|ntsc|1"] = {"fps": [24], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|4K SuperView|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|2.7K|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K|ntsc|2"] = {"fps": [48, 60], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|2.7K|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K|pal|2"] = {"fps": [48, 50], "pt": ["on", "off"], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|2.7K|ntsc|1"] = {"fps": [24, 30], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K|ntsc|2"] = {"fps": [48, 60], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|2.7K|pal|1"] = {"fps": [24, 25], "fov": ["wide", "medium"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K|pal|2"] = {"fps": [48, 50], "fov": ["wide", "medium"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|2.7K SuperView|ntsc|1"] = {"fps": [30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K SuperView|pal|1"] = {"fps": [25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K SuperView|ntsc|1"] = {"fps": [30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K SuperView|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|2.7K 4:3|ntsc|1"] = {"fps": [30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|2.7K 4:3|pal|1"] = {"fps": [25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K 4:3|ntsc|1"] = {"fps": [30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|2.7K 4:3|pal|1"] = {"fps": [25], "fov": ["wide"], "spot": ["on", "off"]}

            self.modes["Video|Video|1440|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1440|ntsc|2"] = {"fps": [48, 60, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1440|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1440|pal|2"] = {"fps": [48, 50, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1440|ntsc|1"] = {"fps": [24, 30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1440|ntsc|2"] = {"fps": [48, 60, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1440|pal|1"] = {"fps": [24, 25], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1440|pal|2"] = {"fps": [48, 50, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|1080|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080|ntsc|2"] = {"fps": [48, 60], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080|ntsc|3"] = {"fps": [90, 120], "pt": ["on", "off"], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080|pal|2"] = {"fps": [48, 50], "pt": ["on", "off"], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080|pal|3"] = {"fps": [90, 120], "pt": ["on", "off"], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|ntsc|1"] = {"fps": [24, 30], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080|ntsc|2"] = {"fps": [48, 60], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|ntsc|3"] = {"fps": [90, 120], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|pal|1"] = {"fps": [24, 25], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080|pal|2"] = {"fps": [48, 50], "fov": ["wide", "medium", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080|pal|3"] = {"fps": [90, 120], "fov": ["wide", "narrow"], "spot": ["on", "off"], "lowlight": ["on", "off"]}

            self.modes["Video|Video|1080 SuperView|ntsc|1"] = {"fps": [24, 30], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080 SuperView|ntsc|2"] = {"fps": [48, 60, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Video|1080 SuperView|pal|1"] = {"fps": [24, 25], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Video|1080 SuperView|pal|2"] = {"fps": [48, 50, 80], "pt": ["on", "off"], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|ntsc|1"] = {"fps": [24, 30], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|ntsc|2"] = {"fps": [48, 60, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|pal|1"] = {"fps": [24, 25], "fov": ["wide"], "spot": ["on", "off"]}
            self.modes["Video|Looping|1080 SuperView|pal|2"] = {"fps": [48, 50, 80], "fov": ["wide"], "spot": ["on", "off"], "lowlight": ["on", "off"]}


class CameraModes:
    def __init__(self):
        self.Selected.RepoList = None
        self.Selected._PROTUNE_MODE = GpCameraSetting.VIDEO_PROTUNE
        self.Selected._PROTUNE_ON_OFF = GpCameraSettingOption.VIDEO_PROTUNE_OFF
        self.Selected._VIDEO_MODES = GpCameraSubModes.VIDEO
        self.Selected._PHOTO_MODES = GpCameraSubModes.SINGLE
        self.Selected._MULTI_MODES = GpCameraSubModes.TIME_LAPSE
        self.Selected._VIDEO_FORMAT = GpCameraSettingOption.SETUP_VIDEO_FORMAT_NTSC
        self.Selected._VIDEO_RESOLUTIONS = GpCameraSettingOption.VIDEO_RESOLUTION_WVGA
        self.Selected._VIDEO_FRAME_RATES = GpCameraSettingOption.VIDEO_FPS_240
        self.Selected._MAIN_MODE = GpCameraModes.MODE_VIDEO
        self.Selected._SUB_MODE = GpCameraSubModes.VIDEO
        self.Selected._VIDEO_FOV = GpCameraSettingOption.VIDEO_FOV_WIDE
        self.gpcamerasetting = None
        self.gpcamerasetting_option = None
        self.gpcamerasetting_groups = None
        self.gpcamerasetting_dict = None

    class Selected:
        current_key = ""
        camera_name = ""
        camera_fw = ""
        _MAIN_MODE = None
        _SUB_MODE = None
        _VIDEO_MODES = None
        _PHOTO_MODES = None
        _MULTI_MODES = None
        _VIDEO_FORMAT = None
        _VIDEO_RESOLUTIONS = None
        _VIDEO_FRAME_RATES = None
        _PROTUNE_MODE = None
        _PROTUNE_ON_OFF = None
        _VIDEO_FOV = None

    MAIN_MODES = (  # main mode
        GpCameraModes.MODE_VIDEO,
        GpCameraModes.MODE_MULTI_SHOT,
        GpCameraModes.MODE_PHOTO,
        GpCameraModes.MODE_SETUP)

    # MAIN_MODES = (  # main mode
    #     'video',
    #     'Multi_Shot',
    #     'Photo',
    #     'Playback'
    #     'Setup')

    VIDEO_MODES = (  # submode
        "Video",#$GpCameraSubModes.VIDEO,
        GpCameraSubModes.TIME_LAPSE_VIDEO,
        GpCameraSubModes.VIDEO_PLUS_PHOTO,
        GpCameraSubModes.LOOPING)

    PHOTO_MODES = (  # submode
        GpCameraSubModes.SINGLE,
        GpCameraSubModes.NIGHT,
        GpCameraSubModes.CONTINUOUS)

    MULTI_MODES = (  # submode
        GpCameraSubModes.TIME_LAPSE,
        GpCameraSubModes.BURST,
        GpCameraSubModes.NIGHT_LAPSE)

    VIDEO_FORMAT = (
        GpCameraSettingOption.SETUP_VIDEO_FORMAT_NTSC,
        GpCameraSettingOption.SETUP_VIDEO_FORMAT_PAL)

    VIDEO_RESOLUTIONS = (
        GpCameraSettingOption.VIDEO_RESOLUTION_WVGA,
        GpCameraSettingOption.VIDEO_RESOLUTION_720,
        GpCameraSettingOption.VIDEO_RESOLUTION_720_SUPERVIEW,
        GpCameraSettingOption.VIDEO_RESOLUTION_960,
        GpCameraSettingOption.VIDEO_RESOLUTION_1080,
        GpCameraSettingOption.VIDEO_RESOLUTION_1080_SUPERVIEW,
        GpCameraSettingOption.VIDEO_RESOLUTION_1440,
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K,
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K_4_3,
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K_SUPERVIEW,
        GpCameraSettingOption.VIDEO_RESOLUTION_4K,
        GpCameraSettingOption.VIDEO_RESOLUTION_4K_SUPERVIEW,
    )

    VIDEO_FRAME_RATES = (
        GpCameraSettingOption.VIDEO_FPS_12_5,
        GpCameraSettingOption.VIDEO_FPS_15,
        GpCameraSettingOption.VIDEO_FPS_24,
        GpCameraSettingOption.VIDEO_FPS_25,
        GpCameraSettingOption.VIDEO_FPS_30,
        GpCameraSettingOption.VIDEO_FPS_48,
        GpCameraSettingOption.VIDEO_FPS_50,
        GpCameraSettingOption.VIDEO_FPS_60,
        GpCameraSettingOption.VIDEO_FPS_80,
        GpCameraSettingOption.VIDEO_FPS_90,
        GpCameraSettingOption.VIDEO_FPS_100,
        GpCameraSettingOption.VIDEO_FPS_120,
        GpCameraSettingOption.VIDEO_FPS_240
    )

    # For now support protune default mode
    PROTUNE_MODE = (
        GpCameraSetting.PHOTO_PROTUNE,
        GpCameraSetting.VIDEO_PROTUNE,
        GpCameraSetting.MULTI_SHOT_PROTUNE)

    PROTUNE_ONOFF = (
        GpCameraSettingOption.VIDEO_PROTUNE_ON,
        GpCameraSettingOption.VIDEO_PROTUNE_OFF)

    MULTI_SHOT_BURST_RATE = (
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_10_PHOTOS_PER_1_SECOND,  # = ('10 Photos / 1 Second', 2)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_10_PHOTOS_PER_2_SECONDS,  # = ('10 Photos / 2 Seconds', 3)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_10_PHOTOS_PER_3_SECONDS,  # = ('10 Photos / 3 Seconds', 4)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_30_PHOTOS_PER_1_SECOND,  # = ('30 Photos / 1 Second', 5)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_30_PHOTOS_PER_2_SECONDS,  # = ('30 Photos / 2 Seconds', 6)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_30_PHOTOS_PER_3_SECONDS,  # = ('30 Photos / 3 Seconds', 7)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_30_PHOTOS_PER_6_SECONDS,  # = ('30 Photos / 6 Seconds', 8)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_3_PHOTOS_PER_1_SECOND,  # = ('3 Photos / 1 Second', 0)
        GpCameraSettingOption.MULTI_SHOT_BURST_RATE_5_PHOTOS_PER_1_SECOND  # = ('5 Photos / 1 Second', 1)
    )

    MULTI_SHOT_SUB_MODE = (
        GpCameraSettingOption.MULTI_SHOT_CURRENT_SUB_MODE_BURST,  # = ('Burst', 0)
        GpCameraSettingOption.MULTI_SHOT_CURRENT_SUB_MODE_NIGHT_LAPSE,  # = ('Night Lapse', 2)
        GpCameraSettingOption.MULTI_SHOT_CURRENT_SUB_MODE_TIME_LAPSE)  # = ('Time Lapse', 1)
    # MULTI_SHOT_DEFAULT_SUB_MODE_BURST = ('Burst', 0)
    # MULTI_SHOT_DEFAULT_SUB_MODE_NIGHT_LAPSE = ('Night Lapse', 2)
    # MULTI_SHOT_DEFAULT_SUB_MODE_TIME_LAPSE = ('Time Lapse', 1)
    MULTI_SHOT_EXPOSURE_TIME = (
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_10_SECONDS,  # = ('10 Seconds', 3)
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_15_SECONDS,  # = ('15 Seconds', 4)
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_20_SECONDS,  # = ('20 Seconds', 5)
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_2_SECONDS,  # = ('2 Seconds', 1)
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_30_SECONDS,  # = ('30 Seconds', 6)
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_5_SECONDS,  # = ('5 Seconds', 2)
        GpCameraSettingOption.MULTI_SHOT_EXPOSURE_TIME_AUTO  # = ('Auto', 0)
    )
    MULTI_SHOT_NIGHTLAPSE_RATE = (
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_10_SECONDS,  # = ('10 Seconds', 10)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_15_SECONDS,  # = ('15 Seconds', 15)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_1_MINUTE,  # = ('1 Minute', 60)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_20_SECONDS,  # = ('20 Seconds', 20)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_2_MINUTES,  # = ('2 Minutes', 120)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_30_MINUTES,  # = ('30 Minutes', 1800)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_30_SECONDS,  # = ('30 Seconds', 30)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_4_SECONDS,  # = ('4 Seconds', 4)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_5_MINUTES,  # = ('5 Minutes', 300)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_5_SECONDS,  # = ('5 Seconds', 5)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_60_MINUTES,  # = ('60 Minutes', 3600)
        GpCameraSettingOption.MULTI_SHOT_NIGHTLAPSE_RATE_CONTINUOUS)  # = ('Continuous', 0)

    MULTI_SHOT_PROTUNE_COLOR = (
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_COLOR_FLAT,  # = ('Flat', 1)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_COLOR_GOPRO_COLOR)  # = ('GoPro Color', 0)

    MULTI_SHOT_PROTUNE_EV = (
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_0_0,  # = ('0.0', 4)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_0_5,  # = ('0.5', 3)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_1_0,  # = ('1.0', 2)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_1_5,  # = ('1.5', 1)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_2_0,  # = ('2.0', 0)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_NEG0_5,  # = ('-0.5', 5)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_NEG1_0,  # = ('-1.0', 6)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_NEG1_5,  # = ('-1.5', 7)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_EV_NEG2_0)  # = ('-2.0', 8)

    MULTI_SHOT_PROTUNE_ISO = (
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_100,  # = ('100', 3)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_200,  # = ('200', 2)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_400,  # = ('400', 1)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_800,  # = ('800', 0)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_MIN_100,  # = ('100', 3)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_MIN_200,  # = ('200', 2)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_MIN_400,  # = ('400', 1)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ISO_MIN_800)  # = ('800', 0)

    MULTI_SHOT_PROTUNE_ONOFF = (
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_ON)  # = ('ON', 1)

    MULTI_SHOT_PROTUNE_SHARPNESS = (
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_SHARPNESS_HIGH,  # = ('High', 0)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_SHARPNESS_LOW,  # = ('Low', 2)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_SHARPNESS_MEDIUM)  # = ('Medium', 1)

    MULTI_SHOT_PROTUNE_WHITE_BALANCE = (
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_3000K,  # = ('3000K', 1)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_4000K,  # = ('4000K', 5)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_4800K,  # = ('4800K', 6)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_5500K,  # = ('5500K', 2)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_6000K,  # = ('6000K', 7)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_6500K,  # = ('6500K', 3)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_AUTO,  # = ('Auto', 0)
        GpCameraSettingOption.MULTI_SHOT_PROTUNE_WHITE_BALANCE_NATIVE)  # = ('Native', 4)

    MULTI_SHOT_RESOLUTION = (
        GpCameraSettingOption.MULTI_SHOT_RESOLUTION_12MP_WIDE,  # = ('12MP Wide', 0)
        GpCameraSettingOption.MULTI_SHOT_RESOLUTION_5MP_MED,  # = ('5MP Med', 3)
        GpCameraSettingOption.MULTI_SHOT_RESOLUTION_7MP_MED,  # = ('7MP Med', 2)
        GpCameraSettingOption.MULTI_SHOT_RESOLUTION_7MP_WIDE)  # = ('7MP Wide', 1)

    MULTI_SHOT_SPOT_METER = (
        GpCameraSettingOption.MULTI_SHOT_SPOT_METER_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.MULTI_SHOT_SPOT_METER_ON)  # = ('ON', 1)

    MULTI_SHOT_TIMELAPSE_RATE = (
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_0_5_SEC,  # = ('1 Photo / 0.5 Sec', 0)
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_10_SEC,  # = ('1 Photo / 10 Sec', 10)
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_1_SEC,  # = ('1 Photo / 1 Sec', 1)
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_2_SEC,  # = ('1 Photo / 2 Sec', 2)
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_30_SEC,  # = ('1 Photo / 30 Sec', 30)
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_5_SEC,  # = ('1 Photo / 5 Sec', 5)
        GpCameraSettingOption.MULTI_SHOT_TIMELAPSE_RATE_1_PHOTO_PER_60_SEC)  # = ('1 Photo / 60 Sec', 60)

    PHOTO_CONTINUOUS_RATE = (
        GpCameraSettingOption.PHOTO_CONTINUOUS_RATE_10_FRAMES_PER_SECOND,  # = ('10 Frames / Second', 2)
        GpCameraSettingOption.PHOTO_CONTINUOUS_RATE_3_FRAMES_PER_SECOND,  # = ('3 Frames / Second', 0)
        GpCameraSettingOption.PHOTO_CONTINUOUS_RATE_5_FRAMES_PER_SECOND)  # = ('5 Frames / Second', 1)

    PHOTO_SUB_MODE = (
        GpCameraSettingOption.PHOTO_CURRENT_SUB_MODE_CONTINUOUS,  # = ('Continuous', 1)
        GpCameraSettingOption.PHOTO_CURRENT_SUB_MODE_NIGHT,  # = ('Night', 2)
        GpCameraSettingOption.PHOTO_CURRENT_SUB_MODE_SINGLE)  # = ('Single', 0)
    # GpCameraSettingOption.PHOTO_DEFAULT_SUB_MODE_CONTINUOUS = ('Continuous', 1)
    # GpCameraSettingOption.PHOTO_DEFAULT_SUB_MODE_NIGHT = ('Night', 2)
    # GpCameraSettingOption.PHOTO_DEFAULT_SUB_MODE_SINGLE = ('Single', 0)
    PHOTO_EXPOSURE_TIME = (
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_10_SECONDS,  # = ('10 Seconds', 3)
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_15_SECONDS,  # = ('15 Seconds', 4)
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_20_SECONDS,  # = ('20 Seconds', 5)
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_2_SECONDS,  # = ('2 Seconds', 1)
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_30_SECONDS,  # = ('30 Seconds', 6)
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_5_SECONDS,  # = ('5 Seconds', 2)
        GpCameraSettingOption.PHOTO_EXPOSURE_TIME_AUTO)  # = ('Auto', 0)

    PHOTO_PROTUNE_COLOR = (
        GpCameraSettingOption.PHOTO_PROTUNE_COLOR_FLAT,  # = ('Flat', 1)
        GpCameraSettingOption.PHOTO_PROTUNE_COLOR_GOPRO_COLOR)  # = ('GoPro Color', 0)

    PHOTO_PROTUNE_EV = (
        GpCameraSettingOption.PHOTO_PROTUNE_EV_0_0,  # = ('0.0', 4)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_0_5,  # = ('0.5', 3)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_1_0,  # = ('1.0', 2)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_1_5,  # = ('1.5', 1)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_2_0,  # = ('2.0', 0)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_NEG0_5,  # = ('-0.5', 5)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_NEG1_0,  # = ('-1.0', 6)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_NEG1_5,  # = ('-1.5', 7)
        GpCameraSettingOption.PHOTO_PROTUNE_EV_NEG2_0)  # = ('-2.0', 8)

    PHOTO_PROTUNE_ISO = (
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_100,  # = ('100', 3)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_200,  # = ('200', 2)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_400,  # = ('400', 1)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_800,  # = ('800', 0)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_MIN_100,  # = ('100', 3)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_MIN_200,  # = ('200', 2)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_MIN_400,  # = ('400', 1)
        GpCameraSettingOption.PHOTO_PROTUNE_ISO_MIN_800)  # = ('800', 0)

    PHOTO_PROTUNE_ONOFF = (
        GpCameraSettingOption.PHOTO_PROTUNE_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.PHOTO_PROTUNE_ON)  # = ('ON', 1)

    PHOTO_PROTUNE_SHARPNESS = (
        GpCameraSettingOption.PHOTO_PROTUNE_SHARPNESS_HIGH,  # = ('High', 0)
        GpCameraSettingOption.PHOTO_PROTUNE_SHARPNESS_LOW,  # = ('Low', 2)
        GpCameraSettingOption.PHOTO_PROTUNE_SHARPNESS_MEDIUM)  # = ('Medium', 1)

    PHOTO_PROTUNE_WHITE_BALANCE = (
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_3000K,  # = ('3000K', 1)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_4000K,  # = ('4000K', 5)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_4800K,  # = ('4800K', 6)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_5500K,  # = ('5500K', 2)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_6000K,  # = ('6000K', 7)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_6500K,  # = ('6500K', 3)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_AUTO,  # = ('Auto', 0)
        GpCameraSettingOption.PHOTO_PROTUNE_WHITE_BALANCE_NATIVE)  # = ('Native', 4)

    PHOTO_RESOLUTION = (
        GpCameraSettingOption.PHOTO_RESOLUTION_12MP_WIDE,  # = ('12MP Wide', 0)
        GpCameraSettingOption.PHOTO_RESOLUTION_5MP_MED,  # = ('5MP Med', 3)
        GpCameraSettingOption.PHOTO_RESOLUTION_7MP_MED,  # = ('7MP Med', 2)
        GpCameraSettingOption.PHOTO_RESOLUTION_7MP_WIDE,  # = ('7MP Wide', 1)
        GpCameraSettingOption.PHOTO_SINGLE_WDR_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.PHOTO_SINGLE_WDR_ON,  # = ('ON', 1)
        GpCameraSettingOption.PHOTO_SPOT_METER_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.PHOTO_SPOT_METER_ON)  # = ('ON', 1)

    SETUP_AUTO_POWER_DOWN = (
        GpCameraSettingOption.SETUP_AUTO_POWER_DOWN_1_MIN,  # = ('1 MIN', 1)
        GpCameraSettingOption.SETUP_AUTO_POWER_DOWN_2_MIN,  # = ('2 MIN', 2)
        GpCameraSettingOption.SETUP_AUTO_POWER_DOWN_3_MIN,  # = ('3 MIN', 3)
        GpCameraSettingOption.SETUP_AUTO_POWER_DOWN_5_MIN,  # = ('5 MIN', 4)
        GpCameraSettingOption.SETUP_AUTO_POWER_DOWN_NEVER)  # = ('NEVER', 0)

    SETUP_BEEP_VOLUME = (
        GpCameraSettingOption.SETUP_BEEP_VOLUME_100_PERCENT,  # = ('100%', 0)
        GpCameraSettingOption.SETUP_BEEP_VOLUME_70_PERCENT,  # = ('70%', 1)
        GpCameraSettingOption.SETUP_BEEP_VOLUME_OFF)  # = ('OFF', 2)

    SETUP_DEFAULT_APP_MODE = (
        GpCameraSettingOption.SETUP_DEFAULT_APP_MODE_MULTINEGSHOT,  # = ('Multi-shot', 2)
        GpCameraSettingOption.SETUP_DEFAULT_APP_MODE_PHOTO,  # = ('Photo', 1)
        GpCameraSettingOption.SETUP_DEFAULT_APP_MODE_VIDEO)  # = ('Video', 0)

    SETUP_LCD_BRIGHTNESS = (
        GpCameraSettingOption.SETUP_LCD_BRIGHTNESS_HIGH,  # = ('High', 0)
        GpCameraSettingOption.SETUP_LCD_BRIGHTNESS_LOW,  # = ('Low', 2)
        GpCameraSettingOption.SETUP_LCD_BRIGHTNESS_MEDIUM)  # = ('Medium', 1)

    SETUP_LCD_LOCK_OFFON = (
        GpCameraSettingOption.SETUP_LCD_LOCK_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.SETUP_LCD_LOCK_ON)  # = ('ON', 1)

    SETUP_LCD_OFFON = (
        GpCameraSettingOption.SETUP_LCD_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.SETUP_LCD_ON)  # = ('ON', 1)

    SETUP_LCD_SLEEP = (
        GpCameraSettingOption.SETUP_LCD_SLEEP_1_MIN,  # = ('1 MIN', 1)
        GpCameraSettingOption.SETUP_LCD_SLEEP_2_MIN,  # = ('2 MIN', 2)
        GpCameraSettingOption.SETUP_LCD_SLEEP_3_MIN,  # = ('3 MIN', 3)
        GpCameraSettingOption.SETUP_LCD_SLEEP_NEVER)  # = ('Never', 0)

    SETUP_LED = (
        GpCameraSettingOption.SETUP_LED_2,  # = ('2', 1)
        GpCameraSettingOption.SETUP_LED_4,  # = ('4', 2)
        GpCameraSettingOption.SETUP_LED_OFF)  # = ('OFF', 0)

    SETUP_ORIENTATION = (
        GpCameraSettingOption.SETUP_ORIENTATION_AUTO,  # = ('Auto', 0)
        GpCameraSettingOption.SETUP_ORIENTATION_DOWN,  # = ('Down', 2)
        GpCameraSettingOption.SETUP_ORIENTATION_UP)  # = ('Up', 1)

    SETUP_OSD_OFFON = (
        GpCameraSettingOption.SETUP_OSD_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.SETUP_OSD_ON)  # = ('ON', 1)

    SETUP_QUICK_CAPTURE_OFFON = (
        GpCameraSettingOption.SETUP_QUICK_CAPTURE_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.SETUP_QUICK_CAPTURE_ON)  # = ('ON', 1)

    SETUP_STREAM_BIT_RATE = (
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_1_2_MBPS,  # = ('1.2 Mbps', 1200000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_1_6_MBPS,  # = ('1.6 Mbps', 1600000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_1_MBPS,  # = ('1 Mbps', 1000000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_250_KBPS,  # = ('250 Kbps', 250000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_2_4_MBPS,  # = ('2.4 Mbps', 2400000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_2_MBPS,  # = ('2 Mbps', 2000000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_400_KBPS,  # = ('400 Kbps', 400000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_600_KBPS,  # = ('600 Kbps', 600000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_700_KBPS,  # = ('700 Kbps', 700000)
        GpCameraSettingOption.SETUP_STREAM_BIT_RATE_800_KBPS)  # = ('800 Kbps', 800000)

    SETUP_STREAM_GOP_SIZE = (
        GpCameraSettingOption.SETUP_STREAM_GOP_SIZE_15,  # = ('15', 15)
        GpCameraSettingOption.SETUP_STREAM_GOP_SIZE_3,  # = ('3', 3)
        GpCameraSettingOption.SETUP_STREAM_GOP_SIZE_30,  # = ('30', 30)
        GpCameraSettingOption.SETUP_STREAM_GOP_SIZE_4,  # = ('4', 4)
        GpCameraSettingOption.SETUP_STREAM_GOP_SIZE_8,  # = ('8', 8)
        GpCameraSettingOption.SETUP_STREAM_GOP_SIZE_DEFAULT)  # = ('Default', 0)

    SETUP_STREAM_IDR_INTERVAL = (
        GpCameraSettingOption.SETUP_STREAM_IDR_INTERVAL_1,  # = ('1', 1)
        GpCameraSettingOption.SETUP_STREAM_IDR_INTERVAL_2,  # = ('2', 2)
        GpCameraSettingOption.SETUP_STREAM_IDR_INTERVAL_4,  # = ('4', 4)
        GpCameraSettingOption.SETUP_STREAM_IDR_INTERVAL_DEFAULT)  # = ('Default', 0)

    SETUP_STREAM_WINDOW_SIZE = (
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_240,  # = ('240', 1)
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_240_1_2_SUBSAMPLE,  # = ('240 1:2 Subsample', 3)
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_240_3_4_SUBSAMPLE,  # = ('240 3:4 Subsample', 2)
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_480,  # = ('480', 4)
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_480_1_2_SUBSAMPLE,  # = ('480 1:2 Subsample', 6)
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_480_3_4_SUBSAMPLE,  # = ('480 3:4 Subsample', 5)
        GpCameraSettingOption.SETUP_STREAM_WINDOW_SIZE_DEFAULT)  # = ('Default', 0)

    SETUP_VIDEO_FORMAT_NTSCPAL = (
        GpCameraSettingOption.SETUP_VIDEO_FORMAT_NTSC,  # = ('NTSC', 0)
        GpCameraSettingOption.SETUP_VIDEO_FORMAT_PAL)  # = ('PAL', 1)

    SETUP_WIRELESS_MODE = (
        GpCameraSettingOption.SETUP_WIRELESS_MODE_APP,  # = ('App', 1)
        GpCameraSettingOption.SETUP_WIRELESS_MODE_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.SETUP_WIRELESS_MODE_RC,  # = ('RC', 2)
        GpCameraSettingOption.SETUP_WIRELESS_MODE_SMART)  # = ('Smart', 4)

    VIDEO_SUB_MODE = (
        GpCameraSettingOption.VIDEO_CURRENT_SUB_MODE_LOOPING,  # = ('Looping', 3)
        GpCameraSettingOption.VIDEO_CURRENT_SUB_MODE_TIME_LAPSE_VIDEO,  # = ('Time Lapse Video', 1)
        GpCameraSettingOption.VIDEO_CURRENT_SUB_MODE_VIDEO,  # = ('Video', 0)
        GpCameraSettingOption.VIDEO_CURRENT_SUB_MODE_VIDEO_PLUS_PHOTO)  # = ('Video + Photo', 2)
    # VIDEO_DEFAULT_SUB_MODE_LOOPING = ('Looping', 3)
    # VIDEO_DEFAULT_SUB_MODE_TIME_LAPSE_VIDEO = ('Time Lapse Video', 1)
    # VIDEO_DEFAULT_SUB_MODE_VIDEO = ('Video', 0)
    # VIDEO_DEFAULT_SUB_MODE_VIDEO_PLUS_PHOTO = ('Video + Photo', 2)
    VIDEO_EXPOSURE_TIME = (
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER100,  # = ('1/100', 12)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER120,  # = ('1/120', 13)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER12_5,  # = ('1/12.5', 1)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER15,  # = ('1/15', 2)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER160,  # = ('1/160', 14)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER180,  # = ('1/180', 15)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER192,  # = ('1/192', 16)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER200,  # = ('1/200', 17)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER24,  # = ('1/24', 3)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER240,  # = ('1/240', 18)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER25,  # = ('1/25', 4)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER30,  # = ('1/30', 5)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER320,  # = ('1/320', 19)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER360,  # = ('1/360', 20)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER400,  # = ('1/400', 21)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER48,  # = ('1/48', 6)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER480,  # = ('1/480', 22)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER50,  # = ('1/50', 7)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER60,  # = ('1/60', 8)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER80,  # = ('1/80', 9)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER90,  # = ('1/90', 10)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER96,  # = ('1/96', 11)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_1PER960,  # = ('1/960', 23)
        GpCameraSettingOption.VIDEO_EXPOSURE_TIME_AUTO)  # = ('Auto', 0)

    VIDEO_FOV = (
        GpCameraSettingOption.VIDEO_FOV_MEDIUM,  # = ('Medium', 1)
        GpCameraSettingOption.VIDEO_FOV_NARROW,  # = ('Narrow', 2)
        GpCameraSettingOption.VIDEO_FOV_WIDE)  # = ('Wide', 0)

    VIDEO_FPS = (
        GpCameraSettingOption.VIDEO_FPS_100,  # = ('100', 2)
        GpCameraSettingOption.VIDEO_FPS_120,  # = ('120', 1)
        GpCameraSettingOption.VIDEO_FPS_12_5,  # = ('12.5', 12)
        GpCameraSettingOption.VIDEO_FPS_15,  # = ('15', 11)
        GpCameraSettingOption.VIDEO_FPS_24,  # = ('24', 10)
        GpCameraSettingOption.VIDEO_FPS_240,  # = ('240', 0)
        GpCameraSettingOption.VIDEO_FPS_25,  # = ('25', 9)
        GpCameraSettingOption.VIDEO_FPS_30,  # = ('30', 8)
        GpCameraSettingOption.VIDEO_FPS_48,  # = ('48', 7)
        GpCameraSettingOption.VIDEO_FPS_50,  # = ('50', 6)
        GpCameraSettingOption.VIDEO_FPS_60,  # = ('60', 5)
        GpCameraSettingOption.VIDEO_FPS_80,  # = ('80', 4)
        GpCameraSettingOption.VIDEO_FPS_90)  # = ('90', 3)

    VIDEO_LOOPING = (
        GpCameraSettingOption.VIDEO_LOOPING_120_MINUTES,  # = ('120 Minutes', 4)
        GpCameraSettingOption.VIDEO_LOOPING_20_MINUTES,  # = ('20 Minutes', 2)
        GpCameraSettingOption.VIDEO_LOOPING_5_MINUTES,  # = ('5 Minutes', 1)
        GpCameraSettingOption.VIDEO_LOOPING_60_MINUTES,  # = ('60 Minutes', 3)
        GpCameraSettingOption.VIDEO_LOOPING_MAX)  # = ('Max', 0)
    VIDEO_LOW_LIGHT_OFFON = (
        GpCameraSettingOption.VIDEO_LOW_LIGHT_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.VIDEO_LOW_LIGHT_ON)  # = ('ON', 1)

    VIDEO_PIV = (
        GpCameraSettingOption.VIDEO_PIV_1_PHOTO_PER_10_SECONDS,  # = ('1 Photo / 10 Seconds', 2)
        GpCameraSettingOption.VIDEO_PIV_1_PHOTO_PER_30_SECONDS,  # = ('1 Photo / 30 Seconds', 3)
        GpCameraSettingOption.VIDEO_PIV_1_PHOTO_PER_5_SECONDS,  # = ('1 Photo / 5 Seconds', 1)
        GpCameraSettingOption.VIDEO_PIV_1_PHOTO_PER_60_SECONDS)  # = ('1 Photo / 60 Seconds', 4)

    VIDEO_PROTUNE_COLOR = (
        GpCameraSettingOption.VIDEO_PROTUNE_COLOR_FLAT,  # = ('Flat', 1)
        GpCameraSettingOption.VIDEO_PROTUNE_COLOR_GOPRO_COLOR)  # = ('GoPro Color', 0)

    VIDEO_PROTUNE_EV = (
        GpCameraSettingOption.VIDEO_PROTUNE_EV_0_0,  # = ('0.0', 4)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_0_5,  # = ('0.5', 3)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_1_0,  # = ('1.0', 2)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_1_5,  # = ('1.5', 1)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_2_0,  # = ('2.0', 0)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_NEG0_5,  # = ('-0.5', 5)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_NEG1_0,  # = ('-1.0', 6)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_NEG1_5,  # = ('-1.5', 7)
        GpCameraSettingOption.VIDEO_PROTUNE_EV_NEG2_0)  # = ('-2.0', 8)

    VIDEO_PROTUNE_ISO = (
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_1600,  # = ('1600', 1)
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_3200,  # = ('3200', 3)
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_400,  # = ('400', 2)
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_6400,  # = ('6400', 0)
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_800,  # = ('800', 4)
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_MODE_LOCK,  # = ('Lock', 1)
        GpCameraSettingOption.VIDEO_PROTUNE_ISO_MODE_MAX)  # = ('Max', 0)

    VIDEO_PROTUNE_OFFON = (
        GpCameraSettingOption.VIDEO_PROTUNE_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.VIDEO_PROTUNE_ON)  # = ('ON', 1)

    VIDEO_PROTUNE_SHARPNESS = (
        GpCameraSettingOption.VIDEO_PROTUNE_SHARPNESS_HIGH,  # = ('High', 0)
        GpCameraSettingOption.VIDEO_PROTUNE_SHARPNESS_LOW,  # = ('Low', 2)
        GpCameraSettingOption.VIDEO_PROTUNE_SHARPNESS_MEDIUM)  # = ('Medium', 1)

    VIDEO_PROTUNE_WHITE_BALANCE = (
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_3000K,  # = ('3000K', 1)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_4000K,  # = ('4000K', 5)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_4800K,  # = ('4800K', 6)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_5500K,  # = ('5500K', 2)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_6000K,  # = ('6000K', 7)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_6500K,  # = ('6500K', 3)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_AUTO,  # = ('Auto', 0)
        GpCameraSettingOption.VIDEO_PROTUNE_WHITE_BALANCE_NATIVE)  # = ('Native', 4)

    VIDEO_RESOLUTION = (
        GpCameraSettingOption.VIDEO_RESOLUTION_1080,  # = ('1080', 9)
        GpCameraSettingOption.VIDEO_RESOLUTION_1080_SUPERVIEW,  # = ('1080 SuperView', 8)
        GpCameraSettingOption.VIDEO_RESOLUTION_1440,  # = ('1440', 7)
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K,  # = ('2.7K', 4)
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K_4_3,  # = ('2.7K 4:3', 6)
        GpCameraSettingOption.VIDEO_RESOLUTION_2_7K_SUPERVIEW,  # = ('2.7K SuperView', 5)
        GpCameraSettingOption.VIDEO_RESOLUTION_4K,  # = ('4K', 1)
        GpCameraSettingOption.VIDEO_RESOLUTION_4K_SUPERVIEW,  # = ('4K SuperView', 2)
        GpCameraSettingOption.VIDEO_RESOLUTION_720,  # = ('720', 12)
        GpCameraSettingOption.VIDEO_RESOLUTION_720_SUPERVIEW,  # = ('720 SuperView', 11)
        GpCameraSettingOption.VIDEO_RESOLUTION_960,  # = ('960', 10)
        GpCameraSettingOption.VIDEO_RESOLUTION_WVGA)  # = ('WVGA', 13)

    VIDEO_SPOT_METER_OFFON = (
        GpCameraSettingOption.VIDEO_SPOT_METER_OFF,  # = ('OFF', 0)
        GpCameraSettingOption.VIDEO_SPOT_METER_ON)  # = ('ON', 1)

    VIDEO_TIMELAPSE_RATE = (
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_0_5_SECONDS,  # = ('0.5 Seconds', 0)
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_10_SECONDS,  # = ('10 Seconds', 4)
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_1_SECOND,  # = ('1 Second', 1)
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_2_SECONDS,  # = ('2 Seconds', 2)
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_30_SECONDS,  # = ('30 Seconds', 5)
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_5_SECONDS,  # = ('5 Seconds', 3)
        GpCameraSettingOption.VIDEO_TIMELAPSE_RATE_60_SECONDS)  # = ('60 Seconds', 6)


# =================================================================
# =================================================================
class ImageRepoJSON:
    d_imagelist = {}
    isNewList = True
    json_name = ""
    json_path = ""
    json_dir = ""
    _platform = ""

    def __init__(self, camera):
        # self.json_name = "HERO5 Black|HD5.02.00.20.00"
        self.json_name = "ImageRepo|" + camera.getCameraInfo().getModelName() + "|" + camera.getCameraInfo().getFirmwareVersion() + ".json"
        self.json_dir = "/Automation/ImageRepo/"
        # self._platform == "Linux|Darwin|Windows"
        self._platform = platform.system()
        if self._platform == "Windows":
            self.json_dir = "C:\\Automation\\ImageRepo\\"

        self.json_path = self.json_dir + self.json_name

        if not os.path.isdir(self.json_dir):
            os.makedirs(self.json_dir)
            print "Error: need to create this directory"
            print self.json_dir
            if not os.path.isdir(self.json_dir):
                exit(1)
        if not os.path.exists(self.json_path):
            print "Warning:json not found: File will get created to path during image collection run"
            print self.json_path
        self.getDictFromFile()
        if len(self.d_imagelist) > 0:
            self.isNewList = False
        else:
            self.isNewList = True

    def isImageKey(self, key):
        if key in self.d_imagelist:
            # print "Found in ImageList:" + key
            return True
        return False

    def saveImagekey(self, key, goproimagename):
        if self.isImageKey(key):
            print "Found in ImageList: Skipping " + key
            return False
        self.d_imagelist[key] = goproimagename
        return True

    ######################################################
    #
    ######################################################
    def putDictToFile(self):

        if self.d_imagelist and len(self.d_imagelist) > 0:
            s_dict = json.dumps(self.d_imagelist)
            fpath = self.json_path
            print "putDictToFile:d_imagelist=" + fpath
            if not self.filewrite(s_dict):
                print "FAILED: to save putDictToFile Imagerepo file "
                print "Automation needs to save these values for subsequent test runs for faster run times"
                exit(1)
            return True
        else:
            return False

    ######################################################
    #
    ######################################################
    def getDictFromFile(self):
        print "getDictFromFile>>>>"
        self.d_imagelist = {}

        fpath = self.json_path
        #    if d_gda_settings["isWindows"]:
        #        fpath = d_gda_settings["HOME"]+"\\workspace\\d_similarity.json"
        #        print "win d_similarity="+fpath
        #    else:
        #        print "mac d_similarity="+fpath
        print "Loading:" + fpath
        _json = self.fileread(fpath)
        if _json and len(_json) > 0:
            self.d_imagelist = json.loads(_json)
            if self.d_imagelist:
                print "OK"
                return self.d_imagelist
            else:
                print "Error: Failed to set Dict"
        else:
            print "Error: Failed to set JSON"
        print "getDictFromFile<<<"
        return self.d_imagelist

    ##########################################
    # fmode w|a
    ##########################################
    def filewrite(self, txt):
        f = None
        rc = False
        try:
            f = open(self.json_path, 'w')
            f.write(txt)
            rc = True
        except:
            print "***Failed: filewrite - len:" + str(len(txt)) + " - " + self.json_path
        finally:
            if f:
                f.close()
        return rc

    ##########################################
    #
    ##########################################
    def fileread(self, fpath):
        txt = None
        f = None
        try:
            f = open(self.json_path)
            txt = f.read()
        except:
            print "***Failed: fileread - " + self.json_path
            if txt:
                print "text length:" + str(len(txt))
        finally:
            if f:
                f.close()

        return txt
        # =================================================================
        # =================================================================


# def parseCommand(mode="Video", videoformat="NTSC", videores="1080", fps="30", duration=1000):
#     """
#     Parse arguments from the commandline
#     :return: A tuple of the form (type,resolution,frameRate,duration) which contains VALID values
#     """
#     rc = 0
#     # usageStr = "%s -m <VIDEO MODE> -o <FORMAT> -r <RESOLUTION> -f <FRAME RATE> -d <DURATION>" % sys.argv[0]
#     # epilogStr = "Example: xxx"
#     # descriptionStr = "A utility to record a video of a specific type/resolution/frame-rate/duration"
#
#
#     if not mode in CameraModes.VIDEO_MODES:
#         rc += 1
#         print "Error: Invalid mode '%s'" % mode
#         # sys.exit(1)
#
#     videoFormat = videoformat
#     formatFound = False
#     for format in CameraModes.VIDEO_FORMAT:
#         formatName = format[0]
#         if formatName == videoFormat:
#             videoFormat = format
#             formatFound = True
#             break
#     if not formatFound:
#         rc += 1
#         print "Error: Invalid resolution: '%s'" % videoFormat
#         # sys.exit(1)
#
#     resolution = videores
#     resolutionFound = False
#     for res in CameraModes.VIDEO_RESOLUTIONS:
#         displayName = res[0]
#         if displayName == resolution:
#             resolution = res
#             resolutionFound = True
#             break
#     if not resolutionFound:
#         rc += 1
#         print "Error: Invalid resolution: '%s'" % resolution
#         # sys.exit(1)
#
#     frameRate = fps
#     frameRateFound = False
#     for rate in CameraModes.VIDEO_FRAME_RATES:
#         displayName = rate[0]
#         if displayName == frameRate:
#             frameRate = rate
#             frameRateFound = True
#             break
#     if not frameRateFound:
#         rc += 1
#         print "Error: Invalid frame rate: '%s'" % frameRate
#         # sys.exit(1)
#
#     duration = duration
#     try:
#         duration = int(duration)
#     except (ValueError, TypeError):
#         rc += 1
#         print "Error: Invalid duration: %s" % duration
#         # sys.exit(1)
#     if rc > 0:
#         rc = False
#     else:
#         rc = True
#     return rc, mode, videoFormat, resolution, frameRate, duration
#

# def recordvideo(camera,cammodes, videomode="Video",videoformat="NTSC",videores="1080",fps="30",pt="on",duration=1000):
#     rc = False
#     rc, mode, videoFormat, resolution, frameRate, duration = parseCommand(videomode, videoformat, videores, fps, duration)
#
#     if not rc:
#         print "Error: Invalid camera mode: Skipped"
#         return rc, camera, ""
#     # if len(sys.argv) > 2:
#     #     mode, videoFormat, resolution, frameRate, duration = parseCommandlineArgs()
#     if not camera:
#         camera = GpCamera.GpCamera.connectOnCurrentWiFiNetwork()
#
#     # Set camera to <MODE> with <RESOLUTION> at <FRAME RATE>
#     camera.changeSubMode(mode)
#     camera.waitForPollingPeriod()
#     #camera.waitForPollingPeriod()
#     camera.setSetting(GpCameraSetting.SETUP_VIDEO_FORMAT, videoFormat)
#     camera.waitForPollingPeriod()
#     camera.setSetting(GpCameraSetting.VIDEO_RESOLUTION, resolution)
#     camera.waitForPollingPeriod()
#     camera.setSetting(GpCameraSetting.VIDEO_FPS, frameRate)
#     camera.waitForPollingPeriod()
#     camera.setSetting(GpCameraSetting.VIDEO_PROTUNE, pt)
#     camera.waitForPollingPeriod()
#     # Record a video for <DURATION MS>
#     d1 = round((duration/4), 0)
#     camera.setShutter(True)
#
#     camera.sleep(d1)
#     camera.waitForPollingPeriod()
#     camera.tagMoment()
#     camera.sleep(d1)
#     camera.waitForPollingPeriod()
#     camera.tagMoment()
#     camera.sleep(d1)
#     camera.waitForPollingPeriod()
#     camera.tagMoment()
#     camera.sleep(d1)
#     camera.waitForPollingPeriod()
#     camera.setShutter(False)
#     camera.waitForPollingPeriod()
#
#     # Get name of file just created
#     #filePath = GpCamera.getMostRecentMediaFile(camera.getMediaList(), GpMediaType.MEDIA_TYPE_VIDEO)
#     #filePath = camera.getMostRecentMediaFile(camera.getMediaList(), GpMediaType.MEDIA_TYPE_VIDEO)
#
#
#     mostRecentVideoFilePath = camera.getMostRecentMediaFilePath(GpMediaType.MEDIA_TYPE_VIDEO)
#     camera.waitForPollingPeriod()
#     videoFilename = mostRecentVideoFilePath.split("/")[-1]
#     camera.waitForPollingPeriod()
#     videoUri = camera.getVideoDownloadUri(mostRecentVideoFilePath, getHighRes=True)
#     camera.waitForPollingPeriod()
#     #videouri = camera.getVideoDownloadUri()
#     #camera.waitForPollingPeriod()
#     #videometa = camera.getVideoMetadata(filePath)
#     print "Recorded video: mode=%s, videoFormat=%s, resolution=%s, framerate=%s, duration=%s, \nfilePath=%s, \nuri=%s, \nmeta=%s" % (mode,
#                                                                                                               videoFormat[
#                                                                                                                   0],
#                                                                                                               resolution[
#                                                                                                                   0],
#                                                                                                               frameRate[
#                                                                                                                   0],
#                                                                                                               duration,
#                                                                                                             mostRecentVideoFilePath,
#                                                                                                               videoUri, "No meta yet")
#
#     rc = True
#     return rc, camera, mostRecentVideoFilePath

# 00 = {tuple} <type 'tuple'>: ('WVGA', 13)
# 01 = {tuple} <type 'tuple'>: ('720', 12)
# 02 = {tuple} <type 'tuple'>: ('720 SuperView', 11)
# 03 = {tuple} <type 'tuple'>: ('960', 10)
# 04 = {tuple} <type 'tuple'>: ('1080', 9)
# 05 = {tuple} <type 'tuple'>: ('1080 SuperView', 8)
# 06 = {tuple} <type 'tuple'>: ('1440', 7)
# 07 = {tuple} <type 'tuple'>: ('2.7K', 4)
# 08 = {tuple} <type 'tuple'>: ('2.7K 4:3', 6)
# 09 = {tuple} <type 'tuple'>: ('2.7K SuperView', 5)
# 10 = {tuple} <type 'tuple'>: ('4K', 1)
# 11 = {tuple} <type 'tuple'>: ('4K SuperView', 2)
# 00 = {tuple} <type 'tuple'>: ('12.5', 12)
# 01 = {tuple} <type 'tuple'>: ('15', 11)
# 02 = {tuple} <type 'tuple'>: ('24', 10)
# 03 = {tuple} <type 'tuple'>: ('25', 9)
# 04 = {tuple} <type 'tuple'>: ('30', 8)
# 05 = {tuple} <type 'tuple'>: ('48', 7)
# 06 = {tuple} <type 'tuple'>: ('50', 6)
# 07 = {tuple} <type 'tuple'>: ('60', 5)
# 08 = {tuple} <type 'tuple'>: ('80', 4)
# 09 = {tuple} <type 'tuple'>: ('90', 3)
# 10 = {tuple} <type 'tuple'>: ('100', 2)
# 11 = {tuple} <type 'tuple'>: ('120', 1)
# 12 = {tuple} <type 'tuple'>: ('240', 0)

def evaltuple(label, arrayitem):
    itemfound = False
    tubleitem = None
    itemName = None
    rc = 0
    if label and arrayitem:
        for item in arrayitem:
            if type(item) is tuple:
                itemName = item[0]
            # elif type(item) is list:
            #     itemName = item[0]
            elif type(item) is str:
                itemName = item
            elif type(item) is int:
                itemName = str(item)
            if itemName.lower() == str(label).lower():
                tubleitem = item
                itemfound = True
                break
    if not itemfound:
        print "Error: Invalid Label: " + str(label) + " - Tuple:" + str(arrayitem)
        rc = 0
    return rc, tubleitem


class camsettingssdk:
    videoFormat = None
    resolution = None
    fps = None
    fov = None
    duration = None
    protune = None
    lowlight = None
    interval = None
    main_mode = None
    spot = None
    sub_mode = None
    id = None
    camera_name = None


########################################################
#
#
#
########################################################
def parsecamerasettings(cam_settings):
    """
    Parse arguments from the commandline
    :return: A tuple of the form (type,resolution,frameRate,duration) which contains VALID values
    """
    rc = 0
    evalcount = 0
    usageStr = "%s -m <VIDEO MODE> -o <FORMAT> -r <RESOLUTION> -f <FRAME RATE> -d <DURATION>" % sys.argv[0]
    epilogStr = "Example: xxx"
    descriptionStr = "A utility to record a video of a specific type/resolution/frame-rate/duration"

    if not cam_settings:
        evalcount += 1
        print "Error: Invalid camera cam_settings"
        # sys.exit(1)
    camsdk = camsettingssdk()
    evalcount += rc
    rc, camsdk.videoFormat = evaltuple(cam_settings.video_format, CameraModes.VIDEO_FORMAT)
    evalcount += rc
    rc, camsdk.resolution = evaltuple(cam_settings.video_res, CameraModes.VIDEO_RESOLUTIONS)
    evalcount += rc
    rc, camsdk.fps = evaltuple(cam_settings.fps, CameraModes.VIDEO_FRAME_RATES)
    evalcount += rc
    rc, camsdk.fov = evaltuple(cam_settings.fov, CameraModes.VIDEO_FOV)
    evalcount += rc
    rc, camsdk.protune = evaltuple(cam_settings.protune, CameraModes.VIDEO_PROTUNE_OFFON)
    evalcount += rc
    rc, camsdk.interval = evaltuple(cam_settings.interval, CameraModes.VIDEO_LOOPING)
    evalcount += rc

    rc, camsdk.lowlight = evaltuple(cam_settings.lowlight, CameraModes.VIDEO_LOW_LIGHT_OFFON)
    # evalcount += rc
    rc, camsdk.main_mode = evaltuple(cam_settings.main_mode, CameraModes.MAIN_MODES)
    evalcount += rc
    rc, camsdk.spot = evaltuple(cam_settings.spot, CameraModes.VIDEO_SPOT_METER_OFFON)
    # evalcount += rc
    rc, camsdk.sub_mode = evaltuple(cam_settings.sub_mode, CameraModes.VIDEO_MODES)
    evalcount += rc
    camsdk.duration = cam_settings.duration
    camsdk.id = cam_settings.id
    camsdk.camera_name = cam_settings.camera_name

    # videoFormat = cam_settings.video_format
    # formatFound = False
    # for format in CameraModes.VIDEO_FORMAT:
    #     formatName = format[0]
    #     if formatName.lower() == videoFormat.lower():
    #         videoFormat = format
    #         formatFound = True
    #         break
    # if not formatFound:
    #     rc += 1
    #     print "Error: Invalid resolution: '%s'" % videoFormat
    #     #sys.exit(1)
    #
    # resolution = cam_settings.video_res
    # resolutionFound = False
    # for res in CameraModes.VIDEO_RESOLUTIONS:
    #     displayName = res[0]
    #     if displayName == resolution:
    #         resolution = res
    #         resolutionFound = True
    #         break
    # if not resolutionFound:
    #     rc += 1
    #     print "Error: Invalid resolution: '%s'" % resolution
    #     #sys.exit(1)

    # frameRate = cam_settings.fps
    # frameRateFound = False
    # for rate in CameraModes.VIDEO_FRAME_RATES:
    #     displayName = rate[0]
    #     if (displayName == frameRate):
    #         frameRate = rate
    #         frameRateFound = True
    #         break
    # if not frameRateFound:
    #     rc += 1
    #     print "Error: Invalid frame rate: '%s'" % frameRate
    #     #sys.exit(1)

    # fovitem = cam_settings.fov
    # fovFound = False
    # for fov in CameraModes.VIDEO_FOV:
    #     displayName = rate[0]
    #     if (displayName == fov):
    #         frameRate = rate
    #         fovFound = True
    #         break
    # if not frameRateFound:
    #     rc += 1
    #     print "Error: Invalid frame rate: '%s'" % frameRate
    #     #sys.exit(1)

    camsdk.duration = int(cam_settings.duration)
    try:
        camsdk.duration = int(cam_settings.duration)
    except (ValueError, TypeError):
        rc += 1
        print "Error: Invalid duration: %s" % str(camsdk.duration)
        # sys.exit(1)

    # yes no to push settings to camera after setting mode eval
    if evalcount > 0:
        rc = False
    else:
        rc = True

    return rc, camsdk  # mode,videoFormat,resolution,frameRate,duration)

def evalcamerachangeresult(result,camsetting,gpsetting):
    if not result:

        #print "CAMERA MODE CHANGE ERROR: " + ', '.join("%s: %s" % item for item in smode.items())
        print "CAMERA MODE CHANGE ERROR: " +str(camsetting) +" - " +str(gpsetting)
        return False
    return True

def set_video(camera, cammodes,sdkvalues, camsettings):
    camera.waitForPollingPeriod()
    if not evalcamerachangeresult(camera.changeSubMode(sdkvalues.sub_mode),"",sdkvalues.sub_mode):
        return False

    camera.waitForPollingPeriod()

    if sdkvalues.sub_mode.lower() == "looping":
        if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_LOOPING, sdkvalues.interval), GpCameraSetting.VIDEO_LOOPING, sdkvalues.interval):
            return False
    else:
        camera.waitForPollingPeriod()
        if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_PROTUNE, sdkvalues.protune),GpCameraSetting.VIDEO_PROTUNE,sdkvalues.protune):
            return False

    camera.waitForPollingPeriod()

    # camera.waitForPollingPeriod()
    if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.SETUP_VIDEO_FORMAT, sdkvalues.videoFormat),GpCameraSetting.SETUP_VIDEO_FORMAT,sdkvalues.videoFormat):
        return False

    camera.waitForPollingPeriod()


    if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_RESOLUTION, sdkvalues.resolution),GpCameraSetting.VIDEO_RESOLUTION,sdkvalues.resolution):
        return False

    camera.waitForPollingPeriod()

    if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_FPS, sdkvalues.fps),GpCameraSetting.VIDEO_FPS,sdkvalues.fps):
        return False

    camera.waitForPollingPeriod()

    if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_FOV, sdkvalues.fov),GpCameraSetting.VIDEO_FOV,sdkvalues.fov):
        return False

    camera.waitForPollingPeriod()

    if sdkvalues.lowlight:
        if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_LOW_LIGHT, sdkvalues.lowlight),GpCameraSetting.VIDEO_LOW_LIGHT,sdkvalues.lowlight):
            return False
    if sdkvalues.spot:
        if not evalcamerachangeresult(camera.setSetting(GpCameraSetting.VIDEO_SPOT_METER, sdkvalues.spot),GpCameraSetting.VIDEO_SPOT_METER,sdkvalues.spot):
            return False

    camera.waitForPollingPeriod()


    # Record a video for <DURATION MS>
    sec = (sdkvalues.duration / 1000)
    d1 = round((sec/4), 3)
    print "duration " + str(sec)
    camera.setShutter(True)

    #camera.sleep(d1)
    print "tag sleep " + str(d1)
    time.sleep(d1)
    camera.waitForPollingPeriod()
    camera.tagMoment()
    print "tag sleep " + str(d1)
    time.sleep(d1)
    #camera.sleep(d1)
    camera.waitForPollingPeriod()
    camera.tagMoment()
    print "tag sleep " + str(d1)
    time.sleep(d1)
    #camera.sleep(d1)
    camera.waitForPollingPeriod()
    camera.tagMoment()
    print "tag sleep " + str(d1)
    time.sleep(d1)
    #camera.sleep(d1)
    camera.waitForPollingPeriod()
    camera.setShutter(False)
    camera.waitForPollingPeriod()


    # Get name of file just created
    # filePath = GpCamera.getMostRecentMediaFile(camera.getMediaList(), GpMediaType.MEDIA_TYPE_VIDEO)
    # filePath = camera.getMostRecentMediaFile(camera.getMediaList(), GpMediaType.MEDIA_TYPE_VIDEO)

    mostRecentVideoFilePath = camera.getMostRecentMediaFilePath(GpMediaType.MEDIA_TYPE_VIDEO)
    camera.waitForPollingPeriod()
    videoFilename = mostRecentVideoFilePath.split("/")[-1]
    camera.waitForPollingPeriod()
    videoUri = camera.getVideoDownloadUri(mostRecentVideoFilePath, getHighRes=True)
    camera.waitForPollingPeriod()
    # videouri = camera.getVideoDownloadUri()
    # camera.waitForPollingPeriod()
    # videometa = camera.getVideoMetadata(filePath)
    modes = vars(cammodes)
    print "Recorded: " + ', '.join("%s: %s" % item for item in modes.items())
    print "File=" + mostRecentVideoFilePath
    print "URI=" + videoUri

    return True

def record(camera, cammodes, camsettings):
    rc = False
    # rc, mode, videoFormat, resolution, frameRate, duration = parseCommand(videomode, videoformat, videores, fps, duration)
    rc, sdkvalues = parsecamerasettings(camsettings)
    if not rc:
        print "Error: Invalid camera mode: Skipped"
        return rc, camera, ""
    # if len(sys.argv) > 2:
    #     mode, videoFormat, resolution, frameRate, duration = parseCommandlineArgs()
    if not camera:
        camera = GpCamera.GpCamera.connectOnCurrentWiFiNetwork()
    if not camera:
        print "Error: Invalid camera: GpCamera.GpCamera.connectOnCurrentWiFiNetwork()"
        return rc, camera, ""

    failcount = 0
    # Set camera to <MODE> with <RESOLUTION> at <FRAME RATE>
    camera.waitForPollingPeriod()
    if not evalcamerachangeresult(camera.changeMode(sdkvalues.main_mode),"",sdkvalues.main_mode):
        return
    if sdkvalues.main_mode.lower() == "video":
        rc = set_video(camera, cammodes, sdkvalues, camsettings)
    elif sdkvalues.main_mode.lower() == "video":
        print "do photos"
    elif sdkvalues.main_mode.lower() == "multi":
        print "do multi"

    return rc, camera


######################################################
#
######################################################
def lastcaminfo(camera):
    print camera.getCameraInfo()
    print camera.getVideoDownloadUri()
    # medialist = camera.getMediaList()
    # print medialist
    print camera.getScreennailUri()
    print camera.getThumbnailUri()
    # print camera.getMostRecentMediaFile(medialist, "Video")
    # print camera.getMediaListFilenames(medialist)


######################################################
# wrapper for recordvideo to manage errors and logging to json the video mode capture
# build key, skip if key exists, set video mode and record, trap for errors,
# save mode key into dictionary, save dict to file
######################################################
# def record_video(cam, cammodes, videomode="Video", videoformat="NTSC", videores="1080", fps="30", pt = None, duration=1000):
#     #key = cam name | cam fw | main mode | sub mode| format | resolution | fps | pt | duration
#     if pt and len(pt)==2:
#         kpt = pt[0]
#     dkey = cam.getCameraInfo().getModelName() + "|" + videomode + "|" + videoformat + "|" + videores + "|" + str(fps)+"|pt-" + str(kpt)+"|" + str(duration)
#     rc = False
#     lastfile = ""
#     try:
#         if not dkey in cammodes.Selected.RepoList.d_imagelist:
#             rc, cam, lastfile = recordvideo(cam, cammodes, videomode, videoformat, videores, fps, pt, duration)
#             if rc:
#                 if lastfile and len(lastfile) > 0:
#                     if cammodes.Selected.RepoList.saveImagekey(dkey, lastfile):
#                         cammodes.Selected.RepoList.putDictToFile()
#                         rc = True
#                 else:
#                     print "Failed to generate image file on sdcard"
#             return rc, cam, lastfile
#         else:
#             print "Found in ImageList:" + dkey
#             print cammodes.Selected.RepoList.d_imagelist[dkey]
#             return rc, cam, cammodes.Selected.RepoList.d_imagelist[dkey]
#     except:
#         print "Error:" + dkey
#     return rc, cam, lastfile

def set_cam_settings(camera, cammodes, cam_settings):  # record_video
    # rc, cam_sdk = parsecamerasettings(cam_settings)
    # if rc:
    record(camera, cammodes, cam_settings)


def callbackmsg(camera, cammodes, cam_settings):
    objs = vars(cam_settings)
    # print "callback:"+str(msg)
    print ', '.join("%s: %s" % item for item in objs.items())
    set_cam_settings(camera, cammodes, cam_settings)

    # pt = GpCameraSettingOption.VIDEO_PROTUNE_ON
    # testcount += 1
    # print "-------------------------------"
    # print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(f) + "-pt:on-" + "-duration:" + str(dur)
    # rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
    # print str(rc) + " - " + lastfile
    # print "-------------------------------"


# def modedriver(cam, cammodes):
#     cammodessettings = CameraModeSettings(cam, cammodes, "HERO4 Black",callbackmsg)
#     duration = []
#     video_res = []
#     ntscpal = {"NTSC","PAL"}
#     fps = {}
#     modes = {}
#     pt = False
#     fov = {}
#     lowlight=False
#     spot = False
#     testcount = 0
#     rc = False
#     lastfile = None
#     if cam.getCameraInfo().getModelName() == "HERO4 Black":
#         main_sub_modes = ["video|video","Video|Looping","video|videophoto","video|timelapse","photo|single","photo|continous","photo|night","multi|burst","multi|timelapse","multi|night"]
#         duration = [5000,10000,30000,300000,600000] #seconds 1,5,10,30,5min,10min
#         looping = ["Max",5,20,60,120]
#         #fps["loopingWVGA"] = []
#         video_res = ["WVGA", "960", "720", "720 SuperView", "4K", "4K SuperView", "2.7K", "2.7K SuperView", "1440", "1080", "1080 SuperView"]
#
#         fps["960"] = {"ptntsc":[60], "ptpal":[50], "ptntscpal": [120]}
#         fps["720"] = {"ptntsc":[ 30,60], "ptpal": [25,50], "ptntscpal": [120]}
#         fps["720 SuperView"] = {"ptntsc":[60], "ptpal":[50], "ptntscpal":[120]}
#         fps["4K"] = {"ptntsc":[30], "ptpal": [25], "ptntscpal":[24]}
#         fps["4K SuperView"] = {"ptntscpal": [24]}
#         fps["2.7K"] = {"ptntsc":[30, 60], "ptpal": [25], "ptntscpal": [24, 48]}
#         fps["2.7K SuperView"] = {"ptntsc": [30], "ptpal": [25]}
#         fps["2.7K 4:3"] = {"ptntsc": [30], "ptpal": [25]}
#         fps["1440"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal":[24,48,80]}
#         fps["1080"] = {"ptntsc":[30, 60], "ptpal":[25, 50], "ptntscpal": [120, 90, 24, 48]}
#         fps["1080 SuperView"] = {"ptntsc":[30, 60], "ptpal": [25, 50], "ptntscpal":[24,48,80]}
#
#         #pt = ["ON","OFF"]
#         keyitem = "pt"
#
#
#     elif cam.getCameraInfo().getModelName() == "HERO4 Silver":
#         duration = [5000, 10000, 30000, 300000, 600000]  # seconds 1,5,10,30,5min,10min
#         video_res = ["WVGA", "960", "720", "720 SuperView", "4K", "4K SuperView", "2.7K", "2.7K SuperView", "1440", "1080",
#                      "1080 SuperView"]
#         fps["WVGA"] = {"ptntscpal": [240]}
#         fps["960"] = {"ptntsc": [60], "ptpal": [50], "ptntscpal": [120]}
#         fps["720"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [120]}
#         fps["720 SuperView"] = {"ptntsc": [60], "ptpal": [50], "ptntscpal": [120]}
#         fps["4K"] = {"ptntsc": [30], "ptpal": [25], "ptntscpal": [24]}
#         fps["4K SuperView"] = {"ptntscpal": [24]}
#         fps["2.7K"] = {"ptntsc": [30, 60], "ptpal": [25], "ptntscpal": [24, 48]}
#         fps["2.7K SuperView"] = {"ptntsc": [30], "ptpal": [25]}
#         fps["2.7K 4:3"] = {"ptntsc": [30], "ptpal": [25]}
#         fps["1440"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [24, 48, 80]}
#         fps["1080"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [120, 90, 24, 48]}
#         fps["1080 SuperView"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [24, 48, 80]}
#         # pt = ["ON","OFF"]
#         keyitem = "pt"
#
#     elif cam.getCameraInfo().getModelName() == "HERO4 Session":
#         duration = [5000, 10000, 30000, 300000, 600000]  # seconds 1,5,10,30,5min,10min
#         video_res = ["WVGA", "960", "720", "720 SuperView", "4K", "4K SuperView", "2.7K", "2.7K SuperView", "1440", "1080",
#                      "1080 SuperView"]
#         fps["WVGA"] = {"ptntscpal": ["240"]}
#         fps["960"] = {"ptntsc": [60], "ptpal": [50], "ptntscpal": [120]}
#         fps["720"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [120]}
#         fps["720 SuperView"] = {"ptntsc": [60], "ptpal": [50], "ptntscpal": [120]}
#         fps["4K"] = {"ptntsc": [30], "ptpal": [25], "ptntscpal": [24]}
#         fps["4K SuperView"] = {"ptntscpal": [24]}
#         fps["2.7K"] = {"ptntsc": [30, 60], "ptpal": [25], "ptntscpal": [24, 48]}
#         fps["2.7K SuperView"] = {"ptntsc": [30], "ptpal": [25]}
#         fps["2.7K 4:3"] = {"ptntsc": [30], "ptpal": [25]}
#         fps["1440"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [24, 48, 80]}
#         fps["1080"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [120, 90, 24, 48]}
#         fps["1080 SuperView"] = {"ptntsc": [30, 60], "ptpal": [25, 50], "ptntscpal": [24, 48, 80]}
#         # pt = ["ON","OFF"]
#         keyitem = "pt"
#
#     else:
#         print "Invalid camera name:" + cam.getCameraInfo().getModelName()
#         return
#     #Iterate the modes
#     for dur in duration:
#         for videomode in ntscpal:
#             for vidres in video_res:
#                 if vidres in fps:
#                     fpsitem = fps[vidres]
#                     k = "pt" + videomode.lower()
#                     if k in fpsitem:
#                         fitems = fpsitem[k]
#                         for f in fitems:
#                             pt = GpCameraSettingOption.VIDEO_PROTUNE_ON
#                             testcount += 1
#                             print "-------------------------------"
#                             print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
#                                 f) + "-pt:on-" + "-duration:" + str(dur)
#                             rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
#                             print str(rc) + " - " + lastfile
#                             print "-------------------------------"
#                             pt = GpCameraSettingOption.VIDEO_PROTUNE_OFF
#                             print "-------------------------------"
#                             testcount += 1
#                             print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
#                                 f) + "-pt:off-" + "-duration:" + str(dur)
#                             rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
#                             print str(rc) + " - " + lastfile
#                             print "-------------------------------"
#                     k = "pt" + videomode.lower() + "pal"
#                     if k in fpsitem:
#                         fitems = fpsitem[k]
#                         for f in fitems:
#                             pt = GpCameraSettingOption.VIDEO_PROTUNE_ON
#                             print "-------------------------------"
#                             testcount += 1
#                             print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
#                                 f) + "-pt:on-duration:" + str(dur)
#                             rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
#                             print str(rc) + " - " + lastfile
#                             print "-------------------------------"
#
#                             pt = GpCameraSettingOption.VIDEO_PROTUNE_OFF
#                             print "-------------------------------"
#                             testcount += 1
#                             print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
#                                 f) + "-pt:off-duration:" + str(dur)
#                             rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
#                             print str(rc) + " - " + lastfile
#                             print "-------------------------------"
#                     k = "pt" + "ntsc" + videomode.lower()
#                     if k in fpsitem:
#                         fitems = fpsitem[k]
#                         for f in fitems:
#                             pt = GpCameraSettingOption.VIDEO_PROTUNE_ON
#                             print "-------------------------------"
#                             testcount += 1
#                             print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
#                                 f) + "-pt:on-duration:" + str(dur)
#                             rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
#                             print str(rc) + " - " + lastfile
#                             print "-------------------------------"
#                             pt = GpCameraSettingOption.VIDEO_PROTUNE_OFF
#                             print "-------------------------------"
#                             testcount += 1
#                             print str(testcount) + ". " + videomode + "-" + vidres + "-" + str(
#                                 f) + "-pt:off-duration:" + str(dur)
#                             rc, cam, lastfile = record_video(cam, cammodes, "Video", videomode, vidres, str(f), pt, dur)
#                             print str(rc) + " - " + lastfile
#                             print "-------------------------------"
#     return

def main():
    """
    Script begins here!

    Prerequisite: You should be connected to a GoPro camera via WiFi before running this script

    :return: 0 if there are no errors; 1 otherwise
    """
    GpCameraWifiConnect.main() # if args for camera AP try to connect automatically
    cammodes = CameraModes
    camera = None
    for i in range(0, 10):  # retry connection to camera. Normally has 75% first try connection failures
        try:
            camera = GpCamera.GpCamera.connectOnCurrentWiFiNetwork()
            if camera:
                break
        except:
            time.sleep(5)

    camera.waitForPollingPeriod()
    imagerepojson = ImageRepoJSON(camera)
    cammodes.Selected.RepoList = imagerepojson

    # to reset sdcard remove target json from /Automation/imagerepo/target.json
    # will assume a complete new capture
    if imagerepojson.isNewList:
        camera.deleteAllFilesOnSdCard()

    camera.resetProtuneToDefault()
    # lastcaminfo(camera)
    # modedriver(camera, cammodes)
    CameraModeSettings(camera, cammodes, "HERO4 Black", callbackmsg)


if __name__ == "__main__":
    main()

# main
#   cammodessettings = CameraModeSettings(camera, cammodes, "HERO4 Black",callbackmsg)
#       CameraModeSettings.self.set_camera_mode()
#       CameraModeSettings.sself.iterate_cameramodes()
#           CameraModeSettings.self.listener(self.camera, self.cammodes, camsettings)
#               callbackmsg
#                   set_cam_settings
#                       parsecamerasettings
#                           recordvideo2
