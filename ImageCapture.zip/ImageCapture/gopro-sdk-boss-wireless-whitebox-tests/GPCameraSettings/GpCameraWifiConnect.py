#!/usr/bin/python
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: GpCameraWifiConnect.py
# Description: A Utility to connect wifi to target camera with SSID assume camera is broadcasting
#              GpCamera can call this to intiate the wifi connectivity on the nic.
# Author: Keith Fischer
# Date Created: 19 May 2016
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# args example: "-s auto4pipe -p password1 -n en0"
# Note: windows has not been tested yet
# For Mac & Window
#
# Examples ----------------------
# output example: success:
# Connecting WiFi...
# WiFi connected succesfully
# platform:Darwin, ssid:auto4pipe, pw:password1, nic:default
# Process finished with exit code 0
# ----------------------
# output example: AP not found:
# Could not find network auto5pipe.
# Failed: WiFi Connect
# platform:Darwin, ssid:auto5pipe, pw:password1, nic:default
# Process finished with exit code 1
# -----------------------
# output example: invalid password:
# Could not find network auto5pipe.
# Failed: WiFi Connect
# Failed to join network auto4pipe.
# Error: -3905 The operation couldn't be completed com.apple.wifi.apple80211API.error error -3905
# platform:Darwin, ssid:auto4pipe, pw:password2, nic:default
# Process finished with exit code 1
# -----------------------
# =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import subprocess
import platform
from GpCameraDiscoverer import *

# setwificonnect returns True on success, False
# Each platform has unique tool for making the AP connection
# Non Windows could use this single library:
# https://pypi.python.org/pypi/wireless/0.3.0
# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
def setwificonnect(platform, ssid,pw, wifi_nic = None):
    rc = False
    if not ssid or not pw:
        return rc
    if platform == "Darwin":
        nic = "en0" #which nic: builtin wifi, check network prefs to confirm
        if wifi_nic:
            nic = wifi_nic
        # networksetup -setairportnetwork en0 autobackdoor4851 password1
        exe = "networksetup -setairportnetwork %s %s %s" % (nic,ssid,pw)
        proc = subprocess.Popen(exe, shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

        while True:
            out = proc.stderr.read(1)

            if out == '' and proc.poll() != None:
                break
            if out != '':
                sys.stdout.write(out)
                sys.stdout.flush()
            else:
                sys.stdout.write('.')
                sys.stdout.flush()

        stdout,err = proc.communicate()
        if stdout:
            print stdout
        if err:
            print err
        elif not stdout and not err:
            rc = True

    elif platform == "Windows":
        rc = False
        # AP SSID profile must already exist
        process = subprocess.Popen(
            'netsh wlan connect {0}'.format(ssid),
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        if stderr:
            print stderr
        if 'Connection request was completed successfully' in stdout:
            print stdout
            rc = True

    elif platform == "Linux":
        print "Not implemented yet"
        rc = False


    return rc


# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
def parseargs():
    ssid = None
    pw = None
    nic = None
    for i in range(1,len(sys.argv)):
        if sys.argv[i] =="-s": #ssid
            i+=1
            ssid = sys.argv[i]
        elif sys.argv[i] =="-p": #password
            i+=1
            pw = sys.argv[i]
        elif sys.argv[i] =="-n": #network
            i+=1
            nic = sys.argv[i]
    return ssid,pw,nic


# --------------------------------------------------------------------------
#
# --------------------------------------------------------------------------
def main():
    ssid, pw, nic = parseargs()
    if not ssid or not pw:
        print "Error: missing ssid or pw in arguments"
        print "for ssid '-s myssid'"
        print "for password '-p mypassword'"
        print "for network '-n en0'"
        exit(1)
    print "Connecting WiFi..."
    connected = False
    for i in range(1, 5):
        if setwificonnect(platform.system(), ssid, pw, nic):
            print "WiFi connected succesfully"
            connected = True
            break
        else:
            print "%s Failed: WiFi Connect" % str(i)

    if not nic:
        nic = "default"
    print "platform:%s\nssid:%s\npw:%s\nnic:%s" % (platform.system(), ssid, pw, nic)
    if not connected:
        exit(1)

if __name__ == "__main__":
    main()
