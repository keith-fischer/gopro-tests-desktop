#!/usr/bin/python
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
# File: ConfluenceJiraManager.py
# Overview: A class designed to allow users to XXX
# Author: Sean Foley
# Date Created: 23 May 2016
#
# Useful REST API Documentation:
#   https://docs.atlassian.com/jira/REST/6.3.11/
#=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

import ast
import base64
import getpass
import json
import os
import pprint
import sys
import traceback
import urllib
import requests


class JiraMetadataKeys:
    """
    A lookup table of keys from JIRA issue metadata (i.e. return value of ConfluenceJiraManager.getIssueMetadata)
    """

    # Primary information about a JIRA ticket
    ISSUE_ID  = 'id'
    ISSUE_KEY = 'key'
    FIELDS    = 'fields'

    # Non-custom fields
    REPORTER     = 'reporter'
    DATE_CREATED = 'created'
    ATTACHMENTS  = 'attachment'
    DESCRIPTION  = 'description'
    PRIORITY     = 'priority'
    PROJECT      = 'project'
    FIX_VERSIONS = 'fixVersions'
    LABELS       = 'labels'
    SUMMARY      = 'summary'
    ISSUE_TYPE   = 'issuetype'
    CREATOR      = 'creator'
    ISSUE_LINKS  = 'issuelinks'
    COMMENT      = 'comment'
    COMPONENTS   = 'components'
    SUBTASKS     = 'subtasks'
    VERSIONS     = 'versions'
    STATUS       = 'status'
    RESOLUTION   = 'resolution'

    # Attachment related keys
    ATTACHMENT_AUTHOR   = 'author'
    ATTACHMENT_CONTENT  = 'content'
    ATTACHMENT_FILENAME = 'filename'
    ATTACHMENT_MIMETYPE = 'mimeType'


class JiraMetadataParser:
    @staticmethod
    def getAttachments(metadata):
        """
        Get information about JIRA attachments
        :param metadata: A json/dict from ConfluenceJiraManager.getIssueMetadata containing information about an issue
        :return: A list of attachment metadata or None if there was an error
        """

        if metadata.__class__ is not dict:
            print "Error: Expected dict for metadata; got '%s'" % metadata.__class__
            return None

        fields = metadata.get(JiraMetadataKeys.FIELDS)
        if fields is None:
            print "Error: Unable to parse fields from metadata"
            return None

        attachments = fields.get(JiraMetadataKeys.ATTACHMENTS)
        return attachments


class ConfluenceJiraManager:
    """
    An API that helps XXX
    """

    # Static member variables
    GOPRO_JIRA_SERVER = "https://jira.gopro.com"


    def __init__(self, jiraServerUrl, username, password):
        self.__username = username
        self.__password = password
        self.__baseUrl = "%s/rest/api/latest/issue" % jiraServerUrl


        """
        print "Getting auth for JIRA...?"
        headers = {"Content-Type": "application/json"}
        url = "%s/rest/auth/latest/session" % jiraServerUrl
        data = {
            'username': self.__username,
            'password': self.__password
        }
        response = requests.post(
            url,
            data=str(data),
            headers=headers,
            auth=(self.__username, self.__password)
        )

        print "Response:    '%s'" % response
        print "Content:     '%s'" % response.content
        print "Raw Content: '%s'" % response.raw.data
        sys.exit(0)
        """


    def getIssueMetadata(self, issue):
        """
        Get metadata about a specific JIRA issue

        :param issue: The issue ID (e.g. "BOSS-1234")
        :return: A dict/json containing information about the issue or None if there was an error
        """

        headers = {"Content-Type": "application/json"}
        url = "%s/%s" % (self.__baseUrl, issue)

        try:
            response = requests.get(
                url,
                headers=headers,
                auth=(self.__username, self.__password)
            )
        except requests.exceptions.Timeout:
            print "Timed out trying to connect"
            return None
        except requests.exceptions.ConnectionError:
            print "ConnectionError occurred."
            return None
        except:
            print "Unknown error occurred."
            traceback.print_exc()
            return None

        response.raise_for_status()
        return response.json()


    def downloadAttachments(self, issue, filenamePatterns=None):
        """
        Download attachments from a specific JIRA issue

        :param issue: The JIRA ticket's issue name (e.g. "BOSS-1234")
        :param filenamePatterns: A list of uncompiled regular expressions to match against attached files for download
        :return: The number of files downloaded or None if there's an error
        """

        metadata = self.getIssueMetadata(issue)
        if metadata is None:
            return None

        attachmentsList = JiraMetadataParser.getAttachments(metadata)
        if attachmentsList is None:
            print "Error: Unable to get attachments"
            return None

        numFilesDownloaded = 0
        for attachment in attachmentsList:
            attachmentUrl = attachment.get(JiraMetadataKeys.ATTACHMENT_CONTENT)
            if attachmentUrl is None:
                print "Error: Unable to parse attachment URL from metadata"
                print "Metadata:\n%s" % pprint.pformat(attachment)
                return None
            attachmentUrl += "?expand=attachment"

            attachmentFilename = attachment.get(JiraMetadataKeys.ATTACHMENT_FILENAME)
            if attachmentFilename is None:
                print "Error: Unable to parse attachment filename from metadata"
                print "Metadata\n%s" % pprint.pformat(attachment)
                return None

            attachmentMimeType = attachment.get(JiraMetadataKeys.ATTACHMENT_MIMETYPE)
            if attachmentMimeType is None:
                print "Error: Unable to parse mime type from metadata"
                print "Metadata:\n%s" % pprint.pformat(attachment)
                return None

            headers = {"Content-Type": attachmentMimeType}
            response = requests.get(
                attachmentUrl,
                headers=headers,
                auth=(self.__username, self.__password),
            )
            response.raise_for_status()

            print "Debug:"
            print "  Headers:         '%s'" % headers
            print "  URL:             '%s'" % attachmentUrl
            print "  Response:        '%s'" % response
            print "  Content:         '%s'" % response.content
            print "  Request Headers: '%s'" % response.request.headers
            print "  Is Redirect?     %s"   % response.is_redirect
            print "  Is Perm. Redir?  %s"   % response.is_permanent_redirect


    def createTemplateTicket(self):
        pass



if __name__ == "__main__":

    if len(sys.argv) == 3+1:
        username,password,issue = sys.argv[1:]
    else:
        username = raw_input("Username: ")
        password = getpass.getpass("Password: ")
        issue    = raw_input("Issue: ")

    jira = ConfluenceJiraManager(ConfluenceJiraManager.GOPRO_JIRA_SERVER, username, password)
    jira.downloadAttachments(issue)

    print "Done."

